package com.skcc.bcsvc.co.biz;

import java.util.Map;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;

/**
 * [DU]사용자.
 * <pre>
 * [DU]사용자
 * </pre>
 * 
 * @author mscho (조명신)
 * @since 2018-06-11 11:26:23
 */
@BizUnit("[DU]사용자")
public class DUSER_01 extends nexcore.framework.biz.online.DataUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */

	/**
	 * Default Constructor
	 */
	public DUSER_01(){
		super();
	}

	/**
	 * [DM]사용자 조회.
	 * <pre>
	 * [DM]사용자 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author mscho (조명신)
	 * @since 2018-06-11 11:26:54
	 */
	@BizMethod("[DM]사용자 조회")
	public IDataSet s001(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    IRecord record = dbSelectSingle("S001", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;
	}
	
	/**
	 * [DM]회원가입.
	 * <pre>
	 * 
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author 김인경(kimig)
	 * @since 2018-06-22 16:51:28
	 */
	@BizMethod("[DM]회원가입")
	public IDataSet i001(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    int result = dbInsert("I001", requestData, onlineCtx);
	    responseData.put("result", result);
	
	    return responseData;
	}

	/**
	 * [DM] 사용자 조회-아이디 찾기.
	 * <pre>
	 * [DM] 사용자 조회-아이디 찾기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-22 13:16:00
	 */
	@BizMethod("[DM] 사용자 조회-아이디 찾기")
	public IDataSet s002(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    IRecord record = dbSelectSingle("S002", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;
	}

	/**
	 * [DM] 비밀번호 찾기(조회).
	 * <pre>
	 * [DM] 비밀번호 찾기(조회)
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * <pre>
	 * </pre>
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * <pre>
	 * </pre>
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-22 16:39:51
	 */
	@BizMethod("[DM] 비밀번호 찾기(조회)")
	public IDataSet s003(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	
	    IRecord record = dbSelectSingle("S003", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;
	}

	/**
	 * [DM] 비밀번호 찾기(저장).
	 * <pre>
	 * [DM] 비밀번호 찾기(저장)
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-22 16:55:34
	 */
	@BizMethod("[DM] 비밀번호 찾기(저장)")
	public IDataSet u001(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();

	    int row = dbUpdate("U001", requestData, onlineCtx);

	    responseData.put("EXPECTED_ROW", row);
	
	    return responseData;
	}

	/**
	 * [DM]비밀번호 변경.
	 * <pre>
	 * [DM]비밀번호 변경
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-06-25 10:56:49
	 */
	@BizMethod("[DM]비밀번호 변경")
	public IDataSet u002(IDataSet requestData, IOnlineContext onlineCtx) {
		 IDataSet responseData = new DataSet();

		 int row = dbUpdate("U002", requestData, onlineCtx);

		 responseData.put("EXPECTED_ROW", row);
		
		 return responseData;
	}

	/**
	 * [DM]비밀번호 변경(조회).
	 * <pre>
	 * [DM]비밀번호 변경(조회)
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-06-25 13:36:02
	 */
	@BizMethod("[DM]비밀번호 변경(조회)")
	public IDataSet s004(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();
		
	    IRecord record = dbSelectSingle("S004", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;
	}

	/**
	 * [DM] 중복확인 - 아이디.
	 * <pre>
	 * [DM] 중복확인 - 아이디
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-25 15:20:01
	 */
	@BizMethod("[DM] 중복확인 - 아이디")
	public IDataSet s005(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    IRecord record = dbSelectSingle("S005", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;	
	}

	/**
	 * [DM] 중복확인 - 모바일.
	 * <pre>
	 * [DM] 중복확인 - 모바일
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-25 15:23:33
	 */
	@BizMethod("[DM] 중복확인 - 모바일")
	public IDataSet s006(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    IRecord record = dbSelectSingle("S006", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;	
	}

	/**
	 * [DM] 중복확인 - 이메일.
	 * <pre>
	 * [DM] 중복확인 - 이메일
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-25 15:25:00
	 */
	@BizMethod("[DM] 중복확인 - 이메일")
	public IDataSet s007(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    IRecord record = dbSelectSingle("S007", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	
	    return responseData;
	}
	
	/**
	 * [DM]비밀번호 오류횟수 카운트업.
	 * <pre>
	 * [DM]비밀번호 오류횟수 카운트업
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimjh (김준호)
	 * @since 2018-06-25 15:32:27
	 */
	@BizMethod("[DM]비밀번호 오류횟수 카운트업")
	public IDataSet u003(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();

		 int row = dbUpdate("U003", requestData, onlineCtx);

		 responseData.put("EXPECTED_ROW", row);
	
	    return responseData;
	}

	/**
	 * [DM]비밀번호 오류횟수 초기화.
	 * <pre>
	 * [DM]비밀번호 오류횟수 초기화
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimjh (김준호)
	 * @since 2018-06-25 17:39:03
	 */
	@BizMethod("[DM]비밀번호 오류횟수 초기화")
	public IDataSet u004(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();

		 int row = dbUpdate("U004", requestData, onlineCtx);

		 responseData.put("EXPECTED_ROW", row);
	
	    return responseData;
	}

	/**
	 * [DM] 디바이스 잠금 확인.
	 * <pre>
	 * [DM] 디바이스 잠금 확인
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-26 13:33:24
	 */
	@BizMethod("[DM] 디바이스 잠금 확인")
	public IDataSet s008(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    IRecord record = dbSelectSingle("S008", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }else{
	    	// not exists device, return 'N'
	    	responseData.put("APP_LOCK_YN", "N");
	    }
	
	    return responseData;
	}

	/**
	 * [DM] 디바이스 잠금 해제.
	 * <pre>
	 * [DM] 디바이스 잠금 해제
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-26 15:27:26
	 */
	@BizMethod("[DM] 디바이스 잠금 해제")
	public IDataSet u005(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();

		int row = dbUpdate("U005", requestData, onlineCtx);

		responseData.put("EXPECTED_ROW", row);
		
	    return responseData;
	}

	/**
	 * [DM] 임시비밀번호 여부 해제.
	 * <pre>
	 * [DM] 임시비밀번호 여부 해제
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimjh (김준호)
	 * @since 2018-06-27 13:01:22
	 */
	@BizMethod("[DM] 임시비밀번호 여부 해제")
	public IDataSet u006(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();

		int row = dbUpdate("U006", requestData, onlineCtx);

		responseData.put("EXPECTED_ROW", row);
		
	    return responseData;
	}

	/**
	 * [DM] 디바이스 잠금.
	 * <pre>
	 * [DM] 디바이스 잠금
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimjh (김준호)
	 * @since 2018-06-27 13:12:16
	 */
	@BizMethod("[DM] 디바이스 잠금")
	public IDataSet u007(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();

		int row = dbUpdate("U007", requestData, onlineCtx);

		responseData.put("EXPECTED_ROW", row);
		
	    return responseData;
	}

	/**
	 * [DM] 사용자 - 지갑생성 완료 저장.
	 * <pre>
	 * [DM] 사용자 - 지갑생성 완료 저장
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-07-11 14:39:07
	 */
	@BizMethod("[DM] 사용자 - 지갑생성 완료 저장")
	public IDataSet u008(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
		int row = dbUpdate("U008", requestData, onlineCtx);

		responseData.put("EXPECTED_ROW", row);
	
	    return responseData;	}

	/**
	 * [DM]사용자 비번 가져오기.
	 * <pre>
	 * [DM]사용자 비번 가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-26 09:13:30
	 */
	@BizMethod("[DM]사용자 비번 가져오기")
	public IDataSet s009(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    // Auto-generated execute db block
	    IRecordSet recordset = dbSelect("S009", requestData, onlineCtx);
	    
	    // Auto-generated make response block
	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	    
	    // 처리 결과값을 responseData에 넣어서 리턴하십시요 
	
	    return responseData;
	}
  
}