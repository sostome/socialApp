package com.skcc.bcsvc.co.biz;

import java.util.Map;
import java.security.SecureRandom;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.component.streotype.BizUnitBind;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.UserMessage;
import nexcore.framework.core.exception.BizRuntimeException;
import nexcore.framework.core.util.BaseUtils;
import nexcore.framework.core.util.CryptoUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;

/**
 * [PU]회원.
 * <pre>
 * [PU]회원
 * </pre>
 * 
 * @author kimjh (김준호)
 * @since 2018-06-18 16:26:15
 */
@BizUnit("[PU]회원")
public class PUSER extends nexcore.framework.biz.online.ProcessUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */
	
	@BizUnitBind
	private DUSER_01 dUSER_01;
	
	@BizUnitBind
	private FBASE fBase;
	
	@BizUnitBind
	private FBC fBC;
	
	/**
	 * Default Constructor
	 */
	public PUSER(){
		super();
	}

	// generate Password	
    private static SecureRandom random = new SecureRandom();
    private static final String ALPHA_CAPS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String ALPHA = "abcdefghijklmnopqrstuvwxyz";
    private static final String NUMERIC = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$%^&*_=+-/";
    
    // constants for generate password
    private static final int GEN_PWD_LEN = 6;
    private static final String GEN_PWD_METHOD = ALPHA + NUMERIC;

    /**
     * Method will generate random string based on the parameters
     * 
     * @param len : the length of the random string
     * @param dic : the dictionary used to generate the password
     * @return the random password
     */
    public static String generatePassword(int len, String dic) {
    	String result = "";
    	for (int i = 0; i < len; i++) {
    		int index = random.nextInt(dic.length());
    		result += dic.charAt(index);
    	}
    	return result;
    }

	
	/**
	 * [PM]회원가입.
	 * <pre>
	 * [PM]회원가입
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimjh (김준호)
	 * @since 2018-06-18 16:28:11
	 */
	@BizMethod("[PM]회원가입")
	public IDataSet pSignup(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    
	    String result = null;
	    // 처리 결과값을 responseData에 넣어서 리턴하십시요 
	    Integer DupCount = dUSER_01.s005(requestData, onlineCtx).getInt("COUNT");
	    
	    if(DupCount > 0)
	    	result = "dup";
	    else {
	    	
	    	String userID = requestData.getString("USER_ID");
	    	String address = requestData.getString("USER_WAT_ADDR");
	    	String email = requestData.getString("EMAIL_ID");
	    	String name = requestData.getString("USER_LNM")+requestData.getString("USER_NM");
	    	String pwd = requestData.getString("PWD");

	    	// encrypt password 
	    	String encPwd = CryptoUtils.encode("AES", pwd);	    	
	    	requestData.put("PWD", encPwd);
	    	
	    	dUSER_01.i001(requestData, onlineCtx);
	    

	    	IDataSet reqData = new DataSet();
	    	reqData.put("address", address);
	    	reqData.put("email", email);
	    	reqData.put("name", name);
	    	
	    	IDataSet resultEnrollment = fBC.fBCEnrollment(reqData, onlineCtx);
        	System.out.println(resultEnrollment.getString("success"));
        	
        	if(resultEnrollment.get("success").equals(true)) {
    	    	dUSER_01.u008(requestData, onlineCtx);
    		    result = "success";
        	} else {
    	    	result = "fail : "+resultEnrollment.getString("message");
        	}
	    	
	    }
	    
	    responseData.put("result", result);
	    
	    return responseData;
	}

	/**
	 * [PM] 아이디 찾기.
	 * <pre>
	 * [PM] 아이디 찾기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * <pre>
	 *	- field : USER_NAME [USER_NAME]
	 *	- field : MOB_PHN_NO [MOB_PHN_NO]
	 * </pre>
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * <pre>
	 *	- field : USER_ID [USER_ID]
	 * </pre>
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-22 13:26:58
	 */
	@BizMethod("[PM] 아이디 찾기")
	public IDataSet pFindID(IDataSet requestData, IOnlineContext onlineCtx) {
		
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);

        try {
            // Find ID with Name, Mobile
        	IDataSet result = dUSER_01.s002(requestData, onlineCtx);

        	String userID = result.getString("USER_ID");
        	responseData.put("USER_ID", userID );
        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
            throw be;            
        } catch(Exception e) {            
            throw new BizRuntimeException("BCSVC-E000");
        }
	
	    return responseData;	    
	}

	/**
	 * [PM] 비밀번호 찾기.
	 * <pre>
	 * [PM] 비밀번호 찾기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-22 17:08:09
	 */
	@BizMethod("[PM] 비밀번호 찾기")
	public IDataSet pFindPWD(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	
	    try {
	    	// Find ID with ID, Name, Mobile
	    	IDataSet result = dUSER_01.s003(requestData, onlineCtx);

	    	String userID = result.getString("USER_ID");
	        String userName = requestData.getString("USER_NAME");
	        String userMobileNo = requestData.getString("MOB_PHN_NO");
            String newPassword = null;

        	// checks not found
        	if(StringUtils.isEmpty(userID)) {
                onlineCtx.setUserMessage(UserMessage.FAIL, "BCSVC-I000", null);
        		
        	} else {
        		
        		// generate password : 6 digits(alpha, numeric) 
        		newPassword = generatePassword(GEN_PWD_LEN, GEN_PWD_METHOD);
	    		String encPassword = CryptoUtils.encode("AES", newPassword);
        	    
        	    IDataSet reqData = new DataSet();
        	    reqData.put("USER_ID", userID);
//        	    reqData.put("PWD", newPassword);  // test
        	    reqData.put("PWD", encPassword);  // actual

    	    	IDataSet result2 = dUSER_01.u001(reqData, onlineCtx);
    	    	int row = result2.getInt("EXPECTED_ROW");
    	    	
    	    	// for fail test
//    	    	row=0;
    	    	if(row>0) {
    		    	// reset device unlock
            	    IDataSet reqData2 = new DataSet();
            	    reqData2.put("USER_ID", userID);
        	    	IDataSet result3 = dUSER_01.u005(reqData2, onlineCtx);
    	    		
    	    		// TODO: inserts call SMS send
//    	    		sendSMS(userName, userMobileNo);
    		    	responseData.put("NEW_PWD_ENC", encPassword ); // for dev
    		    	responseData.put("RESULT", "OK" );
    		    	
    	    		
    	    	} else {
    	    		// fails save
            		newPassword = null;
    		    	responseData.put("RESULT", "FAIL" );
    	    	}
    	    	
                onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        	}
        	
        	// TODO: for DEV.(checks at client) 
	    	responseData.put("NEW_PWD", newPassword ); // for dev
      
	    } catch(BizRuntimeException be) {
	    	throw be;            
	    } catch(Exception e) {            
	    	throw new BizRuntimeException("BCSVC-E000");
	    }
	    
	    return responseData;
	}

	/**
	 * [PM]비밀번호 변경.
	 * <pre>
	 * [PM]비밀번호 변경
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-06-25 11:01:38
	 */
	@BizMethod("[PM]비밀번호 변경")
	public IDataSet pPwdChange(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
        Map<String, Object> param = requestData.toMap();
	
	    try {
	    	// Find ID with ID, Name, Mobile
	    	String id = (String)param.get("USER_ID");
            String pw = (String)param.get("USER_PW");
            String pwd = CryptoUtils.encode("AES", pw);	
        	
        	if(StringUtils.isEmpty(id)) {
                onlineCtx.setUserMessage(UserMessage.FAIL, "BCSVC-I000", null);
        		
        	} else {
        		
        	    
        	    IDataSet reqData = new DataSet();
        	    reqData.put("USER_ID", id);
        	    reqData.put("USER_PW", pwd);  // test
                //reqData.put("PWD", encPassword);  // actual

    	    	IDataSet result = dUSER_01.u002(reqData, onlineCtx);
    	    	int row = result.getInt("EXPECTED_ROW");
    	    	
    	    	if(row>0) {
    	    		//디바이스 잠금 해제
    	    		dUSER_01.u005(reqData, onlineCtx);
    	    		//임시비밀번호 여부 해제
    	    		dUSER_01.u006(reqData, onlineCtx);
    	    	} 
    	    	
                onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        	}
        	
      
	    } catch(BizRuntimeException be) {
	    	throw be;            
	    } catch(Exception e) {            
	    	throw new BizRuntimeException("BCSVC-E000");
	    }
	    
	    return responseData;
	}


	/**
	 * [PM] 중복확인 - 아이디.
	 * <pre>
	 * [PM] 중복확인 - 아이디
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-25 13:58:48
	 */
	@BizMethod("[PM] 중복확인 - 아이디")
	public IDataSet pCheckDupID(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);

        try {
        	responseData.put("COUNT", dUSER_01.s005(requestData, onlineCtx).getInt("COUNT") );
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
            throw be;            
        } catch(Exception e) {            
            throw new BizRuntimeException("BCSVC-E000");
        }
        
	    return responseData;	
	}


	/**
	 * [PM] 중복확인 - 모바일.
	 * <pre>
	 * [PM] 중복확인 - 모바일
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-25 14:54:43
	 */
	@BizMethod("[PM] 중복확인 - 모바일")
	public IDataSet pCheckDupMobile(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);

        try {
        	responseData.put("COUNT", dUSER_01.s006(requestData, onlineCtx).getInt("COUNT") );
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
            throw be;            
        } catch(Exception e) {            
            throw new BizRuntimeException("BCSVC-E000");
        }
        
	    return responseData;	
	}


	/**
	 * [PM] 중복확인 - 이메일.
	 * <pre>
	 * [PM] 중복확인 - 이메일
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-25 14:58:26
	 */
	@BizMethod("[PM] 중복확인 - 이메일")
	public IDataSet pCheckDupEmail(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);

        try {
        	responseData.put("COUNT", dUSER_01.s007(requestData, onlineCtx).getInt("COUNT") );
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
            throw be;   
        } catch(Exception e) { 
            throw new BizRuntimeException("BCSVC-E000");
        }
        
	    return responseData;
	}


	/**
	 * [PM] 디바이스 잠금 확인.
	 * <pre>
	 * [PM] 디바이스 잠금 확인
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author kimig (김인경)
	 * @since 2018-06-26 13:35:33
	 */
	@BizMethod("[PM] 디바이스 잠금 확인")
	public IDataSet pCheckDeviceLock(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);

        try {
        	responseData.put("APP_LOCK_YN", dUSER_01.s008(requestData, onlineCtx).getString("APP_LOCK_YN") );
        	
        	responseData.put("BOBSVR_WAT_1", BaseUtils.getBootupConfiguration("blockchain.bob.server1.address").toString() );
        	responseData.put("BOBSVR_WAT_2", BaseUtils.getBootupConfiguration("blockchain.bob.server2.address").toString() );
        	responseData.put("BOBSVR_WAT_3", BaseUtils.getBootupConfiguration("blockchain.bob.server3.address").toString() );
        	
	    	IDataSet reqData = new DataSet();
	    	reqData.put("currency", "SKW");
	    	
	    	IDataSet result = fBC.fTGGetCurrency(reqData, onlineCtx);
           	responseData.put("SKW_ISSUER_ADDRESS", result.getString("issuer_address"));
        	
        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
            throw be;            
        } catch(Exception e) {            
            throw new BizRuntimeException("BCSVC-E000");
        }
        
	    return responseData;
        
	}


	/**
	 * [PM]사용자 원 암호 가져오기.
	 * <pre>
	 * [PM]사용자 원 암호 가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-26 09:12:19
	 */
	@BizMethod("[PM]사용자 원 암호 가져오기")
	public IDataSet pGetUserPwdOriginal(IDataSet requestData, IOnlineContext onlineCtx) {
	    IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	
	    IRecordSet rs = dUSER_01.s009(requestData, onlineCtx).getRecordSet("rs");
	    
	    String originPwds = "";
	    
	    // 처리 결과값을 responseData에 넣어서 리턴하십시요 
	    
	    int len = rs.getRecordCount();
	    
	    for(int i=0;i<len;i++){
	    	IRecord record = rs.getRecord(i);
	    	String pwd = record.getString("PWD");
	    	String originPwd = CryptoUtils.decode("AES", pwd);
	    	originPwds += originPwd+",";
	    }
	    
	    responseData.put("originPwds", originPwds);
	
	    return responseData;
	}

}
