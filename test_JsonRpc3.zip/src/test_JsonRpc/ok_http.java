package test_JsonRpc;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ok_http {

	public static void main(String[] args) {
		
		OkHttpClient client = new OkHttpClient();

		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType, "{ \"method\" : \"guru.test\", \"params\" : [ \"Guru\" ] }");
		Request request = new Request.Builder()
		  .url("https://gurujsonrpc.appspot.com/guru")
		  .post(body)
		  .addHeader("content-type", "application/json")
		  .addHeader("cache-control", "no-cache")
		  .addHeader("token", "e0bd09e2-34c9-b211-0b3c-d80b4205514a")
		  .build();

		try {
			
			Response response = client.newCall(request).execute();
			System.out.println(response.message());
			System.out.println(response.code());
			Headers headers = response.headers();
			
			Set<String> keys = headers.toMultimap().keySet();
			Iterator iter = keys.iterator();
			while(iter.hasNext()){
				String key = (String)iter.next();
				System.out.println("key:"+key);
				List<String> value = headers.toMultimap().get(key);
				Iterator iter1 = value.iterator();
				while(iter.hasNext()){
					
					System.out.println("value:");
					System.out.println(iter.next());
				}
				
			}
			
			System.out.println(response.isSuccessful());
			
			
			InputStream is = response.body().byteStream();
			
			int readLength = 0;
	   		   byte[] input = new byte[1024];
	   		   StringBuffer sb = new StringBuffer();
	   		
	   		   while ((readLength = is.read(input, 0, input.length)) != -1) {
	   		      sb.append(  new String( input )  );
	   		  }
	   		
	   		   System.out.println(sb.toString());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
