import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.Gson;
import com.skplanet.jose.Jose;
import com.skplanet.jose.JoseBuilders;
import com.skplanet.jose.JoseHeader;
import com.skplanet.jose.jwa.Jwa;
import com.skplanet.syruppay.token.SyrupPayTokenBuilder;
import com.skplanet.syruppay.token.claims.PayConfigurer;

public class test11pay {

	public static void main(String[] args) {
		try {
			String token = new SyrupPayTokenBuilder().of("11Pay에서 발급/전달한 가맹점 ID")
					  .login()
					    .withMerchantUserId("가맹점의 회원 ID 또는 식별자")
					    .withSsoCredential("발급 받은 SSO")
					  .and()
					  .pay()
					    .withOrderIdOfMerchant("가맹점에서 관리하는 주문 ID")
					    .withProductTitle("제품명 예. Macbook 27 인치 노트북 외 1건")
					    .withProductUrls(
					        "http://deal.11st.co.kr/product/prdNo=1122841340",
					        "http://deal.11st.co.kr/product/prdNo=1265508741"
					        ) // Optional
					    .withLanguageForDisplay(PayConfigurer.Language.KO)  // 한글
					    .withAmount(50000) // 결제요청 금액
					    .withCurrency(PayConfigurer.Currency.KRW)  // 원화
					    .withShippingAddress(
					        new PayConfigurer.ShippingAddress("137-332",
					           "서초구 잠원동 하나아파트", "1동 1호", "서울", "", "kr")
					        ) // 배송지 Optional
					    .withDeliveryPhoneNumber("01012345678") // 수신자 전화번호 Optional
					    .withDeliveryName("배송 수신자") // 수신자 이름 Optional
					    .withInstallmentPerCardInformation(
					        new PayConfigurer.CardInstallmentInformation("카드구분 코드",
					            "할부정보. ex. NN1;NN2;YY3;YY4;YY5;NH6")
					        ) // Optional. 특정 카드만 허용 가능하게 설정할 수 있음
					    .withBeAbleToExchangeToCash(false) // 환금성 상품 여부 Optional
					    .withRestrictionPaymentTypeOf("MOBILE;BANK;CARD") // Optional, 결제수단 제약                                      
					  .and()
					  .generateTokenBy("11Pay에서 발급/전달한 가맹점 Secret");
			
			System.out.println(token);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void validateToken(){
		
		String kid = "11Pay가 발급/전달한 가맹점 ID";
		String key = "11Pay가 발급/전달한 가맹점 Secret";

		// 검증 후, 원 (JSON) 데이터를 Return합니다.
		String jsonData = new Jose().configuration(
		        JoseBuilders.compactDeserializationBuilder()
		            .serializedSource("11Pay가 생성/전달한 JWT 형태의 값")
		            .key(key)
		).deserialization();
		
		Gson gson = new Gson();
		System.out.println(jsonData);
		System.out.println(gson.fromJson(jsonData, Object.class));
	
	}
	
	public static void requestTransApproval(){
		// URL 설정합니다.
		//사용 https://api-pay.syrup.co.kr
		URL url;
		try {
			url = new URL("https://api-devqapay.syrup.co.kr/v1/api-basic/payment/approval");
			// API 키를 설정합니다.
			String apiKey = "SyrupPay_API_Key"; //11Pay가 전달한 API Key 값을 세팅합니다.
			 
			// HTTP Connection 설정합니다.
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");  // HTTP POST 방식입니다.
			connection.setDoOutput(true);

			// 11Pay 인증 방식에 대한 HTTP Header 설정합니다.
			connection.setRequestProperty("Authorization", "Basic " + apiKey);   

			// HTTP Accept Header 설정합니다.
			connection.setRequestProperty("Accept", "application/jose;charset=utf-8");

			// HTTP Content-Type Header 설정합니다.
			connection.setRequestProperty("Content-type", "application/jose;charset=utf-8");  
			 
			// HTTP 요청정보를 구성합니다. 11Pay가 제공하는 REST API의 Request JSON String을 설정합니다.
			// 아래는 자격증명 발행을 위한 JSON 구성을 기준으로 작성 되었습니다.
			// NOTE: 실제 사용 시 두개의 연속된 백슬래쉬는 하나의 백슬래쉬로 대체해서 사용해야 합니다.
			String requestBody = "{\n" +
					               "\"mctRequestId\": \"dd8b3728465b47838114f45590f736f0\",\n"+ //가맹점 거래 승인요청 ID (최대 40 Byte)
					                //(주) 해당 ID는 가맹점에서 요청 시마다 Unique한 값을 전달해야 합니다.
				                   "\"mctRequestTime\": \"1457338413\",\n"+//가맹점 거래승인 요청시간
				                   //UTC Unix Timestamp (단위: 초) (10 Digit)
				                   //long epoch = System.currentTimeMillis()/1000;
				                   //String date = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new java.util.Date (epoch*1000));
				                   //long epoch = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse("01/01/1970 01:00:00").getTime() / 1000;
				                   "\"mctTransAuthId\": \"61c39585-770d-43fb-af13-34753ceb21dc\",\n"+
				                   //가맹점 거래인증 ID
				                   //가맹점에서 거래 인증요청 토큰(Token) 발행 시, 생성한 ID (최대 40 Byte)
				                   "\"mctPaymentCode\": \"null\",\n"+
				                   //가맹점-카드사 간 계약에 의해, 카드사 또는 VAN에서 발급되는 가맹점 구분자에 대한 11Pay 매핑 값 (최대 32 Byte)
				                   //일반적인 경우 불필요하나 가맹점 요청에 의해 사용 가능합니다. 단, 11Pay와 사전 협의 필요합니다.
				                   "\"paymentAmt\": \"237000\",\n"+
				                   //거래승인 요청 금액 (세금 포함)
				                   //거래인증 시 요청한 거래요청 금액과 반드시 일치해야 합니다. 
				                   //(주 1) 가맹점에선 11Pay에서 암호화 후 전달한 거래인증 결과값을 확인함으로써 악의적 사용자에 의한 결제금액 위/변조 여부를 확인할 수 있습니다.
				                   //(주 2) 카드 거래인 경우 최소 10원 이상 금액을 요청해야 합니다.
				                   "\"taxFreeAmt\": \"0\",\n"+
				                   //비과세 상품 금액
				                   //가맹점이 비과세가 허용되는 영세사업자이거나 결제 상품에 면세 상품이 포함되어 있는 경우, 
				                   //반드시 비과세 상품에 대한 금액을 전달해야 합니다. 비과세 상품 금액이 없는 경우는 0으로 전달합니다.
				                   "\"ocTransAuthId\": \"TA20160307000000000027536\",\n"+
				                   //11Pay 거래인증 ID
				                   //11Pay가 거래인증 결과 값으로 전달한 ID (최대 40 Byte)
				                   "\"tranAuthValue\": \"3bC3x6CcUWUp3zPl3hOdOMloB3tyB6sFQOG5eZ2_cfU\",\n"+
				                   //11Pay 거래인증 값
				                   //11Pay가 거래인증 결과 값으로 전달한 값 (최대 128 Byte)
				                   "\"submallInfo\": \"null\"\n"+
				                   //Optional 가맹점에서 관리하는 하위 가맹점 정보
				                   //가맹점에서 판매하는 상품이 가맹점 하위의 별도 사업자라면 필수로 전달해야 합니다.

			                  
			                   "}";

			JoseHeader h = new JoseHeader(Jwa.A128KW, Jwa.A128CBC_HS256, "11Pay가 전달한 가맹점 ID");
			 
			// HTTP 요청정보를 암호화 처리합니다.
			String request = new Jose().configuration(
			        JoseBuilders.JsonEncryptionCompactSerializationBuilder()
			          .header(h)
			          .payload(requestBody)
			            .key("가맹점 SECRET") //11Pay가 전달한 가맹점 Secret입니다.
			).serialization();
			 
			// 11Pay로 HTTP 요청을 수행합니다.
			OutputStream out;
			try {
				out = connection.getOutputStream();
				out.write(request.getBytes());
				out.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			 
			// 11Pay에서 전달하는 HTTP 응답을 처리힙니다.
			try {
			  int status = connection.getResponseCode();
			  InputStream content;
			  if (status == 200) {  // HTTP 응답 성공인 경우
			      content = connection.getInputStream(); 
			  } else {   // HTTP 응답 실패인 경우
			      content = connection.getErrorStream();
			  }
			  BufferedReader in = new BufferedReader(new InputStreamReader(content));
			  String line;
			  StringBuilder buf = new StringBuilder();
			  while ((line = in.readLine()) != null) {
			      buf.append(line);
			  }

			  // 11Pay가 전달한 응답에 대한 복호화 처리합니다.
			  String response = new Jose().configuration(
			        JoseBuilders.compactDeserializationBuilder()
			        .serializedSource(buf.toString())
			        .key("가맹점 SECRET") // 11Pay가 전달한 가맹점 Secret입니다.
			  ).deserialization();
			  
			  //성공시
			  /*
			  {
				    "ocTransApproveNo": "201706050309731", // 결제사(카드, 계좌, 폰빌)에 따라 결과값 구성이 달라질 수 있습니다.
				    "ocTransApproveTime": 1457338413,
				    "mctRequestId": "dd8b3728465b47838114f45590f736f0",
				    "mctTransAuthId": "61c39585-770d-43fb-af13-34753ceb21dc",
				    "ocTransAuthId": "TA20160307000000000027536",
				    "mctDefinedValue": "test",
				    "paymentInfo": {
				        "productTitle": "[삼성전자]S27E500 27인치 커브드 모니터",
				        "currencyCode": "KRW",
				        "productAmt": 237000,
				        "paymentAmt": 237000,
				        "discountAmt": 0,
				        "paymentMethod": "CARD"
				    },
				    "discountInfoList": null,
				    "cardApprovalInfo": {
				        "cardNumber": "411905********30",
				        "cardName": "하나카드",
				        "cardType": "CC",
				        "cardApprovalNo": "07171333", // 카드사 승인번호 구성은 카드사에 따라 달라질 수 있습니다.
				        "cardApprovalTime": "20160307171333",
				        "isCardPointApplied": false,
				        "payInstallment": 6,
				        "payInstallmentOption": "INTEREST"
				    },
				    "bankApprovalInfo": null,
				    "phoneApprovalInfo": null,
				    "syrupPayError": null,
				    "except": false
				}
				*/
			  //실패시

			  /*
			   {
	             "ocTransApproveNo": null,
	             "ocTransApproveTime": 0,
	             "mctRequestId": null,
	             "mctTransAuthId": null,
	             "ocTransAuthId": null,
	             "paymentInfo": null,
	             "discountInfoList": null,
	             "cardApprovalInfo": null,
	             "bankApprovalInfo": null,
	             "phoneApprovalInfo": null,
	             "syrupPayError": {
	                "httpStatus": "BAD_REQUEST",
	                "code": "INVALID_REQUEST",
	                "message": "ocTransAuthId is not valid",
	                "errors": []
	             },
	             "except": true
	           }

			   
			   */
			  
			  

			  System.out.println(response);  // 응답을 확인합니다.
			  // 필요할 경우, 응답에 대한 가맹점 후 처리(Post Processing)를 수행합니다.
			  Gson gson = new Gson();
		      System.out.println(gson.fromJson(response, Object.class));

			  in.close();
			} catch (FileNotFoundException fe) {
			  System.out.println("File Not Found");
			} catch (IOException e) {
			  e.printStackTrace();
			}

		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		 
		
	}
	}


