import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class test_token {

	public static void main(String[] args) {
		try {
			// url
			URL url = new URL("https://skcoin.skcc.com/auth/realms/skcoinlab_auth/protocol/openid-connect/token");

	        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

	        httpURLConnection.setRequestMethod("POST");
	        httpURLConnection.setDoOutput(true);
	        httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	        httpURLConnection.setRequestProperty("Authorization", "Basic Ym9ic2VydmVyOjFlN2VkOTAyLTY2ZWMtNDJlZS1iYjk0LTJjYmZjMWVkNTYxMw==");
	        httpURLConnection.setConnectTimeout(5000);
	        httpURLConnection.setReadTimeout(5000);
	        httpURLConnection.setInstanceFollowRedirects(true);
	        
            // params

            StringBuffer stringBuffer = new StringBuffer();

            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(httpURLConnection.getOutputStream());
            //outputStreamWriter.write(requestData.get("params").toString());
            outputStreamWriter.write("grant_type=client_credentials");
            outputStreamWriter.flush();
           
            if (httpURLConnection.getResponseCode() == 200) {
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader( httpURLConnection.getInputStream(), "EUC-KR" ), httpURLConnection.getContentLength() );

                String inputLine;
                
                while ((inputLine = bufferedReader.readLine()) != null) {
                	stringBuffer.append(inputLine);
                }
                
                bufferedReader.close();            	
            }
            
            httpURLConnection.disconnect();
            
            System.out.println(stringBuffer.toString());
            
            //responseData.put("result", stringBuffer);
            
		} catch (MalformedURLException e) {
			e.printStackTrace();
            //log.error("<오류> <MalformedURLException> " + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
            //log.error("<오류> <IOException> " + e.getMessage());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
            //log.error("<오류> <IllegalArgumentException> " + e.getMessage());
		}         
	
	    //return responseData;

	}

}
