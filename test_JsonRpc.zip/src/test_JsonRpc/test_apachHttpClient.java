package test_JsonRpc;

import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

public class test_apachHttpClient {

	public static void main(String[] args) {
		HttpClient httpClient = HttpClientBuilder.create().build(); //Use this instead 

		try {

		    HttpPost request = new HttpPost("https://gurujsonrpc.appspot.com/guru");
		    StringEntity params =new StringEntity("{ \"method\" : \"guru.test\", \"params\" : [ \"Guru\" ] }");
		    request.addHeader("content-type", "application/json");
		    request.setEntity(params);
		    HttpResponse response = httpClient.execute(request);
		    
		    HttpEntity en = response.getEntity();
		    InputStream is = en.getContent();
		    
		    int readLength = 0;
	   		   byte[] input = new byte[1024];
	   		   StringBuffer sb = new StringBuffer();
	   		
	   		   while ((readLength = is.read(input, 0, input.length)) != -1) {
	   		      sb.append(  new String( input )  );
	   		  }
	   		
	   		   System.out.println(sb.toString());

		    //handle response here...

		}catch (Exception ex) {
			
			ex.printStackTrace();

		    //handle exception here

		} finally {
		    //Deprecated
		    //httpClient.getConnectionManager().shutdown(); 
		}

	}

}
