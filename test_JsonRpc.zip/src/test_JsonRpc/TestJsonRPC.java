package test_JsonRpc;

import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.googlecode.jsonrpc4j.JsonRpcHttpClient;


class Result {
	
	public String account;
	public Double ledger_current_index;
	public HashMap<String, Object>[] lines;
	public String status;
	public boolean validated;
	public String error;
	public String error_code;
	public String error_message;
	public HashMap<String, Object> request;	
		 
}

public class TestJsonRPC {

	public static void main(String[] args) {
		
		try {
		    Map<String, String> headers = new HashMap<>();
		    //String sendTxt = "{ \"method\" : \"account_lines\", \"params\" : [ {\"account\":\"r9cZA1mLK5R5Am25ArfXFmqgNwjZgnfk59\"} ] }";
		    
		    //headers.put("Authorization", "Basic <encoded-credentials>");
		    headers.put("Content-type", "application/json");		   
		    
		    JsonRpcHttpClient client = new JsonRpcHttpClient(
		            new URL("http://s1.ripple.com:51234/"), headers);
		    
		    JsonRpcHttpClient client1 = new JsonRpcHttpClient(
		            new URL("https://gurujsonrpc.appspot.com/guru"), headers);		       
		   
		    JsonRpcHttpClient client2 = new JsonRpcHttpClient(
		            new URL("http://io1.skcc.com:5005"), headers);	
		    
		    Gson gson = new Gson();
		    		
			Object[] objArr = new Object[1];
		    Map paramMap = new HashMap();
		    paramMap.put("account", "r9cZA1mLK5R5Am25ArfXFmqgNwjZgnfk59");
		    objArr[0] = paramMap;
		    
		    Object[] objArr2 = new Object[1];
		    objArr2[0] = "World";
		    
		    Object[] objArr3 = new Object[1];
		    Map paramMap3 = new HashMap();
		    paramMap3.put("account", "r9cZA1mLK5R5Am25ArfXFmqgNwjZgnfk59");
		    objArr3[0] = paramMap3;
		    
		    
		   
		    //Result resultObj = client.invoke("account_lines",objArr, Result.class);
		    
		    //Result resultObj = client1.invoke("guru.test",objArr2, Result.class);
		    
		    Result resultObj = client2.invoke("account_lines",objArr3, Result.class);
		    if(resultObj.lines != null){
		    	
		    	for(int i=0;i<resultObj.lines.length;i++){
			    	Map res = resultObj.lines[i];
			    	Set keys = res.keySet();
			    	Iterator iter = keys.iterator();
			    	while(iter.hasNext()){
			    		String key = (String)iter.next();
			    		System.out.println("key: "+ key);
			    		Object val = res.get(key);
			    		System.out.println("value: ");
			    		System.out.println(val.toString());
			    	}
			    }
		    	
		    }
		    
		      
		   
		    
		} catch (Throwable throwable) {
		    throwable.printStackTrace();
		}

	}

}
