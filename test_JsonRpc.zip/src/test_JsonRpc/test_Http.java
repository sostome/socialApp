package test_JsonRpc;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;

import com.google.gson.Gson;

public class test_Http {
	
	public static void main(String[] args) {
		test_Http.Post_JSON();
	}
	public static void Post_JSON() {
		
           String query_url = "https://gurujsonrpc.appspot.com/guru";
           String json = "{\"method\" : \"guru.test\", \"params\" : [ \"jinu awad\" ], \"id\" : 123 }";
           try {
           URL url = new URL(query_url);
           HttpURLConnection conn = (HttpURLConnection) url.openConnection();
           conn.setConnectTimeout(5000);
           conn.setRequestProperty("Content-Type", "application/json");
           conn.setDoOutput(true);
           conn.setDoInput(true);
           conn.setRequestMethod("POST");
           //conn.setRequestProperty("Content-Length", String.valueOf(json.getBytes("UTF-8")));
           //conn.setRequestProperty("Connection", "close");
           /*
           String userCredentials = "username:password";
           String basicAuth = "Basic " + new String(new Base64().encode(userCredentials.getBytes()));
           myURLConnection.setRequestProperty ("Authorization", basicAuth);
           */
           //headers.put("Content-type", "application/json");
		    //headers.put("Connection", "close");
		    //headers.put("Content-length", String.valueOf(sendTxt.length()));
           
           Gson gson = new Gson();
           OutputStream os = conn.getOutputStream();
           os.write(json.getBytes("UTF-8"));
           os.close(); 
           
           // read the response
           InputStream in = new BufferedInputStream(conn.getInputStream());
           
           int readLength = 0;
   		   byte[] input = new byte[1024];
   		   StringBuffer sb = new StringBuffer();
   		
   		   while ((readLength = in.read(input, 0, input.length)) != -1) {
   		      sb.append(  new String( input )  );
   		  }
   		
   		   System.out.println(sb.toString());
           
           /*
           String result = IOUtils.toString(in, "UTF-8");
           
           System.out.println(result);
           System.out.println("result after Reading JSON Response");
           JSONObject myResponse = new JSONObject(result);
           System.out.println("jsonrpc- "+myResponse.getString("jsonrpc"));
           System.out.println("id- "+myResponse.getInt("id"));
           System.out.println("result- "+myResponse.getString("result"));
           */
           in.close();
           conn.disconnect();
           
           
           } catch (Exception e) {
   			System.out.println(e);
   		}
	}

}
