## 함수 선언 부분 ##
def myFunc(v1, v2) :
    hap = v1 + v2
    return

## 변수 선언 부분 ##
hap = 0 # 전역 변수
num1 = 100
num2 = 200

## 메인 코드 부분 ##
myFunc(num1, num2)
print(num1, '+', num2, '=', hap)