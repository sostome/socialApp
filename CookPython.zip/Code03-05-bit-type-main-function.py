print(int('10010011',2))
print(0x93)
print(int('93', 16))
print(bin(11));print(bin(0o11));print(bin(0x11))
print(oct(11));print(oct(0b11));print(oct(0x11))
print(hex(11));print(hex(0b11));print(hex(0o11))

sel=int(input("입력 진수 결정(16/10/8/2) : "))
num=input("값 입력 : ")

if sel == 16 :
    num10 = int(num, 16)
if sel == 10 :
    num10 = int(num, 10)
if sel == 8 :
    num10 = int(num, 8)
if sel == 2 :
    num10 = int(num, 2)

print("16진수 ==> ", hex(num10))
print("10진수 ==> ", num10)
print("8진수 ==> ", oct(num10))
print("2진수 ==> ", bin(num10))

a = 123
print(type(a))
a = 100**100
print(a)
a=0xFF
b=0o77
c=0b1111
print(a,b,c)

a=3.14
b=3.14e5
print(a,b)
a,b=9,2
print(a**b, a%b, a//b)
a= True
print(type(a))
a=(100 == 100)
b=(10>100)
print(a,b)
a = "작은 따음표 ' 모양이다."
b = '큰 따음표 " 모양이다.'
print(a, b)
print(type(a))
a="""파이썬
만세"""
a
print(a)

## 함수 선언 부분 ##
def myFunc() :
    print('함수를 호출함.')
    
## 전역 변수 선언 부분 ##
gVar = 100

## 메인 함수 정의 ##
def main() :
    print('메인 함수 부분이 실행됩니다.')
    myFunc()
    print('전역 변수 값:', gVar)
    
## 메인 부분 ##
if __name__ == '__main__' :
    main()


