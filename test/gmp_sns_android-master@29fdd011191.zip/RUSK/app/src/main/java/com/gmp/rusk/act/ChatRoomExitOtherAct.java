package com.gmp.rusk.act;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.layout.ChatRoomUserListItemLayout;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * ChatRoomExitOtherAct
 * 
 * @author kch 강퇴 Activity
 */
public class ChatRoomExitOtherAct extends CustomActivity{

	ArrayList<UserListData> m_arrUserListDatas = null;
	ArrayList<Boolean> m_arrIsCheck;
	UserListAdapter m_UserListAdapter;
	ArrayList<Integer> m_arrUserNo;
	ImageView m_btnComplete;
	private ListView m_lvUserList = null;
	int m_nOwnerNo;

	UserListData m_UserListData;
	ArrayList<Integer> m_arrExitUser;
	CommonPopup m_Popup;

	TextView m_tvSectionName;
	TextView m_tvTitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatroom_menu_exit_other);

		m_arrIsCheck = new ArrayList<Boolean>();
		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_arrUserNo = bundle.getIntegerArrayList(IntentKeyString.INTENT_KEY_ARR_USERNO);
			m_nOwnerNo = bundle.getInt(IntentKeyString.INTENT_KEY_OWNERNO);
		}

		m_arrUserListDatas = new ArrayList<UserListData>();

		for(int nUserNo : m_arrUserNo){
			m_UserListData = ContactsDBManager.getContacts(this, nUserNo);
			m_arrUserListDatas.add(m_UserListData);
			m_arrIsCheck.add(false);
		}
		Collections.sort(m_arrUserListDatas,myComparator);
		for(int i = 0; i < m_arrUserListDatas.size(); i++){
			if(m_arrUserListDatas.get(i).m_nUserNo == App.m_MyUserInfo.m_nUserNo){
				UserListData tempData = m_arrUserListDatas.get(i);
				m_arrUserListDatas.remove(m_arrUserListDatas.get(i));
				m_arrUserListDatas.add(0, tempData);
			}
		}
		for(int i = 0; i < m_arrUserListDatas.size(); i++){
			if(m_arrUserListDatas.get(i).m_nUserNo == m_nOwnerNo && m_arrUserListDatas.get(i).m_nUserNo != App.m_MyUserInfo.m_nUserNo){
				UserListData tempData = m_arrUserListDatas.get(i);
				m_arrUserListDatas.remove(m_arrUserListDatas.get(i));
				m_arrUserListDatas.add(1, tempData);
			}
		}


		m_arrExitUser = new ArrayList<Integer>();

		initUI();

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {

			Intent intent = new Intent();

			setResult(RESULT_CANCELED, intent);
			finish();
		}
		return super.onKeyDown(keyCode, event);

	}

	
	
	private void initUI() {

		m_lvUserList = (ListView) findViewById(R.id.lv_chat_member_list);
		m_tvSectionName = (TextView) findViewById(R.id.tv_section_name);
		m_tvTitle = (TextView) findViewById(R.id.tv_exitother_title);
		RelativeLayout layout_nolisttext;
		layout_nolisttext = (RelativeLayout) findViewById(R.id.layout_hinttext);
		if (m_arrUserListDatas != null) {
			layout_nolisttext.setVisibility(View.GONE);
			m_UserListAdapter = new UserListAdapter();
			m_lvUserList.setAdapter(m_UserListAdapter);
		}
		ImageView ivClose = (ImageView) findViewById(R.id.btn_top_close);
		ivClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		m_btnComplete = (ImageView) findViewById(R.id.btn_complete);
		m_btnComplete.setOnClickListener(null);
		m_tvSectionName.setText(getString(R.string.chat_member_section) + " " + m_arrUserNo.size());
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		switch (v.getId()) {
		case R.id.btn_complete:
			boolean isNoExit = true;
			for (int i = 0; i < m_arrIsCheck.size(); i++) {
				if (m_arrIsCheck.get(i)) {
					isNoExit = false;
				}
			}
			if (isNoExit) {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_exit_other_title), getString(R.string.popup_exit_other_no_select));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_exit_other_title), getString(R.string.popup_exit_other_text));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			break;
		case R.id.ib_pop_ok:
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			for (int i = 0; i < m_arrIsCheck.size(); i++) {
				if (m_arrIsCheck.get(i)) {
					m_arrExitUser.add(m_arrUserListDatas.get(i).m_nUserNo);
					CommonLog.e(this, "KickUser : " + m_arrUserListDatas.get(i).m_nUserNo);
				}
			}
			Intent intentFinish = new Intent();
			intentFinish.putExtra(IntentKeyString.INTENT_KEY_KICK_USERS, m_arrExitUser);
			setResult(RESULT_OK, intentFinish);

			finish();
			popup_ok.cancel();
			break;
		case R.id.ib_pop_cancel:
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			break;
		case R.id.ib_pop_ok_long:
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			break;
		default:
			break;
		}
	}

	public void setCheckBoxPosition(int nPosition, boolean isCheck) {
		m_arrIsCheck.set(nPosition, isCheck);
		boolean isNoCheck = true;
		int nCheckCount = 0;
		for(int i = 0; i < m_arrIsCheck.size(); i++){
			if(m_arrIsCheck.get(i)){
				isNoCheck = false;
				nCheckCount++;
			} 
		}
		if(isNoCheck){
			m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
			m_btnComplete.setOnClickListener(null);
		} else {
			m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);
			m_btnComplete.setOnClickListener(this);
		}
		if(nCheckCount > 0)
			m_tvTitle.setText(getString(R.string.chatroom_menu_kick) + " " + nCheckCount);
		else
			m_tvTitle.setText(getString(R.string.chatroom_menu_kick));

	}

	public boolean getCheckBoxPosition(int nPosition) {
		return m_arrIsCheck.get(nPosition);
	}

	private class UserListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nUserListDataSize = 0;

			if (m_arrUserListDatas != null)
				nUserListDataSize = m_arrUserListDatas.size();

			return nUserListDataSize;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_arrUserListDatas != null && position < m_arrUserListDatas.size())
				return m_arrUserListDatas.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			UserListData userData;

			if (nPosition < m_arrUserListDatas.size()) {
				userData = (UserListData) m_arrUserListDatas.get(nPosition);
				// convertView null 시 새로 생성하자
				if (convertView == null)
					convertView = new ChatRoomUserListItemLayout(ChatRoomExitOtherAct.this, ChatRoomUserListItemLayout.CHATROOM_ITEM_TYPE_EXIT);
				((ChatRoomUserListItemLayout) convertView).setOwner(m_nOwnerNo);
				((ChatRoomUserListItemLayout) convertView).setPosition(nPosition);
				((ChatRoomUserListItemLayout) convertView).setUserListData(userData);
			}

			return convertView;
		}
	}

	private final static Comparator<UserListData> myComparator = new Comparator<UserListData>() {
		private final Collator collator = Collator.getInstance(new Locale("ko"));

		@Override
		public int compare(UserListData lhs, UserListData rhs) {
			// TODO Auto-generated method stub
			boolean isLeftNumber = true;
			boolean isRightNumber = true;

			char leftChar = lhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME).charAt(0);
			char rightChar = rhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME).charAt(0);

			if(leftChar < '0' || leftChar > '9'){
				isLeftNumber = false;
			}
			if(rightChar < '0' || rightChar > '9'){
				isRightNumber = false;
			}

			if(isLeftNumber && !isRightNumber){
				return 1;
			} else if(!isLeftNumber && isRightNumber){
				return -1;
			} else
				return collator.compare(lhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME), rhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
		}

	};

	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
