package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;
import com.gmp.rusk.utils.CommonLog;

public class GetRegularRes extends Res{
			
	public GetRegularRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);

		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}
}
