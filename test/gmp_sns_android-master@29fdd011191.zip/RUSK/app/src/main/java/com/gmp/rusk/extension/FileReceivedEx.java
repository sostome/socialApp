package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class FileReceivedEx implements PacketExtension {
	//public static final String NAMESPACE = "urn:xmpp:groupchat:join";
	public static final String ELEMENT_NAME = "file-received";
	private String id;

	public FileReceivedEx() {
	}

	public FileReceivedEx(String id) {
		this.id = id;
	}

	//
	//
	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return ELEMENT_NAME;
	}

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return "";
	}


	public String getID() {
		return this.id;
	}

	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		StringBuilder buf = new StringBuilder();
		// 1.5.5 에서 규격 수정됨

		// buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
		return buf.toString();
	}

	public static class Provider implements PacketExtensionProvider {

		public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
			String id = null;
			boolean done = false;
			while (!done) {
				int eventType = parser.getEventType();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("id")) {
						if (parser.getAttributeCount() == 1) {
							id = parser.nextText();
						} else {
						
						}

					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals(ELEMENT_NAME)) {
						done = true;
					}
				}
				if (!done)
					parser.next();
			}
			return new FileReceivedEx(id);
		}
	}
}