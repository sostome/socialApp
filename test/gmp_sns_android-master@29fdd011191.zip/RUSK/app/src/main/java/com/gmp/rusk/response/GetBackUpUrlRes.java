package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class GetBackUpUrlRes extends Res{
	
	private final String JSON_RESULTURL 			= "resultUrl";

	
	private String m_strResultUrl = "";

	
	public GetBackUpUrlRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			m_strResultUrl = jsonRoot.getString(JSON_RESULTURL);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getResultUrl()
	{
		return m_strResultUrl;
	}

}
