package com.gmp.rusk.extension;

import java.util.ArrayList;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class ReadEx implements PacketExtension{
		public static final String NAMESPACE = "urn:xmpp:notify";
		public static final String ELEMENT_NAME = "read";
		
		private ArrayList<String> ids = new ArrayList<String>();
		private boolean isGroup;
		
//		public ReadEx(){}
//		
//		public ReadEx(String id){
//			ids.add(id);
//		}
//		public ReadEx(String id, boolean isGroup){
//			ids.add(id);
//			this.isGroup = isGroup;
//		}
		public ReadEx(ArrayList<String> ids){
			this.ids = ids;
		}
		public ReadEx(ArrayList<String> ids, boolean isGroup){
			this.ids = ids;
			this.isGroup = isGroup;
		}
		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}
		
		
		public ArrayList<String> getIds(){
			return ids;
		}

		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();
			// 1.5.5 에서 규격 수정됨
//			if(isGroup){
//				buf.append("<query xmlns='").append(MultiChatMsgEx.NAMESPACE).append("'/>");
//			}
			buf.append("<read xmlns='").append(NAMESPACE).append("'>");
			for(String id : ids){
				buf.append("<ack id='").append(id).append("'/>");
			}
			buf.append("</read>");
			return buf.toString();
		}
		
//		public static class Provider implements PacketExtensionProvider {
//			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
//	            ArrayList<String> ids = new ArrayList<String>();
//				boolean done = false;
//				int cnt = parser.getAttributeCount();
//				for(int i = 0; i < cnt; i++){
//					if(parser.getAttributeName(i).equals("id")){
//						ids.add(parser.getAttributeValue(i));		
//					}
//				}
//				while(!done){
//					int eventType = parser.next();					
//					if (eventType == XmlPullParser.START_TAG) {
//		                if (parser.getName().equals("id")) {
//		                	ids.add(parser.nextText());
//		                }
//		            }
//		            else if (eventType == XmlPullParser.END_TAG) {
//		                if (parser.getName().equals(ELEMENT_NAME)) {
//		                    done = true;
//		                }
//		            }
//				}
//				return new ReadEx(ids);
//			}
//		}

		public static class Provider implements PacketExtensionProvider {
			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
	            ArrayList<String> ids = new ArrayList<String>();
				boolean done = false;
				while(!done){
					int eventType = parser.getEventType();					
					if (eventType == XmlPullParser.START_TAG) {
		                if (parser.getName().equals("ack")) {
		                	ids.add(parser.getAttributeValue("", "id"));
		                }
		            }
		            else if (eventType == XmlPullParser.END_TAG) {
		                if (parser.getName().equals(ELEMENT_NAME)) {
		                    done = true;
		                }
		            }
					if(!done) parser.next();
				}
				return new ReadEx(ids);
			}
		}
	}