package com.gmp.rusk.service;

import android.content.Context;

import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.extension.GroupChatsEx;
import com.gmp.rusk.extension.IQKickErrorEx;
import com.gmp.rusk.extension.IQMaxUserErrorEx;
import com.gmp.rusk.extension.IQQuitErrorEx;
import com.gmp.rusk.extension.IQRoomTitleEx;
import com.gmp.rusk.extension.IQUsersEx;
import com.gmp.rusk.extension.InviteMyEx;
import com.gmp.rusk.extension.QuitMyEx;
import com.gmp.rusk.extension.RoomsEx;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.Utils;

import org.jivesoftware.smack.packet.Packet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

public class XmppFilterIQ extends XmppFilterMessage{

	private final String TAG = XmppConnectionService.class.getSimpleName();
	
	// 방이 없을때 방 목록 받아와 방을 만드는 경우 만들어 지고 있는 방 갯수를 체크하기 위해서
	int m_nTotalRoomCount = 0;
	int m_nMakedRoomCount = 0;
	
	Context mContext;
	// 앱 업데이트시 방을 새로 갱신해 주기 위함
	private boolean m_isRemakeRoom = false;
	
	// 앱 최초 설치, 업데이트시 모임 방 이름 지정을 위해 사용
	private HashMap<String, ArrayList<String>> m_mapSNSName = new HashMap<String, ArrayList<String>>();
	
	XmppListener mXmppListener;

	
	private XmppSendPacket mXmppSendPacket;
	public XmppFilterIQ(XmppListener listener, XmppSendPacket xmppSendPacket, Context context){
		mXmppListener = listener;
		mContext = context;
		mXmppSendPacket = xmppSendPacket;
		setContext(context);
	}
	

	public void setFilterIQ(Packet iq) {

		if (iq.getError() != null) {
			if (mXmppListener.getIntroPacketListner() != null) {
				mXmppListener.getIntroPacketListner().showPopup();
			}
		}
		else if(iq instanceof IQRoomTitleEx) {


		}
		// 본인이 나가기 버튼 클릭
		else if (iq instanceof QuitMyEx) {
			
		}
		// // 본인이 추방
		
		// 본인이 초대
		else if (iq instanceof InviteMyEx) {
			InviteMyEx inviteEx = (InviteMyEx) iq;
			if (inviteEx != null) {
				if (iq.getError() != null)
					CommonLog.e(TAG, "IQ Error Code : " + iq.getError().getCode());
				

			}
		}
		//그룹챗 목록
		else if(iq instanceof GroupChatsEx){
			GroupChatsEx groupChatsEx = (GroupChatsEx) iq;
			if (groupChatsEx != null) {
				ArrayList<ChattingRoomInfoData> arrRoominfo = groupChatsEx.getNodes();
				if (arrRoominfo.isEmpty()) {
					if (mXmppListener.getIntroPacketListner() != null) {
						CommonLog.e(TAG, "RR-Room Empty");
						SharedPref pref = SharedPref.getInstance(mContext);
						pref.setStringPref(SharedPref.PREF_NOW_VERSION, Utils.getApplicationVersion(mContext));

						mXmppListener.getIntroPacketListner().onUnBind();

					}
				} else {
					m_nTotalRoomCount = arrRoominfo.size();

					SharedPref pref = SharedPref.getInstance(mContext);
					if (Utils.getApplicationVersion(mContext).equals(pref.getStringPref(SharedPref.PREF_NOW_VERSION))) {
						CommonLog.e(TAG, "RR-Version Same");
						ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(mContext);
						for (ChattingRoomInfoData roomInfoData : arrRoomData) {
							for(int i = 0 ; i < arrRoominfo.size() ; i++) {
								if(arrRoominfo.get(i).m_strRoomId.equals(roomInfoData.m_strRoomId)) {
									if (!roomInfoData.m_strRoomTitle.equals("") && !arrRoominfo.get(i).m_strRoomTitle.equals("")){
										try {
											LocalAesCrypto crypto = new LocalAesCrypto();
											String strRoomTitle = crypto.decrypt(roomInfoData.m_strRoomTitle);
											if (!arrRoominfo.get(i).m_strRoomTitle.equals(strRoomTitle)) {
												roomInfoData.m_strRoomTitle = crypto.encrypt(arrRoominfo.get(i).m_strRoomTitle);
												RoomDBManager.updateRoom(mContext, roomInfoData);
											}
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
								}
							}
						}

					} else {
						CommonLog.e(TAG, "RR-Version Different");
						m_isRemakeRoom = true;
						ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(mContext);
						for (ChattingRoomInfoData roomInfoData : arrRoomData) {
							boolean isRoom = false;
							if (roomInfoData.m_strRoomId.length() >= 8) {
								/*for (String strRoomID : arrRoomID) {
									if (strRoomID.contains("|")) {
										strRoomID = strRoomID.split("\\|")[0];
									}
									if (strRoomID.equals(roomInfoData.m_strRoomId)) {
										isRoom = true;
										break;
									}
								}*/
								for(int i = 0 ; i < arrRoominfo.size() ; i++){
									if(arrRoominfo.get(i).m_strRoomId.equals(roomInfoData.m_strRoomId)){
										isRoom = true;
										break;
									}
								}
								if (!isRoom) {
									RoomDBManager.deleteRoom(mContext, roomInfoData.m_strRoomId);
									ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
									chattingDBMng.openWritable(roomInfoData.m_strRoomId);
									chattingDBMng.deleteChattingUser();
									chattingDBMng.close();
									CommonLog.e(TAG, "RR-Invalid Room Delete");
								}
							}
						}
					}
					//m_mapSNSName에 모임 대화방의 이름을 저장한다.
					/*for (String strRoomID : arrRoomID) {
						if (strRoomID.contains("|")) {
							try {
								LocalAesCrypto crypto = new LocalAesCrypto();
								RoomDBManager.updateRoom(mContext, strRoomID.split("\\|")[0],
										crypto.encrypt(strRoomID.split("\\|")[1]), true);
								m_mapSNSName.put(strRoomID.split("\\|")[0], strRoomID.split("\\|")[1]);
							} catch (Exception e) {
								// TODO Auto-generated
								// catch block
								e.printStackTrace();
							}
						}

						mXmppSendPacket.requestUserList(strRoomID);
					}*/
					for (int i = 0 ; i < arrRoominfo.size() ; i ++){
						if(!arrRoominfo.get(i).m_strRoomTitle.equals("")){
							if(!arrRoominfo.get(i).m_strCoverImagUrl.equals("")){
								ChattingRoomInfoData chattingRoomInfoData = RoomDBManager.getChattingRoom(mContext,arrRoominfo.get(i).m_strRoomId);
								if(chattingRoomInfoData !=null){
									RoomDBManager.updateRoom(mContext,arrRoominfo.get(i).m_strRoomId,arrRoominfo.get(i).m_strCoverImagUrl);
									ArrayList<String> roomInfo = new ArrayList<>();
									roomInfo.add(arrRoominfo.get(i).m_strRoomTitle);
									m_mapSNSName.put(arrRoominfo.get(i).m_strRoomId,roomInfo);
								} else { //이미지는 있는데 방이 없는 경우
									ArrayList<String> roomInfo = new ArrayList<>();
									roomInfo.add(arrRoominfo.get(i).m_strRoomTitle);
									roomInfo.add(arrRoominfo.get(i).m_strCoverImagUrl);
									m_mapSNSName.put(arrRoominfo.get(i).m_strRoomId,roomInfo);
								}
							} else {
								ArrayList<String> roomInfo = new ArrayList<>();
								roomInfo.add(arrRoominfo.get(i).m_strRoomTitle);
								m_mapSNSName.put(arrRoominfo.get(i).m_strRoomId,roomInfo);
							}
						}
						mXmppSendPacket.requestUserList(arrRoominfo.get(i).m_strRoomId);
					}

				}
			}

		}
		// 방 목록
		/*else if (iq instanceof RoomsEx) {

			RoomsEx roomsEx = (RoomsEx) iq;
			if (roomsEx != null) {
				ArrayList<String> arrRoomID = roomsEx.getNodes();
				if (arrRoomID.isEmpty()) {
					if (mXmppListener.getIntroPacketListner() != null) {
						CommonLog.e(TAG, "RR-Room Empty");
						SharedPref pref = SharedPref.getInstance(mContext);
						pref.setStringPref(SharedPref.PREF_NOW_VERSION, Utils.getApplicationVersion(mContext));
						
						mXmppListener.getIntroPacketListner().onUnBind();

					}
				} else {
					m_nTotalRoomCount = arrRoomID.size();

					SharedPref pref = SharedPref.getInstance(mContext);
					if (Utils.getApplicationVersion(mContext).equals(pref.getStringPref(SharedPref.PREF_NOW_VERSION))) {
						CommonLog.e(TAG, "RR-Version Same");

					} else {
						CommonLog.e(TAG, "RR-Version Different");
						m_isRemakeRoom = true;
						ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(mContext);
						for (ChattingRoomInfoData roomInfoData : arrRoomData) {
							boolean isRoom = false;
							if (roomInfoData.m_strRoomId.length() >= 8) {
								for (String strRoomID : arrRoomID) {
									if (strRoomID.contains("|")) {
										strRoomID = strRoomID.split("\\|")[0];
									}
									if (strRoomID.equals(roomInfoData.m_strRoomId)) {
										isRoom = true;
										break;
									}
								}
								if (!isRoom) {
									RoomDBManager.deleteRoom(mContext, roomInfoData.m_strRoomId);
									ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
									chattingDBMng.openWritable(roomInfoData.m_strRoomId);
									chattingDBMng.deleteChattingUser();
									chattingDBMng.close();
									CommonLog.e(TAG, "RR-Invalid Room Delete");
								}
							}
						}
					}
					for (String strRoomID : arrRoomID) {
						if (strRoomID.contains("|")) {
							try {
								LocalAesCrypto crypto = new LocalAesCrypto();
								RoomDBManager.updateRoom(mContext, strRoomID.split("\\|")[0],
										crypto.encrypt(strRoomID.split("\\|")[1]), true);
								m_mapSNSName.put(strRoomID.split("\\|")[0], strRoomID.split("\\|")[1]);
							} catch (Exception e) {
								// TODO Auto-generated
								// catch block
								e.printStackTrace();
							}
						}

						mXmppSendPacket.requestUserList(strRoomID);
					}

				}
			}
			// }
		}*/
		// 유저 목록
		else if (iq instanceof IQUsersEx) {
			CommonLog.e(TAG, "성공!" + iq.toXML());
			IQUsersEx iquserEx = (IQUsersEx) iq;

			if (iquserEx != null) {

				// 방장 포함 아이디 리스트
				m_nMakedRoomCount += 1;
				CommonLog.e(TAG, "TotalCount : " + m_nTotalRoomCount);
				CommonLog.e(TAG, "MakedCount : " + m_nMakedRoomCount);
				ChattingRoomInfoData nowRoomData = RoomDBManager.getChattingRoom(mContext, iq.getFrom().split("@")[0]);
				boolean isRoom = nowRoomData != null;
				ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
				chattingDBMng.openWritable(iq.getFrom().split("@")[0]);
				ArrayList<Integer> arrRoomUsers = chattingDBMng.getChattingUser();
				
				if(arrRoomUsers.size() == 0){
					//방의 사용자가 0명이라면  다시 사용자를 넣음
					isRoom = false;
				}
				if (m_isRemakeRoom || !isRoom) {
					
					SharedPref pref = SharedPref.getInstance(mContext);

					pref.setLongPref(iq.getFrom().split("@")[0], System.currentTimeMillis());
					CommonLog.e(TAG, "체크 등록시간 : " + System.currentTimeMillis());

					ArrayList<String> arrStrUserIdList = iquserEx.getUsers();
					arrStrUserIdList.add(iquserEx.getOwnerUser());
					ArrayList<Integer> arrUserIdList = new ArrayList<Integer>();

					ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
					ArrayList<Integer> arrDBSetUserIdList = new ArrayList<Integer>();
					for (String user : arrStrUserIdList) {
						if (user != null) {
							arrUserIdList.add(Integer.parseInt(user));
							UserListData data = ContactsDBManager.getContacts(mContext, Integer.parseInt(user));
							if (data != null) {
								arrUserListData.add(data);
							} else {
								arrDBSetUserIdList.add(Integer.parseInt(user));
							}
						}

					}

					if (!arrDBSetUserIdList.isEmpty()) {
						int[] arrDBsetUser = new int[arrDBSetUserIdList.size()];
						for (int i = 0; i < arrDBSetUserIdList.size(); i++) {
							arrDBsetUser[i] = arrDBSetUserIdList.get(i);
						}
						CountDownLatch latch = new CountDownLatch(1);
						requestAddedByUserList(arrDBsetUser, latch);

						try {
							latch.await();

						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						for (UserListData userListData : m_arrDBSetUser) {
							arrUserListData.add(userListData);
						}
					}
					ArrayList<String> arrTitleName = new ArrayList<String>();
					StringBuffer title = new StringBuffer();
					for (int i = 0; i < arrUserListData.size(); i++) {
						if(arrUserListData.get(i) == null){
							arrTitleName.add(mContext.getString(R.string.not_in_db_user));
						} else {
							arrTitleName.add(arrUserListData.get(i).m_PersonalData.mapPersonalData.get(PersonalData.NAME));
						}
					}
					
					Collections.sort(arrTitleName, Utils.nameComparator);
					for (int i = 0; i < arrTitleName.size(); i++) {

						title.append(arrTitleName.get(i));
						
						if (i != arrTitleName.size() - 1) {
							title.append(", ");
						}
					}
					
//					String title = "";
//					for (int i = 0; i < arrUserListData.size(); i++) {
//						if(arrUserListData.get(i) == null){
//							title += mContext.getString(R.string.not_in_db_user);
//						} else {
//							title += Utils.aesDecoderPartnerData(arrUserListData.get(i).m_strAesData)[0];
//						}
//						
//						if (i != arrUserListData.size() - 1) {
//							title += ", ";
//						}
//					}
					// 방 만들고 채팅 유저 등록

					ChattingRoomInfoData roomInfoData;
					try {
						if (iquserEx.getOwnerUser() != null) {
							if(m_mapSNSName.containsKey(iq.getFrom().split("@")[0])){
								LocalAesCrypto crypto = new LocalAesCrypto();
								if(m_mapSNSName.get(iq.getFrom().split("@")[0]).size() >1) {
									roomInfoData = new ChattingRoomInfoData(iq.getFrom().split("@")[0], crypto.encrypt(m_mapSNSName.get(iq.getFrom().split("@")[0]).get(0)), true, Integer.parseInt(iquserEx
											.getOwnerUser()), true, m_mapSNSName.get(iq.getFrom().split("@")[0]).get(1));
								}else {
									roomInfoData = new ChattingRoomInfoData(iq.getFrom().split("@")[0], crypto.encrypt(m_mapSNSName.get(iq.getFrom().split("@")[0]).get(0)), true, Integer.parseInt(iquserEx
											.getOwnerUser()), true);
								}
							} else {
								LocalAesCrypto crypto = new LocalAesCrypto();
								roomInfoData = new ChattingRoomInfoData(iq.getFrom().split("@")[0], crypto.encrypt(title.toString()), true, Integer.parseInt(iquserEx
										.getOwnerUser()), false);
							}
							
							if(!isRoom) {
								RoomDBManager.insertRoom(mContext, roomInfoData);
							}
							else{ 
								if(!m_mapSNSName.containsKey(iq.getFrom().split("@")[0])){
									if(!nowRoomData.m_isTitleEdited){
										LocalAesCrypto crypto = new LocalAesCrypto();
										RoomDBManager.updateRoom(mContext, iq.getFrom().split("@")[0], crypto.encrypt(title.toString()), false);
									}
								}
							}
							
							if (isRoom) {
								CommonLog.e(TAG, "RR-Room User Delete");
								chattingDBMng.deleteChattingUser();
							}
							chattingDBMng.insertChattingUser(arrUserIdList);						

							mXmppSendPacket.requestOnOff("on", iq.getFrom().split("@")[0]);
						}
					} catch (NumberFormatException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					arrStrUserIdList = new ArrayList<String>();
				}
				chattingDBMng.close();
				if (m_nTotalRoomCount == m_nMakedRoomCount) {
					m_nTotalRoomCount = 0;
					m_nMakedRoomCount = 0;
					m_mapSNSName = new HashMap<String, ArrayList<String>>();
					if (mXmppListener.getIntroPacketListner() != null) {
						SharedPref pref = SharedPref.getInstance(mContext);
						pref.setStringPref(SharedPref.PREF_NOW_VERSION, Utils.getApplicationVersion(mContext));
						CommonLog.e(TAG, "RR-Now Version Setting : " + Utils.getApplicationVersion(mContext));
						m_isRemakeRoom = false;
						mXmppListener.getIntroPacketListner().onUnBind();
					}
				}
			}
		}
	}
	
	public void setFilterErrorIQ(Packet iq) {
		CommonLog.e(TAG, "IQ Error : " + iq.toXML());
		CommonLog.e(TAG, "IQ Error error: " + iq.getError());

		if (iq.getError() != null) {
			if (mXmppListener.getIntroPacketListner() != null) {
				mXmppListener.getIntroPacketListner().showPopup();
			}
		}
		if (iq instanceof IQQuitErrorEx) {

			IQQuitErrorEx quitErrorEx = (IQQuitErrorEx) iq;

			if (quitErrorEx != null) {
				CommonLog.e(TAG, "IQ Error Code : " + quitErrorEx.getCode());
				CommonLog.e(TAG, "IQ Error Text : " + quitErrorEx.getText());

				if (mXmppListener.getGroupPacketListener() != null) {
					mXmppListener.getGroupPacketListener().onErrorPopup(iq.getFrom().split("@")[0], quitErrorEx.getText());
				}
			}
		} else if (iq instanceof IQMaxUserErrorEx) {
			IQMaxUserErrorEx maxuserErrorEx = (IQMaxUserErrorEx) iq;

			if (maxuserErrorEx != null) {
				CommonLog.e(TAG, "IQ Error Code : " + maxuserErrorEx.getCode());
				CommonLog.e(TAG, "IQ Error Text : " + maxuserErrorEx.getText());

				if (mXmppListener.getGroupPacketListener() != null) {
					mXmppListener.getGroupPacketListener().onErrorPopup(iq.getFrom().split("@")[0], maxuserErrorEx.getText());
				}
			}
		} else if (iq instanceof IQKickErrorEx) {
			IQKickErrorEx kickErrorEx = (IQKickErrorEx) iq;

			if (kickErrorEx != null) {
				CommonLog.e(TAG, "IQ Error Code : " + kickErrorEx.getCode());
				CommonLog.e(TAG, "IQ Error Text : " + kickErrorEx.getText());

				if (mXmppListener.getGroupPacketListener() != null) {
					mXmppListener.getGroupPacketListener().onErrorPopup(iq.getFrom().split("@")[0], kickErrorEx.getText());
				}
			}
		}
	}
	
}
