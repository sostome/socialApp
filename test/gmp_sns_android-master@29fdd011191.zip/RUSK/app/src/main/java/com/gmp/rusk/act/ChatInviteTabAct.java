package com.gmp.rusk.act;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomFragmentActivity;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.fragment.ChatRoomChatRoomListFlag;
import com.gmp.rusk.fragment.ChatRoomFellowListFlag;
import com.gmp.rusk.fragment.ChatRoomOrganFlag;
import com.gmp.rusk.fragment.ChatRoomSearchListFlag;
import com.gmp.rusk.service.XMPPConnectionComplete;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

/**
 * ChatInviteTabAct
 *
 * @author kch Chatroom Menu Activity
 */
public class ChatInviteTabAct extends CustomFragmentActivity{

	// Tab Tag
	private final String TAB_FELLOW = "Fellow"; // 추천동료
	/* private final String TAB_REGULAR = "Regular"; // SKT직원
       private final String TAB_PARTNER = "Partner"; // 파트너*/
/*	private final String TAB_CHATROOM = "Chatroom"; // 채팅방
	private final String TAB_CHATROOMLIST = "ChatroomList"; //채팅방 리스트*/
	private final String TAB_CHATROOMLIST 	= "ChatroomList";
	private final String TAB_SEARCH     	= "Search"; //사용자 검색
	private final String TAB_ORGAN			= "Organ"; //조직도
	private final String TAB_FELLOWLIST 	= "FellowList"; // 동료리스트

	private final int TAB_INDEX_SEARCH = 0;
	/*private final int TAB_INDEX_REGULAR = 1;
    private final int TAB_INDEX_PARTNER = 2;*/
	private final int TAB_INDEX_ORGAN = 1;
	private int TAB_INDEX_FELLOWLIST = 2;
	private int TAB_INDEX_MAX;

	private final int TAB_INDEX_SEND_SEARCH = 0;
	private final int TAB_INDEX_SEND_CHATROOM = 0;
	private final int TAB_INDEX_SEND_FELLOW = 1;
	private final int TAB_INDEX_SEND_MAX = 2;

	TabHost mTabHost;
	TabManager mTabManager;
	HorizontalScrollView m_BadgeScroll;
	//ArrayList<FellowListData> m_arrFelloListData;
	//ArrayList<RegularSearchListData> m_arrRegularSearchListData;
	//ArrayList<PartnerSearchListData> m_arrPartnerSearchListData;
	ArrayList<SearchListCheckData> m_arrSearchListCheckData;
	LinearLayout m_LayoutBadge;
	LayoutInflater inflater;
	ImageView m_btnClose,m_btnComplete;
	Intent extras;
	static Fragment m_testFragment;
	LinearLayout m_RealTabContent;
	OnNotifyListener m_NotifyListener;
	// 위쪽의 초대 목록을 지울때 사용
	ArrayList<Integer> m_arrSaveUserNo;
	ArrayList<Integer> m_arrUserNumbers;

	boolean m_isInvite;
	// 메세지 전달
	String m_strSendMessage;
	String m_strSendMessageRoomID = "";
	String m_strType;

	//대화방 Tab에서 현재의 방이 보이지 않게 하기 위해
	String m_strCurrentRoom = "";
	boolean m_isInChatRoomMemberList = false;
	RelativeLayout m_layoutReturnList;

	private KickMessageBroadcastReceiver m_kickmessageReceiver = null;
	String m_strRoomID = "no_room";

	CommonPopup m_Popup;

	//전달 할 대화방이 그룹방인데 대화상대가 없음
	boolean m_isEmptyGroupRoom = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatinvitetab);
		extras = getIntent();
		m_arrUserNumbers = extras.getIntegerArrayListExtra(IntentKeyString.INTENT_KEY_ARR_USERNO);
		if (m_arrUserNumbers == null) {
			m_arrUserNumbers = new ArrayList<Integer>();
			m_arrUserNumbers.add(App.m_MyUserInfo.m_nUserNo);
		}
		if(App.m_arrRoomUserList == null) {
			App.m_arrRoomUserList = new ArrayList<Integer>();
		}
		if(!App.m_arrRoomUserList.contains(App.m_MyUserInfo.m_nUserNo)){
			App.m_arrRoomUserList.add(App.m_MyUserInfo.m_nUserNo);
		}
		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();
		m_BadgeScroll = (HorizontalScrollView) findViewById(R.id.sv_badge);
		//m_arrFelloListData = new ArrayList<FellowListData>();
		//m_arrRegularSearchListData = new ArrayList<RegularSearchListData>();
		//m_arrPartnerSearchListData = new ArrayList<PartnerSearchListData>();
		m_arrSearchListCheckData = new ArrayList<SearchListCheckData>();
		m_isInvite = extras.getBooleanExtra(IntentKeyString.INTENT_KEY_INVITE, false);
		m_strSendMessage = extras.getStringExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE);
		m_strType = extras.getStringExtra(IntentKeyString.INTENT_KEY_SEND_FILE);
		// 이 안에 있는 extras들 bundle로 변경
		Bundle bundle = getIntent().getExtras();
		if (bundle != null)
			m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID, "");
		inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		m_RealTabContent = (LinearLayout) findViewById(R.id.layout_realtabcontent);
		m_LayoutBadge = (LinearLayout) findViewById(R.id.layout_badge);
		m_btnClose = (ImageView) findViewById(R.id.btn_cancel);
		m_btnComplete = (ImageView) findViewById(R.id.btn_complete);
		m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
		m_btnComplete.setEnabled(false);
		m_arrSaveUserNo = new ArrayList<Integer>();
		View[] viewTabs;
		if(m_strSendMessage != null){
			viewTabs = new View[TAB_INDEX_SEND_MAX];
			for (int i = 0; i < TAB_INDEX_SEND_MAX; i++) {
				LayoutInflater inflater = getLayoutInflater();
				viewTabs[i] = inflater.inflate(R.layout.layout_tabitem_text, null);
			}


		/*	TextView ivSearchTab = (TextView) viewTabs[TAB_INDEX_SEND_SEARCH].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 사용자 검색 Tab*/
			TextView ivRegularTab = (TextView) viewTabs[TAB_INDEX_SEND_CHATROOM].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 대화방 Tab
			TextView ivFellowTab = (TextView) viewTabs[TAB_INDEX_SEND_FELLOW].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 추천 동로 Tab
			// Tab Image 설정

		/*	ivSearchTab.setText(R.string.tabitem_text_search_user);
			ivSearchTab.setBackgroundResource(R.drawable.tabitem_background);*/
			ivRegularTab.setText(R.string.tabitem_text_chatlist);
			ivRegularTab.setBackgroundResource(R.drawable.tabitem_background);
			ivFellowTab.setText(R.string.tabitem_text_fellowlist);
			ivFellowTab.setBackgroundResource(R.drawable.tabitem_background);

		} else {
			if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
				TAB_INDEX_MAX = 3;
			} else {
				TAB_INDEX_MAX = 2;
			}
			viewTabs = new View[TAB_INDEX_MAX];
			for (int i = 0; i < TAB_INDEX_MAX; i++) {
				LayoutInflater inflater = getLayoutInflater();
				viewTabs[i] = inflater.inflate(R.layout.layout_tabitem_text, null);

			}

			/*m_layoutReturnList = (RelativeLayout) viewTabs[1].findViewById(R.id.layout_tabitem_chatinviteitem_return);
			m_layoutReturnList.setOnClickListener(this);
			m_layoutReturnList.setVisibility(View.GONE);*/
			TextView tvSearchTab = null;
			TextView tvOrganTab = null;
			TextView tvFellowListTab = null;
			if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
				tvFellowListTab = (TextView) viewTabs[TAB_INDEX_FELLOWLIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 동료리스트 Tab
				tvSearchTab = (TextView) viewTabs[TAB_INDEX_SEARCH].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 사용자 검색 Tab
				tvOrganTab = (TextView) viewTabs[TAB_INDEX_ORGAN].findViewById(R.id.tv_tabitem_snsgroupmemberlist); //조직도 Tab
			} else {
				TAB_INDEX_FELLOWLIST = 1;
				tvSearchTab = (TextView) viewTabs[TAB_INDEX_SEARCH].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 사용자 검색 Tab
				tvFellowListTab = (TextView) viewTabs[TAB_INDEX_FELLOWLIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 동료리스트 Tab
			}

			// Tab Image 설정
			tvSearchTab.setText(R.string.tabitem_text_search_user);
			tvSearchTab.setBackgroundResource(R.drawable.tabitem_background);
			if(tvOrganTab!=null) {
				tvOrganTab.setText(R.string.tabitem_text_organ);
				tvOrganTab.setBackgroundResource(R.drawable.tabitem_background);
			}
			tvFellowListTab.setText(R.string.tabitem_text_fellowlist);
			tvFellowListTab.setBackgroundResource(R.drawable.tabitem_background);

		}


		// 여기서 타이틀 구분....
		if (m_isInvite) {
			setTitle(getString(R.string.chat_invite));
			m_btnClose.setImageResource(R.drawable.btn_btn_top_close);
		}
		else {
			if (m_strSendMessage != null) {
				setTitle(getString(R.string.chat_send_message));
				//mTabHost.getTabWidget().setVisibility(View.GONE);
				// m_BadgeScroll.setVisibility(View.VISIBLE);
				LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
				//lParams.weight = 1701;
				m_RealTabContent.setLayoutParams(lParams);
				m_btnClose.setImageResource(R.drawable.btn_btn_top_close);
			} else {
				setTitle(getString(R.string.make_chat));
			}
		}

		mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

		if(m_strSendMessage != null){
			mTabManager.addTab(mTabHost.newTabSpec(TAB_CHATROOMLIST).setIndicator(viewTabs[TAB_INDEX_SEND_CHATROOM]), ChatRoomChatRoomListFlag.class, null);
			mTabManager.addTab(mTabHost.newTabSpec(TAB_FELLOW).setIndicator(viewTabs[TAB_INDEX_SEND_FELLOW]) ,ChatRoomFellowListFlag.class,null);
		} else {
			if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
				mTabManager.addTab(mTabHost.newTabSpec(TAB_SEARCH).setIndicator(viewTabs[TAB_INDEX_SEARCH]), ChatRoomSearchListFlag.class, null);
				mTabManager.addTab(mTabHost.newTabSpec(TAB_ORGAN).setIndicator(viewTabs[TAB_INDEX_ORGAN]), ChatRoomOrganFlag.class, null);
				mTabManager.addTab(mTabHost.newTabSpec(TAB_FELLOWLIST).setIndicator(viewTabs[TAB_INDEX_FELLOWLIST]), ChatRoomFellowListFlag.class, null);
			/*	mTabManager.addTab(mTabHost.newTabSpec(TAB_ORGAN).setIndicator(viewTabs[TAB_INDEX_ORGAN]), ChatRoomOrganFlag.class,null);*/
			} else {
				mTabManager.addTab(mTabHost.newTabSpec(TAB_SEARCH).setIndicator(viewTabs[TAB_INDEX_SEARCH]), ChatRoomSearchListFlag.class, null);
				mTabManager.addTab(mTabHost.newTabSpec(TAB_FELLOWLIST).setIndicator(viewTabs[TAB_INDEX_FELLOWLIST]), ChatRoomFellowListFlag.class, null);
			}
		}
		// mTabHost.getTabWidget().getChildAt(0).getLayoutParams().height = 0;
		m_btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		m_btnComplete.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				// 기존 방 초대
				if (m_arrSaveUserNo.size() > 0 || !m_strSendMessageRoomID.equals("")) {
					if (m_isInvite) {
						if(m_arrUserNumbers.size() + m_arrSaveUserNo.size() > 150){
							m_Popup = new CommonPopup(ChatInviteTabAct.this, ChatInviteTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.snsgroupinvite_limit_chat_text));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						} else if (!m_arrSaveUserNo.isEmpty()) {
							m_Popup = new CommonPopup(ChatInviteTabAct.this, new OnClickListener() {
								@Override
								public void onClick(View v) {
									if (mService.isConnected()) {
										Intent intent = new Intent();
										intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, m_arrSaveUserNo);
										setResult(RESULT_OK, intent);
										finish();
									}
								}
							}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_title), String.format(getString(R.string.cork_pop_invite_chat_confirm),m_arrSaveUserNo.size()));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
					} else {
						// 전달
						if (m_strSendMessage != null) {
							if(!m_strSendMessageRoomID.equals("")){
								if(m_strSendMessageRoomID.length() < 8){
									Intent intent = new Intent(ChatInviteTabAct.this, ChatRoomAct.class);
									intent.putExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE, m_strSendMessage);
									intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, Integer.parseInt(m_strSendMessageRoomID));
									if(m_strType != null){
										intent.putExtra(IntentKeyString.INTENT_KEY_SEND_FILE, m_strType);
									}
									Intent intentFinish = new Intent();
									setResult(RESULT_OK, intentFinish);
									startActivity(intent);
									finish();
								} else {
									if(m_isEmptyGroupRoom){

										m_Popup = new CommonPopup(ChatInviteTabAct.this, ChatInviteTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
										m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_send_message_fail_noselect));
										m_Popup.setCancelable(false);
										isCheckShowPopup();
									} else {
										Intent intent = new Intent(ChatInviteTabAct.this, ChatRoomGroupAct.class);
										intent.putExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE, m_strSendMessage);
										intent.putExtra(IntentKeyString.INTENT_KEY_MAKE_ROOMID, m_strSendMessageRoomID);
										intent.putExtra(IntentKeyString.INTENT_KEY_NO_MAKE_ROOM, "yes");
										if (m_strType != null) {
											intent.putExtra(IntentKeyString.INTENT_KEY_SEND_FILE, m_strType);
										}
										Intent intentFinish = new Intent();
										setResult(RESULT_OK, intentFinish);
										startActivity(intent);
										finish();
									}
								}
							}
							else if (m_arrSaveUserNo.size() > 1) {
								Intent intent = new Intent(ChatInviteTabAct.this, ChatRoomGroupAct.class);
								intent.putExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE, m_strSendMessage);
								intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, m_arrSaveUserNo);
								if(m_strType != null){
									intent.putExtra(IntentKeyString.INTENT_KEY_SEND_FILE, m_strType);
								}
								Intent intentFinish = new Intent();
								setResult(RESULT_OK, intentFinish);
								startActivity(intent);
								finish();
							} else {
								Intent intent = new Intent(ChatInviteTabAct.this, ChatRoomAct.class);

								intent.putExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE, m_strSendMessage);
								intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, m_arrSaveUserNo.get(0));
								if(m_strType != null){
									intent.putExtra(IntentKeyString.INTENT_KEY_SEND_FILE, m_strType);
								}
								Intent intentFinish = new Intent();
								setResult(RESULT_OK, intentFinish);
								startActivity(intent);
								finish();
							}
						}
						// 신규 초대
						else if (!m_arrSaveUserNo.isEmpty()) {
							if(m_arrUserNumbers.size() + m_arrSaveUserNo.size() > 150){
								m_Popup = new CommonPopup(ChatInviteTabAct.this, ChatInviteTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
								m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.snsgroupinvite_limit_chat_text));
								m_Popup.setCancelable(false);
								isCheckShowPopup();
							} else if (m_arrSaveUserNo.size() > 1) {
								m_Popup = new CommonPopup(ChatInviteTabAct.this, new OnClickListener() {
									@Override
									public void onClick(View v) {
										Intent intent = new Intent(ChatInviteTabAct.this, ChatRoomGroupAct.class);
										intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, m_arrSaveUserNo);
										startActivity(intent);
										finish();
									}
								}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
								m_Popup.setBodyAndTitleText(getString(R.string.popup_title), String.format(getString(R.string.cork_pop_make_chat_confirm),m_arrSaveUserNo.size()));
								m_Popup.setCancelable(false);
								isCheckShowPopup();
							} else {
								m_Popup = new CommonPopup(ChatInviteTabAct.this, new OnClickListener() {
									@Override
									public void onClick(View v) {
										Intent intent = new Intent(ChatInviteTabAct.this, ChatRoomAct.class);
										intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, m_arrSaveUserNo.get(0));
										startActivity(intent);
										finish();
									}
								}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
								m_Popup.setBodyAndTitleText(getString(R.string.popup_title), String.format(getString(R.string.cork_pop_make_chat_confirm),m_arrSaveUserNo.size()));
								m_Popup.setCancelable(false);
								isCheckShowPopup();
							}
						}
					}
				} else {
					m_Popup = new CommonPopup(ChatInviteTabAct.this, ChatInviteTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					if(m_strSendMessage != null){
						m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_send_message_fail_noselect));
					} else {
						m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_invite_fail_noselect));
					}
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}

			}
		});

		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(StaticString.BROADCAST_KICK_RECEIVER);

		if (m_kickmessageReceiver == null) {
			m_kickmessageReceiver = new KickMessageBroadcastReceiver();
		}

		registerReceiver(m_kickmessageReceiver, intentFilter, StaticString.BROADCAST_PERMISSION_KICK, null);

	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		// TODO Auto-generated method stub
		switch (v.getId()) {
			case R.id.ib_pop_ok_long:
				CommonPopup popup_ok_long = (CommonPopup)v.getTag();
				popup_ok_long.cancel();
				break;

			case R.id.layout_tabitem_chatinviteitem_return:
				m_OnKeyBackPressedListener.onBack();
				break;

			default:
				break;
		}
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {

			if (m_isInChatRoomMemberList) {
				m_OnKeyBackPressedListener.onBack();
			} else {
				setReset();
				Intent intent = new Intent();
				setResult(RESULT_CANCELED, intent);
				finish();
			}
			return true;
		}else
			return super.onKeyDown(keyCode, event);

	}

	@Override
	protected void onXMPPServiceConnected() {
		// TODO Auto-generated method stub
		super.onXMPPServiceConnected();

		if (mService.isConnected()) {

		} else
			mService.startConnection(m_XMPPConnectionComplete);
	}

	private XMPPConnectionComplete m_XMPPConnectionComplete = new XMPPConnectionComplete() {

		@Override
		public void onConnectionComplete() {
			// TODO Auto-generated method stub
		}
	};

	@Override
	protected void onXMPPServiceDisConnected() {
		// TODO Auto-generated method stub
		super.onXMPPServiceDisConnected();

	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (m_kickmessageReceiver != null) {
			unregisterReceiver(m_kickmessageReceiver);
			m_kickmessageReceiver = null;
		}
		setReset();
	}

	public void setTitle(String a_strTitle) {
		TextView tvTitle = (TextView) findViewById(R.id.tv_tabact_main_title);
		tvTitle.setText(a_strTitle);
	}


	public void removeListData(int nUserNo) {

		for (SearchListCheckData partnerData : m_arrSearchListCheckData) {
			if (partnerData.m_nUserNo == nUserNo) {
				m_arrSearchListCheckData.remove(partnerData);
				for (SearchListCheckData appPartnerData : App.m_arrSearchListCheckData) {
					if (nUserNo == appPartnerData.m_nUserNo) {
						//appPartnerData.m_isChecked = false;
						App.m_arrSearchListCheckData.remove(appPartnerData);
						break;
					}
				}
				break;
			}
		}
		for (int i = 0; i < m_arrSaveUserNo.size(); i++) {
			if (nUserNo == m_arrSaveUserNo.get(i)) {

				for (int j = 0; j < App.m_arrSearchListCheckData.size(); j++) {
					if (m_arrSaveUserNo.get(i) == App.m_arrSearchListCheckData.get(j).m_nUserNo) {
						//App.m_arrSearchListCheckData.get(j).m_isChecked = false;
						App.m_arrSearchListCheckData.remove(j);
						break;
					}
				}

				m_LayoutBadge.removeViewAt(i);
				m_arrSaveUserNo.remove(i);

				break;
			}
		}

		if (m_arrSearchListCheckData.isEmpty()) {
			m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
			m_btnComplete.setEnabled(false);
			m_BadgeScroll.setVisibility(View.GONE);
			LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
//       if (m_strSendMessage != null) {
//          lParams.weight = 1701;
//       } else {
			lParams.weight = 1521;
//       }
			m_RealTabContent.setLayoutParams(lParams);
		}

		m_NotifyListener.onNotify();
		if (m_isInvite) {
			if(m_arrSearchListCheckData.size() > 0)
				setTitle(getString(R.string.chat_invite) + " " + m_arrSearchListCheckData.size());
			else
				setTitle(getString(R.string.chat_invite));
		}
		else {
			if (m_strSendMessage != null) {
				setTitle(getString(R.string.chat_send_message));
				//mTabHost.getTabWidget().setVisibility(View.GONE);
				// m_BadgeScroll.setVisibility(View.VISIBLE);
				LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
				//lParams.weight = 1701;
				m_RealTabContent.setLayoutParams(lParams);
			} else {
				if(m_arrSearchListCheckData.size() > 0)
					setTitle(getString(R.string.make_chat) + " " + m_arrSearchListCheckData.size());
				else
					setTitle(getString(R.string.make_chat));
			}
		}
	}

	public void addSearchList(SearchListCheckData a_SearchListData) {
		m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);
		m_btnComplete.setEnabled(true);
		if (m_arrSearchListCheckData.isEmpty()) {
			m_BadgeScroll.setVisibility(View.VISIBLE);
			m_btnComplete.setVisibility(View.VISIBLE);
			LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
//       if (m_strSendMessage != null) {
//          lParams.weight = 1551;
//       } else {
			lParams.weight = 1371;
//       }
			m_RealTabContent.setLayoutParams(lParams);
		}
		boolean isSame = false;

		for (SearchListCheckData listData : m_arrSearchListCheckData) {

			if (listData.m_nUserNo == a_SearchListData.m_nUserNo) {
				isSame = true;
			}
		}
		if (!isSame) {
			SearchListCheckData addData = new SearchListCheckData(a_SearchListData.m_nUserNo, a_SearchListData.m_strName);
			//addData.m_isChecked = true;
			App.m_arrSearchListCheckData.add(0, addData);
			m_arrSearchListCheckData.add(0, a_SearchListData);
			final LinearLayout inviteScrollItem = (LinearLayout) inflater.inflate(R.layout.layout_invite_scroll_item, null);
			m_LayoutBadge.addView(inviteScrollItem, 0);
			final TextView tvInviteScrollItem = (TextView) inviteScrollItem.findViewById(R.id.tv_invite_scroll_item);
			final LinearLayout layoutScrollItem = (LinearLayout) inviteScrollItem.findViewById(R.id.layout_invite_scroll_item);
			tvInviteScrollItem.setText(a_SearchListData.m_strName);
			m_arrSaveUserNo.add(0, a_SearchListData.m_nUserNo);
			layoutScrollItem.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int nUserNo = m_arrSaveUserNo.get(m_LayoutBadge.indexOfChild(inviteScrollItem));
					for (SearchListCheckData partnerData : m_arrSearchListCheckData) {
						if (partnerData.m_nUserNo == nUserNo) {
							removeListData(partnerData.m_nUserNo);
							break;
						}

					}

				}
			});
		}

		if (m_isInvite)
			if(m_arrSearchListCheckData.size() > 0)
				setTitle(getString(R.string.chat_invite) + " " + m_arrSearchListCheckData.size());
			else
				setTitle(getString(R.string.chat_invite));
		else {
			if (m_strSendMessage != null) {
				setTitle(getString(R.string.chat_send_message));
				//mTabHost.getTabWidget().setVisibility(View.GONE);
				// m_BadgeScroll.setVisibility(View.VISIBLE);
				LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
				//lParams.weight = 1701;
				m_RealTabContent.setLayoutParams(lParams);
			} else {
				if(m_arrSearchListCheckData.size() > 0)
					setTitle(getString(R.string.make_chat) + " " + m_arrSearchListCheckData.size());
				else
					setTitle(getString(R.string.make_chat));
			}
		}
	}

	public void setSendRoomID(String a_strSendMessageRoomID, boolean a_isOneUser){
		m_strSendMessageRoomID = a_strSendMessageRoomID;
		m_isEmptyGroupRoom = a_isOneUser;
		if(a_strSendMessageRoomID.equals("")){
			m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
			m_btnComplete.setEnabled(false);
		} else {
			m_btnComplete.setVisibility(View.VISIBLE);
			m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);
			m_btnComplete.setEnabled(true);
		}
	}

	public String getSendRoomID(){
		return m_strSendMessageRoomID;
	}

	public String getType(){
		return m_strType;
	}

	public void setCloudFailPopup(){
		m_Popup = new CommonPopup(ChatInviteTabAct.this, ChatInviteTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_fail_cloud));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}

	public void setNotifyListener(OnNotifyListener a_Listener) {
		m_NotifyListener = a_Listener;
	}

	public interface OnNotifyListener {
		public void onNotify();
	}

	public class TabManager implements TabHost.OnTabChangeListener {
		private final FragmentActivity mActivity;
		private final TabHost mTabHost;
		private final int mContainerId;
		private final HashMap<String, TabInfo> mTabs = new HashMap<String, TabInfo>();
		TabInfo mLastTab;

		final class TabInfo {
			private final String tag;
			private final Class<?> clss;
			private final Bundle args;
			private Fragment fragment;

			TabInfo(String _tag, Class<?> _class, Bundle _args) {
				tag = _tag;
				clss = _class;
				args = _args;
			}
		}

		class DummyTabFactory implements TabHost.TabContentFactory {
			private final Context mContext;

			public DummyTabFactory(Context context) {
				mContext = context;
			}

			@Override
			public View createTabContent(String tag) {
				View v = new View(mContext);
				v.setMinimumWidth(0);
				v.setMinimumHeight(0);
				return v;
			}
		}

		public TabManager(FragmentActivity activity, TabHost tabHost, int containerId) {
			mActivity = activity;
			mTabHost = tabHost;
			mContainerId = containerId;
			mTabHost.setOnTabChangedListener(this);
		}

		public void addTab(TabHost.TabSpec tabSpec, Class<?> clss, Bundle args) {
			tabSpec.setContent(new DummyTabFactory(mActivity));
			String tag = tabSpec.getTag();

			TabInfo info = new TabInfo(tag, clss, args);

			// Check to see if we already have a fragment for this tab, probably
			// from a previously saved state. If so, deactivate it, because our
			// initial state is that a tab isn't shown.
			info.fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
			if (info.fragment != null && !info.fragment.isDetached()) {
				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				ft.detach(info.fragment);
				ft.commit();
			}
			m_testFragment = info.fragment;
			mTabs.put(tag, info);
			mTabHost.addTab(tabSpec);
		}

		@Override
		public void onTabChanged(String tabId) {
			TabInfo newTab = mTabs.get(tabId);

			if(m_strSendMessage != null){
				if(tabId.equals(TAB_CHATROOMLIST)){
					m_arrSaveUserNo.clear();
					m_arrSearchListCheckData.clear();
					if(App.m_arrSearchListCheckData != null){
						App.m_arrSearchListCheckData.clear();
					}
					m_LayoutBadge.removeAllViews();

					App.m_arrRoomUserList = new ArrayList<Integer>();
					for (int i = 0; i < App.m_arrFellowListData.size(); i++) {
						App.m_arrFellowListData.get(i).m_isChecked = false;
					}
					m_BadgeScroll.setVisibility(View.GONE);
					m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
					m_btnComplete.setEnabled(false);
					LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
//          if (m_strSendMessage != null) {
//             lParams.weight = 1701;
//          } else {
					lParams.weight = 1521;
//          }
					m_RealTabContent.setLayoutParams(lParams);
				} else {
					m_strSendMessageRoomID = "";
					m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
					m_btnComplete.setEnabled(false);
				}
			}

			if (mLastTab != newTab) {

				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				if (mLastTab != null) {
					if (mLastTab.fragment != null) {
						ft.detach(mLastTab.fragment);
					}
				}
				if (newTab != null) {
					if (newTab.fragment == null) {
						newTab.fragment = Fragment.instantiate(mActivity, newTab.clss.getName(), newTab.args);
						ft.add(mContainerId, newTab.fragment, newTab.tag);
					} else {
						ft.attach(newTab.fragment);
					}
				}

				mLastTab = newTab;
				ft.commit();
				mActivity.getSupportFragmentManager().executePendingTransactions();
			}
		}
	}

	public ArrayList<Integer> getUserNumbers() {
		return m_arrUserNumbers;
	}
	private void setReset() {
		m_arrSaveUserNo.clear();
		//m_arrFelloListData.clear();
		//m_arrRegularSearchListData.clear();
		m_arrSearchListCheckData.clear();
		//App.m_arrSearchListCheckData.clear();
		App.m_arrSearchListCheckData = new ArrayList<SearchListCheckData>();
		App.m_arrRoomUserList = new ArrayList<Integer>();
		for (int i = 0; i < App.m_arrFellowListData.size(); i++) {
			App.m_arrFellowListData.get(i).m_isChecked = false;
		}
//    for (int i = 0; i < App.m_arrSearchListCheckData.size(); i++) {
//       App.m_arrSearchListCheckData.get(i).m_isChecked = false;
//    }
//    for (int i = 0; i < App.m_arrRegularSearchListDatas.size(); i++) {
//       App.m_arrRegularSearchListDatas.get(i).m_isChecked = false;
//    }
	}

	// CustomFragmentActivity 중에선 여기서만 필요하므로
	public class KickMessageBroadcastReceiver extends BroadcastReceiver {

		String strAction;

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			strAction = intent.getAction();

			if (strAction.equals(StaticString.BROADCAST_KICK_RECEIVER)) {
				Bundle bundle = intent.getExtras();
				if (bundle != null)
					onKick(bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID_KICK));
			}
		}

	}

	protected void onKick(String a_strRoomId) {
		if (m_strRoomID.equals(a_strRoomId)) {
			finish();
		}
	}

	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		}
	}

	public String getCurrentRoom() {
		return m_strRoomID;
	}

	private onKeyBackPressedListener m_OnKeyBackPressedListener;

	public interface onKeyBackPressedListener {
		public void onBack();
	}

	public void setOnKeyBackPressedListener(onKeyBackPressedListener listener) {
		m_OnKeyBackPressedListener = listener;
	}

	public void inChatRoomMemberList(boolean isState) {
		m_isInChatRoomMemberList = isState;
		if (isState) {
			m_layoutReturnList.setVisibility(View.VISIBLE);
		} else {
			m_layoutReturnList.setVisibility(View.GONE);
		}
	}
}
