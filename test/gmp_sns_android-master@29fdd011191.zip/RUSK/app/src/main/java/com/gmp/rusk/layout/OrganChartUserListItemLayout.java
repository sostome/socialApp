package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.gmp.rusk.R;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostAddBuddysReq;

import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.HashMap;

/**
 * OrganChartUserListItemLayout
 * 조직도 인물 List Item Layout
 */
public class OrganChartUserListItemLayout extends CustomLinearLayout implements OnClickListener{
	
	ImageButton ib_add_fellow;
	Context m_Context;
	boolean m_isMakeRoom = false;
	
	private DepartmentUserListData m_DepartmentUserListData = null;
	
	private CommonPopup m_Popup = null;
	
	private ProgressDlg m_Progress = null;
	
	public OrganChartUserListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public OrganChartUserListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	public OrganChartUserListItemLayout(Context context, boolean isMakeRoom) {
		super(context);
		// TODO Auto-generated constructor stub
		m_isMakeRoom = isMakeRoom;
		init(context);
	}
	
	private void init(Context a_context)
	{
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listview_organchart_user, this);
		
	}
	
	public void setDepartmentUserListData(DepartmentUserListData a_Data)
	{
		m_DepartmentUserListData = a_Data;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		ImageView iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
		ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);

		if(m_DepartmentUserListData.getImageAvailable())
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_DepartmentUserListData.getUserNo(), true), R.drawable.profile_pic_default, false);
		}
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}

		TextView tv_name = (TextView)findViewById(R.id.tv_name);
		TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
		LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
		TextView tv_position = (TextView) findViewById(R.id.tv_position);
		LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
		TextView tv_charge = (TextView) findViewById(R.id.tv_charge);
		tv_name.setText(m_DepartmentUserListData.getName());

		if(m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_DepartmentUserListData.m_strPosition !=null && !m_DepartmentUserListData.m_strPosition.equals("")){
			layout_position.setVisibility(VISIBLE);
			tv_position.setText(m_DepartmentUserListData.m_strPosition);
		} else {
			layout_position.setVisibility(GONE);
		}

		if(m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_DepartmentUserListData.m_strCharge!=null && !m_DepartmentUserListData.m_strCharge.equals("")){
			layout_charge.setVisibility(VISIBLE);
			tv_charge.setText(m_DepartmentUserListData.m_strCharge);
		} else {
			layout_charge.setVisibility(GONE);
		}

		if(m_DepartmentUserListData.getAvailable())
		{
			tv_uninstall.setVisibility(GONE);
		}
		else
		{
			tv_uninstall.setVisibility(VISIBLE);
		}

		TextView tv_departments = (TextView)findViewById(R.id.tv_departments);

		if (m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR)) {
			tv_departments.setText(m_DepartmentUserListData.m_strDepartment+" | "+m_DepartmentUserListData.m_strCompanyName);
		}

		ib_add_fellow = (ImageButton)findViewById(R.id.ib_add_fellow);
		ib_add_fellow.setOnClickListener(this);

		CheckBox cb_makeroom = (CheckBox)findViewById(R.id.cb_makeroom);

		if(m_isMakeRoom){

			if(App.m_EntryData.m_nUserNo != m_DepartmentUserListData.getUserNo())
			{
				cb_makeroom.setVisibility(View.VISIBLE);
			}
			else
				cb_makeroom.setVisibility(View.INVISIBLE);

			cb_makeroom.setOnCheckedChangeListener(new OnCheckedChangeListener() {

				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					// TODO Auto-generated method stub
					if(buttonView.getId() == R.id.cb_makeroom){
						if(isChecked){
							App.m_arrDepartmentUserListData.add(m_DepartmentUserListData);
						} else {
							App.m_arrDepartmentUserListData.remove(m_DepartmentUserListData);
						}
					}
				}
			});
		}
		UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_DepartmentUserListData.getUserNo());
		if(m_DepartmentUserListData.getAvailable() && App.m_EntryData.m_nUserNo != m_DepartmentUserListData.getUserNo())
		{
			ib_add_fellow.setVisibility(View.VISIBLE);

			if(userData != null)
			{
				if(userData.m_isFellow)
					ib_add_fellow.setVisibility(View.INVISIBLE);
			}
		}
		else
			ib_add_fellow.setVisibility(View.INVISIBLE);

		iv_notfellow_pic.setVisibility(View.GONE);
		RelativeLayout layout_listitem_search = (RelativeLayout)findViewById(R.id.layout_listitem_search);
		layout_listitem_search.setOnClickListener(this);
	}
	

	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()== R.id.ib_add_fellow)
		{	
			ib_add_fellow.setClickable(false);
			requestAddBuddys();
		}
		else if(v.getId()==R.id.layout_listitem_search)
		{
			doShowProfile();
		}
		else if(v.getId()==R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(m_Context);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Context);
			}
			else
			{
				popup_ok_long.cancel();
			}
		}
	}
	
	private void doShowProfile()
	{
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_DepartmentUserListData.getUserNo());
		m_Context.startActivity(intent);
	}
	
	private void requestAddBuddys()
    {
		showProgress();
    	int[] nSelects = new int[1];
    	nSelects[0] = m_DepartmentUserListData.getUserNo();
    	PostAddBuddysReq req = new PostAddBuddysReq(nSelects);
		WebAPI webApi = new WebAPI(m_Context);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
//				FellowListData fellowListData = new FellowListData(m_PartnerSearchListData.m_nUserNo, "P", m_PartnerSearchListData.m_strName, m_PartnerSearchListData.m_strCompany,
//						null, null, m_PartnerSearchListData.m_isImageAvailable, m_PartnerSearchListData.m_isAvailable);
				ib_add_fellow.setClickable(true);
				UserListData getItem = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_DepartmentUserListData.getUserNo());
				
				if(getItem != null)
				{
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();

					closeProgress();
					TTalkDBManager.ContactsDBManager.updateContacts(m_Context, getItem);	
					ib_add_fellow.setVisibility(View.INVISIBLE);

					HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
					if (getItem.m_strUserType.equals("R")) {
						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),personalData.get(PersonalData.AFFILIATION),
								personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
						App.buddyAdd(fellowListData);
					} else {
						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
								getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
						App.buddyAdd(fellowListData);
					}
		    		((MainTabAct)m_Context).mService.addBuddy(Integer.toString(getItem.m_nUserNo));
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							m_Context.getString(R.string.pop_fellowadd_title),
							m_Context.getString(R.string.pop_fellowadd_success));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else
				{
					//사용자 추가..... 구현
					//Toast.makeText(m_Context, m_DepartmentUserListData.getUserNo() +"["+m_DepartmentUserListData.getName()+"]은 사용자 정보 DB에 없습니다.", Toast.LENGTH_SHORT).show();
					requestAddedByUserList();
				}
				
				
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				ib_add_fellow.setClickable(true);
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							m_Context.getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
    }
	
    private void requestAddedByUserList()
    {	
    	int[] nSelects = new int[1];
    	nSelects[0] = m_DepartmentUserListData.getUserNo();
    	GetUserInfoReq req = new GetUserInfoReq(nSelects);
    	WebAPI webApi = new WebAPI(m_Context);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);
				
				UserListData getItem = res.getUserListData().get(0);
				if(getItem != null)
				{
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();
					if(ContactsDBManager.insertContacts(m_Context, getItem) > 0)
					{
						ib_add_fellow.setVisibility(View.INVISIBLE);

						HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
						if (getItem.m_strUserType.equals("R")) {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),personalData.get(PersonalData.AFFILIATION),
									personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						} else {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
									getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						}
						((MainTabAct)m_Context).mService.addBuddy(Integer.toString(getItem.m_nUserNo));
						m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(
								m_Context.getString(R.string.pop_fellowadd_title),
								m_Context.getString(R.string.pop_fellowadd_success));
						m_Popup.setCancelable(false);
						m_Popup.show();
					}
				}
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else
				{
					m_Popup = new CommonPopup(m_Context, OrganChartUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							m_Context.getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
    }
    
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

}
