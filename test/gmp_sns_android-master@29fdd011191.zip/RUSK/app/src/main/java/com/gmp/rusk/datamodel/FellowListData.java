package com.gmp.rusk.datamodel;

public class FellowListData {
	public String m_strUserId = "";
	public int m_nUserNo = 0;						//사용자 번호
	public String m_strUserType = "";				//사용자 유형 R:정직원 P:파트너
	public String m_strName = "";					//이름
	public String m_strEmail = "";				//이메일
	public String m_strMobile = "";				//전화번호
	public String m_strCompanyCode = "";
	public String m_strDepartment = "";				//부서
	public String m_strDepartmentCode = "";
	public String m_strParentDepartment = "";					//소속
	public String m_strCharge = "";					//직책
	public String m_strPosition = "";					//지위
	public String m_strSecondCharge = "";			//겸직 직책
	public String m_strCompany = "";				//회사명
	public String m_strAffiliation = "";
	public boolean m_isImageAvailable = false;		//이미지 보유 여부
	public String m_strGreeting ="";
	public boolean m_isActive = false;				//사용자 앱 설치 유무
	public String m_strStatus = "";
	public String m_strFellowAddTime = "";				//동료 추가 시간
	public boolean m_isChecked = false;


	public FellowListData() {

	}
	public FellowListData(int a_nUserNo, String a_strUserType, String a_strName,String a_strCompany,String a_strSecondCharge,String a_strPosition, String a_strDepartment, String a_strParentDepartment, String a_strAffliation, String a_strCharge,
			boolean a_isImageAvailable, boolean a_isActive, String a_strFellowAddTime, String a_strGreeting) {
		m_nUserNo = a_nUserNo;
		m_strUserType = a_strUserType;
		m_strName = a_strName;
		m_strDepartment = a_strDepartment;
		m_strPosition = a_strPosition;
		m_strParentDepartment = a_strParentDepartment;
		m_strAffiliation = a_strAffliation;
		m_strCompany = a_strCompany;
		m_strCharge = a_strCharge;
		m_isImageAvailable = a_isImageAvailable;
		m_isActive = a_isActive;
		m_strFellowAddTime = a_strFellowAddTime;
		m_strGreeting = a_strGreeting;
	}
}
