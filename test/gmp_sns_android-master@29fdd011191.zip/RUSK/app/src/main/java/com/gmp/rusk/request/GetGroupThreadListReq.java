package com.gmp.rusk.request;

/**
 *	@author kch
 *			모임 게시글 목록 조회
 *			method : get
 */

public class GetGroupThreadListReq extends Req{

	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";


	public GetGroupThreadListReq(int a_nGroupId, int a_nPage, long a_lThreadNo)
	{
		if(a_nPage == 0) {
			a_lThreadNo = 0;
		}
		APINAME = APINAME + "/" + a_nGroupId + "/thread" + "?page=" + a_nPage + "&baseThreadNo=" + a_lThreadNo;
	}


	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
			return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
