package com.gmp.rusk.request;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author subi78
 *			조직도 - 초기
 *			method : get
 */

public class GetDepartmentReq extends Req{
	
	private String APINAME = "department";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";
	

	public GetDepartmentReq(String a_strCompanyCode, String a_strDepartmentCode) {
		APINAME = APINAME + "/" + a_strCompanyCode + "/" + a_strDepartmentCode;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
