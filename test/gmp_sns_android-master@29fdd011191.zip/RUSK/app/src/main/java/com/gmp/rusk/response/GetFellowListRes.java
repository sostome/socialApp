package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.AddedByFellowListData;
import com.gmp.rusk.utils.CommonLog;

public class GetFellowListRes extends Res{
//	private final String JSON_BUDDYCOUNT 				= "buddyCount";
	private final String JSON_BUDDIES		 			= "buddies";
	private final String JSON_USERNO					= "userNo";
			
	ArrayList<Integer> m_arrBuddyNo = null;
	
	public GetFellowListRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_BUDDIES)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_BUDDIES);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrBuddyNo = new ArrayList<Integer>();
					for (int i = 0; i < nArrCount; i++) {
						
						int nUserNo = jsonArray.getInt(i);

						m_arrBuddyNo.add(nUserNo);
					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	public ArrayList<Integer> getFellowList()
	{
		return m_arrBuddyNo;
	}
	
}
