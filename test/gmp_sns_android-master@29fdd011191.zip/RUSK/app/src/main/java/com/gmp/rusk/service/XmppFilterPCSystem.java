package com.gmp.rusk.service;

import java.util.HashMap;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;


import com.gmp.rusk.R;
import com.gmp.rusk.act.PushPopupScreenOffAct;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.db.TTalkDBManager.SNSGroupDBManager;
import com.gmp.rusk.extension.DelayInformationTTalk;
import com.gmp.rusk.extension.PCSyncEx;
import com.gmp.rusk.extension.PCSystemEx;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.request.GetUserInfoReq;

import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import android.content.Context;
import android.os.Handler;
import android.os.PowerManager;

public class XmppFilterPCSystem extends XmppFilterMessage {
	Handler mHandler;
	XMPPConnection connection;
	Context mContext;
	Long lnEditTime;
	XmppListener mXmppListener;

	public XmppFilterPCSystem(Long lTime, XmppListener listener, Handler handler, XMPPConnection superConnection, Context context) {
		lnEditTime = lTime;
		mXmppListener = listener;
		mHandler = handler;
		connection = superConnection;
		mContext = context;
		setContext(context);
	}

	public void setFilter(final Packet message) {

		PCSystemEx pcsystemEx = (PCSystemEx) message.getExtension(PCSystemEx.NAMESPACE);
		PCSyncEx pcsyncEx = (PCSyncEx) message.getExtension(PCSyncEx.NAMESPACE);

		//서버 메시지의 처리를 위해 Message에 다른 정보가 포함 되므로, 푸쉬 메시지 표시를 위한 String을 따로 할당
		String strPushMessage = "";
		if ((message.getFrom().equals("cork.com"))) {
			if (pcsystemEx != null) {
				if (pcsystemEx.getElementName().equals(PCSystemEx.ELEMENT_NAME)) {

					boolean isNoRoom = true;
					ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(mContext, Integer.toString(App.m_MyUserInfo.m_nUserNo));
					if (roomData != null) {
						isNoRoom = false;
					}

					if (isNoRoom) {
						CommonLog.e(mContext, "생성 진입");

						ChattingRoomInfoData data;
						try {
							LocalAesCrypto crypto = new LocalAesCrypto();
							data = new ChattingRoomInfoData(Integer.toString(App.m_MyUserInfo.m_nUserNo), crypto.encrypt(mContext.getString(R.string.app_name)), true, App.m_MyUserInfo.m_nUserNo, false);
							RoomDBManager.insertRoom(mContext, data);
						} catch (Exception e) {
							// TODO Auto-generated
							// catch block
							e.printStackTrace();
						}

						CommonLog.e(mContext, "생성 중");

					}

					final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

					ChattingMessageData a_chattingMsgData;
					a_chattingMsgData = new ChattingMessageData();

					int nDBResult = 0;
					ChattingDBManager chattingDBMng = null;

					chattingDBMng = new ChattingDBManager(mContext);
					chattingDBMng.openWritable(Integer.toString(App.m_MyUserInfo.m_nUserNo));

					if (message.getExtension("info", "urn:xmpp:urgent") != null) {

						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
						CommonLog.e(TAG, "Urgent Success");
					}

					if (nDBResult != -1) {
						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
						if (((Message) message).getBody() != null)
						a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());

						strPushMessage = a_chattingMsgData.m_strMsgText;
						if(pcsystemEx.getType().equals(StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORPARTNER)){
							a_chattingMsgData.m_strMsgText = a_chattingMsgData.m_strMsgText + "*" + StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORPARTNER + "*" + pcsystemEx.getApprovalUserNo();
						} else if(pcsystemEx.getType().equals(StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORREGULAR)){
							a_chattingMsgData.m_strMsgText = a_chattingMsgData.m_strMsgText + "*" + StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORREGULAR;
						}
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						// a_chattingMsgData.m_nSendUserId =
						// Integer.parseInt(message.getFrom().split("@")[0]);
						a_chattingMsgData.m_nNoReadUserCount = 0;
						a_chattingMsgData.m_nSendUserId = App.m_MyUserInfo.m_nUserNo;

						int nInsertCount = 0;
						if (delay.getStamp().getTime() > lnEditTime)
							nInsertCount = chattingDBMng.insertMessage(a_chattingMsgData);

						if (nInsertCount != -1) {

							Message sendMSG2 = new Message();
							sendMSG2.setPacketID(strPacketID);
							sendMSG2.setTo("cork.com" + "@" + SERVICE_NAME);
							sendMSG2.addExtension(new PacketExtension() {

								@Override
								public String toXML() {
									// TODO
									// Auto-generated
									// method stub
									return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
								}

								@Override
								public String getElementName() {
									// TODO
									// Auto-generated
									// method stub
									return "received";
								}

								@Override
								public String getNamespace() {
									// TODO
									// Auto-generated
									// method stub
									return "urn:xmpp:receipts";
								}

							});
							connection.sendPacket(sendMSG2);

							SharedPref pref = SharedPref.getInstance(mContext);
							int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
							int nUpdateBadgeCount = nBadgeCount + 1;
							if (nUpdateBadgeCount < 0) {
								nUpdateBadgeCount = 0;
							}
							pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
							IconBadge.updateIconBadge(mContext);

							if (mXmppListener.getPacketListener() != null && mXmppListener.getPacketListener().getRoomID().equals(mContext.getString(R.string.app_name))) {

							} else {
								if (delay.getType() != null && delay.getIdx() != null) {
									if (!delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) && !delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)) {
										PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
										boolean isScreenOn = pm.isScreenOn();

										if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
											String[] aesData;
											String strFriendName = mContext.getString(R.string.app_name);

											mHandler.post(new ToastRunnable(mContext, App.m_MyUserInfo.m_nUserNo, strFriendName, strPushMessage, mContext.getString(R.string.app_name),
													Integer.toString(App.m_MyUserInfo.m_nUserNo)));
											PushController.buildMessageNotification(mContext, App.m_MyUserInfo.m_nUserNo, strFriendName, strPushMessage,
													mContext.getString(R.string.app_name), null);
										}
									}
								} else {
									if ((message.getFrom().equals("cork.com"))) {
										PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
										boolean isScreenOn = pm.isScreenOn();

										if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
											String[] aesData;
											String strFriendName = mContext.getString(R.string.app_name);

											mHandler.post(new ToastRunnable(mContext, App.m_MyUserInfo.m_nUserNo, strFriendName, strPushMessage, mContext.getString(R.string.app_name),
													Integer.toString(App.m_MyUserInfo.m_nUserNo)));
											PushController.buildMessageNotification(mContext, App.m_MyUserInfo.m_nUserNo, strFriendName, strPushMessage,
													mContext.getString(R.string.app_name), null);
										}
									}
								}
							}

							if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null
									&& mXmppListener.getGroupPacketListener() == null) {
								mXmppListener.getNotifyListner().onNotify(Integer.toString(App.m_MyUserInfo.m_nUserNo), message.getPacketID(), false);
							}
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, App.m_MyUserInfo.m_nUserNo);
							}
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().onReadCheck(App.m_MyUserInfo.m_nUserNo, message);
							}

						}
					}

					chattingDBMng.close();

					// }
				}

			}
		} else if (message.getFrom().split("@")[0].equals(message.getTo().split("@")[0]) && message.getFrom().split("@")[1].equals("cork.com/TMS_PC")) {
			if (pcsyncEx != null) {
				if (pcsyncEx.getElementName().equals(PCSyncEx.ELEMENT_NAME)) {
					if (pcsyncEx.getType().equals("chatNameModify")) {
						ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(mContext, pcsyncEx.getJid());
						if (roomData != null) {
							try {
								LocalAesCrypto crypto = new LocalAesCrypto();
								RoomDBManager.updateRoom(mContext, roomData.m_strRoomId, crypto.encrypt(pcsyncEx.getName()), true);
							} catch (Exception e) {
								// TODO Auto-generated
								// catch block
								e.printStackTrace();
							}
						}
					} else if (pcsyncEx.getType().equals("buddyAdd")) {
						UserListData getItem = TTalkDBManager.ContactsDBManager.getContacts(mContext, pcsyncEx.getUsers().get(0));

						if (getItem != null) {
							
							getItem.m_isFellow = true;
							getItem.m_strFellowAddTime = Utils.getCurrentTime();

							TTalkDBManager.ContactsDBManager.updateContacts(mContext, getItem);

							HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
							if (getItem.m_strUserType.equals("R")) {
								FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
										personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
								App.buddyAdd(fellowListData);
							} else {
								FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
										getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
								App.buddyAdd(fellowListData);
							}

						} else {
							// 사용자 추가..... 구현
							// Toast.makeText(m_Context,
							// m_UserListData.m_nUserNo
							// +"["+aesData[0]+"]은 사용자 정보 DB에 없습니다.",
							// Toast.LENGTH_SHORT).show();
							requestAddedByUserList(pcsyncEx.getUsers().get(0));
						}
					} else if (pcsyncEx.getType().equals("buddyDel")) {
						for (int i = 0; i < pcsyncEx.getUsers().size(); i++) {
							for (Integer delInteger : pcsyncEx.getUsers()) {
								for (int j = 0; j < App.m_arrFellowListData.size(); j++) {
									if (delInteger == App.m_arrFellowListData.get(j).m_nUserNo) {
										App.m_arrFellowListData.remove(j);
										TTalkDBManager.ContactsDBManager.updateContactsIsFellow(mContext, delInteger, false);
									}
								}
							}
						}
					} else if (pcsyncEx.getType().equals("groupFavoriteAdd")) {
						for (int i = 0; i < pcsyncEx.getGroupId().size(); i++) {
							SNSGroupDBManager.updateSNSMyGroupInfoFavorite(mContext, pcsyncEx.getGroupId().get(i), true);
						}
					} else if (pcsyncEx.getType().equals("groupFavoriteDel")) {
						for (int i = 0; i < pcsyncEx.getGroupId().size(); i++) {
							SNSGroupDBManager.updateSNSMyGroupInfoFavorite(mContext, pcsyncEx.getGroupId().get(i), false);
						}
					} else if (pcsyncEx.getType().equals("chatFavoriteAdd")) {
						String strRoomId = pcsyncEx.getJid().replace("p_", "");
						ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(mContext, strRoomId);

						if (roomData != null) {
							RoomDBManager.updateRoomFavorite(mContext, roomData.m_strRoomId, true);
						}
					} else if (pcsyncEx.getType().equals("chatFavoriteDel")) {
						String strRoomId = pcsyncEx.getJid().replace("p_", "");
						ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(mContext, strRoomId);

						if (roomData != null) {
							RoomDBManager.updateRoomFavorite(mContext, roomData.m_strRoomId, false);
						}
					}
					final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;
					Message sendMSG2 = new Message();
					sendMSG2.setPacketID(strPacketID);
					sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
					sendMSG2.addExtension(new PacketExtension() {

						@Override
						public String toXML() {
							// TODO
							// Auto-generated
							// method stub
							return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
						}

						@Override
						public String getElementName() {
							// TODO
							// Auto-generated
							// method stub
							return "received";
						}

						@Override
						public String getNamespace() {
							// TODO
							// Auto-generated
							// method stub
							return "urn:xmpp:receipts";
						}

					});
					connection.sendPacket(sendMSG2);
					
				}
			}
		}

	}

	private void requestAddedByUserList(int nSelect) {
		int[] nSelects = new int[1];
		nSelects[0] = nSelect;
		GetUserInfoReq req = new GetUserInfoReq(nSelects);
		WebAPI webApi = new WebAPI(mContext);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				UserListData getItem = res.getUserListData().get(0);
				if (getItem != null) {				
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();
					if (ContactsDBManager.insertContacts(mContext, getItem) > 0) {

						HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
						if (getItem.m_strUserType.equals("R")) {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
									personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						} else {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
									getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						}

					}
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub

			}
		});
	}
}
