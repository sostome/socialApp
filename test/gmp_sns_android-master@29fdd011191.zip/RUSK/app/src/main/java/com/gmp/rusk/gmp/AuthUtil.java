package com.gmp.rusk.gmp;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.View.OnClickListener;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.AppSetting.APISERVER_LIST;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.Utils;

import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 인증 유틸리티
 *
 * @author  : june
 * @date    : $Date$
 * @id      : $Id$
 */
public class AuthUtil {

	public static final String ID_MDN        = "MDN";
	public static final String ID_APP_ID     = "APPID";
	public static final String ID_AUTH_KEY   = "authKey";
	public static final String ID_COMPANY_CD = "companyCd";
	public static final String ID_ENC_PWD    = "encPwd";
	
	public static final String WebServiceAd;
	public static final String WebDocID;
	
	public static final String NON_PERSONA_GROUP_AUTH = "com.sk.pe.group.auth";
	public static final String PERSONA_GROUP_AUTH = "com.sk.pe.group.auth.tps";
	
	public static final String NON_PERSONA_PE = "com.skt.pe";
	public static final String PERSONA_PE = "com.skt.pe.tps";
	
	public static final String m_strGroupAuth;
	public static final String m_strPeAuth;
	static {
		if(AppSetting.USING_SERVER == APISERVER_LIST.DEV_SERVER)
		{
			// 개발 톡톡 인증 서버
			//WebServiceAd    = "http://devgmp.sktelecom.com:9000/service.pe"; //테스트 서버
			WebServiceAd    = "https://m.smartworkdev.com:7000/service.pe"; //테스트 서버
			WebDocID = "https://m.smartworkdev.com:7000/service.pe";
		}
		else
		{
			// 상용 톡톡 인증 서버
			WebServiceAd    = "https://m.toktok.sk.com:49443/service.pe"; //상용 서버
			WebDocID = "https://m.toktok.sk.com:9443/service.pe";
		}
		
		if(AppSetting.FEATURE_PERSONA){
			m_strGroupAuth = PERSONA_GROUP_AUTH;
			m_strPeAuth = PERSONA_PE;
		} else {
			m_strGroupAuth = NON_PERSONA_GROUP_AUTH;
			m_strPeAuth = NON_PERSONA_PE;
		}
	}
	
	public static boolean m_isRunGMPLogin = false;
	
	/**
	 * GMP 로그인 화면을 띄운다.(일반 로그인), 호출하는 activity로 결과를 리턴한다.
	 */
	public static void runGMPLogin(Activity activity) {
		
		if(checkCoreApplication(activity))
		{
			if(!m_isRunGMPLogin)
			{
				m_isRunGMPLogin = true;
				Intent intent = new Intent(m_strGroupAuth + ".GMP_LOGIN");
				intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
				activity.startActivityForResult(intent, 1007);
			}
		}
	}

	/**
	 * Legacy 로그인 화면을 띄운다.(겸직 로그인), 호출하는 activity로 결과를 리턴한다.
	 */
	public static void runLegacyLogin(Activity activity, String companyCd) {
		Intent intent = new Intent(m_strGroupAuth + ".LEGACY_LOGIN");
		intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
		intent.putExtra("COMPANY_CD", companyCd);
		activity.startActivityForResult(intent, 1007);
	}

	/**
	 * 로그아웃	
	 */
	public static void logout(Context context) throws Exception {
		ContentResolver cr = context.getContentResolver();
		cr.update(Uri.parse("content://" + m_strPeAuth +".auth"), new ContentValues(), null, null);
	}

	/**
	 * 사용자 정보 를 가져 온다
	 */
	public static Map<String,String> getAuthInfo(Context context, String mdn, String appId) throws Exception 
	{
		MyApp App = MyApp.getInstance();
		ContentValues values = new ContentValues();
		
		values.put(ID_MDN   , getMDN(context));
		values.put(ID_APP_ID, appId);		
		ContentResolver cr = context.getContentResolver();
		Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/GMP_AUTH_PWD"), values);
		List<String> authValues = uri.getPathSegments();
		String returnId = authValues.get(1);

		if("E001".equals(returnId)) {
			throw new Exception("E001"); //GMP_AUTH is null!
		} else if("E002".equals(returnId)) {
			throw new Exception("E002"); //GMP_AUTH is fail!
		} else if("E007".equals(returnId)) {
			throw new Exception("E007"); //GMP_AUTH is fail!
		} else if("E008".equals(returnId)) {
			throw new Exception("E008"); //LEGACY is fail!"
		}

		Map<String,String> map = new HashMap<String,String>();

		String buffer = authValues.get(2);		
		String[] ids = new String[] {ID_AUTH_KEY, ID_COMPANY_CD, ID_ENC_PWD};
		
		// 구분자가 포함된 암호화된 패스워드가 나올 수 있음
		int b_offset = 0;
		int offset = buffer.indexOf("|");
		if(offset != -1) {
			map.put(ids[0], buffer.substring(0, offset));
			
			b_offset = offset;
			offset = buffer.indexOf("|", offset+1);
			if(offset != -1) {
				map.put(ids[1], buffer.substring(b_offset+1, offset));
				map.put(ids[2], buffer.substring(offset+1));
			} else {
				throw new Exception("E999");
			}
		} else {
			throw new Exception("E999");
		}

		Map<String, String> params = new HashMap<String, String>();
		params.put("primitive","COMMON_COMMON_USERINFO");
		params.put("encPwd",map.get(ID_ENC_PWD)); // 인코딩 문제시 URLEncoder.encode() 함수 삭제
		params.put("mdn", getMDN(context));
		params.put("companyCd",map.get(ID_COMPANY_CD));
		params.put("appId", App.m_AppID);
		params.put("authKey",map.get(ID_AUTH_KEY));  // 인코딩 문제시 URLEncoder.encode() 함수 삭제
		params.put("appVer",Utils.getApplicationVersion(context));  // App 버전정보
		
		CommonLog.e("getGMPAuthPwd", "ids[ID_AUTH_KEY] : " + map.get(ID_AUTH_KEY));
		CommonLog.e("getGMPAuthPwd", "ids[ID_COMPANY_CD] : " + map.get(ID_COMPANY_CD));
		CommonLog.e("getGMPAuthPwd", "ids[ID_ENC_PWD] : " + map.get(ID_ENC_PWD));
		
		CommonLog.e("getGMPAuthPwd", "WebService Start");
		WebService webService=new WebService(WebServiceAd); // 웹 서비스 주소와 연결
		String response[]=webService.webGet("", params);
		CommonLog.e("getGMPAuthPwd", "WebService end");
		
		map.put("result_code",response[0]);
		map.put("result_user_num",response[1]);
		map.put("result_message", response[2]);

		CommonLog.e("ty","response0 = " + response[0]+" **** response1 = " + response[1] +  "**** response2 = " + response[2]);
		
		return map;
	}
	
	/**
	 * 사용자 정보 를 가져 온다
	 */
	public static Map<String,String> getVersionInfo(Context context, String mdn, String appId) throws Exception 
	{
		MyApp App = MyApp.getInstance();
		ContentValues values = new ContentValues();
		
		values.put(ID_MDN   , getMDN(context));
		values.put(ID_APP_ID, appId);
		
		ContentResolver cr = context.getContentResolver();
		Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/GMP_AUTH_PWD"), values);
		List<String> authValues = uri.getPathSegments();
		String returnId = authValues.get(1);

		if("E001".equals(returnId)) {
			throw new Exception("E001"); //GMP_AUTH is null!
		} else if("E002".equals(returnId)) {
			throw new Exception("E002"); //GMP_AUTH is fail!
		} else if("E007".equals(returnId)) {
			throw new Exception("E007"); //GMP_AUTH is fail!
		} else if("E008".equals(returnId)) {
			throw new Exception("E008"); //LEGACY is fail!"
		}

		Map<String,String> map = new HashMap<String,String>();

		String buffer = authValues.get(2);
		String[] ids = new String[] {ID_AUTH_KEY, ID_COMPANY_CD, ID_ENC_PWD};
		
		// 구분자가 포함된 암호화된 패스워드가 나올 수 있음
		int b_offset = 0;
		int offset = buffer.indexOf("|");
		if(offset != -1) {
			map.put(ids[0], buffer.substring(0, offset));
			
			b_offset = offset;
			offset = buffer.indexOf("|", offset+1);
			if(offset != -1) {
				map.put(ids[1], buffer.substring(b_offset+1, offset));
				map.put(ids[2], buffer.substring(offset+1));
			} else {
				throw new Exception("E999");
			}
		} else {
			throw new Exception("E999");
		}

		Map<String, String> params = new HashMap<String, String>();
		params.put("primitive","COMMON_APP_CHECK");
		params.put("encPwd",map.get(ID_ENC_PWD)); // 인코딩 문제시 URLEncoder.encode() 함수 삭제
		params.put("mdn",getMDN(context));
		params.put("companyCd",map.get(ID_COMPANY_CD));
		params.put("groupCd","SK");
		params.put("appId", App.m_AppID);
		params.put("authKey",map.get(ID_AUTH_KEY));  // 인코딩 문제시 URLEncoder.encode() 함수 삭제
		params.put("appVer",Utils.getApplicationVersion(context));  // App 버전정보
		
		WebService webService=new WebService(WebServiceAd); // 웹 서비스 주소와 연결
		String response[]=webService.webGetVersion("", params);
		
		map.put("result",response[0]);
		map.put("appVer",response[1]);
		map.put("result_message", response[2]);

		CommonLog.e("ty","response0 = " + response[0]+" **** response1 = " + response[1] +  "**** response2 = " + response[2]);
		
		return map;
	}

	/**
	 * 파일뷰어에 사용할 DocId를 가져온다.
	 */
	public static Map<String,String> getDocId(Context context, String mdn, String appId, String strFileName, String strFileUrl) throws Exception
	{
		MyApp App = MyApp.getInstance();
		ContentValues values = new ContentValues();

		values.put(ID_MDN   , getMDN(context));
		values.put(ID_APP_ID, appId);

		ContentResolver cr = context.getContentResolver();
		Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/GMP_AUTH_PWD"), values);
		List<String> authValues = uri.getPathSegments();
		String returnId = authValues.get(1);

		if("E001".equals(returnId)) {
			throw new Exception("E001"); //GMP_AUTH is null!
		} else if("E002".equals(returnId)) {
			throw new Exception("E002"); //GMP_AUTH is fail!
		} else if("E007".equals(returnId)) {
			throw new Exception("E007"); //GMP_AUTH is fail!
		} else if("E008".equals(returnId)) {
			throw new Exception("E008"); //LEGACY is fail!"
		}

		Map<String,String> map = new HashMap<String,String>();

		String buffer = authValues.get(2);
		String[] ids = new String[] {ID_AUTH_KEY, ID_COMPANY_CD, ID_ENC_PWD};

		// 구분자가 포함된 암호화된 패스워드가 나올 수 있음
		int b_offset = 0;
		int offset = buffer.indexOf("|");
		if(offset != -1) {
			map.put(ids[0], buffer.substring(0, offset));

			b_offset = offset;
			offset = buffer.indexOf("|", offset+1);
			if(offset != -1) {
				map.put(ids[1], buffer.substring(b_offset+1, offset));
				map.put(ids[2], buffer.substring(offset+1));
			} else {
				throw new Exception("E999");
			}
		} else {
			throw new Exception("E999");
		}

		Map<String, String> params = new HashMap<String, String>();
		params.put("primitive","EXTERNAL_CORK_DOCID");
		params.put("encPwd",map.get(ID_ENC_PWD)); // 인코딩 문제시 URLEncoder.encode() 함수 삭제
		params.put("mdn", getMDN(context));
		params.put("companyCd",map.get(ID_COMPANY_CD));
		params.put("groupCd","SK");
		params.put("osName", "Android");
		params.put("appId", App.m_AppID);
		params.put("authKey",map.get(ID_AUTH_KEY));  // 인코딩 문제시 URLEncoder.encode() 함수 삭제
		params.put("appVer",Utils.getApplicationVersion(context));  // App 버전정보
		params.put("lang", App.m_strLocale);
		params.put("docName", strFileName);
		params.put("docUrl", strFileUrl);

		WebService webService=new WebService(WebDocID); // 웹 서비스 주소와 연결
		String response[]=webService.webGetDocId("", params);

		map.put("result",response[0]);
		map.put("docId",response[1]);

		CommonLog.e("ty","response0 = " + response[0]+" **** response1 = " + response[1]);

		return map;
	}

	/**
	 * 비밀키를 얻는다.
	 * 
	 * @param context
	 * @return
	 * @throws Exception
	 */	
	public static String getSecretKey(Context context) throws Exception {
		ContentResolver cr = context.getContentResolver();
		Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/SECRETKEY"), new ContentValues());
		List<String> authValues = uri.getPathSegments();
		String returnId = authValues.get(1);

		if("E001".equals(returnId)) {
			throw new Exception("E001"); //Secret-Value is null!
		}
		return authValues.get(2);
	}
	
//	/**
//	 * 서비스 요청에 필요한 authKey, companyCd, encPwd를 얻는다.
//	 * 각각 해당 키값은 ID_AUTH_KEY(="authKey"), ID_COMPANY_CD(="companyCd"), ID_ENC_PWD(="encPwd")
//	 * 
//	 * @param context
//	 * @param mdn
//	 * @param appId
//	 * @return
//	 * @throws Exception
//	 */
//	public static Map<String,String> getGMPAuthPwd(Context context, String mdn, String appId) throws Exception {
//		ContentValues values = new ContentValues();
//		
//		CommonLog.e("getGMPAuthPwd", "mdn : " + mdn);
//		CommonLog.e("getGMPAuthPwd", "appId : " + appId);
//		
//		values.put(ID_MDN   , mdn);
//		values.put(ID_APP_ID, appId);
//		String appVer = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
//
//		CommonLog.e("getGMPAuthPwd", "appVer : " + appVer);
//		
//		ContentResolver cr = context.getContentResolver();
//		Uri uri = cr.insert(Uri.parse("content://com.skt.pe.auth/GMP_AUTH_PWD"), values);
//		List<String> authValues = uri.getPathSegments();
//		String returnId = authValues.get(1);
//		CommonLog.e("getGMPAuthPwd", "returnId : " + returnId);
//		if("E001".equals(returnId)) {
//			throw new Exception("E001"); //GMP_AUTH is null!
//		} else if("E002".equals(returnId)) {
//			throw new Exception("E002"); //GMP_AUTH is fail!
//		} else if("E007".equals(returnId)) {
//			throw new Exception("E007"); //GMP_AUTH is fail!
//		} else if("E008".equals(returnId)) {
//			throw new Exception("E008"); //LEGACY is fail!"
//		}
//
//		Map<String,String> map = new HashMap<String,String>();
//
//		String buffer = authValues.get(2);		
//		String[] ids = new String[] {ID_AUTH_KEY, ID_COMPANY_CD, ID_ENC_PWD};
//		
//		// 구분자가 포함된 암호화된 패스워드가 나올 수 있음
//		int b_offset = 0;
//		int offset = buffer.indexOf("|");
//		if(offset != -1) {
//			map.put(ids[0], buffer.substring(0, offset));
//			
//			b_offset = offset;
//			offset = buffer.indexOf("|", offset+1);
//			if(offset != -1) {
//				map.put(ids[1], buffer.substring(b_offset+1, offset));
//				map.put(ids[2], buffer.substring(offset+1));
//			} else {
//				throw new Exception("E999");
//			}
//		} else {
//			throw new Exception("E999");
//		}
//
//		Map<String, String> params = new HashMap<String, String>();
//		params.put("primitive","COMMON_COMMON_USERINFO");
//		params.put("appId", App.m_AppID);
//		params.put("encPwd",map.get(ID_ENC_PWD)); // 인코딩 문제시 URLEncoder.encode() 함수 삭제
//		params.put("mdn",mdn);
//		params.put("authKey",map.get(ID_AUTH_KEY));  // 인코딩 문제시 URLEncoder.encode() 함수 삭제
//		params.put("appVer",appVer);
//		params.put("companyCd",map.get(ID_COMPANY_CD));
//		
//		CommonLog.e("getGMPAuthPwd", "ids[ID_AUTH_KEY] : " + map.get(ID_AUTH_KEY));
//		CommonLog.e("getGMPAuthPwd", "ids[ID_COMPANY_CD] : " + map.get(ID_COMPANY_CD));
//		CommonLog.e("getGMPAuthPwd", "ids[ID_ENC_PWD] : " + map.get(ID_ENC_PWD));
//		
//		CommonLog.e("getGMPAuthPwd", "WebService Start");
//		WebService webService=new WebService(WebServiceAd); // 웹 서비스 주소와 연결
//		String response[]=webService.webGet("", params);
//		CommonLog.e("getGMPAuthPwd", "WebService end");
//		
//		map.put("result_code",response[0]);
//		map.put("result_user_num",response[1]);
//		
//		Log.e("ty","response0 = " + response[0]+" **** response1 = " + response[1]);
//		
//		return map;
//	}
	
	/**
	*  서비스 요청에 필요한 authKey를 얻는다. 
	*/
	public static String getGMPAuthKey(Context context, String mdn,	String appId) throws Exception {
		ContentValues values = new ContentValues();
		values.put("MDN", mdn);
		values.put("APPID", appId);

		ContentResolver cr = context.getContentResolver();
		Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/GMP_AUTH"), values);
		List<String> authValues = uri.getPathSegments();

		String[] gmpAuth = null;
		String buffer = authValues.get(2);
		gmpAuth = buffer.split("\\|");

		return gmpAuth[0];
	}
	
	/**
	* 인증된 계정의 회사코드를 얻는다.
	*/
	public static String getCheckedCompanyCd(Context context) throws Exception {
		ContentResolver cr = context.getContentResolver();
		Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/CHECKED_COMPANY_CD"), new ContentValues());
		List<String> authValues = uri.getPathSegments();

		return authValues.get(2);
	}
	
	/**
	 * 로그인여부를 체크한다	 
	 */
	public static boolean isLogin(Activity activity, String mdn, String appID){		
		try{			
			ContentValues values = new ContentValues();
			values.put(ID_MDN, getMDN(activity));
			values.put(ID_APP_ID, appID);

			ContentResolver cr = ((Context)activity).getContentResolver();
			Uri uri = cr.insert(Uri.parse("content://" + m_strPeAuth +".auth/GMP_AUTH_PWD"), values);
			List<String> authValues = uri.getPathSegments();
			String returnId = authValues.get(1);

			if ("E001".equals(returnId)) {
				return false;
			} else if ("E002".equals(returnId)) {
				return false;
			} else if ("E007".equals(returnId)) {
				return false;
			} else if ("E008".equals(returnId)) {
				return false;
			}
		}catch(Exception e){
			return false;
		}	
		
		return true;
	}
	
	private static boolean checkCoreApplication(Activity activity)
	{
		String packageString[] = {m_strPeAuth +".activity.mobileclient", "com.sk.pe.resource", m_strPeAuth +".provider"};
		
		String AppidString[] = {"Z0000PE002","Z000S00002","Z0000PE001"};
		List<String> appIdList = new ArrayList<String>();
		
		PackageManager pm = activity.getPackageManager();
		
		//if(WebServiceAd.equals("https://m.toktok.sk.com:9000/service.pe"))
		//{
			for(int i=0 ; i<3 ; i++){ // 필수 어플 설치 여부 판단 및 설치 되지 않은 어플 어플 아이디로 List에 저장
				try {
					pm.getApplicationInfo(packageString[i],PackageManager.GET_META_DATA); // 어플체크
				} catch (NameNotFoundException e) {
					// TODO Auto-generated catch block
					CommonLog.e(AuthUtil.class, packageString[i]+"= "+packageString[i]);
					appIdList.add(AppidString[i]); // 필수 어플이 없을 경우 List에 해당 어플 아이디 추가
				}
			}
		//}
		
		return installCorePush(activity, appIdList); //필수 어플이 설치 되지 않은 리스트를 사용하여 다이얼로그 생성	
	}
	
	private static CommonPopup m_popupCoreApp = null;
	private static Context m_Context = null;
	
	private static boolean installCorePush(final Context context, List<String> appIdList) {
		String message;
		String appName = "";
		final List<String> apps = appIdList;
		
		if (apps.size() == 1) {
			appName = getAppName(context, apps.get(0));
		} else {
			for (int i = 0; i < apps.size(); i++) {
				if(i==0){
					appName += getAppName(context, apps.get(i));
				}else{
					appName += ", " + getAppName(context, apps.get(i));	
				}				
			}
		}
		
		if(appIdList.contains("Z0000PE002") || appIdList.contains("Z0000PE001") || appIdList.contains("Z000S00002") ){ // 스토어 어플이 없을 경우 다이얼로그 생성
			m_Context = context;
			message = appName +" "+ context.getResources().getString(R.string.checkcoreapp_notfoundmsg); //_E034_WEB 가 없습니다. (스트링값 변경 시켜주세요)
			
			m_popupCoreApp = new CommonPopup(context, new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					m_popupCoreApp.cancel();
					Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					m_Context.startActivity(intent);
					((Activity)m_Context).finish();
					MyApp App = MyApp.getInstance();
					App.allActivityDestroy();
				}
			}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
			m_popupCoreApp.setBodyAndTitleText(context.getString(R.string.pop_error_title), message);
			m_popupCoreApp.setCancelable(false);
			m_popupCoreApp.show();
			
			return false;
		}
		/*else if(appIdList.contains("Z0000PE001") || appIdList.contains("Z000S00002") ){ // 단말공통 리소스, 인증 어플이 없을 경우 다이얼 로그 생성
			m_Context = context;
			message = appName +" "+ context.getResources().getString(R.string.checkcoreapp_notfoundmsg); //_E034 가 없습니다. (스트링값 변경 시켜주세요)
			m_popupCoreApp = new CommonPopup(context, new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					m_popupCoreApp.cancel();
					Intent intent = new Intent();
					intent.setComponent(new ComponentName(m_strPeAuth +".activity.mobileclient", m_strPeAuth +".activity.mobileclient.CoreAppListActivity"));
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					m_Context.startActivity(intent);
					((Activity)m_Context).finish();
					MyApp App = MyApp.getInstance();
					App.allActivityDestroy();
				}
			}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
			m_popupCoreApp.setBodyAndTitleText(context.getString(R.string.pop_error_title), message);
			m_popupCoreApp.setCancelable(false);
			m_popupCoreApp.show();
			return false;
		}*/
		
		return true;
	}
	
	private static String getAppName(Context context, String appId){
		String name = "";		
		if(appId.equals("Z0000PE001")){
			name = context.getResources().getString(R.string.checkcoreapp_auth); //인증 어플 (스트링값 변경 시켜주세요)
		}else if(appId.equals("Z0000PE002")){
			name = context.getResources().getString(R.string.checkcoreapp_store); //스토어 어플 (스트링값 변경 시켜주세요)
		}else if(appId.equals("Z000S00002")){
			name = context.getResources().getString(R.string.checkcoreapp_resource); // 단말 공통 어플 (스트링값 변경 시켜주세요)
		}
		return name;

	}

	public static String getMDN(Context context) throws Exception {

		String mdn = "";

		//if (getDeviceType().equals("Phone")) { // Android Phone일 경우

			ContentResolver cr = context.getContentResolver();
			Uri uri = cr.insert(Uri.parse("content://com.skt.pe.auth/MDNCHK"), new ContentValues());
			List<String> authValues = uri.getPathSegments();
			if(authValues.size() > 0){
				mdn = authValues.get(2);
			}else{
				TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
				String number = tm.getLine1Number();
				mdn = number;
			}
			MyApp App = MyApp.getInstance();
			App.m_Mdn = mdn;
		/*}else{ // Android Tablet일 경우

			ContentResolver cr = context.getContentResolver();
			Uri uri = cr.insert(Uri.parse("content://com.sk.pe.group.auth/MACADDR"), new ContentValues());
			List<String> authValues = uri.getPathSegments();

			if(authValues.size() > 0){
				mdn = authValues.get(2).toUpperCase();
			} else {
				List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());

				for (NetworkInterface nif : all) {
					if (!nif.getName().equalsIgnoreCase("wlan0")) continue;

					byte[] macBytes = nif.getHardwareAddress();

					if (macBytes == null) {
						mdn = "";
					}

					StringBuilder res1 = new StringBuilder();

					for (byte b : macBytes) {
						res1.append(Integer.toHexString(b & 0xFF) + ":");
					}

					if (res1.length() > 0) {
						res1.deleteCharAt(res1.length() - 1);
					}

					mdn = res1.toString();
				}
			}

		}*/

		return mdn;

	}

}
