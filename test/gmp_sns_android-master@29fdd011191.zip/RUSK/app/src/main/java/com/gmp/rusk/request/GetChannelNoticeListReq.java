package com.gmp.rusk.request;


import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

/**
 *	@author kch
 *			모임 공지 목록 조회
 *			method : get
 */

public class GetChannelNoticeListReq extends Req{

	private String APINAME = "notice-channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";

	public GetChannelNoticeListReq(int a_nChannelNo)
	{
		APINAME = APINAME + "/" + a_nChannelNo + "/" + "thread";
	}

	public GetChannelNoticeListReq(int a_nChannelNo,String a_strKeyword)
	{
		try {
			a_strKeyword = URLEncoder.encode(a_strKeyword,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		APINAME = APINAME + "/" + a_nChannelNo + "/search/" + "?keyword=" + a_strKeyword;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		/*if(m_strSearchKeyword !=null) {
			try {
				JSONObject jsonObj = new JSONObject();
				if (m_strSearchKeyword != null)
					jsonObj.put(JSON_KEYWORD, m_strSearchKeyword);
				return jsonObj.toString();
			} catch (Exception e) {
				CommonLog.e(GetChannelNoticeListReq.class.getSimpleName(), "" + e.getMessage());
				return "";
			}
		} else*/
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
