package com.gmp.rusk.layout;


import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


/**
 * ChatRoomSystemLayout
 * 채팅방 시스템 메세지 List Item Layout
 */
public class ChatRoomSystemLayout extends CustomLinearLayout{

	public ChatRoomSystemLayout(Context context) {
		super(context);
		init();		
	}

	private void init() 
	{
		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(
				m_strInfService);
		li.inflate(R.layout.layout_chat_room_sysmsg, this, true);	
	}

	public void setChatRoomData(ChatRoomData a_Data)
	{
		TextView tvSystemMSG = (TextView)findViewById(R.id.tv_chat_systemmsg);
		RelativeLayout layoutSysMSGDay = (RelativeLayout)findViewById(R.id.layout_chat_systemmsg_day);
		TextView tvSystemMSGDay = (TextView)findViewById(R.id.tv_chat_systemmsg_day);
		if(a_Data.m_strRoomID.split("_").length == 3){
			tvSystemMSG.setBackgroundColor(Color.parseColor("#daece5"));
			tvSystemMSGDay.setBackgroundColor(Color.parseColor("#daece5"));
		}
		if(a_Data.m_nType == StaticString.CHAT_ROOM_SYSTEM_MSG){
			tvSystemMSG.setVisibility(View.VISIBLE);
			layoutSysMSGDay.setVisibility(GONE);
			tvSystemMSGDay.setVisibility(View.GONE);
			tvSystemMSG.setText(a_Data.m_strSystemMSG);
		} else if(a_Data.m_nType == StaticString.CHAT_ROOM_SYSTEM_MSG_DAY){
			tvSystemMSG.setVisibility(View.GONE);
			layoutSysMSGDay.setVisibility(VISIBLE);
			tvSystemMSGDay.setVisibility(View.VISIBLE);
			tvSystemMSGDay.setText(a_Data.m_strSystemMSG);
		}
	}
}
