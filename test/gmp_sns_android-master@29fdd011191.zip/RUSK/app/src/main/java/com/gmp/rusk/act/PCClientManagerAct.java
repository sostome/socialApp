package com.gmp.rusk.act;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetPCClientReq;
import com.gmp.rusk.response.GetPCClientRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

public class PCClientManagerAct extends CustomActivity implements OnClickListener{
	
	private final int REQUESTCODE_PCCLIENTSTOP = 20001;

	private final String PCCLIENT_PARTNER_URL = "https://cork.toktok.sk.com";
	private final String PCCLIENT_REGULAR_URL = "https://cork.toktok.sk.com";
	private final String PCCLIENT_DEV_PARTNER_URL = "https://devcork.toktok.sk.com";
	private final String PCCLIENT_DEV_REGULAR_URL = "https://devcork.toktok.sk.com";

	private final String PCCLIENT_PORT = ":8443";
	private final String PCCLIENT_VARIANT_R = "/r_pc";
	private final String PCCLIENT_VARIANT = "/pc";

	private String m_strHostName = "";
	private String m_strDeviceUID = "";
	
	private ProgressDlg m_Progress = null;

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_set_pcclientmanager);
		
		initUI();
		
		getPCClient();
	}
	
	private void initUI()
	{
		ImageView ivClose = (ImageView)findViewById(R.id.btn_cancel);
		ivClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		LinearLayout layoutPCClientActive = (LinearLayout)findViewById(R.id.layout_pcclientmanager_pcclientactive);
		LinearLayout layoutPCClientChangeDevice = (LinearLayout)findViewById(R.id.layout_pcclientmanager_pcclientchangedevice);
		LinearLayout layoutPCClientStop = (LinearLayout)findViewById(R.id.layout_pcclientmanager_pcclientstop);
		TextView tvPCClientText = (TextView)findViewById(R.id.tv_pcclientmanager_url);

		if(AppSetting.USING_SERVER.equals(AppSetting.APISERVER_LIST.DEV_SERVER)){
			if (AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)) {
				tvPCClientText.setText(PCCLIENT_DEV_PARTNER_URL + PCCLIENT_PORT + PCCLIENT_VARIANT_R);
			} else {
				tvPCClientText.setText(PCCLIENT_DEV_REGULAR_URL + PCCLIENT_PORT + PCCLIENT_VARIANT);
			}
		} else {
			if (AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)) {
				tvPCClientText.setText(PCCLIENT_PARTNER_URL + PCCLIENT_PORT + PCCLIENT_VARIANT_R);
			} else {
				tvPCClientText.setText(PCCLIENT_REGULAR_URL + PCCLIENT_PORT + PCCLIENT_VARIANT);
			}
		}
		
		layoutPCClientActive.setOnClickListener(this);
		layoutPCClientChangeDevice.setOnClickListener(this);
		layoutPCClientStop.setOnClickListener(this);
		
		layoutPCClientActive.setVisibility(View.GONE);
		layoutPCClientChangeDevice.setVisibility(View.GONE);
		layoutPCClientStop.setVisibility(View.GONE);
	}
	
	private void setUI()
	{
		LinearLayout layoutPCClientActive = (LinearLayout)findViewById(R.id.layout_pcclientmanager_pcclientactive);
		LinearLayout layoutPCClientChangeDevice = (LinearLayout)findViewById(R.id.layout_pcclientmanager_pcclientchangedevice);
		LinearLayout layoutPCClientStop = (LinearLayout)findViewById(R.id.layout_pcclientmanager_pcclientstop);
		
		if(m_strHostName.equals("") || m_strDeviceUID.equals(""))
		{
			layoutPCClientActive.setVisibility(View.VISIBLE);
			layoutPCClientChangeDevice.setVisibility(View.GONE);
			layoutPCClientStop.setVisibility(View.GONE);
		}
		else
		{
			layoutPCClientActive.setVisibility(View.GONE);
			layoutPCClientChangeDevice.setVisibility(View.VISIBLE);
			layoutPCClientStop.setVisibility(View.VISIBLE);
		}
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.layout_pcclientmanager_pcclientactive)
		{
			clickPCClientActive();
		}
		else if(nId == R.id.layout_pcclientmanager_pcclientchangedevice)
		{
			clickPCClientChangeDevice();
		}
		else if(nId == R.id.layout_pcclientmanager_pcclientstop)
		{
			clickPCClientStop();
		}
		super.onClick(v);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == REQUESTCODE_PCCLIENTSTOP)
		{
			if(resultCode == RESULT_OK)
			{
				m_strHostName = "";
				m_strDeviceUID = "";
				setUI();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private void clickPCClientActive()
	{
		Intent intent = new Intent(this, PCClientAuthAct.class);
		startActivity(intent);
	}
	
	private void clickPCClientChangeDevice()
	{
		Intent intent = new Intent(this, PCClientAuthAct.class);
		startActivity(intent);
	}
	
	private void clickPCClientStop()
	{
		Intent intent = new Intent(this, PCClientStopAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_PCCLIENTSTOP_HOSTNAME, m_strHostName);
		intent.putExtra(IntentKeyString.INTENT_KEY_PCCLIENTSTOP_DEVICEUID, m_strDeviceUID);
		startActivityForResult(intent, REQUESTCODE_PCCLIENTSTOP);
	}
	
	private void getPCClient()
	{
		GetPCClientReq req = new GetPCClientReq();
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e(PCClientManagerAct.class.getSimpleName(), "Res Data : " + a_strData);
				GetPCClientRes res = new GetPCClientRes(a_strData);
				m_strHostName = res.getHostName();
				m_strDeviceUID = res.getDeviceUID();
				setUI();
				closeProgress();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
			}
		});
	}
	
	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
