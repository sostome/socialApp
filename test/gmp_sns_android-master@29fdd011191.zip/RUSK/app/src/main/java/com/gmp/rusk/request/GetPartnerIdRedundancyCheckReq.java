package com.gmp.rusk.request;

/**
 *	@author subi78
 *			파트너 아이디 중복 체크 
 *			method : get
 */

public class GetPartnerIdRedundancyCheckReq extends Req{
	
	private String APINAME = "partner";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "GET";
	
	
	public GetPartnerIdRedundancyCheckReq(String a_strUserId)
	{
		APINAME = APINAME +"/usable-user-id/"+a_strUserId;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
