package com.gmp.rusk.request;

import org.apache.http.entity.mime.MultipartEntity;

abstract public class UploadReq extends Req{
	
	abstract public MultipartEntity getMultiPartEntity();

	@Override
	public String getAPIName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getMethod() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

}
