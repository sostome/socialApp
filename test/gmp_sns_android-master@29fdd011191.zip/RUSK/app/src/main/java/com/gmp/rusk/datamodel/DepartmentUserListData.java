package com.gmp.rusk.datamodel;

public class DepartmentUserListData {
	public int m_nUserNo = 0;						//사용자 번호
	public String m_strUserType = "";				//사용자 유형 R:정직원 P:파트너
	public String m_strName = "";					//이름
	public String m_strEmail = "";				//이메일
	public String m_strMobile = "";				//전화번호
	public String m_strCompanyCode = "";
	public String m_strCompanyName = "";
	public String m_strDepartment = "";				//부서
	public String m_strDepartmentCode = "";
	public String m_strParentDepartment = "";					//소속
	public String m_strCharge = "";					//직책
	public String m_strPosition = "";					//지위
	public String m_strSecondCharge = "";			//겸직 직책
	public String m_strCompany = "";				//소속 회사명
	public String m_strAffiliation = "";
	public boolean m_isImageAvailable = false;		//이미지 보유 여부
	public String m_strGreeting ="";
	public boolean m_isAvailable = false;				//사용자 앱 설치 유무
	public String m_strStatus = "";
	public String m_strFellowAddTime = "";				//동료 추가 시간
	public boolean m_isChecked = false;

	public String m_strSecondDepartment = "";
	public String m_strSecondParentDepartment = "";

	public DepartmentUserListData(UserInfoData data){
		m_nUserNo = data.m_nUserNo;
		m_strUserType = data.m_strUserType;
		m_strName = data.m_strName;
		m_strEmail = data.m_strEmail;
		m_strMobile = data.m_strMobile;
		m_strCompanyCode = data.m_strCompanyCode;
		m_strCompanyName = data.m_strCompanyName;
		m_strDepartment =	data.m_strDepartment;
		m_strDepartmentCode = data.m_strDepartmentCode;
		m_strParentDepartment = data.m_strParentDepartment;
		m_strCharge = data.m_strCharge;
		m_strPosition = data.m_strPosition;
		m_strSecondCharge = data.m_strSecondCharge;
		m_strCompany = data.m_strCompany;
		m_strAffiliation = data.m_strAffiliation;
		m_isImageAvailable = data.m_isImageAvailable;
		m_strGreeting = data.m_strGreeting;
		m_isAvailable = data.m_isAvailable;
		m_strStatus = data.m_strStatus;
		m_strFellowAddTime = data.m_strFellowAddTime;
		m_isChecked = data.m_isChecked;
	}
	/*public DepartmentUserListData(int a_nUserNo, String a_strName, String a_strCharge, String a_strDepartment, String a_strParentDepartment, boolean a_isImageAvailable, boolean a_isAvailable) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCharge = a_strCharge;
		m_strDepartment = a_strDepartment;
		m_strParentDepartment = a_strParentDepartment;
		m_isImageAvailable = a_isImageAvailable;
		m_isAvailable = a_isAvailable;
	}*/
	
	public int getUserNo(){
		return m_nUserNo;
	}
	
	public String getName(){
		return m_strName;
	}
	
	public String getCharge(){
		return m_strCharge;
	}
	
	public String getDepartment(){
		return m_strDepartment;
	}
	
	public String getParentDepartment(){
		return m_strParentDepartment;
	}
	
	public boolean getImageAvailable(){
		return m_isImageAvailable;
	}
	
	public boolean getAvailable(){
		return m_isAvailable;
	}
}
