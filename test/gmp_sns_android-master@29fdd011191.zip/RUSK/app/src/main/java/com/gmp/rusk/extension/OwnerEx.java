package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class OwnerEx implements PacketExtension {
	public static final String NAMESPACE = "urn:xmpp:groupchat:owner";
	public static final String ELEMENT_NAME = "info";

	private String user;

	public OwnerEx() {
	}

	public OwnerEx(String user) {
		this.user = user;
	}

	//
	//
	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return ELEMENT_NAME;
	}

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return NAMESPACE;
	}


	public String getUser() {
		return user;
	}

	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		StringBuilder buf = new StringBuilder();
		// 1.5.5 에서 규격 수정됨

		buf.append("<Ownerid='").append(user).append("'/>");
		return buf.toString();
	}

	public static class Provider implements PacketExtensionProvider {

		public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
			//ArrayList<String> users = new ArrayList<String>();
			String user = null;
			boolean done = false;
			while (!done) {
				int eventType = parser.getEventType();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("user")) {						
							user = parser.nextText();
				}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals(ELEMENT_NAME)) {
						done = true;
					}
				}
				if (!done)
					parser.next();
			}
			return new OwnerEx(user);
		}
	}
}