package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelCommentData;
import com.gmp.rusk.datamodel.ChannelFileData;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface ChannelFileResObject {

    public final String JSON_FILENO = "fileNo";
    public final String JSON_TYPE = "type";
    public final String JSON_URL = "url";
    public final String JSON_PREVIEWURL = "previewUrl";
    public final String JSON_WIDEPREVIEWURL = "widePreviewUrl";
    public final String JSON_FILENAME = "fileName";
    public final String JSON_FILESIZE = "fileSize";
    public final String JSON_IMAGECOUNT = "imageCount";
    public final String JSON_MOVIEFILECOUNT = "movieFileCount";
    public final String JSON_NORMALFILECOUNT = "normalFileCount";


    public void parseChannelFileData();
    public void parseChannelFileListData();
    public ArrayList<ChannelFileData> getChannelFileListData();
    public ChannelFileData getChannelFileData();
    public int getChannelImageCount();
    public int getChannelMovieFileCount();
    public int getChannelNormalFileCount();
}
