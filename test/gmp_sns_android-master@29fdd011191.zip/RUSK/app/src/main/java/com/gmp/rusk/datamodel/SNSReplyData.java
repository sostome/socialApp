package com.gmp.rusk.datamodel;

public class SNSReplyData {
	
	public int m_nReplyNo = -1;
	public int m_nUserNo = -1;
	public String m_strUserName = "";
	public String m_strCompanyOrDepartment = "";
	public String m_strUserImageUrl = "";
	public String m_strUserType = "";
	public String m_strReplyComment = "";
	public String m_strCreatedDate = "";
	public String m_strFileUrl = "";
	public String m_strPreviewFileUrl = "";

}
