package com.gmp.rusk.fragment;

import java.util.ArrayList;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.act.SNSGroupMemberListAct;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SNSGroupInvitedMemberListFrag extends Fragment implements OnItemClickListener{

	public MyApp App = MyApp.getInstance();
	private View m_vList = null;
	private ArrayList<SNSGroupMemberData> m_arrInvitedMember = null;
	private InvitedMemberListAdapter m_adapterInvitedMember = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		m_vList = inflater.inflate(R.layout.fragact_snsgroupmemberlist_member, container, false);
		getInvitedMember();
		initUI();
		return m_vList;
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == StaticString.REQUESTCODE_PROFILEVIEW)
		{
			if(resultCode == StaticString.RESULT_PROFILE_NOTIFYCHANGE_IMAGE)
			{
				if(m_adapterInvitedMember != null)
					m_adapterInvitedMember.notifyDataSetChanged();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private void getInvitedMember()
	{
		m_arrInvitedMember = ((SNSGroupMemberListAct) getActivity()).getInvitedMember();
	}
	
	private void initUI()
	{
		TextView tvSection = (TextView)m_vList.findViewById(R.id.tv_snsgroupmemberlist_section);
		int nCount = m_arrInvitedMember == null ? 0 : m_arrInvitedMember.size();
		SNSGroupMemberData tempData = null;
		for(SNSGroupMemberData data : m_arrInvitedMember){
			if(data.m_isOwner) {
				tempData = data;
				m_arrInvitedMember.remove(data);
				m_arrInvitedMember.add(0,tempData);
				break;
			}
		}
		tvSection.setText(String.format(getString(R.string.snsgroupmemberlist_invitedmember_countformat), nCount));
		ListView lvInvitedMemberList = (ListView)m_vList.findViewById(R.id.lv_snsgroupmemberlist_memberlist);
		if(m_adapterInvitedMember == null)
			m_adapterInvitedMember = new InvitedMemberListAdapter();
		
		lvInvitedMemberList.setAdapter(m_adapterInvitedMember);
		lvInvitedMemberList.setOnItemClickListener(this);
	}
	
	private void doShowProfile(int a_nUserNo)
	{
		Intent intent = new Intent(getActivity(), ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, a_nUserNo);
		startActivityForResult(intent, StaticString.REQUESTCODE_PROFILEVIEW);
	}
	
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		
		SNSGroupMemberData data = m_arrInvitedMember.get(position);
		doShowProfile(data.m_nUserNo);
	}
	
	private class InvitedMemberListAdapter extends BaseAdapter
	{
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if(m_arrInvitedMember == null)
				return 0;
			else
				return m_arrInvitedMember.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if(m_arrInvitedMember == null || m_arrInvitedMember.size() == 0)
				return null;
			else
				return m_arrInvitedMember.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if(convertView == null)
			{
				LayoutInflater li = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = li.inflate(R.layout.layout_snsgroupmemberlist_listitem_member, parent, false);
			}
			
			SNSGroupMemberData data = m_arrInvitedMember.get(position);
			
			ImageView ivPic = (ImageView)convertView.findViewById(R.id.iv_snsgroupmemberlist_listitem_member_pic);
			ImageView ivPicNotFellow = (ImageView)convertView.findViewById(R.id.iv_snsgroupmemberlist_listitem_member_pic_notfellow);
			ImageView ivIconBangJang = (ImageView)convertView.findViewById(R.id.iv_snsgroupmemberlist_listitem_member_bangjang);
			TextView tvName = (TextView)convertView.findViewById(R.id.tv_snsgroupmemberlist_listitem_member_name);
			ImageView ivPartnerIcon = (ImageView) convertView.findViewById(R.id.iv_chatlist_icon_partner);

			//ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(getActivity());
			//imageLoaderMng.getProfileImage(ivPic, data.m_strUserImageUrl, R.drawable.profile_pic_default, false);
			App.imageloader.cancelDownload(ivPic);
			App.imageloader.getProfileImage(ivPic, App.getImageDownLoaderUrl(data.m_nUserNo, false), R.drawable.profile_pic_default, false);
			UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(getContext(), data.m_nUserNo);
			tvName.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
			if(data.m_isOwner)
				ivIconBangJang.setVisibility(View.VISIBLE);
			else
				ivIconBangJang.setVisibility(View.GONE);

			if(userData.m_strUserType.equals(StaticString.VARIANT_REGULAR))
				ivPartnerIcon.setVisibility(View.GONE);
			else
				ivPartnerIcon.setVisibility(View.VISIBLE);
			LinearLayout layout_position = (LinearLayout) convertView.findViewById(R.id.layout_position);
			TextView tv_position = (TextView) convertView.findViewById(R.id.tv_position);
			LinearLayout layout_charge = (LinearLayout) convertView.findViewById(R.id.layout_charge);
			TextView tv_charge = (TextView) convertView.findViewById(R.id.tv_charge);
			TextView tv_uninstall = (TextView) convertView.findViewById(R.id.tv_uninstall);
			if(userData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && userData.m_PersonalData.mapPersonalData.get(PersonalData.POSITION) !=null && !userData.m_PersonalData.mapPersonalData.get(PersonalData.POSITION).equals("")){
				layout_position.setVisibility(View.VISIBLE);
				tv_position.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.POSITION));
			} else {
				layout_position.setVisibility(View.GONE);
			}

			if(userData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && userData.m_PersonalData.mapPersonalData.get(PersonalData.CHARGE)!=null && !userData.m_PersonalData.mapPersonalData.get(PersonalData.CHARGE).equals("")){
				layout_charge.setVisibility(View.VISIBLE);
				tv_charge.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.CHARGE));
			} else {
				layout_charge.setVisibility(View.GONE);
			}

			if (userData.m_isActive) {
				tv_uninstall.setVisibility(View.GONE);
			} else {
				tv_uninstall.setVisibility(View.VISIBLE);
			}

			TextView tv_departments = (TextView) convertView.findViewById(R.id.tv_snsgroupmemberlist_listitem_member_departments);


			if (userData.m_strUserType.equals("R")) {
				tv_departments.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.DEPARTMENT)+" | "+userData.m_PersonalData.mapPersonalData.get(PersonalData.COMPANY_NAME));
			} else {
				tv_departments.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.AFFILIATION));
			}
			ivPicNotFellow.setVisibility(View.GONE);

			RelativeLayout layoutButton = (RelativeLayout)convertView.findViewById(R.id.layout_snsgroupmemberlist_listitem_member_btn);
			layoutButton.setVisibility(View.GONE);
			
			return convertView;
		}
		
	}
}
