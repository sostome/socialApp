package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelThreadData;

import java.util.ArrayList;

public class GetChannelNoticeListRes extends ChannelRes{


	public GetChannelNoticeListRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}


}
