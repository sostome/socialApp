package com.gmp.rusk.response;

public class GetGroupFileRes extends ChannelRes{


	public GetGroupFileRes(String a_strData , String a_strType) {
		super(a_strData, a_strType);
		// TODO Auto-generated constructor stub

	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}

}