package com.gmp.rusk.act;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore.Images;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.customview.TouchImageView;
import com.gmp.rusk.filedownload.FileDownload;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.layout.ChatRoomMyFileLayout;
import com.gmp.rusk.takemedia.FileUtil;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

public class ChatRoomImageAct extends CustomActivity{
	Bundle bundle;
	String m_strDownloadPath, m_strDownloadRoomID, m_strDownloadMsgID;
//	GestureImageView m_ivLargeImage; 
	TouchImageView m_ivLargeImage;
	RelativeLayout m_layoutTitle;
	ImageView m_ivLoading;
	Button m_ibDownloadButton;
	CommonPopup m_Popup;

	private RotateAnimation m_animProgress = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		if (Build.VERSION.SDK_INT < 16) {
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
					WindowManager.LayoutParams.FLAG_FULLSCREEN);
		} else {
			View decorView = getWindow().getDecorView();
			int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
			decorView.setSystemUiVisibility(uiOptions);
		}

		setContentView(R.layout.act_chatroom_image);

		ImageView ivBack = (ImageView)findViewById(R.id.iv_chat_back);
		ivBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		m_ivLargeImage = (TouchImageView) findViewById(R.id.iv_chatroom_largeimage);
		m_layoutTitle = (RelativeLayout)findViewById(R.id.layout_imageviewtitle);
		m_ibDownloadButton = (Button) findViewById(R.id.ib_save_largeimage);
		m_ibDownloadButton.setVisibility(View.VISIBLE);
		m_ivLoading = (ImageView) findViewById(R.id.iv_chatroom_image_loading);
		bundle = getIntent().getExtras();
		if (bundle != null) {
			m_strDownloadPath = bundle.getString(IntentKeyString.INTENT_KEY_DOWNLOAD_IMAGE_PATH);
			m_strDownloadRoomID = bundle.getString(IntentKeyString.INTENT_KEY_DOWNLOAD_ROOM_ID);
			m_strDownloadMsgID = bundle.getString(IntentKeyString.INTENT_KEY_DOWNLOAD_MESSAGE_ID);
			super.m_strRoomID = m_strDownloadRoomID;
		}
		
		m_animProgress = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		m_animProgress.setInterpolator(new LinearInterpolator());
		m_animProgress.setRepeatCount(Animation.INFINITE);
		m_animProgress.setDuration(1000);
		
		init(m_strDownloadPath);

		m_ibDownloadButton.setOnClickListener(this);

	}

	
	
	private void init(final String a_strDownloadPath) {
		m_ivLoading.startAnimation(m_animProgress);
		ImageLoaderManager imageloader = ImageLoaderManager.getInstance(ChatRoomImageAct.this);
		Bitmap bitmap = imageloader.getLocalImage(a_strDownloadPath);
		if(bitmap == null)
			imageloader.getImage(m_ivLargeImage, a_strDownloadPath, 0, m_ImageLoaderListener);
		else
			m_ivLargeImage.setImageBitmap(bitmap);
		m_ivLargeImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if(m_layoutTitle.getVisibility() == View.VISIBLE)
					m_layoutTitle.setVisibility(View.INVISIBLE);
				else
					m_layoutTitle.setVisibility(View.VISIBLE);
			}
		});

	}
	
	ImageLoaderManager.ImageLoaderListener m_ImageLoaderListener = new ImageLoaderManager.ImageLoaderListener() {
		
		@Override
		public void onSuccess() {
			// TODO Auto-generated method stub
			m_animProgress.setRepeatCount(0);
			m_ivLoading.setVisibility(View.GONE);
		}
		
		@Override
		public void onFail(String a_strErrorMsg) {
			// TODO Auto-generated method stub
			m_animProgress.setRepeatCount(0);
			m_ivLoading.setVisibility(View.GONE);
			m_Popup = new CommonPopup(ChatRoomImageAct.this, ChatRoomImageAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			
			String strError;
			if(a_strErrorMsg == null)
				strError = getString(R.string.popup_fail_imagedownload_text);
			else 
				strError = a_strErrorMsg;
			
			m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_download_title), strError);
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
		
		@Override
		public void onNotModified() {
			// TODO Auto-generated method stub
			m_animProgress.setRepeatCount(0);
			m_ivLoading.setVisibility(View.GONE);
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		switch (v.getId()) {
		case R.id.ib_save_largeimage:

			if (FileUtil.getAvailableExternalMemorySize() < 10485760) {
				m_Popup = new CommonPopup(ChatRoomImageAct.this, ChatRoomImageAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_download_title), getString(R.string.popup_fail_download_text));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else if((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
					App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled){
				m_Popup = new CommonPopup(this, ChatRoomImageAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
			else {
				FileDownload fileDownload = new FileDownload(this, m_strDownloadRoomID, m_strDownloadMsgID, m_strDownloadPath);

				fileDownload.startDownload(new FileDownload.OnDownloadComplete() {

					@Override
					public void onDownloadFail() {
						// TODO Auto-generated method stub
						// 다운로드 실패 처리
					}

					@Override
					public void onComplete(String a_strFilePath) {
						// TODO Auto-generated method stub
						CommonLog.e(ChatRoomImageAct.this, "Result Path : " + a_strFilePath);
						ContentValues values = new ContentValues(); 
		            	values.put(Images.Media.TITLE, "TTalk"); 
		            	
		            	values.put(Images.Media.DISPLAY_NAME, "TTalk");
		                values.put(Images.Media.BUCKET_ID, "TTalk"); 
		                values.put(Images.Media.DESCRIPTION, "TTalk"); 
		                values.put(Images.Media.MIME_TYPE, "image/jpeg"); 
		                values.put(Images.Media.DATA, a_strFilePath);
		                getContentResolver().insert(Images.Media.EXTERNAL_CONTENT_URI, values);
					}

					@Override
					public void onProgess(int a_nCount, int a_nTotal) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onStart() {

					}
				});

				m_Popup = new CommonPopup(ChatRoomImageAct.this, ChatRoomImageAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_download_title), getString(R.string.popup_download_text));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			break;

		case R.id.ib_pop_ok_long:
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			break;
		}
		default:
			break;
		}

	}

	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
