package com.gmp.rusk.act;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.Utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.parameter.EmailType;
import ezvcard.parameter.TelephoneType;
import ezvcard.property.Email;
import ezvcard.property.Telephone;

public class ContactPreviewAct extends CustomActivity implements OnClickListener{
	
	private String m_strName = "";
	private String m_strLookupKey = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.act_contactpreview);
		
		checkIntent();
		
		initUI();
		setUI();
	}
	
	private void checkIntent()
	{
		m_strName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_NAME);
		m_strLookupKey = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_LOOKUPKEY);
	}
	
	private void initUI()
	{
		ImageView btnSend = (ImageView)findViewById(R.id.btn_send);
		ImageView ivBack = (ImageView)findViewById(R.id.iv_back);
		btnSend.setOnClickListener(this);
		ivBack.setOnClickListener(this);
	}
	
	private void setUI()
	{
		TextView tvName = (TextView)findViewById(R.id.tv_contactpreview_name);
		tvName.setText(m_strName);
		
		Uri uriLookupKey = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, m_strLookupKey);
		AssetFileDescriptor fd;
		String strVCard = null;
		try {
			fd = getContentResolver().openAssetFileDescriptor(uriLookupKey, "r");
			FileInputStream fis = fd.createInputStream();
			byte[] b = new byte[(int) fd.getDeclaredLength()];
			fis.read(b);
			strVCard = new String(b);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		LinearLayout layoutTelePhone = (LinearLayout)findViewById(R.id.layout_contactpreview_telephone);
		LinearLayout layoutEmail = (LinearLayout)findViewById(R.id.layout_contactpreview_email);
		
		if(strVCard != null && !strVCard.equals(""))
		{
			VCard vcard = Ezvcard.parse(strVCard).first();
			List<Telephone> arrTele = vcard.getTelephoneNumbers();
			if(arrTele != null && arrTele.size() > 0)
			{
				LayoutInflater li = getLayoutInflater();
				View vLastSepa = null;
				layoutTelePhone.setVisibility(View.VISIBLE);
				for(Telephone tele : arrTele)
				{
					String strCall = "";
					String strType = getString(R.string.contactpreview_telephone_etc);
					Iterator<TelephoneType> iter = tele.getTypes().iterator();
				    while (iter.hasNext()) {
				    	TelephoneType type = iter.next();
				    	CommonLog.e(ContactPreviewAct.class.getSimpleName(), "type : " + type.getValue());
				    	if(type == TelephoneType.CELL)
				    	{
				    		strType = getString(R.string.contactpreview_telephone_cell);
				    		break;
				    	}
				    	else if(type == TelephoneType.HOME)
				    	{
				    		strType = getString(R.string.contactpreview_telephone_home);
				    		break;
				    	}
				    	else if(type == TelephoneType.WORK)
				    	{
				    		strType = getString(R.string.contactpreview_telephone_work);
				    		break;
				    	}
				    	else
				    	{
				    		strType = getString(R.string.contactpreview_telephone_etc);
				    		break;
				    	}
				    }
				    strCall = tele.getText().replace("-", "");
				    strCall = Utils.getPhoneNumberWithHyphen(strCall);
				    LinearLayout layoutTelePhoneItem = (LinearLayout) li.inflate(R.layout.layout_contactpreview_item, layoutTelePhone, false);
				    View vSepa = li.inflate(R.layout.layout_contactpreview_sepa, layoutTelePhone, false);
				    vLastSepa = vSepa;
				    
				    TextView tvType = (TextView)layoutTelePhoneItem.findViewById(R.id.tv_contactpreview_type);
				    TextView tvValue = (TextView)layoutTelePhoneItem.findViewById(R.id.tv_contactpreview_value);
				    
				    tvType.setText(strType);
				    tvValue.setText(strCall);
				    
				    layoutTelePhone.addView(layoutTelePhoneItem);
				    layoutTelePhone.addView(vSepa);
				}
				
				if(vLastSepa != null)
				{
					layoutTelePhone.removeView(vLastSepa);
				}
			}
			else
			{
				layoutTelePhone.setVisibility(View.GONE);
			}
			
			List<Email> arrEmail = vcard.getEmails();
			if(arrEmail != null && arrEmail.size() > 0)
			{
				LayoutInflater li = getLayoutInflater();
				View vLastSepa = null;
				layoutEmail.setVisibility(View.VISIBLE);
				for(Email email : arrEmail)
				{
					String strEmail = "";
					String strType = getString(R.string.contactpreview_email_etc);
					
					Iterator<EmailType> iter = email.getTypes().iterator();
					while (iter.hasNext()) {
						EmailType type = iter.next();
						if(type == EmailType.INTERNET)
							continue;
						
						if(type == EmailType.HOME)
						{
				    		strType = getString(R.string.contactpreview_email_home);
				    		break;
						}
				    	else if(type == EmailType.WORK)
				    	{
				    		strType = getString(R.string.contactpreview_email_work);
				    		break;
				    	}
				    	else
				    	{
				    		strType = getString(R.string.contactpreview_email_etc);
				    		break;
				    	}
					}
					strEmail = email.getValue();
					
					LinearLayout layoutEmailItem = (LinearLayout) li.inflate(R.layout.layout_contactpreview_item, layoutEmail, false);
				    View vSepa = li.inflate(R.layout.layout_contactpreview_sepa, layoutEmail, false);
				    vLastSepa = vSepa;
				    
				    TextView tvType = (TextView)layoutEmailItem.findViewById(R.id.tv_contactpreview_type);
				    TextView tvValue = (TextView)layoutEmailItem.findViewById(R.id.tv_contactpreview_value);
				    
				    tvType.setText(strType);
				    tvValue.setText(strEmail);
				    
				    layoutEmail.addView(layoutEmailItem);
				    layoutEmail.addView(vSepa);
				}
				
				if(vLastSepa != null)
				{
					layoutTelePhone.removeView(vLastSepa);
				}
			}
			else
			{
				layoutEmail.setVisibility(View.GONE);
			}
		}
		else
		{
			layoutTelePhone.setVisibility(View.GONE);
			layoutEmail.setVisibility(View.GONE);
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		
		if(nId == R.id.btn_send)
		{
			Intent intent = new Intent();
			intent.putExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_NAME, m_strName);
			intent.putExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_LOOKUPKEY, m_strLookupKey);
			setResult(RESULT_OK, intent);
			finish();
		}
		else if(nId == R.id.iv_back)
		{
			setResult(RESULT_CANCELED);
			finish();
		}
	}
}
