package com.gmp.rusk.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.gmp.rusk.push.PushController;
import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

import m.client.push.library.PushManager;
import m.client.push.library.common.Logger;
import m.client.push.library.common.PushConstants;
import m.client.push.library.common.PushLog;

/**
 * MessageArrivedReceiver
 * 메세지 수신 처리를 위해 등록된 리시버
 */
public class MessageArrivedReceiver extends BroadcastReceiver {
	
	@Override   
	public void onReceive(Context context, Intent intent) {
		PushLog.d("onReceive", "[UPNSCallback] receive action");
		// UPNS 타입의 경우
		if (intent.getAction().equals(context.getPackageName() + PushConstants.ACTION_UPNS_MESSAGE_ARRIVED)) { 
			try {
				String jsonData = intent.getExtras().getString(PushConstants.KEY_JSON);
				JSONObject jsonMsg = new JSONObject(jsonData);
				String msgID = intent.getExtras().getString(PushConstants.KEY_UPNSMESSAGEID);

				String rawData = intent.getExtras().getString(PushConstants.KEY_ORIGINAL_PAYLOAD_STRING);
				byte[] rawDataBytes = intent.getExtras().getByteArray(PushConstants.KEY_ORIGINAL_PAYLOAD_BYTES);

				Logger.i("received raw data : " + rawData);
				Logger.i("received bytes data : " + new String(rawDataBytes, "utf-8"));

				PushController.recvPushMessage(context, jsonData);
				//PushLog.d("onReceive", "## received message: " + jsonData); // 수신 메세지 페이로드
				//PushLog.d("onReceive", "1. receive confirm msgIDForAck: " + msgID); // 수신 ACK를 위한 메세지 아이디
				//PushLog.d("onReceive", "2. received message SEQNO: " + jsonMsg.getString("SEQNO")); // 메세지 시퀀스 넘버
				//PushLog.d("onReceive", "3. received message MESSAGEID: " + jsonMsg.getString("MESSAGEID")); // UPNS 메세지 아이디
				//PushManager.getInstance().upnsMessageReceiveConfirm(context, msgID);
				//PushManager.getInstance().upnsSubscribe(context);
				
				/*// 노티피케이션 생성
				PushNotificationManager.createNotification(context, intent, PushConstants.STR_UPNS_PUSH_TYPE);
				
				// 화면 온/오프 상태 체크
				if (PushNotificationManager.isRestrictedScreen(context)) {
					// 팝업 다이얼로그 예제
					PushNotificationManager.showNotificationPopupDialog(context, intent, PushConstants.STR_UPNS_PUSH_TYPE);
				}
				else {
					// 토스트 발생
					PushNotificationManager.showToast(context, intent, PushConstants.STR_UPNS_PUSH_TYPE);
				}*/

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		// GCM 의 경우
		else if (intent.getAction().equals(context.getPackageName() + PushConstants.ACTION_GCM_MESSAGE_ARRIVED)) { 
			try {

				// 노티피케이션 생성
				//PushNotificationManager.createNotification(context, intent, PushConstants.STR_GCM_PUSH_TYPE);
				
				// 팝업 다이얼로그 예제
//				PushNotificationManager.showNotificationPopupDialog(context, intent, PushConstants.STR_GCM_PUSH_TYPE);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
