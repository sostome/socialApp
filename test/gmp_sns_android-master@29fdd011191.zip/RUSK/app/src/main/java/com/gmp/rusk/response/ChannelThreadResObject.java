package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.ChannelNoticeData;
import com.gmp.rusk.datamodel.ChannelThreadData;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface ChannelThreadResObject {

    public final String JSON_NOTICES = "notices";
    public final String JSON_THREADS = "threads";
    public final String JSON_THREADNO = "threadNo";
    public final String JSON_USERNO = "userNo";
    public final String JSON_BODY = "body";
    public final String JSON_NOTICE = "notice";
    public final String JSON_READ = "read";
    public final String JSON_CREATEDDATE = "createdDate";
    //public final String JSON_CREATEDATE = "createDate";
    public final String JSON_UPDATEDDATE = "updatedDate";
    public final String JSON_LIKECOUNT = "likeCount";
    public final String JSON_LIKED = "liked";
    public final String JSON_COMMENTCOUNT = "commentCount";
    public final String JSON_THREADTYPE = "threadType";
    public final String JSON_CREATETYPE = "createType";
    public final String JSON_FILES = "files";

    public final String JSON_NOTICETHREADS = "noticeThreads";
    public final String JSON_TITLE = "title";

    public final String JSON_PAGE = "page";
    public final String JSON_SIZE = "size";
    public final String JSON_TOTALELEMENTS = "totalElements";
    public final String JSON_TOTALPAGES = "totalPages";
    public final String JSON_NUMBER = "number";

    public void parseChannelThreadData();
    public void parseChannelThreadListData();
    public void parseChannelNoticeListData();
    public ChannelThreadData getChannelThreadData();
    public ArrayList<ChannelThreadData> getChannelThreadListData();
    public ArrayList<ChannelThreadData> getChannelThreadNoticeListData();
    public ArrayList<ChannelNoticeData> getChannelNoticeListData();
}
