package com.gmp.rusk.fragment;

/**
 * Created by kang on 2017-05-22.
 */

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.utils.CommonLog;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by kang on 2017-04-13.
 */

public class ChatRoomEmoticonViewpagerItemFrag extends Fragment {
    int m_n_select;
    int m_nPosition;
    int m_nMaxPage;
    String m_strRoomID = "";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LinearLayout linearLayout=(LinearLayout)inflater.inflate(R.layout.layout_emoticon_viewpager_item,container,false);

        if(m_nPosition == 4)
            m_nPosition = 1;
        else if(m_nPosition == 0)
            m_nPosition = 3;

        if(m_n_select==1) {
            ImageView[] ivs = new ImageView[8];

            ivs[0] = (ImageView) linearLayout.findViewById(R.id.iv_image1);
            ivs[1] = (ImageView) linearLayout.findViewById(R.id.iv_image2);
            ivs[2] = (ImageView) linearLayout.findViewById(R.id.iv_image3);
            ivs[3] = (ImageView) linearLayout.findViewById(R.id.iv_image4);
            ivs[4] = (ImageView) linearLayout.findViewById(R.id.iv_image5);
            ivs[5] = (ImageView) linearLayout.findViewById(R.id.iv_image6);
            ivs[6] = (ImageView) linearLayout.findViewById(R.id.iv_image7);
            ivs[7] = (ImageView) linearLayout.findViewById(R.id.iv_image8);

            String[][] sticon = {
                    {"skt_sticon01","skt_sticon02","skt_sticon03","skt_sticon04","skt_sticon05","skt_sticon06","skt_sticon07","skt_sticon08"},
                    {"skt_sticon09","skt_sticon10","skt_sticon11","skt_sticon12","skt_sticon13","skt_sticon14","skt_sticon15","skt_sticon16"},
                    {"skt_sticon17","skt_sticon18","skt_sticon19","skt_sticon20","skt_sticon21","skt_sticon22","skt_sticon23","skt_sticon24"},
            };

            for (int i = 0; i < ivs.length; i++) {
                if (ivs[i] != null) {
                    int resourceID = getResources().getIdentifier(sticon[m_nPosition - 1][i],"drawable",getActivity().getPackageName());
                    ivs[i].setImageResource(resourceID);
                }
                ivs[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(m_strRoomID.length() > 8){
                            ((ChatRoomGroupAct) getContext()).itemClick(m_n_select, m_nPosition, Integer.parseInt(v.getTag().toString()));
                        } else {
                            ((ChatRoomAct) getContext()).itemClick(m_n_select, m_nPosition, Integer.parseInt(v.getTag().toString()));
                           /* Toast.makeText(getContext(), "sel :" + m_n_select + " , pos :" + m_nPosition + ", " + v.getTag(), Toast.LENGTH_SHORT).show();*/
                        }
                    }
                });
            }
        } else  if(m_n_select==2) {
            ImageView[] ivs = new ImageView[8];

            ivs[0] = (ImageView) linearLayout.findViewById(R.id.iv_image1);
            ivs[1] = (ImageView) linearLayout.findViewById(R.id.iv_image2);
            ivs[2] = (ImageView) linearLayout.findViewById(R.id.iv_image3);
            ivs[3] = (ImageView) linearLayout.findViewById(R.id.iv_image4);
            ivs[4] = (ImageView) linearLayout.findViewById(R.id.iv_image5);
            ivs[5] = (ImageView) linearLayout.findViewById(R.id.iv_image6);
            ivs[6] = (ImageView) linearLayout.findViewById(R.id.iv_image7);
            ivs[7] = (ImageView) linearLayout.findViewById(R.id.iv_image8);

            String[][] apng = {
                    {"skt_anicon_cover01", "skt_anicon_cover02", "skt_anicon_cover03", "skt_anicon_cover04", "skt_anicon_cover05", "skt_anicon_cover06", "skt_anicon_cover07", "skt_anicon_cover08"}
                    ,{"skt_anicon_cover09", "skt_anicon_cover10", "skt_anicon_cover11", "skt_anicon_cover12", "skt_anicon_cover13", "skt_anicon_cover14", "skt_anicon_cover15", "skt_anicon_cover16"}
                    ,{"skt_anicon_cover17", "skt_anicon_cover18", "skt_anicon_cover19", "skt_anicon_cover20", "skt_anicon_cover21", "skt_anicon_cover22", "skt_anicon_cover23", "skt_anicon_cover24"}
            };

         /*   for (int i = 0; i < ivs.length; i++) {
                Bitmap bitmap = null;
                AssetManager manager = getResources().getAssets();
                try {
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = 4;
                    InputStream is = manager.open(apng[m_nPosition-1][i]+".png");
                    bitmap = BitmapFactory.decodeStream(is,new Rect(1,1,1,1),options);

                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (ivs[i] != null)
                    ivs[i].setImageBitmap(bitmap);
                ivs[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(m_strRoomID.length() > 8){
                            ((ChatRoomGroupAct) getContext()).itemClick(m_n_select, m_nPosition, Integer.parseInt(v.getTag().toString()));
                        } else {
                            ((ChatRoomAct) getContext()).itemClick(m_n_select, m_nPosition, Integer.parseInt(v.getTag().toString()));
                         *//*   Toast.makeText(getContext(), "sel :" + m_n_select + " , pos :" + m_nPosition + ", " + v.getTag(), Toast.LENGTH_SHORT).show();*//*
                        }
                    }
                });
            }*/
            for (int i = 0; i < ivs.length; i++) {
                if (ivs[i] != null) {
                    int resourceID = getResources().getIdentifier(apng[m_nPosition - 1][i],"drawable",getActivity().getPackageName());
                    ivs[i].setImageResource(resourceID);
                }
                ivs[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(m_strRoomID.length() > 8){
                            ((ChatRoomGroupAct) getContext()).itemClick(m_n_select, m_nPosition, Integer.parseInt(v.getTag().toString()));
                        } else {
                            ((ChatRoomAct) getContext()).itemClick(m_n_select, m_nPosition, Integer.parseInt(v.getTag().toString()));
                         /*   Toast.makeText(getContext(), "sel :" + m_n_select + " , pos :" + m_nPosition + ", " + v.getTag(), Toast.LENGTH_SHORT).show();*/
                        }
                    }
                });
            }
        }


        return linearLayout;
    }

    public void setSelect(int a_select){ m_n_select = a_select;}
    public void setRoomID(String a_strRoomID){m_strRoomID = a_strRoomID;}
    public void setPosition(int a_position){
        m_nPosition = a_position;
    }
    public void setMaxPage(int a_maxPage){
        m_nMaxPage = a_maxPage;
    }
}
