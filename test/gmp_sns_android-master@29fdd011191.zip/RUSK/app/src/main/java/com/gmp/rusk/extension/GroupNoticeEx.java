package com.gmp.rusk.extension;

import com.gmp.rusk.utils.CommonLog;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

/**
 * Created by kang on 2017-06-20.
 */

public class GroupNoticeEx implements PacketExtension {
    public static final String NAMESPACE = "urn:comma:group:notice";
    public static final String ELEMENT_NAME = "info";

    private String groupId;
    private String boardNo;
    private String text;
    private String imageCount;
    private String image;
    private String fileCount;
    private String fileSize;
    private String fileName;

    public GroupNoticeEx() {}

    public GroupNoticeEx(String a_groupId,String a_boardNo,String a_text,String a_imageCount,String a_image,String a_fileCount,String a_fileSize,String a_fileName) {
        groupId = a_groupId;
        boardNo = a_boardNo;
        text = a_text;
        imageCount = a_imageCount;
        image = a_image;
        fileCount = a_fileCount;
        fileSize = a_fileSize;
        fileName = a_fileName;
    }
    //
    //
    @Override
    public String getElementName() {
        // TODO Auto-generated method stub
        return ELEMENT_NAME;
    }

    @Override
    public String getNamespace() {
        // TODO Auto-generated method stub
        return NAMESPACE;
    }

    public String getGroupId() { return groupId;}
    public String getBoardNo() {return boardNo;}
    public String getText(){
        return text;
    }
    public String getImageCount(){
        return imageCount;
    }
    public String getImage(){
        return image;
    }
    public String getFileCount(){
        return fileCount;
    }
    public String getFileSize(){
        return fileSize;
    }
    public String getFileName(){
        return fileName;
    }
    @Override
    public String toXML() {
        // TODO Auto-generated method stub
        StringBuilder buf = new StringBuilder();
        // 1.5.5 에서 규격 수정됨

        // buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
        return buf.toString();
    }

    public static class Provider implements PacketExtensionProvider {

        public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
            boolean done = false;
            String groupId = "";
            String boardNo = "";
            String text = "";
            String image = "";
            String imageCount = "";
            String fileCount = "";
            String fileSize = "";
            String fileName = "";
            int count = parser.getAttributeCount();
            for(int i = 0 ; i < count ; i++){
                if(parser.getAttributeName(i).equals("groupId")){
                    groupId = parser.getAttributeValue(i);
                }
                else if(parser.getAttributeName(i).equals("boardNo")){
                    boardNo = parser.getAttributeValue(i);
                }
            }

            while (!done) {
                int eventType = parser.getEventType();
                if (eventType == XmlPullParser.START_TAG) {
                    if(parser.getName().equals("body"))
                        text = parser.nextText();
                    else if(parser.getName().equals("image")) {
                        int count2 = parser.getAttributeCount();
                        for(int i = 0 ; i < count2 ; i++) {
                            if (parser.getAttributeName(i).equals("count")) {
                                imageCount = parser.getAttributeValue(i);
                            }
                        }
                        image = parser.nextText();
                    }
                    else if(parser.getName().equals("file")) {
                        int count3 = parser.getAttributeCount();
                        for(int i = 0 ; i < count3 ; i++){
                            if(parser.getAttributeName(i).equals("count")){
                                fileCount = parser.getAttributeValue(i);
                            }
                            else if(parser.getAttributeName(i).equals("size")){
                                fileSize = parser.getAttributeValue(i);
                            }
                        }
                        fileName = parser.nextText();
                    }
                } else if (eventType == XmlPullParser.END_TAG) {
                    if (parser.getName().equals(ELEMENT_NAME)) {
                        done = true;
                    }
                }
                if (!done)
                    parser.next();
            }
            return new GroupNoticeEx(groupId,boardNo,text,imageCount,image,fileCount,fileSize,fileName);
        }
    }
}