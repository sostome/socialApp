package com.gmp.rusk.act;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.customview.CustomFragmentActivity;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.fragment.SNSGroupInvitedMemberListFrag;
import com.gmp.rusk.fragment.SNSGroupInvitingMemberListFrag;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetGroupUserReq;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.response.GetGroupUserRes;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;

public class SNSGroupMemberListAct extends CustomFragmentActivity{
	
	private final String TAB_INVITEDLIST	 		= "InvitedList"; 	// 참여중인 멤버 리스트
	private final String TAB_INVITINGLIST 			= "InvitingList"; 	// 수락대기중인 멤버 리스트
	
	private final int TAB_INDEX_INVITEDLIST 		= 0;
	private final int TAB_INDEX_INVITINGLIST 		= 1;
	private final int TAB_INDEX_MAX 				= 2;

	private int m_nGroupId = -1;
	private boolean m_isOwnered = false;
	
	private TabHost mTabHost;
	private TabManager mTabManager;
	
	private CommonPopup m_Popup = null;
	
	private ArrayList<SNSGroupMemberData> m_arrInvitedMember = null;
	private ArrayList<Integer> m_arrUnInvitedMember = null;
	private ArrayList<SNSGroupMemberData> m_arrCanceledMember = null;
	
	private TextView m_ivInvitedListTab = null;
	private TextView m_ivInvitingListTab = null;
	
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_snsgroupmemberlist);
		
		getIntentData();
		
		getGroupMemberList();
	}
	
	private void initUI()
	{
		RelativeLayout layoutTopClose = (RelativeLayout)findViewById(R.id.layout_top_close);
		layoutTopClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();

		View[] viewTabs = new View[TAB_INDEX_MAX];
		for (int i = 0; i < TAB_INDEX_MAX; i++) {
			LayoutInflater inflater = getLayoutInflater();
			viewTabs[i] = inflater.inflate(R.layout.layout_tabitem_text, null);
		}

		m_ivInvitedListTab = (TextView) viewTabs[TAB_INDEX_INVITEDLIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
		m_ivInvitingListTab = (TextView) viewTabs[TAB_INDEX_INVITINGLIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist);

		m_ivInvitedListTab.setText(getString(R.string.snsgroupexitother_invited));
		m_ivInvitingListTab.setText(getString(R.string.snsgroupexitother_inviting));
		m_ivInvitedListTab.setBackgroundResource(R.drawable.tabitem_background);
		m_ivInvitingListTab.setBackgroundResource(R.drawable.tabitem_background);

		
		mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

		mTabManager.addTab(mTabHost.newTabSpec(TAB_INVITEDLIST).setIndicator(viewTabs[TAB_INDEX_INVITEDLIST]), SNSGroupInvitedMemberListFrag.class, null);
		mTabManager.addTab(mTabHost.newTabSpec(TAB_INVITINGLIST).setIndicator(viewTabs[TAB_INDEX_INVITINGLIST]), SNSGroupInvitingMemberListFrag.class, null);
	}
	
	private void getIntentData()
	{
		m_nGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID, -1);
		m_isOwnered = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_ISOWNER, false);
	}
	
	public ArrayList<SNSGroupMemberData> getInvitedMember()
	{
		return m_arrInvitedMember;
	}
	
	public ArrayList<Integer> getUnInvitedMember()
	{
		return m_arrUnInvitedMember;
	}
	
	public ArrayList<SNSGroupMemberData> getCanceledMember()
	{
		return m_arrCanceledMember;
	}
	
	public int getGroupId()
	{
		return m_nGroupId;
	}
	
	public boolean isOwnered()
	{
		return m_isOwnered;
	}
	
	private void getGroupMemberList()
	{
		GetGroupUserReq req = new GetGroupUserReq(m_nGroupId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetGroupUserRes res = new GetGroupUserRes(a_strData);
				m_arrInvitedMember = res.getGroupMemberList();
				m_arrUnInvitedMember = res.getGroupInvitedMemberList();

				ArrayList<Integer> arrUserID = new ArrayList<Integer>();
				UserListData data;
				for(int i = 0; i < m_arrInvitedMember.size(); i++){
					data = TTalkDBManager.ContactsDBManager.getContacts(SNSGroupMemberListAct.this, m_arrInvitedMember.get(i).m_nUserNo);
					if(data == null){
						if(!arrUserID.contains(m_arrInvitedMember.get(i).m_nUserNo)){
							arrUserID.add(m_arrInvitedMember.get(i).m_nUserNo);
						}
					}
				}
				for(int i = 0; i < m_arrUnInvitedMember.size(); i++){
					data = TTalkDBManager.ContactsDBManager.getContacts(SNSGroupMemberListAct.this, m_arrUnInvitedMember.get(i));
					if(data == null){
						if(!arrUserID.contains(m_arrUnInvitedMember.get(i))){
							arrUserID.add(m_arrUnInvitedMember.get(i));
						}
					}
				}
				int[] nNotInDBUsers = new int[arrUserID.size()];
				for(int j = 0; j < arrUserID.size(); j++){
					nNotInDBUsers[j] = arrUserID.get(j);
				}
				if(nNotInDBUsers.length > 0){
					requestAddedByUserList(nNotInDBUsers);
				} else {
					initUI();
				}
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP)
					showNotInvitedGroupPopup(strMessage);
				else
					showErrorPopup(nErrorCode, strMessage);
			}
		});
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
	
	public void showNotInvitedGroupPopup(String a_strMsg)
	{
		m_Popup = new CommonPopup(SNSGroupMemberListAct.this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
				setResult(RESULTCODE_NOTINVITED_SNSGROUP);
				finish();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMsg);
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	public static class TabManager implements TabHost.OnTabChangeListener {
		private final FragmentActivity mActivity;
		private final TabHost mTabHost;
		private final int mContainerId;
		private final HashMap<String, TabInfo> mTabs = new HashMap<String, TabInfo>();
		TabInfo mLastTab;

		static final class TabInfo {
			private final String tag;
			private final Class<?> clss;
			private final Bundle args;
			private Fragment fragment;

			TabInfo(String _tag, Class<?> _class, Bundle _args) {
				tag = _tag;
				clss = _class;
				args = _args;
			}
		}

		static class DummyTabFactory implements TabHost.TabContentFactory {
			private final Context mContext;

			public DummyTabFactory(Context context) {
				mContext = context;
			}

			@Override
			public View createTabContent(String tag) {
				View v = new View(mContext);
				v.setMinimumWidth(0);
				v.setMinimumHeight(0);
				return v;
			}
		}

		public TabManager(FragmentActivity activity, TabHost tabHost, int containerId) {
			mActivity = activity;
			mTabHost = tabHost;
			mContainerId = containerId;
			mTabHost.setOnTabChangedListener(this);
		}

		public void addTab(TabHost.TabSpec tabSpec, Class<?> clss, Bundle args) {
			tabSpec.setContent(new DummyTabFactory(mActivity));
			String tag = tabSpec.getTag();

			TabInfo info = new TabInfo(tag, clss, args);

			// Check to see if we already have a fragment for this tab, probably
			// from a previously saved state. If so, deactivate it, because our
			// initial state is that a tab isn't shown.
			info.fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
			if (info.fragment != null && !info.fragment.isDetached()) {
				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				ft.detach(info.fragment);
				ft.commit();
			}

			mTabs.put(tag, info);
			mTabHost.addTab(tabSpec);
		}

		@Override
		public void onTabChanged(String tabId) {
			TabInfo newTab = mTabs.get(tabId);
			if (mLastTab != newTab) {
				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				if (mLastTab != null) {
					if (mLastTab.fragment != null) {
						ft.detach(mLastTab.fragment);
					}
				}
				if (newTab != null) {
					if (newTab.fragment == null) {
						newTab.fragment = Fragment.instantiate(mActivity, newTab.clss.getName(), newTab.args);
						ft.add(mContainerId, newTab.fragment, newTab.tag);
					} else {
						ft.attach(newTab.fragment);
					}
				}

				mLastTab = newTab;
				ft.commit();
				mActivity.getSupportFragmentManager().executePendingTransactions();
			}
		}
	}

	synchronized public void requestAddedByUserList(int[] nUserIDs){
		GetUserInfoReq req = new GetUserInfoReq(nUserIDs);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				for (int i = 0; i < res.getUserListData().size(); i++) {
					UserListData getItem = res.getUserListData().get(i);
					if (getItem != null) {
						TTalkDBManager.ContactsDBManager.insertContacts(SNSGroupMemberListAct.this, getItem);
					}
				}
				initUI();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				showErrorPopup(a_nErrorCode, a_strMessage);
			}
		});
	}
}
