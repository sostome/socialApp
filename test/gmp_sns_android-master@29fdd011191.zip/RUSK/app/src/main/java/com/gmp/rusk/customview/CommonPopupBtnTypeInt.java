package com.gmp.rusk.customview;

public class CommonPopupBtnTypeInt {
	public final static int POP_BTNTYPE_YESNO = 0;
	public final static int POP_BTNTYPE_YES = POP_BTNTYPE_YESNO + 1;
}
