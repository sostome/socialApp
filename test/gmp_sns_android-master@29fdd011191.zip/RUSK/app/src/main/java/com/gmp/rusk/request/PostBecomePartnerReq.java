package com.gmp.rusk.request;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author subi78
 *			파트너 가입
 *			method : post
 */

public class PostBecomePartnerReq extends Req{
	
	private String APINAME = "partner";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "POST";
	
	private final String JSON_USERID = "userId";
	private final String JSON_PASSWORD = "password";
	private final String JSON_NAME = "name";
	private final String JSON_EMAIL = "email";
	private final String JSON_MOBILE = "mobile";
	private final String JSON_AFFILIATION = "affiliation";
	private final String JSON_APPROVALUSERNO = "approvalUserNo";

	
	private String m_strUserId = "";			//사용자 ID
	private String m_strPassword = "";			//사용자 비밀번호
	private String m_strName = "";				//사용자 이름
	private String m_strEmail = "";				//사용자 이메일
	private String m_strMobile = "";			//사용자 전화번호
	private String m_strAffiliation = "";			//사용자 소속
	private int m_nApprovalUserNo = 0;			//승인자 번호
	
	
	public PostBecomePartnerReq(String a_strUserId, String a_strPassword, String a_strName, String a_strEmail, String a_strMobile, String a_strAffiliation, int a_nApprovalUserNo)
	{
		m_strUserId = a_strUserId;
		m_strPassword = a_strPassword;
		m_strName = a_strName;
		m_strEmail = a_strEmail;
		m_strMobile = a_strMobile;
		m_strAffiliation = a_strAffiliation;
		m_nApprovalUserNo = a_nApprovalUserNo;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_USERID, m_strUserId);
			jsonObj.put(JSON_PASSWORD, m_strPassword);
			jsonObj.put(JSON_NAME, m_strName);
			jsonObj.put(JSON_EMAIL, m_strEmail);
			jsonObj.put(JSON_MOBILE, m_strMobile);
			jsonObj.put(JSON_AFFILIATION, m_strAffiliation);
			jsonObj.put(JSON_APPROVALUSERNO, m_nApprovalUserNo);

			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PostBecomePartnerReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
