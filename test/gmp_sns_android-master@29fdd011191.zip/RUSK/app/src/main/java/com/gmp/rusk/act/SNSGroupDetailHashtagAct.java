package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.customview.SNSGroupDetailSwifeRefreshLayout;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChannelThreadData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.datamodel.SNSGroupSearchListData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.SNSGroupDBManager;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.listview.LoadMoreListView;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteBoardLikeReq;
import com.gmp.rusk.request.GetGroupBoardReq;
import com.gmp.rusk.request.GetGroupSearchReq;
import com.gmp.rusk.request.GetHashtagReq;
import com.gmp.rusk.request.PostBoardLikeReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetGroupBoardRes;
import com.gmp.rusk.response.GetGroupSearchRes;
import com.gmp.rusk.response.GetHashtagRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SNSGroupDetailHashtagAct extends CustomActivity implements OnClickListener{

	private final int REQUEST_CODE_BOARDDETAIL = 6;

	private SNSBoardListAdapter m_adapterBoardList = null;

	private ArrayList<ChannelThreadData> m_SNSGroupSearchListDatas = new ArrayList<ChannelThreadData>();
	private int m_nGroupId = -1;
	private String m_strGroupName = "";
	private String m_strHashTag = "";
	private ArrayList<Integer> m_arrNoReadBoard;
	private SparseBooleanArray m_arrReadTrueList;

	CommonPopup m_Popup = null;

	boolean m_isListViewHeader = false;

	private String m_strSearchType = "H";

	private static String SEARCH_HASHTAG = "H";
	private static String SEARCH_CONTENT = "C";

	boolean m_isSampleHashTagEmpty = false;

	int m_nSeletedPosition = 0;

	EditText et_search_keyword;
	ImageView m_btnTopClose;
	ImageButton ib_cancel;
	TextView tv_search_count;
	RelativeLayout layout_nolisttext;
	RelativeLayout layout_notfound;
	ScrollView layout_hashtag;
	TextView m_ivHashTagIcon;

	private InputMethodManager imm;

	private FrameLayout layout_groupdetail_searchbylist_list = null;
	private SwipeRefreshLayout m_layoutSwipeRefresh = null;
	private LoadMoreListView m_lvGroupDetailSearchList = null;

	private int m_nPage = 1;
	private boolean m_isLastPage = false;
	private ArrayList<Integer> m_arrBoardNo = new ArrayList<Integer>();

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);

		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

		setContentView(R.layout.act_snsgroupdetail_hashtag_only);
		//이미 검색 창이 떠있다면 제거
		boolean isAlreadyActivity = false;
		Activity alreadyActivity = null;
		for(Activity activity : App.m_arrActivitys){
			if(activity.getClass().getSimpleName().equals("SNSGroupDetailSearchAct")){
				if(!isAlreadyActivity){
					isAlreadyActivity = true;
					alreadyActivity = activity;
				} else {
					alreadyActivity.finish();
					break;
				}
			}

		}
		getIntentData();

		initSearchRegular();
		requestHashTag();
		if(m_strHashTag != null && !m_strHashTag.equals("")){
			requestHashTagSearch(m_strHashTag);
		}
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);

		m_nPage = 1;
		m_isLastPage = false;
		m_arrBoardNo = new ArrayList<Integer>();
		m_SNSGroupSearchListDatas = new ArrayList<ChannelThreadData>();

		m_strHashTag = intent.getStringExtra(IntentKeyString.INTENT_KEY_SNSGROUPSEARCH_HASHTAG);
		requestHashTagSearch(m_strHashTag);

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode == RESULTCODE_NOTINVITED_SNSGROUP)
		{
			setResult(RESULTCODE_NOTINVITED_SNSGROUP);
			finish();
		} else if (requestCode == REQUEST_CODE_BOARDDETAIL){
			if (data != null){
			final int nBoardId = data.getIntExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, -1);
			if(nBoardId != -1)
			{
				boolean isDeleted = data.getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISDELETE, false);
				if(isDeleted)
				{
					for(ChannelThreadData snsBoardData : m_SNSGroupSearchListDatas)
					{
						if(nBoardId == snsBoardData.m_nThreadNo)
						{
							m_SNSGroupSearchListDatas.remove(snsBoardData);
							break;
						}
					}
					SNSGroupDBManager.deleteSNSAlarmWhereBoardId(SNSGroupDetailHashtagAct.this, nBoardId);
					updateSNSAlarmIconBadge();
					m_adapterBoardList.notifyDataSetChanged();

					tv_search_count.setText(m_SNSGroupSearchListDatas.size()+"");
				}
				else
				{
					m_arrReadTrueList = new SparseBooleanArray();
					m_arrReadTrueList.append((Integer)nBoardId, true);

//					DeleteSNSGroupBadgeReq req = new DeleteSNSGroupBadgeReq(m_arrReadTrueList);
//					WebAPI api = new WebAPI(this);
//					api.request(req, new WebListener() {
//
//						@Override
//						public void onPreRequest() {
//							// TODO Auto-generated method stub
//
//						}
//
//						@Override
//						public void onPostRequest(String a_strData) {
//							// TODO Auto-generated method stub
							SNSGroupDBManager.updateSNSIsBoardRead(SNSGroupDetailHashtagAct.this, m_nGroupId, m_arrReadTrueList);
							updateSNSAlarmIconBadge();
							if(m_arrNoReadBoard != null)
							{
								m_arrNoReadBoard.remove((Integer)nBoardId);
							}
							getBoardDetailData(nBoardId);
//						}
//
//						@Override
//						public void onNetworkError(int nErrorCode, String strMessage) {
//							// TODO Auto-generated method stub
//							if(m_arrNoReadBoard != null)
//							{
//								m_arrNoReadBoard.remove((Integer)nBoardId);
//							}
//							getBoardDetailData(nBoardId);
//						}
//					});

				}
			}
		}
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	private void getIntentData()
	{
		m_nGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, 0);
		m_strGroupName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME);
		m_strHashTag = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSGROUPSEARCH_HASHTAG);
	}

	private void setUI()
	{
		layout_groupdetail_searchbylist_list.setVisibility(View.VISIBLE);

		if(m_SNSGroupSearchListDatas != null)
    	{
			m_arrNoReadBoard = SNSGroupDBManager.getSNSAlarmWhereNoBoardRead(SNSGroupDetailHashtagAct.this, m_nGroupId);
    		layout_nolisttext.setVisibility(View.GONE);
			layout_hashtag.setVisibility(View.GONE);
    		if(m_SNSGroupSearchListDatas == null || m_SNSGroupSearchListDatas.size() == 0)
    			layout_notfound.setVisibility(View.VISIBLE);
    		else
    			layout_notfound.setVisibility(View.GONE);
			if(m_adapterBoardList == null) {
				m_adapterBoardList = new SNSBoardListAdapter();
				m_lvGroupDetailSearchList.setAdapter(m_adapterBoardList);
			} else {
				m_adapterBoardList.notifyDataSetChanged();
			}

    		tv_search_count.setText(m_SNSGroupSearchListDatas.size()+"");
    	}
    	else
    	{
			if(m_strSearchType.equals(SEARCH_HASHTAG)) {
				layout_hashtag.setVisibility(View.VISIBLE);
			} else {
				layout_nolisttext.setVisibility(View.VISIBLE);
			}
    		layout_notfound.setVisibility(View.GONE);
    	}
		if(et_search_keyword != null) {
			et_search_keyword.setSelection(et_search_keyword.length());
		}
	}

	private void startSNSBoardDetailAct(boolean a_isPush, int a_nGroupId, String a_strGroupName, final int a_nBoardId, boolean a_isReply, boolean a_isWriteReply, boolean a_isLastScroll)
	{
//		boolean isShowChatBtn = false;
//		if(btnGroupChat != null && btnGroupChat.getVisibility() == View.VISIBLE){
//			isShowChatBtn = true;
//		}
//
		Intent intent = new Intent(this, SNSBoardDetailAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISPUSH, a_isPush);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPID, a_nGroupId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPNAME, a_strGroupName);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, a_nBoardId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, a_isReply);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_WRITEREPLY, a_isWriteReply);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_SHOWCHATBTN, false);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISLASTSCROLL, a_isLastScroll);
		startActivityForResult(intent, REQUEST_CODE_BOARDDETAIL);
//		startActivity(intent);

//		m_arrReadTrueList = new SparseBooleanArray();
//		m_arrReadTrueList.append((Integer)a_nBoardId, true);

//		DeleteSNSGroupBadgeReq req = new DeleteSNSGroupBadgeReq(m_arrReadTrueList);
//		WebAPI api = new WebAPI(this);
//		api.request(req, new WebListener() {
//
//			@Override
//			public void onPreRequest() {
//				// TODO Auto-generated method stub
//
//			}
//
//			@Override
//			public void onPostRequest(String a_strData) {
//				// TODO Auto-generated method stub
//				TTalkDBManager.SNSGroupDBManager.updateSNSIsBoardRead(SNSGroupDetailSearchAct.this, m_nGroupId, m_arrReadTrueList);
//				if(m_arrNoReadBoard != null)
//				{
//					m_arrNoReadBoard.remove((Integer)a_nBoardId);
//					m_adapterBoardList.notifyDataSetChanged();
//				}
//				updateSNSAlarmIconBadge();
//			}
//
//			@Override
//			public void onNetworkError(int nErrorCode, String strMessage) {
//				// TODO Auto-generated method stub
//				if(m_arrNoReadBoard != null)
//				{
//					m_arrNoReadBoard.remove((Integer)a_nBoardId);
//					m_adapterBoardList.notifyDataSetChanged();
//				}
//				updateSNSAlarmIconBadge();
//			}
//		});

	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		/*
		 * SNSAlarmDB 에 BoardRead 적용하기 전에 서버에 DeleteSNSGroupBadgeReq를 요청한다.
		 */
//		DeleteSNSGroupBadgeReq req = new DeleteSNSGroupBadgeReq(m_arrNoReadBoard);
//		WebAPI api = new WebAPI(this);
//		api.request(req, new WebListener() {
//
//			@Override
//			public void onPreRequest() {
//				// TODO Auto-generated method stub
//
//			}
//
//			@Override
//			public void onPostRequest(String a_strData) {
//				// TODO Auto-generated method stub
				m_arrReadTrueList = new SparseBooleanArray();
				if(m_arrNoReadBoard != null)
				{
					for(int i = 0; i < m_arrNoReadBoard.size(); i++){
						m_arrReadTrueList.append(m_arrNoReadBoard.get(i), true);
					}
					SNSGroupDBManager.updateSNSIsBoardRead(SNSGroupDetailHashtagAct.this, m_nGroupId, m_arrReadTrueList);
					updateSNSAlarmIconBadge();
				}
//			}
//			
//			@Override
//			public void onNetworkError(int nErrorCode, String strMessage) {
//				// TODO Auto-generated method stub
//				
//			}
//		});
		
		super.onBackPressed();
	}
	
	
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		else if(nId == R.id.ib_pop_ok)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		else if(nId == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		
		
		
		super.onClick(v);
	}
	
	/*@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		
		SNSGroupSearchListData data = (SNSGroupSearchListData)m_adapterBoardList.getItem(position);
		startSNSBoardDetailAct(false, m_nGroupId, data.m_strGroupName, data.m_nBoardNo, false, false, false);
	}*/
	
	private void initSearchRegular()
    {
		m_ivHashTagIcon = (TextView) findViewById(R.id.tv_icon_hash);
		layout_groupdetail_searchbylist_list = (FrameLayout) findViewById(R.id.layout_groupdetail_searchbylist_list);
//    	m_lvAddedByRegularList = (ListView)m_vAddedByRegularList.findViewById(R.id.lv_addedbylist_list);
		m_layoutSwipeRefresh = (SwipeRefreshLayout)findViewById(R.id.layout_snsgroupdetail_search_swiperefresh);
		m_layoutSwipeRefresh.setOnRefreshListener(m_onTimeLineRefreshListener);
		m_lvGroupDetailSearchList = (LoadMoreListView) findViewById(R.id.lv_snsgroupdetail_search_boardlist);
		m_lvGroupDetailSearchList.setOnLoadMoreListener(m_onTimeLineLoadMoreListener);
		m_btnTopClose = (ImageView) findViewById(R.id.btn_top_close);
		m_btnTopClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		//m_lvGroupDetailSearchList.setOnItemClickListener(this);
		
		layout_groupdetail_searchbylist_list.setVisibility(View.GONE);
    
		tv_search_count = (TextView)findViewById(R.id.tv_search_count);
    	    	
    	layout_nolisttext = (RelativeLayout)findViewById(R.id.layout_nolisttext);
    	layout_notfound = (RelativeLayout)findViewById(R.id.layout_notfound);
		layout_hashtag = (ScrollView)findViewById(R.id.layout_hashtag_sample_view);

		//해시태그 페이지가 제일 처음
		layout_hashtag.setVisibility(View.VISIBLE);
    	layout_nolisttext.setVisibility(View.GONE);
    	layout_notfound.setVisibility(View.GONE);
    	et_search_keyword = (EditText)findViewById(R.id.et_search_keyword);
    	if(imm != null && et_search_keyword != null)
    		imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
    	ib_cancel = (ImageButton) findViewById(R.id.ib_cancel);
    	ib_cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				et_search_keyword.setText("");
				initSearchRegular();
			}
		});
    	    	
    	et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				CommonLog.e("EditAction", "actionId1 : "+actionId);
							
				switch(actionId) {
				case EditorInfo.IME_ACTION_SEARCH:
					if(v.getText().toString().trim().length() > 1 || m_strSearchType.equals(SEARCH_HASHTAG))
					{
						if(!m_strSearchType.equals(SEARCH_HASHTAG) && !Utils.UseChar(v.getText().toString()))
						{
							m_Popup = new CommonPopup(SNSGroupDetailHashtagAct.this, SNSGroupDetailHashtagAct.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									getString(R.string.regular_expression_search).toString());
							m_Popup.setCancelable(false);
							isCheckShowPopup();
							return false;
						}

						if(m_strSearchType.equals(SEARCH_HASHTAG) && v.getText().toString().trim().length() == 0){
							m_Popup = new CommonPopup(SNSGroupDetailHashtagAct.this, SNSGroupDetailHashtagAct.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									getString(R.string.popup_search_length_hash).toString());
							m_Popup.setCancelable(false);
							isCheckShowPopup();
							return false;
						}

						SNSGroupDetailSwifeRefreshLayout layoutSwipeRefresh = (SNSGroupDetailSwifeRefreshLayout)findViewById(R.id.layout_snsgroupdetail_search_swiperefresh);
						layoutSwipeRefresh.initFlag();

						m_nPage = 1;
						m_isLastPage = false;
						m_arrBoardNo = new ArrayList<Integer>();
						m_SNSGroupSearchListDatas = new ArrayList<ChannelThreadData>();
						if(m_strSearchType.equals(SEARCH_HASHTAG)){
							requestHashTagSearch("#" + v.getText().toString().trim());
						} else {
							requestGroupSearch();
						}
					}
					else
					{
						m_Popup = new CommonPopup(SNSGroupDetailHashtagAct.this, SNSGroupDetailHashtagAct.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(
								getString(R.string.pop_error_title).toString(),
								getString(R.string.popup_search_length).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
					break;
				}
				return false;
			}
		});
    	
    	et_search_keyword.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if(s.toString().length()>0)
				{
					ib_cancel.setVisibility(View.VISIBLE);
					et_search_keyword.setFilters(new InputFilter[] { new InputFilter.LengthFilter(10) });
					if(et_search_keyword.getText().toString().contains(" ")){
						String strReplaceText = et_search_keyword.getText().toString();
						strReplaceText = strReplaceText.replace(" ", "");
						et_search_keyword.setText(strReplaceText);
						et_search_keyword.setSelection(start);
					}
					if(et_search_keyword.getText().toString().contains("#")){
						String strReplaceText = et_search_keyword.getText().toString();
						strReplaceText = strReplaceText.replace("#", "");
						et_search_keyword.setText(strReplaceText);
						et_search_keyword.setSelection(start);
					}
				}
				else
				{	
					ib_cancel.setVisibility(View.INVISIBLE);
					layout_notfound.setVisibility(View.INVISIBLE);
					if(m_strSearchType.equals(SEARCH_HASHTAG)) {
						layout_hashtag.setVisibility(View.VISIBLE);
						LinearLayout layoutHashtagSample = (LinearLayout)findViewById(R.id.layout_hashtag_sample_itemview);
						if(layoutHashtagSample.getChildCount() == 0 && !m_isSampleHashTagEmpty){
							requestHashTag();
						}

					} else {
						layout_nolisttext.setVisibility(View.VISIBLE);
					}
					layout_groupdetail_searchbylist_list.setVisibility(View.GONE);
//					m_arrRegularSearchListDatas = null;
//					initSearchRegular();


				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});

    }


	private SwipeRefreshLayout.OnRefreshListener m_onTimeLineRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {

		@Override
		public void onRefresh() {
			// TODO Auto-generated method stub
			SNSGroupDetailSwifeRefreshLayout layoutSwipeRefresh = (SNSGroupDetailSwifeRefreshLayout)findViewById(R.id.layout_snsgroupdetail_search_swiperefresh);
			layoutSwipeRefresh.initFlag();

			m_nPage = 1;
			m_isLastPage = false;
			m_arrBoardNo = new ArrayList<Integer>();
			m_SNSGroupSearchListDatas = new ArrayList<ChannelThreadData>();
			if(m_strSearchType.equals(SEARCH_HASHTAG)){
				requestHashTagSearch("#" + et_search_keyword.getText().toString().trim());
			} else {
				requestGroupSearch();
			}

		}
	};

	private LoadMoreListView.OnLoadMoreListener m_onTimeLineLoadMoreListener = new LoadMoreListView.OnLoadMoreListener() {

		@Override
		public void onLoadMore() {
			if(!m_isLastPage) {
				m_nPage++;
				if (m_strSearchType.equals(SEARCH_HASHTAG)) {
					requestHashTagSearch("#" + et_search_keyword.getText().toString().trim());
				} else {
					requestGroupSearch();
				}
			}

		}
	};

	private void completeLoadMore()
	{
		LoadMoreListView lvBoardList = (LoadMoreListView)findViewById(R.id.lv_snsgroupdetail_search_boardlist);
		lvBoardList.onLoadMoreComplete();
	}
	private void requestGroupSearch()
	{
		final SNSGroupDetailSwifeRefreshLayout layoutSwipeRefresh = (SNSGroupDetailSwifeRefreshLayout)findViewById(R.id.layout_snsgroupdetail_search_swiperefresh);
		String strSearchType = "";
		if(m_strSearchType.equals(SEARCH_HASHTAG))
			strSearchType = SEARCH_CONTENT;
		else
			strSearchType = m_strSearchType;
		GetGroupSearchReq req = new GetGroupSearchReq(m_nGroupId, strSearchType, et_search_keyword.getText().toString().trim());
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				layout_groupdetail_searchbylist_list.setVisibility(View.GONE);
				GetGroupSearchRes res = new GetGroupSearchRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_THREAD_LIST);
				ArrayList<ChannelThreadData> tempData = res.getChannelThreadListData();
				ArrayList<Integer> tempBoardNos = new ArrayList<Integer>();
				if(tempData != null) {
					for (int i = 0; i < tempData.size(); i++) {
						if (!m_arrBoardNo.contains(tempData.get(i).m_nThreadNo)) {
							tempBoardNos.add(tempData.get(i).m_nThreadNo);
							m_SNSGroupSearchListDatas.add(tempData.get(i));
						} else {

						}
					}
				}
				m_arrBoardNo.addAll(tempBoardNos);

				/*if(res.getPageData().m_nTotalPage == m_nPage){
					m_isLastPage = true;
				}*/

				if(m_SNSGroupSearchListDatas != null)
				{
					setUI();
				}
				else
				{
					if(m_SNSGroupSearchListDatas == null || m_SNSGroupSearchListDatas.size() == 0)
					{
		    			layout_notfound.setVisibility(View.VISIBLE);
		    			layout_nolisttext.setVisibility(View.GONE);
						layout_hashtag.setVisibility(View.GONE);
					}
					else
					{
		    			layout_notfound.setVisibility(View.GONE);
					}
				}
				layoutSwipeRefresh.setRefreshing(false);
				completeLoadMore();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				closeProgress();
				layoutSwipeRefresh.setRefreshing(false);
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

	private void requestHashTagSearch(String a_strHashtag)
	{
		final SNSGroupDetailSwifeRefreshLayout layoutSwipeRefresh = (SNSGroupDetailSwifeRefreshLayout)findViewById(R.id.layout_snsgroupdetail_search_swiperefresh);
		et_search_keyword.setText(a_strHashtag.substring(1));
		GetGroupSearchReq req = new GetGroupSearchReq(m_nGroupId, SEARCH_CONTENT, a_strHashtag);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				layout_groupdetail_searchbylist_list.setVisibility(View.GONE);
				GetGroupSearchRes res = new GetGroupSearchRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_THREAD_LIST);
				ArrayList<ChannelThreadData> tempData = res.getChannelThreadListData();
				ArrayList<Integer> tempBoardNos = new ArrayList<Integer>();
				if(tempData != null) {
					for (int i = 0; i < tempData.size(); i++) {
						if (!m_arrBoardNo.contains(tempData.get(i).m_nThreadNo)) {
							tempBoardNos.add(tempData.get(i).m_nThreadNo);
							m_SNSGroupSearchListDatas.add(tempData.get(i));
						} else {

						}
					}
				}
				m_arrBoardNo.addAll(tempBoardNos);

				/*if(res.getPageData().m_nTotalPage == m_nPage){
					m_isLastPage = true;
				}*/

				if(m_SNSGroupSearchListDatas != null)
				{
					setUI();
				}
				else
				{
					if(m_SNSGroupSearchListDatas == null || m_SNSGroupSearchListDatas.size() == 0)
					{
						layout_notfound.setVisibility(View.VISIBLE);
						layout_nolisttext.setVisibility(View.GONE);
						layout_hashtag.setVisibility(View.GONE);
					}
					else
					{
						layout_notfound.setVisibility(View.GONE);
					}
				}
				layoutSwipeRefresh.setRefreshing(false);
				completeLoadMore();
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				// TODO Auto-generated method stub
				closeProgress();
				layoutSwipeRefresh.setRefreshing(false);
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

	private void requestHashTag()
	{
		GetHashtagReq req = new GetHashtagReq(m_nGroupId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				showProgress();
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				closeProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
				GetHashtagRes res = new GetHashtagRes(a_strData);
				final ArrayList<String> arrHashtags = res.getHashtags();

				LinearLayout layoutHashtagSample = (LinearLayout)findViewById(R.id.layout_hashtag_sample_itemview);
				layoutHashtagSample.removeAllViews();
				if(arrHashtags == null || arrHashtags.size() == 0){
					m_isSampleHashTagEmpty = true;
				}
				for(int i = 0; i < arrHashtags.size(); i++){
					LayoutInflater li = LayoutInflater.from(SNSGroupDetailHashtagAct.this);
					LinearLayout tempView = (LinearLayout)li.inflate(R.layout.layout_snsboardsearch_hashtag_item, null);
					TextView tv_tempText = (TextView)tempView.findViewById(R.id.tv_snsboardsearch_hashtag_item);
					final String strText = arrHashtags.get(i);
					final SpannableStringBuilder sps = new SpannableStringBuilder(strText);
					sps.setSpan(new ForegroundColorSpan(Color.parseColor("#6363b7")), 0, strText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					tv_tempText.append(sps);
					tempView.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							SNSGroupDetailSwifeRefreshLayout layoutSwipeRefresh = (SNSGroupDetailSwifeRefreshLayout)findViewById(R.id.layout_snsgroupdetail_search_swiperefresh);
							layoutSwipeRefresh.initFlag();
							m_nPage = 1;
							m_isLastPage = false;
							m_arrBoardNo = new ArrayList<Integer>();
							m_SNSGroupSearchListDatas = new ArrayList<ChannelThreadData>();
							requestHashTagSearch(strText);
						}
					});
					layoutHashtagSample.addView(tempView, i);
				}
			}
		});
	}
	private void updateSNSAlarmIconBadge()
	{
		int nBoardNoReadCount = SNSGroupDBManager.getNoBoardReadCount(this);
		SharedPref pref = SharedPref.getInstance(this);
		//int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, 0);
		int nUpdateBadgeCount = nBoardNoReadCount;
		if(nUpdateBadgeCount < 0){
			nUpdateBadgeCount = 0;
		}
		pref.setIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, nUpdateBadgeCount);
		IconBadge.updateIconBadge(this);
	}
		
	private class SNSBoardListAdapter extends BaseAdapter
	{
		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub
			super.notifyDataSetChanged();
			
			
		}
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if(m_SNSGroupSearchListDatas == null)
				return 0;
			
			return m_SNSGroupSearchListDatas.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if(m_SNSGroupSearchListDatas == null)
				return null;
			
			return m_SNSGroupSearchListDatas.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if(convertView == null)
			{
				LayoutInflater li = LayoutInflater.from(SNSGroupDetailHashtagAct.this);
				convertView = li.inflate(R.layout.layout_snsgroupdetail_board_listitem, parent, false);
			}
			
			/*View vFirstItemTopMargin;
			View vNoFirstItemTopMargin;
			View vLastItemBottomMargin;
			View vNoLastItemBottomMargin;
			
			vFirstItemTopMargin = convertView.findViewById(R.id.v_snsgroupdetail_board_listitem_firstitemtopmargin);
			vNoFirstItemTopMargin = convertView.findViewById(R.id.v_snsgroupdetail_board_listitem_nofirstitemtopmargin);
			vLastItemBottomMargin = convertView.findViewById(R.id.v_snsgroupdetail_board_listitem_lastitembottommargin);
			vNoLastItemBottomMargin = convertView.findViewById(R.id.v_snsgroupdetail_board_listitem_nolastitembottommargin);*/
			
			/*if(position == 0)
			{
				// First Item
				vFirstItemTopMargin.setVisibility(View.VISIBLE);
				vNoFirstItemTopMargin.setVisibility(View.GONE);
			}
			else
			{
				vFirstItemTopMargin.setVisibility(View.GONE);
				vNoFirstItemTopMargin.setVisibility(View.VISIBLE);
			}
			
			if(position == (getCount() - 1))
			{
				// Last Item
				vLastItemBottomMargin.setVisibility(View.VISIBLE);
				vNoLastItemBottomMargin.setVisibility(View.GONE);
			}
			else
			{
				vLastItemBottomMargin.setVisibility(View.GONE);
				vNoLastItemBottomMargin.setVisibility(View.VISIBLE);
			}*/
			
			final ChannelThreadData data = (ChannelThreadData)getItem(position);

			LinearLayout layoutBackground = (LinearLayout)convertView.findViewById(R.id.layout_snsgroupdetail_board_background);

			ImageView ivUserImg = (ImageView)convertView.findViewById(R.id.iv_snsgroupdetail_board_listitem_userimg);
			ImageView ivNoReadIcon = (ImageView)convertView.findViewById(R.id.iv_snsgroupdetail_board_listitem_dot);
			TextView tvUserName = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_username);
			TextView tvCompanyOrDepartment = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_companyordepartment);
			TextView tvDate = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_date);
			TextView tvComment = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_comment);
			ImageView ivPartnerMark = (ImageView)convertView.findViewById(R.id.iv_partner_mark);

			layoutBackground.setTag(data.m_nThreadNo);
			layoutBackground.setOnClickListener(m_onBackgroundClickListener);
			SharedPref pref = SharedPref.getInstance(SNSGroupDetailHashtagAct.this);
			int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
			if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
				tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14.33f);
			} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
				tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18.62f);
			} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
				tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 22.93f);
			}

			TextView tvReplyCount = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_replycount);
			
			CommonLog.e(getClass(), "data.m_nBoardOwnerNo : " + data.m_nUserNo);
			final UserListData userInfo = TTalkDBManager.ContactsDBManager.getContacts(SNSGroupDetailHashtagAct.this, data.m_nUserNo);
			App.imageloader.cancelDownload(ivUserImg);
			App.imageloader.getProfileImage(ivUserImg, App.getImageDownLoaderUrl(data.m_nUserNo, false), R.drawable.profile_pic_default, false);
			
			tvUserName.setText(userInfo.m_PersonalData.mapPersonalData.get(PersonalData.NAME));

			if(m_arrNoReadBoard.contains(data.m_nThreadNo)){
				ivNoReadIcon.setVisibility(View.VISIBLE);
			} else {
				ivNoReadIcon.setVisibility(View.GONE);
			}

			//파트너 마크표사
			String a_userType = App.m_arrUserListData.get(data.m_nUserNo).m_strUserType;
			if(a_userType.equals("P")) {
				ivPartnerMark.setVisibility(View.VISIBLE);
				tvCompanyOrDepartment.setText(userInfo.m_PersonalData.mapPersonalData.get(PersonalData.AFFILIATION));
			}
			else {
				tvCompanyOrDepartment.setText(userInfo.m_PersonalData.mapPersonalData.get(PersonalData.DEPARTMENT)+"|"+userInfo.m_PersonalData.mapPersonalData.get(PersonalData.COMPANY_NAME));
				ivPartnerMark.setVisibility(View.GONE);
			}

			SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());
			String strDate = "";
			try {
				Date createDate = sdfOriginal.parse(data.m_strCreatedDate);
				
				SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
				strDate = sdfCreateDateUIPrint.format(createDate);
				
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(strDate != null && !strDate.equals(""))
				tvDate.setText(strDate);
			else
				tvDate.setText(data.m_strCreatedDate);
			
			String strComment;
			if(data.m_strBody.length() > 300)
				strComment = data.m_strBody.substring(0, 299) + "...";
			else
				strComment = data.m_strBody;


			boolean isHashTagSearch = false;
			if(m_strSearchType.equals(SEARCH_HASHTAG)){
				isHashTagSearch = true;
			} else {
				isHashTagSearch = false;
			}
			//tvComment.setText(Utils.getHashtagString(SNSGroupDetailHashtagAct.this, strComment, m_nGroupId, m_strGroupName, "#" + et_search_keyword.getText().toString(), isHashTagSearch));

			tvComment.setTag(data.m_nThreadNo);
			tvComment.setSingleLine(false);
			tvComment.setEllipsize(TextUtils.TruncateAt.END);
			tvComment.setMaxLines(3);
			tvComment.setOnClickListener(m_onBackgroundClickListener);
			SpannableString spanText = Utils.getHashtagString(SNSGroupDetailHashtagAct.this, data.m_strBody, m_nGroupId, m_strGroupName, "#" + et_search_keyword.getText().toString(), isHashTagSearch);
			tvComment.setOnTouchListener(new Utils.MovementMethod(spanText));
			tvComment.setText(spanText);
			CustomLinkify.addLinks(tvComment, CustomLinkify.ALL);
			tvReplyCount.setText("" + data.m_nCommentCount);
			
			RelativeLayout layoutReply = (RelativeLayout)convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_reply);
			//LinearLayout layoutWriteReply = (LinearLayout)convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_writereply);
			RelativeLayout layoutLike = (RelativeLayout)convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_like);
			final ImageView ivLike = (ImageView)convertView.findViewById(R.id.iv_snsgroupdetail_board_listitem_like);
			final TextView tvLike = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_like);
			layoutReply.setTag(data.m_nThreadNo);
			layoutLike.setTag(data.m_isLiked);
			if(data.m_isLiked) {
				ivLike.setBackgroundResource(R.drawable.ic_btn_like_click);
				tvLike.setText("" + data.m_nLikeCount);
			} else {
				ivLike.setBackgroundResource(R.drawable.ic_btn_like);
				tvLike.setText("" + data.m_nLikeCount);
			}
			layoutReply.setOnClickListener(m_onReplyClickListener);
			layoutLike.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(final View v) {
					if(!(boolean)v.getTag()){

						PostBoardLikeReq reqGroupNotice = new PostBoardLikeReq(m_nGroupId, data.m_nThreadNo);
						WebAPI webApi = new WebAPI(SNSGroupDetailHashtagAct.this);
						webApi.request(reqGroupNotice, new WebListener() {

							@Override
							public void onPreRequest() {
								// TODO Auto-generated method stub

							}

							@Override
							public void onNetworkError(int nErrorCode, String strMessage) {
								// TODO Auto-generated method stub
								showErrorPopup(nErrorCode, strMessage);
							}

							@Override
							public void onPostRequest(String a_strData) {
								// TODO Auto-generated method stub
								//원래 좋아요 상태가 아니었던 경우
								ivLike.setBackgroundResource(R.drawable.ic_btn_like_click);
								if(!data.m_isLiked)
									tvLike.setText("" + (data.m_nLikeCount+1));
									//원래 좋아요 상태 였던 경우
								else
									tvLike.setText("" + (data.m_nLikeCount));
								v.setTag(true);
							}
						});
					} else {
						DeleteBoardLikeReq reqGroupNotice = new DeleteBoardLikeReq(m_nGroupId, data.m_nThreadNo);
						WebAPI webApi = new WebAPI(SNSGroupDetailHashtagAct.this);
						webApi.request(reqGroupNotice, new WebListener() {

							@Override
							public void onPreRequest() {
								// TODO Auto-generated method stub

							}

							@Override
							public void onNetworkError(int nErrorCode, String strMessage) {
								// TODO Auto-generated method stub
								showErrorPopup(nErrorCode, strMessage);
							}

							@Override
							public void onPostRequest(String a_strData) {
								// TODO Auto-generated method stub
								//원래 좋아요 상태가 아니었던 경우
								ivLike.setBackgroundResource(R.drawable.ic_btn_like);
								if(!data.m_isLiked)
									tvLike.setText("" + (data.m_nLikeCount));
									//원래 좋아요 상태 였던 경우
								else
									tvLike.setText("" + (data.m_nLikeCount-1));
								v.setTag(false);
							}
						});
					}
				}
			});
			
			RelativeLayout layoutAttachFileList = (RelativeLayout)convertView.findViewById(R.id.layout_snsgroupdetail_listitem_contents_attachfiles);
			RelativeLayout layoutPicture1 = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_contents_pics_1);
			ImageView ivPicture1 = (ImageView)convertView.findViewById(R.id.iv_one_pic_image);
			ImageView ivVodPic1 = (ImageView)convertView.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay_for_oneImage);
			LinearLayout layoutPicture2 = (LinearLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_contents_pics_2);
			ImageView ivPicture2_1 = (ImageView)convertView.findViewById(R.id.iv_two_pic_image1);
			ImageView ivVodPic2_1 = (ImageView)convertView.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay_image1);
			ImageView ivPicture2_2 = (ImageView)convertView.findViewById(R.id.iv_two_pic_image2);
			ImageView ivVodPic2_2 = (ImageView)convertView.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay_image2);
			HorizontalScrollView hsImages = (HorizontalScrollView)convertView.findViewById(R.id.hs_sns_images);
			LinearLayout layoutImage = (LinearLayout)convertView.findViewById(R.id.layout_sns_image);
			ArrayList<ChannelFileData> arrPictureData = new ArrayList<ChannelFileData>();
			ArrayList<ChannelFileData> arrFileData = new ArrayList<ChannelFileData>();
			if(data.m_arrChannelFileData != null && data.m_arrChannelFileData.size() > 0)
			{			
				for(ChannelFileData fileData : data.m_arrChannelFileData)
				{
					if(fileData.m_strType.equals(StaticString.FILE_TYPE_IMAGE) || fileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO))
					{

						arrPictureData.add(fileData);
					}
					else
					{
						arrFileData.add(fileData);						
					}
				}
				if(arrFileData.size() > 0)
				{
					TextView tvAllFileCount = (TextView)layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_allfilecount);
					tvAllFileCount.setText("" + arrFileData.size());
					layoutAttachFileList.setVisibility(View.VISIBLE);
					
					//View vFile = li.inflate(R.layout.layout_snsboarddetail_listitem_file, layoutAttachFileList, false);
					TextView tvFileName = (TextView)layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_listitem_file_filename);
					tvFileName.setText(arrFileData.get(0).m_strFileName);
				/*	TextView tvFileSize = (TextView)layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_listitem_file_filesize);

					float fFileSize = Utils.bytesToMegabyteFloat(arrFileData.get(0).m_lnFileSize);
					if(fFileSize == 0.0)
						fFileSize = 0.1F;
					
					tvFileSize.setText(String.format(getString(R.string.snsboarddetail_filesize), fFileSize));*/
				}
				else{
					
					layoutAttachFileList.setVisibility(View.GONE);
				}
				if(arrPictureData != null && arrPictureData.size() == 1) {
					layoutPicture1.setVisibility(View.VISIBLE);
					ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSGroupDetailHashtagAct.this);
					imageLoaderMng.cancelDownload(ivPicture1);
					Bitmap bmp = imageLoaderMng.getLocalImage(arrPictureData.get(0).m_strPreviewUrl);
					if(bmp == null)
						imageLoaderMng.getImage(ivPicture1, arrPictureData.get(0).m_strPreviewUrl, 0);
					else
						ivPicture1.setImageBitmap(bmp);
					layoutPicture2.setVisibility(View.GONE);
					hsImages.setVisibility(View.GONE);
					if(arrPictureData.get(0).m_strType.equals(StaticString.FILE_TYPE_VIDEO)){
						ivVodPic1.setVisibility(View.VISIBLE);
					} else
						ivVodPic1.setVisibility(View.GONE);
				} else if(arrPictureData != null && arrPictureData.size() == 2){
					layoutPicture2.setVisibility(View.VISIBLE);
					ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSGroupDetailHashtagAct.this);
					imageLoaderMng.cancelDownload(ivPicture2_1);
					Bitmap bmp = imageLoaderMng.getLocalImage(arrPictureData.get(0).m_strPreviewUrl);
					if(bmp == null)
						imageLoaderMng.getImage(ivPicture2_1, arrPictureData.get(0).m_strPreviewUrl, 0);
					else
						ivPicture2_1.setImageBitmap(bmp);
					if(arrPictureData.get(0).m_strType.equals(StaticString.FILE_TYPE_VIDEO)){
						ivVodPic2_1.setVisibility(View.VISIBLE);
					} else
						ivVodPic2_1.setVisibility(View.GONE);

					imageLoaderMng.cancelDownload(ivPicture2_2);
					Bitmap bmp2 = imageLoaderMng.getLocalImage(arrPictureData.get(1).m_strPreviewUrl);
					if(bmp == null)
						imageLoaderMng.getImage(ivPicture2_2, arrPictureData.get(1).m_strPreviewUrl, 0);
					else
						ivPicture2_2.setImageBitmap(bmp2);
					if(arrPictureData.get(1).m_strType.equals(StaticString.FILE_TYPE_VIDEO)){
						ivVodPic2_2.setVisibility(View.VISIBLE);
					} else
						ivVodPic2_2.setVisibility(View.GONE);


					layoutPicture1.setVisibility(View.GONE);
					hsImages.setVisibility(View.GONE);
				} else if(arrPictureData != null && arrPictureData.size() >= 3){
					hsImages.setVisibility(View.VISIBLE);
					layoutImage.removeAllViews();
					ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSGroupDetailHashtagAct.this);
					for(ChannelFileData fileData : arrPictureData) {
						final RelativeLayout snsScrollImage = (RelativeLayout) getLayoutInflater().inflate(R.layout.layout_snsgroupdetail_listitem_picture, null);
						ImageView ivSNSImage = (ImageView)snsScrollImage.findViewById(R.id.iv_snsgroupdetail_listitem_picture);
						imageLoaderMng.cancelDownload(ivSNSImage);
						Bitmap bmp = imageLoaderMng.getLocalImage(fileData.m_strPreviewUrl);
						if (bmp == null)
							imageLoaderMng.getImage(ivSNSImage, fileData.m_strPreviewUrl, 0);
						else
							ivSNSImage.setImageBitmap(bmp);

						ImageView ivVodPlay = (ImageView) snsScrollImage.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay);
						if (fileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
							ivVodPlay.setVisibility(View.VISIBLE);
						} else
							ivVodPlay.setVisibility(View.GONE);

						snsScrollImage.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								startSNSBoardDetailAct(false, m_nGroupId, m_strGroupName, data.m_nThreadNo, false, false, false);
							}
						});
						layoutImage.addView(snsScrollImage);
					}
					layoutPicture1.setVisibility(View.GONE);
					layoutPicture2.setVisibility(View.GONE);
				} else {
					/*	if(vpPictures3.getAdapter() != null)
						{
							PicturePagerAdapter pictureAdapter = (PicturePagerAdapter)vpPictures3.getAdapter();
						}*/
					layoutPicture1.setVisibility(View.GONE);
					layoutPicture2.setVisibility(View.GONE);
					hsImages.setVisibility(View.GONE);
				}
			} else {
				layoutAttachFileList.setVisibility(View.GONE);
				layoutPicture1.setVisibility(View.GONE);
				layoutPicture2.setVisibility(View.GONE);
				hsImages.setVisibility(View.GONE);
			}
			return convertView;
		}
		
		private OnClickListener m_onReplyClickListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Integer nBoardId = (Integer)v.getTag();
				startSNSBoardDetailAct(false, m_nGroupId, m_strGroupName, nBoardId, true, false, false);
			}
		};

		private OnClickListener m_onBackgroundClickListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				Integer nBoardId = (Integer)v.getTag();
				startSNSBoardDetailAct(false, m_nGroupId, m_strGroupName, nBoardId, false, false, false);
			}
		};

		/*private OnClickListener m_onWriteReplyClickListener = new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Integer nBoardId = (Integer)v.getTag();
				startSNSBoardDetailAct(false, m_nGroupId, m_strGroupName, nBoardId, false, true, false);
			}
		};*/

	}
	
	private class PicturePagerAdapter extends PagerAdapter
	{
		private SNSGroupSearchListData m_boardData = null;
		private ArrayList<SNSBoardFileData> m_arrBoardFileData = null;
//		public PicturePagerAdapter(ArrayList<SNSBoardFileData> a_arrBoardFileData) {
//			// TODO Auto-generated constructor stub
//			super();
//			m_arrBoardFileData = a_arrBoardFileData;
//		}
		public PicturePagerAdapter(SNSGroupSearchListData a_boardData, ArrayList<SNSBoardFileData> a_arrBoardFileData) {
			super();
			m_boardData = a_boardData;
			m_arrBoardFileData = a_arrBoardFileData;
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return m_arrBoardFileData.size();
		}

		@Override
		public Object instantiateItem(View container, int position) {
			// TODO Auto-generated method stub
			// ViewPager에서 사용할 뷰객체 생성 및 들록
			CommonLog.e(getClass(), "instantiateItem");
			View vContent = null;
			LayoutInflater li = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
			vContent = li.inflate(R.layout.layout_snsgroupdetail_listitem_picture, null);
			
			SNSBoardFileData data = m_arrBoardFileData.get(position);
			
			ImageView ivPicture = (ImageView)vContent.findViewById(R.id.iv_snsgroupdetail_listitem_picture);
			ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSGroupDetailHashtagAct.this);
			imageLoaderMng.cancelDownload(ivPicture);
			Bitmap bmp = imageLoaderMng.getLocalImage(data.m_strPreviewFileURL);
			if(bmp == null)
				imageLoaderMng.getImage(ivPicture, data.m_strPreviewFileURL, 0);
			else
				ivPicture.setImageBitmap(bmp);
			
			ImageView ivVodPlay = (ImageView)vContent.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay);
			if(data.m_strFileType.equals(StaticString.FILE_TYPE_VIDEO))
				ivVodPlay.setVisibility(View.VISIBLE);
			else
				ivVodPlay.setVisibility(View.GONE);
			
			vContent.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					startSNSBoardDetailAct(false, m_nGroupId, m_strGroupName, m_boardData.m_nBoardNo, false, false, false);
				}
			});
			
			((ViewPager)container).addView(vContent, 0);
			
			return vContent;
		}
		
		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			// instantiateImage Method에서 생성한 객체를 이용할 것인지 여부를 반환 한다.
			return arg0 == arg1;
		}
		
		@Override
		public void destroyItem(View container, int position, Object object) {
			// TODO Auto-generated method stub
			// View 객체를 삭제 
			ImageView ivPicture = (ImageView)((View)object).findViewById(R.id.iv_snsgroupdetail_listitem_picture);
			ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSGroupDetailHashtagAct.this);
			imageLoaderMng.cancelDownload(ivPicture);
			((ViewPager)container).removeView((View)object);
		}
		
		@Override 
		public void restoreState(Parcelable arg0, ClassLoader arg1) 
		{
			// saveState Method 상태에서 저장했던 Adapter와 Pager를 복구 한다.
		}
		
		@Override 
		public Parcelable saveState() 
		{
			// 현재 UI 상태를 저장하기 위해 Adapter와 Page 관련 인스턴스 상태를 저장.
			return null;
		}
		
		@Override
		public void startUpdate(View arg0)
		{
			// 페이지 변경이 시작될 때 호출
		}
		
		@Override
		public void finishUpdate(View arg0)
		{
			// 페이지 변경이 완료 됐을때 호출
		}

	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}

	private void getBoardDetailData(final int a_nBoardId)
	{
		GetGroupBoardReq req = new GetGroupBoardReq(m_nGroupId, a_nBoardId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetGroupBoardRes res = new GetGroupBoardRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_THREAD);
				ChannelThreadData snsBoardData = res.getChannelThreadData();
				
				for(ChannelThreadData data : m_SNSGroupSearchListDatas)
				{
					if(a_nBoardId == data.m_nThreadNo)
					{
						data.m_strBody = snsBoardData.m_strBody;
						data.m_nCommentCount = snsBoardData.m_nCommentCount;
//						data.m_arrBoardFileData = snsBoardData.m_arrBoardFileData;
						data.m_isLiked = snsBoardData.m_isLiked;
						data.m_nLikeCount = snsBoardData.m_nLikeCount;
						break;
					}
				}
				m_adapterBoardList.notifyDataSetChanged();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSGroupDetailHashtagAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

}
