package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.ApprovalPendingListData;
import com.gmp.rusk.utils.CommonLog;

public class GetPartnerApprovalListRes extends Res{
//	private final String JSON_REQUESTCOUNT				= "requestCount";
	private final String JSON_REQUESTS					= "requests";
	private final String JSON_USERNO		 			= "userNo";
	private final String JSON_NAME			 			= "name";
	private final String JSON_AFFILIATION					= "affiliation";
	private final String JSON_MOBILE					= "mobile";
	
	public int m_strRequestCount = 0;
	
	ArrayList<ApprovalPendingListData> m_arrApprovalPendingListDatas = null;
	
	public GetPartnerApprovalListRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_REQUESTS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_REQUESTS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrApprovalPendingListDatas = new ArrayList<ApprovalPendingListData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						int nUserNo = jsonItem.optInt(JSON_USERNO);
						String strName = jsonItem.optString(JSON_NAME);
						String strCompany = jsonItem.optString(JSON_AFFILIATION);
						String strMobile = jsonItem.optString(JSON_MOBILE);
						
						ApprovalPendingListData item = new ApprovalPendingListData(nUserNo, strName, strCompany, strMobile);
						
						m_arrApprovalPendingListDatas.add(item);
					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	public ArrayList<ApprovalPendingListData> getApprovalPendingList()
	{
		return m_arrApprovalPendingListDatas;
	}
}
