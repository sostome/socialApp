package com.gmp.rusk.request;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author subi78
 *			정회원 검색 
 *			method : post
 */

public class PostSearchRegularReq extends Req{
	
	private String APINAME = "search";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	private final String JSON_KEYWORD = "keyword";
	
	private String m_strKeyword = "";
	
	public PostSearchRegularReq(String a_strKeyword, int a_nPage)
	{
		APINAME = APINAME +"/regular/10000/"+a_nPage;
		m_strKeyword = a_strKeyword;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_KEYWORD, m_strKeyword);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PostSearchApprovalUserReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
