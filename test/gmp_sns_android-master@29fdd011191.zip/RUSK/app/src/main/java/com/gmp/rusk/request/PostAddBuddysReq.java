package com.gmp.rusk.request;



/**
 *	@author subi78
 *			동료 추가
 *			method : post
 */

public class PostAddBuddysReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	
	public PostAddBuddysReq(int[] a_nArrBuddyNos)
	{
		String strBuddyNos = "";
		for(int i=0;i<a_nArrBuddyNos.length;i++)
		{
			strBuddyNos = strBuddyNos + a_nArrBuddyNos[i];
			
			if(i < a_nArrBuddyNos.length-1)
				strBuddyNos = strBuddyNos + ",";
		}
		APINAME = APINAME + "/" + App.m_EntryData.m_nUserNo + "/buddy/" + strBuddyNos; 
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
