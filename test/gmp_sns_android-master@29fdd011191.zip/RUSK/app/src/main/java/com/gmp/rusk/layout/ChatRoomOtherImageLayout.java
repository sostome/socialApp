package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.ChatRoomImageAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomImageView;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;

/**
 * ChatRoomOtherImageLayout 채팅방 다른사람 이미지 List Item Layout
 */
public class ChatRoomOtherImageLayout extends CustomLinearLayout implements OnClickListener, OnLongClickListener {
	// Context m_Context;
	// int m_nNumber;
	// String m_strOtherImageUrl, m_strOtherImageThumbUrl, m_strOtherName, m_strRoomID;
	// ArrayList<Integer> m_arrRead;
	CustomImageView m_ivOtherImageWidth;
	// ArrayList<Integer> m_arrTotalRead;
	TextView m_tvChatOtherImageNosee, m_tvChatOtherImageTime, m_tvChatOtherName;;
	// long m_lTime;
	// int m_nSendStatus;
	ImageView m_ivOtherImage, m_ivNotFellowImage ,m_ivOtherProfileFrame,m_ivPartnerIcon;
	// String m_strMessageID;
	// int m_nWidth, m_nHeight;
	// boolean m_isAvailable;
	CommonPopup m_Popup;

	private boolean isAbleClick = true;

	private ChatRoomData m_ChatRoomData = null;
	private CommonListPopup m_ListPopup = null;

	public ChatRoomOtherImageLayout(Context context) {
		super(context);
		// m_strOtherImageUrl = a_strOtherImageUrl;
		// m_nSendStatus = a_nSendStatus;
		// m_strOtherImageThumbUrl = a_strOtherImageThumbUrl;
		// m_nNumber = a_nNumber;
		// m_arrRead = a_arrRead;
		// m_strOtherName = a_strOtherName;
		// m_strRoomID = a_strRoomID;
		// m_arrTotalRead = a_arrTotalRead;
		// m_lTime = a_lDate;
		// m_strMessageID = a_strMessageID;
		// m_nWidth = a_nWidht;
		// m_nHeight = a_nHeight;
		// m_isAvailable = a_isAvailable;
		init();

	}

	private void init() {

		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
		li.inflate(R.layout.layout_chat_room_otherimage, this, true);

		m_tvChatOtherImageNosee = (TextView) findViewById(R.id.tv_chat_otherimage_nosee);
		m_tvChatOtherImageTime = (TextView) findViewById(R.id.tv_chat_otherimage_time);

		m_ivOtherImageWidth = (CustomImageView) findViewById(R.id.iv_chat_otherimage_width);
		m_ivOtherImage = (ImageView) findViewById(R.id.iv_chat_otherimage);
		m_ivPartnerIcon = (ImageView) findViewById(R.id.iv_chatroom_icon_partner);
		m_tvChatOtherName = (TextView) findViewById(R.id.tv_chat_image_othername);
		m_ivNotFellowImage = (ImageView) findViewById(R.id.iv_profile_notfellow_pic);
		m_ivOtherProfileFrame = (ImageView) findViewById(R.id.iv_profile_other_frame);

		m_tvChatOtherImageNosee.setOnClickListener(this);
		m_ivOtherImageWidth.setOnClickListener(this);
		m_ivOtherImageWidth.setOnLongClickListener(this);
		m_tvChatOtherImageTime.setOnClickListener(this);
		m_ivOtherImage.setOnClickListener(this);
	}

	public void setChatRoomData(ChatRoomData a_Data) {
		m_ChatRoomData = a_Data;

		if(a_Data.m_strRoomID.split("_").length == 3){
			m_ivOtherImageWidth.setBackgroundResource(R.drawable.btn_group_balloon_friend);
			m_ivOtherProfileFrame.setBackgroundResource(R.drawable.img_profile_talk);
			m_tvChatOtherImageNosee.setTextColor(Color.parseColor("#e04f07"));
		} else {
			m_ivOtherImageWidth.setBackgroundResource(R.drawable.btn_chat_balloon_friend);
			m_ivOtherProfileFrame.setBackgroundResource(R.drawable.img_profile_talk);
			m_tvChatOtherImageNosee.setTextColor(Color.parseColor("#e04f07"));
		}

		m_tvChatOtherName.setText(m_ChatRoomData.m_strName);

//		UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(getContext(), m_ChatRoomData.m_nNO);
		if (m_ChatRoomData.m_isImageAvailable) {
			App.imageloader.cancelDownload(m_ivOtherImage);
			App.imageloader.getProfileImage(m_ivOtherImage, App.getImageDownLoaderUrl(m_ChatRoomData.m_nNO, true), R.drawable.profile_pic_default, false);
			
		} else
		{
			App.imageloader.cancelDownload(m_ivOtherImage);
			m_ivOtherImage.setImageResource(R.drawable.profile_pic_default);
		}
		if(m_ChatRoomData.m_strSenderType.equals("R")){
			m_ivPartnerIcon.setVisibility(GONE);
		} else {
			m_ivPartnerIcon.setVisibility(VISIBLE);
		}
//		boolean isFellow = userData != null && userData.m_isFellow;
//		boolean isRegular = userData != null && AppSetting.FEATURE_VARIANT.equals("R") && userData.m_strUserType.equals("R"); 
//		if(!isFellow && !isRegular){
//			if(userData != null && App.m_MyUserInfo.m_nUserNo == userData.m_nUserNo){
//				m_ivNotFellowImage.setVisibility(View.GONE);			
//			}
//			else {
//				m_ivNotFellowImage.setVisibility(View.VISIBLE);
//			}
//		} else {
//			m_ivNotFellowImage.setVisibility(View.GONE);
//		}
		if(m_ChatRoomData.m_isSmileView){
			m_ivNotFellowImage.setVisibility(View.VISIBLE);
		} else {
			m_ivNotFellowImage.setVisibility(View.GONE);
		}
		// 올린 시간
		String pattern = "a h:mm";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String date = (String) format.format(new Timestamp(m_ChatRoomData.m_lDate));

		int nNoReadCount = 0;
		//nNoReadCount = m_ChatRoomData.m_arrTotalRead.size() - m_ChatRoomData.m_arrRead.size();
		nNoReadCount = m_ChatRoomData.m_nNoReadCount;
		if (nNoReadCount == 0) {
			m_tvChatOtherImageNosee.setText("");
			m_tvChatOtherImageNosee.setVisibility(View.GONE);
		} else if (nNoReadCount < 0) {
			m_tvChatOtherImageNosee.setText("");
			m_tvChatOtherImageNosee.setVisibility(View.GONE);
		} else {
			m_tvChatOtherImageNosee.setText("" + nNoReadCount);
			m_tvChatOtherImageNosee.setVisibility(View.VISIBLE);
		}
		m_tvChatOtherImageTime.setText(date);
		
		int height = m_ChatRoomData.m_nHeight;
		int width = m_ChatRoomData.m_nWidht;
		
		
		if (width >= height && width > 290) {
			height = (height * 290) / width;
			width = 290;
		} else if (width < height && height > 290) {
			width = (width * 290) / height;
			height = 290;
		}
		m_ivOtherImageWidth.setMinimumHeight(height+70);
		m_ivOtherImageWidth.setMinimumWidth(width+70);
		
		if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_SUCCESS) {
		
			ImageLoaderManager imageloader = ImageLoaderManager.getInstance(getContext());
			Bitmap thumbBitmap = imageloader.getLocalRoundImage(m_ChatRoomData.m_strOtherImageThumbUrl);
			if(thumbBitmap == null)
				imageloader.getImageRound(m_ivOtherImageWidth, m_ChatRoomData.m_strOtherImageThumbUrl, 0, m_ImageLoaderListener);
			else
				m_ivOtherImageWidth.setImageBitmap(thumbBitmap);
			// CustomImageView customImageView = CustomImageView.getInstance(getContext());
			// customImageView.getImage(m_ivOtherImageWidth, m_ChatRoomData.m_strOtherImageThumbUrl, 0, m_ChatRoomData.m_nWidht, m_ChatRoomData.m_nHeight);

		} else {
			m_ivOtherImageWidth.setImageBitmap(null);
			
			m_tvChatOtherImageTime.setOnClickListener(null);
			// setImageLoadTask task = new setImageLoadTask();
			// task.execute();
		}

	}

	ImageLoaderManager.ImageLoaderListener m_ImageLoaderListener = new ImageLoaderManager.ImageLoaderListener() {

		@Override
		public void onSuccess() {
			// TODO Auto-generated method stub
			if (m_ChatRoomData.m_strRoomID.length() > 8) {
				//((ChatRoomGroupAct) getContext()).setDataChanged();
			} else {
				//((ChatRoomAct) getContext()).setDataChanged();
			}
		}

		@Override
		public void onFail(String a_strErrorMsg) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onNotModified() {
			// TODO Auto-generated method stub

		}
	};

	// public class setImageLoadTask extends AsyncTask<Void, Void, Bitmap> {
	//
	// @Override
	// protected Bitmap doInBackground(Void... params) {
	// // TODO Auto-generated method stub
	// CommonLog.e(getContext(), "경로 : " + m_ChatRoomData.m_strOtherImageUrl);
	//
	// Bitmap bmp = BitmapFactory.decodeFile(Uri.fromFile(new File(m_ChatRoomData.m_strOtherImageUrl)).getPath());
	// int height = m_ChatRoomData.m_nHeight;
	// int width = m_ChatRoomData.m_nWidht;
	//
	// Bitmap resizedBmp = null;
	//
	// if (width >= height) {
	// height = (height * 500) / width;
	// width = 500;
	// } else if (width < height) {
	// width = (width * 400) / height;
	// height = 400;
	// }
	//
	// resizedBmp = Bitmap.createScaledBitmap(bmp, width, height, true);
	//
	// return resizedBmp;
	// }
	//
	// protected void onPostExecute(Bitmap resizedBmp) {
	//
	// m_ivOtherImageWidth.setImageBitmap(resizedBmp);
	//
	// }
	//
	// }

	@Override
	public void onClick(View v) {

		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				isAbleClick = true;
			}

		};

		if (isAbleClick) {

			Timer mTimer = new Timer();
			mTimer.schedule(task, 500);

			isAbleClick = false;

			switch (v.getId()) {
			case R.id.iv_chat_otherimage_width:
				if((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
						App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled){
					m_Popup = new CommonPopup(getContext(), ChatRoomOtherImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title), getContext().getString(R.string.cork_pop_fail_open_file));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					Intent intent = new Intent(getContext(), ChatRoomImageAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_IMAGE_PATH, m_ChatRoomData.m_strOtherImageUrl);
					intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_ROOM_ID, m_ChatRoomData.m_strRoomID);
					intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_MESSAGE_ID, m_ChatRoomData.m_strMessageID);

					getContext().startActivity(intent);
				}
				break;
			case R.id.tv_chat_otherimage_nosee:
			case R.id.tv_chat_otherimage_time:

				break;
			case R.id.ib_pop_ok:
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				if (m_ChatRoomData.m_strRoomID.length() < 8) {
					((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
				} else {
					((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
				}
				popup_ok.cancel();
				break;
			case R.id.ib_pop_cancel:
				CommonPopup popup_cancel = (CommonPopup)v.getTag();
				popup_cancel.cancel();
				break;
			case R.id.ib_pop_ok_long:
				CommonPopup popup_ok_long = (CommonPopup)v.getTag();
				popup_ok_long.cancel();
				break;
			case R.id.iv_chat_otherimage:
				Intent intentProfile = new Intent(getContext(), ProfileViewPopupAct.class);
				//intentProfile.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intentProfile.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_ChatRoomData.m_nNO);
				intentProfile.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_ChatRoomData.m_strRoomID);
				getContext().startActivity(intentProfile);
				break;
			case R.id.ib_pop_cancel_long:
				m_ListPopup.cancel();
				break;
			case R.id.tv_pop_first_row:
				m_ListPopup.cancel();
				if (System.currentTimeMillis() >= m_ChatRoomData.m_lDate + 1814400000){
					m_Popup = new CommonPopup(getContext(), ChatRoomOtherImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title),
							getContext().getString(R.string.popup_send_other_fail));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
//				m_Popup = new CommonPopup(getContext(), ChatRoomOtherImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
//				m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title), getContext().getString(R.string.popup_delete_text_text));
//				m_Popup.setCancelable(false);
//				m_Popup.show();
				if (m_ChatRoomData.m_strRoomID.length() < 8) {
					((ChatRoomAct) getContext()).sendFileOther(m_ChatRoomData.m_JsonObject.toString());
				} else {
					((ChatRoomGroupAct) getContext()).sendFileOther(m_ChatRoomData.m_JsonObject.toString());
				}
				}
				break;
			case R.id.tv_pop_second_row:
				m_ListPopup.cancel();
				m_Popup = new CommonPopup(getContext(), ChatRoomOtherImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title), getContext().getString(R.string.popup_delete_text_text));
				m_Popup.setCancelable(false);
				m_Popup.show();
				break;
			default:
				break;
			}
		}

	}

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_chat_otherimage_width:
			m_ListPopup = new CommonListPopup(getContext(), ChatRoomOtherImageLayout.this);
			m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_file_longclick_type));
			m_ListPopup.setCancelable(true);
			m_ListPopup.show();

			break;

		default:
			break;
		}
		return true;
	}
}
