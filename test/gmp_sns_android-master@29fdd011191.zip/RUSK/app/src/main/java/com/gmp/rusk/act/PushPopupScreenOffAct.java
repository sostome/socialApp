package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.broadcastreceiver.PushBroadcastReceiver;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PushWakeLock;
import com.gmp.rusk.utils.SharedPref;

public class PushPopupScreenOffAct extends Activity implements OnClickListener {
	
	private final String TAG = PushPopupScreenOffAct.class.getSimpleName();
	
	public static boolean m_isPushPopupRunning = false;
	
	public static PushPopupScreenOffAct m_Instance = null; 
	
	private int m_nFriendUserNo = 0;
	private String m_strGroupId = "";
	private String m_strPushType = "";
	private String m_strName = "";
	
	private int m_nSNSGroupId = -1;
	private int m_nSNSBoardId = -1;
	private int m_nSNSReplyId = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		m_Instance = this;
		m_isPushPopupRunning = true;
		
		getWindow().addFlags(
				WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
				WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
				WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

		this.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.act_pushpopup_screenoff);
		
		setUi(getIntent());
	}
	
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		CommonLog.e(TAG, "onNewIntent");
		PushWakeLock.acquireCpuWakeLock(this);
		PushWakeLock.releaseCpuLock();
		setUi(intent);
		super.onNewIntent(intent);
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		
		m_Instance = null;
		m_isPushPopupRunning = false;
	}
	
	private void setUi(Intent intent)
	{
		m_nFriendUserNo = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_USERNO, 0);
		m_strName = intent.getStringExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_NAME);
		String strMsg = intent.getStringExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_MESSAGE);
		String strImageUrl = intent.getStringExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_IMGURL);
		m_strGroupId = intent.getStringExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_GID);
		m_strPushType = intent.getStringExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_PUSHTYPE);
		
		ImageView ivPic = (ImageView)findViewById(R.id.iv_pushpopup_pic);
		ImageView ivNotFellowPic = (ImageView)findViewById(R.id.iv_pushpopup_notfellow_pic);
		LinearLayout layoutDetail = (LinearLayout)findViewById(R.id.layout_pushpopup_detail);
		TextView tvDefaultMsg = (TextView)findViewById(R.id.tv_pushpopup_defaultmsg);
		
		if(!TextUtils.isEmpty(strImageUrl))
		{
			ImageLoaderManager imageLoader = ImageLoaderManager.getInstance(this);
			//imageLoader.getImage(ivPic, strImageUrl, R.drawable.notice_profile_pic_frame);
			//ivPic.setImageBitmap(imageLoader.getImage(strImageUrl, R.drawable.notice_profile_pic_frame));
			imageLoader.getImage(ivPic, strImageUrl, R.drawable.notice_profile_pic_frame);
			ivNotFellowPic.setVisibility(View.GONE);
		}
		else
		{
			if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_REQUEST))
			{
				ivPic.setImageResource(R.drawable.ic_launcher);
			} 
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_BOARD))
			{
				ivPic.setImageResource(R.drawable.ic_launcher);
				m_nSNSGroupId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSGROUPID, -1);
				m_nSNSBoardId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSBOARDID, -1);
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_REPLY))
			{
				ivPic.setImageResource(R.drawable.ic_launcher);
				m_nSNSGroupId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSGROUPID, -1);
				m_nSNSBoardId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSBOARDID, -1);
				m_nSNSReplyId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSREPLYID, -1);
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_INVITE))
			{
				ivPic.setImageResource(R.drawable.ic_launcher);
			}
			else {
				if(m_nFriendUserNo == 0 && m_strName.equals("cork.com")){
					ivPic.setImageResource(R.drawable.ic_launcher);
					m_strName = getString(R.string.app_name);
				} else {
					ivPic.setImageResource(R.drawable.profile_pic_default);
					ivNotFellowPic.setVisibility(View.GONE);
				}
			}
		}
		
		SharedPref pref = SharedPref.getInstance(this);
		boolean isPreview = pref.getBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
		if(isPreview)
		{
			layoutDetail.setVisibility(View.VISIBLE);
			tvDefaultMsg.setVisibility(View.GONE);
			TextView tvName = (TextView)findViewById(R.id.tv_pushpopup_name);
			TextView tvMsg = (TextView)findViewById(R.id.tv_pushpopup_msg);
			tvName.setText(m_strName);
			
			EmoticonUtils emoticonUtils = new EmoticonUtils();
			
			tvMsg.setText(emoticonUtils.parsingEmoticonText(this, strMsg, (int)tvMsg.getTextSize()));
		}
		else
		{
			layoutDetail.setVisibility(View.GONE);
			tvDefaultMsg.setVisibility(View.VISIBLE);
		}
		
		Button btnShow = (Button)findViewById(R.id.btn_pushpopup_show);
		Button btnClose = (Button)findViewById(R.id.btn_pushpopup_close);
		btnShow.setOnClickListener(this);
		btnClose.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.btn_pushpopup_show)
		{
			Intent intent = null;
			if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_MSG))
			{
				if(m_strGroupId != null)
				{
					intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_MESSAGE_GROUP);
					intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_GROUPID, m_strGroupId);
				}
				else
				{
					intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_MESSAGE_NORMAL);
					if(m_nFriendUserNo == 0 && m_strName.equals(getString(R.string.app_name))){
						intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_USERID, 1);
					} else {
						intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_USERID, m_nFriendUserNo);
					}
				}
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_REQUEST))
			{
				intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_APPROVALREQUEST);
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_KICK)){
				intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_KICK);
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_BOARD))
			{
				intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_SNS_BOARD);
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSGROUPID, m_nSNSGroupId);
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSBOARDID, m_nSNSBoardId);
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_REPLY))
			{
				intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_SNS_REPLY);
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSGROUPID, m_nSNSGroupId);
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSBOARDID, m_nSNSBoardId);
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSREPLYID, m_nSNSReplyId);
			}
			else if(m_strPushType.equals(IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_INVITE))
			{
				intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_SNS_INVITE);
			}
			
			if(intent != null)
			{
				sendBroadcast(intent);
			}
			finish();
		}
		else if(v.getId() == R.id.btn_pushpopup_close)
		{
			finish();
		}
	}
}
