package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class FileEx implements PacketExtension {
	public static final String NAMESPACE = "urn:xmpp:file";
	public static final String ELEMENT_NAME = "info";

	private String fileName;
	private String mimetype;
	private String url;
	private String width;
	private String height;
	private String thumb;
	private String docId;
	private String createTime;
	private String vdi;
	private String validUntil;

	public FileEx() {
	}

	public FileEx(String fileName, String mimetype, String url, String width, String height, String thumb, String docId, String creatTime, String vdi, String validUntil) {
		this.fileName = fileName;
		this.mimetype = mimetype;
		this.url = url;
		this.width = width;
		this.height = height;
		this.thumb = thumb;
		this.docId = docId;
		this.createTime = creatTime;
		this.vdi = vdi;
		this.validUntil = validUntil;
	}

	//
	//
	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return ELEMENT_NAME;
	}

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return NAMESPACE;
	}

	public String getFileName() {
		return this.fileName;
	}

	public String getMimetype() {
		return this.mimetype;
	}

	public String getUrl() {
		return this.url;
	}
	
	public String getWidth() {
		return this.width;
	}
	
	public String getHeight() {
		return this.height;
	}
	
	public String getThumb() {
		return this.thumb;
	}
	
	public String getDocId() {
		return this.docId;
	}
	
	public String getCreateTime(){
		return this.createTime;
	}

	public String getVdi() {
		return this.vdi;
	}

	public String getValidUntil() { return this.validUntil; }
	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		StringBuilder buf = new StringBuilder();
		// 1.5.5 에서 규격 수정됨

		// buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
		return buf.toString();
	}

	public static class Provider implements PacketExtensionProvider {

		public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
			String fileName = "";
			String mimetype = "";
			String url = "";
			String width = "0";
			String height = "0";
			String thumb = "";
			String docId = "";
			String createTime = "0";
			String vdi = "false";
			String validUntil = "";

			boolean done = false;
			int cnt = parser.getAttributeCount();
			for(int i = 0; i < cnt; i++){
				if(parser.getAttributeName(i).equals("isVdi")){
					vdi = parser.getAttributeValue(i);
				}
			}

			while (!done) {
				int eventType = parser.getEventType();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("fileName")) {
						fileName = parser.nextText();
					} else if (parser.getName().equals("mimetype")) {
						mimetype = parser.nextText();
					} else if (parser.getName().equals("url")) {
						url = parser.nextText();
					} else if (parser.getName().equals("width")) {
						width = parser.nextText();
					} else if (parser.getName().equals("height")) {
						height = parser.nextText();
					} else if (parser.getName().equals("thumb")) {
						thumb = parser.nextText();
					} else if (parser.getName().equals("docId")){
						docId = parser.nextText();
					} else if( parser.getName().equals("createTime")){
						createTime = parser.nextText();
					} else if( parser.getName().equals("validUntil")){
						validUntil = parser.nextText();
					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals(ELEMENT_NAME)) {
						done = true;
					}
				}
				if (!done)
					parser.next();
			}
			return new FileEx(fileName, mimetype, url, width, height, thumb, docId, createTime, vdi, validUntil);
		}
	}

	public String setFileExText(FileEx fileEx){


		return "";
	}
}