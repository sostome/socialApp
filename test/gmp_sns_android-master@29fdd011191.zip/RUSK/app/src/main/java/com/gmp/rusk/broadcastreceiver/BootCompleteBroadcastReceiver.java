package com.gmp.rusk.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.utils.SharedPref;

public class BootCompleteBroadcastReceiver extends BroadcastReceiver{

	public MyApp App = MyApp.getInstance();

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub

		if(App.m_EntryData == null) {
			SharedPref pref = SharedPref.getInstance(context);
			App.m_PartnerPW = "";
			pref.setStringPref(SharedPref.PREF_PARTNER_PW, "");
			pref.setStringPref(SharedPref.PREF_COOKIE, "");
		}
	}
}
