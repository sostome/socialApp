package com.gmp.rusk.datamodel;

public class FriendData {

}
