package com.gmp.rusk.datamodel;

import com.gmp.rusk.utils.AppSetting;

import java.util.ArrayList;

public class EntryData {
	
	public int m_nUserNo = 8007;	//정회원
	public String m_strUserId = "";
	public String m_strUserType = "";
	public String m_strName = "";
	public String m_strEmail = "";
	public String m_strMobile = "";
	public String m_strCompanyCode = "";
	public String m_strCompanyName = "";
	public String m_strDepartment = "";
	public String m_strDepartmentCode = "";
	public String m_strParentDepartment = "";
	public String m_strCharge = "";
	public String m_strSecondCharge = "";
	public String m_strAffiliation = "";
	public boolean m_isImageAvailable = false;
	public String m_strGreeting ="";
	public boolean m_isActive = false;

	public String m_strImageUrlTemplate = "";
	public String m_strPreviewImageUrlTemplate = "";
	//티니 이모티콘 때 추가
	public String m_strEmoticonTemplate = "";
	public String m_strLatestVersion = "";
	public String m_strLol = "";


	public ArrayList<CompanyData> m_arrCompanyData = new ArrayList<CompanyData>();

	public CompanyEntryData m_MultiTenancy = null;

	public EntryData(){

	}

}
