package com.gmp.rusk.request;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import com.bumptech.glide.util.Util;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.ResolveText;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

/**
 *	@author subi78
 *			파일 업로드
 *			method : post
 *			Accept Media Type: multipart/form-data
 */

public class PostFileUploadReq extends UploadReq{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	
	public PostFileUploadReq(int a_nUserNo)
	{
		APINAME = APINAME + "/" + a_nUserNo + "/file";
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}

	
	private Context m_Context = null;
	private Uri m_Uri = null;
	private String m_strFileType = "";
	private String m_strFileName = "";
	private byte[] m_byteFileData = null;
	
	public void setFileInfo(Context a_Context, Uri a_uriFile, String a_strFileName, String a_strFileType)
	{
		m_Context = a_Context;
		m_Uri = a_uriFile;
		m_strFileType = a_strFileType;
		m_strFileName = a_strFileName;
		m_byteFileData = null;
	}
	
	public void setImageFileInfo(byte[] a_byteData, String a_strFilePath)
	{
		m_Context = null;
		m_Uri = null;
		m_byteFileData = a_byteData;
		m_strFileType = StaticString.FILE_TYPE_IMAGE;

		String[] strsFileNames = a_strFilePath.split("/");
		String tempFileName = strsFileNames[strsFileNames.length - 1];
		String strRemoveDotName = "";
		if(tempFileName.contains("."))
			strRemoveDotName = tempFileName.split("\\.")[0];
		m_strFileName = strRemoveDotName + ".jpg";
	}
	
	private final String MULTIPART_KEY_FILE = "file";
	private final String MULTIPART_KEY_TYPE = "type";
	private final String MULTIPART_KEY_VIDEOPREVIEWFILE = "videoPreviewFile";
	
	@Override
	public MultipartEntity getMultiPartEntity()
	{
		byte[] data = null;
		String strFileName;
		//동영상 전송에만 사용
		byte[] previewData = null;
		String strPreviewName = "";
		if(m_strFileType.equals(StaticString.FILE_TYPE_IMAGE))
		{
			strFileName = m_strFileName;
			data = m_byteFileData;
		}
		else if(m_strFileType.equals(StaticString.FILE_TYPE_VIDEO))
		{
			String strPath = Utils.getPathFromUri(m_Context, m_Uri);
			data = getFileByte(strPath);
			String[] strsFileNames = strPath.split("/");
			strFileName = strsFileNames[strsFileNames.length - 1];

			Bitmap bitmap = Utils.getMiniThumbnailFromVideo(m_Context, m_Uri);
			previewData = Utils.bmpToByte(bitmap);
			strPreviewName = System.currentTimeMillis() + ".jpg";
		}
		else if(m_strFileType.equals(StaticString.FILE_TYPE_CONTACT))
		{
			data = getFileByte();
			strFileName = m_strFileName;
		}
		else
		{
			if(m_Uri.getScheme() != null && m_Uri.getScheme().equals("file"))
			{
				data = getFileByte();
				strFileName = m_Uri.getLastPathSegment();
			}
			else
			{
				data = getFileByteFromUri();
				strFileName = m_strFileName;
			}
		}
//		if(m_Uri == null && m_byteFileData != null)
//		{
//			data = m_byteFileData;
//			if(m_strFileType.equals(TYPE_IMAGE))
//				strFileName = System.currentTimeMillis() + ".jpg";
//			else
//				strFileName = System.currentTimeMillis() + "";
//		}
//		else
//		{
////			if(m_strFileType.equals(TYPE_NORMAL) && m_Uri != null)
//			if(m_strFileType.equals(TYPE_NORMAL) )
//			{
//				// 파일 첨부는 Uri로 가져오자
//				data = getFileByteFromUri();
//				strFileName = m_strFileName;
//			}
//			else
//			{
//				data = getFileByte();
//				String[] strsFileNames = m_strFilePath.split("/");
//				strFileName = strsFileNames[strsFileNames.length - 1];
//			}
//		}
		
		if(data != null)
		{
			MultipartEntity multiPart = new MultipartEntity();
			
			CommonLog.e(PostFileUploadReq.class.getSimpleName(), "file name : " + strFileName);
			ContentBody fileBody = new ByteArrayBody(data, strFileName);
			if(m_strFileType.equals(StaticString.FILE_TYPE_VIDEO)){
				ContentBody previewBody = new ByteArrayBody(previewData, strPreviewName);
				multiPart.addPart(MULTIPART_KEY_VIDEOPREVIEWFILE, previewBody);
			}
			multiPart.addPart(MULTIPART_KEY_FILE, fileBody);
			
			try {
				ContentBody typeBody = new StringBody(m_strFileType, Charset.forName("UTF-8"));
				multiPart.addPart(MULTIPART_KEY_TYPE, typeBody);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return multiPart;
		}
		else 
			return null;
	}
	
	private byte[] getFileByteFromUri()
	{
		byte[] readBuffer = null;
		InputStream inputStream = null;
		try {
			inputStream = m_Context.getContentResolver().openInputStream(m_Uri);
			readBuffer = new byte[inputStream.available()];
			while(inputStream.read(readBuffer) != -1)
			{
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(inputStream != null)
			{
				try {
					inputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return readBuffer;
	}
	
	private byte[] getFileByte()
	{
		return getFileByte(m_Uri.getPath());
	}
	
	private byte[] getFileByte(String a_strPath)
	{
		byte[] bArData = null;
		File file = new File(a_strPath);
		if(file != null && file.exists())
		{
			try {
				FileInputStream isFile = new FileInputStream(file);
				int nCount = isFile.available();
				if(nCount > 0)
				{
					bArData = new byte[nCount];
					isFile.read(bArData);
				}
				if(isFile != null)
				{
					isFile.close();
				}
			} 
			catch (FileNotFoundException e) {
				e.printStackTrace();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return bArData;
	}
}
