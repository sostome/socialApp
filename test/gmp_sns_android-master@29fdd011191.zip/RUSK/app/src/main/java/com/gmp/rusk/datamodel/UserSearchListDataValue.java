package com.gmp.rusk.datamodel;

public class UserSearchListDataValue {
	public int m_nUserNo = 0;					//사용자 번호
	public String m_strName = "";				//사용자 이름
	public String m_strCharge = "";			//직책, 일반 매니저의 경우에는 내려주지 않음
	public String m_strCompany = "";
	public String m_strSecondCharge = "";
	public String m_strPosition = "";
	public String m_strDepartment = "";		//부서명
	public String m_strParentDepartment = "";			//소속명
	public String m_strAffiliation = "";			//파트너 소속명
	public boolean m_isImageAvailable = false;	//이미지 보유 여부
	public boolean m_isAvailable = false;		//대화 가능 여부
	public boolean m_isChecked = false;
	public String m_strUserType = "";			//사용자 유형 R:정직원, P:파트너
	
	public UserSearchListDataValue(int a_nUserNo, String a_strName, String a_strCharge,String a_strCompany,String a_strSecondCharge,String a_strPosition, String a_strDepartment, String a_strAffliation, boolean a_isImageAvailable, boolean a_isAvailable, String a_strUserType) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCharge = a_strCharge;
		m_strCompany = a_strCompany;
		m_strSecondCharge = a_strSecondCharge;
		m_strPosition = a_strPosition;
		m_strDepartment = a_strDepartment;
		m_strAffiliation = a_strAffliation;
		m_isImageAvailable = a_isImageAvailable;
		m_isAvailable = a_isAvailable;
		m_strUserType = a_strUserType;
	}

	public UserSearchListDataValue(int a_nUserNo, String a_strName, String a_strCharge, String a_strDepartment, String a_strParentDepartment, String a_strCompany, boolean a_isImageAvailable, boolean a_isAvailable, String a_strUserType) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCharge = a_strCharge;
		m_strDepartment = a_strDepartment;
		m_strParentDepartment = a_strParentDepartment;
		m_strCompany = a_strCompany;
		m_isImageAvailable = a_isImageAvailable;
		m_isAvailable = a_isAvailable;
		m_strUserType = a_strUserType;
	}
}
