package com.gmp.rusk.db;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.database.Cursor;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ReadCountData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.StaticString;

public class ChattingDBManager {
	
	private ChattingDBAdapter m_ChattingDB = null;
	private Context m_Context = null;
	
	public ChattingDBManager(Context a_Context)
	{ 
		m_Context = a_Context;
	}
	
	/**
	 * openWritable Database Open Writable
	 * @param a_strRoomId 
	 */
	public void openWritable(String a_strRoomId)
	{
		m_ChattingDB = new ChattingDBAdapter(m_Context, a_strRoomId);
		m_ChattingDB.open();
	}
	
	/**
	 * openReadable Database Open Readable
	 * @param a_strRoomId
	 */
	public void openReadable(String a_strRoomId)
	{
		m_ChattingDB = new ChattingDBAdapter(m_Context, a_strRoomId);
		m_ChattingDB.openReadOnly();
	}
	
	/**
	 * close Database Close
	 */
	public void close()
	{
		m_ChattingDB.close();
		m_ChattingDB = null;
	}

	/**
	 * insertChattingUser 채팅방 참여 User Id List 추가
	 * 
	 * @param a_arrUserIdList
	 *            : 참가한 User Id List
	 * @return 추가한 Item의 개수
	 */
	public int insertChattingUser(ArrayList<Integer> a_arrUserIdList) {
		return m_ChattingDB.insertChattingUser(a_arrUserIdList);
	}

	/**
	 * insertChattingUser 채팅방 참여 User Id 추가
	 * 
	 * @param a_nUserNoList
	 *            : 참가한 User Id
	 * @return 추가한 Item의 개수
	 */
	public int insertChattingUser(int a_nUserNoList) {
		return m_ChattingDB.insertChattingUser(a_nUserNoList);
	}

	/**
	 * updateReadMessage 복수 Message isRead Update
	 * 
	 * @param a_mapReadMessage
	 *            : String-MsgId, Boolean-isRead
	 * @return 수정한 Item의 개수
	 */
	public int updateReadMessage(HashMap<String, Boolean> a_mapReadMessage) {
		return m_ChattingDB.updateMsgRead(a_mapReadMessage);
	}
	
	public int updateReadMessageInGetReadCount(HashMap<String, Boolean> a_mapReadMessage) {
		return m_ChattingDB.updateMsgReadInGetReadCount(a_mapReadMessage);
	}

	/**
	 * updateReadMessage 단일 Message isRead Update
	 * 
	 * @param a_strMsgId
	 *            : Message Id
	 * @param a_isRead
	 *            : isRead
	 * @return 수정한 Item의 개수
	 */
	public int updateReadMessage(String a_strMsgId, boolean a_isRead) {
		return m_ChattingDB.updateMsgRead(a_strMsgId, a_isRead);
	}
	
	
	public int insertMessage(ChattingMessageData a_chattingMsgData)
	{
		return m_ChattingDB.insertChattingMessage(a_chattingMsgData);
	}

	/**
	 * updateSendStatus 단일 Message Send Status Update
	 * 
	 * @param a_strMsgId
	 *            : Message Id
	 * @param a_nSendStatus
	 *            : Send Status
	 * @return 수정한 Item의 개수
	 */
	public int updateSendStatus(String a_strMsgId, int a_nSendStatus) {
		return m_ChattingDB.updateSendStatus(a_strMsgId, a_nSendStatus);
	}
	
	public int updateChattingMessage(ChattingMessageData a_data) {
		return m_ChattingDB.updateMsg(a_data);
	}
	
	public int updateNoReadUserCount(String a_strMsgId, int a_nCount)
	{
		return m_ChattingDB.updateNoReadUserCount(a_strMsgId, a_nCount);
	}
	
	public int updateNoReadUserCount(ArrayList<ReadCountData> a_arrNoReadCountData)
	{
		return m_ChattingDB.updateNoReadUserCount(a_arrNoReadCountData);
	}

	/**
	 * deleteChattingMessage Message 전체 Delete
	 * 
	 * @return 삭제한 Item의 개수
	 */
	public int deleteChattingMessage() {
		return m_ChattingDB.deleteChattingMessage();
	}

	/**
	 * deleteChattingMessage Message 단일 Delete
	 * 
	 * @param a_strMsgId
	 *            : Msg Id
	 * @return 삭제한 Item의 개수
	 */
	public int deleteChattingMessage(String a_strMsgId) {
		return m_ChattingDB.deleteChattingMessage(a_strMsgId);
	}
	
	public int deleteChattingMessageTimeAfter(long a_lnTime)
	{
		return m_ChattingDB.deleteChattingMessageTimeAfter(a_lnTime);
	}

	/**
	 * deleteChattingUser Chatting User 전체 Delete
	 * 
	 * @return 삭제한 Item의 개수
	 */
	public int deleteChattingUser() {
		return m_ChattingDB.deleteChattingUser();
	}

	/**
	 * deleteChattingUser Chatting User Delete
	 * 
	 * @param a_nUserNo
	 *            : User Id
	 * @return 삭제한 Item의 개수
	 */
	public int deleteChattingUser(int a_nUserNo) {
		return m_ChattingDB.deleteChattingUser(a_nUserNo);
	}
	
	/**
	 * getChattingMessage get Chatting Message
	 * 
	 * @return ChattingMessage Data ArrayList
	 */
	public ArrayList<ChattingMessageData> getChattingMessage() {
		
		ArrayList<ChattingMessageData> arrChattingMsgData = new ArrayList<ChattingMessageData>();
		ArrayList<String> arrMsgId = new ArrayList<String>();
		
		Cursor cursor = m_ChattingDB.getChattingMessage();
		if (cursor.moveToFirst()) {
			do {
				int nMsgType = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
				String strMsgText = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
				String strEmoticon = "";
				if(strMsgText == null || strMsgText.equals(""))
					continue;

				try
				{
					LocalAesCrypto crypto = new LocalAesCrypto();
					if(nMsgType != StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE &&nMsgType != StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE) {
						strMsgText = crypto.decrypt(strMsgText);
					} else {
						Gson gson = new Gson();
						Type type = new TypeToken<ArrayList<String>>() {}.getType();
						ArrayList<String>  arrMsgNEmoticon = gson.fromJson(cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG)), type);
						strMsgText = crypto.decrypt(arrMsgNEmoticon.get(0));
						strEmoticon = arrMsgNEmoticon.get(1);
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
				int nMsgIdx = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_IDX));
				String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
				
				if(arrMsgId.contains(strMsgId))
					continue;
				
				arrMsgId.add(strMsgId);
				
				int nSendUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
				long lnSendTime = cursor.getLong(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
				boolean isRead = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
				int nSendStatus = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
				int nNoReadUserCount = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
				Gson gson = new Gson();
				Type type = new TypeToken<ArrayList<String>>() {}.getType();
				ArrayList<String> arrSNSAddedList = gson.fromJson(cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_SNSNOTICE_ADDEDLIST)),type);
				
				ChattingMessageData data = new ChattingMessageData();
				data.m_nIdx = nMsgIdx;
				data.m_strMsgId = strMsgId;
				data.m_nSendUserId = nSendUserId;
				data.m_lnMsgSendTime = lnSendTime;
				data.m_nMsgType = nMsgType;
				data.m_strMsgText = strMsgText;
				data.m_isRead = isRead;
				data.m_nSendStatus = nSendStatus;
				data.m_nNoReadUserCount = nNoReadUserCount;
				if(arrSNSAddedList!=null)
					data.m_SNSNoticeAddedList = arrSNSAddedList;
				data.m_strEmoticon = strEmoticon;
				arrChattingMsgData.add(data);
					
			} while (cursor.moveToNext());
		}

		cursor.close();
		
		return arrChattingMsgData;
	}
	
	public ArrayList<ChattingMessageData> getChattingMessage(long a_lnLastMsgSendTime, int a_nLimit) {
		
		ArrayList<ChattingMessageData> arrChattingMsgData = new ArrayList<ChattingMessageData>();
		ArrayList<String> arrMsgId = new ArrayList<String>();
		
		Cursor cursor = m_ChattingDB.getChattingMessage(a_lnLastMsgSendTime, a_nLimit);
		if (cursor.moveToLast()) {
			do {
				int nMsgType = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
				String strMsgText = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
				String strEmoticon = "";
				if(strMsgText == null || strMsgText.equals(""))
					continue;

				try
				{
					LocalAesCrypto crypto = new LocalAesCrypto();
					if(nMsgType != StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE &&nMsgType != StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE) {
						strMsgText = crypto.decrypt(strMsgText);
					} else {
						Gson gson = new Gson();
						Type type = new TypeToken<ArrayList<String>>() {}.getType();
						ArrayList<String>  arrMsgNEmoticon = gson.fromJson(cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG)), type);
						strMsgText = crypto.decrypt(arrMsgNEmoticon.get(0));
						strEmoticon = arrMsgNEmoticon.get(1);
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
				String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
				if(arrMsgId.contains(strMsgId))
					continue;
				
				arrMsgId.add(strMsgId);
				
				int nMsgIdx = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_IDX));
				int nSendUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
				long lnSendTime = cursor.getLong(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
				boolean isRead = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
				int nSendStatus = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
				int nNoReadUserCount = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
				Gson gson = new Gson();
				Type type = new TypeToken<ArrayList<String>>() {}.getType();
				ArrayList<String> arrSNSAddedList = gson.fromJson(cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_SNSNOTICE_ADDEDLIST)),type);
				
				ChattingMessageData data = new ChattingMessageData();
				data.m_nIdx = nMsgIdx;
				data.m_strMsgId = strMsgId;
				data.m_nSendUserId = nSendUserId;
				data.m_lnMsgSendTime = lnSendTime;
				data.m_nMsgType = nMsgType;
				data.m_strMsgText = strMsgText;
				data.m_isRead = isRead;
				data.m_nSendStatus = nSendStatus;
				data.m_nNoReadUserCount = nNoReadUserCount;
				if(arrSNSAddedList!=null)
					data.m_SNSNoticeAddedList = arrSNSAddedList;
				data.m_strEmoticon = strEmoticon;
				arrChattingMsgData.add(data);
					
			} while (cursor.moveToPrevious());
		}

		cursor.close();
		
		return arrChattingMsgData;
	}
	
	public ChattingMessageData getChattingMessage(String a_strPacketId) {
		
		ChattingMessageData chattingMsgData = new ChattingMessageData();

		Cursor cursor = m_ChattingDB.getChattingMessage(a_strPacketId);

		if (cursor.moveToFirst()) {
			int nMsgType = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
			String strMsgText = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
			String strEmoticon = "";

			if(strMsgText == null || strMsgText.equals("")){
				cursor.close();
				return chattingMsgData;
			}
			
			try
			{
				LocalAesCrypto crypto = new LocalAesCrypto();
				if(nMsgType != StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE && nMsgType != StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE) {
					strMsgText = crypto.decrypt(strMsgText);
				} else {
					Gson gson = new Gson();
					Type type = new TypeToken<ArrayList<String>>() {}.getType();
					ArrayList<String>  arrMsgNEmoticon = gson.fromJson(cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG)), type);
					strMsgText = crypto.decrypt(arrMsgNEmoticon.get(0));
					strEmoticon = arrMsgNEmoticon.get(1);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			int nMsgIdx = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_IDX));
			String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
			int nSendUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
			long lnSendTime = cursor.getLong(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
			boolean isRead = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
			int nSendStatus = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
			int nNoReadUserCount = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
			
			chattingMsgData.m_nIdx = nMsgIdx;
			chattingMsgData.m_strMsgId = strMsgId;
			chattingMsgData.m_nSendUserId = nSendUserId;
			chattingMsgData.m_lnMsgSendTime = lnSendTime;
			chattingMsgData.m_nMsgType = nMsgType;
			if(strEmoticon.equals(""))
				chattingMsgData.m_strMsgText = strMsgText;
			else
				chattingMsgData.m_strMsgText =  m_Context.getString(R.string.emoticon)+strMsgText;
			chattingMsgData.m_isRead = isRead;
			chattingMsgData.m_nSendStatus = nSendStatus;
			chattingMsgData.m_nNoReadUserCount = nNoReadUserCount;
		}
		cursor.close();
		return chattingMsgData;
	}
	
	public ChattingMessageData getCurrentUrgentMessage()
	{
		ChattingMessageData chattingMessageData = new ChattingMessageData();
		

		Cursor cursorCurrentUrgentMessage = m_ChattingDB.getCurrentUrgentMessage();
		if(cursorCurrentUrgentMessage.moveToFirst())
		{
			String strMsgId = cursorCurrentUrgentMessage.getString(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
			String strMsgText = cursorCurrentUrgentMessage.getString(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
			if(strMsgText == null || strMsgText.equals(""))
			{
				cursorCurrentUrgentMessage.close();
				return chattingMessageData;
			}
			
			try
			{
				LocalAesCrypto crypto = new LocalAesCrypto();
				strMsgText = crypto.decrypt(strMsgText);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			int nMsgIdx = cursorCurrentUrgentMessage.getInt(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_IDX));
			int nSendUserId = cursorCurrentUrgentMessage.getInt(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
			long lnSendTime = cursorCurrentUrgentMessage.getLong(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
			int nMsgType = cursorCurrentUrgentMessage.getInt(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
			boolean isRead = cursorCurrentUrgentMessage.getInt(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
			int nSendStatus = cursorCurrentUrgentMessage.getInt(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
			int nNoReadUserCount = cursorCurrentUrgentMessage.getInt(cursorCurrentUrgentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
			
			chattingMessageData.m_nIdx = nMsgIdx;
			chattingMessageData.m_strMsgId = strMsgId;
			chattingMessageData.m_nSendUserId = nSendUserId;
			chattingMessageData.m_lnMsgSendTime = lnSendTime;
			chattingMessageData.m_nMsgType = nMsgType;
			chattingMessageData.m_strMsgText = strMsgText;
			chattingMessageData.m_isRead = isRead;
			chattingMessageData.m_nSendStatus = nSendStatus;
			chattingMessageData.m_nNoReadUserCount = nNoReadUserCount;
		}
		cursorCurrentUrgentMessage.close();
		
		return chattingMessageData;
	}
	
	public ChattingMessageData getCurrentMessage()
	{
		ChattingMessageData chattingMessageData = new ChattingMessageData();
		
		Cursor cursorCurrentMessage = m_ChattingDB.getCurrentMessage();
		if(cursorCurrentMessage.moveToFirst())
		{
			String strMsgId = cursorCurrentMessage.getString(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));

			int nMsgType = cursorCurrentMessage.getInt(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
			int nMsgIdx = cursorCurrentMessage.getInt(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_IDX));
			String strMsgText = cursorCurrentMessage.getString(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
			String strEmoticon = "";
			try
			{
				LocalAesCrypto crypto = new LocalAesCrypto();
				if(nMsgType != StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE && nMsgType != StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE) {
					strMsgText = crypto.decrypt(strMsgText);
				} else {
					Gson gson = new Gson();
					Type type = new TypeToken<ArrayList<String>>() {}.getType();
					ArrayList<String>  arrMsgNEmoticon = gson.fromJson(cursorCurrentMessage.getString(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG)), type);
					strMsgText = crypto.decrypt(arrMsgNEmoticon.get(0));
					strEmoticon = arrMsgNEmoticon.get(1);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			int nSendUserId = cursorCurrentMessage.getInt(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
			long lnSendTime = cursorCurrentMessage.getLong(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
			boolean isRead = cursorCurrentMessage.getInt(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
			int nSendStatus = cursorCurrentMessage.getInt(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
			int nNoReadUserCount = cursorCurrentMessage.getInt(cursorCurrentMessage.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
			
			chattingMessageData.m_nIdx = nMsgIdx;
			chattingMessageData.m_strMsgId = strMsgId;
			chattingMessageData.m_nSendUserId = nSendUserId;
			chattingMessageData.m_lnMsgSendTime = lnSendTime;
			chattingMessageData.m_nMsgType = nMsgType;
			if(strEmoticon.equals(""))
				chattingMessageData.m_strMsgText = strMsgText;
			else
				chattingMessageData.m_strMsgText = m_Context.getString(R.string.emoticon)+strMsgText;
			chattingMessageData.m_isRead = isRead;
			chattingMessageData.m_nSendStatus = nSendStatus;
			chattingMessageData.m_nNoReadUserCount = nNoReadUserCount;
		}
		cursorCurrentMessage.close();
		return chattingMessageData;
	}
	
	public ArrayList<ChattingMessageData> getChattingMessageNotNoReadCount0() {
		
		ArrayList<ChattingMessageData> arrChattingMsgData = new ArrayList<ChattingMessageData>();
		
		Cursor cursor = m_ChattingDB.getChattingMessageNotNoReadCount0();
		if (cursor.moveToLast()) {
			do {
				String strMsgText = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
				if(strMsgText == null || strMsgText.equals(""))
					continue;
				
				try
				{
					LocalAesCrypto crypto = new LocalAesCrypto();
					strMsgText = crypto.decrypt(strMsgText);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
				int nMsgIdx = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_IDX));
				String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
				int nSendUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
				long lnSendTime = cursor.getLong(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
				int nMsgType = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
				boolean isRead = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
				int nSendStatus = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
				int nNoReadUserCount = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
				
				ChattingMessageData data = new ChattingMessageData();
				data.m_nIdx = nMsgIdx;
				data.m_strMsgId = strMsgId;
				data.m_nSendUserId = nSendUserId;
				data.m_lnMsgSendTime = lnSendTime;
				data.m_nMsgType = nMsgType;
				data.m_strMsgText = strMsgText;
				data.m_isRead = isRead;
				data.m_nSendStatus = nSendStatus;
				data.m_nNoReadUserCount = nNoReadUserCount;
				
				arrChattingMsgData.add(data);
					
			} while (cursor.moveToPrevious());
		}

		cursor.close();
		
		return arrChattingMsgData;
	}

	public ArrayList<ChattingMessageData> getChattingMessageNotNoReadMine() {
		
		ArrayList<ChattingMessageData> arrChattingMsgData = new ArrayList<ChattingMessageData>();
		
		Cursor cursor = m_ChattingDB.getChattingMessageNotNoReadMine();
		if (cursor.moveToLast()) {
			do {
				String strMsgText = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
				if(strMsgText == null || strMsgText.equals(""))
					continue;
				
				try
				{
					LocalAesCrypto crypto = new LocalAesCrypto();
					strMsgText = crypto.decrypt(strMsgText);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
				int nMsgIdx = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_IDX));
				String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
				int nSendUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
				long lnSendTime = cursor.getLong(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
				int nMsgType = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
				boolean isRead = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
				int nSendStatus = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
				int nNoReadUserCount = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_NOREADUSERCOUNT));
				ChattingMessageData data = new ChattingMessageData();
				data.m_nIdx = nMsgIdx;
				data.m_strMsgId = strMsgId;
				data.m_nSendUserId = nSendUserId;
				data.m_lnMsgSendTime = lnSendTime;
				data.m_nMsgType = nMsgType;
				data.m_strMsgText = strMsgText;
				data.m_isRead = isRead;				
				data.m_nSendStatus = nSendStatus;
				data.m_nNoReadUserCount = nNoReadUserCount;
				
				arrChattingMsgData.add(data);
					
			} while (cursor.moveToPrevious());
		}

		cursor.close();
		
		return arrChattingMsgData;
	}
	/**
	 * getNoReadMessageCount get is Not Read Message Count
	 * 
	 * @return int is Not Read Message Count
	 */
	public int getNoReadMessageCount() {
		int nNoReadMessageCount = m_ChattingDB.getNoReadMessageCount();
		return nNoReadMessageCount;
	}
	
	/**
	 * getChattingUser
	 * get Chatting UserId
	 * @return ArrayList<Integer> is User Id List 
	 */
	public ArrayList<Integer> getChattingUser()
	{
		ArrayList<Integer> arrChattingUser = new ArrayList<Integer>();
		Cursor cursor = m_ChattingDB.getChattingUser();
		if(cursor.moveToFirst())
		{
			do
			{
				int nUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTINGUSER_USERID));
				arrChattingUser.add(nUserId);
			}while(cursor.moveToNext());
		}
		
		cursor.close();
		return arrChattingUser;
	}
	
	/**
	 * 여기서부터는 ChattingDBManageService에서 사용하는 Function 들
	 */
	
	public void beginTransactionAtChattingDB()
	{
		m_ChattingDB.beginTransaction();
	}
	
	public void setTransactionSuccessfulAtChattingDB()
	{
		m_ChattingDB.setTransactionSuccessful();
	}
	
	public void endTransactionAtChattingDB()
	{
		m_ChattingDB.endTransaction();
	}
	
	public int realInsertChattingMessage(ChattingMessageData data)
	{
		return m_ChattingDB.insertChattingMessageNonTransaction(data);
	}
	
	public int realInsertChattingUser(ArrayList<Integer> a_arrUserIdList) {
		return m_ChattingDB.insertChattingUserNonTransaction(a_arrUserIdList);
	}

	public int realInsertChattingUser(int a_nUserNoList) {
		return m_ChattingDB.insertChattingUserNonTransaction(a_nUserNoList);
	}

	/**
	 * updateReadMessage 복수 Message isRead Update
	 * 
	 * @param a_mapReadMessage
	 *            : String-MsgId, Boolean-isRead
	 * @return 수정한 Item의 개수
	 */
	public int realUpdateReadMessage(HashMap<String, Boolean> a_mapReadMessage) {
		return m_ChattingDB.updateMsgReadNonTransaction(a_mapReadMessage);
	}

	/**
	 * updateReadMessage 단일 Message isRead Update
	 * 
	 * @param a_strMsgId
	 *            : Message Id
	 * @param a_isRead
	 *            : isRead
	 * @return 수정한 Item의 개수
	 */
	public int realUpdateReadMessage(String a_strMsgId, boolean a_isRead) {
		return m_ChattingDB.updateMsgReadNonTransaction(a_strMsgId, a_isRead);
	}
	
	public int realUpdateSendStatus(String a_strMsgId, int a_nSendStatus) {
		return m_ChattingDB.updateSendStatusNonTransaction(a_strMsgId, a_nSendStatus);
	}
	
	public int realUpdateChattingMessage(ChattingMessageData data) {
		return m_ChattingDB.updateChattingMessageNonTransaction(data);
	}
	
	public int realUpdateNoReadUserCount(String a_strMsgId, int a_nCount)
	{
		return m_ChattingDB.updateNoReadUserCountNonTransaction(a_strMsgId, a_nCount);
	}
	
	public int realUpdateNoReadUserCount(ArrayList<ReadCountData> a_arrNoReadCountData)
	{
		return m_ChattingDB.updateNoReadUserCountNonTransaction(a_arrNoReadCountData);
	}

	/**
	 * deleteChattingMessage Message 전체 Delete
	 * 
	 * @return 삭제한 Item의 개수
	 */
	public int realDeleteChattingMessage() {
		return m_ChattingDB.deleteChattingMessage();
	}

	/**
	 * deleteChattingMessage Message 단일 Delete
	 * 
	 * @param a_strMsgId
	 *            : Msg Id
	 * @return 삭제한 Item의 개수
	 */
	public int realDeleteChattingMessage(String a_strMsgId) {
		return m_ChattingDB.deleteChattingMessage(a_strMsgId);
	}

	/**
	 * deleteChattingUser Chatting User 전체 Delete
	 * 
	 * @return 삭제한 Item의 개수
	 */
	public int realDeleteChattingUser() {
		return m_ChattingDB.deleteChattingUser();
	}

	/**
	 * deleteChattingUser Chatting User Delete
	 * 
	 * @param a_nUserNo
	 *            : User Id
	 * @return 삭제한 Item의 개수
	 */
	public int realDeleteChattingUser(int a_nUserNo) {
		return m_ChattingDB.deleteChattingUser(a_nUserNo);
	}
}
