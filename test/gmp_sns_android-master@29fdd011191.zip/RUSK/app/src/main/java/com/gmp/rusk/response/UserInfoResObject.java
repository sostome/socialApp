package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.UserInfoData;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface UserInfoResObject {

    //중복 정의 되는 부분 뺌
    public final String JSON_USERS					= "users";

    //public final String JSON_USERNO					= "userNo";
    //public final String JSON_TYPE		 			= "type";
    //public final String JSON_NAME					= "name";
    public final String JSON_EMAIL					= "email";
    //public final String JSON_MOBILE				= "mobile";
    //public final String JSON_COMPANYCODE			= "companyCode";
    //public final String JSON_DEPARTMENT			= "department";
    //public final String JSON_PARENTDEPARTMENT		= "parentDepartment";
    //public final String JSON_CHARGE				= "charge";
    public final String JSON_POSITION				= "position";
    //public final String JSON_SECONDCHARGE			= "secondCharge";
    //public final String JSON_AFFILIATION				= "affiliation";
    //public final String JSON_IMAGEAVAILABLE		= "imageAvailable";
    //public final String JSON_GREETING				= "greeting";
    //public final String JSON_AVAILABLE				= "available";
    public final String JSON_STATUS					= "status";

    public void parseUserInfoData();
    public void parseUserInfoDataSingle();
    public ArrayList<UserInfoData> getUserInfoDatas();
}
