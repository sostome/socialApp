package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Html;
import android.text.InputFilter;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonNoticePopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetLoginReq;
import com.gmp.rusk.request.GetProvisioningReq;
import com.gmp.rusk.request.PostMigrateMobileReq;
import com.gmp.rusk.response.GetLoginRes;
import com.gmp.rusk.response.GetProvisioningRes;
import com.gmp.rusk.response.PostPartnerMigrateMobileRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.KeystoreCrypto;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PartnerLoginAct
 * @author subi78
 * 파트너 및 가사번 로그인 Activity
 */
public class PartnerLoginAct extends Activity implements OnClickListener {
	public MyApp App = MyApp.getInstance();
	EditText et_login_id;
	EditText et_login_pw;
	TextView tv_helpdesk;
	ImageView iv_login_call;
	LinearLayout layout_login_sendmail;
	
	String strTempID, strTempPW;
	private CommonPopup m_Popup = null;
	private CommonNoticePopup m_NoticePopup = null;
	//int m_nPopupType;
	private ProgressDlg m_Progress = null;
	
	private boolean isTwo = false;
	
	public boolean m_isRunning = false;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_login);
		setResult(Activity.RESULT_CANCELED);
		setPartnerLoginUi();
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
		
		
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
		App.m_arrActivitys.remove(this);
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if (!isTwo) {
			Toast.makeText(this, getString(R.string.press_back_key), Toast.LENGTH_SHORT).show();
			myTimer timer = new myTimer(2000, 1); // 2초동안 수행
			timer.start(); // 타이머를 이용해줍시다
		} else // super.onBackPressed();
		{
			// android.os.Process.killProcess(android.os.Process.myPid()); //프로세스 끝내기
			super.onBackPressed();
		}
	}
	
	private void setPartnerLoginUi()
	{
		et_login_id = (EditText)findViewById(R.id.et_login_id);
		et_login_id.setOnClickListener(this);
		et_login_id.setText(App.m_PartnerID);

		//et_login_id.setFilters(new InputFilter[]{Utils.filterAlphaNum});

		et_login_pw = (EditText)findViewById(R.id.et_login_pw);
		et_login_pw.setOnClickListener(this);

		/*tv_helpdesk = (TextView) findViewById(R.id.tv_partner_login_helpdesk);
		tv_helpdesk.setText(Html.fromHtml("<u>" + getString(R.string.partner_helpdesk) + "</u>"));*/
		/*if(et_login_id.getText().toString().length() != 0){
			et_login_pw.requestFocus();
		}*/
		
		/*iv_login_call = (ImageView) findViewById(R.id.iv_partner_login_call);
		iv_login_call.setOnClickListener(this);*/
		
		layout_login_sendmail = (LinearLayout) findViewById(R.id.layout_partner_login_mail);
		layout_login_sendmail.setOnClickListener(this);
		//et_login_pw.setFilters(new InputFilter[]{Utils.filterAlphaNum});
		
		Button ib_pt_login = (Button)findViewById(R.id.ib_pt_login);
		ib_pt_login.setOnClickListener(this);
		
		Button ib_pt_signup = (Button)findViewById(R.id.ib_pt_signup);
		ib_pt_signup.setOnClickListener(this);

		
//		ImageButton ib_pt_signup_num = (ImageButton)findViewById(R.id.ib_pt_signup_num);
//		ib_pt_signup_num.setVisibility(View.INVISIBLE);
//		ib_pt_signup_num.setOnClickListener(this);
		
		TextView tv_find_id_pw = (TextView)findViewById(R.id.tv_find_id_pw);
		tv_find_id_pw.setOnClickListener(this);

		
		//이미 파트너 로그인 창이 떠있다면 제거
		for(Activity activity : App.m_arrActivitys){
			if(activity.getClass().getSimpleName().equals("PartnerLoginAct")){
				activity.finish();
				break;
			}
				
		}
		App.m_arrActivitys.add(this);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(requestCode == StaticString.REQUESTCODE_PARTNERUSERID_CERTI)
		{
			if(resultCode == Activity.RESULT_OK)
			{
				setResult(Activity.RESULT_OK);
			}
			else if(resultCode == StaticString.RESULT_BACK_ACTIVITY_FINISH)
			{
				onBackPressed();
			}
		}
		else if(requestCode == StaticString.REQUESTCODE_PARTNER_APPROVALREQ)
		{
//			if(resultCode == Activity.RESULT_OK)
//			{
//				setResult(Activity.RESULT_OK);
//			}
//			else if(resultCode == StaticString.RESULT_BACK_ACTIVITY_FINISH)
//			{
//				onBackPressed();
//			}
			if(resultCode == StaticString.RESULT_BACK_ACTIVITY_FINISH)
			{
				onBackPressed();
			}
		}
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Intent intent = null;
		
		if(v.getId() == R.id.tv_find_id_pw)
		{
			intent = new Intent(PartnerLoginAct.this, FindIdPwTabAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.ib_pt_login)
		{


			if(et_login_id.getText().toString().length() < 6)
			{
				m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_userid_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
		/*	if(et_login_pw.getText().toString().trim().length() < 8)
			{
				m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			} else {
				String input = et_login_pw.getText().toString().trim();
				Pattern p = Pattern.compile("([a-zA-Z0-9].*[!,@,#,$,%,^,&,*,?,_,~])|([!,@,#,$,%,^,&,*,?,_,~].*[a-zA-Z0-9])");
				Matcher m = p.matcher(input);
				if (m.find()){
					//정상적인 비밀번호 이므로 통과
				}else{
					m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.partner_signup_popup_pw_length).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}*/
			SharedPref pref = SharedPref.getInstance(PartnerLoginAct.this);
			try {
				strTempID = "";
				LocalAesCrypto crypto = new LocalAesCrypto(KeystoreCrypto.getKey(this));
				strTempID = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_ID, ""));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//strTempPW = new String(pref.getStringPref(SharedPref.PREF_PARTNER_ID));
			//CommonLog.e("aaa", "Before PW : " + strTempPW);
			App.m_PartnerID = et_login_id.getText().toString();
			App.m_PartnerPW = et_login_pw.getText().toString();
			et_login_pw.setText("");
			
//			if(AppSetting.USING_SERVER == APISERVER_LIST.DEV_SERVER)
//				requestEntry();
//			else
				requestLogin();
		}
		else if(v.getId() == R.id.ib_pt_signup)
		{
			intent = new Intent(PartnerLoginAct.this, AgreementAgreeAct.class);
			startActivityForResult(intent, StaticString.REQUESTCODE_PARTNER_APPROVALREQ);
		}
//		else if(v.getId() == R.id.ib_pt_signup_num)
//		{
//			intent = new Intent(PartnerLoginAct.this, PartnerUseridCertiAct.class);
//			startActivityForResult(intent, StaticString.REQUESTCODE_PARTNERUSERID_CERTI);
//		}
		else if(v.getId() == R.id.ib_pop_ok_long)
		{
			if(m_Popup!=null && m_Popup.isShowing()) {
				CommonPopup popup_ok_long = (CommonPopup) v.getTag();
				popup_ok_long.cancel();
			} else if(m_NoticePopup !=null && m_NoticePopup.isShowing()){
				CommonNoticePopup popup_ok_long = (CommonNoticePopup) v.getTag();
				popup_ok_long.cancel();
			}
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		else if(v.getId() == R.id.ib_pop_ok)
		{
			CommonPopup popup_ok = (CommonPopup)v.getTag();	
			if(popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_LOGIN_SEND_MAIL){
				intent = new Intent(Intent.ACTION_SEND);
				intent.setType("message/rfc822");
				intent.putExtra(Intent.EXTRA_EMAIL  , new String[]{"talk_help@uangel.com"});
				startActivity(intent);
			}
			else if(popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE){
				requestPartnerMigrateMobile();
			}
			popup_ok.cancel();
		}
		/*else if(v.getId() == R.id.iv_partner_login_call)
		{
			intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:1599-2365"));
		    startActivity(intent);
		} */
		else if(v.getId() == R.id.layout_partner_login_mail)
		{
			m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
					CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_LOGIN_SEND_MAIL);
			m_Popup.setBodyAndTitleText(
					getString(R.string.partner_login_send_email_title).toString(),
					getString(R.string.partner_login_send_email_text).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	}
	
	private void requestLogin()
	{
		showProgress();
		GetLoginReq req = new GetLoginReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetLoginRes res = new GetLoginRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				
				SharedPref pref = SharedPref.getInstance(PartnerLoginAct.this);

//				if(!strTempID.equals(App.m_PartnerID)){	//대소문자 구분 함
				if(!strTempID.equalsIgnoreCase(App.m_PartnerID)){	//대소문자 구분 안함
//				if(res.m_strUserNo != pref.getIntegerPref(SharedPref.PREF_PARTNER_USERNO)){
					//App.m_EntryData = null; // 로그인 정보
					App.m_arrFellowListData = null;
					App.m_arrDepartmentUserListData = null;
					//App.m_arrPartnerSearchListData = null;
					App.m_MyUserInfo = null;
					App.m_arrRoomUserList = null;
					App.m_arrRegularSearchListDatas = null;
					
					String strBeforCookie = pref.getStringPref(SharedPref.PREF_COOKIE);
					//pref.deletePreferences();
					pref.setStringPref(SharedPref.PREF_COOKIE, strBeforCookie);

					//TTalkDBManager.initTTalkDB(PartnerLoginAct.this);
				}

				//App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate, res.m_strPreviewImageUrlTemplate,"", res.m_strLatestVersion, res.m_strLol, res.m_strMobile);
				App.m_MyUserInfo = res.getEntryUserData(getApplicationContext());
				App.m_EntryData.m_strLol = res.getLOL();
				if(pref.getIntegerPref(SharedPref.PREF_USERNO) != App.m_MyUserInfo.m_nUserNo){
					App.m_arrFellowListData = null;
					App.m_arrDepartmentUserListData = null;
					App.m_arrRoomUserList = null;
					App.m_arrRegularSearchListDatas = null;

					String strBeforCookie = pref.getStringPref(SharedPref.PREF_COOKIE);
					pref.deletePreferences();
					pref.setStringPref(SharedPref.PREF_COOKIE, strBeforCookie);

					TTalkDBManager.initTTalkDB(PartnerLoginAct.this);
				}
				pref.setIntegerPref(SharedPref.PREF_USERNO, App.m_MyUserInfo.m_nUserNo);
				setResult(Activity.RESULT_OK);
				closeProgress();
				finish();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				
				if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					App.m_PartnerID = "";
					App.m_PartnerPW = "";
					m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.cork_401_error).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_NOT_JOIN)
				{
					Intent intent = new Intent(PartnerLoginAct.this, PartnerSignUpWattingAct.class);
					startActivity(intent);
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_NOT_EMAIL_CERTIFICATION)
				{
					Intent intent = new Intent(PartnerLoginAct.this, PartnerSignUpEmailWaittingAct.class);
					startActivity(intent);
				}
				else
				{
					App.m_PartnerID = "";
					App.m_PartnerPW = "";
					m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				
			}
		});
	}
	
//	private void requestEntry()
//	{
//		showProgress();
//		GetEntryReq req = new GetEntryReq();
//		WebAPI webApi = new WebAPI(this);
//		webApi.request(req, new WebListener() {
//	
//			@Override
//			public void onPreRequest() {
//				// TODO Auto-generated method stub
//			}
//	
//			@Override
//			public void onPostRequest(String a_strData) {
//				// TODO Auto-generated method stub
//				GetEntryRes res = new GetEntryRes(a_strData);
//				App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate, res.m_strPreviewImageUrlTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);
//				App.m_MyUserInfo = res.getUserInfoData();
//				setResult(Activity.RESULT_OK);
//				closeProgress();
//				finish();
//			}
//	
//			@Override
//			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
//				// TODO Auto-generated method stub
//				closeProgress();
//				
//				if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
//				{
//					m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
//							CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
//					m_Popup.setBodyAndTitleText(
//							getString(R.string.pop_error_title).toString(),
//							getString(R.string.pop_changeDevice).toString());
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				}
//				else if(a_nErrorCode == ApiResult.HTTP_SERVER_NOT_JOIN)
//				{
//					Intent intent = new Intent(PartnerLoginAct.this, PartnerSignUpWattingAct.class);
//					startActivity(intent);
//				}
//				else
//				{
//					App.m_PartnerID = "";
//					App.m_PartnerPW = "";
//					m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
//							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//					m_Popup.setBodyAndTitleText(
//							getString(R.string.pop_error_title).toString(),
//							a_strMessage);
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				}
//				
//			}
//		});
//	}
	
	private void requestPartnerMigrateMobile()
	{
		showProgress();
		GetProvisioningReq req = new GetProvisioningReq();

		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {

			}

			@Override
			public void onPostRequest(String a_strData) {
				GetProvisioningRes res = new GetProvisioningRes(a_strData, Res.RES_TYPE_USER_COMPANY);
				App.m_EntryData = new EntryData();
				App.m_EntryData.m_strImageUrlTemplate = res.getUserImageUrlTemplate();
				App.m_EntryData.m_strPreviewImageUrlTemplate = res.getUserPreviewImageUrlTemplate();
				App.m_EntryData.m_arrCompanyData = res.getCompanies();

				PostMigrateMobileReq req = new PostMigrateMobileReq();
				WebAPI webApi = new WebAPI(PartnerLoginAct.this);
				webApi.request(req, new WebListener() {

					@Override
					public void onPreRequest() {
						// TODO Auto-generated method stub
					}

					@Override
					public void onPostRequest(String a_strData) {
						// TODO Auto-generated method stub
						PostPartnerMigrateMobileRes res = new PostPartnerMigrateMobileRes(a_strData, Res.RES_TYPE_USER_ENTRY);

						SharedPref pref = SharedPref.getInstance(PartnerLoginAct.this);

//				if(!strTempID.equals(App.m_PartnerID)){
						if(!strTempID.equalsIgnoreCase(App.m_PartnerID)){	//대소문자 구분 안함
							//App.m_EntryData = null; // 로그인 정보
							App.m_arrFellowListData = null;
							App.m_arrDepartmentUserListData = null;
							//App.m_arrPartnerSearchListData = null;
							App.m_MyUserInfo = null;
							App.m_arrRoomUserList = null;
							App.m_arrRegularSearchListDatas = null;

							String strBeforCookie = pref.getStringPref(SharedPref.PREF_COOKIE);
							pref.deletePreferences();
							pref.setStringPref(SharedPref.PREF_COOKIE, strBeforCookie);

							TTalkDBManager.initTTalkDB(PartnerLoginAct.this);
						}

						//App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate, res.m_strPreviewImageUrlTemplate,"", res.m_strLatestVersion, res.m_strLol, res.m_strMobile);
						App.m_MyUserInfo = res.getEntryUserData(getApplicationContext());
						App.m_EntryData.m_strLol = res.getLOL();
						if(pref.getIntegerPref(SharedPref.PREF_USERNO) != App.m_MyUserInfo.m_nUserNo){
							App.m_arrFellowListData = null;
							App.m_arrDepartmentUserListData = null;
							App.m_arrRoomUserList = null;
							App.m_arrRegularSearchListDatas = null;

							String strBeforCookie = pref.getStringPref(SharedPref.PREF_COOKIE);
							pref.deletePreferences();
							pref.setStringPref(SharedPref.PREF_COOKIE, strBeforCookie);

							TTalkDBManager.initTTalkDB(PartnerLoginAct.this);
						}
						pref.setIntegerPref(SharedPref.PREF_USERNO, App.m_MyUserInfo.m_nUserNo);
						pref.setBooleanPref(SharedPref.PREF_BACKUP_RESTORE, true);
						setResult(Activity.RESULT_OK);
						closeProgress();
						finish();
					}

					@Override
					public void onNetworkError(int a_nErrorCode, String a_strMessage) {
						closeProgress();
						// TODO Auto-generated method stub
						if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
						{
							m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									a_strMessage);
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
						else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
						{
							App.m_PartnerID = "";
							App.m_PartnerPW = "";
							m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									getString(R.string.cork_401_error).toString());
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
						else if(a_nErrorCode == ApiResult.HTTP_SERVER_NOT_JOIN)
						{
							Intent intent = new Intent(PartnerLoginAct.this, PartnerSignUpWattingAct.class);
							startActivity(intent);
						}
						else if(a_nErrorCode == ApiResult.HTTP_SERVER_NOT_EMAIL_CERTIFICATION)
						{
							Intent intent = new Intent(PartnerLoginAct.this, PartnerSignUpEmailWaittingAct.class);
							startActivity(intent);
						}
						else
						{
							App.m_PartnerID = "";
							App.m_PartnerPW = "";
							m_Popup = new CommonPopup(PartnerLoginAct.this, PartnerLoginAct.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									a_strMessage);
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}

					}
				});
			}
		});


	}
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public class myTimer extends CountDownTimer {

		public myTimer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
			// TODO Auto-generated constructor stub
			isTwo = true;
		}

		@Override
		public void onFinish() {
			isTwo = false;
		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub

		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}
	private void isCheckShowNoticePopup(){
		if(m_isRunning){
			m_NoticePopup.show();
		}
	}
}
