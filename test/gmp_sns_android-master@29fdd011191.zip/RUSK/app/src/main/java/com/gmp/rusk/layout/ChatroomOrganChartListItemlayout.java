package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatInviteTabAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.act.SNSGroupMemeberInviteAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;

/**
 * Created by kang on 2017-07-13.
 */

public class ChatroomOrganChartListItemlayout extends CustomLinearLayout implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    Context m_Context;

    private DepartmentUserListData m_DepartmentUserListData = null;

    private CommonPopup m_Popup = null;

    private ProgressDlg m_Progress = null;
    CheckBox cb_invite;
    private OnCheckedChangedListener m_CheckedChangeListener = null;

    public ChatroomOrganChartListItemlayout(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
        init(context);
    }

    public ChatroomOrganChartListItemlayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        // TODO Auto-generated constructor stub
        init(context);
    }


    private void init(Context a_context)
    {
        this.m_Context = a_context;
        LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        layoutInflater.inflate(R.layout.layout_listitem_chat, this);

    }

    public void setDepartmentUserListData(DepartmentUserListData a_Data)
    {
        m_DepartmentUserListData = a_Data;
        setUiData();
    }

    // UI 세팅
    private void setUiData()
    {
        ImageView iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
        iv_profile_pic.setOnClickListener(this);
        ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);

        if(m_DepartmentUserListData.getImageAvailable())
        {
            App.imageloader.cancelDownload(iv_profile_pic);
            App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_DepartmentUserListData.getUserNo(), true), R.drawable.profile_pic_default, false);
        }
        else
        {
            App.imageloader.cancelDownload(iv_profile_pic);
            iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
        }

        TextView tv_name = (TextView)findViewById(R.id.tv_name);
        TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
        LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
        TextView tv_position = (TextView) findViewById(R.id.tv_position);
        LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
        TextView tv_charge = (TextView) findViewById(R.id.tv_charge);
        tv_name.setText(m_DepartmentUserListData.getName());

        if(m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_DepartmentUserListData.m_strPosition !=null && !m_DepartmentUserListData.m_strPosition.equals("")){
            layout_position.setVisibility(VISIBLE);
            tv_position.setText(m_DepartmentUserListData.m_strPosition);
        } else {
            layout_position.setVisibility(GONE);
        }

        if(m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_DepartmentUserListData.m_strCharge!=null && !m_DepartmentUserListData.m_strCharge.equals("")){
            layout_charge.setVisibility(VISIBLE);
            tv_charge.setText(m_DepartmentUserListData.m_strCharge);
        } else {
            layout_charge.setVisibility(GONE);
        }

        if(m_DepartmentUserListData.getAvailable())
        {
            tv_uninstall.setVisibility(GONE);
        }
        else
        {
            tv_uninstall.setVisibility(VISIBLE);
        }

        TextView tv_departments = (TextView)findViewById(R.id.tv_departments);

        tv_departments.setText(m_DepartmentUserListData.m_strDepartment+" | "+m_DepartmentUserListData.m_strCompanyName);


        iv_notfellow_pic.setVisibility(View.GONE);
        cb_invite = (CheckBox) findViewById(R.id.cb_invite);
        cb_invite.setOnCheckedChangeListener(this);


        RelativeLayout layout_listitem_search = (RelativeLayout)findViewById(R.id.layout_listitem);
        layout_listitem_search.setOnClickListener(this);
    }



    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.layout_listitem) {
            //doShowProfile();
            if(cb_invite.getVisibility() == View.VISIBLE && cb_invite.isChecked())
                cb_invite.setChecked(false);
            else if(cb_invite.getVisibility() == View.VISIBLE && !cb_invite.isChecked())
                cb_invite.setChecked(true);
        } else if(v.getId() == R.id.iv_profile_pic) {
            doShowProfile();
        }
        else if(v.getId()==R.id.ib_pop_ok_long)
        {
            CommonPopup popup_ok_long = (CommonPopup)v.getTag();
            if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
            {	popup_ok_long.cancel();
                App.expirePartnerLogin(m_Context);
            }
            else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
            {
                popup_ok_long.cancel();
                App.initPartnerLogin(m_Context);
            }
            else
            {
                popup_ok_long.cancel();
            }
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        // TODO Auto-generated method stub
        if (buttonView.getId() == R.id.cb_invite) {
            if (isChecked) {
                SearchListCheckData addData = new SearchListCheckData(m_DepartmentUserListData.getUserNo(), m_DepartmentUserListData.getName());
                //addData.m_isChecked = true;
                ((ChatInviteTabAct) m_Context).addSearchList(addData);
                m_CheckedChangeListener.onChecked(true, m_DepartmentUserListData.getUserNo());

            } else {
                ((ChatInviteTabAct) m_Context).removeListData(m_DepartmentUserListData.getUserNo());
                m_CheckedChangeListener.onChecked(false, m_DepartmentUserListData.getUserNo());
            }
        }
    }

    public void setCheckedChangedListener(OnCheckedChangedListener a_Listener) {
        m_CheckedChangeListener = a_Listener;
    }

    public interface OnCheckedChangedListener {
        public void onChecked(boolean a_isChecked, int a_nUserId);
        public void onDataSetChagnged();
    }
    private void doShowProfile()
    {
        Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_DepartmentUserListData.getUserNo());
        m_Context.startActivity(intent);
    }


    public void showProgress() {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Context);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void showProgress(String a_strMsg) {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Context, a_strMsg);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void closeProgress() {
        if (m_Progress != null && m_Progress.isShowing())
            m_Progress.cancel();
    }

}
