package com.gmp.rusk.act;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * ChatRoomAct
 * 
 * @author kch 전체보기 Activity
 */

public class ChatRoomAllViewAct extends CustomActivity {

	Intent intent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatroom_allview);
		intent = getIntent();
		init();
		
		Bundle bundle = getIntent().getExtras();

		if (bundle != null){
			super.m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID, "");
			 
		}

	}

	private void init() {
		ImageView ivTopBack = (ImageView)findViewById(R.id.iv_chat_back);
		ivTopBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		EmoticonUtils utils = new EmoticonUtils();
		TextView tv_AllText = (TextView) findViewById(R.id.tv_chat_allview);
		tv_AllText.setText(utils.parsingEmoticonText(this, intent.getExtras().getString(IntentKeyString.INTENT_KEY_TEXT), (int) tv_AllText.getTextSize()));

	}
}
