package com.gmp.rusk.request;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author dym
 *			Read Count 검색
 *			method : post
 */

public class PostReadCountReq extends Req{
	
	private String APINAME = "support";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	private final String JSON_MESSAGEIDS = "messageIds";
	
	private ArrayList<String> m_arrMessageIds = null;
		
	public PostReadCountReq(ArrayList<String> a_arrMessageIds)
	{
		APINAME = APINAME +"/unread-count";
		
		m_arrMessageIds = a_arrMessageIds;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			int nMessageIdSize = m_arrMessageIds.size();

/*			StringBuffer strMessageIds = new StringBuffer();
			for(int i = 0; i < nMessageIdSize; i++)
			{
				String text = m_arrMessageIds.get(i) + ",";
				strMessageIds.append(text);

			}*/

			JSONObject jsonObj = new JSONObject();
			//jsonObj.put(JSON_MESSAGEIDS, "[" + strMessageIds.substring(0, strMessageIds.length()-1) + "]");
			jsonObj.put(JSON_MESSAGEIDS, new JSONArray(m_arrMessageIds));
			String json = jsonObj.toString().replace("\\", "");
			return json;
		} catch (Exception e) {
			CommonLog.e("PostReadCountReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
