package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.SNSGroupMemberData;

public class GetGroupUserRes extends ChannelRes{

	private final String JSON_MEMBERS				= "members";
	private final String JSON_USERNO				= "userNo";
	private final String JSON_OWNER				= "owner";
	private final String JSON_INVITEDMEMBER			= "invitedMembers";

	ArrayList<SNSGroupMemberData> m_arrGroupMember = new ArrayList<SNSGroupMemberData>();
	ArrayList<Integer> m_arrGroupInvitedMember = new ArrayList<Integer>();
	public GetGroupUserRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			JSONArray jsonMembers = jsonRoot.getJSONArray(JSON_MEMBERS);
			int nMembersSize = jsonMembers.length();
			for(int i = 0; i < nMembersSize; i++)
			{
				JSONObject jsonMember = jsonMembers.getJSONObject(i);
				SNSGroupMemberData memberData = new SNSGroupMemberData();
				memberData.m_nUserNo = jsonMember.getInt(JSON_USERNO);
				memberData.m_isOwner = jsonMember.getBoolean(JSON_OWNER);
				m_arrGroupMember.add(memberData);
			}

			JSONArray jsonInvitedMembers = jsonRoot.getJSONArray(JSON_INVITEDMEMBER);
			int nInvitiedMembersSize = jsonInvitedMembers.length();
			for(int i = 0; i < nInvitiedMembersSize; i++)
			{
				JSONObject jsonInvitedMember = jsonInvitedMembers.getJSONObject(i);
				m_arrGroupInvitedMember.add(jsonInvitedMember.getInt(JSON_USERNO));
			}

			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<SNSGroupMemberData> getGroupMemberList()
	{
		return m_arrGroupMember;
	}

	public ArrayList<Integer> getGroupInvitedMemberList() {
		return m_arrGroupInvitedMember;
	}
}