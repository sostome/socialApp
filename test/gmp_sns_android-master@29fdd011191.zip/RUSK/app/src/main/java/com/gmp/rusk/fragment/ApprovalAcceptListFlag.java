package com.gmp.rusk.fragment;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ApprovalTabAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.datamodel.ApprovalAcceptListData;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.GMPData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.datamodel.UserUpdateListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.gmp.AuthUtil;
import com.gmp.rusk.gmp.SimpleCrypto;
import com.gmp.rusk.layout.ApprovalAcceptListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeletePartnerApprovalCancelReq;
import com.gmp.rusk.request.GetAccepterPartnerListReq;
import com.gmp.rusk.request.GetEntryReq;
import com.gmp.rusk.request.GetUserListReq;
import com.gmp.rusk.request.PutApprovedPartnerReq;
import com.gmp.rusk.response.GetAccepterPartnerListRes;
import com.gmp.rusk.response.GetEntryRes;
import com.gmp.rusk.response.GetUserListRes;
import com.gmp.rusk.response.Res;

import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * ApprovalAcceptListFlag
 * @author subi78
 * ApprovalAcceptListFlag - 승인 완료 리스트 Fragment
 */
public class ApprovalAcceptListFlag extends Fragment implements OnClickListener, OnItemClickListener{

	public MyApp App = MyApp.getInstance();
	public static final String ID_AUTH_KEY   = "authKey";
	public static final String ID_ENC_PWD    = "encPwd";
	public static final String ID_COMPANY_CD = "companyCd";
	
	private View m_vApprovalAcceptList = null;	
	
	private FragmentActivity m_Activity = null;
	
	private ListView m_lvApprovalAcceptList = null;
	private ApprovalAcceptListApdapter m_ApprovalAcceptAdapter = null;
	
	ArrayList<ApprovalAcceptListData> m_arrAcceptListDatas = null;
	ArrayList<ApprovalAcceptListData> m_arrAcceptSearchListDatas = null;

	LinearLayout layout_nolisttext;
	
	private ProgressDlg m_Progress = null;
	
	private CommonPopup m_Popup = null;
	
	private int m_nUserNo = 0;
	public boolean m_isRunning = false;
	private TextView m_tvDesc;
	
	EditText et_search_keyword;
	ImageButton ib_cancel;
	private InputMethodManager imm; 
	private String m_strTimeStamp = "";
	
	private ArrayList<UserListData> m_arrAddedFellowListData = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        m_Activity = getActivity();
        imm = (InputMethodManager)m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE); 
    }
    
    /**
     * The Fragment's UI is just a simple text view showing its
     * instance number.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    	
    	m_vApprovalAcceptList = inflater.inflate(R.layout.fragact_approvalaccept_list, container, false);
    	
    	((ApprovalTabAct)m_Activity).setTitle(getString(R.string.approvaltab_title));
    	if (App.m_EntryData == null) {
    		initProcess();
		} 
    	else
		{
    		initSetUI();
    		requestGetAccepterPartnerList();
		}
        return m_vApprovalAcceptList;
    }
    
    @Override
    public void onResume() {
    	// TODO Auto-generated method stub
    	super.onResume();
    	if(m_ApprovalAcceptAdapter !=null)
    		m_ApprovalAcceptAdapter.notifyDataSetInvalidated();
    	m_isRunning = true;
    }
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}
	
	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == StaticString.REQUESTCODE_PROFILEVIEW)
		{
			if(resultCode == StaticString.RESULT_PROFILE_NOTIFYCHANGE_IMAGE)
			{
				if(m_ApprovalAcceptAdapter != null)
		    		m_ApprovalAcceptAdapter.notifyDataSetInvalidated();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_pop_ok)
		{
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_OUT)
			{
				requestDeletePartnerApprovalCancel();
			}
			else if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_REAPPROVAL)
			{
				int[] arrUserNo = new int[1];
				arrUserNo[0] = m_nUserNo;
				requestPostApprovedPartner(arrUserNo);
			}
			else if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION)
			{
				if(AppSetting.FEATURE_VARIANT.equals("R"))
				{
					//버전 업데이트 처리
					try{

	                    Intent intent = new Intent("com.sk.pe.group.store.detail"); //GMP 스마트폰 스토어의 상세화면
			             // Intent intent = new Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿 스토어의 상세화면

	                    intent.putExtra("APP_ID", App.m_AppID); //대상 어플 아이디
	                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); //Activity 남기지 않음
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
	                catch(ActivityNotFoundException e){
	                    Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
				}
				else
				{	
					Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
	                startActivity(intent);
	                App.allActivityDestroy();
				}
			}
			popup_ok.cancel();
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			if(popup_cancel.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION)
			{
				if(AppSetting.FEATURE_VARIANT.equals("R"))
					new ReqGMPInfoTask().execute(null,null,null);
				else
				{
					SharedPref pref = SharedPref.getInstance(m_Activity);
					m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

					CommonLog.e(getClass(), "UserList DB update");
					requestUpdateUserList(m_strTimeStamp);
				}
			}
			popup_cancel.cancel();
		}
		else if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	
				popup_ok_long.cancel();
				App.expirePartnerLogin(m_Activity);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_OUT_SUCCESS)
			{
				for(int i=0; i<m_arrAcceptSearchListDatas.size();i++)
				{
					if(m_arrAcceptSearchListDatas.get(i).m_nUserNo == m_nUserNo)
					{
						m_arrAcceptSearchListDatas.remove(i);
						m_ApprovalAcceptAdapter.notifyDataSetInvalidated();
					}
				}
				for(int j=0; j<m_arrAcceptListDatas.size();j++)
				{
					if(m_arrAcceptListDatas.get(j).m_nUserNo == m_nUserNo)
					{
						m_arrAcceptListDatas.remove(j);
						m_ApprovalAcceptAdapter.notifyDataSetInvalidated();
					}
				}
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Activity);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION)
			{
				popup_ok_long.cancel();
				CommonLog.e("","update..... gogo");
				if(AppSetting.FEATURE_VARIANT.equals("R"))
				{
					//버전 업데이트 처리
					try{

	                    Intent intent = new Intent("com.sk.pe.group.store.detail"); //GMP 스마트폰 스토어의 상세화면
			             // Intent intent = new Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿 스토어의 상세화면

	                    intent.putExtra("APP_ID", App.m_AppID); //대상 어플 아이디
	                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); //Activity 남기지 않음
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
	                catch(ActivityNotFoundException e){
	                    Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
				}
				else
				{	
					Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
	                startActivity(intent);
	                App.allActivityDestroy();
				}
			}
			else if(popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_NO_SEARCH)
			{
				popup_ok_long.cancel();
				et_search_keyword.setText("");
				m_arrAcceptSearchListDatas = m_arrAcceptListDatas;
				m_ApprovalAcceptAdapter.notifyDataSetChanged();
				if(!m_arrAcceptSearchListDatas.isEmpty()){
		    		layout_nolisttext.setVisibility(View.GONE);
		    	}
				m_tvDesc.setText(getString(R.string.approvalaccept_description));
			}
			popup_ok_long.cancel();
		}
	}
    
    private void initSetUI()
    {
    	m_lvApprovalAcceptList = (ListView)m_vApprovalAcceptList.findViewById(R.id.lv_approvalpending_list);
    	
    	layout_nolisttext = (LinearLayout)m_vApprovalAcceptList.findViewById(R.id.layout_hinttext);
    	//layout_nolisttext.setVisibility(View.VISIBLE);
    	
    	m_tvDesc = (TextView)m_vApprovalAcceptList.findViewById(R.id.tv_approvalaccept_text);
    	m_tvDesc.setText(getString(R.string.approvalaccept_description));
//    	et_search_keyword.setImeOptions(EditorInfo.IME_ACTION_SEARCH);

    }
    
    private void initSearch(String a_strKeyword){
    	m_arrAcceptSearchListDatas = new ArrayList<ApprovalAcceptListData>();
    	if(m_arrAcceptListDatas != null){
    		for(int i = 0; i < m_arrAcceptListDatas.size(); i++){
    			if(m_arrAcceptListDatas.get(i).m_strName.contains(a_strKeyword) || m_arrAcceptListDatas.get(i).m_strAffiliation.contains(a_strKeyword)){
    				m_arrAcceptSearchListDatas.add(m_arrAcceptListDatas.get(i));
    			}
    		}
    		if(!m_arrAcceptSearchListDatas.isEmpty()){
    			layout_nolisttext.setVisibility(View.GONE);
    			m_tvDesc.setText(getString(R.string.approvaltab_search_text));
    			m_ApprovalAcceptAdapter.notifyDataSetChanged();
    		} 
    		else {
    			m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_NO_SEARCH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.layout_sectionstring_search_noresult));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
    		}
    		
    	}
    	
    }
    private void setApprovalPendingApdapter()
    {	
    	m_ApprovalAcceptAdapter = new ApprovalAcceptListApdapter();
        if(m_arrAcceptSearchListDatas != null && !m_arrAcceptSearchListDatas.isEmpty())
        {
        	CommonLog.e("", "m_arrAcceptListDatas != null");
        	m_lvApprovalAcceptList.setVisibility(View.VISIBLE);
        	layout_nolisttext.setVisibility(View.GONE);
        	
    	
        	m_lvApprovalAcceptList.setAdapter(m_ApprovalAcceptAdapter);
    	
        	m_lvApprovalAcceptList.setOnScrollListener(new OnScrollListener() {
			
				@Override
				public void onScrollStateChanged(AbsListView view, int scrollState) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onScroll(AbsListView view, int firstVisibleItem,
						int visibleItemCount, int totalItemCount) {
					// TODO Auto-generated method stub
	
				}
			});
        	m_lvApprovalAcceptList.setOnItemClickListener(this);
        }
        else
        {
        	CommonLog.e("", "m_arrAcceptListDatas == null");
        	m_lvApprovalAcceptList.setVisibility(View.INVISIBLE);
        	layout_nolisttext.setVisibility(View.VISIBLE);
        	initSetUI();
        }
    }
    
	// ApprovalAcceptList Adapter
	private class ApprovalAcceptListApdapter extends BaseAdapter
	{	
		
		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub
			
			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if(m_arrAcceptSearchListDatas != null)
				return m_arrAcceptSearchListDatas.size();
			
			return 0;
		}

		@Override
		public Object getItem(int position) {
//			if(position == 0) return header;
			
			if(m_arrAcceptSearchListDatas != null)
				return m_arrAcceptSearchListDatas.get(position);
			
			return null;
		}
		
		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) 
		{
			final int nPosition = position;
			ApprovalAcceptListData data = (ApprovalAcceptListData)m_arrAcceptSearchListDatas.get(nPosition);
			
			CommonLog.e(getClass(), "getView");
			
			
			// convertView null 시 새로 생성하자
			if(convertView == null)
				convertView = new ApprovalAcceptListItemLayout(m_Activity);
			
			((ApprovalAcceptListItemLayout)convertView).setApprovalAcceptListData(data);	
						
			((ApprovalAcceptListItemLayout)convertView).setApprovalAcceptListener(m_ApprovalAcceptListner);
			return convertView;
		}	
	}    
    
    private void requestGetAccepterPartnerList()
    {
    	showProgress(getString(R.string.progress_search));
    	GetAccepterPartnerListReq req = new GetAccepterPartnerListReq();
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e("", "requestGetPartnerApprovalList... post..");
				closeProgress();
				GetAccepterPartnerListRes res = new GetAccepterPartnerListRes(a_strData);
				m_arrAcceptListDatas = new ArrayList<ApprovalAcceptListData>();
				if(res.getApprovalAcceptList() != null)
				{
					m_arrAcceptListDatas = res.getApprovalAcceptList();
					m_arrAcceptSearchListDatas = m_arrAcceptListDatas;
				}
				setApprovalPendingApdapter();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
    }
    
    private void requestDeletePartnerApprovalCancel()
    {
    	showProgress();
    	DeletePartnerApprovalCancelReq req = new DeletePartnerApprovalCancelReq(m_nUserNo);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_OUT_SUCCESS);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_approvalaccept_out).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
    }

	private void requestPostApprovedPartner(final int[] a_nUserNo)
	{
		showProgress(getString(R.string.progress_search));
		PutApprovedPartnerReq req = new PutApprovedPartnerReq(a_nUserNo);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				for(int i=0; i<m_arrAcceptSearchListDatas.size();i++)
				{
					if(m_arrAcceptSearchListDatas.get(i).m_nUserNo == m_nUserNo)
					{
						m_arrAcceptSearchListDatas.get(i).m_isExpiresoon = false;
						m_ApprovalAcceptAdapter.notifyDataSetInvalidated();
					}
				}
				for(int j=0; j<m_arrAcceptListDatas.size();j++)
				{
					if(m_arrAcceptListDatas.get(j).m_nUserNo == m_nUserNo)
					{
						m_arrAcceptListDatas.get(j).m_isExpiresoon = false;
						m_ApprovalAcceptAdapter.notifyDataSetInvalidated();
					}
				}
				closeProgress();

			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	ApprovalAcceptListItemLayout.OnApprovalAcceptListener m_ApprovalAcceptListner = new ApprovalAcceptListItemLayout.OnApprovalAcceptListener() {
		@Override
		public void onApprovalOut(int a_nApprovalPendingUserNo) {
			// TODO Auto-generated method stub
			m_nUserNo = 0;
			m_nUserNo = a_nApprovalPendingUserNo;
			
			m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
					CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_OUT);
			m_Popup.setBodyAndTitleText(
					getString(R.string.pop_error_title).toString(),
					getString(R.string.pop_approvalaccept_prev_out).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}

		@Override
		public void onReApproval(int a_nReApprovalUserNo) {
			m_nUserNo = 0;
			m_nUserNo = a_nReApprovalUserNo;

			m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
					CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_REAPPROVAL);
			m_Popup.setBodyAndTitleText(
					getString(R.string.pop_error_title).toString(),
					getString(R.string.pop_approvalaccept_reapproval).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	};
    
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		doShowProfile(m_arrAcceptSearchListDatas.get(position).m_nUserNo);
	}
	
	private void doShowProfile(int a_nUserNo)
	{
		Intent intent = new Intent(getActivity(), ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, a_nUserNo);
		startActivityForResult(intent, StaticString.REQUESTCODE_PROFILEVIEW);
	}

    public void initProcess()
    {
    	if(AppSetting.FEATURE_VARIANT.equals("R"))
			doGMPLogin();
		else
			new ReqVersionInfoTask().execute(null,null,null);
//			new ReqGMPInfoTask().execute(null,null,null);
    }
    
    /*
	 * 사용자 목록 조회 및 Update
	 */
	
	private void doUserListSync()
	{
		SharedPref pref = SharedPref.getInstance(m_Activity);
		if(!AppSetting.FEATURE_VARIANT.equals("R"))
		{	
			int nUpdateType = Utils.CheckVersion(m_Activity,App.m_EntryData.m_strLatestVersion);
			if(nUpdateType == 1)
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			else if(nUpdateType == 2)
			{
				if(!pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(App.m_EntryData.m_strLatestVersion))
				{
					pref.setStringPref(SharedPref.PREF_GMP_VERSION, App.m_EntryData.m_strLatestVersion);
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.update_version).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}
		}
		m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);
		
		CommonLog.e(getClass(), "UserList DB update");
		requestUpdateUserList(m_strTimeStamp);
	}
    /*
	 * GMPLogin
	 */
	private void doGMPLogin()
	{
		
		//GMP 인증
		if(!AuthUtil.isLogin(m_Activity, App.m_Mdn, App.m_AppID)){
			AuthUtil.runGMPLogin(m_Activity);			
		}else{
			requestEntry();
		}
	}
	
	private class ReqGMPInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			try {
				Map<String,String> map = new HashMap<String,String>();
				
				CommonLog.e(getClass(), "getGMPAuthPwd start");	
					map = AuthUtil.getAuthInfo(m_Activity,App.m_Mdn,App.m_AppID);
					
					CommonLog.e(getClass(), "getGMPAuthPwd end");
//				String secretkeydecrypt = null;
				strResultCode = map.get("result_code");
				if(strResultCode.equals("1000")){ // 정상 처리일 경우정상 처리 코드 넣어주시기 바랍니다.
					String strRegularID = "";
					String secretkey = AuthUtil.getSecretKey(m_Activity); //비밀키 얻어오기
					try{
						strRegularID = SimpleCrypto.decrypt(secretkey, map.get("result_user_num")); // 복호화
					}catch (Exception e){
						strRegularID = "-2"; //복호화 실패시 아이디 값에 넣어줌
					}
					
					App.m_GMPData = new GMPData(map.get(ID_COMPANY_CD), strRegularID, map.get(ID_AUTH_KEY), map.get(ID_ENC_PWD));
					
				}               
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("1000")) 
				requestEntry();
			else if(result.equals("7009"))
			{
				try {
					AuthUtil.logout(m_Activity);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					doGMPLogin();
				}
			}
			else if(result.equals("3205"))
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			else
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}
	
	private class ReqVersionInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		String strAppVersion = "";
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			try {
				Map<String,String> map = new HashMap<String,String>();
				
				CommonLog.e(getClass(), "getVersionInfo start");	
					map = AuthUtil.getVersionInfo(m_Activity,App.m_Mdn,App.m_AppID);
					
					CommonLog.e(getClass(), "getVersionInfo end");
//				String secretkeydecrypt = null;
				strResultCode = map.get("result");
				if(strResultCode.equals("1000")){ // 정상 처리일 경우정상 처리 코드 넣어주시기 바랍니다.
					CommonLog.e(getClass(), "result : 1000");	
					strAppVersion = map.get("appVer");
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("1000")) 
			{
				if(strAppVersion.equals(""))
				{
					new ReqGMPInfoTask().execute(null,null,null);
				}
				else
				{
					SharedPref pref = SharedPref.getInstance(m_Activity);
					int nUpdateType = Utils.CheckVersion(m_Activity, strAppVersion);
					if(nUpdateType == 2 && !pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(strAppVersion))
					{
						pref.setStringPref(SharedPref.PREF_GMP_VERSION, strAppVersion);
						m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
						m_Popup.setBodyAndTitleText(
								getString(R.string.pop_error_title).toString(),
								getString(R.string.update_version).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
					else
					{
						new ReqGMPInfoTask().execute(null,null,null);
					}
				}
			}
			else if(result.equals("7009"))
			{
				try {
					AuthUtil.logout(m_Activity);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					doGMPLogin();
				}
			}
			else if(result.equals("3205"))
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			else
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}
	
	public void requestEntry()
	{
//		showProgress(getString(R.string.progress_entry).toString());
		GetEntryReq req = new GetEntryReq();
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetEntryRes res = new GetEntryRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				//App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate, res.m_strPreviewImageUrlTemplate,res.m_strEmoticonTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);
				App.m_MyUserInfo = res.getEntryUserData(m_Activity);
//				closeProgress();
				doUserListSync();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
//				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}				
			}
		});
	}
	
	public void requestUpdateUserList(String a_strTimeStamp)
	{
//		showProgress(getString(R.string.progress_getfellowlist));
		GetUserListReq req = new GetUserListReq(a_strTimeStamp);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);
				
				if(res.getUserListData() != null)
				{
					for(UserListData data : res.getUserListData())
					{
						UserListData getitem = ContactsDBManager.getContacts(m_Activity, data.m_nUserNo);
						if(getitem == null)
						{
							UserListData item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType , data.m_isImageAvailable, data.m_isActive, data.m_strGreeting, "A", false, "");
							ContactsDBManager.insertContacts(m_Activity, item);
						}
						else
						{							
							UserListData item = null;
							if(data.m_strUserStatus.equals("A"))
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive, data.m_strGreeting, data.m_strUserStatus,
										getitem.m_isFellow, getitem.m_strFellowAddTime);
							else
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive, data.m_strGreeting, data.m_strUserStatus,
										getitem.m_isFellow, "");
							
							ContactsDBManager.updateContacts(m_Activity, item);
						}
					}
				}
				SharedPref pref = SharedPref.getInstance(m_Activity);
				pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);
				
				
				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
				finally
				{
			    	initSetUI();
			    	requestGetAccepterPartnerList();
				}
				
				
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
//				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalAcceptListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
			    	initSetUI();
			    	requestGetAccepterPartnerList();
				}
			}
		});
	}
	
	private ArrayList<FellowListData> setFellowList() throws Exception
    {    
    	m_arrAddedFellowListData = TTalkDBManager.ContactsDBManager.getContactsByFellows(m_Activity); 
    	App.m_arrFellowListData = new ArrayList<FellowListData>();
    	//CommonLog.e("", "setFellowList() lol : " + App.m_EntryData.m_strLol);
		for (UserListData data : m_arrAddedFellowListData) {
			HashMap<String, String> personalData = data.m_PersonalData.mapPersonalData;
			if (data.m_strUserType.equals("R")) {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
						personalData.get(PersonalData.CHARGE), data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			} else {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
						data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			}
		}
    	
    	return App.m_arrFellowListData;
    }
}