package com.gmp.rusk.request;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author subi78
 *			파트너 비밀번호 찾기 인증 요청
 *			method : post
 */

public class PostFindPasswordAuthPartnerReq extends Req{
	
	private String APINAME = "partner";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "POST";
	
	private final String JSON_NAME = "name";
	private final String JSON_EMAIL = "email";
	
	private String m_strName = "";			//사용자 이름
	private String m_strEmail = "";				//사용자 이메일
		
	public PostFindPasswordAuthPartnerReq(String a_strUserId, String a_strName, String a_strEmail)
	{
		APINAME = APINAME +"/find-password/"+a_strUserId;
		
		m_strName = a_strName;
		m_strEmail = a_strEmail;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_NAME, m_strName);
			jsonObj.put(JSON_EMAIL, m_strEmail);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PostFindPasswordAuthPartnerReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
