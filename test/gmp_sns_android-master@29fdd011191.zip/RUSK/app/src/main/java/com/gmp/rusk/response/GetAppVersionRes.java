package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class GetAppVersionRes extends Res{

    private final String JSON_LATEST = "latest";
    private final String JSON_DOWNLOADURL = "downloadUrl";

    private String m_strLatestVersion = "";
    private String m_strDownloadUrl = "";

    public GetAppVersionRes(String a_strData) {
        super(a_strData);
        // TODO Auto-generated constructor stub
        parseData();
    }

    @Override
    public void parseData() {
        // TODO Auto-generated method stub
        try {
            JSONObject jsonRoot = new JSONObject(m_strResData);

            m_strLatestVersion = jsonRoot.getString(JSON_LATEST);
            m_strDownloadUrl = jsonRoot.getString(JSON_DOWNLOADURL);

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String getLatestVersion()
    {
        return m_strLatestVersion;
    }
}
