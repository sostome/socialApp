package com.gmp.rusk.request;

import org.json.JSONObject;


import com.gmp.rusk.utils.CommonLog;

/**
 *	@author kch
 *			모임 게시글 댓글 수정
 *			method : put
 */

public class PutGroupReplyReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";

	private final String jSON_BODY		= "body";

	private String m_strBody = "";
	
	public PutGroupReplyReq(int a_nThreadId, int a_nCommentNo, int a_nChannelId, String a_strBody)
	{
		APINAME = APINAME + "/" + a_nChannelId + "/thread/" + a_nThreadId + "/comment/" + a_nCommentNo;

		m_strBody = a_strBody;
	}
	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(jSON_BODY, m_strBody);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PutGroupReplyReq.class.getSimpleName(), "" + e.getMessage());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
