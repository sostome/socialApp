package com.gmp.rusk.datamodel;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-16.
 */

public class ChannelUnreadsData {

    public int m_nChannelNo = 0;
    //기본적으로 threadNo를 넣으며, 댓글일 경우 threadNo 를 |(pipe) 로 구분하여 commnetNo를 넣는다
    public ArrayList<String> m_arrThreadAndCommentNo = new ArrayList<String>();

}
