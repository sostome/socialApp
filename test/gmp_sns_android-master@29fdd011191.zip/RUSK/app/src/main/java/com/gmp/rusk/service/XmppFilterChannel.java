package com.gmp.rusk.service;

import android.content.Context;
import android.os.Handler;

import com.gmp.rusk.extension.ChannelEx;
import com.gmp.rusk.extension.ChannelInviteEx;
import com.gmp.rusk.extension.EmoticonEx;
import com.gmp.rusk.extension.ReadEx;
import com.gmp.rusk.extension.RequestEx;
import com.gmp.rusk.utils.CommonLog;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;

/**
 * Created by K on 2017-10-08.
 */

public class XmppFilterChannel extends XmppFilterMessage{

    Handler mHandler;
    XMPPConnection connection;
    Context mContext;
    XmppListener mXmppListener;


    public XmppFilterChannel(XmppListener listener, Handler handler, XMPPConnection superConnection, Context context) {
        mXmppListener = listener;
        mHandler = handler;
        connection = superConnection;
        mContext = context;
        setContext(context);
    }

    public void setFilter(final Packet message) {
        PacketExtension packetExtensionReceq = message.getExtension(RequestEx.NAMESPACE);
        PacketExtension packetExtensionRead = message.getExtension(ReadEx.NAMESPACE);
        ChannelEx channelEx = (ChannelEx)message.getExtension(ChannelEx.NAMESPACE);
        ChannelInviteEx channelInviteEx = (ChannelInviteEx)message.getExtension(ChannelInviteEx.NAMESPACE);

        if(channelEx != null){
            if(mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null){
                mXmppListener.getNotifyListner().onChannelNotify(Integer.parseInt(channelEx.getChannelNo()), Integer.parseInt(channelEx.getThreadNo()), Integer.parseInt(channelEx.getCommentNo()));
            }
        } else if(channelInviteEx != null){
            if(mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null){
                mXmppListener.getNotifyListner().onChannelInviteNotify(Integer.parseInt(channelInviteEx.getChannelNo()));
            }
        }
    }
}
