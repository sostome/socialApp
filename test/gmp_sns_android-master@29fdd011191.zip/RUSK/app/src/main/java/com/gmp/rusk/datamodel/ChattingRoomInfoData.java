package com.gmp.rusk.datamodel;

public class ChattingRoomInfoData {
	public String m_strRoomId = "";				// Room Id
	public String m_strRoomTitle = "";			// Room Title
	public boolean m_isAlarmOn = true;			// Alarm On/Off
	public int m_nRoomOwnerId = 0;				// Room Owner Id
	public boolean m_isTitleEdited = false;		// Room Title isEdited
	public boolean m_isFavorite = false;		// Room Favorite
	public int m_backgroundColor = 0;
	public String m_strCoverImagUrl = "";

	public ChattingRoomInfoData(){

	}

	public ChattingRoomInfoData(String a_strRoomId, String a_strRoomTitle, boolean a_isAlarmOn, int a_nRoomOwnerId, boolean a_isTitleEdited)
	{
		m_strRoomId = a_strRoomId;
		m_strRoomTitle = a_strRoomTitle;
		m_isAlarmOn = a_isAlarmOn;
		m_nRoomOwnerId = a_nRoomOwnerId;
		m_isTitleEdited = a_isTitleEdited;
		m_isFavorite = false;
	}
	
	public ChattingRoomInfoData(String a_strRoomId, String a_strRoomTitle, boolean a_isAlarmOn, int a_nRoomOwnerId, boolean a_isTitleEdited, boolean a_isFavorite)
	{
		m_strRoomId = a_strRoomId;
		m_strRoomTitle = a_strRoomTitle;
		m_isAlarmOn = a_isAlarmOn;
		m_nRoomOwnerId = a_nRoomOwnerId;
		m_isTitleEdited = a_isTitleEdited;
		m_isFavorite = a_isFavorite;
	}

	public ChattingRoomInfoData(String a_strRoomId, String a_strRoomTitle, boolean a_isAlarmOn, int a_nRoomOwnerId, boolean a_isTitleEdited, boolean a_isFavorite,int a_backgroundColor)
	{
		m_strRoomId = a_strRoomId;
		m_strRoomTitle = a_strRoomTitle;
		m_isAlarmOn = a_isAlarmOn;
		m_nRoomOwnerId = a_nRoomOwnerId;
		m_isTitleEdited = a_isTitleEdited;
		m_isFavorite = a_isFavorite;
		m_backgroundColor = a_backgroundColor;
	}
	public ChattingRoomInfoData(String a_strRoomId, String a_strRoomTitle, boolean a_isAlarmOn, int a_nRoomOwnerId, boolean a_isTitleEdited,String a_strCoverImage)
	{
		m_strRoomId = a_strRoomId;
		m_strRoomTitle = a_strRoomTitle;
		m_isAlarmOn = a_isAlarmOn;
		m_nRoomOwnerId = a_nRoomOwnerId;
		m_isTitleEdited = a_isTitleEdited;
		m_strCoverImagUrl = a_strCoverImage;
	}
	public ChattingRoomInfoData(String a_strRoomId, String a_strRoomTitle, boolean a_isAlarmOn, int a_nRoomOwnerId, boolean a_isTitleEdited, boolean a_isFavorite,int a_backgroundColor,String a_strCoverImage)
	{
		m_strRoomId = a_strRoomId;
		m_strRoomTitle = a_strRoomTitle;
		m_isAlarmOn = a_isAlarmOn;
		m_nRoomOwnerId = a_nRoomOwnerId;
		m_isTitleEdited = a_isTitleEdited;
		m_isFavorite = a_isFavorite;
		m_backgroundColor = a_backgroundColor;
		m_strCoverImagUrl = a_strCoverImage;
	}
}
