package com.gmp.rusk.request;

/**
 *	@author kch
 *			사용자 정보 조회
 *			method : get
 */

public class GetUserInfoReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";
	
	
	public GetUserInfoReq(int a_nTargetUserNo)
	{
		APINAME = APINAME + "/" + App.m_MyUserInfo.m_nUserNo + "/related-user/" + a_nTargetUserNo;
	}

	public GetUserInfoReq(int a_nTargetUserNo, boolean isProfile){
		APINAME = APINAME + "/" + App.m_MyUserInfo.m_nUserNo + "/info/" + a_nTargetUserNo;
	}
	public GetUserInfoReq(int[] a_nArrTargetUserNo)
	{
		StringBuffer strTargetUserNos = new StringBuffer();
		for(int i=0;i<a_nArrTargetUserNo.length;i++)
		{
			strTargetUserNos.append(""+a_nArrTargetUserNo[i]);
			if(i < a_nArrTargetUserNo.length-1)
				strTargetUserNos.append(",");
		}
		APINAME = APINAME + "/" + App.m_MyUserInfo.m_nUserNo + "/related-user/" + strTargetUserNos;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
