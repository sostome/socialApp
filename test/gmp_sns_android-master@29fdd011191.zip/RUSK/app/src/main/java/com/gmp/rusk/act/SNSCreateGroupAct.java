package com.gmp.rusk.act;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostGroupReq;
import com.gmp.rusk.request.PutGroupReq;
import com.gmp.rusk.request.Req;
import com.gmp.rusk.response.PostGroupImageUploadRes;
import com.gmp.rusk.response.PostGroupRes;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;

/**
 * @brief      	모임 생성 Activity
 * @details
 * @author      강효재
 * @date        2017-01-17
 */
public class SNSCreateGroupAct extends CustomActivity implements OnClickListener{
	
	private boolean m_isEditGroup = false;
	private int m_nEditGroupId = 0;
	private String m_strEditGroupName = "";
	private String m_strEditGroupImageUrl = "";
	
	// 0 : Picture Select, 1~n: DefaultImage1~n
	private int m_nSelectedIndex = 1;
	private CommonPopup m_Popup = null;
	private CommonListPopup m_ListPopup = null;
	
	private TakeMediaIntent m_TakeMedia = null;
	EditText m_etGroupName;
	private Bitmap m_Bitmap;
	private byte[] m_BitmapByte;
	private ImageLoaderManager imageLoaderManager;
	private String strPreviewURL = "";
	private String strImageURL = "";

	/**
	 * @brief       액티비티가 처음에 만들어졌을 때 호출됨. getIntentData(),initUI(),setUI()를 차례로 호출한다.
	 * @param       arg0  Bundle
	 * @return      void
	 */
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_snscreategroup);
		
		getIntentData();
		initUI();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}
	}
	/**
	 * @brief      	intent로부터 정보를 받아 온다.
	 * @details		이 Activity에 오는 경우는 2가지가 있다. 모임 생성하러 올 때와 모임 수정할 경우<br>
	 *     			모임 생성인 경우는 intent로 받아올 것이 없지만 수정인 경우는 groupId,groupName,이전 선택 이미지를 받아서 저장한다.
	 * @param
	 * @return      void
	 */
	private void getIntentData()
	{
		m_isEditGroup = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_ISEDIT, false);
		if(m_isEditGroup)
		{
			m_nEditGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPID, 0);
			m_strEditGroupName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPNAME);
			m_nSelectedIndex = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPDEFAULTIMAGEIDX, 0);
			if(m_nSelectedIndex < 1)
			{
				m_nSelectedIndex = 0;
				m_strEditGroupImageUrl = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPIMAGEURL);
			}
		}
	}
	/**
	 * @brief       모임 생성(모임 수정)의 전반적인 UI를 세팅한다.
	 * @details		모임 수정일 경우 제목은 모임명/커버이다. 가져온 group이름을 세팅하고 이전 이미지를 세팅한다.<br>
	 *     			모임 생성일 경우 제목을 모임 생성으로 하고 이미지를 랜덤하게 선택해 둔다.<br>
	 *     			각 이미지에 대해서 onCLickListener를 달아 준다.
	 *
	 * @param
	 * @return      void
	 */
	private void initUI()
	{
		imageLoaderManager = ImageLoaderManager.getInstance(this);
		TextView tvTitle = (TextView)findViewById(R.id.tv_snscreategroup_title);
		m_etGroupName = (EditText)findViewById(R.id.et_snscreategroup_name);
		final ImageButton ibCancel = (ImageButton)findViewById(R.id.ib_cancel);
		ibCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_etGroupName.setText("");
				ibCancel.setVisibility(View.GONE);
			}
		});
		setSaveButtonEnable(false);
		m_etGroupName.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if (s.length() > 0){
					setSaveButtonEnable(true);
					ibCancel.setVisibility(View.VISIBLE);
				} else {
					setSaveButtonEnable(false);
					ibCancel.setVisibility(View.GONE);
				}
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

		if(m_isEditGroup)
		{
			tvTitle.setText(R.string.snscreategroup_edit_title);

			m_etGroupName.setText(m_strEditGroupName);
			m_etGroupName.setHint(m_strEditGroupName);
			m_etGroupName.setSelection(m_etGroupName.length());
		}
		else
		{
			Random rand = new Random();
			m_nSelectedIndex = rand.nextInt(9) + 1;
			tvTitle.setText(R.string.snscreategroup_title);
		}
		
		ImageView btnCreateGroup = (ImageView)findViewById(R.id.btn_snscreategroup_save);
		ImageView btnCancel = (ImageView)findViewById(R.id.btn_cancel);
		btnCreateGroup.setOnClickListener(this);
		btnCancel.setOnClickListener(this);
	}

	private void setSaveButtonEnable(boolean a_isEnable)
	{
		ImageView btnCreateGroup = (ImageView) findViewById(R.id.btn_snscreategroup_save);
		btnCreateGroup.setEnabled(a_isEnable);
		if(a_isEnable)
			btnCreateGroup.setImageResource(R.drawable.btn_btn_top_ok);
		else
			btnCreateGroup.setImageResource(R.drawable.btn_top_ok_disabled);
	}

	/**
	 * @brief       setCenterImage()와 setSelectedThumbImage()를 호출한다.
	 * @param
	 * @return      void
	 */

	/**
	 * @brief       클릭이벤트에 대한 처리
	 * @details     1) 완료버튼 					->	createGroup()호출
	 * 				2) 카메라모양 사진 선택 버튼 	->	showSelectImageSetPopup()
	 * 				3) 준비된 이미지를 선택 		->	m_nSelectedIndex의 값을 선택한 이미지의 index(1부터 시작)값으로 변경하고 setCenterImage및 setSelectedThumbImage를 호출한다.
	 * 												(setUI에서 2메소드를 호출하니 setUI로 대체 가능할 것 같다.)
	 * 				4) ok_Long 버튼 				->	세션만료/디바이스 변경의 경우 App.expirePartnerLogin(this)호출
	 * @param       v	View
	 * @return      void
	 */
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		
		if(nId == R.id.btn_snscreategroup_save)
		{
			createGroup();
		}
		else if(nId == R.id.btn_cancel){
			if(m_isEditGroup)
				finish();
			else {
				if(m_etGroupName.getText().toString().equals(""))
					finish();
				else {
					m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_close_create_channel));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		} else if(nId == R.id.ib_pop_ok){
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			finish();
		} else if(nId == R.id.ib_pop_cancel){
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE) {
				popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_COMPLETE){
				popup_ok_long.cancel();
				finish();
			} else {
				popup_ok_long.cancel();
			}
		}
		super.onClick(v);
	}

	@Override
	public void onBackPressed() {
		if(m_etGroupName.getText().toString().equals(""))
			finish();
		else {
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_close_create_channel));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	}

	/**
	 * @brief       startActivityForResult에 의해 갔다가 돌아왔을 때 이곳으로 온다.
	 * @details		1) 앨범에서 선택 	->	m_TakeMedia.doCropImageFromAlbumWithAspect()호출		->(결국에는 REQUEST_CROP부분으로 옴)	bitMap을 setting하고 setUI안의 메소드 호출
	 * 				2) 카메라에서		->	m_TakeMedia.doCropImageFromCameraWithAspect()호출	->(결국에는 REQUEST_CROP부분으로 옴)	bitMap을 setting하고 setUI안의 메소드 호출
	 * @param       requestCode    	요청 코드
	 * @param 		resultCode		결과 코드
	 * @param 		data			데이터
	 * @return      void
	 */


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM) {
				// Album에서 Image 선택후 Crop 실행
				Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
				ArrayList<GalleryListData> arrSelectedImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);
				if(arrSelectedImage != null && arrSelectedImage.size() > 0)
				{
					GalleryListData galleryListData = arrSelectedImage.get(0);
					CommonLog.e(getClass(), "getDirName : " + galleryListData.getDirName());
					CommonLog.e(getClass(), "getDirPath : " + galleryListData.getDirPath());
					CommonLog.e(getClass(), "getSdcardPath : " + galleryListData.getSdcardPath());
					m_TakeMedia.doCropImageFromAlbumWithAspect(Uri.fromFile(new File(galleryListData.getSdcardPath())));
				}
			}
		} else {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM || requestCode == TakeMediaIntent.REQUESTCODE_CAMERA
					|| requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				// 취소등에 의한 후처리 필요
				m_TakeMedia.deleteDirectory();
				m_TakeMedia = null;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	/**
	 * @brief       이미지 고르기(카메라 모양 버튼) 클릭시 나오는 popup
	 * @details		1) 사진 앨범
	 * 				2)
	 * @param
	 * @return      void
	 */
	private void showSelectImageSetPopup()
	{
		m_ListPopup = new CommonListPopup(this, new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch (v.getId()) {
				case R.id.tv_pop_first_row:
					m_TakeMedia = new TakeMediaIntent(SNSCreateGroupAct.this);
//					m_TakeMedia.doGetImageFromAlbum();
					m_TakeMedia.doGetMultiSelectImageFromGallery(GalleryMultiselectorListAct.FROMACTIVITY_SNS_CREATE, 1, 500000000);
					m_ListPopup.cancel();
					break;
				case R.id.tv_pop_second_row:
					m_TakeMedia = new TakeMediaIntent(SNSCreateGroupAct.this);
					m_TakeMedia.doTakeImageFromCamera();
					m_ListPopup.cancel();
					break;
				case R.id.ib_pop_cancel_long:
					m_ListPopup.cancel();
					break;
				}

			}
		});
		
		m_ListPopup.setBodyAndTitleText(getString(R.string.snscreategroup_imagesetmenupopup_title),
				getResources().getStringArray(R.array.arr_snscreategroup_imageset_menu));
		m_ListPopup.setCancelable(true);
		m_ListPopup.show();
	}
	
	private void createGroup()
	{
		EditText etGroupName = (EditText)findViewById(R.id.et_snscreategroup_name);
		String strGroupName = etGroupName.getText().toString();
		if(strGroupName != null && strGroupName.trim().length() > 1)
		{
			Req req;
			if(m_isEditGroup)
			{
				if(m_nSelectedIndex == 0 && (m_Bitmap == null || m_BitmapByte == null))
					req = new PutGroupReq(m_nEditGroupId, strGroupName);
				else
					req = new PutGroupReq(m_nEditGroupId, strGroupName);
			}
			else
				req = new PostGroupReq(strGroupName);
			
			WebAPI webApi = new WebAPI(this);
			webApi.request(req, new WebListener() {

				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub
					showProgress();
				}

				@Override
				public void onNetworkError(int a_nErrorCode, String a_strMessage) {
					// TODO Auto-generated method stub
					closeProgress();
//					if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
//						m_Popup = new CommonPopup(SNSCreateGroupAct.this, SNSCreateGroupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//								PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
//						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//						m_Popup.setCancelable(false);
//						isCheckShowPopup();
//					} else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE || a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
//						m_Popup = new CommonPopup(SNSCreateGroupAct.this, SNSCreateGroupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
//						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
//						m_Popup.setCancelable(false);
//						isCheckShowPopup();
//					} else if (a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
//						m_Popup = new CommonPopup(SNSCreateGroupAct.this, SNSCreateGroupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
//						m_Popup.setCancelable(false);
//						isCheckShowPopup();
//					} else {
//						m_Popup = new CommonPopup(SNSCreateGroupAct.this, SNSCreateGroupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
//						m_Popup.setCancelable(false);
//						isCheckShowPopup();
//					}
					showErrorPopup(a_nErrorCode, a_strMessage);
				}

				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub
					EditText etGroupName = (EditText)findViewById(R.id.et_snscreategroup_name);
					String strGroupName = etGroupName.getText().toString();
					if(m_isEditGroup) {
						Intent intent = new Intent();
						intent.putExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPNAME, strGroupName);
						setResult(RESULT_OK, intent);
					}
					PostGroupRes res = new PostGroupRes(a_strData);

					closeProgress();
					if(!m_isEditGroup) {
						Intent intent = new Intent();
						intent.putExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPID,res.getChannelNo());
						intent.putExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPNAME, strGroupName);
						setResult(RESULT_OK, intent);

						startGroupMemberInviteActivity(res.getChannelNo(), strGroupName);
						finish();
					}
					else {
						m_Popup = new CommonPopup(SNSCreateGroupAct.this, SNSCreateGroupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_COMPLETE);
						m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_rewrite_snstitle));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}

				}
			});
		}
		else
		{
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_sns_notinputgroupname));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	}
	
	private void startGroupMemberInviteActivity(int a_nGroupId,String a_strChannelName)
	{
		Intent intent = new Intent(this, SNSGroupMemeberInviteAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, a_nGroupId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME,a_strChannelName);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPCREATE, true);
		startActivity(intent);
	}
	
	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}
}
