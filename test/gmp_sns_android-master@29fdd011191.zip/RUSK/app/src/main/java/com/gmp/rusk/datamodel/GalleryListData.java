package com.gmp.rusk.datamodel;

import com.gmp.rusk.utils.CommonLog;

import java.io.Serializable;

@SuppressWarnings("serial")
public class GalleryListData implements Serializable {

	private String	m_strDirPath;			// directory path
	private String	m_strDirName;			// directory name
	private String	m_strSdcardPath;		// file full path
	public boolean	isSeleted	= false;	// select status
	public long		m_nMediaIndex;			// selected file media index
	public String	m_nItemId;				// selected file media id (video id)
	public int		m_strType;				// IMAGE or VIDEO type
	public long		m_lnSize;				// file size
	public int		m_nFileType;			// Directory or File type
	public int m_nSelectedNum = -1;

	public GalleryListData()
	{
	}

	public void setSdcardPath(String path)
	{
		m_strSdcardPath = path;
		m_strDirPath = path.substring(0, path.lastIndexOf("/"));
		String[] tmpPath = path.split("/");
		m_strDirName = tmpPath[tmpPath.length - 1];
	}

	public String getSdcardPath()
	{
		return m_strSdcardPath;
	}

	public String getDirPath()
	{
		return m_strDirPath;
	}

	public String getDirName()
	{
		return m_strDirName;
	}

}
