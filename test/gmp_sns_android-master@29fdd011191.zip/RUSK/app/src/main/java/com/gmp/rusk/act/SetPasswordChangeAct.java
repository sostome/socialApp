package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PutChangePasswordPartnerReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * SetAlramAct
 * @author subi78
 * 알림 설정 Activity
 */
public class SetPasswordChangeAct extends CustomActivity {

	EditText et_now_password;
	EditText et_new_password;
	EditText et_renew_password;
	
	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;
	
	String strNewPw = "";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_set_passwordchange);
		setAccountManagementUI();
	}
	
	
	
	private void setAccountManagementUI()
	{
		et_now_password = (EditText)findViewById(R.id.et_now_password);
		et_new_password = (EditText)findViewById(R.id.et_new_password);
		et_renew_password = (EditText)findViewById(R.id.et_renew_password);
		
		//et_now_password.setFilters(new InputFilter[]{Utils.filterAlphaNum});
		//et_new_password.setFilters(new InputFilter[]{Utils.filterAlphaNum});
		//et_renew_password.setFilters(new InputFilter[]{Utils.filterAlphaNum});
		ImageView btn_close = (ImageView)findViewById(R.id.btn_cancel);
		btn_close.setOnClickListener(this);

		ImageView btn_passwordchange = (ImageView)findViewById(R.id.btn_passwordchange);
		btn_passwordchange.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		if(v.getId() == R.id.btn_passwordchange)
		{
			String strNowPw = et_now_password.getText().toString();
			strNewPw = et_new_password.getText().toString();
			String strReNewPw = et_renew_password.getText().toString();
			
			if(strNowPw.length() < 8 || strNewPw.length() < 8 || strReNewPw.length() < 8)
			{
				m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			} else {
				String input = strNewPw;
				Pattern p = Pattern.compile("([a-zA-Z0-9].*[!,@,#,$,%,^,&,*,?,_,~])|([!,@,#,$,%,^,&,*,?,_,~].*[a-zA-Z0-9])");
				Matcher m = p.matcher(input);
				if (m.find()) {
					//정상적인 비밀번호 이므로 통과
				} else {
					m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.partner_signup_popup_pw_length).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}
			
			if(strNowPw.length() > 20 || strNewPw.length() > 20 || strReNewPw.length() > 20)
			{
				m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(!strNowPw.equals(App.m_PartnerPW))
			{
				m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.set_now_password_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(!strNewPw.equals(strReNewPw))
			{
				m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.set_new_password_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			requestPutChangePasswordPartner(strNewPw);
		} else if(v.getId() == R.id.btn_cancel){
			finish();
		} else if(v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_CHANGE_PASSWORD)
			{
				popup_ok_long.cancel();
				finish();
			}
			else
				popup_ok_long.cancel();
		}
	}
	
	private void requestPutChangePasswordPartner(final String a_strNewPassword)
	{
		showProgress();
		PutChangePasswordPartnerReq req = new PutChangePasswordPartnerReq(a_strNewPassword);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				
				App.m_PartnerPW = a_strNewPassword;
				
				SharedPref pref = SharedPref.getInstance(SetPasswordChangeAct.this);
				pref.setStringPref(SharedPref.PREF_PARTNER_PW, App.m_PartnerPW);
				
				m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES,PopupIndex.INDEX_PREVPOPUP_CHANGE_PASSWORD);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.set_passwordchange_ok).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(SetPasswordChangeAct.this, SetPasswordChangeAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
