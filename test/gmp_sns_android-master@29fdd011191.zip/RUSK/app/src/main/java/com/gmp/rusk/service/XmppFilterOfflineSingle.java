package com.gmp.rusk.service;

import android.content.Context;


import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManagerForDelayMessage;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.extension.ClearEx;
import com.gmp.rusk.extension.DelayInformationTTalk;
import com.gmp.rusk.extension.EmoticonEx;
import com.gmp.rusk.extension.FileEx;
import com.gmp.rusk.extension.PCSingleMessageEx;
import com.gmp.rusk.extension.PCSyncEx;
import com.gmp.rusk.extension.ReadEx;
import com.gmp.rusk.extension.ReceivedEx;
import com.gmp.rusk.extension.RequestEx;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;

public class XmppFilterOfflineSingle extends XmppFilterMessage{

	private LinkedList<Packet> m_QueuePacket;
	com.gmp.rusk.db.RoomDBManager m_DelayRoomDB;
	com.gmp.rusk.db.ContactsDBManager m_ContactsDBManager;
	ChattingDBManagerForDelayMessage m_DelayMessageDB;
	
	String m_strUser;
	Context m_Context;
	long m_lEditTime;
	
	public XmppFilterOfflineSingle(Context context, Long a_lTime, final String a_strUserName, ChattingDBManagerForDelayMessage a_DelayMessageDB, com.gmp.rusk.db.RoomDBManager a_DelayRoomDB, com.gmp.rusk.db.ContactsDBManager a_ContactsDBManager){
		
		m_DelayMessageDB = a_DelayMessageDB;
		m_DelayRoomDB = a_DelayRoomDB;
		m_ContactsDBManager = a_ContactsDBManager;
		m_strUser = a_strUserName;
		m_Context = context;
		m_lEditTime = a_lTime;
		m_QueuePacket = new LinkedList<Packet>();
		setContext(context);
	}
	
	public LinkedList<Packet> getQueue() {
		return m_QueuePacket;
	}
	
	public void clearQueue() {
		m_QueuePacket.clear();
	}
	
	public void setFilterSingle(final Packet message){
				
		PacketExtension packetExtensionReceq = message.getExtension(RequestEx.NAMESPACE);
		PacketExtension packetExtensionRead = message.getExtension(ReadEx.NAMESPACE);

		ClearEx clearEx = (ClearEx) message.getExtension(ClearEx.NAMESPACE);
		FileEx fileEx = (FileEx) message.getExtension(FileEx.NAMESPACE);
		PCSyncEx pcsyncEx = (PCSyncEx) message.getExtension(PCSyncEx.NAMESPACE);
		EmoticonEx emoticonEx = (EmoticonEx) message.getExtension(EmoticonEx.NAMESPACE);
		PCSingleMessageEx pcSingleMessageEx = null;
		if(message.getExtension(PCSingleMessageEx.NAMESPACE) != null && message.getExtension(PCSingleMessageEx.NAMESPACE).getElementName().equals(PCSingleMessageEx.ELEMENT_NAME))
			pcSingleMessageEx = (PCSingleMessageEx) message.getExtension(PCSingleMessageEx.NAMESPACE);
		
		if (message.getError() != null) {
			if (message.getError().getCode() == 404) {
				
			}
		} else if(!message.getFrom().equals("cork.com") && pcSingleMessageEx != null && pcSingleMessageEx.getElementName().equals(PCSingleMessageEx.ELEMENT_NAME)){
			if(!pcSingleMessageEx.getReadIds().isEmpty()){
				// ArrayList<ReadCountData> arrReadCountData = new
				// ArrayList<ReadCountData>();

				HashMap<String, Boolean> mapNoReadMessageID = new HashMap<String, Boolean>();

				for (String readId : pcSingleMessageEx.getReadIds()) {
					mapNoReadMessageID.put(readId, true);
					// ReadCountData readCountData = new
					// ReadCountData();
					//
					// ChattingMessageData chattingMsg =
					// chattingDBMngd.getChattingMessage(readId);
					// readCountData.m_strRoomId =
					// message.getFrom().split("@")[0];
					// readCountData.m_strMessageId = readId;
					// readCountData.m_strCreateDate = "" +
					// chattingMsg.m_lnMsgSendTime;
					// readCountData.m_nCount =
					// chattingMsg.m_nNoReadUserCount - 1;
					// arrReadCountData.add(readCountData);
				}
				// chattingDBMngd.updateNoReadUserCount(arrReadCountData);
				m_DelayMessageDB.updateReadMessage(pcSingleMessageEx.getTo().split("@")[0], mapNoReadMessageID);

			} else {
			
			boolean isNoRoom = true;

			ChattingRoomInfoData roomData = m_DelayRoomDB.getChattingRoom(pcSingleMessageEx.getTo().split("@")[0]);

			if (roomData != null) {
				isNoRoom = false;
			}

			if (isNoRoom) {
				CommonLog.e(m_Context, "생성 진입");
				UserListData m_UserData = m_ContactsDBManager.getContacts(Integer.parseInt(pcSingleMessageEx.getTo().split("@")[0]));
				if (m_UserData == null) {
					CountDownLatch latch = new CountDownLatch(1);
					requestAddedByUserList(Integer.parseInt(pcSingleMessageEx.getTo().split("@")[0]), latch);
					try {
						latch.await();
					} catch (InterruptedException e) {
						// TODO Auto-generated
						// catch block
						e.printStackTrace();
					}
				} else {
					String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
					ChattingRoomInfoData data;
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
						data = new ChattingRoomInfoData(pcSingleMessageEx.getTo().split("@")[0], crypto.encrypt(strFriendUserName), true,
								App.m_MyUserInfo.m_nUserNo, false);
						m_DelayRoomDB.insertRoom(data);
					} catch (Exception e) {
						// TODO Auto-generated
						// catch block
						e.printStackTrace();
					}

					CommonLog.e(m_Context, "생성 중");
				}
			}

			DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

			long lTime = delay.getStamp().getTime();
			int nDBResult = -1;
			
			if(pcSingleMessageEx.getType().equals("clear")){

				m_DelayMessageDB.deleteChattingMessage(pcSingleMessageEx.getTo().split("@")[0]);

				String pattern = "a h:mm";
				SimpleDateFormat format = new SimpleDateFormat(pattern);
				String date = (String) format.format(new Timestamp(lTime));

				// 방장 이름
				UserListData userClear = null;

				userClear = (m_ContactsDBManager.getContacts(Integer.parseInt(pcSingleMessageEx.getFrom().split("@")[0])));


				String strClearName;
				if(userClear == null){
					strClearName = m_Context.getString(R.string.not_in_db_user);
				} else {
					strClearName = userClear.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
				}
				
				ChattingMessageData data = new ChattingMessageData();

				data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_clear), strClearName) + date;
				data.m_nMsgType = 1;
				data.m_isRead = true;
				data.m_strMsgId = pcSingleMessageEx.getId();
				data.m_lnMsgSendTime = lTime;

					if(delay.getStamp().getTime() > m_lEditTime)
						nDBResult = m_DelayMessageDB.insertChattingMessage(pcSingleMessageEx.getTo().split("@")[0], data);
				
			}
			else if(pcSingleMessageEx.getType().equals("file")){
				ChattingMessageData a_chattingMsgData;
				a_chattingMsgData = new ChattingMessageData();

				ArrayList<Integer> arrMyId = new ArrayList<Integer>();
				arrMyId.add(App.m_MyUserInfo.m_nUserNo);
				// 처음 글을 올리는 순간은 무조건 나만 본것
				// 파일에서 텍스트는 fid, mimetype, url의 순서로
				// *을 써서 구분하여 넣도록 한다

				if (pcSingleMessageEx.getMimetype() != null && pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
					String strCreateTime = "";
					if (pcSingleMessageEx.getCreateTime() != null && !pcSingleMessageEx.getCreateTime().equals("0")) {
						strCreateTime = pcSingleMessageEx.getCreateTime();
					} else {
						strCreateTime = Long.toString(delay.getStamp().getTime());
					}
					XmppUtils utils = new XmppUtils();
					utils.strFileName = pcSingleMessageEx.getFileName();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strCreateTime = strCreateTime;
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}
				// 이미지 라면 추가로 width, height, 썸네일
				// url도 추가한다
				else if (pcSingleMessageEx.getMimetype() != null && pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;
					XmppUtils utils = new XmppUtils();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strWidth = pcSingleMessageEx.getWidth();
					utils.strHeight = pcSingleMessageEx.getHeight();
					utils.strThumb = pcSingleMessageEx.getThumb();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}
				// 동영상일 경우 fileName에 "" 을 넣도록
				// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
				else if (pcSingleMessageEx.getMimetype() != null && pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
					String strCreateTime = "";
					if (pcSingleMessageEx.getCreateTime() != null && !pcSingleMessageEx.getCreateTime().equals("0")) {
						strCreateTime = pcSingleMessageEx.getCreateTime();
					} else {
						strCreateTime = Long.toString(delay.getStamp().getTime());
					}
					XmppUtils utils = new XmppUtils();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strCreateTime = strCreateTime;
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strThumb = pcSingleMessageEx.getThumb();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();

				}
				else if (pcSingleMessageEx.getMimetype() != null && pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
					XmppUtils utils = new XmppUtils();
					utils.strFileName = pcSingleMessageEx.getFileName();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}

				a_chattingMsgData.m_nSendUserId = 0;
				a_chattingMsgData.m_strMsgId = pcSingleMessageEx.getId();
				a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
				a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
				a_chattingMsgData.m_nNoReadUserCount = 1;
				a_chattingMsgData.m_isRead = true;
				if(delay.getStamp().getTime() > m_lEditTime)
					nDBResult = m_DelayMessageDB.insertChattingMessage(pcSingleMessageEx.getTo().split("@")[0], a_chattingMsgData);
			} 
			else if(pcSingleMessageEx.getType().equals("urgent") || pcSingleMessageEx.getType().equals("")){
			ChattingMessageData a_chattingMsgData;
			a_chattingMsgData = new ChattingMessageData();

			ArrayList<Integer> arrMyId = new ArrayList<Integer>();
			// 임시
			arrMyId.add(App.m_MyUserInfo.m_nUserNo);
			// 처음 글을 올리는 순간은 무조건 나만 본것

			if(pcSingleMessageEx.getType().equals("urgent")){
				a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
			}
			a_chattingMsgData.m_nSendUserId = 0;
			a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
			if(pcSingleMessageEx.getBody() != null)
			a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(pcSingleMessageEx.getBody());
				if (pcSingleMessageEx.getName() !=null){
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
					a_chattingMsgData.m_strEmoticon = pcSingleMessageEx.getName();
				}
			a_chattingMsgData.m_strMsgId = pcSingleMessageEx.getId();
			a_chattingMsgData.m_lnMsgSendTime = lTime;
			a_chattingMsgData.m_nNoReadUserCount = 1;
			a_chattingMsgData.m_isRead = true;

			if(lTime > m_lEditTime)
				nDBResult = m_DelayMessageDB.insertChattingMessage(pcSingleMessageEx.getTo().split("@")[0], a_chattingMsgData);
			
			}
			if(nDBResult != -1){
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;
			Message sendMSG2 = new Message();
			sendMSG2.setPacketID(strPacketID);
			sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
			sendMSG2.addExtension(new PacketExtension() {

				@Override
				public String toXML() {
					// TODO Auto-generated
					// method stub
					return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
				}

				@Override
				public String getElementName() {
					// TODO Auto-generated
					// method stub
					return "received";
				}

				@Override
				public String getNamespace() {
					// TODO Auto-generated
					// method stub
					return "urn:xmpp:receipts";
				}

			});
			m_QueuePacket.add(sendMSG2);
			CommonLog.e(TAG, "MyPCMessage Receive Offline: " + sendMSG2);
			}
			}
		}
		else if (!message.getFrom().equals("cork.com") &&(pcsyncEx == null || !pcsyncEx.getElementName().equals(PCSyncEx.ELEMENT_NAME)) && (message.getFrom().split("@")[1].equals("cork.com/TMS") || message.getFrom().split("@")[1].equals("cork.com")
				|| message.getFrom().split("@")[1].equals("cork.com/TMS_PC") || message.getFrom().split("@")[1].equals("cork.com/TMS_ALL"))) {

			if (clearEx != null) {
				if (clearEx.getElementName().equals(ClearEx.ELEMENT_NAME)) {
					// 자기가 초기화 했다면
					if (message.getFrom().equals(m_strUser)) {
						m_DelayMessageDB.deleteChattingMessage(message.getTo().split("@")[0]);
					}
					// 친구가 했다면
					else {
						m_DelayMessageDB.deleteChattingMessage(message.getFrom().split("@")[0]);
					}

					DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

					long lTime = delay.getStamp().getTime();

					String pattern = "a h:mm";
					SimpleDateFormat format = new SimpleDateFormat(pattern);
					String date = (String) format.format(new Timestamp(lTime));

					// 방장 이름
					UserListData userClear = null;

					// 자기가 초기화 했다면
					if (message.getFrom().equals(m_strUser)) {
						userClear = (m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("@")[0])));
					}
					// 친구가 했다면
					else {
						userClear = (m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("@")[0])));
					}

					String strClearName;
					if(userClear == null){
						strClearName = m_Context.getString(R.string.not_in_db_user);
					} else {
						strClearName = userClear.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
					}
					
					ChattingMessageData data = new ChattingMessageData();

					data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_clear), strClearName) + date;
					data.m_nMsgType = 1;
					data.m_isRead = true;
					data.m_strMsgId = message.getPacketID();
					data.m_lnMsgSendTime = lTime;

					int nResult = 0;
					// 자기가 초기화 했다면
					if (message.getFrom().equals(m_strUser)) {
						if(delay.getStamp().getTime() > m_lEditTime)
						nResult = m_DelayMessageDB.insertChattingMessage(message.getTo().split("@")[0], data);
					}
					// 친구가 했다면
					else {
						if(delay.getStamp().getTime() > m_lEditTime)
						nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
					}
					if(nResult != -1){
					Packet receivePacket = new Packet() {

						@Override
						public String toXML() {
							// TODO Auto-generated
							// method stub
							final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
							StringBuilder buf = new StringBuilder();
							buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
							buf.append("\" id=\"").append(strPacketID);
							buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@" + SERVICE_NAME).append("\">");
							buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
							buf.append("</message>");

							return buf.toString();
						}
					};
					m_QueuePacket.add(receivePacket);
					}

				}
			} else if (message.getFrom().equals(m_strUser)) {
				// 내가 보낸 파일에 대한 응답
				if (fileEx != null) {
					if (fileEx.getElementName().equals(FileEx.ELEMENT_NAME)) {

						// 전송 완료전의 임시 DB를 삭제 하기 위함

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						ArrayList<Integer> arrMyId = new ArrayList<Integer>();
						arrMyId.add(App.m_MyUserInfo.m_nUserNo);
						// 처음 글을 올리는 순간은 무조건 나만 본것
						if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 이미지 라면 추가로 width, height, 썸네일
						// url도 추가한다
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strWidth = fileEx.getWidth();
							utils.strHeight = fileEx.getHeight();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 동영상일 경우 fileName에 "" 을 넣도록
						// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						a_chattingMsgData.m_nSendUserId = 0;
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						a_chattingMsgData.m_nNoReadUserCount = 1;
						a_chattingMsgData.m_isRead = true;
						ArrayList<Integer> arrThisRoomUser = new ArrayList<Integer>();
						arrThisRoomUser.add(Integer.parseInt(message.getFrom().split("@")[0]));
						arrThisRoomUser.add(Integer.parseInt(message.getTo().split("@")[0]));
						if(delay.getStamp().getTime() > m_lEditTime)
						m_DelayMessageDB.updateChattingMessage(message.getTo().split("@")[0], a_chattingMsgData);

					}
				}
				// 내 리드 메세지
				else if (packetExtensionRead != null) {
					if (packetExtensionRead.getElementName().equals(ReadEx.ELEMENT_NAME)) {
//						ReadEx readEx = (ReadEx) message.getExtension(ReadEx.NAMESPACE);
//
//						HashMap<String, Boolean> mapNoReadMessageID = new HashMap<String, Boolean>();
//						for (String readId : readEx.getIds()) {
//							mapNoReadMessageID.put(readId, true);
////							ReadCountData readCountData = new ReadCountData();
//
////							ChattingMessageData chattingMsg = chattingDBMngd.getChattingMessage(readId);
////							readCountData.m_strRoomId = message.getFrom().split("@")[0];
////							readCountData.m_strMessageId = readId;
////							readCountData.m_strCreateDate = "" + chattingMsg.m_lnMsgSendTime;
////							readCountData.m_nCount = chattingMsg.m_nNoReadUserCount - 1;
////							arrReadCountData.add(readCountData);
//						}
////						chattingDBMngd.updateNoReadUserCount(arrReadCountData);
//						m_DelayMessageDB.updateReadMessage(message.getTo().split("@")[0], mapNoReadMessageID);
//
//
//						// if (m_PacketListener != null) {
//						//
//						// m_PacketListener.setReadMessage(readEx.getIds(),
//						// Integer.parseInt(message.getFrom().split("@")[0]));
//						// }
					}
				} else if (packetExtensionReceq != null) {
					if (packetExtensionReceq.getElementName().equals(RequestEx.ELEMENT_NAME)) {

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						if (message.getExtension("info", "urn:xmpp:urgent") != null) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
						}
						ArrayList<Integer> arrMyId = new ArrayList<Integer>();
						// 임시
						arrMyId.add(App.m_MyUserInfo.m_nUserNo);
						// 처음 글을 올리는 순간은 무조건 나만 본것

						a_chattingMsgData.m_nSendUserId = 0;
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						if(((Message) message).getBody()!=null)
							a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
						else
							a_chattingMsgData.m_strMsgText = "";
						if (emoticonEx !=null){
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
							a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
						}

						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nNoReadUserCount = 1;
						a_chattingMsgData.m_isRead = true;
						ArrayList<Integer> arrThisRoomUser = new ArrayList<Integer>();
						arrThisRoomUser.add(Integer.parseInt(message.getFrom().split("@")[0]));
						arrThisRoomUser.add(Integer.parseInt(message.getTo().split("@")[0]));
						if(delay.getStamp().getTime() > m_lEditTime)
						m_DelayMessageDB.updateChattingMessage(message.getTo().split("@")[0], a_chattingMsgData);

					}
				}
				// request, receive등 아무것도 포함되지 않았을때
				else {
					ChattingMessageData a_chattingMsgData;
					a_chattingMsgData = new ChattingMessageData();

					DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

					if (message.getExtension("info", "urn:xmpp:urgent") != null) {

						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
					}
					ArrayList<Integer> arrMyId = new ArrayList<Integer>();
					// 임시
					arrMyId.add(App.m_MyUserInfo.m_nUserNo);
					// 처음 글을 올리는 순간은 무조건 나만 본것

					a_chattingMsgData.m_nSendUserId = 0;
					a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
					if(((Message) message).getBody()!=null)
						a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
					else
						a_chattingMsgData.m_strMsgText = "";
					if (emoticonEx !=null){
						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
						a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
					}

					a_chattingMsgData.m_strMsgId = message.getPacketID();
					a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
					a_chattingMsgData.m_nNoReadUserCount = 1;
					a_chattingMsgData.m_isRead = true;
					if(delay.getStamp().getTime() > m_lEditTime)
					m_DelayMessageDB.updateChattingMessage(message.getTo().split("@")[0], a_chattingMsgData);
				}

			} else {
				// 받은 메시지 화면에 표시하고 DB에 삽입

				// Request
				if (packetExtensionRead != null) {
					if (packetExtensionRead.getElementName().equals(ReadEx.ELEMENT_NAME)) {
						// ReadEx readEx = (ReadEx)
						// message.getExtension(ReadEx.NAMESPACE);
						// ArrayList<Integer> arrThisRoomUser = new
						// ArrayList<Integer>();
						//
						// arrThisRoomUser.add(Integer.parseInt(message.getFrom().split("@")[0]));
						// arrThisRoomUser.add(Integer.parseInt(message.getTo().split("@")[0]));
						//
						// ChattingDBManager chattingDBMng = new
						// ChattingDBManager(m_Context);
						// chattingDBMng.openReadable(message.getFrom().split("@")[0]);
						// ArrayList<ChattingMessageData> arrMessageData =
						// chattingDBMng.getChattingMessage();
						// chattingDBMng.close();
						//
						// ArrayList<ChatRoomData> arrRoomData = new
						// ArrayList<ChatRoomData>();
						// ChattingDBManager chattingDBMng2 = new
						// ChattingDBManager(m_Context);
						// chattingDBMng2.openWritable(message.getFrom().split("@")[0]);
						//
						// ArrayList<Integer> arrDBResult = new
						// ArrayList<Integer>();
						// for (ChattingMessageData messageData :
						// arrMessageData) {
						// for (String readID : readEx.getIds()) {
						// if (messageData.m_strMsgId.equals(readID)) {
						//
						// ChatRoomData roomData = new ChatRoomData();
						//
						// roomData.m_arrRead = arrThisRoomUser;
						// roomData.m_strMessageID = messageData.m_strMsgId;
						// arrRoomData.add(roomData);
						//
						// ChattingMessageData a_chattingMsgData;
						// a_chattingMsgData = new ChattingMessageData();
						// a_chattingMsgData.m_nMsgType =
						// StaticString.CHAT_ROOM_MY_MESSAGE;
						// a_chattingMsgData.m_strMsgText = "";
						// a_chattingMsgData.m_nSendStatus =
						// StaticString.CHAT_SEND_STATUS_SUCCESS;
						// a_chattingMsgData.m_isRead = false;
						// a_chattingMsgData.m_strMsgId = readID;
						// a_chattingMsgData.m_lnMsgSendTime = 0;
						// // 아직 전달 되지 않은 메세지 이므로
						// // 일은 사람 표시를 하지 않는다.
						// a_chattingMsgData.m_arrReadUser = arrThisRoomUser;
						// a_chattingMsgData.m_arrCurrentUser = arrThisRoomUser;
						//
						// int nDBResult =
						// chattingDBMng2.updateReadUserIdList(a_chattingMsgData);
						// arrDBResult.add(nDBResult);
						//
						// }
						//
						// }
						// }
						// chattingDBMng2.close();
						//
						// boolean isAllSuccess = true;
						// for (int nDBResult : arrDBResult) {
						// if (nDBResult == -1) {
						// isAllSuccess = false;
						// }
						// }
						// if (isAllSuccess) {
						// final String strPacketID =
						// Long.toString(System.currentTimeMillis()) + "_" +
						// App.m_MyUserInfo.m_nUserNo;
						// Message sendMSG2 = new Message();
						// sendMSG2.setPacketID(strPacketID);
						// sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0])
						// + "@" + SERVICE_NAME);
						// sendMSG2.addExtension(new PacketExtension() {
						//
						// @Override
						// public String toXML() {
						// // TODO Auto-generated
						// // method stub
						// return "<received xmlns='urn:xmpp:receipts' id='" +
						// message.getPacketID() + "'/>";
						// }
						//
						// @Override
						// public String getElementName() {
						// // TODO Auto-generated
						// // method stub
						// return "received";
						// }
						//
						// @Override
						// public String getNamespace() {
						// // TODO Auto-generated
						// // method stub
						// return "urn:xmpp:receipts";
						// }
						//
						// });
						//
						// connection.sendPacket(sendMSG2);
						//
						// if (m_NotifyListner != null && isOnline &&
						// m_PacketListener ==
						// null && m_GroupPacketListener == null) {
						// // m_NotifyListner.onNotify();
						// }
						// if (m_PacketListener != null && isOnline) {
						//
						// //
						// m_PacketListener.onPrintMessage(Integer.parseInt(message.getFrom().split("@")[0]));
						// m_PacketListener.setReadMessage(arrRoomData,
						// Integer.parseInt(message.getFrom().split("@")[0]));
						// }
						// CommonLog.e(TAG, "Read : " + message.toXML());
						// }
					}
					// }
				}
				// 상대방이 보낸 파일을 받았을때
				else if (fileEx != null) {
					if (fileEx.getElementName().equals(FileEx.ELEMENT_NAME)) {

						ChattingRoomInfoData singleRoomData = RoomDBManager.getChattingRoom(m_Context, message.getFrom().split("@")[0]);

						if (singleRoomData == null) {

							UserListData m_UserData = m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("@")[0]));
							if (m_UserData == null) {
								CountDownLatch latch = new CountDownLatch(1);
								requestAddedByUserList(Integer.parseInt(message.getFrom().split("@")[0]), latch);
								try {
									latch.await();
								} catch (InterruptedException e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}
								
							} else {

								String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								ChattingRoomInfoData data;
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									data = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(strFriendUserName), true,
											App.m_MyUserInfo.m_nUserNo, false);
									m_DelayRoomDB.insertRoom(data);
								} catch (Exception e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}

							}
						}

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						ArrayList<Integer> arrFriendId = new ArrayList<Integer>();
						// 처음 파일을 받았을때는 읽음 표시 하지 않음
						arrFriendId.add(Integer.parseInt(message.getFrom().split("@")[0]));

						if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 이미지 라면 추가로 width, height, 썸네일
						// url도 추가한다
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_IMAGE;
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strWidth = fileEx.getWidth();
							utils.strHeight = fileEx.getHeight();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 동영상일 경우 fileName에 "" 을 넣도록
						// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("@")[0]);
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						a_chattingMsgData.m_nNoReadUserCount = 0;

						int nResult = 0;
						if(delay.getStamp().getTime() > m_lEditTime)
						nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);

						if(nResult != -1){
						final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

						Message sendMSG2 = new Message();
						sendMSG2.setPacketID(strPacketID);
						sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
						sendMSG2.addExtension(new PacketExtension() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
							}

							@Override
							public String getElementName() {
								// TODO Auto-generated
								// method stub
								return "received";
							}

							@Override
							public String getNamespace() {
								// TODO Auto-generated
								// method stub
								return "urn:xmpp:receipts";
							}

						});
						m_QueuePacket.add(sendMSG2);
						}
					}
				} else if (packetExtensionReceq != null) {
					CommonLog.e("XmppConnection", "Recv 2");
					if (packetExtensionReceq.getElementName().equals(RequestEx.ELEMENT_NAME)) {
						boolean isNoRoom = true;

						ChattingRoomInfoData roomData = m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]);

						if (roomData != null) {
							isNoRoom = false;
						}

						if (isNoRoom) {
							CommonLog.e(m_Context, "생성 진입");
							UserListData m_UserData = m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("@")[0]));
							if (m_UserData == null) {
								CountDownLatch latch = new CountDownLatch(1);
								requestAddedByUserList(Integer.parseInt(message.getFrom().split("@")[0]), latch);
								try {
									latch.await();
								} catch (InterruptedException e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}
							} else {
								String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								ChattingRoomInfoData data;
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									data = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(strFriendUserName), true,
											App.m_MyUserInfo.m_nUserNo, false);
									m_DelayRoomDB.insertRoom(data);
								} catch (Exception e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}

								CommonLog.e(m_Context, "생성 중");
							}
						}

						final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						int nDBResult = 0;

						if (message.getExtension("info", "urn:xmpp:urgent") != null) {

							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
						}

						if (nDBResult != -1) {
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

							if (message.getExtension("info", "urn:xmpp:event") != null) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
								String pattern = "a h:mm";
								SimpleDateFormat format = new SimpleDateFormat(pattern);
								String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
								if (((Message) message).getBody() != null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;

								a_chattingMsgData.m_isRead = true;
							} else {
								if(((Message) message).getBody()!=null)
									a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
								else
									a_chattingMsgData.m_strMsgText = "";
								if (emoticonEx !=null){
									a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
									a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
								}
							}

							a_chattingMsgData.m_strMsgId = message.getPacketID();
							a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
							a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("@")[0]);
							a_chattingMsgData.m_nNoReadUserCount = 0;

							int nResult = 0;
							if(delay.getStamp().getTime() > m_lEditTime)
							nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
							if(nResult != -1){
							Message sendMSG2 = new Message();
							sendMSG2.setPacketID(strPacketID);
							sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
							sendMSG2.addExtension(new PacketExtension() {

								@Override
								public String toXML() {
									// TODO
									// Auto-generated
									// method stub
									return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
								}

								@Override
								public String getElementName() {
									// TODO
									// Auto-generated
									// method stub
									return "received";
								}

								@Override
								public String getNamespace() {
									// TODO
									// Auto-generated
									// method stub
									return "urn:xmpp:receipts";
								}

							});

							m_QueuePacket.add(sendMSG2);
							}
						}

						// }
					}
					// Received
					else if (packetExtensionReceq.getElementName().equals(ReceivedEx.ELEMENT_NAME)) {

					}

				}
				// receive, request등 아무것도 포함되지 않은경우
				else {
					ChattingRoomInfoData singleRoomData = RoomDBManager.getChattingRoom(m_Context, message.getFrom().split("@")[0]);

					if (singleRoomData == null) {
						CommonLog.e(m_Context, "생성 진입");
						UserListData m_UserData = m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("@")[0]));
						if (m_UserData == null) {
							CountDownLatch latch = new CountDownLatch(1);
							requestAddedByUserList(Integer.parseInt(message.getFrom().split("@")[0]), latch);
							try {
								latch.await();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch
								// block
								e.printStackTrace();
							}
						} else {
							String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
							ChattingRoomInfoData data;
							try {
								LocalAesCrypto crypto = new LocalAesCrypto();
								data = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(strFriendUserName), true,
										App.m_MyUserInfo.m_nUserNo, false);
								m_DelayRoomDB.insertRoom(data);
							} catch (Exception e) {
								// TODO Auto-generated catch
								// block
								e.printStackTrace();
							}

							CommonLog.e(m_Context, "생성 중");
						}
					}

					final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

					ChattingMessageData a_chattingMsgData;
					a_chattingMsgData = new ChattingMessageData();

					int nDBResult = 0;
					if (message.getExtension("info", "urn:xmpp:urgent") != null) {
						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
					}
					if (nDBResult != -1) {
						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						if (message.getExtension("info", "urn:xmpp:event") != null) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
							String pattern = "a h:mm";
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
							if (((Message) message).getBody() != null)
							a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;

							a_chattingMsgData.m_isRead = true;
						} else {
							if(((Message) message).getBody()!=null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
							else
								a_chattingMsgData.m_strMsgText = "";
							if (emoticonEx !=null){
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
								a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
							}
						}

						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();

						a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("@")[0]);
						a_chattingMsgData.m_nNoReadUserCount = 0;

						int nResult = 0;
						if(delay.getStamp().getTime() > m_lEditTime)
						nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
						if(nResult != -1){
						Message sendMSG2 = new Message();
						sendMSG2.setPacketID(strPacketID);
						sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
						sendMSG2.addExtension(new PacketExtension() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
							}

							@Override
							public String getElementName() {
								// TODO Auto-generated
								// method stub
								return "received";
							}

							@Override
							public String getNamespace() {
								// TODO Auto-generated
								// method stub
								return "urn:xmpp:receipts";
							}

						});

						m_QueuePacket.add(sendMSG2);
						}
					}
				}
			}

		}
	}
	
	
}
