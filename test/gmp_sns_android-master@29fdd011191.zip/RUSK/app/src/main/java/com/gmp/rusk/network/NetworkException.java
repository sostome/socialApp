package com.gmp.rusk.network;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.net.SocketTimeoutException;

import org.apache.http.client.ClientProtocolException;

public class NetworkException extends Exception{
	
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1334325101786383789L;
	int ErrorCode ;
	String m_strErrorMessage;
    public NetworkException(int Code, String Message){
    	super(Message);
    	ErrorCode = Code;
    	m_strErrorMessage = Message;
    }

    public NetworkException(SocketException e){
    	this(ApiResult.HTTP_ERR_SOCKET_ERROR, e.getMessage());
    }
    
    public NetworkException(SocketTimeoutException e){
    	this(ApiResult.HTTP_ERR_TIME_OUT, e.getMessage());
    }
    
    public NetworkException(UnsupportedEncodingException e){
    	this(ApiResult.HTTP_ERR_ENCODING_EXCEPTION, e.getMessage());
    }   

    public NetworkException(ClientProtocolException e){
    	this(ApiResult.HTTP_ERR_PROTOCOL_EXCEPTION, e.getMessage());
    }   
    
    public NetworkException(IOException e){
    	this(ApiResult.HTTP_ERR_IO_EXCEPTION, e.getMessage());
    }   
    
    public NetworkException(String a_strMessage){
    	this(ApiResult.HTTP_USER_DEFINE, a_strMessage);
    }
    
    int getErrorCode(){
    	return ErrorCode;
    }
    
    String getErrorMessage()
    {
    	return m_strErrorMessage;
    }
}