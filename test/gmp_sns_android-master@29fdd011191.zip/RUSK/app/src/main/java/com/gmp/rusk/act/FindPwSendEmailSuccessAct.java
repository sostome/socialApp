package com.gmp.rusk.act;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.app.Activity;

/**
 * FindPwSendEmailSuccessAct
 * @author subi78
 * ID/Password password 찾기 완료 Activity
 */
public class FindPwSendEmailSuccessAct extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_findidpw_pwsendemail_success);
		setResult(Activity.RESULT_OK);
		setSignUpSuccessUI();
	}
	
	private void setSignUpSuccessUI()
	{
		Button ib_ok = (Button)findViewById(R.id.ib_ok);
		ib_ok.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_ok)
		{
			finish();			
		}
	}
}
