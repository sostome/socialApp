package com.gmp.rusk.request;

import org.json.JSONObject;


import com.gmp.rusk.utils.CommonLog;

/**
 *	@author subi78
 *			파트너 비밀번호 변경
 *			method : put
 */

public class PutChangePasswordPartnerReq extends Req{
	
	private String APINAME = "partner";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";
	
	private final String JSON_PASSWORD = "password";
	
	
	private String m_strPassword = "";			//사용자 비밀번호
		
	public PutChangePasswordPartnerReq(String a_strPassword)
	{
		APINAME = APINAME +"/"+App.m_EntryData.m_nUserNo+"/password";
		
		m_strPassword = a_strPassword;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_PASSWORD, m_strPassword);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PutChangePasswordPartnerReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
