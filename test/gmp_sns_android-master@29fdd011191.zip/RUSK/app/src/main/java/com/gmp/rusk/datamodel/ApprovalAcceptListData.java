package com.gmp.rusk.datamodel;

public class ApprovalAcceptListData {
	public int m_nUserNo = 0;					//사용자 번호
	public String m_strName = "";				//사용자 이름
	public String m_strAffiliation = "";			//파트너 소속
	public String m_strMobile = "";
	public boolean m_isExpiresoon = false;
	
	public ApprovalAcceptListData(int a_nUserNo, String a_strName, String a_strAffiliation, String a_strMobile, boolean a_isExpiresoon) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strAffiliation = a_strAffiliation;
		m_strMobile = a_strMobile;
		m_isExpiresoon = a_isExpiresoon;
	}
}
