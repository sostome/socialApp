package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.act.SNSGroupMemeberInviteAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;

/**
 * AddedByPartnerListItemLayout 파트너 검색 List Item Layout
 */
public class SNSInvitePartnerListItemLayout extends CustomLinearLayout implements OnClickListener, OnCheckedChangeListener {

	Context m_Context;

	private OnCheckedChangedListener m_CheckedChangeListener = null;
	private PartnerSearchListData m_PartnerSearchListData = null;
	CheckBox cb_invite;
	ImageView m_ivInviteSelected;

	private CommonPopup m_Popup = null;
	
	private ProgressDlg m_Progress = null;

	public SNSInvitePartnerListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public SNSInvitePartnerListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}

	private void init(Context a_context) {
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		layoutInflater.inflate(R.layout.layout_listitem_chat_room_invite, this);

	}

	public void setPartnerSearchListData(PartnerSearchListData a_Data) {
		m_PartnerSearchListData = a_Data;
		setUiData();
	}

	// UI 세팅
	private void setUiData() {
		ImageView iv_profile_pic = (ImageView) findViewById(R.id.iv_profile_pic);
		iv_profile_pic.setOnClickListener(this);
		ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);

		if (m_PartnerSearchListData.m_isImageAvailable)
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_PartnerSearchListData.m_nUserNo, true), R.drawable.profile_pic_default, false);		
		}
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}

		iv_notfellow_pic.setVisibility(View.GONE);
//		TextView tv_name = (TextView) findViewById(R.id.tv_name);
//		tv_name.setText(m_PartnerSearchListData.m_strName);

		TextView tv_name = (TextView)findViewById(R.id.tv_name);
		TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
		tv_name.setText(m_PartnerSearchListData.m_strName);

		if(m_PartnerSearchListData.m_isAvailable)
		{
			tv_uninstall.setVisibility(GONE);
		}
		else
		{
			tv_uninstall.setVisibility(VISIBLE);
		}
		
		TextView tv_departments = (TextView) findViewById(R.id.tv_departments);
		tv_departments.setText(m_PartnerSearchListData.m_strAffliaction);

		cb_invite = (CheckBox) findViewById(R.id.cb_invite);
		m_ivInviteSelected = (ImageView) findViewById(R.id.iv_invite_selected);
		cb_invite.setOnCheckedChangeListener(this);

		if(App.m_EntryData.m_nUserNo == m_PartnerSearchListData.m_nUserNo)
			cb_invite.setVisibility(View.INVISIBLE);
		else
			cb_invite.setVisibility(View.VISIBLE);
		
		if (App.m_arrRoomUserList != null) {
			for (int nUserID : App.m_arrRoomUserList) {
				if (nUserID == m_PartnerSearchListData.m_nUserNo) {
					cb_invite.setVisibility(View.GONE);
					m_ivInviteSelected.setVisibility(View.VISIBLE);
					break;
				} else {
					cb_invite.setVisibility(View.VISIBLE);
					m_ivInviteSelected.setVisibility(View.GONE);
				}
			}
		}

		RelativeLayout layout_listitem_search = (RelativeLayout) findViewById(R.id.layout_listitem);
		layout_listitem_search.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.ib_add_fellow) {

		} else if (v.getId() == R.id.layout_listitem) {
			//doShowProfile();
			if(cb_invite.getVisibility() == View.VISIBLE && cb_invite.isChecked())
				cb_invite.setChecked(false);
			else if(cb_invite.getVisibility() == View.VISIBLE && !cb_invite.isChecked())
				cb_invite.setChecked(true);
		} else if(v.getId() == R.id.iv_profile_pic) {
			doShowProfile();
		}
		else if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(m_Context);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Context);
			}
			else
			{
				popup_ok_long.cancel();
			}
		}
	}

	private void doShowProfile() {
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_PartnerSearchListData.m_nUserNo);
		m_Context.startActivity(intent);
	}

//	private void requestAddBuddys() {
//		showProgress();
//		int[] nSelects = new int[1];
//		nSelects[0] = m_PartnerSearchListData.m_nUserNo;
//		PostAddBuddysReq req = new PostAddBuddysReq(nSelects);
//		WebAPI webApi = new WebAPI(m_Context);
//		webApi.request(req, new WebListener() {
//
//			@Override
//			public void onPreRequest() {
//				// TODO Auto-generated method stub
//			}
//
//			@Override
//			public void onPostRequest(String a_strData) {
//				// TODO Auto-generated method stub
//				// FellowListData fellowListData = new FellowListData(m_PartnerSearchListData.m_nUserNo, "P", m_PartnerSearchListData.m_strName, m_PartnerSearchListData.m_strCompany,
//				// null, null, m_PartnerSearchListData.m_isImageAvailable, m_PartnerSearchListData.m_isAvailable);
//
//				UserListData getItem = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_PartnerSearchListData.m_nUserNo);
//
//				if (getItem != null) {
//					closeProgress();
//					getItem.m_isFellow = true;
//					getItem.m_strFellowAddTime = Utils.getCurrentTime();
//
//					TTalkDBManager.ContactsDBManager.updateContacts(m_Context, getItem);
//
//					String[] aesData;
//					if (getItem.m_strUserType.equals("R")) {
//						aesData = Utils.aesDecoderRegularData(getItem.m_strAesData);
//						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, aesData[0], aesData[2], aesData[1], "", getItem.m_strCharge, getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
//						App.m_arrFellowListData.add(fellowListData);
//					} else {
//						aesData = Utils.aesDecoderPartnerData(getItem.m_strAesData);
//						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, aesData[0], "", "", aesData[1], getItem.m_strCharge, getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
//						App.m_arrFellowListData.add(fellowListData);
//					}
//				} else {
//					// 사용자 추가..... 구현
//					Toast.makeText(m_Context, m_PartnerSearchListData.m_nUserNo + "[" + m_PartnerSearchListData.m_strName + "]은 사용자 정보 DB에 없습니다.", Toast.LENGTH_SHORT).show();
//				}
//			}
//
//			@Override
//			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
//				// TODO Auto-generated method stub
//				closeProgress();
//				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
//				{
//					m_Popup = new CommonPopup(m_Context, ChatroomInvitePartnerListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
//					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), a_strMessage);
//					m_Popup.setCancelable(false);
//					m_Popup.show();
//				}
//				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE || a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
//				{
//					m_Popup = new CommonPopup(m_Context, ChatroomInvitePartnerListItemLayout.this,
//							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
//					m_Popup.setBodyAndTitleText(
//							m_Context.getString(R.string.pop_error_title).toString(),
//							a_strMessage);
//					m_Popup.setCancelable(false);
//					m_Popup.show();
//				}
//				else
//				{
//					m_Popup = new CommonPopup(m_Context, ChatroomInvitePartnerListItemLayout.this,
//							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//					m_Popup.setBodyAndTitleText(
//							m_Context.getString(R.string.pop_error_title).toString(),
//							a_strMessage);
//					m_Popup.setCancelable(false);
//					m_Popup.show();
//				}
//			}
//		});
//	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if (buttonView.getId() == R.id.cb_invite) {
			if (isChecked) {
				m_PartnerSearchListData.m_isChecked = true;
				
				
				SearchListCheckData addData = new SearchListCheckData(m_PartnerSearchListData.m_nUserNo, m_PartnerSearchListData.m_strName);
				//addData.m_isChecked = true;
				((SNSGroupMemeberInviteAct) m_Context).addSearchList(addData);
				m_CheckedChangeListener.onChecked(true, m_PartnerSearchListData.m_nUserNo);
			} else {
				m_PartnerSearchListData.m_isChecked = false;
				
				((SNSGroupMemeberInviteAct) m_Context).removeListData(m_PartnerSearchListData.m_nUserNo);
				m_CheckedChangeListener.onChecked(false, m_PartnerSearchListData.m_nUserNo);
			}
		}
	}

	public void setCheckedChangedListener(OnCheckedChangedListener a_Listener) {
		m_CheckedChangeListener = a_Listener;
	}

	public interface OnCheckedChangedListener {
		public void onChecked(boolean a_isChecked, int a_nUserId);
	}
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
