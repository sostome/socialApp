package com.gmp.rusk.datamodel;

/**
 * Created by K on 2017-08-02.
 */

public class CompanyData {

    public String strCode = "";
    public String strName = "";

    public CompanyData(String a_strCode, String a_strName) {
        strCode = a_strCode;
        strName = a_strName;
    }
}
