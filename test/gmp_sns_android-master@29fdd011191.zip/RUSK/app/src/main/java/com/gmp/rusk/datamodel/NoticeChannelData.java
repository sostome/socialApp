package com.gmp.rusk.datamodel;

/**
 * Created by K on 2017-08-25.
 */

public class NoticeChannelData {

    public int m_nNoticeChannelNo = -1;
    public String m_strNoticeName = "";
}
