package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class GetTermTextRes extends Res{

	private final String JSON_TERM		= "term";


	private String m_strTerm = "";


	public GetTermTextRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			m_strTerm = jsonRoot.getString(JSON_TERM);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getTermText()
	{
		return m_strTerm;
	}

}
