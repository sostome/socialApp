package com.gmp.rusk.datamodel;

import org.json.JSONObject;

/**
 * Created by K on 2017-08-14.
 */

public class FileBoxData {


    public int m_nFileNo = -1;
    public String m_strMsgId = "";
    public String m_strType = "";
    public String m_strUrl = "";
    public String m_strPreviewUrl = "";
    public String m_strFileName = "";
    public long m_lnFileSize = -1;
    public String m_strTime = "";

    public JSONObject m_jsonObject;

}
