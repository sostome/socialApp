package com.gmp.rusk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.DepartmentsData;
import com.gmp.rusk.datamodel.NavigationInfoData;
import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserSearchListData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.FellowAddSearchAllUserListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostSearchUserReq;
import com.gmp.rusk.response.PostSearchUserRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;

/**
 * Created by kang on 2017-05-08.
 */

public class SearchBrowseListFrag extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener, View.OnTouchListener {

    public MyApp App = MyApp.getInstance();
    private FragmentActivity m_Activity = null;

    ArrayList<NavigationInfoData> m_arrNavigationInfoDatas = null;
    ArrayList<DepartmentsData> m_arrDepartmentsDatas = null;
    ArrayList<DepartmentUserListData> m_arrDepartmentUserListDatas = null;

    private AddedByUserListAdapter m_AddedByUserAdapter = null;
    View m_vOrganChart;

    private ListView m_lvOrganChartList = null;

    private RelativeLayout layout_organchart = null;
    private RelativeLayout layout_organregular = null;

    private LinearLayout layout_organchartlist_list = null;
    private ListView m_lvorganRegularList = null;
    // private SectionListAdapter m_SectionListAdapter = null;
    // private ArrayList<SectionListItem> m_SectionListItems = null; //
    // SectionListView
    // 에 넣는 Item
    // 생성

    private static int SEARCH_NAME = 0;
    private static int SEARCH_TEAM = 1;

    private int m_nSearchType = 0;
    private int m_nPage = 1;

    EditText et_search_keyword;
    TextView tv_hint;
    ImageButton ib_cancel;

    RelativeLayout m_layoutSection;
    TextView m_tvSectionText;
    TextView m_tvSectionTextOrgan;
    CheckBox m_cbAllcheck;
    CheckBox m_cbAllcheckOrgan;

    Spinner spn_search_type;
    TextView tv_spinner_text;
    String m_strCurrentSelTeamCode = "";

    HorizontalScrollView m_hsvOrgMenu;
    RelativeLayout layout_hinttext, layout_nolist;
    RelativeLayout m_LayoutDepartmentsList;
    ArrayAdapter<String> adspin;
    ArrayList<String> m_arrSKTTeamList = null;
    ArrayList<String> m_arrSKTTeamCodeList = null;
    LinearLayout m_LayoutOrgMenu01, m_LayoutOrgMenu02, m_LayoutOrgMenu03, m_LayoutOrgMenu04, m_LayoutOrgMenu05, m_LayoutOrgMenu06, m_LayoutOrgMenu07,
            m_LayoutOrgMenu08, m_LayoutOrgMenu09, m_LayoutOrgMenu10;
    private ProgressDlg m_Progress = null;
    private CommonPopup m_Popup = null;

    private InputMethodManager imm;
    public boolean m_isRunning = false;

    ArrayList<UserSearchListData> m_arrUserSearchListDatas;

    // 사용자가 눌러서 터치를 한것인지, 앱에서 판단해서 체크하는지
    boolean m_isTouchCheckBox = false;

    ArrayList<Integer> m_arrUserNumbers;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        m_Activity = getActivity();
        imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        m_isRunning = false;
    }

    @Override
    public void onStop() {
        // TODO Auto-generated method stub
        super.onStop();
        m_isRunning = false;
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        if(m_AddedByUserAdapter != null)
            m_AddedByUserAdapter.notifyDataSetChanged();
        super.onResume();
        ((MainTabAct) m_Activity).setTopButton(((MainTabAct) m_Activity).TAB_BTN_ORGANCHART);
        m_isRunning = true;
    }

    @Override
    public void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        if (imm != null && et_search_keyword != null)
            imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        m_vOrganChart = inflater.inflate(R.layout.fragact_sns_organization_chart, container, false);

        layout_organchart = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organchart);
        layout_organregular = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organregular);

        m_LayoutDepartmentsList = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_departments_list);

            initSearchOrganChart();
            initSearchBar();

        return m_vOrganChart;
    }

    private void initSearchBar() {
      /*if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
         adspin = ArrayAdapter.createFromResource(m_Activity, R.array.arr_search_type, R.layout.layout_spinner_textview);
      } else {*/

        tv_hint = (TextView) m_vOrganChart.findViewById(R.id.tv_hinttext);
        tv_hint.setText(getString(R.string.addbyregularlist_hinttext));
        m_arrSKTTeamList = new ArrayList<>();
        m_arrSKTTeamCodeList = new ArrayList<>();
        if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)) {
            for (int i = 0; i < App.m_EntryData.m_arrCompanyData.size(); i++) {
                if (App.m_EntryData.m_strCompanyCode.equals(App.m_EntryData.m_arrCompanyData.get(i).strCode)) {
                    m_arrSKTTeamList.add(0, getString(R.string.search_my_company) + " " + App.m_EntryData.m_arrCompanyData.get(i).strName);
                    m_arrSKTTeamCodeList.add(0, App.m_EntryData.m_arrCompanyData.get(i).strCode);
                } else {
                    m_arrSKTTeamList.add(App.m_EntryData.m_arrCompanyData.get(i).strName);
                    m_arrSKTTeamCodeList.add(App.m_EntryData.m_arrCompanyData.get(i).strCode);
                }
            }
            m_arrSKTTeamList.add(1, getString(R.string.search_all));
            m_arrSKTTeamCodeList.add(1, PostSearchUserReq.SEARCH_ALL);
        } else {
            m_arrSKTTeamList.add(0, getString(R.string.search_all));
            m_arrSKTTeamCodeList.add(0, PostSearchUserReq.SEARCH_ALL);
            if(App.m_EntryData.m_MultiTenancy.isPartnerRegularSearchEnabled){
                m_arrSKTTeamList.add(1, App.m_EntryData.m_strCompanyName);
                m_arrSKTTeamCodeList.add(1, App.m_EntryData.m_strCompanyCode);
            }
        }
        adspin = new ArrayAdapter<String>(m_Activity,R.layout.layout_spinner_textview, m_arrSKTTeamList);
        tv_spinner_text = (TextView) m_vOrganChart.findViewById(R.id.tv_spinner_text);
        spn_search_type = (Spinner) m_vOrganChart.findViewById(R.id.spn_search_type);
        adspin.setDropDownViewResource(R.layout.spinner_custom_list_item);
        spn_search_type.setAdapter(adspin);
        spn_search_type.setOnItemSelectedListener(this);
        et_search_keyword = (EditText) m_vOrganChart.findViewById(R.id.et_search_keyword);
        m_tvSectionTextOrgan = (TextView) m_vOrganChart.findViewById(R.id.tv_sectiontext_organ);

        ib_cancel = (ImageButton) m_vOrganChart.findViewById(R.id.ib_cancel);
        ib_cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                et_search_keyword.setText("");
                initSearchOrganChart();
            }
        });

        et_search_keyword.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // TODO Auto-generated method stub
                CommonLog.e("EditAction", "actionId1 : " + actionId);

                switch (actionId) {
                    case EditorInfo.IME_ACTION_SEARCH:
                        if (v.getText().toString().trim().length() > 1) {
                            if (!Utils.UseChar(v.getText().toString())) {
                                m_Popup = new CommonPopup(m_Activity, SearchBrowseListFrag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                                m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.regular_expression_search)
                                        .toString());
                                m_Popup.setCancelable(false);
                                isCheckShowPopup();
                                return false;
                            }

                            requestAddedByName(v.getText().toString());

                        } else {
                            m_Popup = new CommonPopup(m_Activity, SearchBrowseListFrag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                            m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.popup_search_length).toString());
                            m_Popup.setCancelable(false);
                            isCheckShowPopup();
                        }
                        break;
                }
                return false;
            }
        });

        et_search_keyword.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
                if (s.toString().length() > 0) {
                    ib_cancel.setVisibility(View.VISIBLE);
                } else {
                    ib_cancel.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });

    }

    private void initSearchOrganChart() {
        m_cbAllcheck = (CheckBox) m_vOrganChart.findViewById(R.id.cb_sns_allmember);
        m_cbAllcheck.setVisibility(View.GONE);
        layout_organchart.setVisibility(View.GONE);
        layout_organregular.setVisibility(View.VISIBLE);
        m_LayoutDepartmentsList.setVisibility(View.GONE);

        layout_organchartlist_list = (LinearLayout) m_vOrganChart.findViewById(R.id.layout_organ_regular_list);
        m_lvorganRegularList = (ListView) m_vOrganChart.findViewById(R.id.lv_organ_regular_list);
        layout_organchartlist_list.setVisibility(View.GONE);
        m_layoutSection = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_section);
        m_tvSectionText = (TextView) m_vOrganChart.findViewById(R.id.tv_sectiontext);
        layout_hinttext = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_hinttext);
        layout_hinttext.setVisibility(View.VISIBLE);
        layout_nolist = (RelativeLayout)m_vOrganChart.findViewById(R.id.layout_no_list);
        layout_nolist.setVisibility(View.GONE);
    }

    private void setUserSearchApdapter() {
        initSearchOrganChart();
        m_lvorganRegularList.setVisibility(View.VISIBLE);
        layout_organchartlist_list.setVisibility(View.VISIBLE);

        if (m_arrUserSearchListDatas != null) {
            layout_hinttext.setVisibility(View.GONE);
            layout_nolist.setVisibility(View.GONE);
            m_layoutSection.setVisibility(View.VISIBLE);
            m_tvSectionText.setText(getString(R.string.layout_sectionstring_search_result) +" " + m_arrUserSearchListDatas.size());
        } else {
            m_layoutSection.setVisibility(View.GONE);
            layout_hinttext.setVisibility(View.GONE);
            layout_nolist.setVisibility(View.VISIBLE);
            if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER)){
                RelativeLayout textLayout = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organization_nolisttext_regular);
                textLayout.setVisibility(View.GONE);
            }
        }
        m_AddedByUserAdapter = new AddedByUserListAdapter();
        m_AddedByUserAdapter.areAllItemsEnabled();
        m_lvorganRegularList.setAdapter(m_AddedByUserAdapter);
    }

    private class AddedByUserListAdapter extends BaseAdapter {
        @Override
        public void notifyDataSetChanged() {
            // TODO Auto-generated method stub

            super.notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            if (m_arrUserSearchListDatas != null)
                return m_arrUserSearchListDatas.size();

            return 0;
        }

        @Override
        public Object getItem(int position) {

            if (m_arrUserSearchListDatas != null)
                return m_arrUserSearchListDatas.get(position);

            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int nPosition = position;
            UserSearchListData data = m_arrUserSearchListDatas.get(nPosition);

            // convertView null 시 새로 생성하자
            if (convertView == null)
                convertView = new FellowAddSearchAllUserListItemLayout(m_Activity);

            ((FellowAddSearchAllUserListItemLayout) convertView).setUserSearchListData(data);
          /*  ((SNSInviteAllUserListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);*/
            CheckBox cb_redaction = (CheckBox) ((FellowAddSearchAllUserListItemLayout) convertView).findViewById(R.id.cb_invite);
            cb_redaction.setVisibility(View.GONE);

            int nUserNumber;
            boolean isActive;
            if (data.m_isRegular) {
                RegularSearchListData regularSearchListData = (RegularSearchListData) data.m_UserData;
                nUserNumber = regularSearchListData.m_nUserNo;
                isActive = regularSearchListData.m_isAvailable;
            } else {
                PartnerSearchListData partnerSearchListData = (PartnerSearchListData) data.m_UserData;
                nUserNumber = partnerSearchListData.m_nUserNo;
                isActive = partnerSearchListData.m_isAvailable;
            }

           /* if (m_arrUserNumbers.contains(nUserNumber) || !isActive) {

                cb_redaction.setVisibility(View.GONE);
            } else {
                cb_redaction.setVisibility(View.VISIBLE);
            }*/


            if (cb_redaction.getVisibility() != View.GONE) {
                boolean is_redaction = false;
                ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;

                for (int i = 0; i < arrSearchListCheckData.size(); i++) {
                    if (nUserNumber == arrSearchListCheckData.get(i).m_nUserNo) {
                        is_redaction = true;
                        cb_redaction.setChecked(true);
                        break;
                    }
                }
                if (!is_redaction) {
                    cb_redaction.setChecked(false);
                }
            }
            return convertView;
        }

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.cb_sns_allmember) {
            m_isTouchCheckBox = true;
        } else if (v.getId() == R.id.cb_sns_allmember_organ) {
            m_isTouchCheckBox = true;
        }
        return false;
    }

    private void requestAddedByName(String a_strKeyword) {
        showProgress(getString(R.string.progress_search));
        PostSearchUserReq req = new PostSearchUserReq(a_strKeyword,m_strCurrentSelTeamCode); // 이름검색

        WebAPI webApi = new WebAPI(m_Activity);
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub
            }

            @Override
            public void onPostRequest(String strData) {
                // TODO Auto-generated method stub
                PostSearchUserRes res = new PostSearchUserRes(strData);
                res.parseData();

                m_arrUserSearchListDatas = null;
                if (res.getUserSearchListData() != null) {
                    m_arrUserSearchListDatas = res.getUserSearchListData();
                } else {

                }

                closeProgress();
                setUserSearchApdapter();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((MainTabAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        tv_spinner_text.setText(m_arrSKTTeamList.get(position));
        m_strCurrentSelTeamCode = m_arrSKTTeamCodeList.get(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub

    }

    public void showProgress() {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Activity);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void showProgress(String a_strMsg) {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Activity, a_strMsg);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void closeProgress() {
        if (m_Progress != null && m_Progress.isShowing())
            m_Progress.cancel();
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.ib_pop_ok_long) {
            CommonPopup popup_ok_long = (CommonPopup) v.getTag();
            if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
                popup_ok_long.cancel();
                App.expirePartnerLogin(m_Activity);
            } else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
                popup_ok_long.cancel();
                App.initPartnerLogin(m_Activity);
            } else {
                popup_ok_long.cancel();
            }
        }
    }

    private void isCheckShowPopup() {
        if (m_isRunning) {
            m_Popup.show();
        }
    }

}
