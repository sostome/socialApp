package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ApprovalPendingListData;

/**
 * ApprovalUserListItemLayout
 * 승인 대기 List Item Layout
 */
public class ApprovalPendingListItemLayout extends CustomLinearLayout implements OnClickListener{
	
	Button ib_complete;
	Button ib_denial;
	Context m_Context;
	
	private OnApprovalPendingListener m_ApprovalPendingListener = null;
	private ApprovalPendingListData m_ApprovalPendingListData = null;
	
	public ApprovalPendingListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public ApprovalPendingListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context a_context)
	{
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listitem_approval_pending, this);
		
	}
	
	public void setApprovalPendingListData(ApprovalPendingListData a_Data)
	{	
		m_ApprovalPendingListData = a_Data;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		TextView tv_name = (TextView)findViewById(R.id.tv_name);
		tv_name.setText(m_ApprovalPendingListData.m_strName);
		
		TextView tv_company = (TextView)findViewById(R.id.tv_company);
		tv_company.setText(m_ApprovalPendingListData.m_strCompany);
		
		TextView tv_mobile = (TextView)findViewById(R.id.tv_mobile);
		tv_mobile.setText(m_ApprovalPendingListData.m_strMobile);
		
		ib_complete = (Button)findViewById(R.id.ib_complete);
		ib_complete.setOnClickListener(this);
		
		ib_denial = (Button)findViewById(R.id.ib_denial);
		ib_denial.setOnClickListener(this);
		
		RelativeLayout layout_listitem_approval_pending = (RelativeLayout)findViewById(R.id.layout_listitem_approval_pending);
		layout_listitem_approval_pending.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()== R.id.ib_complete)
		{	
			m_ApprovalPendingListener.onApprovalComplete(m_ApprovalPendingListData.m_nUserNo);
		}
		else if(v.getId()==R.id.ib_denial)
		{
			m_ApprovalPendingListener.onApprovalDenial(m_ApprovalPendingListData.m_nUserNo);
		} else if(v.getId()== R.id.layout_listitem_approval_pending)
		{
			Intent intent = new Intent( Intent.ACTION_DIAL );
			intent.setData( Uri.parse( "tel:" + m_ApprovalPendingListData.m_strMobile ) );
			m_Context.startActivity( intent );
		}
	}
	    
	public void setApprovalPendingListener(OnApprovalPendingListener a_Listener)
	{
		m_ApprovalPendingListener = a_Listener;
	}

	public interface OnApprovalPendingListener {
        public void onApprovalComplete(int a_nApprovalPendingUserNo);
        public void onApprovalDenial(int a_nApprovalPendingUserNo);
    }
}
