package com.gmp.rusk.act;

import java.util.ArrayList;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.customview.ExtendedViewPager;
import com.gmp.rusk.customview.TouchImageView;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class SNSImageViewAct extends CustomActivity {
	RelativeLayout m_layoutTitle;

	private ArrayList<String> m_arrImageUrl = new ArrayList<String>();
	private int m_nSelectedImagePos = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

		if (Build.VERSION.SDK_INT < 16) {
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
					WindowManager.LayoutParams.FLAG_FULLSCREEN);
		} else {
			View decorView = getWindow().getDecorView();
			int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
			decorView.setSystemUiVisibility(uiOptions);
		}
		setContentView(R.layout.act_snsimageview);
		
		checkIntent();
		initUI();
		setUI();
	}
	
	private void checkIntent()
	{
		m_arrImageUrl = getIntent().getStringArrayListExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_IMAGEURLLIST);
		m_nSelectedImagePos = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_SELECTEDIMAGEPOS, -1);
	}
	
	private void initUI()
	{
		m_layoutTitle = (RelativeLayout)findViewById(R.id.layout_imageviewtitle);
		ExtendedViewPager vpPicture = (ExtendedViewPager)findViewById(R.id.vp_snsimgeview_image);
		vpPicture.setAdapter(new TouchImageAdapter());

		ImageView ivBack = (ImageView)findViewById(R.id.iv_chat_back);
		ivBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}
	
	private void setUI()
	{
		ExtendedViewPager vpPicture = (ExtendedViewPager)findViewById(R.id.vp_snsimgeview_image);
		vpPicture.setCurrentItem(m_nSelectedImagePos);
	}
	
	private class TouchImageAdapter extends PagerAdapter {

        @Override
        public int getCount() {
        	if(m_arrImageUrl == null)
        		return 0;
        	
        	return m_arrImageUrl.size();
        }

        @Override
        public View instantiateItem(ViewGroup container, int position) {
            TouchImageView img = new TouchImageView(container.getContext());
//            img.setImageResource(images[position]);
            ImageLoaderManager imageLoaderManager = ImageLoaderManager.getInstance(SNSImageViewAct.this);
            Bitmap bmp = imageLoaderManager.getLocalImage(m_arrImageUrl.get(position));
            if(bmp == null)
            	imageLoaderManager.getImage(img, m_arrImageUrl.get(position), R.drawable.file_img_frame_page);
            else
            	img.setImageBitmap(bmp);
            
            container.addView(img, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
			img.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_layoutTitle.getVisibility() == View.VISIBLE)
						m_layoutTitle.setVisibility(View.INVISIBLE);
					else
						m_layoutTitle.setVisibility(View.VISIBLE);
				}
			});
            return img;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

    }
}
