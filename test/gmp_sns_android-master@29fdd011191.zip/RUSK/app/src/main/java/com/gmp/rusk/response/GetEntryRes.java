package com.gmp.rusk.response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.CompanyEntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.utils.CommonLog;

public class GetEntryRes extends Res{

	private final String JSON_LOL						= "lol";

	public String m_strLol = "";

	public GetEntryRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);

			if(!jsonRoot.isNull(JSON_LOL)) {
				m_strLol = jsonRoot.optString(JSON_LOL);
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	public String getLOL(){
		return m_strLol;
	}

}
