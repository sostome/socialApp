package com.gmp.rusk.customview;

import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;

public class SysNoticePopupAct extends CustomActivity implements OnTouchListener{

	private String m_strTitle = "";
	private String m_strBody = "";
	private int m_nSysNoticeId = 0;

	private boolean m_isCheck = false;
	
	private ImageView iv_pop_notice_not_review;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		setContentView(R.layout.act_popup_sysnotice);
		// select UserNo 가져 오는 부분 구현
		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_strTitle = bundle.getString(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_TITLE, getString(R.string.pop_error_title));
			m_strBody = bundle.getString(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BODY, "");
			m_nSysNoticeId = bundle.getInt(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_SYSNOTICEID);
		}

		TextView tv_pop_title = (TextView) findViewById(R.id.tv_pop_title);
		tv_pop_title.setText(m_strTitle);

		TextView tv_pop_body = (TextView) findViewById(R.id.tv_pop_body);
		tv_pop_body.setText(m_strBody);
		
		iv_pop_notice_not_review = (ImageView) findViewById(R.id.iv_pop_notice_not_review);
		iv_pop_notice_not_review.setOnTouchListener(this);
		
		ImageButton ib_pop_notice_ok = (ImageButton) findViewById(R.id.ib_pop_notice_ok);
		ib_pop_notice_ok.setOnClickListener(this);
		
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		// super.onBackPressed();
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		// TODO Auto-generated method stub
		if (v.getId() == R.id.ib_pop_notice_ok) {
			if(m_isCheck)
			{
				SharedPref pref = SharedPref.getInstance(this);
				pref.setIntegerPref(SharedPref.PREF_ADMIN_NOTICENO, m_nSysNoticeId);
			}
			finish();
		} 
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.iv_pop_notice_not_review) {
			if(event.getAction() == MotionEvent.ACTION_DOWN)
			{
				if(!m_isCheck)
				{
					m_isCheck = true;
					iv_pop_notice_not_review.setBackgroundResource(R.drawable.btn_notagain_pressed);
				
				}else {
					m_isCheck = false;
					iv_pop_notice_not_review.setBackgroundResource(R.drawable.btn_notagain);
				}
			}
		}
		return false;
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub

		Rect dialogBounds = new Rect();
		getWindow().getDecorView().getHitRect(dialogBounds);
		if (!dialogBounds.contains((int) ev.getX(), (int) ev.getY())) {
			return false;
		}
		return super.dispatchTouchEvent(ev);
	}

}
