package com.gmp.rusk.service;

import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.IntroAct;
import com.gmp.rusk.act.MainTabAct;

public class XmppListener {

	private ChatRoomAct.PacketListener m_PacketListener = null;
	private ChatRoomGroupAct.PacketListener m_GroupPacketListener = null;
	private MainTabAct.OnNotifyListener m_NotifyListner = null;
	private IntroAct.PacketListener m_IntroPacketListener = null;

	// 일반 채팅
	public void addIntroPacketListener(IntroAct.PacketListener aPacketListener) {
		m_IntroPacketListener = aPacketListener;
	}

	public void removeIntroPacketListener() {
		m_IntroPacketListener = null;
	}
	
	public IntroAct.PacketListener getIntroPacketListner() {
		return m_IntroPacketListener;
	}

	// 메인 탭
	public void addNotifyListner(MainTabAct.OnNotifyListener aNotifyListener) {
		m_NotifyListner = aNotifyListener;
	}

	public void removeNotifyListener() {
		m_NotifyListner = null;
	}

	public MainTabAct.OnNotifyListener getNotifyListner(){
		return m_NotifyListner;
	}
	// 일반 채팅
	public void addPacketListener(ChatRoomAct.PacketListener aPacketListener) {
		m_PacketListener = aPacketListener;
	}

	public void removePacketListener() {
		m_PacketListener = null;
	}
	public ChatRoomAct.PacketListener getPacketListener(){
		return m_PacketListener;
	}
	// 그룹 채팅

	public void addGroupPacketListener(ChatRoomGroupAct.PacketListener aPacketListener) {
		m_GroupPacketListener = aPacketListener;
	}

	public void removeGroupPacketListener() {
		m_GroupPacketListener = null;
	}
	
	public ChatRoomGroupAct.PacketListener getGroupPacketListener(){
		return m_GroupPacketListener;
	}
}
