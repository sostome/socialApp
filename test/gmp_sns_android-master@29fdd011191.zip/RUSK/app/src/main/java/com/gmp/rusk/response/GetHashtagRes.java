package com.gmp.rusk.response;

import com.gmp.rusk.utils.CommonLog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetHashtagRes extends Res{

private final String JSON_HASHTAGS 			= "hashtags";

	private ArrayList<String> m_arrHashtags = new ArrayList<String>();

	public GetHashtagRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			JSONArray jsonArray = jsonRoot.getJSONArray(JSON_HASHTAGS);
			for(int i = 0; i < jsonArray.length(); i++){
				m_arrHashtags.add(jsonArray.getString(i));
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<String> getHashtags(){
		return m_arrHashtags;
	}
}
