package com.gmp.rusk.fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomImageAct;
import com.gmp.rusk.act.FileBoxAct;
import com.gmp.rusk.act.SNSImageViewAct;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.FileBoxData;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by kang on 2017-09-17.
 */

public class FileBoxTabImageFrag extends Fragment {

    public MyApp App = MyApp.getInstance();
    View FileBoxGrid;
    LayoutInflater m_Inflater;

    ArrayList<FileBoxData> m_arrFileListDatas = new ArrayList<FileBoxData>();
    MediaAdapter adapter;

    boolean m_isChannel = false;
    int m_nPage = 0;
    boolean m_isLastPage = false;
    boolean m_isLoading = false;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        FileBoxGrid = inflater.inflate(R.layout.fragact_filebox_tab_image, container, false);
        m_Inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        ((FileBoxAct)getActivity()).setViewListener(m_ImageViewListener);
        initUI();
        return FileBoxGrid;
    }


    private void initUI(){

        if(((FileBoxAct)getActivity()).m_nChannelID != 0) {
            m_isChannel = true;
            setChannelFileList();

        } else {
            m_isChannel = false;
            setChatRoomFileList();
        }

    }

    public class ViewHolder {
        public ImageView m_ivMedia, m_ivMovieIcon;
    }

    class MediaAdapter extends BaseAdapter {

        ViewHolder viewHolder;

        @Override
        public int getCount() {
            return m_arrFileListDatas.size();
        }

        @Override
        public Object getItem(int position) {
            return m_arrFileListDatas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final FileBoxData m_Data = (FileBoxData) m_arrFileListDatas.get(position);
            if(convertView == null) {
                convertView = m_Inflater.inflate(R.layout.layout_filebox_grid_media, parent,false);
                viewHolder = new ViewHolder();
                viewHolder.m_ivMedia = (ImageView) convertView.findViewById(R.id.iv_media);
                viewHolder.m_ivMovieIcon = (ImageView) convertView.findViewById(R.id.iv_movie_icon);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            viewHolder.m_ivMovieIcon.setVisibility(View.GONE);

            if(m_Data != null) {
                ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(getActivity());
                Bitmap bmp = imageLoaderMng.getLocalImage(m_Data.m_strPreviewUrl);
                if(bmp == null)
                    imageLoaderMng.getImage(viewHolder.m_ivMedia, m_Data.m_strPreviewUrl, R.drawable.file_img_frame_page);
                else
                    viewHolder.m_ivMedia.setImageBitmap(bmp);

                if(!m_isChannel) {
                    viewHolder.m_ivMedia.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
                                    App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled){
                                ((FileBoxAct)getContext()).showImageErrorPopup();
                            } else {
                                Intent intent = new Intent(getContext(), ChatRoomImageAct.class);
                                intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_IMAGE_PATH, m_Data.m_strUrl);
                                intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_ROOM_ID, ((FileBoxAct) getActivity()).m_strChatroomID);
                                try {
                                    intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_MESSAGE_ID, m_Data.m_jsonObject.getString(StaticString.XMPP_TEXT_FILENAME));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                                getContext().startActivity(intent);
                            }
                        }
                    });
                } else {
                    viewHolder.m_ivMedia.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
                                    App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled) {
                                ((FileBoxAct)getContext()).showImageErrorPopup();
                            } else {
                                Intent intent = new Intent(getContext(), SNSImageViewAct.class);
                                ArrayList<String> arrImageUrlList = new ArrayList<String>();
                                arrImageUrlList.add(m_Data.m_strUrl);
                                intent.putExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_IMAGEURLLIST, arrImageUrlList);
                                intent.putExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_SELECTEDIMAGEPOS, 0);
                                startActivity(intent);
                            }
                        }
                    });

                }
            }
            return convertView;
        }
    }

    private void setChannelFileList(){

        m_arrFileListDatas = new ArrayList<FileBoxData>();

        ArrayList<ChannelFileData> arrData = ((FileBoxAct)getActivity()).m_arrImageListDatas;
        for(int i = 0; i < arrData.size(); i++){
            FileBoxData data = new FileBoxData();
            data.m_strUrl = arrData.get(i).m_strUrl;
            data.m_strPreviewUrl = arrData.get(i).m_strPreviewUrl;
            data.m_lnFileSize = 0;
            m_arrFileListDatas.add(data);

        }

        adapter = new MediaAdapter();
        GridView gv_Media = (GridView) FileBoxGrid.findViewById(R.id.gv_media);
        gv_Media.setAdapter(adapter);
        gv_Media.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                final int lastItem = firstVisibleItem + visibleItemCount;
                if(lastItem == totalItemCount){
                    // here you have reached end of list, load more data
                    if(!m_isLastPage && !m_isLoading) {
                        m_isLoading = true;
                        ((FileBoxAct) getActivity()).requestChannelFileList(m_nPage++, StaticString.FILE_TYPE_IMAGE);
                    }
                }
            }
        });

    }

    private void setChannelFileAddList(boolean isLastPage){
        m_isLastPage = isLastPage;
        m_isLoading = false;
        m_arrFileListDatas = new ArrayList<FileBoxData>();

        ArrayList<ChannelFileData> arrData = ((FileBoxAct)getActivity()).m_arrImageListDatas;
        for(int i = 0; i < arrData.size(); i++){
            FileBoxData data = new FileBoxData();
            data.m_strUrl = arrData.get(i).m_strUrl;
            data.m_strPreviewUrl = arrData.get(i).m_strPreviewUrl;
            data.m_lnFileSize = 0;
            m_arrFileListDatas.add(data);

        }

        adapter.notifyDataSetChanged();

    }
    private void setChatRoomFileList(){

        m_arrFileListDatas = new ArrayList<FileBoxData>();

        ArrayList<ChattingMessageData> arrMessageData = ((FileBoxAct)getActivity()).m_arrChattingImageListDatas;
        for(int i = 0; i < arrMessageData.size(); i++){
            FileBoxData data = new FileBoxData();
            try {
                JSONObject jsonObject = new JSONObject(arrMessageData.get(i).m_strMsgText);
                data.m_strUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
                data.m_strPreviewUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
                data.m_lnFileSize = 0;
                data.m_jsonObject = jsonObject;
                m_arrFileListDatas.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        adapter = new MediaAdapter();
        GridView gv_Media = (GridView) FileBoxGrid.findViewById(R.id.gv_media);
        gv_Media.setAdapter(adapter);

    }

    FileBoxAct.OnImageViewListener m_ImageViewListener = new FileBoxAct.OnImageViewListener() {

        @Override
        public void startViewAdd(boolean isLastPage) {
                setChannelFileAddList(isLastPage);
        }
    };
}
