package com.gmp.rusk.datamodel;

import java.util.ArrayList;

public class SetSuggestBoardData {
	
	public int m_nComplaintNo = -1;
	public boolean m_isResponed = false;
	public String m_strTitle = "";
	public String m_strBody = "";
	public String m_strCreatedDate = "";
	public String m_strUpdatedDate = "";
	public String m_strResponse = "";
	public String m_strResponseDate = "";

	public ArrayList<SetSuggestBoardFileData> m_arrSetSuggestFileData = new ArrayList<SetSuggestBoardFileData>();
}
