package com.gmp.rusk.datamodel;

public class ApprovalPendingListData {
	public int m_nUserNo = 0;					//사용자 번호
	public String m_strName = "";				//사용자 이름
	public String m_strCompany = "";			//파트너 소속
	public String m_strMobile = "";			//전화번호
	
	public ApprovalPendingListData(int a_nUserNo, String a_strName, String a_strCompany, String a_strMobile) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCompany = a_strCompany;
		m_strMobile = a_strMobile;
	}
}
