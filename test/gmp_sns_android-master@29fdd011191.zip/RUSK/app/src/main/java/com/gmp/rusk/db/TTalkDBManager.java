package com.gmp.rusk.db;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.database.Cursor;
import android.util.SparseArray;
import android.util.SparseBooleanArray;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.datamodel.ChatRoomListData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSAlarmData;
import com.gmp.rusk.datamodel.SNSGroupData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * TTalkDBManager TTalk 의 Database를 관리하는 Class
 * 
 * @author DoYoungmin
 */
public class TTalkDBManager {
	
	public static void initTTalkDB(Context a_Context)
	{
		ContactsDBManager.deleteContacts(a_Context);
		ArrayList<ChattingRoomInfoData> arrRoomInfo = RoomDBManager.getChattingRoom(a_Context);
		
		for(ChattingRoomInfoData data : arrRoomInfo)
		{
			ChattingDBManager chattingDB = new ChattingDBManager(a_Context);
			chattingDB.openWritable(data.m_strRoomId);
			chattingDB.deleteChattingMessage();
			chattingDB.deleteChattingUser();
			chattingDB.close();
		}
		
		RoomDBManager.deleteRoom(a_Context);
		SNSGroupDBManager.deleteSNSMyGroupInfo(a_Context);
		SNSGroupDBManager.deleteSNSAlarm(a_Context);
	}
	
	public static void checkTTalkDB(Context a_Context)
	{
		ContactsDBManager.initDatabase(a_Context);
		RoomDBManager.initDatabase(a_Context);
		
		ArrayList<ChattingRoomInfoData> arrRoomInfo = RoomDBManager.getChattingRoom(a_Context);
		
		for(ChattingRoomInfoData data : arrRoomInfo)
		{
			ChattingDBManager chattingDB = new ChattingDBManager(a_Context);
			chattingDB.openReadable(data.m_strRoomId);
			chattingDB.close();
		}
	}

	public static class ContactsDBManager {
		/**
		 * insertContacts 주소록 ArrayList 추가
		 * 
		 * @param a_Context
		 * @param
		 * @return 추가한 Item의 개수
		 */
		
		public static void initDatabase(Context a_Context)
		{
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.openReadOnly();
			contactsDB.close();
		}
		
		public static int insertContacts(Context a_Context, ArrayList<UserListData> a_arrUserListData) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.insertContacts(a_arrUserListData);
			contactsDB.close();
			MyApp App = MyApp.getInstance();
			if(App.m_arrUserListData != null) {
				for(UserListData data : a_arrUserListData) {
					App.m_arrUserListData.put(data.m_nUserNo, data);
				}
			}
			return nCount;
		}

		/**
		 * insertContacts 주소록 단일 추가
		 * 
		 * @param a_Context
		 * @param a_userListData
		 * @return 추가한 Item의 개수
		 */
		public static int insertContacts(Context a_Context, UserListData a_userListData) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.insertContacts(a_userListData);
			contactsDB.close();
			MyApp App = MyApp.getInstance();
			if(App.m_arrUserListData != null) {
				App.m_arrUserListData.put(a_userListData.m_nUserNo, a_userListData);
			}
			return nCount;
		}

		/**
		 * updateContacts 주소록 Array 수정 userno == userid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_arrUserListData
		 * @return 수정한 Item의 개수
		 */
		public static int updateContacts(Context a_Context, ArrayList<UserListData> a_arrUserListData) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.updateContacts(a_arrUserListData);
			contactsDB.close();
			MyApp App = MyApp.getInstance();
			if(App.m_arrUserListData != null) {
				for(UserListData data : a_arrUserListData) {
					App.m_arrUserListData.put(data.m_nUserNo, data);
				}
			}
			return nCount;
		}

		/**
		 * updateContacts 주소록 단일 수정 userno == userid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_userListData
		 * @return 수정한 Item의 개수
		 */
		public static int updateContacts(Context a_Context, UserListData a_userListData) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.updateContacts(a_userListData);
			contactsDB.close();
			MyApp App = MyApp.getInstance();
			if(App.m_arrUserListData != null) {
				App.m_arrUserListData.put(a_userListData.m_nUserNo, a_userListData);
			}
			return nCount;
		}
		
		public static int updateContactsIsFellow(Context a_Context, int a_nUserNo, boolean a_isFellow) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.updateContacts(a_nUserNo, a_isFellow);
			contactsDB.close();

			MyApp App = MyApp.getInstance();
			if(App.m_arrUserListData != null) {
				UserListData data = App.m_arrUserListData.get(a_nUserNo);
				data.m_isFellow = a_isFellow;
				App.m_arrUserListData.put(a_nUserNo, data);
			}
			return nCount;
		}

		/**
		 * deleteContacts 주소록 전체 삭제
		 * 
		 * @param a_Context
		 * @return 삭제한 Item의 개수
		 */
		public static int deleteContacts(Context a_Context) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.deleteContacts();
			contactsDB.close();
			MyApp App = MyApp.getInstance();
			App.m_arrUserListData = null;
			return nCount;
		}

		/**
		 * deleteContacts 주소록 삭제
		 * 
		 * @param a_Context
		 * @param a_nUserNo
		 *            삭제할 UserNo
		 * @return 삭제한 Item의 개수
		 */
		public static int deleteContacts(Context a_Context, int a_nUserNo) {
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.open();
			int nCount = contactsDB.deleteContacts(a_nUserNo);
			contactsDB.close();

			return nCount;
		}

		/**
		 * getContacts 주소록 가져오기
		 * 
		 * @param a_Context
		 * @return 주소록 ArrayList
		 *//*
		public static ArrayList<UserListData> getContacts(Context a_Context) {
			ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.openReadOnly();

			Cursor cursor = contactsDB.getContactsList();

			if (cursor.moveToFirst()) {
				do {
					int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
					String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
					String strCharge = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_CHARGE));
					boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
					boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
					String strAesData = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ENCRYPINFO));
					String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
					boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
					String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
					String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));

					UserListData data = new UserListData(nUserNo, strUserType, strCharge, isImageAvailable, isActive, strAesData, strGreeting, strUserStatus, isFellow, strFellowAddTime);

					arrUserListData.add(data);
				} while (cursor.moveToNext());
			}

			cursor.close();

			contactsDB.close();
			return arrUserListData;
		}*/
		
		public static SparseArray<UserListData> getContactsReturnSparseArray(Context a_Context) {
			MyApp App = MyApp.getInstance();
			if(App.m_arrUserListData == null) {
			SparseArray<UserListData> arrUserListData = new SparseArray<UserListData>();
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.openReadOnly();

			Cursor cursor = contactsDB.getContactsList();

			if (cursor.moveToFirst()) {
				do {
					int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
					Gson gson = new Gson();
					Type type = new TypeToken<HashMap<String, String>>() {}.getType();
					String strMapData = "";
					PersonalData personalData = null;
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
						strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
						HashMap mapPersonalData = gson.fromJson(strMapData, type);
						personalData = new PersonalData(mapPersonalData);
					} catch (Exception e) {
						e.printStackTrace();
						personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
					}
					String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
					boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
					boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
					String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
					boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
					String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
					String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));

					UserListData data = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);

					arrUserListData.put(nUserNo, data);
				} while (cursor.moveToNext());
			}

			cursor.close();

			contactsDB.close();
				App.m_arrUserListData = arrUserListData;
			}
			CommonLog.e(TTalkDBManager.class.getSimpleName(), "getContactsList Size : " + App.m_arrUserListData.size());
			return App.m_arrUserListData;
		}

		/**
		 * getContacts 주소록 가져오기
		 * 
		 * @param a_Context
		 * @param a_nUserNo
		 * @return UserListData
		 */
		public static UserListData getContacts(Context a_Context, int a_nUserNo) {
			MyApp App = MyApp.getInstance();
			UserListData userListData = null;
			if(App.m_arrUserListData == null) {

			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.openReadOnly();

			Cursor cursor = contactsDB.getContacts(a_nUserNo);

			if (cursor.moveToFirst()) {
				int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
				Gson gson = new Gson();
				Type type = new TypeToken<HashMap<String, String>>() {}.getType();
				String strMapData = "";
				PersonalData personalData = null;
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
					HashMap mapPersonalData = gson.fromJson(strMapData, type);
					personalData = new PersonalData(mapPersonalData);
				} catch (Exception e) {
					e.printStackTrace();
					personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
				}
				String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
				boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
				boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
				String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
				boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
				String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
				String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));
				
				userListData = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);
			}

			cursor.close();

			contactsDB.close();
			} else {
				userListData = App.m_arrUserListData.get(a_nUserNo);
			}
			return userListData;
		}

		public static UserListData getContacts(Context a_Context, int a_nUserNo, boolean aaa) {
			MyApp App = MyApp.getInstance();
			UserListData userListData = null;
			if(App.m_arrUserListData == null) {

				ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
				contactsDB.openReadOnly();

				Cursor cursor = contactsDB.getContacts(a_nUserNo);

				if (cursor.moveToFirst()) {
					int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
					Gson gson = new Gson();
					Type type = new TypeToken<HashMap<String, String>>() {}.getType();
					String strMapData = "";
					PersonalData personalData = null;
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
						strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
						HashMap mapPersonalData = gson.fromJson(strMapData, type);
						personalData = new PersonalData(mapPersonalData);
					} catch (Exception e) {
						e.printStackTrace();
						personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
					}
					String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
					boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
					boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
					String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
					boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
					String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
					String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));

					userListData = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);
				}

				cursor.close();

				contactsDB.close();
			} else {
				userListData = App.m_arrUserListData.get(a_nUserNo);
			}
			return userListData;
		}

		/**
		 * getContactsByFellows 동료 리스트 가져오기
		 * 
		 * @param a_Context
		 * @return 주소록 ArrayList
		 */
		public static ArrayList<UserListData> getContactsByFellows(Context a_Context) {
			ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
			ContactsDBAdapter contactsDB = new ContactsDBAdapter(a_Context);
			contactsDB.openReadOnly();

			Cursor cursor = contactsDB.getContactsByFellowList();

			if (cursor.moveToFirst()) {
				do {
					int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
					Gson gson = new Gson();
					Type type = new TypeToken<HashMap<String, String>>() {}.getType();
					String strMapData = "";
					PersonalData personalData = null;
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
						strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
						HashMap mapPersonalData = gson.fromJson(strMapData, type);
						personalData = new PersonalData(mapPersonalData);
					} catch (Exception e) {
						e.printStackTrace();
						personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
					}
					String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
					boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
					boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
					String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
					boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
					String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
					String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));
					
					UserListData data = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);

					arrUserListData.add(data);
				} while (cursor.moveToNext());
			}

			cursor.close();

			contactsDB.close();
			return arrUserListData;
		}
	}

	// public static class FellowsDBManager
	// {
	// /**
	// * insertFellows
	// * 동료 ArrayList 추가
	// * @param a_Context
	// * @param a_arrFellowListData
	// * @return 추가한 Item의 개수
	// */
	// public static int insertFellows(Context a_Context, ArrayList<FellowListData> a_arrFellowListData)
	// {
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.open();
	// int nCount = fellowsDB.insertFellows(a_arrFellowListData);
	// fellowsDB.close();
	//
	// return nCount;
	// }
	//
	// /**
	// * insertFellows
	// * 동료 단일 추가
	// * @param a_Context
	// * @param a_fellowListData
	// * @return 추가한 Item의 개수
	// */
	// public static int insertFellows(Context a_Context, FellowListData a_fellowListData)
	// {
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.open();
	// int nCount = fellowsDB.insertFellows(a_fellowListData);
	// fellowsDB.close();
	//
	// return nCount;
	// }
	//
	// /**
	// * updateFellows
	// * 동료 Array 수정
	// * userno == userid 인 Item으로 수정한다.
	// * @param a_Context
	// * @param a_arrFellowListData
	// * @return 수정한 Item의 개수
	// */
	// public static int updateFellows(Context a_Context, ArrayList<FellowListData> a_arrFellowListData)
	// {
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.open();
	// int nCount = fellowsDB.updateFellows(a_arrFellowListData);
	// fellowsDB.close();
	//
	// return nCount;
	// }
	//
	// /**
	// * updateFellows
	// * 동료 단일 수정
	// * userno == userid 인 Item으로 수정한다.
	// * @param a_Context
	// * @param a_fellowListData
	// * @return 수정한 Item의 개수
	// */
	// public static int updateFellows(Context a_Context, FellowListData a_fellowListData)
	// {
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.open();
	// int nCount = fellowsDB.updateFellows(a_fellowListData);
	// fellowsDB.close();
	//
	// return nCount;
	// }
	//
	// /**
	// * deleteFellows
	// * 동료 전체 삭제
	// * @param a_Context
	// * @return 삭제한 Item의 개수
	// */
	// public static int deleteFellows(Context a_Context)
	// {
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.open();
	// int nCount = fellowsDB.deleteFellows();
	// fellowsDB.close();
	//
	// return nCount;
	// }
	//
	// /**
	// * deleteFellows
	// * 동료 삭제
	// * @param a_Context
	// * @param a_nUserNo 삭제할 UserNo
	// * @return 삭제한 Item의 개수
	// */
	// public static int deleteFellows(Context a_Context, int a_nUserNo)
	// {
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.open();
	// int nCount = fellowsDB.deleteFellows(a_nUserNo);
	// fellowsDB.close();
	//
	// return nCount;
	// }
	//
	// /**
	// * getFellows
	// * 동료 가져오기
	// * @param a_Context
	// * @return 동료 ArrayList
	// */
	// public static ArrayList<FellowListData> getFellows(Context a_Context)
	// {
	// ArrayList<FellowListData> arrFellowListData = new ArrayList<FellowListData>();
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.openReadOnly();
	//
	// Cursor cursor = fellowsDB.getFellowsList();
	//
	// if(cursor.moveToFirst())
	// {
	// do
	// {
	// int nUserNo = cursor.getInt(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_USERID));
	// String strUserType = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_USERTYPE));
	// String strName = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_NAME));
	// String strDepartment = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_DEPARTMENT));
	// String strTeam = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_TEAM));
	// String strCharge = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_CHARGE));
	// boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_HASTHUMB)) == 1 ? true : false;
	// boolean isActive = cursor.getInt(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_ISAPPINSTALLED)) == 1 ? true : false;
	// // String strUserStatus = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_USERSTATUS));
	//
	// // FellowListData data = new FellowListData(nUserNo, strName, strDepartment, strTeam, strCharge, isImageAvailable, isActive, strUserStatus);
	// FellowListData data = new FellowListData(nUserNo, strUserType, strName, strDepartment, strTeam, strCharge, isImageAvailable, isActive);
	//
	// arrFellowListData.add(data);
	// }while(cursor.moveToNext());
	// }
	//
	// cursor.close();
	//
	// fellowsDB.close();
	// return arrFellowListData;
	// }
	//
	// /**
	// * getContacts
	// * 동료 가져오기
	// * @param a_Context
	// * @param a_nUserNo
	// * @return UserListData
	// */
	// public static FellowListData getContacts(Context a_Context, int a_nUserNo)
	// {
	// FellowListData fellowListData = null;
	// FellowsDBAdapter fellowsDB = new FellowsDBAdapter(a_Context);
	// fellowsDB.openReadOnly();
	//
	// Cursor cursor = fellowsDB.getFellows(a_nUserNo);
	//
	// if(cursor.moveToFirst())
	// {
	// int nUserNo = cursor.getInt(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_USERID));
	// String strUserType = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_USERTYPE));
	// String strName = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_NAME));
	// String strDepartment = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_DEPARTMENT));
	// String strTeam = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_TEAM));
	// String strCharge = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_CHARGE));
	// boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_HASTHUMB)) == 1 ? true : false;
	// boolean isActive = cursor.getInt(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_ISAPPINSTALLED)) == 1 ? true : false;
	// // String strUserStatus = cursor.getString(cursor.getColumnIndex(FellowsDBAdapter.KEY_FELLOWS_USERSTATUS));
	//
	// // fellowListData = new FellowListData(nUserNo, strName, strDepartment, strTeam, strCharge, isImageAvailable, isActive, strUserStatus);
	// fellowListData = new FellowListData(nUserNo, strUserType, strName, strDepartment, strTeam, strCharge, isImageAvailable, isActive);
	// }
	//
	// cursor.close();
	//
	// fellowsDB.close();
	// return fellowListData;
	// }
	// }

	public static class RoomDBManager {
		
		public static void initDatabase(Context a_Context)
		{
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.openReadOnly();
			roomDB.close();
		}
		
		/**
		 * insertRoom 채팅방 ArrayList 추가
		 * 
		 * @param a_Context
		 * @param a_arrRoomListData
		 * @return 추가한 Item의 개수
		 */
		public static int insertRoom(Context a_Context, ArrayList<ChattingRoomInfoData> a_arrRoomListData) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.insertRoom(a_arrRoomListData);
			roomDB.close();

			return nCount;
		}

		/**
		 * insertRoom 채팅방 단일 추가
		 * 
		 * @param a_Context
		 * @param a_roomData
		 * @return 추가한 Item의 개수
		 */
		public static int insertRoom(Context a_Context, ChattingRoomInfoData a_roomData) {
			RoomDBAdapter roomsDB = new RoomDBAdapter(a_Context);
			roomsDB.open();
			int nCount = roomsDB.insertRoom(a_roomData);
			roomsDB.close();

			return nCount;
		}

		/**
		 * updateRoom 채팅방 Array 수정 roomid == roomid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_arrRoomData
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoom(Context a_Context, ArrayList<ChattingRoomInfoData> a_arrRoomData) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoom(a_arrRoomData);
			roomDB.close();

			return nCount;
		}

		/**
		 * updateRoom 채팅방 단일 수정 roomid == roomid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_roomData
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoom(Context a_Context, ChattingRoomInfoData a_roomData) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoom(a_roomData);
			roomDB.close();

			return nCount;
		}
		
		/**
		 * updateRoom 채팅방 방장 수정 roomid == roomid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_strRoomId
		 * @param a_nRoomOwnerId
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoom(Context a_Context, String a_strRoomId, int a_nRoomOwnerId) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoom(a_strRoomId, a_nRoomOwnerId);
			roomDB.close();

			return nCount;
		}
		
		/**
		 * updateRoom 채팅방 Title 수정 roomid == roomid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_strRoomId
		 * @param a_strTitle
		 * @param a_isTitleEdited
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoom(Context a_Context, String a_strRoomId, String a_strTitle, boolean a_isTitleEdited) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoom(a_strRoomId, a_strTitle, a_isTitleEdited);
			roomDB.close();

			return nCount;
		}
		
		/**
		 * updateRoom 채팅방 Alarm 수정 roomid == roomid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_strRoomId
		 * @param a_isAlarmOn
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoom(Context a_Context, String a_strRoomId, boolean a_isAlarmOn) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoom(a_strRoomId, a_isAlarmOn);
			roomDB.close();

			return nCount;
		}
		/**
		 * updateRoom 채팅방 Alarm 수정 roomid == roomid 인 Item으로 수정한다.
		 *
		 * @param a_Context
		 * @param a_strRoomId
		 * @param a_strImage
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoom(Context a_Context, String a_strRoomId, String a_strImage) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoom(a_strRoomId, a_strImage);
			roomDB.close();

			return nCount;
		}
		/**
		 * updateRoomFavorite 채팅방 즐겨찾기 수정 roomid == roomid 인 Item으로 수정한다.
		 * 
		 * @param a_Context
		 * @param a_strRoomId
		 * @param a_isFavorite
		 * @return 수정한 Item의 개수
		 */
		public static int updateRoomFavorite(Context a_Context, String a_strRoomId, boolean a_isFavorite) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoomFavorite(a_strRoomId, a_isFavorite);
			roomDB.close();

			return nCount;
		}
		
		public static int updateRoomTitle(Context a_Context, int a_nGroupId, String a_strRoomTitle) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateRoomTitle(a_nGroupId, a_strRoomTitle);
			roomDB.close();

			return nCount;
		}

		public static int updateRoomBackgroundColor(Context a_Context,String a_strRoomId,int a_nColor){
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.updateChatListBackgroundColor(a_strRoomId,a_nColor);
			roomDB.close();

			return nCount;
		}


		/**
		 * deleteRoom 채팅방 전체 삭제
		 * 
		 * @param a_Context
		 * @return 삭제한 Item의 개수
		 */
		public static int deleteRoom(Context a_Context) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.deleteRoom();
			roomDB.close();

			return nCount;
		}

		/**
		 * deleteRoom 채팅방 삭제
		 * 
		 * @param a_Context
		 * @param a_strRoomId
		 *            삭제할 RoomId
		 * @return 삭제한 Item의 개수
		 */
		public static int deleteRoom(Context a_Context, String a_strRoomId) {
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.open();
			int nCount = roomDB.deleteRoom(a_strRoomId);
			roomDB.close();

			return nCount;
		}

		public static ArrayList<ChattingRoomInfoData> getChattingRoom(Context a_Context) {
			ArrayList<ChattingRoomInfoData> arrRoomInfo = new ArrayList<ChattingRoomInfoData>();
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.openReadOnly();
			Cursor cursor = roomDB.getRoomList();
			if (cursor.moveToFirst()) {
				do {
					String strRoomId = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMID));
					String strRoomTitle = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMTITLE));
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					int nRoomOwnerId = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMOWNERID));
					boolean isAlarmOn = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
					boolean isTitleEdited = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISTITLEDITED)) == 1 ? true : false;
					boolean isFavorite = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISFAVORITE)) == 1 ? true : false;
					int nBackgroundColor = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_BACKGROUND_COLOR));
					String image = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_COVERIMAGE));
					ChattingRoomInfoData data = new ChattingRoomInfoData(strRoomId, strRoomTitle, isAlarmOn, nRoomOwnerId, isTitleEdited, isFavorite,nBackgroundColor,image);
					arrRoomInfo.add(data);

				} while (cursor.moveToNext());
			}

			cursor.close();
			roomDB.close();

			return arrRoomInfo;
		}
		
		public static ChattingRoomInfoData getChattingRoom(Context a_Context, String a_strRoomId) {
			ChattingRoomInfoData roomInfoData = null;
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.openReadOnly();

			Cursor cursor = roomDB.getRoom(a_strRoomId);
			if (cursor.moveToFirst()) {
				String strRoomId = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMID));
				String strRoomTitle = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMTITLE));
				int nRoomOwnerId = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMOWNERID));
				boolean isAlarmOn = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
				boolean isTitleEdited = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISTITLEDITED)) == 1 ? true : false;
				boolean isFavorite = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISFAVORITE)) == 1 ? true : false;
				int nBackgroundColor = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_BACKGROUND_COLOR));
				String image = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_COVERIMAGE));

				roomInfoData = new ChattingRoomInfoData(strRoomId, strRoomTitle, isAlarmOn, nRoomOwnerId, isTitleEdited, isFavorite,nBackgroundColor,image);
			}

			cursor.close();
			roomDB.close();

			return roomInfoData;
		}
		
		public static boolean isRoomAlarm(Context a_Context, String a_strRoomId)
		{
			boolean isAlarm = true;
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.openReadOnly();
			
			Cursor cursor = roomDB.getRoom(a_strRoomId);
			if (cursor.moveToFirst()) {
				isAlarm = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
			}

			cursor.close();
			
			roomDB.close();
			
			return isAlarm;
		}
		
		public static boolean isRoomFavorite(Context a_Context, String a_strRoomId)
		{
			boolean isAlarm = true;
			RoomDBAdapter roomDB = new RoomDBAdapter(a_Context);
			roomDB.openReadOnly();
			
			Cursor cursor = roomDB.getRoom(a_strRoomId);
			if (cursor.moveToFirst()) {
				isAlarm = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISFAVORITE)) == 1 ? true : false;
			}

			cursor.close();
			
			roomDB.close();
			
			return isAlarm;
		}
	}
	
	public static class SNSGroupDBManager 
	{		
		public static int insertMyGroupInfo(Context a_Context, int a_nGroupId) 
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nRowId = snsGroupDB.insertSNSMyGroupInfo(a_nGroupId);
			snsGroupDB.close();

			return nRowId;
		}
		
		public static int insertMyGroupInfo(Context a_Context, ArrayList<SNSGroupData> a_arrGroupId) 
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nRowId = snsGroupDB.insertSNSMyGroupInfo(a_arrGroupId);
			snsGroupDB.close();

			return nRowId;
		}
		
		public static int insertSNSAlarm(Context a_Context, ArrayList<SNSAlarmData> a_arrData)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.insertSNSAlarm(a_arrData);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int insertSNSAlarm(Context a_Context, SNSAlarmData a_Data)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.insertSNSAlarm(a_Data);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSAlarmGroupName(Context a_Context, ArrayList<SNSGroupData> a_arrSNSGroupData)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateAlarmSNSGroupName(a_arrSNSGroupData);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSAlarmIsDelete(Context a_Context, int a_nIdx, boolean a_isDelete)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateSNSAlarmIsDelete(a_nIdx, a_isDelete);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSMyGroupInfoFavorite(Context a_Context, int a_nGroupId, boolean a_isFavorite)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsFavorite(a_nGroupId, a_isFavorite);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSIsAlarmRead(Context a_Context, boolean a_isRead)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsAlarmRead(a_isRead);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSIsAlarmRead(Context a_Context, SparseArray<Boolean> a_arrIsRead)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsAlarmRead(a_arrIsRead);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSIsAlarmRead(Context a_Context, int a_nIdx, boolean a_isRead)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsAlarmRead(a_nIdx, a_isRead);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSIsBoardRead(Context a_Context, int a_nGroupId, SparseBooleanArray a_arrIsRead)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsBoardRead(a_nGroupId, a_arrIsRead);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSIsBoardRead(Context a_Context, int a_nGroupId, int a_nBoardId, boolean a_isRead)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsBoardRead(a_nGroupId, a_nBoardId, a_isRead);
			snsGroupDB.close();
			
			return nCount;
		}
		
		
		public static int updateSNSIsBoardRead(Context a_Context, int a_nIdx, boolean a_isRead)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateIsBoardRead(a_nIdx, a_isRead);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int updateSNSReadBoardAndReply(Context a_Context, ArrayList<Integer> a_arrReadBoardAndReply)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.updateReadBoardAndReply(a_arrReadBoardAndReply);
			snsGroupDB.close();
			
			return nCount;
		}
		
		public static int deleteSNSMyGroupInfo(Context a_Context) 
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSMyGroupInfo();
			snsGroupDB.close();

			return nCount;
		}

		public static int deleteSNSMyGroupInfo(Context a_Context, int a_nGroupId) 
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSMyGroupInfo(a_nGroupId);
			snsGroupDB.close();

			return nCount;
		}
		
		public static int deleteSNSAlarm(Context a_Context) 
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSAlarm();
			snsGroupDB.close();

			return nCount;
		}
		
		public static int deleteSNSAlarm(Context a_Context, int a_nIdx)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSAlarm(a_nIdx);
			snsGroupDB.close();

			return nCount;
		}
		
		public static int deleteSNSAlarmBefore2Week(Context a_Context)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSAlarmBefore2Week();
			snsGroupDB.close();

			return nCount;
		}
		
		public static int deleteSNSAlarmPushType(Context a_Context)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSAlarmPushType();
			snsGroupDB.close();

			return nCount;
		}
		
		public static int deleteSNSAlarmWhereBoardId(Context a_Context, int a_nBoardId)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSAlarmWhereBoardId(a_nBoardId);
			snsGroupDB.close();

			return nCount;
		}
		
		public static int deleteSNSAlarmWhereGroupId(Context a_Context, int a_nGroupId)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.open();
			int nCount = snsGroupDB.deleteSNSAlarmWhereGroupId(a_nGroupId);
			snsGroupDB.close();

			return nCount;
		}
		
		public static SparseBooleanArray getMyGroupInfo(Context a_Context) {
			SparseBooleanArray arrMyGroup = new SparseBooleanArray();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getSNSMyGroupInfo();
			if (cursor.moveToFirst()) {
				do {
					
					int nGroupId = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSMYGROUPINFO_GROUPID));
					int nFavorite = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSMYGROUPINFO_ISFAVORITE));
					if(nFavorite == 0)
						arrMyGroup.put(nGroupId, false);
					else
						arrMyGroup.put(nGroupId, true);

				} while (cursor.moveToNext());
			}

			cursor.close();
			snsGroupDB.close();
			return arrMyGroup;
		}

		public static SparseBooleanArray getFavoriteGroup(Context a_Context) {
			SparseBooleanArray arrFavotiteGroupId = new SparseBooleanArray();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getSNSMyGroupInfoFavorite();
			if (cursor.moveToFirst()) {
				do {
					
					int nGroupId = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSMYGROUPINFO_GROUPID));
					arrFavotiteGroupId.put(nGroupId, true);

				} while (cursor.moveToNext());
			}

			cursor.close();
			snsGroupDB.close();
			return arrFavotiteGroupId;
		}
		
		public static ArrayList<SNSAlarmData> getSNSAlarm(Context a_Context) {
			ArrayList<SNSAlarmData> arrSNSAlarmData = new ArrayList<SNSAlarmData>();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getSNSAlarm();
			if (cursor.moveToFirst()) {
				do {
					SNSAlarmData data = new SNSAlarmData();
					
					data.m_nIdx = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_IDX));
					data.m_nGroupId = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_GROUPID));
					data.m_nBoardNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDNO));
					data.m_nUserNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_USERNO));
					data.m_nReplyNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_REPLYNO));
					data.m_strUserImagerUrl = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDUSERIMAGEURL));
					data.m_strType = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_TYPE));
					data.m_strCreateDate = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_CREATEDDATE));
					data.m_strUpdateDate = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_UPDATEDDATE));
					data.m_isAlarmRead = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_ISALARMREAD)) == 1 ? true : false;
					data.m_isBoardRead = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_ISBOARDREAD)) == 1 ? true : false;
					data.m_strComment = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_COMMENT));
					data.m_strMsg = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_MSG));
					data.m_strGroupName = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_GROUPNAME));
					
					arrSNSAlarmData.add(data);

				} while (cursor.moveToNext());
			}

			cursor.close();
			snsGroupDB.close();

			return arrSNSAlarmData;
		}
		
		public static ArrayList<SNSAlarmData> getSNSAlarmWhereNoDelete(Context a_Context) {
			ArrayList<SNSAlarmData> arrSNSAlarmData = new ArrayList<SNSAlarmData>();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getSNSAlarmWhereNoDelete();
			if (cursor.moveToFirst()) {
				do {
					SNSAlarmData data = new SNSAlarmData();
					
					data.m_nIdx = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_IDX));
					data.m_nGroupId = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_GROUPID));
					data.m_nBoardNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDNO));
					data.m_nUserNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_USERNO));
					data.m_nReplyNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_REPLYNO));
					data.m_strUserImagerUrl = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDUSERIMAGEURL));
					data.m_strType = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_TYPE));
					data.m_strCreateDate = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_CREATEDDATE));
					data.m_strUpdateDate = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_UPDATEDDATE));
					data.m_isAlarmRead = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_ISALARMREAD)) == 1 ? true : false;
					data.m_isBoardRead = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_ISBOARDREAD)) == 1 ? true : false;
					data.m_strComment = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_COMMENT));
					data.m_strMsg = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_MSG));
					data.m_strGroupName = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_GROUPNAME));
					
					arrSNSAlarmData.add(data);

				} while (cursor.moveToNext());
			}

			cursor.close();
			snsGroupDB.close();

			return arrSNSAlarmData;
		}
		
		public static ArrayList<Integer> getSNSAlarmWhereNoBoardRead(Context a_Context, int a_nGroupId) {
			ArrayList<Integer> arrSNSNoBoardReadIdx = new ArrayList<Integer>();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getSNSAlarmWhereNoBoardRead(a_nGroupId);
			if (cursor.moveToFirst()) {
				do {
					int nBoardNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDNO));
					arrSNSNoBoardReadIdx.add(nBoardNo);
				} while (cursor.moveToNext());
			}

			cursor.close();
			
			Cursor cursor2 = snsGroupDB.getSNSAlarmWhereNoBoardReadReply(a_nGroupId);
			if (cursor2.moveToFirst()) {
				do {
					int nBoardNo = cursor2.getInt(cursor2.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDNO));
					int nReplyNo = cursor2.getInt(cursor2.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_REPLYNO));
					if(!arrSNSNoBoardReadIdx.contains(nBoardNo))
						arrSNSNoBoardReadIdx.add(nBoardNo);
					arrSNSNoBoardReadIdx.add(nReplyNo);
				} while (cursor2.moveToNext());
			}

			cursor2.close();
			snsGroupDB.close();

			return arrSNSNoBoardReadIdx;
		}
		
		public static ArrayList<Integer> getSNSAlarmWhereNoReplyRead(Context a_Context, int a_nGroupId, int a_nBoardId) {
			ArrayList<Integer> arrSNSNoBoardReadIdx = new ArrayList<Integer>();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getSNSAlarmWhereNoReplyRead(a_nGroupId, a_nBoardId);
			if (cursor.moveToFirst()) {
				do {
					int nBoardNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_REPLYNO));
					arrSNSNoBoardReadIdx.add(nBoardNo);
				} while (cursor.moveToNext());
			}

			cursor.close();
			snsGroupDB.close();

			return arrSNSNoBoardReadIdx;
		}
		
		public static String getLastAlarmUpdatedDate(Context a_Context, int a_nGroupId)
		{
			String strUpdatedDate = "0";
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getLastAlarm(a_nGroupId);
			if (cursor.moveToFirst()) 
			{
				strUpdatedDate = cursor.getString(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_UPDATEDDATE));
			}

			cursor.close();
			snsGroupDB.close();
			
			return strUpdatedDate;
		}
		
		public static int getNoAlarmReadCount(Context a_Context)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			int nCount = snsGroupDB.getNoAlarmReadCount();
			snsGroupDB.close();
			return nCount;
		}
		
		public static int getNoBoardReadCount(Context a_Context)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			int nCount = snsGroupDB.getNoBoardReadCount();
			snsGroupDB.close();
			return nCount;
		}
		
		public static int getNoBoardReadCountWhereGroupId(Context a_Context, int a_nGroupId)
		{
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			int nCount = snsGroupDB.getNoBoardReadCountWhereGroupId(a_nGroupId);
			snsGroupDB.close();
			return nCount;
		}
		
		public static ArrayList<String> getUnReadBoardAndReplyNos(Context a_Context)
		{
			ArrayList<String> arrUnReadBoardAndReplyNos = new ArrayList<String>();
			SNSGroupDBAdapter snsGroupDB = new SNSGroupDBAdapter(a_Context);
			snsGroupDB.openReadOnly();
			Cursor cursor = snsGroupDB.getUnReadBoardAndReplyNos();
			if (cursor.moveToFirst()) 
			{
				do{
					int nReplyNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_REPLYNO));
					if(nReplyNo > 0)
						arrUnReadBoardAndReplyNos.add("" + nReplyNo);
					else
					{
					int nBoardNo = cursor.getInt(cursor.getColumnIndex(SNSGroupDBAdapter.KEY_SNSALARM_BOARDNO));
					arrUnReadBoardAndReplyNos.add("" + nBoardNo);
					}
				} while(cursor.moveToNext());
			}

			cursor.close();
			snsGroupDB.close();
			
			return arrUnReadBoardAndReplyNos;
		}
	}
}
