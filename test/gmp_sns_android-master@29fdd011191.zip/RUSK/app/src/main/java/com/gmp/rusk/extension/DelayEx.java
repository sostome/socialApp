package com.gmp.rusk.extension;

import java.sql.Timestamp;

import org.jivesoftware.smack.packet.PacketExtension;

public class DelayEx implements PacketExtension{
		public static final String NAMESPACE = "urn:xmpp:delay";
		public static final String ELEMENT_NAME = "delay";
		
		private String type;
		private String stamp;
		private String idx;
		//private boolean isGroup;
		
		public DelayEx(){}
		public DelayEx(String type,String idx){
			this.type = type;
			this.idx = idx;
		}

		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}
		
		public String getType(){
			return type;
		}
		
		public Timestamp getStamp(){
			Timestamp timestamp = Timestamp.valueOf(stamp);
			return timestamp;
		}

		public String getIdx(){
			return idx;
		}
		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();
			// 1.5.5 에서 규격 수정됨
//			if(isGroup){
//				buf.append("<query xmlns='").append(MultiChatMsgEx.NAMESPACE).append("'/>");
//			}
//			buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
			return buf.toString();
		}
		
//		public static class Provider implements PacketExtensionProvider {
//
//			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
//	            String type = null;
//	            String stamp = null;
//	            String idx = null;
//				boolean done = false;
//				int cnt = parser.getAttributeCount();
//				for(int i = 0; i < cnt; i++){
//					if(parser.getAttributeName(i).equals("type")){
//						type = parser.getAttributeValue(i);		
//					}
//					else if(parser.getAttributeName(i).equals("stamp")){
//						stamp = parser.getAttributeValue(i);
//					}
//					else if(parser.getAttributeName(i).equals("idx")){
//						idx = parser.getAttributeValue(i);
//					}
//				}
////				while(!done){
////					int eventType = parser.next();					
////					if (eventType == XmlPullParser.START_TAG) {
////		                if (parser.getName().equals("type")) {
////		                	type = parser.nextText();
////		                }
////		                else if(parser.getName().equals("stamp")){
////							stamp = parser.nextText();
////						}
////		            }
////		            else if (eventType == XmlPullParser.END_TAG) {
////		                if (parser.getName().equals(ELEMENT_NAME)) {
////		                    done = true;
////		                }
////		            }
////				}
//				return new DelayEx(type, stamp, idx);
//			}
//		}
	}