package com.gmp.rusk.request;

import java.util.ArrayList;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author dym
 *			모임 멤버 설정
 *			method : put
 */

public class PutGroupUserReq extends Req{
	
	private String APINAME = "group";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";
	
	private final String JSON_MEMBERED		= "membered";
	
	private String m_strMembered = null;
	
	public PutGroupUserReq(int a_nGroupId, int a_nUserNo, String a_strMembered)
	{
		APINAME = APINAME +"/" + a_nGroupId + "/user/" + a_nUserNo;
		
		m_strMembered = a_strMembered;
	}
	
	public PutGroupUserReq(int a_nGroupId, ArrayList<Integer> a_arrUserNo, String a_strMembered)
	{
		String strUserNo = "";
		int nUserNoSize = a_arrUserNo.size();
		for(int i = 0; i < nUserNoSize; i++)
		{
			strUserNo += a_arrUserNo.get(i);
			
			if(i < nUserNoSize - 1)
				strUserNo += ",";
		}
		
		APINAME = APINAME +"/" + a_nGroupId + "/user/" + strUserNo;
		
		m_strMembered = a_strMembered;
	}
	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_MEMBERED, m_strMembered);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PutGroupUserReq.class.getSimpleName(), "" + e.getMessage());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
