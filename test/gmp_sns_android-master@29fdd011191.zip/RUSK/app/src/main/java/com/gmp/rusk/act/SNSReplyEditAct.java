package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteReplyImageReq;
import com.gmp.rusk.request.PostGroupBoardReplyFileUploadReq;
import com.gmp.rusk.request.PutGroupReplyReq;
import com.gmp.rusk.request.Req;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.ScaleImage;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SNSReplyEditAct extends CustomActivity implements OnClickListener{

	private int m_nGroupId = -1;
	private int m_nBoardId = -1;
	private int m_nReplyNo = -1;
	private String m_strBodyText = "";
	//private String m_strImageUrl = "";

	private TakeMediaIntent m_TakeMedia = null;
	private SNSBoardFileData m_snsFileData;

	//수정 할때, 원래 이미지가 있었는지 여부
	private boolean m_isHasImage = false;
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_snsreplyedit);
		
		getIntentData();
		
		initUI();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		/*if(requestCode == TakeMediaIntent.REQUESTCODE_ALBUM){
			if(resultCode == Activity.RESULT_OK){
				SelectImageProcessTask task = new SelectImageProcessTask();
				task.execute(data);
			} else {
				m_TakeMedia = null;
			}
		}*/
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void getIntentData()
	{
		//무조건 이전 댓글에 대한 정보가 있어야함 
		//없다면 수정 불가?!
		//댓글은 특성상 무조건 자기가 작성한 글만 수정이 가능하므로 가능 여부 판별할 필요가 없다.

		m_nBoardId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_BOARDID, -1);
		m_nGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_GROUPID, -1);
		m_nReplyNo = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, -1); 
		
		m_strBodyText = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT);
		//m_strImageUrl = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_IMAGEURL);
		/*if(!m_strImageUrl.equals(""))
			m_isHasImage = true;*/
	}
	
	private void initUI()
	{
		TextView tvTitle = (TextView)findViewById(R.id.tv_snsreplyedit_title);
		tvTitle.setText(R.string.snsreplyedit_title);
		ImageView ivTopClose = (ImageView)findViewById(R.id.iv_top_close);
		ivTopClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		EditText etComment = (EditText)findViewById(R.id.et_snsreplyedit_comment);
	/*	final ImageView ivImage = (ImageView)findViewById(R.id.iv_snsreplyedit_image);*/
		etComment.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				String strText = s.toString();
				if(m_snsFileData != null || strText.trim().length() > 0)
				{
					if(!m_strBodyText.equals(strText))
						setSaveButtonEnable(true);
					else
						setSaveButtonEnable(false);
				}
				else
				{
					setSaveButtonEnable(false);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				ArrayList<int[]> spans = new ArrayList<int[]>();

				char prefix = '#';
				Pattern pattern = Pattern.compile(prefix + "[^\\r\\n\\t\\f #]{1,10}");
				Matcher matcher = pattern.matcher(s);

				// Check all occurrences
				while (matcher.find()) {
					int[] currentSpan = new int[2];
					currentSpan[0] = matcher.start();
					currentSpan[1] = matcher.end();
					spans.add(currentSpan);
				}
				for (int i = 0; i < spans.size(); i++) {
					int[] span = spans.get(i);
					int hashTagStart = span[0];
					int hashTagEnd = span[1];

					s.setSpan(new ForegroundColorSpan(Color.parseColor("#48abb7")),
							hashTagStart,
							hashTagEnd, 0);

				}
			}
		});
		SharedPref pref = SharedPref.getInstance(SNSReplyEditAct.this);
		int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			etComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			etComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18.2f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			etComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 22.4f);
		}
		etComment.setText(m_strBodyText);//intent로 넘겨 받은 글 내용을 EditText에 뿌려준다.
		etComment.setSelection(etComment.length());

		/*ImageLoaderManager imageLoaderAddMng = ImageLoaderManager.getInstance(SNSReplyEditAct.this);
		imageLoaderAddMng.cancelDownload(ivImage);
		imageLoaderAddMng.getProfileImage(ivImage, m_strImageUrl, R.drawable.file_img, false);

		ivImage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(!m_strImageUrl.equals("")){
					CommonPopup m_Popup = new CommonPopup(SNSReplyEditAct.this, new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							int nId = v.getId();
							if(nId == R.id.ib_pop_ok)
							{
								ivImage.setImageResource(R.drawable.file_img);
								m_strImageUrl = "";
							}
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_reply_image_delete_title), getString(R.string.popup_reply_image_delete_msg));
					m_Popup.setCancelable(false);
					m_Popup.show();

				} else {
					m_TakeMedia = new TakeMediaIntent(SNSReplyEditAct.this);
					m_TakeMedia.doGetMultiSelectImageFromGallery(GalleryMultiselectorListAct.FROMACTIVITY_SNS_REPLY, 1, 104857600L);
				}
			}
		});*/

		ImageView btnSave = (ImageView)findViewById(R.id.iv_snsreplyedit_save);
		btnSave.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.iv_snsreplyedit_save)
		{
			saveBoard();
		}

		super.onClick(v);
	}
	
	private void setSaveButtonEnable(boolean a_isEnable)
	{
		ImageView btnSave = (ImageView)findViewById(R.id.iv_snsreplyedit_save);
		btnSave.setEnabled(a_isEnable);
		if(a_isEnable)
			btnSave.setImageResource(R.drawable.btn_btn_top_ok);
		else
			btnSave.setImageResource(R.drawable.btn_top_ok_disabled);
	}
	
	private void saveBoard()
	{
		EditText etComment = (EditText)findViewById(R.id.et_snsreplyedit_comment);
		final String strComment = etComment.getText().toString();
		if(m_snsFileData == null && (strComment == null || strComment.trim().equals("")))
			return;
		
		Req req;
		
		req = new PutGroupReplyReq(m_nBoardId, m_nReplyNo, m_nGroupId, strComment);

		
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				/*if(m_strImageUrl.equals("") && m_snsFileData == null && !m_isHasImage) {
					closeProgress();
					Intent intent = new Intent();
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, strComment);
					setResult(RESULT_OK, intent);
					finish();
				} else if(m_strImageUrl.equals("") && m_snsFileData == null && m_isHasImage){
					deleteImage(m_nGroupId, m_nBoardId, m_nReplyNo, strComment);
				}
				else if(!m_strImageUrl.equals("") && m_snsFileData == null && m_isHasImage){
					closeProgress();
					Intent intent = new Intent();
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, strComment);
					setResult(RESULT_OK, intent);
					finish();
				}
				 else {
					uploadImage(m_nGroupId, m_nBoardId, m_nReplyNo, strComment);
				}*/
				closeProgress();
				Intent intent = new Intent();
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, strComment);
				setResult(RESULT_OK, intent);
				finish();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				//Toast.makeText(SNSReplyEditAct.this, "Reply Edit Save Fail : " + strMessage, Toast.LENGTH_SHORT).show();
				closeProgress();
				showErrorPopup(nErrorCode, strMessage);
			}
		});
		
	}

	private void uploadImage(int a_nGroupId, int a_nBoardNo, int a_nReplyNo, final String a_strCommnet){
		PostGroupBoardReplyFileUploadReq req = new PostGroupBoardReplyFileUploadReq(a_nGroupId, a_nBoardNo, a_nReplyNo);
		req.addImageFileInfo(this, m_snsFileData.m_strFileURL);
		WebAPI api = new WebAPI(this);
		api.requestUpload(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {

				closeProgress();
				Intent intent = new Intent();
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, a_strCommnet);
				setResult(RESULT_OK, intent);
				finish();
			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
				Intent intent = new Intent();
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, a_strCommnet);
				setResult(RESULT_OK, intent);
				finish();
			}
		});
	}

	private void deleteImage(int a_nGroupId, int a_nBoardNo, int a_nReplyNo, final String a_strCommnet){
		DeleteReplyImageReq req = new DeleteReplyImageReq(a_nGroupId, a_nBoardNo, a_nReplyNo);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {

				closeProgress();
				Intent intent = new Intent();
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, a_strCommnet);
				setResult(RESULT_OK, intent);
				finish();
			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
				Intent intent = new Intent();
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, m_nReplyNo);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, a_strCommnet);
				setResult(RESULT_OK, intent);
				finish();
			}
		});
	}
	/*private class SelectImageProcessTask extends AsyncTask<Intent, Void, Boolean>
	{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			showProgress();
			super.onPreExecute();
		}

		@Override
		protected Boolean doInBackground(Intent... params) {
			// TODO Auto-generated method stub
			Intent data = params[0];
			Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
			ArrayList<GalleryListData> arrAttachImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);

			if(arrAttachImage != null && arrAttachImage.size() > 0)
			{
				String strScaleSaveDirectory = Environment.getExternalStorageDirectory() + getString(R.string.takepicture_save_directory);
				for(GalleryListData galleryListData : arrAttachImage)
				{
					//여러개 업로드 될 가능성을 위해 for문으로 처리 하고 있으나,
					//현재는 1개만 올라가는 시나리오 임
					String strImagePath = galleryListData.getSdcardPath();
					ScaleImage scaleImage = new ScaleImage();
					scaleImage.scaleImage(strImagePath, strScaleSaveDirectory);

					m_snsFileData = new SNSBoardFileData();
					m_snsFileData.m_strFileType = StaticString.FILE_TYPE_IMAGE;
					m_snsFileData.m_strFileURL = scaleImage.getSavedScaleImagePath();
					m_snsFileData.m_lnFileSize = scaleImage.getSavedScaleImageSize();
					//m_arrAttachMedia.add(snsFileData);
					break;
				}
				return true;
			}
			else
				return false;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			//setAttachFileUI();

			*//*final ImageView ivImage = (ImageView)findViewById(R.id.iv_snsreplyedit_image);
			Bitmap bm = BitmapFactory.decodeFile(m_snsFileData.m_strFileURL);
			Bitmap thumb = Utils.makeThumbnail(bm, 250, 250);
			ivImage.setImageBitmap(thumb);*//*

			setSaveButtonEnable(true);

			m_strImageUrl = m_snsFileData.m_strFileURL;
			closeProgress();
			super.onPostExecute(result);
		}
	}*/
}
