package com.gmp.rusk.datamodel;

public class ApprovalListData {
	public int m_nUserNo = 0;					//사용자 번호
	public String m_strName = "";				//사용자 이름
	public String m_strCharge = "";			//직책, 일반 매니저의 경우에는 내려주지 않음
	public String m_strDepartment = "";		//부서명
	public String m_strParentDepartment = "";	//소속명
	public boolean m_isImageAvailable = false;	//이미지 보유 여부
	public boolean m_isAvailable = false;		//승인 가능 여부
	
	public ApprovalListData(int a_nUserNo, String a_strName, String a_strCharge, String a_strDepartment, String a_strParentDepartment, boolean a_isImageAvailable, boolean a_isAvailable) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCharge = a_strCharge;
		m_strDepartment = a_strDepartment;
		m_strParentDepartment = a_strParentDepartment;
		m_isImageAvailable = a_isImageAvailable;
		m_isAvailable = a_isAvailable;
	}
}
