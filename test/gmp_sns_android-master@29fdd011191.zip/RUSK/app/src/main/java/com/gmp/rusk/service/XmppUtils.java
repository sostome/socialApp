package com.gmp.rusk.service;

import com.gmp.rusk.utils.StaticString;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by K on 2017-09-16.
 */

public class XmppUtils {

    public String strFileName = "";
    public String strMimeType = "";
    public String strUrl = "";
    public String strWidth = "0";
    public String strHeight = "0";
    public String strThumb = "";
    public String strDocId = "";
    public String strCreateTime = "0";
    public String strVdi = "false";
    public String strValidUntil = "";

    //연락처를 전송 할때는 파일 이름에 연락처대상의 이름을 저장하는데,
    //전송 실패시 재전송을 할 경우에는 위 정보만 가지고는 전달이 불가능 함
    //그래서 연락처의 경우에만 따로 아래 값을 사용한다.
    public String strContactFileName = "";


    public String getFileExText(){

        JSONObject jsonFileText = new JSONObject();

        try {
            jsonFileText.put(StaticString.XMPP_TEXT_FILENAME, strFileName);
            jsonFileText.put(StaticString.XMPP_TEXT_MIMEYPE, strMimeType);
            jsonFileText.put(StaticString.XMPP_TEXT_URL, strUrl);
            jsonFileText.put(StaticString.XMPP_TEXT_WIDTH, strWidth);
            jsonFileText.put(StaticString.XMPP_TEXT_HEIGHT, strHeight);
            jsonFileText.put(StaticString.XMPP_TEXT_THUMB, strThumb);
            jsonFileText.put(StaticString.XMPP_TEXT_DOCID, strDocId);
            jsonFileText.put(StaticString.XMPP_TEXT_CREATETIME, strCreateTime);
            jsonFileText.put(StaticString.XMPP_TEXT_VDI, strVdi);
            jsonFileText.put(StaticString.XMPP_TEXT_VALIDUNTIL, strValidUntil);
            jsonFileText.put(StaticString.XMPP_TEXT_CONTACTFILENAME, strContactFileName);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String strFileExText = jsonFileText.toString();
        return strFileExText;
    }

    public JSONObject getFileExObject(){
        JSONObject jsonFile = new JSONObject();

        try {
            jsonFile.put(StaticString.XMPP_TEXT_FILENAME, strFileName);
            jsonFile.put(StaticString.XMPP_TEXT_MIMEYPE, strMimeType);
            jsonFile.put(StaticString.XMPP_TEXT_URL, strUrl);
            jsonFile.put(StaticString.XMPP_TEXT_WIDTH, strWidth);
            jsonFile.put(StaticString.XMPP_TEXT_HEIGHT, strHeight);
            jsonFile.put(StaticString.XMPP_TEXT_THUMB, strThumb);
            jsonFile.put(StaticString.XMPP_TEXT_DOCID, strDocId);
            jsonFile.put(StaticString.XMPP_TEXT_CREATETIME, strCreateTime);
            jsonFile.put(StaticString.XMPP_TEXT_VDI, strVdi);
            jsonFile.put(StaticString.XMPP_TEXT_VALIDUNTIL, strValidUntil);
            jsonFile.put(StaticString.XMPP_TEXT_CONTACTFILENAME, strContactFileName);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonFile;
    }

}
