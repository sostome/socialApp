package com.gmp.rusk.layout;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;


import com.gmp.rusk.R;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomFragmentActivity;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.fragment.MainFellowListFlag;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteDelBuddysReq;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import me.thanel.swipeactionview.SwipeActionView;
import me.thanel.swipeactionview.SwipeGestureListener;

/**
 * FellowListItemLayout
 * 동료 리스트 Item Layout
 */
public class FellowListItemLayout extends CustomLinearLayout implements OnClickListener{
	
	private Context m_Context;
	
	private FellowListData m_FellowListData = null;

	private CommonPopup m_Popup;

	OnFellowDeleteByListener m_FellowDeleteByListener;
	
	public FellowListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public FellowListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context a_Context)
	{
		m_Context = a_Context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listitem_fellow_main, this);
	}
	
	public void setFellowListData(FellowListData a_Data)
	{
		m_FellowListData = a_Data;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		ImageView iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
		if(m_FellowListData !=null) {

			if (m_FellowListData.m_isImageAvailable) {
				App.imageloader.cancelDownload(iv_profile_pic);
				App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_FellowListData.m_nUserNo, true), R.drawable.profile_pic_default, false);
			} else {
				App.imageloader.cancelDownload(iv_profile_pic);
				iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
			}
			SwipeActionView layoutFellowSwipe = (SwipeActionView)findViewById(R.id.layout_fellow_swipe);
			layoutFellowSwipe.setSwipeGestureListener(new SwipeGestureListener() {
				@Override
				public boolean onSwipedLeft(@NotNull SwipeActionView swipeActionView) {
					m_FellowDeleteByListener.setSwipeView(swipeActionView);
					return false;
				}

				@Override
				public boolean onSwipedRight(@NotNull SwipeActionView swipeActionView) {
					m_FellowDeleteByListener.setSwipeView(swipeActionView);
					return false;
				}
			});
			LinearLayout layoutFellowDelete = (LinearLayout)findViewById(R.id.layout_sidemenu_fellowdelete);
			layoutFellowDelete.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					DeleteDelBuddysReq req = new DeleteDelBuddysReq(m_FellowListData.m_nUserNo);
					WebAPI webApi = new WebAPI(getContext());
					webApi.request(req, new WebListener() {
						@Override
						public void onPreRequest() {

						}

						@Override
						public void onNetworkError(int nErrorCode, String strMessage) {

						}

						@Override
						public void onPostRequest(String a_strData) {
							m_Popup = new CommonPopup(m_Context, FellowListItemLayout.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
							m_Popup.setBodyAndTitleText(
									m_Context.getString(R.string.pop_fellowdelete_title),
									m_Context.getString(R.string.pop_fellowdelete_text));
							m_Popup.setCancelable(false);
							m_Popup.show();


						}
					});
				}
			});
			ImageView ivPartnerIcon = (ImageView)findViewById(R.id.iv_partner_mark);
			if(m_FellowListData.m_strUserType.equals(StaticString.VARIANT_REGULAR)){
				ivPartnerIcon.setVisibility(GONE);
			} else {
				ivPartnerIcon.setVisibility(VISIBLE);
			}
			TextView tv_name = (TextView) findViewById(R.id.tv_name);
			LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
			TextView tv_position = (TextView) findViewById(R.id.tv_position);
			LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
			TextView tv_charge = (TextView) findViewById(R.id.tv_charge);
			TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
			tv_name.setText(m_FellowListData.m_strName);
			if(m_FellowListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_FellowListData.m_strPosition!=null && !m_FellowListData.m_strPosition.equals("")){
				layout_position.setVisibility(VISIBLE);
				tv_position.setText(m_FellowListData.m_strPosition);
			} else {
				layout_position.setVisibility(GONE);
			}

			if(m_FellowListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_FellowListData.m_strCharge!=null && !m_FellowListData.m_strCharge.equals("")){
				layout_charge.setVisibility(VISIBLE);
				tv_charge.setText(m_FellowListData.m_strCharge);
			} else {
				layout_charge.setVisibility(GONE);
			}

			if (m_FellowListData.m_isActive) {
				tv_uninstall.setVisibility(GONE);
			} else {
				tv_uninstall.setVisibility(VISIBLE);
			}

			TextView tv_departments = (TextView) findViewById(R.id.tv_departments);

			if (m_FellowListData.m_strUserType.equals(StaticString.VARIANT_REGULAR)) {
				tv_departments.setText(m_FellowListData.m_strDepartment+" | "+m_FellowListData.m_strCompany);
			} else {
				tv_departments.setText(m_FellowListData.m_strAffiliation);
			}

			RelativeLayout layout_listitem_search = (RelativeLayout) findViewById(R.id.layout_listitem_fellow);
			layout_listitem_search.setOnClickListener(this);
		}
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==R.id.layout_listitem_fellow)
		{
			doShowProfile();
		}
		else if(v.getId()==R.id.ib_pop_ok){
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			popup_ok.cancel();
			for(int i=0; i<App.m_arrFellowListData.size();i++)
			{
				if(m_FellowListData.m_nUserNo == App.m_arrFellowListData.get(i).m_nUserNo)
				{
					App.m_arrFellowListData.remove(i);
					TTalkDBManager.ContactsDBManager.updateContactsIsFellow(getContext(), m_FellowListData.m_nUserNo, false);
					break;
				}
			}
			ArrayList<String> arrDeleteNo = new ArrayList<String>();
			arrDeleteNo.add("" + m_FellowListData.m_nUserNo);
			((CustomFragmentActivity)m_Context).mService.delBuddy(arrDeleteNo);

			m_Popup = new CommonPopup(m_Context, FellowListItemLayout.this,
					CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(
					m_Context.getString(R.string.pop_fellowdelete_title),
					m_Context.getString(R.string.pop_fellowdelete_complete_text));
			m_Popup.setCancelable(false);
			m_Popup.show();
		} else if(v.getId()==R.id.ib_pop_cancel){
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		} else if(v.getId()==R.id.ib_pop_ok_long){
			CommonPopup popup_long = (CommonPopup)v.getTag();
			popup_long.cancel();
			m_FellowDeleteByListener.onNotifyChageList();
		}
	}
	
	private void doShowProfile()
	{
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_FellowListData.m_nUserNo);
		m_Context.startActivity(intent);
	}

	public void setFellowDeleteByListener(OnFellowDeleteByListener a_Listener){
		m_FellowDeleteByListener = a_Listener;
	}
	public interface OnFellowDeleteByListener {
		public void onNotifyChageList();
		public void setSwipeView(SwipeActionView swipeActionView);
	}
}
