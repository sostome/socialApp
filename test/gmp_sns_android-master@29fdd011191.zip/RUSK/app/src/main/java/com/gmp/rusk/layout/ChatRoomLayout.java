package com.gmp.rusk.layout;

import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

import android.content.Context;
import android.view.LayoutInflater;

public class ChatRoomLayout extends CustomLinearLayout{
	
	private ChatRoomSystemLayout m_layoutSystem = null;
	private ChatRoomOtherMSGLayout m_layoutOtherMsg  = null;
	private ChatRoomTINIMSGLayout m_layoutTiniMsg = null;
	private ChatRoomMyMSGLayout m_layoutMyMsg = null;
	private ChatRoomMyImageLayout m_layoutMyImage = null;
	private ChatRoomOtherImageLayout m_layoutOtherImage = null;
	private ChatRoomOtherFileLayout m_layoutOtherFile = null;
	private ChatRoomMyFileLayout m_layoutMyFile = null;
	private ChatroomSNSNoticeLayout m_layoutSNSNotice = null;
	private ChatRoomMyEmotcionMsgLayout m_layoutMyEmotionMsg = null;
	private ChatRoomOtherEmoticonMsgLayout m_layoutOtherEmoticonMsg = null;
	private int m_nPosition = -1;

	private ChatRoomAct.TiniItemSelectListener m_tiniSelectListener;


	public ChatRoomLayout(Context a_Context)
	{
		super(a_Context);


		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
		li.inflate(R.layout.layout_chat_room_item, this, true);
	}
	public void setPosition(int nPosition){
		m_nPosition = nPosition;
	}
	
	public void setData(ChatRoomData a_ChatRoomData)
	{
		removeAllViews();
		
		if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_SYSTEM_MSG || a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_SYSTEM_MSG_DAY) 
		{
			if(m_layoutSystem == null)
				m_layoutSystem = new ChatRoomSystemLayout(getContext());

			m_layoutSystem.setChatRoomData(a_ChatRoomData);
			
			addView(m_layoutSystem);
		}
		else if(a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE){
			if(m_layoutMyEmotionMsg == null)
				m_layoutMyEmotionMsg = new ChatRoomMyEmotcionMsgLayout(getContext());

			/*m_layoutMyEmotionMsg.setPosition(m_nPosition);*/
			m_layoutMyEmotionMsg.setChatRoomData(a_ChatRoomData);

			addView(m_layoutMyEmotionMsg);
		}
		else if(a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){
			if(m_layoutOtherEmoticonMsg == null)
				m_layoutOtherEmoticonMsg = new ChatRoomOtherEmoticonMsgLayout(getContext());

			/*m_layoutOtherEmoticonMsg.setPosition(m_nPosition);*/
			m_layoutOtherEmoticonMsg.setChatRoomData(a_ChatRoomData);

			addView(m_layoutOtherEmoticonMsg);

		}
		else if(a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_SNS_NOTICE_MESSAGE){

			if(m_layoutSNSNotice == null)
				m_layoutSNSNotice = new ChatroomSNSNoticeLayout(getContext());

			m_layoutSNSNotice.setChatRoomData(a_ChatRoomData);
			addView(m_layoutSNSNotice);

		}
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_OTHER_MESSAGE)
		{
			if(m_layoutOtherMsg == null)
				m_layoutOtherMsg = new ChatRoomOtherMSGLayout(getContext());

		/*	m_layoutOtherMsg.setPosition(m_nPosition);*/
			m_layoutOtherMsg.setChatRoomData(a_ChatRoomData);

			addView(m_layoutOtherMsg);
		}
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_TINI_MESSAGE)
		{
			if(m_layoutTiniMsg == null)
				m_layoutTiniMsg = new ChatRoomTINIMSGLayout(getContext());

			m_layoutTiniMsg.setChatRoomData(a_ChatRoomData);
			if(m_tiniSelectListener !=null)
				m_layoutTiniMsg.setTiniSelectListener(m_tiniSelectListener);

			addView(m_layoutTiniMsg);
		}
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_MY_MESSAGE) 
		{
			if(m_layoutMyMsg == null)
				m_layoutMyMsg = new ChatRoomMyMSGLayout(getContext());

			/*m_layoutMyMsg.setPosition(m_nPosition);*/
			m_layoutMyMsg.setChatRoomData(a_ChatRoomData);
			
			addView(m_layoutMyMsg);
		} 
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_MY_IMAGE) 
		{
			if(m_layoutMyImage == null)
				m_layoutMyImage = new ChatRoomMyImageLayout(getContext());
			
			m_layoutMyImage.setChatRoomData(a_ChatRoomData);
			
			addView(m_layoutMyImage);
		} 
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_OTHER_IMAGE) 
		{
			if(m_layoutOtherImage == null)
				m_layoutOtherImage = new ChatRoomOtherImageLayout(getContext());
			
			m_layoutOtherImage.setChatRoomData(a_ChatRoomData);
			
			addView(m_layoutOtherImage);
		} 
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_OTHER_FILE) 
		{
			if(m_layoutOtherFile == null)
				m_layoutOtherFile = new ChatRoomOtherFileLayout(getContext());
			
			m_layoutOtherFile.setChatRoomData(a_ChatRoomData);
			addView(m_layoutOtherFile);
		} 
		else if (a_ChatRoomData.m_nType == StaticString.CHAT_ROOM_MY_FILE) 
		{
			if(m_layoutMyFile == null)
				m_layoutMyFile = new ChatRoomMyFileLayout(getContext());
			
			m_layoutMyFile.setChatRoomData(a_ChatRoomData);
			
			addView(m_layoutMyFile);
		}
	}
	public void setTiniSelectListener(ChatRoomAct.TiniItemSelectListener aTiniListener){
		m_tiniSelectListener = aTiniListener;
	}
}
