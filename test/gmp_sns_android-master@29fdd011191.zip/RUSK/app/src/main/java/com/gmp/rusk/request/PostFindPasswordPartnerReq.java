package com.gmp.rusk.request;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author kch
 *			파트너 비밀번호 찾기 요청
 *			method : post
 */

public class PostFindPasswordPartnerReq extends Req{
	
	private String APINAME = "partner";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "POST";

	private final String JSON_AUTHTOKEN = "authToken";

	private String m_strAuthToken = "";		//이메일로 전송받은 인증 토큰
		
	public PostFindPasswordPartnerReq(String a_strUserId, String a_strAuthToken)
	{
		APINAME = APINAME +"/find-password/"+a_strUserId+"/send";

		m_strAuthToken = a_strAuthToken;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_AUTHTOKEN, m_strAuthToken);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PostFindPasswordPartnerReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
