package com.gmp.rusk.request;

import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

/**
 *	@author kch
 *			모임 위치 변경
 *			method : put
 */

public class PutGroupPositionReq extends Req{

	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";

	private final String JSON_AFTER = "after";

	private int m_nAfter = -1;

	public PutGroupPositionReq(int a_nGroupId, int a_nAfter)
	{
		APINAME = APINAME +"/" + a_nGroupId + "/order";
		m_nAfter = a_nAfter;
	}

	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub

		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_AFTER, m_nAfter);

			return jsonObj.toString();
		} catch (Exception e) {
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
