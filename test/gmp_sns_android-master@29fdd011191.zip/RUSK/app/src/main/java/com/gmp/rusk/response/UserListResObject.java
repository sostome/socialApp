package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.UserListData;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface UserListResObject {

    public final String JSON_TIMESTAMP					= "timestamp";

    public void parseUserListdata();
    public ArrayList<UserListData> getUserListData();
}
