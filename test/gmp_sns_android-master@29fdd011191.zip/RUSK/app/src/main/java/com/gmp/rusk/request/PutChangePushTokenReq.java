package com.gmp.rusk.request;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

/**
 *	@author subi78
 *			Push 토큰 등록/변경
 *			method : put
 */

public class PutChangePushTokenReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";
	
	private final String JSON_PUSHTOKEN = "pushToken";
	private final String JSON_UPNSTOKEN = "upnsToken";
	private final String JSON_PUSHPREVIEW = "pushPreview";
	
	private String m_strPushToken = "";			// serviceKey
	private String m_strUPNSToken = "";
	private boolean m_isPushPreview = false;
		
	public PutChangePushTokenReq(int a_nUserNo, String a_strPushToken, String a_strUPNSToken, boolean a_isPushPreview)
	{
		APINAME = APINAME +"/"+a_nUserNo+"/push";

		m_strPushToken = a_strPushToken;
		m_strUPNSToken = a_strUPNSToken;
		m_isPushPreview = a_isPushPreview;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_PUSHTOKEN, m_strPushToken);
			jsonObj.put(JSON_UPNSTOKEN, m_strUPNSToken);
			jsonObj.put(JSON_PUSHPREVIEW, m_isPushPreview);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PutChangePushTokenReq", "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
