package com.gmp.rusk.customview;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CommonListPopup extends Dialog {
	
	public int m_nPrevAction = 10000;
	
	private int m_nHttpStatusCode = -1;
	
	TextView tv_pop_first_row;
	TextView tv_pop_second_row;
	TextView tv_pop_third_row;
	TextView tv_pop_fourth_row;
	
	public CommonListPopup(Context context, View.OnClickListener a_Listener) {
		super(context);
		// TODO Auto-generated constructor stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_dlg_custom_list);

		LinearLayout layout_one_btn = (LinearLayout)findViewById(R.id.layout_one_btn);
		layout_one_btn.setVisibility(View.VISIBLE);
		((ImageButton) findViewById(R.id.ib_pop_cancel_long)).setOnClickListener(a_Listener);
		tv_pop_first_row = (TextView)findViewById(R.id.tv_pop_first_row);
		tv_pop_first_row.setOnClickListener(a_Listener);
		
		tv_pop_second_row = (TextView)findViewById(R.id.tv_pop_second_row);
		tv_pop_second_row.setOnClickListener(a_Listener);
		
		tv_pop_third_row = (TextView)findViewById(R.id.tv_pop_third_row);
		tv_pop_third_row.setOnClickListener(a_Listener);
		
		tv_pop_fourth_row = (TextView)findViewById(R.id.tv_pop_fourth_row);
		tv_pop_fourth_row.setOnClickListener(a_Listener);
	}
	
	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		super.cancel();
	}
	
	@Override
	public void onDetachedFromWindow() {
		// 
		super.onDetachedFromWindow();
	}
	
	public void setBodyAndTitleText(String a_Title, String[] a_arrStringBody) {
		TextView tv_pop_title = (TextView) findViewById(R.id.tv_pop_title);
		tv_pop_title.setText(a_Title);
		
		if(a_arrStringBody.length == 1)
		{
			tv_pop_first_row.setVisibility(View.VISIBLE);
			tv_pop_first_row.setText(a_arrStringBody[0]);
		}
		else if(a_arrStringBody.length == 2)
		{
			tv_pop_first_row.setVisibility(View.VISIBLE);
			View v_line1 = (View)findViewById(R.id.v_line1);
			v_line1.setVisibility(View.VISIBLE);
			tv_pop_second_row.setVisibility(View.VISIBLE);
			
			tv_pop_first_row.setText(a_arrStringBody[0]);
			tv_pop_second_row.setText(a_arrStringBody[1]);
		}
		else if(a_arrStringBody.length == 3)
		{
			tv_pop_first_row.setVisibility(View.VISIBLE);
			View v_line1 = (View)findViewById(R.id.v_line1);
			v_line1.setVisibility(View.VISIBLE);
			tv_pop_second_row.setVisibility(View.VISIBLE);
			View v_line2 = (View)findViewById(R.id.v_line2);
			v_line2.setVisibility(View.VISIBLE);
			tv_pop_third_row.setVisibility(View.VISIBLE);
			
			tv_pop_first_row.setText(a_arrStringBody[0]);
			tv_pop_second_row.setText(a_arrStringBody[1]);
			tv_pop_third_row.setText(a_arrStringBody[2]);
		}		
		else if(a_arrStringBody.length == 4)
		{
			tv_pop_first_row.setVisibility(View.VISIBLE);
			View v_line1 = (View)findViewById(R.id.v_line1);
			v_line1.setVisibility(View.VISIBLE);
			tv_pop_second_row.setVisibility(View.VISIBLE);
			View v_line2 = (View)findViewById(R.id.v_line2);
			v_line2.setVisibility(View.VISIBLE);
			tv_pop_third_row.setVisibility(View.VISIBLE);
			View v_line3 = (View)findViewById(R.id.v_line3);
			v_line3.setVisibility(View.VISIBLE);
			tv_pop_fourth_row.setVisibility(View.VISIBLE);
			
			tv_pop_first_row.setText(a_arrStringBody[0]);
			tv_pop_second_row.setText(a_arrStringBody[1]);
			tv_pop_third_row.setText(a_arrStringBody[2]);
			tv_pop_fourth_row.setText(a_arrStringBody[3]);
		}
	}
	
	public int getNetworkStatusCode()
	{
		return m_nHttpStatusCode;
	}
	
	public void setNetworkStatusCode(int a_nCode)
	{
		m_nHttpStatusCode = a_nCode;
	}
}
