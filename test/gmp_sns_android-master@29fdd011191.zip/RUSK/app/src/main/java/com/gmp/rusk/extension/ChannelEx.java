package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class ChannelEx implements PacketExtension {
	public static final String NAMESPACE = "urn:cork:event:channel-thread-event";
	public static final String ELEMENT_NAME = "info";

	private String channelNo;
	private String threadNo;
	private String commentNo;


	public ChannelEx() {
	}

	public ChannelEx(String channelNo, String threadNo, String commentNo) {
		this.channelNo = channelNo;
		this.threadNo = threadNo;
		this.commentNo = commentNo;
	}

	//
	//
	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return ELEMENT_NAME;
	}

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return NAMESPACE;
	}

	public String getChannelNo() {
		return this.channelNo;
	}

	public String getThreadNo() {
		return this.threadNo;
	}

	public String getCommentNo() {
		return this.commentNo;
	}

	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		StringBuilder buf = new StringBuilder();

		return buf.toString();
	}

	public static class Provider implements PacketExtensionProvider {

		public PacketExtension parseExtension(XmlPullParser parser) throws Exception {

			String type = "";
			String channelNo = "0";
			String threadNo = "0";
			String commentNo = "0";

			boolean done = false;
			int cnt = parser.getAttributeCount();
			for(int i = 0; i < cnt; i++){
				if(parser.getAttributeName(i).equals("type")){
					type = parser.getAttributeValue(i);
				}
			}

			while (!done) {
				int eventType = parser.getEventType();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("channel-no")) {
						channelNo = parser.nextText();
					} else if (parser.getName().equals("thread-no")) {
						threadNo = parser.nextText();
					} else if (parser.getName().equals("comment-no")) {
						commentNo = parser.nextText();
					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals(ELEMENT_NAME)) {
						done = true;
					}
				}
				if (!done)
					parser.next();
			}
			return new ChannelEx(channelNo, threadNo, commentNo);
		}
	}

	public String setFileExText(ChannelEx fileEx){


		return "";
	}
}