package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.CompanyData;
import com.gmp.rusk.utils.CommonLog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetProvisioningRes extends Res{

    private final String JSON_USERIMAGEURLTEMPLATE = "userImageUrlTemplate";
    private final String JSON_USERPREVIEWIMAGEURLTEMPLATE = "userPreviewImageUrlTemplate";
    private final String JSON_COMPANIES = "companies";
    private final String JSON_CODE = "code";
    private final String JSON_NAME = "name";

    private String m_strUserImageUrlTemplate = "";
    private String m_strUserPreviewImageUrlTemplate = "";
    private ArrayList<CompanyData> m_arrCompanies = new ArrayList<CompanyData>();


    public GetProvisioningRes(String a_strData, String a_strType) {
        super(a_strData);
        // TODO Auto-generated constructor stub
        parseData();
    }

    @Override
    public void parseData() {
        // TODO Auto-generated method stub
        try {
            JSONObject jsonRoot = new JSONObject(m_strResData);

            m_strUserImageUrlTemplate = jsonRoot.getString(JSON_USERIMAGEURLTEMPLATE);
            m_strUserPreviewImageUrlTemplate = jsonRoot.getString(JSON_USERPREVIEWIMAGEURLTEMPLATE);
            JSONArray jsonArray = jsonRoot.getJSONArray(JSON_COMPANIES);
            for(int i = 0; i < jsonArray.length(); i++){
                JSONObject jsonItem = jsonArray.getJSONObject(i);
                CompanyData companyData = new CompanyData(jsonItem.optString(JSON_CODE), jsonItem.optString(JSON_NAME));
                m_arrCompanies.add(companyData);
            }
        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public String getUserImageUrlTemplate() {
        return m_strUserImageUrlTemplate;
    }

    public String getUserPreviewImageUrlTemplate() {
        return m_strUserPreviewImageUrlTemplate;
    }

    public ArrayList<CompanyData> getCompanies() {
        return m_arrCompanies;
    }
}
