package com.gmp.rusk.utils;

public class IntentKeyString {
	public static final String INTENT_KEY_USERNO							= "userno";		// userNo
	
	//파트너 가입
	public static final String INTENT_KEY_USERID_TYPE						= "ispartner";
	public static final String INTENT_KEY_USERID_ID							= "useridid";
	public static final String INTENT_KEY_USERID_PW							= "useridpw";
	public static final String INTENT_KEY_USERID_MOBILE						= "useridmobile";
	public static final String INTENT_KEY_USERID_APPROVAL_USERNO 			= "approvaluserno";
	public static final String INTENT_KEY_USERID_APPROVAL_USERNAME 			= "approvalusername";
	
	//프로필 ImageView
	public static final String INTENT_KEY_PROFILEIMAGE_USERNO				= "profileimage_userno";
	//채팅방 관련
	public static final String INTENT_KEY_ARR_USERNO						= "user_no";
	public static final String INTENT_KEY_OWNERNO							= "owner_no";
	public static final String INTENT_KEY_ARR_READ_USERNO					= "read_user_no";
	public static final String INTENT_KEY_ROOM_ID							= "room_id";
	public static final String INTENT_KEY_ROOM_ID_KICK						= "room_id_kick";
	public static final String INTENT_KEY_ROOM_CHANGE_TITLE					= "room_change_title";
	public static final String INTENT_KEY_ROOM_USERNO						= "userNo";
	public static final String INTENT_KEY_SEND_MESSAGE						= "send_message";
	public static final String INTENT_KEY_SEND_FILE							= "send_file";
	public static final String INTENT_KEY_NO_MAKE_ROOM						= "no_make_room";
	public static final String INTENT_KEY_MAKE_ROOMID						= "roomID";
	public static final String INTENT_KEY_INVITE							= "invite";
	public static final String INTENT_KEY_TEXT								= "text";
	public static final String INTENT_KEY_ISALARM_ON						= "isAlarmOn";

	//방장 전달
	public static final String INTENT_KEY_PASS_OWNER						= "pass_owner_no";
	//강퇴
	public static final String INTENT_KEY_KICK_USERS						= "kick_users";
	
	//파일 전송
	public static final String INTENT_KEY_SEND_FILE_NAME					= "send_file_name";
	public static final String INTENT_KEY_SEND_FILE_PATH					= "send_file_path";
	
	//Cloud 전송
	public static final String INTENT_KEY_CLOUD_DOCID						= "cloud_docid";
	public static final String INTENT_KEY_CLOUD_FILENAME					= "cloud_filename";
	public static final String INTENT_KEY_CLOUD_URL							= "cloud_url";
	
	//이미지 다운
	public static final String INTENT_KEY_DOWNLOAD_IMAGE_PATH				= "download_image_path";
	public static final String INTENT_KEY_DOWNLOAD_ROOM_ID					= "download_room_id";
	public static final String INTENT_KEY_DOWNLOAD_MESSAGE_ID				= "download_message_id";
	
	public static final String INTENT_KEY_PUSHPOPUP_PUSHTYPE				= "pushType";
	public static final String INTENT_KEY_PUSHPOPUP_USERNO					= "userNo";
	public static final String INTENT_KEY_PUSHPOPUP_MESSAGE					= "message";
	public static final String INTENT_KEY_PUSHPOPUP_NAME					= "name";
	public static final String INTENT_KEY_PUSHPOPUP_IMGURL					= "imageUrl";
	public static final String INTENT_KEY_PUSHPOPUP_GID						= "gid";
	public static final String INTENT_KEY_PUSHPOPUP_SNSGROUPID				= "snsgroupid";
	public static final String INTENT_KEY_PUSHPOPUP_SNSBOARDID				= "snsboardid";
	public static final String INTENT_KEY_PUSHPOPUP_SNSREPLYID				= "snsreplyid";
	
	public static final String INTENT_VALUE_PUSHPOPUP_TYPE_MSG				= "msg";
	public static final String INTENT_VALUE_PUSHPOPUP_TYPE_KICK				= "kick";
	public static final String INTENT_VALUE_PUSHPOPUP_TYPE_REQUEST			= "request";
	public static final String INTENT_VALUE_PUSHPOPUP_TYPE_SNS_BOARD		= "snsboard";
	public static final String INTENT_VALUE_PUSHPOPUP_TYPE_SNS_REPLY		= "snsreply";
	public static final String INTENT_VALUE_PUSHPOPUP_TYPE_SNS_INVITE		= "snsinvite";
	
	// tNa -> TTalk Intro, push -> TTalk Intro
	public static final String INTENT_KEY_INTRO_FROM_APP = "from_app";
	public static final String INTENT_KEY_INTRO_USERNO_SIZE = "ttalk_userno_size";
	public static final String INTENT_KEY_INTRO_USERNO_LIST = "ttalk_userno_list";
	public static final String INTENT_KEY_INTRO_FRIENDNO = "ttalk_friendno";
	public static final String INTENT_KEY_INTRO_GROUPID = "ttalk_groupid";
	public static final String INTENT_KEY_INTRO_SNSGROUPID = "ttalk_snsgroupid";
	public static final String INTENT_KEY_INTRO_SNSBOARDID = "ttalk_snsboardid";
	public static final String INTENT_KEY_INTRO_SNSREPLYID = "ttalk_snsreplyid";
	
	public static final String INTENT_VALUE_INTRO_FROM_TTALK = "tna_for_ttalk";
	public static final String INTENT_VALUE_INTRO_FROM_PUSH = "push_for_ttalk";
	public static final String INTENT_VALUE_INTRO_FROM_KICK = "kick_for_ttalk";				// Push - 강퇴 메시지
	public static final String INTENT_VALUE_INTRO_FROM_REQUEST = "request_for_ttalk";		// Push - 파트너 승인요청 메시지
	public static final String INTENT_VALUE_INTRO_FROM_SNSBOARD = "snsboard_for_ttalk";		// Push - SNS 게시글
	public static final String INTENT_VALUE_INTRO_FROM_SNSREPLY = "snsreply_for_ttalk";		// Push - SNS 댓글
	public static final String INTENT_VALUE_INTRO_FROM_SNSINVITE = "snsinvite_for_ttalk";		// Push - SNS 초대
	
	public static final String INTENT_KEY_CHATROOMGROUP_FROM_PUSH = "frompush";
//	public static final String INTENT_KEY_CHATROOM_FROM_PUSH = "frompush";
	
	public static final String INTENT_KEY_MAINTAB_ISSNSBOARD = "isSNSBoard";
	public static final String INTENT_KEY_MAINTAB_ISSNSREPLY = "isSNSReply";
	public static final String INTENT_KEY_MAINTAB_ISSNSINVITE = "isSNSInvite";
	public static final String INTENT_KEY_MAINTAB_ISPUSH = "isPush";
	public static final String INTENT_KEY_MAINTAB_ISKICK = "isKick";
	public static final String INTENT_KEY_MAINTAB_ISPUSH_APPROVAL = "isApproval";
	public static final String INTENT_KEY_MAINTAB_ISPUSH_CHATROOM = "isChatRoom";
	public static final String INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO = "userNo";
	public static final String INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP = "isChatRoomGroup";
	public static final String INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID = "roomID";
	public static final String INTENT_KEY_MAINTAB_ISSNS_GROUPID = "snsGroupId";
	public static final String INTENT_KEY_MAINTAB_ISSNS_BOARDID = "snsBoardId";
	public static final String INTENT_KEY_MAINTAB_ISSNS_REPLYID = "snsReplyId";
	public static final String INTENT_KEY_MAINTAB_ISMOVETAB = "isMoveTab";
	
	public static final String INTENT_KEY_COMMON_POPUPACT_BTNTYPE = "btnType";
	public static final String INTENT_KEY_COMMON_POPUPACT_TITLE = "commonPopupActTitle";
	public static final String INTENT_KEY_COMMON_POPUPACT_BODY = "commonPopupActBody";
	public static final String INTENT_KEY_COMMON_POPUPACT_SYSNOTICEID = "sysNoticeid";
	
	
	public static final String INTENT_KEY_PUSHBROADCAST_GROUPID = "groupid";
	public static final String INTENT_KEY_PUSHBROADCAST_USERID = "userid";
	public static final String INTENT_KEY_PUSHBROADCAST_SNSGROUPID = "snsgroupid";
	public static final String INTENT_KEY_PUSHBROADCAST_SNSBOARDID = "snsboardid";
	public static final String INTENT_KEY_PUSHBROADCAST_SNSREPLYID = "snsreplyid";
	
	public static final String INTENT_KEY_FINISHCHATROOMBROADCAST_ROOMID = "roomid";
	
	// 모임
	public static final String INTENT_KEY_SNSCREATEGROUP_ISEDIT = "isedit";
	public static final String INTENT_KEY_SNSCREATEGROUP_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSCREATEGROUP_GROUPNAME = "groupname";
	public static final String INTENT_KEY_SNSCREATEGROUP_GROUPIMAGEURL = "groupimgurl";
	public static final String INTENT_KEY_SNSCREATEGROUP_GROUPDEFAULTIMAGEIDX = "groupdefaultimgidx";
	public static final String INTENT_KEY_SNSGROUPDETAIL_GOBOARDDETAIL = "goboarddetail";
	public static final String INTENT_KEY_SNSGORUPDETAIL_WRITEBOARD = "gowriteboard"; //모임글을 복사한 후 다른 모임에 글을 바로 쓸 수있도록 하기 위해 추가
	public static final String INTENT_KEY_SNSGROUPDETAIL_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSGROUPDETAIL_GROUPNAME = "groupname";
	public static final String INTENT_KEY_SNSGROUPDETAIL_GROUPCREATE = "groupcreate";
	public static final String INTENT_KEY_SNSGROUPDETAIL_ANOCATEGORYNO = "anocategoryno";
	public static final String INTENT_KEY_SNSGROUPDETAIL_ANOCATEGORYNAME = "anocategoryname";
	public static final String INTENT_KEY_SNSGROUPDETAIL_ANOADMIN = "anoadmin";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ISREAD = "isread";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ISPUSH = "ispush";
	public static final String INTENT_KEY_SNSBOARDDETAIL_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSBOARDDETAIL_GROUPNAME = "groupname";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ANOCATEGORYNO = "anocategoryno";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ANOCATEGORYNAME = "anocategoryname";
	public static final String INTENT_KEY_SNSBOARDDETAIL_BOARDID = "boardid";
	public static final String INTENT_KEY_SNSBOARDDETAIL_CANCELNOTICE = "cancelnotice";
	public static final String INTENT_KEY_SNSBOARDDETAIL_REPLYIDS = "replyids";
	public static final String INTENT_KEY_SNSBOARDDETAIL_REPLY = "reply";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ISLASTSCROLL = "islastscroll";
	public static final String INTENT_KEY_SNSBOARDDETAIL_EDITREPLY = "editreply";
	public static final String INTENT_KEY_SNSBOARDDETAIL_WRITEREPLY = "writereply";
	public static final String INTENT_KEY_SNSBOARDDETAIL_SHOWCHATBTN = "showchatbtn";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ISDELETE = "isdelete";
	public static final String INTENT_KEY_SNSBOARDDETAIL_ISOWNER = "isowner";
	/**
	 * 글내용 복사용으로 추가
	 */
	public static final String INTENT_KEY_SNSBOARDDETAIL_BOARDTEXT = "boardtext"; //글내용 복사용으로 추가
	public static final String INTENT_KEY_SNSBOARDWRITE_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSBOARDEDIT_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSBOARDEDIT_BOARDID = "boardid";
	public static final String INTENT_KEY_SNSEDITREPLY_REPLYID = "replyid";
	public static final String INTENT_KEY_SNSEDITREPLY_BOARDID  = "boardid";
	public static final String INTENT_KEY_SNSEDITREPLY_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSEDITREPLY_EDITTEXT = "edittext";
	public static final String INTENT_KEY_SNSEDITREPLY_IMAGEURL = "imageurl";
	public static final String INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSGROUPDETAIL_USERIDS = "userids";
	public static final String INTENT_KEY_SNSGROUPDETAIL_ISTHREAD_ALARMON = "isthread_alarmon";
	public static final String INTENT_KEY_SNSGROUPDETAIL_ISCOMMENT_ALARMON = "iscomment_alarmon";
	public static final String INTENT_KEY_SNSGROUPMEMBERLIST_ISOWNER = "isowner";
	public static final String INTENT_KEY_SNSIMAGEVIEW_IMAGEURLLIST = "imageurllist";
	public static final String INTENT_KEY_SNSIMAGEVIEW_SELECTEDIMAGEPOS = "selectedimagepos";
	public static final String INTENT_KEY_SNSGROUPSEARCH_HASHTAG = "hashtag";
	public static final String INTENT_KEY_SNSGROUPFILEBOX_GROUPID = "groupid";
	public static final String INTENT_KEY_SNSGROUPFILEBOX_CHATROOMID = "chatroomid";

	public static final String INTENT_KEY_GALLERYMULTISELECTOR_COUNT_LIMIT = "max_select_count";
	public static final String INTENT_KEY_GALLERYMULTISELECTOR_SIZE_LIMIT = "max_select_size";
	public static final String INTENT_KEY_GALLERYMULTISELECTOR_FILELIST = "file_list";
	public static final String INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY = "file_array";
	public static final String INTENT_KEY_GALLERYMULTISELECTOR_FROM = "fromactivity";
	
	public static final String INTENT_KEY_FILEMULTISELECTOR_FILELIST = "file_list";
	public static final String INTENT_KEY_FILEMULTISELECTOR_ABLEFILECOUNT = "ablefilecount";
	public static final String INTENT_KEY_FILEMULTISELECTOR_ABLEFILEMAXSIZE = "ablefilemaxsize";
	
	public static final String INTENT_KEY_SNSGROUPCHAT_ID = "snsgourpchat_id";
	public static final String INTENT_KEY_SNSGROUPCHAT_NAME = "snsgroupchat_name";
	public static final String INTENT_KEY_SNSGROUPCHAT_MEMBER = "snsgroupchat_member";
	
	public static final String INTENT_KEY_SNSCLOUDFILESEARCH_SELECTEDDDATA = "selecteddata";
	public static final String INTENT_KEY_SNSCLOUDFILESEARCH_BUNDLE = "bundledata";
	public static final String INTENT_KEY_SNSCLOUDFILESEARCH_ABLEFILECOUNT = "ablefilecount";
	public static final String INTENT_KEY_SNSCLOUDFILESEARCH_ABLEFILEMAXSIZE = "ablefilemaxsize";
	
	public static final String INTENT_KEY_SNSGROUPPROFILE_GROUPID = "groupid";
	
	// 주소록 Preview
	public static final String INTENT_KEY_CONTACTSPREVIEW_NAME = "contactname";
	public static final String INTENT_KEY_CONTACTSPREVIEW_LOOKUPKEY = "contactlookupkey";
	
	// PC 버전 사용 중지
	public static final String INTENT_KEY_PCCLIENTSTOP_HOSTNAME = "hostname";
	public static final String INTENT_KEY_PCCLIENTSTOP_DEVICEUID = "deviceuid";

	// 정직원이 재승인 푸쉬 받았을때 사용
	public static final String INTENT_KEY_REAPPROVAL = "reapproval";

	//채널 공지사항 데이터
	public static final String INTENT_KEY_CHANNEL_NOTICELIST_NAME = "name";
	public static final String INTENT_KEY_CHANNEL_NOTICELIST_TITLE = "title";
	public static final String INTENT_KEY_CHANNEL_NOTICELIST_BODY = "body";
	public static final String INTENT_KEY_CHANNEL_NOTICELIST_FILE = "file";

}
