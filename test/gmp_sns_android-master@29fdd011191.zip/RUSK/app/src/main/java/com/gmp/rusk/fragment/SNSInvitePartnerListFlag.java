package com.gmp.rusk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.SNSGroupMemeberInviteAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.SNSInvitePartnerListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostSearchPartnerReq;
import com.gmp.rusk.response.PostSearchPartnerRes;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;


public class SNSInvitePartnerListFlag extends Fragment implements OnClickListener, OnCheckedChangeListener, OnTouchListener {

	public MyApp App = MyApp.getInstance();
	private View m_vAddedByPartnerList = null;

	private FragmentActivity m_Activity = null;

	private AddedByPartnerListAdapter m_AddedByPartnerAdapter = null;

	ArrayList<PartnerSearchListData> m_arrPartnerSearchListDatas = null;

	private LinearLayout layout_addedbylist_list = null;
	private ListView m_lvAddedByPartnerList = null;

	private int m_nPage = 1;

	EditText et_search_keyword;
	ImageButton ib_cancel;
	TextView m_tvSectionText;
	RelativeLayout layout_nolisttext;
	public final ArrayList<Integer> m_nInviteSelectId = new ArrayList<Integer>();
	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;

	private InputMethodManager imm;
	public boolean m_isRunning = false;
	
	CheckBox m_cbAllcheck;
	ArrayList<Integer> m_arrUserNumbers;
	// 사용자가 눌러서 터치를 한것인지, 앱에서 판단해서 체크하는지
	boolean m_isTouchCheckBox = false;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		m_Activity = getActivity();
		imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
	}

	/**
	 * The Fragment's UI is just a simple text view showing its instance number.
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		m_vAddedByPartnerList = inflater.inflate(R.layout.fragact_snsinvitebypartnerlist, container, false);
		m_arrUserNumbers = ((SNSGroupMemeberInviteAct) m_Activity).getUserNumbers();
		((SNSGroupMemeberInviteAct) m_Activity).setNotifyListener(m_NotifyListner);
		initSearchPartner();

		return m_vAddedByPartnerList;
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		if(m_AddedByPartnerAdapter != null)
			m_AddedByPartnerAdapter.notifyDataSetChanged();
		super.onResume();
		m_isRunning = true;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (imm != null && et_search_keyword != null)
			imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
				popup_ok_long.cancel();
				App.expirePartnerLogin(m_Activity);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Activity);
			}
			popup_ok_long.cancel();
		}
	}

	private void initSearchPartner() {
		layout_addedbylist_list = (LinearLayout) m_vAddedByPartnerList.findViewById(R.id.layout_addedbylist_list);
		m_lvAddedByPartnerList = (ListView) m_vAddedByPartnerList.findViewById(R.id.lv_addedbylist_list);
		layout_addedbylist_list.setVisibility(View.GONE);

		m_tvSectionText = (TextView) m_vAddedByPartnerList.findViewById(R.id.tv_sectiontext);
		m_cbAllcheck = (CheckBox) m_vAddedByPartnerList.findViewById(R.id.cb_sns_allmember);
		m_cbAllcheck.setOnCheckedChangeListener(this);
		m_cbAllcheck.setOnTouchListener(this);
		m_cbAllcheck.setChecked(false);
		
		layout_nolisttext = (RelativeLayout) m_vAddedByPartnerList.findViewById(R.id.layout_hinttext);
		layout_nolisttext.setVisibility(View.VISIBLE);
		et_search_keyword = (EditText) m_vAddedByPartnerList.findViewById(R.id.et_search_keyword);
		et_search_keyword.setText("");
		ib_cancel = (ImageButton) m_vAddedByPartnerList.findViewById(R.id.ib_cancel);
		ib_cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				initSearchPartner();
			}
		});

		et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				CommonLog.e("EditAction", "actionId1 : " + actionId);

				switch (actionId) {
				case EditorInfo.IME_ACTION_SEARCH:
					if (v.getText().toString().trim().length() > 1) {
						if(!Utils.UseChar(v.getText().toString()))
						{
							m_Popup = new CommonPopup(m_Activity, SNSInvitePartnerListFlag.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									getString(R.string.regular_expression_search).toString());
							m_Popup.setCancelable(false);
							isCheckShowPopup();
							return false;
						}
						requestAddedByPartner(v.getText().toString());
					}
					else {
						m_Popup = new CommonPopup(m_Activity, SNSInvitePartnerListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.popup_search_length).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
					break;
				}
				return false;
			}
		});

		et_search_keyword.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if (s.toString().length() > 0) {
					ib_cancel.setVisibility(View.VISIBLE);
				} else {
					ib_cancel.setVisibility(View.INVISIBLE);
					layout_nolisttext.setVisibility(View.VISIBLE);
					layout_addedbylist_list.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});

	}

	private void setSearchApdapter() {
		layout_addedbylist_list.setVisibility(View.VISIBLE);


		if (m_arrPartnerSearchListDatas != null) {
			layout_nolisttext.setVisibility(View.GONE);
//			String strSetionName = getString(R.string.layout_sectionstring_search_result);

//			for (PartnerSearchListData data : m_arrPartnerSearchListDatas) {
//				SectionListItem item = new SectionListItem(data, strSetionName + "(" + m_arrPartnerSearchListDatas.size() + ")");
//				//m_SectionListItems.add(item);
//			}
			m_tvSectionText.setText(getString(R.string.layout_sectionstring_search_result) + "(" + m_arrPartnerSearchListDatas.size() + ")");
		} else {
			m_lvAddedByPartnerList.setVisibility(View.GONE);
			layout_nolisttext.setVisibility(View.VISIBLE);
		}
		m_cbAllcheck.setChecked(false);
		m_AddedByPartnerAdapter = new AddedByPartnerListAdapter();
		m_AddedByPartnerAdapter.areAllItemsEnabled();
		m_lvAddedByPartnerList.setAdapter(m_AddedByPartnerAdapter);

	}

	// AddedByPartnerList Adapter
	private class AddedByPartnerListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_arrPartnerSearchListDatas != null)
				return m_arrPartnerSearchListDatas.size();

			return 0;
		}

		@Override
		public Object getItem(int position) {
			// if(position == 0) return header;

			if (m_arrPartnerSearchListDatas != null)
				return m_arrPartnerSearchListDatas.get(position);

			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			PartnerSearchListData data = m_arrPartnerSearchListDatas.get(nPosition);

			CommonLog.e(getClass(), "getView");

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new SNSInvitePartnerListItemLayout(m_Activity);

			((SNSInvitePartnerListItemLayout) convertView).setPartnerSearchListData(data);

			((SNSInvitePartnerListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);
			CheckBox cb_redaction = (CheckBox) ((SNSInvitePartnerListItemLayout) convertView).findViewById(R.id.cb_invite);
			ImageView ivSelected = (ImageView) ((SNSInvitePartnerListItemLayout) convertView).findViewById(R.id.iv_invite_selected);
			if (m_arrUserNumbers.contains(data.m_nUserNo)) {

				cb_redaction.setVisibility(View.GONE);
				ivSelected.setVisibility(View.VISIBLE);

			} else {
				cb_redaction.setVisibility(View.VISIBLE);
				ivSelected.setVisibility(View.GONE);
			}
			if(!data.m_isAvailable) {
				cb_redaction.setVisibility(View.GONE);
				ivSelected.setVisibility(View.GONE);
			}
			if (cb_redaction.getVisibility() != View.GONE) {
				if (data.m_isChecked) {
					boolean is_redaction = false;
					ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;
					for (int i = 0; i < arrSearchListCheckData.size(); i++) {
						if (data.m_nUserNo == arrSearchListCheckData.get(i).m_nUserNo) {
							is_redaction = true;
							cb_redaction.setChecked(true);
							break;
						}
					}
					if (!is_redaction) {
						cb_redaction.setChecked(false);
					}

				} else
					cb_redaction.setChecked(false);
			}
			return convertView;
		}
	}

	private void requestAddedByPartner(String a_strKeyword) {
		showProgress(getString(R.string.progress_search));
		PostSearchPartnerReq req = new PostSearchPartnerReq(a_strKeyword, m_nPage);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				PostSearchPartnerRes res = new PostSearchPartnerRes(a_strData);
				if (res.getPartnerSearchListData() != null) {

					m_arrPartnerSearchListDatas = res.getPartnerSearchListData();
					// 상단 스크롤바에 이름이 있을시 동일 이름이 검색 결과에 있다면 체크 적용
					for (SearchListCheckData checkData : App.m_arrSearchListCheckData) {
						for (PartnerSearchListData afterData : m_arrPartnerSearchListDatas) {
							if (checkData.m_nUserNo == afterData.m_nUserNo) {
								afterData.m_isChecked = true;
							}
						}

					}

					// if (App.m_arrPartnerSearchListData !=
					// m_arrPartnerSearchListDatas) {
					// // 파트너 검색에서
					// for (PartnerSearchListData beforeData :
					// App.m_arrPartnerSearchListData) {
					// if (beforeData.m_isChecked) {
					// for (PartnerSearchListData afterData :
					// m_arrPartnerSearchListDatas) {
					// if (afterData.m_nUserNo == beforeData.m_nUserNo) {
					// afterData.m_isChecked = true;
					// }
					// }
					// }
					// }
					// // 동료 탭에서
					// for (FellowListData beforeData : App.m_arrFellowListData)
					// {
					// if (beforeData.m_isChecked) {
					// for (PartnerSearchListData afterData :
					// m_arrPartnerSearchListDatas) {
					// if (afterData.m_nUserNo == beforeData.m_nUserNo) {
					// afterData.m_isChecked = true;
					// }
					// }
					// }
					// }
					// App.m_arrPartnerSearchListData =
					// m_arrPartnerSearchListDatas;
					// }
				} else {
					m_arrPartnerSearchListDatas = new ArrayList<PartnerSearchListData>();

				}
				closeProgress();
				setSearchApdapter();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				((SNSGroupMemeberInviteAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
//				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
//					m_Popup = new CommonPopup(m_Activity, SNSInvitePartnerListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
//					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE || a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
//					m_Popup = new CommonPopup(m_Activity, SNSInvitePartnerListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//							PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
//					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				} else {
//					m_Popup = new CommonPopup(m_Activity, SNSInvitePartnerListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				}
			}
		});
	}

	SNSGroupMemeberInviteAct.OnNotifyListener m_NotifyListner = new SNSGroupMemeberInviteAct.OnNotifyListener() {

		@Override
		public void onNotify() {
			// TODO Auto-generated method stub
			if (m_AddedByPartnerAdapter != null) {
				if (m_arrPartnerSearchListDatas != null) {
					for (int i = 0; i < m_arrPartnerSearchListDatas.size(); i++) {
						PartnerSearchListData listData = m_arrPartnerSearchListDatas.get(i);
						String strSetionName = getString(R.string.layout_sectionstring_search_result);
						if (App.m_arrSearchListCheckData.size() != 0) {
							for (SearchListCheckData data : App.m_arrSearchListCheckData) {
								if (listData.m_nUserNo == data.m_nUserNo) {
									listData.m_isChecked = true;
									//SectionListItem item = new SectionListItem(listData, strSetionName + "(" + m_arrPartnerSearchListDatas.size() + ")");
									m_arrPartnerSearchListDatas.set(i, listData);
									break;
								} else {
									listData.m_isChecked = false;
									//SectionListItem item = new SectionListItem(listData, strSetionName + "(" + m_arrPartnerSearchListDatas.size() + ")");
									m_arrPartnerSearchListDatas.set(i, listData);
								}
							}
						} else {
							listData.m_isChecked = false;
							//SectionListItem item = new SectionListItem(listData, strSetionName + "(" + m_arrPartnerSearchListDatas.size() + ")");
							m_arrPartnerSearchListDatas.set(i, listData);
						}
					}
				}
				m_AddedByPartnerAdapter.notifyDataSetChanged();
				m_cbAllcheck.setChecked(false);
			}

		}
	};

	SNSInvitePartnerListItemLayout.OnCheckedChangedListener m_CheckedChangedListner = new SNSInvitePartnerListItemLayout.OnCheckedChangedListener() {

		@Override
		public void onChecked(boolean a_isChecked, int a_nUserId) {
			// TODO Auto-generated method stub
			if (a_isChecked) {
				boolean isSame = false;
				if (App.m_arrSearchListCheckData != null) {
					for (int i = 0; i < m_arrPartnerSearchListDatas.size(); i++) {
						for (SearchListCheckData data : App.m_arrSearchListCheckData) {
							if (data.m_nUserNo == m_arrPartnerSearchListDatas.get(i).m_nUserNo) {
								isSame = true;
								break;
							} else if(m_arrUserNumbers.contains(m_arrPartnerSearchListDatas.get(i).m_nUserNo)){
								isSame = true;
								break;
							}
							else {
								isSame = false;
							}

						}
						if (!isSame) {
							break;
						}
					}
				}
				if (isSame) {
					m_cbAllcheck.setChecked(true);
				} else {
					m_cbAllcheck.setChecked(false);
				}
			} else {

				m_cbAllcheck.setChecked(false);
			}
		}
	};

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if (buttonView.getId() == R.id.cb_sns_allmember) {
			if (m_isTouchCheckBox) {
				if (isChecked) {
					int nCheckList = 0;
					for (int i = 0; i < m_arrPartnerSearchListDatas.size(); i++) {

						if(!m_arrUserNumbers.contains(m_arrPartnerSearchListDatas.get(i).m_nUserNo)){
							SearchListCheckData addData = new SearchListCheckData(m_arrPartnerSearchListDatas.get(i).m_nUserNo, m_arrPartnerSearchListDatas.get(i).m_strName);
							((SNSGroupMemeberInviteAct) m_Activity).addSearchList(addData);
							PartnerSearchListData data = m_arrPartnerSearchListDatas.get(i);
							data.m_isChecked = true;
							m_arrPartnerSearchListDatas.set(i, data);
							nCheckList++;
						}
					}
					if(nCheckList == 0){
						m_isTouchCheckBox = false;
						m_cbAllcheck.setChecked(false);
					}
				} else {
					for (int i = 0; i < m_arrPartnerSearchListDatas.size(); i++) {
						((SNSGroupMemeberInviteAct) m_Activity).removeListData(m_arrPartnerSearchListDatas.get(i).m_nUserNo);
						PartnerSearchListData data = m_arrPartnerSearchListDatas.get(i);
						data.m_isChecked = false;
						m_arrPartnerSearchListDatas.set(i, data);
					}
				}
				m_isTouchCheckBox = false;
				if (m_AddedByPartnerAdapter != null)
					m_AddedByPartnerAdapter.notifyDataSetChanged();

			} 

		}

	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.cb_sns_allmember) {
			m_isTouchCheckBox = true;
		}
		return false;
	}
}