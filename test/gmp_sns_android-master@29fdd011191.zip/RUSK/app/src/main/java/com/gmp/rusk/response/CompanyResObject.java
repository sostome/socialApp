package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.CompanyEntryData;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface CompanyResObject {

    public final String JSON_COMPANY				= "company";

    public final String JSON_CODE = "code";
    public final String JSON_NAME = "name";
    public final String JSON_MESSAGEVALIDITYPERIODS = "messageValidityPeriods";
    public final String JSON_PARTNERREGULARSEARCHENABLED = "partnerRegularSearchEnabled";
    public final String JSON_PARTNERCHANNELCREATIONENABLED = "partnerChannelCreationEnabled";
    public final String JSON_REGULARMOBILEIMAGESHARINGENABLED = "regularMobileImageSharingEnabled";
    public final String JSON_REGULARMOBILEIMAGEDOWNLOADENABLED = "regularMobileImageDownloadEnabled";
    public final String JSON_REGULARMOBILENORMALFILESHARINGENABLED = "regularMobileNormalFileSharingEnabled";
    public final String JSON_REGULARMOBILENORMALFILEDOWNLOADENABLED = "regularMobileNormalFileDownloadEnabled";
    public final String JSON_REGULARPCIMAGESHARINGENABLED = "regularPcImageSharingEnabled";
    public final String JSON_REGULARPCIMAGEDOWNLOADENABLED = "regularPcImageDownloadEnabled";
    public final String JSON_REGULARPCNORMALFILESHARINGENABLED = "regularPcNormalFileSharingEnabled";
    public final String JSON_REGULARPCNORMALFILEDOWNLOADENABLED = "regularPcNormalFileDownloadEnabled";
    public final String JSON_PARTNERMOBILEIMAGESHARINGENABLED = "partnerMobileImageSharingEnabled";
    public final String JSON_PARTNERMOBILEIMAGEDOWNLOADENABLED = "partnerMobileImageDownloadEnabled";
    public final String JSON_PARTNERMOBILENORMALFILESHARINGENABLED = "partnerMobileNormalFileSharingEnabled";
    public final String JSON_PARTNERMOBILENORMALFILEDOWNLOADENABLED= "partnerMobileNormalFileDownloadEnabled";
    public final String JSON_PARTNERPCIMAGESHARINGENABLED = "partnerPcImageSharingEnabled";
    public final String JSON_PARTNERPCIMAGEDOWNLOADENABLED = "partnerPcImageDownloadEnabled";
    public final String JSON_PARTNERPCNORMALFILESHARINGENABLED = "partnerPcNormalFileSharingEnabled";
    public final String JSON_PARTNERPCNORMALFILEDOWNLOADENABLED = "partnerPcNormalFileDownloadEnabled";
    public final String JSON_REGULARTAPICALLENABLED = "regularTApiCallEnabled";

    public void parseCompanyData();
    public CompanyEntryData getCompanyData();
}
