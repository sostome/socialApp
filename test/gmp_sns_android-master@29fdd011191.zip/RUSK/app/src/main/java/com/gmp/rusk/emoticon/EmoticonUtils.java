package com.gmp.rusk.emoticon;

import com.gmp.rusk.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.widget.EditText;

public class EmoticonUtils {
	
	private static Bitmap getEmoticonImage(Context a_Context, String a_strText)
	{
		int nRes = -1;
		
		if(a_strText.equals(a_Context.getString(R.string.emoticon_01)))
			nRes = R.drawable.balloon_e01;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_02)))
			nRes = R.drawable.balloon_e02;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_03)))
			nRes = R.drawable.balloon_e03;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_04)))
			nRes = R.drawable.balloon_e04;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_05)))
			nRes = R.drawable.balloon_e05;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_06)))
			nRes = R.drawable.balloon_e06;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_07)))
			nRes = R.drawable.balloon_e07;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_08)))
			nRes = R.drawable.balloon_e08;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_09)))
			nRes = R.drawable.balloon_e09;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_10)))
			nRes = R.drawable.balloon_e10;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_11)))
			nRes = R.drawable.balloon_e11;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_12)))
			nRes = R.drawable.balloon_e12;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_13)))
			nRes = R.drawable.balloon_e13;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_14)))
			nRes = R.drawable.balloon_e14;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_15)))
			nRes = R.drawable.balloon_e15;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_16)))
			nRes = R.drawable.balloon_e16;
		else if(a_strText.equals(a_Context.getString(R.string.emoticon_17)))
			nRes = R.drawable.balloon_e17;
		
		if(nRes == -1)
			return null;
		
		return BitmapFactory.decodeResource(a_Context.getResources(), nRes);
	}
	
	public Spannable parsingEmoticonText(Context a_Context, String a_strText, int a_nTextSize)
    {
    	SpannableString spanString = new SpannableString(a_strText);
    	
    	char[] szText = a_strText.toCharArray();
    	
    	boolean isEmoticon = false;
    	String strTempEmoticonText = "";
    	
    	int nEmoticonStartIdx = -1;
    	int nEmoticonLastIdx = -1;
    	
    	for(int i = 0; i < szText.length; i++)
    	{
    		char c = szText[i];
    		
    		if(!isEmoticon && c == '(')
    		{
    			isEmoticon = true;
    			nEmoticonStartIdx = i;
    		}
    		else if(isEmoticon && c == ')')
    		{
    			nEmoticonLastIdx = i;
    			
    			//if(strTempEmoticonText.length() == 2)
    			//{
    				Bitmap bmp = getEmoticonImage(a_Context, "(" + strTempEmoticonText + ")");
        			
        			if(bmp != null)
        			{
        				int nSize = a_nTextSize + 12;
        				Bitmap bmpResize = Bitmap.createScaledBitmap(bmp, nSize, nSize, true);
        				spanString.setSpan(new ImageSpan(a_Context, bmpResize), nEmoticonStartIdx, nEmoticonLastIdx + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        			}
    			//}
    			
    			isEmoticon = false;
				nEmoticonStartIdx = -1;
				nEmoticonLastIdx = -1;
				strTempEmoticonText = "";
    		}
    		else if(isEmoticon)
    		{
    			strTempEmoticonText += c;
    			
    			/*if(strTempEmoticonText.length() > 2)
    			{
    				isEmoticon = false;
    				nEmoticonStartIdx = -1;
    				nEmoticonLastIdx = -1;
    				strTempEmoticonText = "";
    			}*/
    		}
    	}
    	
    	return spanString;
    }
	public Spannable parsingEmoticonText(Context a_Context, SpannableString spanString, String a_strText, int a_nTextSize)
	{

		char[] szText = a_strText.toCharArray();

		boolean isEmoticon = false;
		String strTempEmoticonText = "";

		int nEmoticonStartIdx = -1;
		int nEmoticonLastIdx = -1;

		for(int i = 0; i < szText.length; i++)
		{
			char c = szText[i];

			if(!isEmoticon && c == '(')
			{
				isEmoticon = true;
				nEmoticonStartIdx = i;
			}
			else if(isEmoticon && c == ')')
			{
				nEmoticonLastIdx = i;

				//if(strTempEmoticonText.length() == 2)
				//{
					Bitmap bmp = getEmoticonImage(a_Context, "(" + strTempEmoticonText + ")");

					if(bmp != null)
					{
						int nSize = a_nTextSize + 12;
						Bitmap bmpResize = Bitmap.createScaledBitmap(bmp, nSize, nSize, true);
						spanString.setSpan(new ImageSpan(a_Context, bmpResize), nEmoticonStartIdx, nEmoticonLastIdx + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
					}
				//}

				isEmoticon = false;
				nEmoticonStartIdx = -1;
				nEmoticonLastIdx = -1;
				strTempEmoticonText = "";
			}
			else if(isEmoticon)
			{
				strTempEmoticonText += c;

				/*if(strTempEmoticonText.length() > 2)
				{
					isEmoticon = false;
					nEmoticonStartIdx = -1;
					nEmoticonLastIdx = -1;
					strTempEmoticonText = "";
				}*/
			}
		}

		return spanString;
	}

	public static void inputEmoticonText(EditText a_etInput, String a_strText)
	{
		int nSelectionStart = a_etInput.getSelectionStart();
		int nSelectionEnd = a_etInput.getSelectionEnd();
		
		
		String strText = a_etInput.getText().toString();
		String strFirst = strText.substring(0, nSelectionStart);
		String strLast = strText.substring(nSelectionEnd, strText.length());
		
		a_etInput.setText(strFirst + a_strText + strLast);
		a_etInput.setSelection(nSelectionStart + a_strText.length(), nSelectionStart + a_strText.length());
	}
}
