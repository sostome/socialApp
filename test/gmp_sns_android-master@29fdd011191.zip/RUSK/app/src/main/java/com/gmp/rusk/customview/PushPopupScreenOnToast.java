package com.gmp.rusk.customview;

import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.SharedPref;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class PushPopupScreenOnToast extends Toast{
	
	private Context m_Context = null;
	private View view = null;
	public PushPopupScreenOnToast(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		m_Context = context;
	}
	
	public void showToast(int a_nFriendUserNo, String a_strName, String a_strMsg, String a_strImageUrl)
	{
		LayoutInflater layoutInflater = (LayoutInflater)m_Context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		view = (LinearLayout)layoutInflater.inflate(R.layout.toast_pushpopup_screenon, null);
		
		ImageView ivPic = (ImageView)view.findViewById(R.id.iv_pushpopup_pic);
		ImageView ivNotFellowPic = (ImageView)view.findViewById(R.id.iv_pushpopup_notfellow_pic);
		LinearLayout layoutDetail = (LinearLayout)view.findViewById(R.id.layout_pushpopup_detail);
		TextView tvDefaultMsg = (TextView)view.findViewById(R.id.tv_pushpopup_defaultmsg);
		
		if(!TextUtils.isEmpty(a_strImageUrl))
		{
			if(a_strImageUrl.equals(m_Context.getString(R.string.app_name))){
				ivPic.setImageResource(R.drawable.img_profile_cork);
				ivNotFellowPic.setVisibility(View.GONE);
			} else if(a_nFriendUserNo == 0 && a_strName.equals("cork.com")){
				ivPic.setImageResource(R.drawable.img_profile_cork);
				ivNotFellowPic.setVisibility(View.GONE);
			}
			else {
				ImageLoaderManager imageLoader = ImageLoaderManager.getInstance(m_Context);
				//imageLoader.getImage(ivPic, a_strImageUrl, R.drawable.notice_profile_pic_frame);
				//ivPic.setImageBitmap(imageLoader.getImage(a_strImageUrl, R.drawable.notice_profile_pic_frame));
				imageLoader.getImage(ivPic, a_strImageUrl, R.drawable.notice_profile_pic_frame);
				ivNotFellowPic.setVisibility(View.GONE);

				}
		}
		else {
			if(a_nFriendUserNo == 0 && a_strName.equals("cork.com")){
				a_strName = m_Context.getString(R.string.app_name);
				ivPic.setImageResource(R.drawable.img_profile_cork);
				ivNotFellowPic.setVisibility(View.GONE);
			} else {
				ivPic.setImageResource(R.drawable.profile_pic_default);
				ivNotFellowPic.setVisibility(View.GONE);
			}
		}
		
		SharedPref pref = SharedPref.getInstance(m_Context);
		boolean isPreview = pref.getBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
		if(isPreview)
		{
			layoutDetail.setVisibility(View.VISIBLE);
			tvDefaultMsg.setVisibility(View.GONE);
			TextView tvName = (TextView)view.findViewById(R.id.tv_pushpopup_name);
			TextView tvMsg = (TextView)view.findViewById(R.id.tv_pushpopup_msg);
			tvName.setText(a_strName);
//			tvMsg.setText(a_strMsg);
			EmoticonUtils emoticonUtils = new EmoticonUtils();
			tvMsg.setText(emoticonUtils.parsingEmoticonText(m_Context, a_strMsg, (int)tvMsg.getTextSize()));
		}
		else
		{
			layoutDetail.setVisibility(View.GONE);
			tvDefaultMsg.setVisibility(View.VISIBLE);
		}
		
		show(this, view, Toast.LENGTH_LONG);
	}
	
	public void showToast(String a_strMsg)
	{
		LayoutInflater layoutInflater = (LayoutInflater)m_Context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		view = (LinearLayout)layoutInflater.inflate(R.layout.toast_pushpopup_screenon, null);
		
		ImageView ivPic = (ImageView)view.findViewById(R.id.iv_pushpopup_pic);
		LinearLayout layoutDetail = (LinearLayout)view.findViewById(R.id.layout_pushpopup_detail);
		TextView tvDefaultMsg = (TextView)view.findViewById(R.id.tv_pushpopup_defaultmsg);
		
		layoutDetail.setVisibility(View.GONE);
		tvDefaultMsg.setVisibility(View.VISIBLE);
		tvDefaultMsg.setText(a_strMsg);
		
		ivPic.setImageResource(R.drawable.ic_launcher);
		
		show(this, view, Toast.LENGTH_LONG);
	}
	
	private void show(Toast toast, View v, int duration){
        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 100);
        toast.setDuration(duration);
        toast.setView(v);
        toast.show();
    }
}
