package com.gmp.rusk.datamodel;

public class SNSAlarmData {
	
	public static final String ALARMTYPE_NEWBOARD 	= "B";		// 게시글
	public static final String ALARMTYPE_NEWREPLY 	= "R";		// 댓글
	public static final String ALARMTYPE_EDITBOARD 	= "U";		// 게시글 수정
	public static final String ALARMTYPE_PUSH		= "P";		// Push
	
	public int m_nIdx = -1;
	public int m_nGroupId = -1;
	public String m_strGroupName = "";
	public int m_nBoardNo = -1;
	public String m_strComment = "";
	public int m_nReplyNo = -1;
	public String m_strMsg = "";
	public int m_nUserNo = -1;
	public String m_strUserImagerUrl = "";
	public String m_strType = "";
	public String m_strCreateDate = "";
	public String m_strUpdateDate = "";
	public boolean m_isDeleted = false;
	public boolean m_isAlarmRead = false;
	public boolean m_isBoardRead = false;
	public long m_lnCreateMillisecond = 0L;
}
