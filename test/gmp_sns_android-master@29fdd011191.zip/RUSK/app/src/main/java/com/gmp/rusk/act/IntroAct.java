package com.gmp.rusk.act;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Toast;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.aom.QuickstartPreferences;
import com.gmp.rusk.aom.RegistrationIntentService;
import com.gmp.rusk.backup.IntroBackUp;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.GMPData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.ChattingDBManagerForDelayMessage;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.filedownload.FileDownload;
import com.gmp.rusk.gmp.AuthUtil;
import com.gmp.rusk.gmp.SimpleCrypto;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteBackUpReq;
import com.gmp.rusk.request.GetAppVersionReq;
import com.gmp.rusk.request.GetBackUpCheckReq;
import com.gmp.rusk.request.GetBackUpUrlReq;
import com.gmp.rusk.request.GetEntryReq;
import com.gmp.rusk.request.GetFellowListReq;
import com.gmp.rusk.request.GetPartnerApprovalListReq;
import com.gmp.rusk.request.GetProvisioningReq;
import com.gmp.rusk.request.GetUserListReq;
import com.gmp.rusk.request.PostGMPAuthReq;
import com.gmp.rusk.request.PostMigrateMobileReq;
import com.gmp.rusk.request.PutChangePushTokenReq;
import com.gmp.rusk.request.PutGroupSettingReq;
import com.gmp.rusk.response.GetAppVersionRes;
import com.gmp.rusk.response.GetBackUpCheckRes;
import com.gmp.rusk.response.GetBackUpUrlRes;
import com.gmp.rusk.response.GetEntryRes;
import com.gmp.rusk.response.GetFellowListRes;
import com.gmp.rusk.response.GetPartnerApprovalListRes;
import com.gmp.rusk.response.GetProvisioningRes;
import com.gmp.rusk.response.GetUserListRes;
import com.gmp.rusk.response.PostPartnerMigrateMobileRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.service.XmppConnectionService;
import com.gmp.rusk.service.XmppConnectionService.LocalBinder;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.KeystoreCrypto;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.PermissionCheck;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GooglePlayServicesUtil;

import org.jivesoftware.smack.SmackConfiguration;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import m.client.push.library.PushManager;
import m.client.push.library.common.PushConfigInfo;
import m.client.push.library.common.PushConstants;
import m.client.push.library.common.PushConstantsEx;
import m.client.push.library.utils.PushUtils;

/**
 * IntroAct
 *
 * @author subi78 인트로 Activity
 */

public class IntroAct extends Activity implements OnClickListener {
	public MyApp App = MyApp.getInstance();
	private final int HANDLER_WHAT_NEXTPAGE = 0;
	private final int HANDLER_DELEYTIME = 0;

	private final int PERMISSION_CHECK = 10000;

	public static final String ID_MDN = "MDN";
	public static final String ID_APP_ID = "APPID";
	public static final String ID_AUTH_KEY = "authKey";
	public static final String ID_COMPANY_CD = "companyCd";
	public static final String ID_ENC_PWD = "encPwd";

	private String m_strTimeStamp = "";

	private ArrayList<UserListData> m_arrAddedFellowListData = null;

	SharedPref pref;

	private CommonPopup m_Popup = null;

	private ProgressDlg m_Progress = null;

	private String m_strGetIntentFromApp = null;
	private int m_nGetIntentFriendNo = -1;
	private String m_strGetIntentGid = null;

	private String[] m_strsGetIntentGroupUserList = null;
	private int m_nGetIntentGroupUserListSize = -1;

	private int m_nSNSGroupId = -1;
	private int m_nSNSBoardId = -1;
	private int m_nSNSReplyId = -1;

	// 방이 하나도 없을 시 서버에 방 목록 요청을 위함
	public XmppConnectionService mService; // 연결 타입 서비스
	public boolean mBound = false; // 서비스 연결 여부

	private BroadcastReceiver mRegistrationBroadcastReceiver;

	private BroadcastReceiver mLoginBroadcastReceiver;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		/*if(!AppSetting.FEATURE_DEBUG){
			Kit[] kits = new Kit[]{new Answers(), new Crashlytics()};
			Fabric.with(this, kits);
		} else {

		}*/

		setContentView(R.layout.act_intro);

		Locale systemLocale = getApplicationContext().getResources().getConfiguration().locale;
		App.m_strLocale = systemLocale.getLanguage();
		registBroadcastReceiver();

		if(AppSetting.FEATURE_PERSONA){
			Intent shortcutIntent = new Intent(Intent.ACTION_MAIN);
			shortcutIntent.addCategory("com.sktelecom.ssm.category.LAUNCHER");
			shortcutIntent.setClassName(this, IntroAct.class.getName());
			shortcutIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
			Intent intent = new Intent();
			intent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, shortcutIntent);
			intent.putExtra(Intent.EXTRA_SHORTCUT_NAME, getString(R.string.app_name));
			intent.putExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, Intent.ShortcutIconResource.fromContext(this, R.drawable.ic_launcher));
			intent.putExtra("duplicate", false); intent.setAction("com.sktelecom.ssm.action.launcher.INSTALL_SHORTCUT");
			sendBroadcast(intent);
		}
		// Push Popup이 떠있으면 내리자
		if (PushPopupScreenOffAct.m_Instance != null)
			PushPopupScreenOffAct.m_Instance.finish();

		AssetManager am = getAssets();
		InputStream in = null;
		try {
			in = am.open("smack.xml");
		} catch (IOException e) {
			e.printStackTrace();
		}
		SmackConfiguration.setConfigFileStream(in);
		checkIntent(getIntent());

		// StrictMode.setThreadPolicy(new
		// StrictMode.ThreadPolicy.Builder().detectDiskReads().detectDiskWrites().detectNetwork().penaltyLog().build());

		pref = SharedPref.getInstance(IntroAct.this);

		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
			TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

			String strMdn = tm.getLine1Number();
			if("null".equals(strMdn) || strMdn == null || strMdn.isEmpty()){
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVEPOPUP_PERMISSION_FAIL);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.no_mdn).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			} else {
				App.m_Mdn = tm.getLine1Number();
				doStart();
			}
		} else {
			PermissionCheck.checkAllPermission(this, PERMISSION_CHECK);
		}
		//doStart();
		//PermissionCheck.checkPermission(this, PermissionCheck.PERMISSION_CODE_CAMERA);
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		if(requestCode == PERMISSION_CHECK){
			boolean isAllPermissionsGrant = true;
			for(int i = 0; i < grantResults.length; i++){

				if(PermissionCheck.ALL_PERMISSION_GRANT.equals(permissions[i])){
					break;
				}
				if(grantResults[i] == -1){
					isAllPermissionsGrant = false;
					break;
				}
			}

			if(isAllPermissionsGrant){
				if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
					TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

					String strMdn = tm.getLine1Number();
					if("null".equals(strMdn) || strMdn == null || strMdn.isEmpty()){
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVEPOPUP_PERMISSION_FAIL);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.no_mdn).toString());
						m_Popup.setCancelable(false);
						m_Popup.show();
					} else {
						App.m_Mdn = tm.getLine1Number();
						doStart();
					}
				}

			} else {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVEPOPUP_PERMISSION_FAIL);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.permission_fail).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
		}
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
		if (mLoginBroadcastReceiver != null) {
			this.unregisterReceiver(mLoginBroadcastReceiver);
			mLoginBroadcastReceiver = null;
		}
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
		super.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
				new IntentFilter(QuickstartPreferences.REGISTRATION_READY));
		LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
				new IntentFilter(QuickstartPreferences.REGISTRATION_GENERATING));
		LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
				new IntentFilter(QuickstartPreferences.REGISTRATION_COMPLETE));

	}

	private void checkIntent(Intent intent) {
		m_strGetIntentFromApp = intent.getStringExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP);
		m_nGetIntentFriendNo = intent.getIntExtra(IntentKeyString.INTENT_KEY_INTRO_FRIENDNO, -1);
		m_strGetIntentGid = intent.getStringExtra(IntentKeyString.INTENT_KEY_INTRO_GROUPID);
		m_strsGetIntentGroupUserList = intent.getStringArrayExtra(IntentKeyString.INTENT_KEY_INTRO_USERNO_LIST);
		m_nGetIntentGroupUserListSize = intent.getIntExtra(IntentKeyString.INTENT_KEY_INTRO_USERNO_SIZE, -1);
		m_nSNSGroupId = intent.getIntExtra(IntentKeyString.INTENT_KEY_INTRO_SNSGROUPID, -1);
		m_nSNSBoardId = intent.getIntExtra(IntentKeyString.INTENT_KEY_INTRO_SNSBOARDID, -1);
		m_nSNSReplyId = intent.getIntExtra(IntentKeyString.INTENT_KEY_INTRO_SNSREPLYID, -1);
	}

	private void doStart() {
		handlerNextPage.sendEmptyMessageDelayed(HANDLER_WHAT_NEXTPAGE, HANDLER_DELEYTIME);
	}

	Handler handlerNextPage = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			if (msg.what == HANDLER_WHAT_NEXTPAGE) {
				doProvisioning();
				//doVersionCheck();
			}

			super.handleMessage(msg);
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		CommonLog.e("onClick", "" + v.getId());

		if (v.getId() == R.id.ib_pop_cancel) {
			CommonLog.e("onClick", "CANCEL : " + v.getId());
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			if (popup_cancel.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION) {
				popup_cancel.cancel();
				if (AppSetting.FEATURE_VARIANT.equals("R"))
					new ReqGMPInfoTask().execute(null, null, null);
				else {

					m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

					if (m_strTimeStamp.equals("")) {
						CommonLog.e(getClass(), "First UserList DB insert");
						setAllAlarmOnOff();
					} else {
						CommonLog.e(getClass(), "UserList DB update");
						requestUpdateUserList(m_strTimeStamp);
					}
				}

			} else if(popup_cancel.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION_PARTNER_FIRST){
				popup_cancel.cancel();
				doPartnerLogin();

			} else if(popup_cancel.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE){
				popup_cancel.cancel();
				finish();
			}
			else {
				popup_cancel.cancel();
				finish();
			}
		} else if (v.getId() == R.id.ib_pop_ok) {
			Intent intent;
			CommonLog.e("onClick", "OK : " + v.getId());
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_HTTP_SERVER_UNAUTHORIZED) {
				popup_ok.cancel();
				App.initPartnerLogin(this);
			} else if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_APP_FINISH) {
				popup_ok.cancel();
				finish();
			} else if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION || popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION_PARTNER_FIRST) {
				popup_ok.cancel();
				CommonLog.e("", "update..... gogo");
				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					// 버전 업데이트 처리
					try {
						intent = new Intent("com.sk.pe.group.store.detail"); // GMP
																				// 스마트폰
																				// 스토어의
																				// 상세화면
						// Intent intent = new
						// Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿
						// 스토어의 상세화면

						intent.putExtra("APP_ID", App.m_AppID); // 대상 어플 아이디
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // Activity
																			// 남기지
																			// 않음
						startActivity(intent);
						finish();
					} catch (ActivityNotFoundException e) {
						intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
						startActivity(intent);
						finish();
					}
				} else {
					intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
					startActivity(intent);
					finish();
				}
			} else if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE){
				popup_ok.cancel();
				requestMigrateMobile();
			}
			else {
				popup_ok.cancel();
			}

		} else if (v.getId() == R.id.ib_pop_ok_long) {
			Intent intent;
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
				popup_ok_long.cancel();

				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					finish();
				} else {
					App.m_PartnerPW = "";
					SharedPref pref = SharedPref.getInstance(this);
					pref.setStringPref(SharedPref.PREF_PARTNER_PW, "");
					pref.setStringPref(SharedPref.PREF_COOKIE, "");
					intent = new Intent(this, PartnerLoginAct.class);
					startActivityForResult(intent, StaticString.REQUESTCODE_PARTNERLOGIN);
				}
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					//finish();
					App.initPartnerLogin(this);
					finish();
				} else {
					App.m_PartnerID = "";
					App.m_PartnerPW = "";
					App.m_EntryData = null; // 로그인 정보
					App.m_arrFellowListData = null;
					App.m_arrDepartmentUserListData = null;
					// App.m_arrPartnerSearchListData = null;
					App.m_arrSearchListCheckData = null;
					App.m_MyUserInfo = null;
					App.m_arrRoomUserList = null;
					App.m_arrRegularSearchListDatas = null;

					SharedPref pref = SharedPref.getInstance(this);
					pref.deletePreferences();

					TTalkDBManager.initTTalkDB(this);
					intent = new Intent(this, PartnerLoginAct.class);
					startActivityForResult(intent, StaticString.REQUESTCODE_PARTNERLOGIN);
				}
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_APP_FINISH) {
				popup_ok_long.cancel();
				finish();
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION) {
				popup_ok_long.cancel();
				CommonLog.e("", "update..... gogo");
				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					// 버전 업데이트 처리
					try {
						intent = new Intent("com.sk.pe.group.store.detail"); // GMP
																				// 스마트폰
																				// 스토어의
																				// 상세화면
						// Intent intent = new
						// Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿
						// 스토어의 상세화면

						intent.putExtra("APP_ID", App.m_AppID); // 대상 어플 아이디
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // Activity
																			// 남기지
																			// 않음
						startActivity(intent);
						finish();
					} catch (ActivityNotFoundException e) {
						intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
						startActivity(intent);
						finish();
					}
				} else {
					intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
					startActivity(intent);
					finish();
				}
			} else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_XMPP_ERROR){
				popup_ok_long.cancel();
				finish();
			} else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVEPOPUP_PERMISSION_FAIL){
				popup_ok_long.cancel();;
				finish();
			}

			else
				popup_ok_long.cancel();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		if (requestCode == 1007) {
			AuthUtil.m_isRunGMPLogin = false;
			if (resultCode == Activity.RESULT_OK) {
				Toast.makeText(IntroAct.this, "로그인 되었습니다", Toast.LENGTH_SHORT).show();
				new ReqVersionInfoTask().execute(null, null, null);
				 //new ReqGMPInfoTask().execute(null,null,null);

			} else {
				finish();
			}
		} else if (requestCode == StaticString.REQUESTCODE_REGULARLOGIN) {
			if (resultCode == Activity.RESULT_OK) {
				doUserListSync();
			} else if (resultCode == Activity.RESULT_CANCELED) {
				finish();
			}
		} else if (requestCode == StaticString.REQUESTCODE_PARTNERLOGIN) {
			if (resultCode == Activity.RESULT_OK) {
				try {
					LocalAesCrypto crypto = new LocalAesCrypto(KeystoreCrypto.getKey(this));
					String strEncryptId = crypto.encrypt(App.m_PartnerID);
					String strEncryptPwd = crypto.encrypt(App.m_PartnerPW);
					pref.setStringPref(SharedPref.PREF_PARTNER_ID, strEncryptId);
					pref.setStringPref(SharedPref.PREF_PARTNER_PW, strEncryptPwd);
					CommonLog.e("", "Aes ID : " + strEncryptId);
					CommonLog.e("", "Aes PW : " + strEncryptPwd);

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				doPartnerVersionCheck();
				//doUserListSync();
			} else if (resultCode == Activity.RESULT_CANCELED) {
				finish();
			}
		}
		else if (requestCode == StaticString.REQUESTCODE_TUTORIAL) {
			/*if (AppSetting.FEATURE_VARIANT == "R")
				requestGetPartnerApprovalList();
			else
			{
//				startNextActivity();
				checkDatabase();
			}*/
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	/* Provisioning
	 *
	 */
	private void doProvisioning() {
		GetProvisioningReq req = new GetProvisioningReq();

		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				showProgress("");
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				closeProgress();
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
				m_Popup.setCancelable(false);
				m_Popup.show();
			}

			@Override
			public void onPostRequest(String a_strData) {
				GetProvisioningRes res = new GetProvisioningRes(a_strData, Res.RES_TYPE_USER_COMPANY);
				App.m_EntryData = new EntryData();
				App.m_EntryData.m_strImageUrlTemplate = res.getUserImageUrlTemplate();
				App.m_EntryData.m_strPreviewImageUrlTemplate = res.getUserPreviewImageUrlTemplate();
				App.m_EntryData.m_arrCompanyData = res.getCompanies();

				doVersionCheck();
			}
		});
	}
	/*
	 * Version Check
	 */
	private void doVersionCheck() {

		// Version check 끝난 후에 정회원만 GMP로그인
		if (AppSetting.FEATURE_VARIANT.equals("R"))
			doGMPLogin();
		else{
			try {
				LocalAesCrypto crypto = new LocalAesCrypto(KeystoreCrypto.getKey(this));
				App.m_PartnerID = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_ID, ""));
				App.m_PartnerPW = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_PW, ""));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			CommonLog.e("aaa", "m_PartnerID 3: " + App.m_PartnerID);
			CommonLog.e("aaa", "m_PartnerPW 3: " + App.m_PartnerPW);
			// ID,PW가 저장이 안되어 있으면 로그인 화면으로
			if (App.m_PartnerID.equals("") || App.m_PartnerPW.equals("")) {

				Intent intent = new Intent(this, PartnerLoginAct.class);
				startActivityForResult(intent, StaticString.REQUESTCODE_PARTNERLOGIN);
			} else {
				// 아이디 pw 있으면 자동 로그인 처리
				//App.expirePartnerLogin(this);
			doPartnerVersionCheck();
			}
			//doPartnerLogin();
		}

	}

	/*
	 * GMPLogin
	 */
	private void doGMPLogin() {

		// GMP 인증
		if (!AuthUtil.isLogin(IntroAct.this, App.m_Mdn, App.m_AppID)) {
			AuthUtil.m_isRunGMPLogin = false;
			AuthUtil.runGMPLogin(IntroAct.this);
		} else {
			new ReqVersionInfoTask().execute(null, null, null);
			// new ReqGMPInfoTask().execute(null,null,null);
		}

		// 최초 실행일 경우 프로필 입력 화면으로

		// 자동로그인 처리 후
		// doUserListSync();
	}
	/*
         * 파트너 로그인
         */
	private void doPartnerVersionCheck() {
		GetAppVersionReq req = new GetAppVersionReq();

		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

					SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
					if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					} else {
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (AppSetting.FEATURE_VARIANT.equals("R") && a_nErrorCode == ApiResult.HTTP_SERVER_NOT_JOIN) {
					Intent intent = new Intent(IntroAct.this, RegularSignUpAct.class);
					startActivityForResult(intent, StaticString.REQUESTCODE_REGULARLOGIN);
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}

			@Override
			public void onPostRequest(String a_strData) {
				GetAppVersionRes res = new GetAppVersionRes(a_strData);
				String strLatest = res.getLatestVersion();
				App.m_EntryData.m_strLatestVersion = strLatest;
				int nUpdateType = Utils.CheckVersion(IntroAct.this, strLatest);
				if (nUpdateType == 1) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
					m_Popup.setCancelable(false);
					m_Popup.show();
					return;
				} else if (nUpdateType == 2) {
					if (!pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(strLatest)) {
						pref.setStringPref(SharedPref.PREF_GMP_VERSION, strLatest);
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION_PARTNER_FIRST);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.update_version).toString());
						m_Popup.setCancelable(false);
						m_Popup.show();
						return;
					}
				}
				doPartnerLogin();
			}
		});

	}
	/*
	 * 파트너 로그인
	 */
	private void doPartnerLogin() {
		try {
			LocalAesCrypto crypto = new LocalAesCrypto(KeystoreCrypto.getKey(this));
			App.m_PartnerID = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_ID, ""));
			App.m_PartnerPW = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_PW, ""));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CommonLog.e("aaa", "m_PartnerID 3: " + App.m_PartnerID);
		CommonLog.e("aaa", "m_PartnerPW 3: " + App.m_PartnerPW);
		// ID,PW가 저장이 안되어 있으면 로그인 화면으로
		if (App.m_PartnerID.equals("") || App.m_PartnerPW.equals("")) {

			Intent intent = new Intent(this, PartnerLoginAct.class);
			startActivityForResult(intent, StaticString.REQUESTCODE_PARTNERLOGIN);
		} else {
			// 아이디 pw 있으면 자동 로그인 처리
			//App.expirePartnerLogin(this);
			requestEntry();
		}
	}

	/*
	 * 사용자 목록 조회 및 Update
	 */

	private void doUserListSync() {

		showProgress("");
		String format = new String("yyyyMMddHH");
		SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.KOREA);
		CommonLog.e(getClass().getSimpleName(), "Now Time : " + sdf.format(new Date()));

		SharedPref pref = SharedPref.getInstance(IntroAct.this);
		pref.setStringPref(SharedPref.PREF_LOGIN_TIME, sdf.format(new Date()));
		if (!AppSetting.FEATURE_VARIANT.equals("R")) {

			int nUpdateType = Utils.CheckVersion(IntroAct.this, App.m_EntryData.m_strLatestVersion);
			if (nUpdateType == 1) {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
				return;
			} else if (nUpdateType == 2) {
				if (!pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(App.m_EntryData.m_strLatestVersion)) {
					pref.setStringPref(SharedPref.PREF_GMP_VERSION, App.m_EntryData.m_strLatestVersion);
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.update_version).toString());
					m_Popup.setCancelable(false);
					m_Popup.show();
					return;
				}
			}
		}

		m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

		if (m_strTimeStamp.equals("")) {
			CommonLog.e(getClass(), "First UserList DB insert");
			setAllAlarmOnOff();
		} else {
			CommonLog.e(getClass(), "UserList DB update");
			requestUpdateUserList(m_strTimeStamp);
		}
	}

	public void requestEntry() {
		showProgress(getString(R.string.progress_entry).toString());
		GetEntryReq req = new GetEntryReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetEntryRes res = new GetEntryRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				/*App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate,
						res.m_strPreviewImageUrlTemplate,res.m_strEmoticonTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);*/
				//EntryData는 Response 에서 처리중
				App.m_MyUserInfo = res.getEntryUserData(getApplicationContext());
				App.m_EntryData.m_strLol = res.getLOL();
				if(pref.getIntegerPref(SharedPref.PREF_USERNO) != App.m_MyUserInfo.m_nUserNo){
					App.m_arrFellowListData = null;
					App.m_arrDepartmentUserListData = null;
					App.m_arrRoomUserList = null;
					App.m_arrRegularSearchListDatas = null;

					String strBeforCookie = pref.getStringPref(SharedPref.PREF_COOKIE);
					pref.deletePreferences();
					pref.setStringPref(SharedPref.PREF_COOKIE, strBeforCookie);

					TTalkDBManager.initTTalkDB(IntroAct.this);
				}
				pref.setIntegerPref(SharedPref.PREF_USERNO, App.m_MyUserInfo.m_nUserNo);
				//closeProgress();
				if(AppSetting.FEATURE_VARIANT.equals("R")){
//					requestGMPAuth();
					doUserListSync();
				} else {
					doUserListSync();
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

						SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
						if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
						} else {
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
						}


					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (AppSetting.FEATURE_VARIANT.equals("R") && a_nErrorCode == ApiResult.HTTP_SERVER_NOT_JOIN) {
					Intent intent = new Intent(IntroAct.this, RegularSignUpAct.class);
					startActivityForResult(intent, StaticString.REQUESTCODE_REGULARLOGIN);
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	public void setAllAlarmOnOff(){
		PutGroupSettingReq req = new PutGroupSettingReq(0, true, true, true, App.m_MyUserInfo.m_nUserNo);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
				pref.setBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
				pref.setBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
				pref.setBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true);
				requestFirstUserList();

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
		});
	}

	public void requestFirstUserList() {
		//showProgress(getString(R.string.progress_getuselist).toString());
		setProgressText(getString(R.string.progress_getuselist).toString());
		GetUserListReq req = new GetUserListReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);
				if (res.getUserListData() != null) {
					CommonLog.e(getClass(), "DB insert Start");
					int nInsertFail = ContactsDBManager.insertContacts(IntroAct.this, res.getUserListData());
					CommonLog.e(getClass(), "DB insert End Fail[" + nInsertFail + "]");

					pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);
				}
				//closeProgress();
				requestFellowList();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

						SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
						if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
						} else {
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
						}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	public void requestUpdateUserList(String a_strTimeStamp) {
		//showProgress(getString(R.string.progress_getfellowlist));
		setProgressText(getString(R.string.progress_getuselist));
		GetUserListReq req = new GetUserListReq(a_strTimeStamp);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);
				if (res.getUserListData() != null) {
					SparseArray<UserListData> savedUserListData = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
					ArrayList<UserListData> arrInsertUserListData = new ArrayList<UserListData>();
					ArrayList<UserListData> arrUpdateUserListData = new ArrayList<UserListData>();

					for (UserListData data : res.getUserListData()) {
//						UserListData getitem = ContactsDBManager.getContacts(IntroAct.this, data.m_nUserNo);
						UserListData getitem = savedUserListData.get(data.m_nUserNo);
						if (getitem == null) {
							UserListData item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable,
									data.m_isActive, data.m_strGreeting, data.m_strUserStatus, false, "");
//							ContactsDBManager.insertContacts(IntroAct.this, item);
							arrInsertUserListData.add(item);
						} else {
							UserListData item = null;
							if (data.m_strUserStatus.equals("A"))
								item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, getitem.m_strFellowAddTime);
							else
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, "");

//							ContactsDBManager.updateContacts(IntroAct.this, item);
							arrUpdateUserListData.add(item);
						}
					}
					if(arrInsertUserListData.size() > 0 )
						ContactsDBManager.insertContacts(IntroAct.this, arrInsertUserListData);
					if(arrUpdateUserListData.size() > 0 )
						ContactsDBManager.updateContacts(IntroAct.this, arrUpdateUserListData);
				}

				SharedPref pref = SharedPref.getInstance(IntroAct.this);
				pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);

				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					// closeProgress();
					// Intent intent = new Intent(IntroAct.this,
					// MainTabAct.class);
					// startActivity(intent);
					// finish();
					registAOM();
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

						SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
						if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
						} else {
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
						}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	public void requestFellowList() {
		//showProgress(getString(R.string.progress_getfellowlist).toString());
		setProgressText(getString(R.string.progress_getuselist).toString());
		GetFellowListReq req = new GetFellowListReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetFellowListRes res = new GetFellowListRes(a_strData);
				if (res.getFellowList() != null) {

					SparseArray<UserListData> savedUserListData = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
					ArrayList<UserListData> arrUpdateUserListData = new ArrayList<UserListData>();

					for (int nUserNo : res.getFellowList()) {
//						UserListData userData = ContactsDBManager.getContacts(IntroAct.this, data.m_nUserNo);
						UserListData userData = savedUserListData.get(nUserNo);
						if (userData != null && !userData.m_strUserStatus.equals("D")) {
							UserListData item = new UserListData(userData.m_nUserNo, userData.m_PersonalData, userData.m_strUserType, userData.m_isImageAvailable,
									userData.m_isActive, userData.m_strGreeting, "A", true, Utils.getCurrentTime());

							CommonLog.e(getClass(), "m_UserNo : " + userData.m_nUserNo);
							CommonLog.e(getClass(), "m_isImageAvailable : " + userData.m_isImageAvailable);
//							ContactsDBManager.updateContacts(IntroAct.this, item);
							arrUpdateUserListData.add(item);
						}
					}
					if(arrUpdateUserListData.size() > 0)
						ContactsDBManager.updateContacts(IntroAct.this, arrUpdateUserListData);
				}

				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					// closeProgress();
					// Intent intent = new Intent(IntroAct.this,
					// MainTabAct.class);
					// startActivity(intent);
					// finish();
					registAOM();
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

						SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
						if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
						} else {
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
						}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	public void requestMigrateMobile() {
		showProgress();
		PostMigrateMobileReq req = new PostMigrateMobileReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				PostPartnerMigrateMobileRes res = new PostPartnerMigrateMobileRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				/*App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate,
						res.m_strPreviewImageUrlTemplate,res.m_strEmoticonTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);*/
				App.m_MyUserInfo = res.getEntryUserData(getApplicationContext());
				App.m_EntryData.m_strLol = res.getLOL();
				if(pref.getIntegerPref(SharedPref.PREF_USERNO) != App.m_MyUserInfo.m_nUserNo){
					App.m_arrFellowListData = null;
					App.m_arrDepartmentUserListData = null;
					App.m_arrRoomUserList = null;
					App.m_arrRegularSearchListDatas = null;

					String strBeforCookie = pref.getStringPref(SharedPref.PREF_COOKIE);
					pref.deletePreferences();
					pref.setStringPref(SharedPref.PREF_COOKIE, strBeforCookie);

					TTalkDBManager.initTTalkDB(IntroAct.this);
				}
				pref.setIntegerPref(SharedPref.PREF_USERNO, App.m_MyUserInfo.m_nUserNo);
				//closeProgress();
				doUserListSync();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

						SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
						if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
						} else {
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
						}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}

			}
		});
	}

	private ArrayList<FellowListData> setFellowList() throws Exception {
		m_arrAddedFellowListData = TTalkDBManager.ContactsDBManager.getContactsByFellows(this);
		App.m_arrFellowListData = new ArrayList<FellowListData>();
		CommonLog.e("", "setFellowList() lol : " + App.m_EntryData.m_strLol);
		for (UserListData data : m_arrAddedFellowListData) {
			HashMap<String, String> personalData = data.m_PersonalData.mapPersonalData;
			if (data.m_strUserType.equals("R")) {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_NAME),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
						personalData.get(PersonalData.CHARGE), data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			} else {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME), "", "",personalData.get(PersonalData.POSITION),"","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
						data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			}
		}
		return App.m_arrFellowListData;
	}

	//인트로에서 프로그레스 대신 이미지를 보여 주기로 함
	//차후에 원복 될 때를 대비해 메소드 내용에만 주석
	public void showProgress() {
		/*if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}*/
	}

	public void showProgress(String a_strMsg) {

		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);


		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	private void setProgressText(String a_strMsg) {

		if (m_Progress.isShowing()) {
			m_Progress.setText(a_strMsg);
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

	private class ReqGMPInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		String strResultMessage = "";

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			try {
				Map<String, String> map = new HashMap<String, String>();

				CommonLog.e(getClass(), "getGMPAuthPwd start");
				map = AuthUtil.getAuthInfo(IntroAct.this, App.m_Mdn, App.m_AppID);

				CommonLog.e(getClass(), "getGMPAuthPwd end");
				// String secretkeydecrypt = null;
				strResultCode = map.get("result_code");
				strResultMessage = map.get("result_message");
				if (strResultCode.equals("1000")) { // 정상 처리일 경우정상 처리 코드 넣어주시기
													// 바랍니다.
					CommonLog.e(getClass(), "result_code : 1000");
					String strRegularID = "";
					String secretkey = AuthUtil.getSecretKey(IntroAct.this); // 비밀키
																				// 얻어오기
					try {
						strRegularID = SimpleCrypto.decrypt(secretkey, map.get("result_user_num")); // 복호화
					} catch (Exception e) {
						Log.e("TnaMoblieDecrypt", "error");
						Log.e("TnaMoblieDecrypt", "secretkey = " + secretkey);
						Log.e("TnaMoblieDecrypt", "ServerEmpId = " + map.get("result_user_num"));
						strRegularID = "-2"; // 복호화 실패시 아이디 값에 넣어줌
					}

					App.m_GMPData = new GMPData(map.get(ID_COMPANY_CD), strRegularID, map.get(ID_AUTH_KEY), map.get(ID_ENC_PWD));
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (result.equals("1000")) {
				//챗봇을 위한 정직원 GMP 인증정보 등록 과정
				requestEntry();
			} else if (result.equals("7009")) {
				try {
					AuthUtil.logout(IntroAct.this);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					doGMPLogin();
				}
			} else if (result.equals("7004")) {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), strResultMessage);
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
			else if (result.equals("3205")) {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			} else {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
		}
	}

	private void requestGMPAuth(){
		PostGMPAuthReq req = new PostGMPAuthReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

					SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
					if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					} else {
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}

			@Override
			public void onPostRequest(String a_strData) {
				doUserListSync();
			}
		});
	}
	private class ReqVersionInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		String strAppVersion = "";
		String strResultMessage = "";

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			try {
				Map<String, String> map = new HashMap<String, String>();

				CommonLog.e(getClass(), "getVersionInfo start");
				map = AuthUtil.getVersionInfo(IntroAct.this, App.m_Mdn, App.m_AppID);

				CommonLog.e(getClass(), "getVersionInfo end");
				// String secretkeydecrypt = null;
				strResultCode = map.get("result");
				strResultMessage = map.get("result_message");
				if (strResultCode.equals("1000")) { // 정상 처리일 경우정상 처리 코드 넣어주시기
													// 바랍니다.
					CommonLog.e(getClass(), "result : 1000");
					strAppVersion = map.get("appVer");
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (result.equals("1000")) {
				if (strAppVersion.equals("")) {
					new ReqGMPInfoTask().execute(null, null, null);
				} else {
					SharedPref pref = SharedPref.getInstance(IntroAct.this);
					int nUpdateType = Utils.CheckVersion(IntroAct.this, strAppVersion);
					if (nUpdateType == 2 && !pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(strAppVersion)) {
						pref.setStringPref(SharedPref.PREF_GMP_VERSION, strAppVersion);
						m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.update_version).toString());
						m_Popup.setCancelable(false);
						m_Popup.show();
					} else {
						new ReqGMPInfoTask().execute(null, null, null);
					}
				}
			} else if (result.equals("7009")) {
				try {
					AuthUtil.logout(IntroAct.this);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					doGMPLogin();
				}
			} else if (result.equals("7004")) {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), strResultMessage);
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
			else if (result.equals("3205")) {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			} else {
				m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			}
		}
	}

	private class CheckDatabaseTask extends AsyncTask<Void, Void, Void>
	{

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			deleteOldChatMessageProcess();

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			boolean isEncryptChatMessage = pref.getBooleanPref(SharedPref.PREF_ISENCRYPTCHATMESSAGE, false);
			if(isEncryptChatMessage)
				getSNSAlarm();
			else
				startEncryptChattingMessageTask();
		}
	}

	private class EncryptChattingMessageTask extends AsyncTask<Void, String, Void>
	{
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub

			//m_Progress.cancel();
			//m_Progress = null;

			//showProgress(getString(R.string.progress_encrypt) + "(0%)"); 
			setProgressText(getString(R.string.progress_encrypt) + "(0%)");
			super.onPreExecute();
		}

		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub
			setProgressText(values[0]);
			super.onProgressUpdate(values);
		}

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
//			CommonLog.e(getClass(), "Encrypt StartTime : " + System.currentTimeMillis());
			boolean isEncryptChatMessage = pref.getBooleanPref(SharedPref.PREF_ISENCRYPTCHATMESSAGE, false);
			if(!isEncryptChatMessage)
			{
				ChattingDBManagerForDelayMessage db = new ChattingDBManagerForDelayMessage(IntroAct.this);

				ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(IntroAct.this);
				int i = 0;
				for(ChattingRoomInfoData data : arrRoomData)
				{
					ArrayList<ChattingMessageData> arrChattingMsgData = db.getChattingMessage(data.m_strRoomId);
//					CommonLog.e(IntroAct.class.getSimpleName(), "Msg Size : " + arrChattingMsgData.size());
					db.deleteChattingMessage(data.m_strRoomId);

//					CommonLog.e(IntroAct.class.getSimpleName(), "Msg Insert Start");
					for(ChattingMessageData msgData : arrChattingMsgData)
					{
						db.insertChattingMessage(data.m_strRoomId, msgData);
					}
					double dProgress = (double)++i / (double)arrRoomData.size();
					int nProgress = (int)(dProgress * 100);
					String strProgress = getString(R.string.progress_encrypt) + "(" + nProgress + "%)";
					CommonLog.e(IntroAct.class.getSimpleName(), "Encrypt Progress :" + strProgress);
					publishProgress(strProgress);
//					CommonLog.e(IntroAct.class.getSimpleName(), "Msg Insert End");
				}

				db.end();
				pref.setBooleanPref(SharedPref.PREF_ISENCRYPTCHATMESSAGE, true);
			}
//			CommonLog.e(getClass(), "Encrypt EndTime : " + System.currentTimeMillis());
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
//			m_Progress.cancel();
//			m_Progress = null;
//			
//			showProgress();
			getSNSAlarm();
		}
	}

	private void checkDatabase()
	{
		CheckDatabaseTask task = new CheckDatabaseTask();
		task.execute();
	}

	private void startEncryptChattingMessageTask()
	{
		EncryptChattingMessageTask task = new EncryptChattingMessageTask();
		task.execute();
	}

	private void deleteOldChatMessageProcess()
	{
		TTalkDBManager.checkTTalkDB(this);

		// 한달 이후 메시지 삭제하기
//		long lnSaved1MonthBeforeTime = pref.getLongPref(SharedPref.PREF_1MONTHBEFORETIME, 0);
		long lnLastDeletedMS = pref.getLongPref(SharedPref.PREF_1MONTHBEFORETIME, 0);
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		long lnNowMS = calendar.getTimeInMillis();

		if(lnNowMS > lnLastDeletedMS)
		{
			CommonLog.e(getClass(), "Delete Message!!!!!");
			int nSaveChatMsgTerm = pref.getIntegerPref(SharedPref.PREF_SAVECHATMESSAGETERM, StaticString.CHATMESSAGETERM_3WEEKBEFORE);
			int nBeforeDay = 21;

			if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3WEEKBEFORE)
				nBeforeDay = 21;
			else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_2WEEKBEFORE)
				nBeforeDay = 14;
			else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_1WEEKBEFORE)
				nBeforeDay = 7;
			else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3DAYBEFORE)
				nBeforeDay = 3;

			Calendar calendarBefore = Calendar.getInstance();
			calendarBefore.set(Calendar.DAY_OF_MONTH, calendarBefore.get(Calendar.DAY_OF_MONTH) - nBeforeDay);
			calendarBefore.set(Calendar.HOUR, 0);
			calendarBefore.set(Calendar.MINUTE, 0);
			calendarBefore.set(Calendar.SECOND, 0);
			calendarBefore.set(Calendar.MILLISECOND, 0);

			long lnEditTime = calendarBefore.getTimeInMillis();

			ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(IntroAct.this);
			for(ChattingRoomInfoData data : arrRoomData)
			{
				ChattingDBManager dbManager = new ChattingDBManager(IntroAct.this);
				dbManager.openWritable(data.m_strRoomId);
				dbManager.deleteChattingMessageTimeAfter(lnEditTime);
				dbManager.close();
			}
			pref.setLongPref(SharedPref.PREF_1MONTHBEFORETIME, lnNowMS);
		}

		//TakeMediaIntent가 사용되는 Activity들은 onDestroy에서 이 과정을 수행 한다.
		//앱이 강제 종료 되거나 하여 제대로 삭제가 되지 않았을때 동작 하게 하기 위함
		File path = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES).getPath());
		if(path.isDirectory()){
			File[] childFileList = path.listFiles();
			for(File childFile : childFileList){
				childFile.delete();
			}
			path.delete();
		}
	}

	private void getSNSAlarm()
	{

		/*final SharedPref pref = SharedPref.getInstance(this);
		boolean isSNSGroupFirstSync = pref.getBooleanPref(SharedPref.PREF_SNSGROUP_FIRSTSYNC, false);
		PostGroupAlarmReq req = null;
		if(!isSNSGroupFirstSync)
		{
			req = new PostGroupAlarmReq();
		}
		else
		{
			SparseBooleanArray arrMyGroup = SNSGroupDBManager.getMyGroupInfo(this);
			SparseArray<String> arrGroupAlarmLastTimestamp = new SparseArray<String>();

			int nMyGroupSize = arrMyGroup.size();
			for(int i = 0 ; i < nMyGroupSize; i++)
			{
				int nGroupId = arrMyGroup.keyAt(i);
				String strUpdatedDate = SNSGroupDBManager.getLastAlarmUpdatedDate(this, nGroupId);
				arrGroupAlarmLastTimestamp.append(nGroupId, strUpdatedDate);
			}

			if(arrGroupAlarmLastTimestamp.size() > 0)
			{
				ArrayList<String> arrUnReadBoardAndReplyNos = SNSGroupDBManager.getUnReadBoardAndReplyNos(this);
				req = new PostGroupAlarmReq(arrGroupAlarmLastTimestamp, arrUnReadBoardAndReplyNos);
			}
		}

		if(req != null)
		{
			WebAPI api = new WebAPI(this);
			api.request(req, new WebListener() {

				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub

				}

				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub

					CommonLog.e(getClass(), "getAlarmData : " + a_strData);
					PostGroupAlarmRes res = new PostGroupAlarmRes(a_strData);
					ArrayList<SNSAlarmData> arrSNSAlarmData = res.getSNSAlarmList();
					ArrayList<Integer> arrReadBoardAndReadNos = res.getReadBoardAndReadNos();
					SNSGroupDBManager.insertSNSAlarm(IntroAct.this, arrSNSAlarmData);
					if(arrReadBoardAndReadNos != null && arrReadBoardAndReadNos.size() > 0)
					{
						SNSGroupDBManager.updateSNSReadBoardAndReply(IntroAct.this, arrReadBoardAndReadNos);
					}
					SNSGroupDBManager.deleteSNSAlarmBefore2Week(IntroAct.this);
					SNSGroupDBManager.deleteSNSAlarmPushType(IntroAct.this);
					pref.setBooleanPref(SharedPref.PREF_SNSGROUP_FIRSTSYNC, true);

					int nBoardNoReadCount = SNSGroupDBManager.getNoBoardReadCount(IntroAct.this);
					SharedPref pref = SharedPref.getInstance(IntroAct.this);
					//int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, 0);
					int nUpdateBadgeCount = nBoardNoReadCount;
					if(nUpdateBadgeCount < 0){
						nUpdateBadgeCount = 0;
					}
					pref.setIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, nUpdateBadgeCount);
					IconBadge.updateIconBadge(IntroAct.this);
//					registAOM();
					startNextActivity();
				}

				@Override
				public void onNetworkError(int nErrorCode, String strMessage) {
					// TODO Auto-generated method stub
//					registAOM();
					startNextActivity();

				}
			});
		}
		else
		{
//			registAOM();
			startNextActivity();

		}*/
		startNextActivity();
	}

	private void getBackUpCheck()
	{
		GetBackUpCheckReq req = new GetBackUpCheckReq();
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetBackUpCheckRes res = new GetBackUpCheckRes(a_strData);

				if(res.getResult().equals("true")) {
					FileDownload filedown = new FileDownload(IntroAct.this, res.getBackupURL());
					filedown.startBackUpDownload(new FileDownload.OnDownloadComplete() {

						@Override
						public void onProgess(int a_nCount, int a_nTotal) {
							// TODO Auto-generated method stub

						}

						@Override
						public void onStart() {

						}

						@Override
						public void onDownloadFail() {
							// TODO Auto-generated method stub

						}

						@Override
						public void onComplete(String a_strFilePath) {
							// TODO Auto-generated method stub
							File file = new File(a_strFilePath);
							String strJson = null;
							if(file.exists()){
								try {
									BufferedReader jsonRead = new BufferedReader(new FileReader(file));
									FileInputStream fileInputStream = new FileInputStream(file);
									if(fileInputStream != null) {
										jsonRead = new BufferedReader(new InputStreamReader(fileInputStream));
										StringBuffer buf = new StringBuffer();
										String strTemp = "";
										while((strTemp = jsonRead.readLine()) != null){
											buf.append(strTemp);
										}
										strJson = buf.toString();
										fileInputStream.close();
									}

								} catch (FileNotFoundException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}

							DoRestoreTask task = new DoRestoreTask();
							task.execute(strJson);

						}
					});
				}
				else{
					getContacts();
					CommonLog.e(getClass().getSimpleName(), "Intro Act : Go MainTabAct");
					Intent intent = new Intent(IntroAct.this, MainTabAct.class);
					startActivity(intent);
					closeProgress();
					finish();
				}

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				getContacts();
				CommonLog.e(getClass().getSimpleName(), "Intro Act : Go MainTabAct");
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				startActivity(intent);
				closeProgress();
				finish();
			}
		});
	}

	private void getBackUpUrl()
	{
		GetBackUpUrlReq req = new GetBackUpUrlReq();
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetBackUpUrlRes res = new GetBackUpUrlRes(a_strData);
				FileDownload filedown = new FileDownload(IntroAct.this, res.getResultUrl());
				filedown.startBackUpDownload(new FileDownload.OnDownloadComplete() {

					@Override
					public void onProgess(int a_nCount, int a_nTotal) {
						// TODO Auto-generated method stub

					}

					@Override
					public void onStart() {

					}

					@Override
					public void onDownloadFail() {
						// TODO Auto-generated method stub

					}

					@Override
					public void onComplete(String a_strFilePath) {
						// TODO Auto-generated method stub
						File file = new File(a_strFilePath);
						String strJson = null;
						if(file.exists()){
						try {
							BufferedReader jsonRead = new BufferedReader(new FileReader(file));
							FileInputStream fileInputStream = new FileInputStream(file);
							if(fileInputStream != null) {
								jsonRead = new BufferedReader(new InputStreamReader(fileInputStream));
								StringBuffer buf = new StringBuffer();
								String strTemp = "";
								while((strTemp = jsonRead.readLine()) != null){
									buf.append(strTemp);
								}
								strJson = buf.toString();
								fileInputStream.close();
							}

						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						}

						DoRestoreTask task = new DoRestoreTask();
						task.execute(strJson);

					}
				});

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				getContacts();
				CommonLog.e(getClass().getSimpleName(), "Intro Act : Go MainTabAct");
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				startActivity(intent);
				closeProgress();
				finish();
			}
		});
	}

	private class DoRestoreTask extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			//closeProgress();
			//m_Progress = null;
			//showProgress(getString(R.string.progress_restore_backup));
			setProgressText(getString(R.string.progress_restore_backup));
		}

		@Override
		protected Void doInBackground(String... params) {
			// TODO Auto-generated method stub
			IntroBackUp backUp = new IntroBackUp(IntroAct.this, params[0]);
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			DeleteBackUpReq req = new DeleteBackUpReq();
			WebAPI webApi = new WebAPI(IntroAct.this);
			webApi.request(req, new WebListener() {

				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub

				}

				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub
					pref.setBooleanPref(SharedPref.PREF_BACKUP_RESTORE, false);
					getContacts();
					CommonLog.e(getClass().getSimpleName(), "Intro Act : Delete Back Up and Go MainTabAct");
					Intent intent = new Intent(IntroAct.this, MainTabAct.class);
					startActivity(intent);
					closeProgress();
				}

				@Override
				public void onNetworkError(int nErrorCode, String strMessage) {
					// TODO Auto-generated method stub
					getContacts();
					CommonLog.e(getClass().getSimpleName(), "Intro Act : Go MainTabAct");
					Intent intent = new Intent(IntroAct.this, MainTabAct.class);
					startActivity(intent);
					closeProgress();
				}
			});


			finish();
		}
	}

	private void registAOM() {

		getInstanceIdToken();

	}


	public void getInstanceIdToken() {
		if (checkPlayServices()) {
			// Start IntentService to register this application with GCM.
			Intent intent = new Intent(this, RegistrationIntentService.class);
			startService(intent);
		} else {
			//startCheckDatabase();
		}
	}

	/**
	 * Google Play Service를 사용할 수 있는 환경이지를 체크한다.
	 */
	public boolean checkPlayServices() {
		GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
		int resultCode = googleAPI.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (googleAPI.isUserResolvableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, this,
						9000).show();
			} else {
				finish();
			}
			return false;
		}
		return true;
	}

	public void registBroadcastReceiver(){
		mRegistrationBroadcastReceiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context context, Intent intent) {
				String action = intent.getAction();

				if(action.equals(QuickstartPreferences.REGISTRATION_READY)){
					// 액션이 READY일 경우

				} else if(action.equals(QuickstartPreferences.REGISTRATION_GENERATING)){
					// 액션이 GENERATING일 경우

				} else if(action.equals(QuickstartPreferences.REGISTRATION_COMPLETE)){
					// 액션이 COMPLETE일 경우


					PushManager.getInstance().initPushServer(getApplicationContext());
					TelephonyManager telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
					String strDeviceid = telephony.getDeviceId();
					//PushManager.getInstance().registerPushService(getApplicationContext());
					JSONObject params = new JSONObject();
					try {
						params.put(PushConstants.KEY_CUID, "" + App.m_MyUserInfo.m_strUserId);
						params.put(PushConstants.KEY_CNAME, App.m_MyUserInfo.m_strName);
						params.put(PushConstants.KEY_DEVICE_ID, strDeviceid);
					} catch (JSONException e) {
						e.printStackTrace();
					}

					PushManager.getInstance().registerServiceAndUser(getApplicationContext(), params);

					registerReceiver();

					String token = intent.getStringExtra("token");
					//requestChangePushToken(PushManager.getInstance().getPushPsid(getApplicationContext()));
					requestChangePushToken(token, PushManager.getInstance().getPushPsid(getApplicationContext()));
				}

			}
		};
	}

	public void registerReceiver() {
		if (mLoginBroadcastReceiver != null) {
			return;
		}

		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(this.getPackageName()  + PushConstantsEx.ACTION_COMPLETED);

		mLoginBroadcastReceiver = new BroadcastReceiver() {

			@Override
			public void onReceive(Context context, Intent intent) {

				if(!PushUtils.checkValidationOfCompleted(intent, context)){
					return;
				}

				//intent 정보가 정상적인지 판단
				String result = intent.getExtras().getString(PushConstants.KEY_RESULT);
				String bundle = intent.getExtras().getString(PushConstantsEx.KEY_BUNDLE);

				JSONObject result_obj = null;
				String resultCode = "";
				String resultMsg = "";
				try {
					result_obj = new JSONObject(result);
					resultCode = result_obj.getString(PushConstants.KEY_RESULT_CODE);
					resultMsg = result_obj.getString(PushConstants.KEY_RESULT_MSG);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				//Action에 따라 분기 (이미 서비스 등록이 된 경우 다음 process 이동)
				if(bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.REG_USER)) {
					if (resultCode.equals(PushConstants.SUCCESS_RESULT_CODE)) {
						//Toast.makeText(context, "로그인 성공!", Toast.LENGTH_SHORT).show();
						//setSendTest();
					}else {
						//Toast.makeText(context, "[LoginActivity] error code: " + resultCode + " msg: " + resultMsg, Toast.LENGTH_SHORT).show();
					}
				}else if (bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.UNREG_PUSHSERVICE)) {

					if (resultCode.equals(PushConstants.SUCCESS_RESULT_CODE)) {
						//Toast.makeText(context, "해제 성공!", Toast.LENGTH_SHORT).show();
					}else {

						//Toast.makeText(context, "[LoginActivity] error code: " + resultCode + " msg: " + resultMsg, Toast.LENGTH_SHORT).show();
					}
				}else if (bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.REG_GROUP)) {

					if (resultCode.equals(PushConstants.SUCCESS_RESULT_CODE)) {
						//Toast.makeText(context, "그룹 등록 성공!", Toast.LENGTH_SHORT).show();
					}else {
						//Toast.makeText(context, "[LoginActivity] error code: " + resultCode + " msg: " + resultMsg, Toast.LENGTH_SHORT).show();
					}
				}else if (bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.UNREG_GROUP)) {

					if (resultCode.equals(PushConstants.SUCCESS_RESULT_CODE)) {
						//Toast.makeText(context, "그룹 해제 성공!", Toast.LENGTH_SHORT).show();
					}else {
						//Toast.makeText(context, "[LoginActivity] error code: " + resultCode + " msg: " + resultMsg, Toast.LENGTH_SHORT).show();
					}
				}else if (bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.REG_SERVICE_AND_USER)) {

					if (resultCode.equals(PushConstants.SUCCESS_RESULT_CODE)) {
						//Toast.makeText(context, "로그인 성공!", Toast.LENGTH_SHORT).show();
						//setSendTest();
					}else {
						//Toast.makeText(context, "[LoginActivity] error code: " + resultCode + " msg: " + resultMsg, Toast.LENGTH_SHORT).show();
					}
				}else if (bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.INITBADGENO)) {

					if (resultCode.equals(PushConstants.SUCCESS_RESULT_CODE)) {
						//Toast.makeText(context, "Badge Number 초기화 성공 !", Toast.LENGTH_SHORT).show();
						PushManager.getInstance().setDeviceBadgeCount(getApplicationContext(), "11");
					}else {
						//Toast.makeText(context, "[LoginActivity] error code: " + resultCode + " msg: " + resultMsg, Toast.LENGTH_SHORT).show();
					}
				}else if(bundle.equals(PushConstantsEx.COMPLETE_BUNDLE.IS_REGISTERED_SERVICE)){
					String isRegister = "";
					try {
						isRegister = result_obj.getString(PushConstants.KEY_ISREGISTER);
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if(isRegister.equals("C")){
						//Toast.makeText(context, "CHECK ON [ 사용자 재등록 필요 !! ]", Toast.LENGTH_LONG ).show();
					}else if(isRegister.equals("N")){
						//Toast.makeText(context, "CHECK ON [ 서비스 재등록 필요 !! ]", Toast.LENGTH_LONG).show();
					}else{
						CommonLog.e("aaa", "서비스 정상 등록 상태 ");
					}
				}
			}
		};


		this.registerReceiver(mLoginBroadcastReceiver, intentFilter, this.getPackageName()+PushConstants.PERMISSION_PUSHSERVICE, null);

	}

	private void requestChangePushToken(String strToken, String strUPNSToken) {
		TelephonyManager tpm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		//String userID = tpm.getLine1Number();
		SharedPref pref = SharedPref.getInstance(this);
		boolean isPushPreview = pref.getBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
		PutChangePushTokenReq req = new PutChangePushTokenReq(App.m_MyUserInfo.m_nUserNo, strToken, strUPNSToken, isPushPreview);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				CommonLog.e(IntroAct.class.getSimpleName(), "PutChangePushToken onNetworkError : " + nErrorCode + " Msg : " + strMessage);
				closeProgress();
				//startTutorialActivity();
				startCheckDatabase();
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e(IntroAct.class.getSimpleName(), "PutChangePushToken Recv : " + a_strData);
				//closeProgress();
				//startTutorialActivity();
				startCheckDatabase();
			}

		});
	}

	private void requestGetPartnerApprovalList() {
		//showProgress(getString(R.string.progress_search));
		setProgressText(getString(R.string.progress_search));
		GetPartnerApprovalListReq req = new GetPartnerApprovalListReq();
		WebAPI webApi = new WebAPI(IntroAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e("", "requestGetPartnerApprovalList... post..");
				//closeProgress();
				GetPartnerApprovalListRes res = new GetPartnerApprovalListRes(a_strData);
				if (res.getApprovalPendingList() != null) {
					pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, res.getApprovalPendingList().size());
					IconBadge.updateIconBadge(IntroAct.this);
				} else {
					pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, 0);
					IconBadge.updateIconBadge(IntroAct.this);
				}
//				startNextActivity();
				checkDatabase();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

						SparseArray<UserListData> checkUserList = ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
						if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
						} else {
							m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
						}

					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	/*private AOMManager.AOMRegistComplete m_AOMRegistComplete = new AOMManager.AOMRegistComplete() {

		@Override
		public void onRegistError() {
			// TODO Auto-generated method stub
			CommonLog.e(IntroAct.class.getSimpleName(), "onRegError");
			//closeProgress();
			//startTutorialActivity();
			startCheckDatabase();
		}

		@Override
		public void onRegistComplete() {
			// TODO Auto-generated method stub
			requestChangePushToken();
		}

		@Override
		public void onUnRegistComplete() {

		}
	};*/

	//기존에 튜토리얼을 보여 주던 위치
	private void startCheckDatabase(){
		if (AppSetting.FEATURE_VARIANT.equals("R"))
			requestGetPartnerApprovalList();
		else
		{
//				startNextActivity();
			checkDatabase();
		}
	}
	/*private void startTutorialActivity() {
		SharedPref pref = SharedPref.getInstance(this);
		if (pref.getBooleanPref(SharedPref.PREF_TUTORIAL_NEVERSHOW, false)) {
			if (AppSetting.FEATURE_VARIANT == "R")
				requestGetPartnerApprovalList();
			else
			{
//				startNextActivity();
				checkDatabase();
			}
		} else {
			Intent intent = new Intent(this, TutorialAct.class);
			startActivityForResult(intent, StaticString.REQUESTCODE_TUTORIAL);
		}
	}*/

	private void startNextActivity() {


		if (TextUtils.isEmpty(m_strGetIntentFromApp)) {
			ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(this);
			// if(arrRoomData.isEmpty()){
			SharedPref pref = SharedPref.getInstance(this);
			if (!Utils.getApplicationVersion(IntroAct.this).equals(pref.getStringPref(SharedPref.PREF_NOW_VERSION))) {
				setProgressText(getString(R.string.progress_remakeroom).toString());
			} else {
				showProgress();
			}
			CommonLog.e(getClass().getSimpleName(), "Intro Act : Start Make Room");
			Intent intent = new Intent(this, XmppConnectionService.class);
			bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
			/*getContacts();
			Intent intent = new Intent(IntroAct.this, MainTabAct.class);
			startActivity(intent);*/
		} else {
			if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_PUSH)) {

				if (TextUtils.isEmpty(m_strGetIntentGid)) {
					// 개인 체팅
					getContacts();
					Intent intent = new Intent(this, MainTabAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO, m_nGetIntentFriendNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM, true);
					startActivity(intent);
					finish();

				} else {
					// 그룹 채팅
					getContacts();
					Intent intent = new Intent(this, MainTabAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID, m_strGetIntentGid);
					intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP, true);
					startActivity(intent);
					finish();
				}
			} else if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_TTALK)) {
				if (m_nGetIntentGroupUserListSize > 1) {
					// 그룹 채팅
					ArrayList<Integer> arrUserNo = new ArrayList<Integer>();
					for (int i = 0; i < m_nGetIntentGroupUserListSize; i++) {
						if (!m_strsGetIntentGroupUserList[i].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))) {
							arrUserNo.add(Integer.parseInt(m_strsGetIntentGroupUserList[i]));
						}
					}
					Intent intent = new Intent(IntroAct.this, ChatRoomGroupAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, arrUserNo);
					startActivity(intent);
					finish();
				} else {
					// 개인 채팅
					Intent intent = new Intent(IntroAct.this, ChatRoomAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, m_strsGetIntentGroupUserList[0]);
					startActivity(intent);
					finish();

				}
			} else if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_KICK)) {
				// 강퇴, 대화방 리스트로 이동
				getContacts();
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISKICK, true);
				startActivity(intent);
				finish();
			} else if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_REQUEST)) {
				// 파트너 승인 요청, 승인 수락하는 페이지로 이동
				getContacts();
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_APPROVAL, true);
				startActivity(intent);
				finish();
			} else if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_SNSINVITE)) {
				// 파트너 승인 요청, 승인 수락하는 페이지로 이동
				getContacts();
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSINVITE, true);
				startActivity(intent);
				finish();
			}
			else if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_SNSBOARD)) {
				// 모임 게시글
				getContacts();
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSBOARD, true);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID, m_nSNSGroupId);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID, m_nSNSBoardId);
				startActivity(intent);
				finish();
			} else if (m_strGetIntentFromApp.equals(IntentKeyString.INTENT_VALUE_INTRO_FROM_SNSREPLY)) {
				// 모임 댓글
				getContacts();
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, true);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID, m_nSNSGroupId);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID, m_nSNSBoardId);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID, m_nSNSReplyId);
				startActivity(intent);
				finish();
			}
		}

		// finish();
	}

	private ServiceConnection mConnection = new ServiceConnection() {

		@Override
		public void onServiceDisconnected(ComponentName arg0) {
			CommonLog.e(IntroAct.this, "onServiceDisconnected");
			mBound = false;
			onXMPPServiceDisConnected();

		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			CommonLog.e(IntroAct.this, "onServiceConnected");
			LocalBinder binder = (LocalBinder) service;
			mService = binder.getService();
			// mService.addPacketListener(mPacketListener);
			// mService.addGroupPacketListener(mPacketListener);
			mBound = true;
			onXMPPServiceConnected();

		}
	};

	protected void onXMPPServiceConnected() {
		// if(mService != null){
		mService.addIntroPacketListener(mPacketListener);
		mService.requestGroupChats();
		// }
	}

	protected void onXMPPServiceDisConnected() {

		mService.removeIntroPacketListener();

		if(pref.getBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_FIRST_LOGIN, false)){
			if (mBound) {
				unbindService(mConnection);

				mBound = false;
			}

			Intent intentService = new Intent(IntroAct.this, XmppConnectionService.class);
			bindService(intentService, mConnection, Context.BIND_AUTO_CREATE);
		} else {
			if(!pref.getBooleanPref(SharedPref.PREF_BACKUP_RESTORE, false)){
				getContacts();
				CommonLog.e(getClass().getSimpleName(), "Intro Act : Go MainTabAct");
				Intent intent = new Intent(IntroAct.this, MainTabAct.class);
				startActivity(intent);
				closeProgress();
				finish();
			} else {
				CommonLog.e(getClass().getSimpleName(), "Intro Act : Get BackUpCheck");
				getBackUpCheck();
			}
			if (mBound) {
				unbindService(mConnection);

				mBound = false;
			}
		}
	}

	private PacketListener mPacketListener = new PacketListener() {

		@Override
		public void onUnBind() {
			// TODO Auto-generated method stub
			// if(mService != null)
			mService.removeIntroPacketListener();


			if(pref.getBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_FIRST_LOGIN, false)){
				if (mBound) {
					unbindService(mConnection);

					mBound = false;
				}

				Intent intentService = new Intent(IntroAct.this, XmppConnectionService.class);
				bindService(intentService, mConnection, Context.BIND_AUTO_CREATE);
			} else {
				if(!pref.getBooleanPref(SharedPref.PREF_BACKUP_RESTORE, false)){
					getContacts();
					CommonLog.e(getClass().getSimpleName(), "Intro Act : Go MainTabAct");
					Intent intent = new Intent(IntroAct.this, MainTabAct.class);
					startActivity(intent);
					closeProgress();
					finish();
				} else {
					CommonLog.e(getClass().getSimpleName(), "Intro Act : Get BackUpCheck");
					getBackUpCheck();
				}
				if (mBound) {
					unbindService(mConnection);

					mBound = false;
				}
			}
		}

		@Override
		public void showPopup() {
			// TODO Auto-generated method stub

			runOnUiThread(new Runnable() {
				public void run() {
					if (m_Popup != null && m_Popup.isShowing())
						m_Popup.cancel();
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_XMPP_ERROR);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			});

		}

		@Override
		public void showPasswordPopup() {
			// TODO Auto-generated method stub
			runOnUiThread(new Runnable() {
				public void run() {
					if (m_Popup != null && m_Popup.isShowing())
						m_Popup.cancel();
					m_Popup = new CommonPopup(IntroAct.this, IntroAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_XMPP_ERROR);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.xmpp_password_error).toString());
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			});
		}

	};

	public interface PacketListener {
		public void onUnBind();
		public void showPopup();
		public void showPasswordPopup();
	}

	private void getContacts(){
		ContactsDBManager.getContactsReturnSparseArray(IntroAct.this);
	}
}
