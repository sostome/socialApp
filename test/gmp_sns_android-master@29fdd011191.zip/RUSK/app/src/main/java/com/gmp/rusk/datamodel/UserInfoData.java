package com.gmp.rusk.datamodel;

public class UserInfoData {
	public int m_nUserNo = 0;						//사용자 번호
	public String m_strUserType = "";				//사용자 유형 R:정직원 P:파트너
	public String m_strName = "";					//이름
	public String m_strEmail = "";				//이메일
	public String m_strMobile = "";				//전화번호
	public String m_strCompanyCode = "";
	public String m_strCompanyName = "";
	public String m_strDepartment = "";				//부서
	public String m_strDepartmentCode = "";
	public String m_strParentDepartment = "";					//소속
	public String m_strCharge = "";					//직책
	public String m_strPosition = "";					//지위
	public String m_strSecondCharge = "";			//겸직 직책
	public String m_strCompany = "";				//소속 회사명
	public String m_strAffiliation = "";
	public boolean m_isImageAvailable = false;		//이미지 보유 여부
	public String m_strGreeting ="";
	public boolean m_isAvailable = false;				//사용자 앱 설치 유무
	public String m_strStatus = "";
	public String m_strFellowAddTime = "";				//동료 추가 시간
	public boolean m_isChecked = false;

	public String m_strSecondDepartment = "";
	public String m_strSecondParentDepartment = "";
	public UserInfoData() {

	}
	public UserInfoData(String a_strUserType, String a_strName, String a_strMobile, String a_strCharge, String a_strDepartment, String a_strParentDepartment, String a_strSecondDepartment, String a_strSecondParentDepartment, 
			String a_strSecondCharge, String a_strCompany, boolean a_isImageAvailable, String a_strGreeting, boolean a_isAvailable) {
		m_strUserType = a_strUserType;
		m_strName = a_strName;
		m_strMobile = a_strMobile;
		m_strCharge = a_strCharge;
		m_strDepartment = a_strDepartment;
		m_strParentDepartment = a_strParentDepartment;
		//m_strSecondDepartment = a_strSecondDepartment;
		//m_strSecondParentDepartment = a_strSecondParentDepartment;
		m_strSecondCharge = a_strSecondCharge;
		m_strCompany = a_strCompany;
		m_isImageAvailable = a_isImageAvailable;
		m_strGreeting = a_strGreeting;
		m_isAvailable = a_isAvailable;
	}
}
