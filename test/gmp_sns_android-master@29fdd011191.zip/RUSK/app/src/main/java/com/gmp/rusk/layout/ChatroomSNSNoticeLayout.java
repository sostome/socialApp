package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.SNSBoardDetailAct;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.Utils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

/**
 * Created by kang on 2017-05-18.
 */

public class ChatroomSNSNoticeLayout extends CustomRelativeLayout implements View.OnClickListener{

    private Context m_Context;
    private String m_thisRoomID;
    private TextView m_tvSnsNotice_text;                     //공지글
    private RelativeLayout m_layoutSnsNoticeAreaImage;      //공지 이미지 틀
    private ImageView m_ivSnsNoticeMainImage;               //공지 메인 이미지
    private RelativeLayout m_rlSnsNoticeImageMask;          //공지 이미지 여러개일때 mask
    private TextView m_tvSnsnoticeImageCount;               //공지 이미지 수
    private RelativeLayout m_layoutSnsNoticeAreaFileCount;  //파일개수 틀
    private TextView m_tvSnsNoticeFileCount;                //파일 개수
    private RelativeLayout m_layoutSnsNoticeAreaFile;       //파일 이름및 사이즈 틀
    private TextView m_tvSnsNoticeFileName;                 //파일이름
    private TextView m_tvSnsNoticeFileSize;                 //파일크기
    private LinearLayout m_layoutSnsNoticeAreaShortcut;     //바로가기
    private TextView m_tvNoReadCount;                       //읽음처리
    private TextView m_tvSNSNoticeTime;                     //시간

    private int m_nGroupid;
    private int m_nBoardNo;



    public ChatroomSNSNoticeLayout(Context context) {
        super(context);
        m_Context = context;
        init();
    }
    private void init(){
        String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
        LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
        li.inflate(R.layout.layout_chat_room_snsnotice, this, true);
        m_tvSnsNotice_text = (TextView) findViewById(R.id.tv_snsnotice_text);
        m_layoutSnsNoticeAreaImage = (RelativeLayout) findViewById(R.id.layout_snsnotice_area_image);
        m_layoutSnsNoticeAreaImage.setOnClickListener(this);
        m_ivSnsNoticeMainImage = (ImageView) findViewById(R.id.iv_snsnotice_mian_image);
        m_rlSnsNoticeImageMask = (RelativeLayout) findViewById(R.id.rl_snsnotice_image_mask);
        m_tvSnsnoticeImageCount = (TextView) findViewById(R.id.tv_snsnotice_image_count);
        m_layoutSnsNoticeAreaFileCount = (RelativeLayout) findViewById(R.id.layout_snsnotice_area_file_count);
        m_tvSnsNoticeFileCount = (TextView) findViewById(R.id.tv_snsnotice_file_count);
        m_layoutSnsNoticeAreaFile = (RelativeLayout) findViewById(R.id.layout_snsnotice_area_file);
        m_layoutSnsNoticeAreaFile.setOnClickListener(this);
        m_tvSnsNoticeFileName = (TextView) findViewById(R.id.tv_snsnotice_file_name);
        m_tvSnsNoticeFileSize = (TextView) findViewById(R.id.tv_snsnotice_file_size);
        m_layoutSnsNoticeAreaShortcut = (LinearLayout) findViewById(R.id.layout_snsnotice_area_shortcut);
        m_layoutSnsNoticeAreaShortcut.setOnClickListener(this);
        m_tvNoReadCount = (TextView) findViewById(R.id.tv_no_read_count);
        m_tvSNSNoticeTime = (TextView) findViewById(R.id.tv_snsnotice_time);

    }
    public void setChatRoomData(ChatRoomData a_Data){
        ChatRoomData chatRoomData = a_Data;
        m_tvNoReadCount.setTextColor(Color.parseColor("#4bb0bc"));
        m_thisRoomID = chatRoomData.m_strRoomID;
        m_nGroupid = Integer.parseInt(chatRoomData.m_strGroupId);
        m_nBoardNo = Integer.parseInt(chatRoomData.m_strBoardNo);
        //공지글
        if(!chatRoomData.m_strSNSNoticeText.equals("")) {
            m_tvSnsNotice_text.setVisibility(VISIBLE);
            m_tvSnsNotice_text.setText(chatRoomData.m_strSNSNoticeText);
        } else {
            m_tvSnsNotice_text.setVisibility(GONE);
        }
        //공지 이미지
        if(chatRoomData.m_nImageCount > 0){
            m_layoutSnsNoticeAreaImage.setVisibility(VISIBLE);
           /* Glide.with(m_Context).load(chatRoomData.m_strImage).into(m_ivSnsNoticeMainImage);*/
            App.imageloader.cancelDownload(m_ivSnsNoticeMainImage);
            App.imageloader.getImage(m_ivSnsNoticeMainImage,chatRoomData.m_strImage,0);
            if(chatRoomData.m_nImageCount == 1) {
                m_rlSnsNoticeImageMask.setVisibility(GONE);
            } else {
                m_rlSnsNoticeImageMask.setVisibility(VISIBLE);
                m_tvSnsnoticeImageCount.setText("+"+(chatRoomData.m_nImageCount-1));
            }
        }else {
            m_layoutSnsNoticeAreaImage.setVisibility(GONE);
        }
        //공지 파일
        if(chatRoomData.m_nFileCount > 0){
            m_layoutSnsNoticeAreaFileCount.setVisibility(VISIBLE);
            m_layoutSnsNoticeAreaFile.setVisibility(VISIBLE);
            m_tvSnsNoticeFileCount.setText(String.valueOf(chatRoomData.m_nFileCount));
            m_tvSnsNoticeFileName.setText(chatRoomData.m_strFileName);
            float fileSize = Utils.bytesToMegabyteFloat(chatRoomData.m_nFileSize);
            if(fileSize == 0.0)
                fileSize = 0.1F;
            m_tvSnsNoticeFileSize.setText(fileSize + " " + getContext().getString(R.string.etc_megabyte));
        } else {
            m_layoutSnsNoticeAreaFileCount.setVisibility(GONE);
            m_layoutSnsNoticeAreaFile.setVisibility(GONE);
        }

        // 날짜
        String pattern = "a h:mm";
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        String date = (String) format.format(new Timestamp(a_Data.m_lDate));
        m_tvSNSNoticeTime.setText(date);
        int nNoReadCount = 0;
        nNoReadCount = a_Data.m_nNoReadCount;
        if (nNoReadCount == 0) {
            m_tvNoReadCount.setText("");
            m_tvNoReadCount.setVisibility(View.GONE);
        } else if (nNoReadCount < 0) {
            m_tvNoReadCount.setText("");
            m_tvNoReadCount.setVisibility(View.GONE);
        }  else {
            m_tvNoReadCount.setText("" + nNoReadCount);
            m_tvNoReadCount.setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.layout_snsnotice_area_shortcut:
                startSNSBoardDetailAct(m_thisRoomID,m_nGroupid,m_nBoardNo);
                break;
            case R.id.layout_snsnotice_area_image:
                startSNSBoardDetailAct(m_thisRoomID,m_nGroupid,m_nBoardNo);
                break;
            case R.id.layout_snsnotice_area_file:
                startSNSBoardDetailAct(m_thisRoomID,m_nGroupid,m_nBoardNo);
                break;
        }
    }
    private void startSNSBoardDetailAct(String a_strRoomId, int a_nGroupId, int a_nBoardId)
    {

        Intent intent = new Intent(m_Context, SNSBoardDetailAct.class);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISPUSH, false);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPID, a_nGroupId);
        ChattingRoomInfoData rData = TTalkDBManager.RoomDBManager.getChattingRoom(m_Context,a_strRoomId);
        String strTitle = "";
        if (rData != null && rData.m_isTitleEdited) {
            try {
                LocalAesCrypto crypto = new LocalAesCrypto();
                strTitle = crypto.decrypt(rData.m_strRoomTitle);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else
            strTitle = "";
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPNAME, strTitle);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, a_nBoardId);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, false);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_WRITEREPLY, false);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_SHOWCHATBTN, false);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISLASTSCROLL, false);
        m_Context.startActivity(intent);
    }

}
