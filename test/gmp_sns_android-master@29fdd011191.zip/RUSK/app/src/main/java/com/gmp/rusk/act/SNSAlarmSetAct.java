package com.gmp.rusk.act;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PutGroupSettingReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

/**
 * Created by kang on 2017-09-12.
 */

public class SNSAlarmSetAct extends CustomActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener,View.OnTouchListener{

    CheckBox cb_newWrite;
    CheckBox cb_newAdd;

    int m_nChannelID = 0;
    int m_nUserNo = 0;
    boolean m_isThreadAlarmOn = true;
    boolean m_isCommentAlarmOn = true;

    CommonPopup m_Popup = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_alarm_setting);

        ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISTHREAD_ALARMON,m_isThreadAlarmOn);
                intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISCOMMENT_ALARMON,m_isCommentAlarmOn);
                setResult(RESULT_OK,intent);
                finish();
            }
        });
        getIntents();
        setAlramUI();
    }

    public void getIntents(){
        m_nChannelID = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID,0);
        m_nUserNo = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_USERIDS,0);
        m_isThreadAlarmOn = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISTHREAD_ALARMON,true);
        m_isCommentAlarmOn = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISCOMMENT_ALARMON,true);
    }


    public void setAlramUI(){
        LinearLayout layoutNewWriteAlarm = (LinearLayout)findViewById(R.id.layout_set_alarm_newwrite_alram);
        layoutNewWriteAlarm.setOnClickListener(this);
        LinearLayout layoutNewAddAlarm = (LinearLayout)findViewById(R.id.layout_set_alarm_newadd_alram);
        layoutNewAddAlarm.setOnClickListener(this);
        LinearLayout layoutChatroomAlarm = (LinearLayout)findViewById(R.id.layout_set_alarm_chatroom_alram);
        layoutChatroomAlarm.setVisibility(View.GONE);
        cb_newWrite = (CheckBox)findViewById(R.id.cb_newwrite_alram);
        cb_newAdd = (CheckBox)findViewById(R.id.cb_newaddd_alram);
        if(m_isThreadAlarmOn){
            cb_newWrite.setChecked(true);
        } else {
            cb_newWrite.setChecked(false);
        }

        if(m_isCommentAlarmOn){
            cb_newAdd.setChecked(true);
        } else {
            cb_newAdd.setChecked(false);
        }

        cb_newWrite.setOnTouchListener(this);
        cb_newWrite.setOnCheckedChangeListener(this);
        cb_newAdd.setOnTouchListener(this);
        cb_newAdd.setOnCheckedChangeListener(this);
    }

    public void setThreadAlarmOnOff(){
        PutGroupSettingReq req = new PutGroupSettingReq(m_nChannelID,m_isThreadAlarmOn, m_isCommentAlarmOn,m_nUserNo);
        WebAPI api = new WebAPI(this);
        api.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                cb_newWrite.setChecked(m_isThreadAlarmOn);
            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                // TODO Auto-generated method stub
                m_isThreadAlarmOn = !m_isThreadAlarmOn;
                if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(SNSAlarmSetAct.this, new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                            setResult(RESULTCODE_NOTINVITED_SNSGROUP);
                            finish();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
                else
                    showErrorPopup(nErrorCode, strMessage);
            }
        });
    }

    public void  setCommentAlarmOnOff(){
        PutGroupSettingReq req = new PutGroupSettingReq(m_nChannelID,m_isThreadAlarmOn,m_isCommentAlarmOn,m_nUserNo);
        WebAPI api = new WebAPI(this);
        api.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                cb_newAdd.setChecked(m_isCommentAlarmOn);
            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                // TODO Auto-generated method stub
                m_isCommentAlarmOn = !m_isCommentAlarmOn;
                if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(SNSAlarmSetAct.this, new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                            setResult(RESULTCODE_NOTINVITED_SNSGROUP);
                            finish();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
                else
                    showErrorPopup(nErrorCode, strMessage);
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISTHREAD_ALARMON,m_isThreadAlarmOn);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISCOMMENT_ALARMON,m_isCommentAlarmOn);
        setResult(RESULT_OK,intent);
        finish();
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if(v.getId() == R.id.layout_set_alarm_newwrite_alram){
            if(cb_newWrite.isChecked()){
                m_isThreadAlarmOn = false;
            } else {
                m_isThreadAlarmOn = true;
            }
            setThreadAlarmOnOff();
        } else if(v.getId() == R.id.layout_set_alarm_newadd_alram) {
            if(cb_newAdd.isChecked()){
                m_isCommentAlarmOn = false;
            } else {
                m_isCommentAlarmOn = true;
            }
            setCommentAlarmOnOff();
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_UP) {
            if (v.getId() == R.id.cb_newwrite_alram) {
                if(cb_newWrite.isChecked()){
                    m_isThreadAlarmOn = false;
                } else {
                    m_isThreadAlarmOn = true;
                }
                setThreadAlarmOnOff();
            } else if (v.getId() == R.id.cb_newaddd_alram) {
                if(cb_newAdd.isChecked()){
                    m_isCommentAlarmOn = false;
                } else {
                    m_isCommentAlarmOn = true;
                }
                setCommentAlarmOnOff();
            }
        }
        return true;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (buttonView.getId() == R.id.cb_newwrite_alram) {

        } else  if (buttonView.getId() == R.id.cb_newaddd_alram) {

        }
    }

    private void isCheckShowPopup() {
        if (super.m_isRunning) {
            m_Popup.show();
        }
    }
}
