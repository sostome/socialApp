package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.layout.ChatRoomMemberListLayout;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

/**
 * ChatRoomMemberAct
 * 
 * @author kch 방 멤버 보기 Activity
 */

public class ChatRoomMemberAct extends CustomActivity {

	ArrayList<UserListData> m_arrUserListDatas = null;
	ArrayList<Integer> m_arrUserNo;
	UserListAdapter m_UserListAdapter;
	ImageView m_btnTopClose;
	Button m_btnComplete;
	private ListView m_lvUserList = null;

	int m_nOwnerNo;
	UserListData m_UserListData;
	TextView m_tvChatCount;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatroom_menu_member);
		
		Bundle bundle = getIntent().getExtras();

		if (bundle != null){
			m_arrUserNo = bundle.getIntegerArrayList(IntentKeyString.INTENT_KEY_ARR_USERNO);
			m_nOwnerNo = bundle.getInt(IntentKeyString.INTENT_KEY_OWNERNO);
			super.m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID, "");
			 
		}
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		if(m_arrUserListDatas == null)
			m_arrUserListDatas = new ArrayList<UserListData>();
		
		m_arrUserListDatas.clear();
		
		for(int nUserNo : m_arrUserNo){
			m_UserListData = ContactsDBManager.getContacts(this, nUserNo);
			m_arrUserListDatas.add(m_UserListData);
		}
		Collections.sort(m_arrUserListDatas,myComparator);
		for(int i = 0; i < m_arrUserListDatas.size(); i++){
			if(m_arrUserListDatas.get(i).m_nUserNo == App.m_MyUserInfo.m_nUserNo){
				UserListData tempData = m_arrUserListDatas.get(i);
				m_arrUserListDatas.remove(m_arrUserListDatas.get(i));
				m_arrUserListDatas.add(0, tempData);
			}
		}
		for(int i = 0; i < m_arrUserListDatas.size(); i++){
			if(m_arrUserListDatas.get(i).m_nUserNo == m_nOwnerNo && m_arrUserListDatas.get(i).m_nUserNo != App.m_MyUserInfo.m_nUserNo){
				UserListData tempData = m_arrUserListDatas.get(i);
				m_arrUserListDatas.remove(m_arrUserListDatas.get(i));
				m_arrUserListDatas.add(1, tempData);
			}
		}

		initUI();
	}
	private final static Comparator<UserListData> myComparator = new Comparator<UserListData>() {
		private final Collator collator = Collator.getInstance(new Locale("ko"));

		@Override
		public int compare(UserListData lhs, UserListData rhs) {
			// TODO Auto-generated method stub
			boolean isLeftNumber = true;
			boolean isRightNumber = true;

			char leftChar = lhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME).charAt(0);
			char rightChar = rhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME).charAt(0);

			if(leftChar < '0' || leftChar > '9'){
				isLeftNumber = false;
			}
			if(rightChar < '0' || rightChar > '9'){
				isRightNumber = false;
			}

			if(isLeftNumber && !isRightNumber){
				return 1;
			} else if(!isLeftNumber && isRightNumber){
				return -1;
			} else
				return collator.compare(lhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME), rhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
		}

	};

	private void initUI() {

		m_btnTopClose = (ImageView)findViewById(R.id.btn_top_close);
		m_btnTopClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		m_lvUserList = (ListView) findViewById(R.id.lv_chat_member_list);
		m_tvChatCount = (TextView) findViewById(R.id.tv_chat_member_count);
		m_tvChatCount.setText(getString(R.string.chat_member_section) +" "+ m_arrUserNo.size());
		RelativeLayout layout_nolisttext;
		layout_nolisttext = (RelativeLayout) findViewById(R.id.layout_hinttext);
		if (m_arrUserListDatas != null) {
			layout_nolisttext.setVisibility(View.GONE);
			if(m_UserListAdapter == null)
			{
				m_UserListAdapter = new UserListAdapter();
				m_lvUserList.setAdapter(m_UserListAdapter);
			}
			else
				m_UserListAdapter.notifyDataSetChanged();;
		}
	}


	private class UserListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nUserListDataSize = 0;

			if (m_arrUserListDatas != null)
				nUserListDataSize = m_arrUserListDatas.size();

			return nUserListDataSize;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_arrUserListDatas != null && position < m_arrUserListDatas.size())
				return m_arrUserListDatas.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			UserListData userData;
			

			if (nPosition < m_arrUserListDatas.size()) {
				userData = (UserListData) m_arrUserListDatas.get(nPosition);
				// convertView null 시 새로 생성하자
				if (convertView == null)
					convertView = new ChatRoomMemberListLayout(ChatRoomMemberAct.this, ChatRoomMemberListLayout.CHATROOM_ITEM_TYPE_MEMBER);
				((ChatRoomMemberListLayout) convertView).setOwner(m_nOwnerNo);
				((ChatRoomMemberListLayout) convertView).setUserListData(userData);
			}

			return convertView;
		}
	}
}
