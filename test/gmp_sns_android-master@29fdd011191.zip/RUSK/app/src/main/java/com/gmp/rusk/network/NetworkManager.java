package com.gmp.rusk.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.PowerManager;

import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.AppSetting.APISERVER_LIST;
import com.gmp.rusk.utils.CommonLog;

/**
 * 네트워크 상태체크 및 final 변수 정의 클래스
 */
public class NetworkManager {

    public static final int NETWORK_DISCONNECTED = -1;
    public static final int NETWORK_CONNECTED_3G = 0;
    public static final int NETWORK_CONNECTED_WIFI = 1;
    public static final int NETWORK_CONNECTED_ETC = 2;

    public static final String NETWORK_OPEN_API_MAIN_URL_HTTP;
    public static final String NETWORK_OPEN_API_MAIN_URL_HTTPS;
    public static final String NETWORK_OPEN_API_MAIN_URL_HTTP_PORT;
    public static final String NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT;
    public static final String NETWORK_FILEVIEWER_DOCID_URL;

    public static final String HTTP_METHOD_POST 	= "POST";
    public static final String HTTP_METHOD_GET		= "GET";
    public static final String HTTP_METHOD_PUT		= "PUT";
    public static final String HTTP_METHOD_DELETE	= "DELETE";




    static {
        if(AppSetting.USING_SERVER == APISERVER_LIST.DEV_SERVER)
        {
           // 내부 개발 서버
            //기존
/*            NETWORK_OPEN_API_MAIN_URL_HTTP = "http://192.168.1.146";
//			NETWORK_OPEN_API_MAIN_URL_HTTP = "http://211.188.179.174";
            NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://192.168.1.146";
//            NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://jupiter.uangel.com"; //사내 메신저 LTE 용
//			NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://211.188.179.174";
            NETWORK_OPEN_API_MAIN_URL_HTTP_PORT = ":7010";
//            NETWORK_OPEN_API_MAIN_URL_HTTP_PORT = "443"; //사내 메신저 용
//			NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = "8081";
            NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = ":7010";
//			NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = ":3443";*/

            //GMP 개발
            //기존
            NETWORK_OPEN_API_MAIN_URL_HTTP = "http://devcork.toktok.sk.com";
//			NETWORK_OPEN_API_MAIN_URL_HTTP = "http://211.188.179.174";
            NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://devcork.toktok.sk.com";
//            NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://jupiter.uangel.com"; //사내 메신저 LTE 용
//			NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://211.188.179.174";
            NETWORK_OPEN_API_MAIN_URL_HTTP_PORT = ":7443";
//            NETWORK_OPEN_API_MAIN_URL_HTTP_PORT = "443"; //사내 메신저 용
//			NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = "8081";
            NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = ":7443";
//			NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = ":3443";

            NETWORK_FILEVIEWER_DOCID_URL = "http://203.236.17.49:9000";
        }
        else
        {
            // SKT 상용 서버
            NETWORK_OPEN_API_MAIN_URL_HTTP = "http://mcork.toktok.sk.com";
            NETWORK_OPEN_API_MAIN_URL_HTTPS = "https://mcork.toktok.sk.com";
            NETWORK_OPEN_API_MAIN_URL_HTTP_PORT = ":7443";
            NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT = ":7443";
            NETWORK_FILEVIEWER_DOCID_URL = "https://m.toktok.sk.com:9443";
        }
    }

    /* ================== Utility ============================= */
	/*
	 * Open API들을 호출하기전에 네트워크 State를 반드시 확인하시기 바랍니다.
	 */
    public static int NetworkStateCheck(Context mCtx) {

        ConnectivityManager cm = (ConnectivityManager) mCtx
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        //기존엔 isConected로 되어 있었으나, Doze 모드 도입 후 isAvailable로 변경
        if (info == null || !info.isAvailable()) {
            return NETWORK_DISCONNECTED;
        }
        //CommonLog.e("aaa", "Network info - Available : " + info.isAvailable() + " isConnectd : " + info.isConnected() + " isConnectedOrConnecting : " +  info.isConnectedOrConnecting() +  " isFailover : " + info.isFailover() + " isRoaming : " +  info.isRoaming());
        switch (info.getType()) {
            case ConnectivityManager.TYPE_WIFI:
                return NETWORK_CONNECTED_WIFI;
            case ConnectivityManager.TYPE_MOBILE:
                return NETWORK_CONNECTED_3G;
            default:
                return NETWORK_CONNECTED_ETC;
        }
    }

}
