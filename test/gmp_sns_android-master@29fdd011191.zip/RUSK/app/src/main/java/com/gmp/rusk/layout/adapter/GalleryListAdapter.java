package com.gmp.rusk.layout.adapter;

import java.io.IOException;
import java.lang.ref.SoftReference;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.act.GalleryMultiselectorListAct;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.utils.CommonLog;

public class GalleryListAdapter extends BaseAdapter {

	private Context						mContext;
	private LayoutInflater				infalter;
	private boolean						isActionMultiplePick;
	private boolean						isCountOver	= false;
	private boolean						isSizeOver	= false;
	private boolean 						isSizeZero = false;
	private ArrayList<GalleryListData>	data		= new ArrayList<GalleryListData>();
	ImageGalleryLoaderManager			imageLoader;

	public GalleryListAdapter(Context c)
	{
		infalter = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mContext = c;
		imageLoader = ImageGalleryLoaderManager.getInstance(mContext);
		clearCache();
	}

	public void setMultiplePick(boolean isMultiplePick)
	{
		this.isActionMultiplePick = isMultiplePick;
	}
	
	@Override
	public int getCount()
	{
		return data.size();
	}

	@Override
	public GalleryListData getItem(int position)
	{
		return data.get(position);
	}

	@Override
	public long getItemId(int position)
	{
		return position;
	}

	public boolean addAll(ArrayList<GalleryListData> files)
	{
		try {
			this.data.clear();
			this.data.addAll(files);

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		notifyDataSetChanged();
		return true;
	}

	long maxSize = 0;

	public int changeSelection(View v, int position, int maxCount, int limitCount, long limitSize)
	{
		if (data.get(position).isSeleted) {
			for (int i = 0; i < data.size(); i++) {
				if (data.get(i).isSeleted && (data.get(i).m_nSelectedNum > data.get(position).m_nSelectedNum)) {
					data.get(i).m_nSelectedNum -= 1;
				}
			}
			data.get(position).isSeleted = false;
			data.get(position).m_nSelectedNum = -1;
			maxSize -= data.get(position).m_lnSize;
			maxCount--;
			isCountOver = false;
			isSizeOver = false;
			isSizeZero = false;

			notifyDataSetChanged();
		} else {
			if (maxCount < limitCount) {
				long lnTotalSize = maxSize + data.get(position).m_lnSize;
				if(lnTotalSize > limitSize)
				{
					isSizeOver = true;
					isSizeZero = false;
					data.get(position).isSeleted = false;
					data.get(position).m_nSelectedNum = -1;
					return -1;
				}
				else if(lnTotalSize == 0L)
				{
					isSizeZero = true;
					isSizeOver = false;
					data.get(position).isSeleted = false;
					data.get(position).m_nSelectedNum = -1;
					return -2;
				}
				else
				{
					isSizeOver = false;
					data.get(position).isSeleted = true;
					data.get(position).m_nSelectedNum = maxCount;
					maxCount++;
					maxSize = lnTotalSize;
				}
				isCountOver = false;
//				data.get(position).isSeleted = true;
//				if (maxSize < limitSize) {
//					maxSize += data.get(position).m_lnSize;
//					isSizeOver = false;
//				} else {
//					isSizeOver = true;
//				}
//				maxCount++;
//				isCountOver = false;
			} else {
				isCountOver = true;
			}
		}

		((FileViewHolder) v.getTag()).imgQueueMultiSelected.setSelected(data.get(position).isSeleted);
		if(data.get(position).m_nSelectedNum > -1)
			((FileViewHolder) v.getTag()).tvSelectedNumber.setText(""+(data.get(position).m_nSelectedNum+1));
		else {
			((FileViewHolder) v.getTag()).tvSelectedNumber.setText("");
		}
		return maxCount;
	}

	public boolean getIsCountOver()
	{
		return isCountOver;
	}

	public boolean getIsSizeOver()
	{
		return isSizeOver;
	}

	public boolean isAllSelected()
	{
		boolean isAllSelected = true;

		for (int i = 0; i < data.size(); i++) {
			if (!data.get(i).isSeleted) {
				isAllSelected = false;
				break;
			}
		}

		return isAllSelected;
	}

	public void isAllCancel()
	{
		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).isSeleted) {
				data.get(i).isSeleted = false;
				break;
			}
		}
	}

	public boolean isAnySelected()
	{
		boolean isAnySelected = false;

		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).isSeleted) {
				isAnySelected = true;
				break;
			}
		}

		return isAnySelected;
	}

	public ArrayList<GalleryListData> getSelected()
	{
		ArrayList<GalleryListData> dataT = new ArrayList<GalleryListData>();

		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).isSeleted) {
				dataT.add(data.get(i));
			}
		}
		Collections.sort(dataT, myComparator);
		ArrayList<GalleryListData> dataC = new ArrayList<GalleryListData>();
		for(GalleryListData data : dataT) {
			dataC.add(data);
	}
		return dataC;
	}

	private final static Comparator<GalleryListData> myComparator = new Comparator<GalleryListData>() {
		private final Collator collator = Collator.getInstance();

		@Override
		public int compare(GalleryListData lhs, GalleryListData rhs) {
			// TODO Auto-generated method stub
			return collator.compare(Integer.toString(lhs.m_nSelectedNum), Integer.toString(rhs.m_nSelectedNum));
		}

	};
	@Override
	public int getItemViewType(int position)
	{
		return getItem(position).m_nFileType;
	}

	@Override
	public int getViewTypeCount()
	{
		// type -> directory 0, file 1
		return 2;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent)
	{
		GalleryListData selectedItem = getItem(position);
		int fileType = getItemViewType(position); // dir or file
		int mediaType = selectedItem.m_strType; // video or image
		
		if (fileType == GalleryMultiselectorListAct.FILE_TYPE) {
			FileViewHolder holder;
			if (convertView == null) {
				convertView = infalter.inflate(R.layout.layout_listitem_gallery_img_model, parent, false);
				holder = new FileViewHolder();
				holder.imgQueue = (ImageView) convertView.findViewById(R.id.imgQueue);
				holder.imgQueueMultiSelected = (ImageView) convertView.findViewById(R.id.imgQueueMultiSelected);
				holder.imgQueueMultiSelected.setMaxHeight(holder.imgQueueMultiSelected.getWidth());
				holder.tvSelectedNumber = (TextView) convertView.findViewById(R.id.tvImageSelectedNumber);

				if (isActionMultiplePick) {
					holder.imgQueueMultiSelected.setVisibility(View.VISIBLE);
				} else {
					holder.imgQueueMultiSelected.setVisibility(View.GONE);
				}

				convertView.setTag(holder);

			} else {
				holder = (FileViewHolder) convertView.getTag();
				holder.imgQueue.setImageResource(R.drawable.file_pic_frame);

			}
			holder.imgQueue.setTag(data.get(position).getSdcardPath());
			imageLoader.getGalleryImage(holder.imgQueue, data.get(position), R.drawable.file_pic_frame, mediaType);
			if (isActionMultiplePick) {

				holder.imgQueueMultiSelected.setSelected(data.get(position).isSeleted);
				if(data.get(position).m_nSelectedNum > -1){
					if(!data.get(position).isSeleted){
						holder.tvSelectedNumber.setText("");
						data.get(position).m_nSelectedNum = -1;
					} else {
						holder.tvSelectedNumber.setText("" + (data.get(position).m_nSelectedNum + 1));
					}
				} else {
					holder.tvSelectedNumber.setText("");
				}

			}
		}
		return convertView;
	}
	
	private static class ImageGalleryLoaderManager {
		private static ImageGalleryLoaderManager m_Instance = null;
		private static Context m_Context;
		public static ImageGalleryLoaderManager getInstance(Context a_Context)
		{
			if(m_Instance == null)
				m_Instance = new ImageGalleryLoaderManager(a_Context);
			else
				m_Instance.setContext(a_Context);
			
			return m_Instance;
		}
		
		private void setContext(Context a_Context)
		{
			m_Context = a_Context;
		}
		
		private ImageGalleryLoaderManager(Context a_Context)
		{
			m_Context = a_Context;
		}
		 /*
	     * GALLERY IMAGE GET METHOD
	     */
		public void getGalleryImage(ImageView a_ivImage, GalleryListData a_GalleryListData, int a_nResId, int a_nMediaType)
		{
			Bitmap bmpCache = getGalleryBitmapFromCache("file://" + a_GalleryListData.getSdcardPath());
			if(bmpCache != null)
				a_ivImage.setImageBitmap(bmpCache);
			else
			{
				a_ivImage.setImageResource(a_nResId);
				AsyncTaskLoadFiles imageasyncLoad = new AsyncTaskLoadFiles(a_GalleryListData.getSdcardPath(), a_GalleryListData.m_nMediaIndex, a_GalleryListData.m_nItemId, a_ivImage, a_nMediaType);
				imageasyncLoad.execute();
				
			}
		}
	    
	    /*
	     * GALLERY MULTI SELECTOR CACHE - IMAGE
	     */
	    
	    private static final int HARD_GALLERY_CACHE_CAPACITY = 100;
	    // Hard cache, with a fixed maximum capacity and a life duration
	    public final static HashMap<String, Bitmap> sHardGalleryBitmapCache =
	        new LinkedHashMap<String, Bitmap>(HARD_GALLERY_CACHE_CAPACITY / 2, 0.75f, true) {
	        @Override
	        protected boolean removeEldestEntry(LinkedHashMap.Entry<String, Bitmap> eldest) {
	            if (size() > HARD_GALLERY_CACHE_CAPACITY) {
	                // Entries push-out of hard reference cache are transferred to soft reference cache
	                sSoftGalleryBitmapCache.put(eldest.getKey(), new SoftReference<Bitmap>(eldest.getValue()));
	                return true;
	            } else
	                return false;
	        }
	    };

	    // Soft cache for bitmaps kicked out of hard cache
	    private final static ConcurrentHashMap<String, SoftReference<Bitmap>> sSoftGalleryBitmapCache =
	        new ConcurrentHashMap<String, SoftReference<Bitmap>>(HARD_GALLERY_CACHE_CAPACITY / 2);
	    /**
	     * Adds this bitmap to the cache.
	     * @param bitmap The newly downloaded bitmap.
	     */
	    public static void addGalleryBitmapToCache(String url, Bitmap bitmap) {
	        if (bitmap != null) {
	            synchronized (sHardGalleryBitmapCache) {
	            	sHardGalleryBitmapCache.put(url, bitmap);
	            }
	        }
	    }

	    /**
	     * @param url The URL of the image that will be retrieved from the cache.
	     * @return The cached bitmap or null if it was not found.
	     */
	    public static Bitmap getGalleryBitmapFromCache(String url) {
	        // First try the hard reference cache
	        synchronized (sHardGalleryBitmapCache) {
	            final Bitmap bitmap = sHardGalleryBitmapCache.get(url);
	            if (bitmap != null) {
	                // Bitmap found in hard cache
	                // Move element to first position, so that it is removed last
	            	sHardGalleryBitmapCache.remove(url);
	            	sHardGalleryBitmapCache.put(url, bitmap);
	                return bitmap;
	            }
	        }

	        // Then try the soft reference cache
	        SoftReference<Bitmap> bitmapReference = sSoftGalleryBitmapCache.get(url);
	        if (bitmapReference != null) {
	            final Bitmap bitmap = bitmapReference.get();
	            if (bitmap != null) {
	                // Bitmap found in soft cache
	                return bitmap;
	            } else {
	                // Soft reference has been Garbage Collected
	            	sSoftGalleryBitmapCache.remove(url);
	            }
	        }

	        return null;
	    }
	    
	    public static class AsyncTaskLoadFiles extends AsyncTask<Void, String, Bitmap> {
			private String		a_strUrl;
			private long		a_longIndex;
			private boolean		a_boolCached	= false;
			private String		a_strThumbUrl;
			private String		a_strMediaId;
			private int			a_intType;
			private ImageView	a_ivQueue;

			public AsyncTaskLoadFiles(String a_strUrl_param, long itemIndex, String mediaId, ImageView imgQueue, int type)
			{
				this.a_strUrl = a_strUrl_param;
				this.a_longIndex = itemIndex;
				a_strThumbUrl = a_strUrl;
				this.a_ivQueue = imgQueue;
				this.a_intType = type;
				this.a_strMediaId = mediaId;
			}

			@Override
			protected void onPreExecute()
			{
				super.onPreExecute();
			}

			@Override
			protected Bitmap doInBackground(Void... params)
			{
				Bitmap bitmapCache = null;
				String a_strCompTag = (String) a_ivQueue.getTag();
				if (a_strCompTag != null && a_strCompTag.equalsIgnoreCase(a_strUrl))
				{
					bitmapCache = ImageGalleryLoaderManager.getGalleryBitmapFromCache("file://" + a_strUrl);
					if (bitmapCache != null)
						a_boolCached = true;
					else
						a_boolCached = false;
					
					if(!a_boolCached)
					{
						if (a_intType == GalleryMultiselectorListAct.IMAGE_TYPE) {
							bitmapCache = Images.Thumbnails.getThumbnail(m_Context.getContentResolver(), a_longIndex, Images.Thumbnails.MINI_KIND, null);
							if (bitmapCache == null)
								bitmapCache = MediaStore.Images.Thumbnails.getThumbnail(m_Context.getContentResolver(), a_longIndex, MediaStore.Images.Thumbnails.MICRO_KIND, null);

							if (bitmapCache != null) {
								try {
									ExifInterface exif = new ExifInterface(a_strThumbUrl);
									int orientaion = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1);
									if(orientaion != 0) {
										int degree = exifOrientationToDegrees(orientaion);

										Matrix matrix = new Matrix();
										matrix.setRotate(degree);

										bitmapCache = Bitmap.createBitmap(bitmapCache, 0, 0, bitmapCache.getWidth(), bitmapCache.getHeight(), matrix, true);
									}
								} catch (IOException e) {
									e.printStackTrace();
								}
								ImageGalleryLoaderManager.addGalleryBitmapToCache("file://" + a_strUrl, bitmapCache);
							}

						}
						else
						{
							bitmapCache = MediaStore.Video.Thumbnails.getThumbnail(m_Context.getContentResolver(), a_longIndex, MediaStore.Video.Thumbnails.MINI_KIND, null);
							if (bitmapCache != null)
								ImageGalleryLoaderManager.addGalleryBitmapToCache("file://" + a_strUrl, bitmapCache);
							else {
								bitmapCache = MediaStore.Video.Thumbnails.getThumbnail(m_Context.getContentResolver(), a_longIndex, MediaStore.Video.Thumbnails.MICRO_KIND, null);
								if(bitmapCache != null)
									ImageGalleryLoaderManager.addGalleryBitmapToCache("file://" + a_strUrl, bitmapCache);
							}
						}
					}
				}
				return bitmapCache;
			}

			@Override
			protected void onPostExecute(Bitmap result)
			{
				String a_strCompTag = (String) a_ivQueue.getTag();
				if (result != null && a_strCompTag != null && a_strCompTag.equalsIgnoreCase(a_strUrl))
					a_ivQueue.setImageBitmap(result);
				

				super.onPostExecute(result);
			}

		}
	}

	public class FileViewHolder {
		ImageView	imgQueue;
		ImageView	imgQueueMultiSelected;
		TextView tvSelectedNumber;
	}

	public void clearCache()
	{
		// imageLoader.clearDiscCache();
		// imageLoader.clearMemoryCache();
	}

	public void clear()
	{
		data.clear();
		notifyDataSetChanged();
	}

	public static int exifOrientationToDegrees(int exifOrientation){
		if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
			return 90;
		} else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
			return 180;
		} else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
			return 270;
		} return 0;
	}
}
