package com.gmp.rusk.datamodel;

import java.util.ArrayList;

public class SNSGroupSearchListData {
	
	public int m_nBoardNo = 0;
	public String m_strGroupName = "";
	public int m_nUserNo = 0;
	public String m_strUserName = "";
	public String m_strCompanyOrDepartment = "";
	public String m_strUserImageUrl = "";
	public String m_strCreatedDate = "";
	public String m_strUpdatedDate = "";
	public String m_strComment = "";
	public int m_nReplyCount = 0;
	public String m_strType = "";
	public boolean m_isLiked = false;
	public int m_nLikeCount = 0;
	public ArrayList<SNSBoardFileData> m_arrBoardFileData = new ArrayList<SNSBoardFileData>();
	
	public SNSGroupSearchListData(int a_nBoardNo, String a_strGroupName, int a_nUserNo, String a_strUserName, String a_strCompanyOrDepartment, 
			String a_strUserImageUrl, String a_strCreatedDate, String a_strUpdatedDate, String a_strComment, int a_nReplyCount, String a_strType, boolean a_isLiked, int a_nLikeCount)
	{
		m_nBoardNo = a_nBoardNo;
		m_strGroupName = a_strGroupName;
		m_nUserNo = a_nUserNo;
		m_strUserName = a_strUserName;
		m_strCompanyOrDepartment = a_strCompanyOrDepartment;
		m_strUserImageUrl = a_strUserImageUrl;
		m_strCreatedDate = a_strCreatedDate;
		m_strUpdatedDate = a_strUpdatedDate;
		m_strComment = a_strComment;
		m_nReplyCount = a_nReplyCount;
		m_strType = a_strType;
		m_isLiked = a_isLiked;
		m_nLikeCount = a_nLikeCount;

	}
}
