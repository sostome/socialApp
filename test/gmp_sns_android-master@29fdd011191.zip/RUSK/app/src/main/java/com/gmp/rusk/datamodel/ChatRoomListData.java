package com.gmp.rusk.datamodel;
import java.io.Serializable;
import java.util.ArrayList;

@SuppressWarnings("serial")

public class ChatRoomListData {
	String m_strRoomID = "";					//사용자 번호
	String m_strName = "";				//사용자 이름
	int m_nType = 0;					//마지막 메시지 타입
	String m_strText = "";				//마지막 메시지
	long m_lTime = 0;				//마지막 메시지 시간
	int	m_nMessageCount = 0;			//읽지 않은 메시지 갯수
	int m_nOwnerID = 0;
	boolean m_isAlarm = true;			//알람 On/Off
	int m_nStatus = 2;					//마지막 메세지 전송 상태
	boolean m_isFavorite = false;
	int m_nBackgroundColor = 0;
	ArrayList<String> m_arrRoomMemberList = null; 	// Room MemberList

	boolean m_isTitleEdited = false;

	public ChatRoomListData(){

	}

	public ChatRoomListData(String a_strRoomID, String a_strName, int a_nType, String a_strText, long a_lTime, int a_nMessageCount, int a_nOwnerID, boolean a_isAlarm, int a_nStatus, boolean a_isFavorite,int a_nBackgroundColor) {
		m_strRoomID = a_strRoomID;
		m_strName = a_strName;
		m_nType = a_nType;
		m_strText = a_strText;
		m_lTime = a_lTime;
		m_nMessageCount = a_nMessageCount;
		m_nOwnerID = a_nOwnerID;
		m_isAlarm = a_isAlarm;
		m_nStatus = a_nStatus;
		m_isFavorite = a_isFavorite;
		m_nBackgroundColor = a_nBackgroundColor;
	}

	public ChatRoomListData(String a_strRoomID, String a_strName, int a_nType, String a_strText, long a_lTime, int a_nMessageCount, int a_nOwnerID, boolean a_isAlarm, int a_nStatus, boolean a_isFavorite,int a_nBackgroundColor, boolean a_isTitleEdited) {
		m_strRoomID = a_strRoomID;
		m_strName = a_strName;
		m_nType = a_nType;
		m_strText = a_strText;
		m_lTime = a_lTime;
		m_nMessageCount = a_nMessageCount;
		m_nOwnerID = a_nOwnerID;
		m_isAlarm = a_isAlarm;
		m_nStatus = a_nStatus;
		m_isFavorite = a_isFavorite;
		m_nBackgroundColor = a_nBackgroundColor;
		m_isTitleEdited = a_isTitleEdited;
	}

	public String getRoomID(){
		return m_strRoomID;
	}
	
	public String getName(){
		return m_strName;
	}
	
	public String getText(){
		return m_strText;
	}
	
	public int getNosee(){
		return m_nMessageCount;
	}
	
	public void setNosee(int nNoSee){
		m_nMessageCount = nNoSee;
	}
	public long getLastMessageTime(){
		return m_lTime;
	}
	
	public int getType(){
		return m_nType;
	}
	
	public int getOwnerID(){
		return m_nOwnerID;
	}
	
	public boolean getAlarm(){
		return m_isAlarm;
	}
	
	public int getStatus(){
		return m_nStatus;
	}
	
	public boolean getFavorite(){
		return m_isFavorite;
	}
	
	public void setLastMessageTime(){
		m_nMessageCount = 0;
	}
	
	public void setLastMessageStatus(){
		m_nStatus = 2;
	}

	public int getBackgroundColor() {
		return m_nBackgroundColor;
	}

	public void setBackgroundColor(int m_nBackgroundColor) {
		this.m_nBackgroundColor = m_nBackgroundColor;
	}

	public void setMemberList(ArrayList<String> memberList){m_arrRoomMemberList = memberList;}

	public ArrayList<String> getMemberList(){return m_arrRoomMemberList;}

	public boolean getTitleEdited() {
		return m_isTitleEdited;
	}
}
