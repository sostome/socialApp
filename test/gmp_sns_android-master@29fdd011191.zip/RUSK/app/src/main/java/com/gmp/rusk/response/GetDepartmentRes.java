package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.DepartmentsData;
import com.gmp.rusk.datamodel.NavigationInfoData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.utils.CommonLog;

public class GetDepartmentRes extends Res{
//	private final String JSON_NAVIGATIONINFOCOUNT 		= "navigationInfoCount";
	private final String JSON_NAVIGATIONINFO 			= "navigationInfo";
	private final String JSON_DEPARTMENTCODE			= "departmentCode";
	private final String JSON_DEPARTMENTNAME			= "departmentName";
	
//	private final String JSON_DEPARTMENTCOUNT 			= "departmentCount";
	private final String JSON_DEPARTMENTS				= "departments";
//	private final String JSON_DEPARTMENTCODE			= "departmentCode";
//	private final String JSON_DEPARTMENTNAME			= "departmentName";
	private final String JSON_LEAF						= "leaf";

			
	ArrayList<NavigationInfoData> m_arrNavigationInfoDatas = null;
	ArrayList<DepartmentsData> m_arrDepartmentsDatas = null; 
	ArrayList<DepartmentUserListData> m_arrDepartmentUserListDatas = null; 
	
	public GetDepartmentRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_NAVIGATIONINFO)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_NAVIGATIONINFO);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrNavigationInfoDatas = new ArrayList<NavigationInfoData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						String strDepartmentCode = jsonItem.optString(JSON_DEPARTMENTCODE);
						String strDepartmentName = jsonItem.optString(JSON_DEPARTMENTNAME);
						
						NavigationInfoData item = new NavigationInfoData(strDepartmentCode, strDepartmentName);
						
						m_arrNavigationInfoDatas.add(item);
					}
				}
			}
			
			if (!jsonRoot.isNull(JSON_DEPARTMENTS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_DEPARTMENTS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrDepartmentsDatas = new ArrayList<DepartmentsData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						String strDepartmentCode = jsonItem.optString(JSON_DEPARTMENTCODE);
						String strDepartmentName = jsonItem.optString(JSON_DEPARTMENTNAME);
						boolean isLeaf = jsonItem.optBoolean(JSON_LEAF);
						
						DepartmentsData item = new DepartmentsData(strDepartmentCode, strDepartmentName, isLeaf);
						
						m_arrDepartmentsDatas.add(item);
					}
				}
			}
			
			/*if (!jsonRoot.isNull(JSON_USERS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_USERS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrDepartmentUserListDatas = new ArrayList<DepartmentUserListData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						int nUserNo = jsonItem.optInt(JSON_USERNO);
						String strName = jsonItem.optString(JSON_NAME);
						String strCharge = jsonItem.optString(JSON_CHARGE);
						String strDepartment = jsonItem.optString(JSON_DEPARTMENT);
						String strParentDepartment = jsonItem.optString(JSON_PARENTDEPARTMENT);
						boolean isImageAvailable = jsonItem.optBoolean(JSON_IMAGEAVAILABLE);
						boolean isAvailable = jsonItem.optBoolean(JSON_AVAILABLE);
						
						DepartmentUserListData item = new DepartmentUserListData(nUserNo, strName, strCharge, strDepartment, strParentDepartment, isImageAvailable, isAvailable);
						
						m_arrDepartmentUserListDatas.add(item);
					}
				}
			}*/
			ArrayList<UserInfoData> datas = getUserInfoDatas();
			if(datas != null && datas.size() > 0)
				m_arrDepartmentUserListDatas = new ArrayList<DepartmentUserListData>();
			for(int i = 0; i < datas.size(); i++){
				DepartmentUserListData userData = new DepartmentUserListData(datas.get(i));
				m_arrDepartmentUserListDatas.add(userData);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}
	
	public ArrayList<NavigationInfoData> getNavigationInfoData(){
		return m_arrNavigationInfoDatas;
	}
	
	public ArrayList<DepartmentsData> getDepartmentsData(){
		return m_arrDepartmentsDatas;
	}
	
	public ArrayList<DepartmentUserListData> getDepartmentUserListData(){
		return m_arrDepartmentUserListDatas;
	}
}
