package com.gmp.rusk.datamodel;

import com.gmp.rusk.utils.StaticString;

public class PartnerSearchListData {
	public int m_nUserNo = 0;					//사용자 번호
	public String m_strName = "";				//사용자 이름
	public String m_strCharge = "";
	public String m_strPosition = "";
	public String m_strAffliaction = "";			//파트너 소속명
	public boolean m_isImageAvailable = false;	//이미지 보유 여부
	public boolean m_isAvailable = false;		//승인 가능 여부
	public boolean m_isChecked = false;
	public String m_strType = StaticString.VARIANT_PARTNER;
	
	public PartnerSearchListData(int a_nUserNo, String a_strName,String a_strCharge,String a_strPosition ,String a_strAffliation, boolean a_isImageAvailable, boolean a_isAvailable, String a_strType) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCharge = a_strCharge;
		m_strPosition = a_strPosition;
		m_strAffliaction = a_strAffliation;
		m_isImageAvailable = a_isImageAvailable;
		m_isAvailable = a_isAvailable;
		m_strType = a_strType;
	}
}
