package com.gmp.rusk.request;

/**
 *	@author kch
 *			이용약관 요청
 *			method : get
 */

public class GetTermTextReq extends Req{

	private String APINAME = "user";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "GET";


	public GetTermTextReq()
	{
		APINAME = APINAME  + "/term";
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
