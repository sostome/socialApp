package com.gmp.rusk.backup;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.IntroAct;
import com.gmp.rusk.act.SetDeviceChangeAct;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.ChattingDBManagerForDelayMessage;
import com.gmp.rusk.db.DBBackup;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.db.TTalkDBManager.SNSGroupDBManager;
import com.gmp.rusk.service.XmppUtils;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.ResolveText;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

public class IntroBackUp {

	public MyApp App = MyApp.getInstance();

	public IntroBackUp(Context context, String strJson){
		
		try {
			JSONObject jsonRoot = new JSONObject(strJson);
			if(!jsonRoot.isNull(DBBackup.JSON_CHATTINGMSGS)){			
				JSONArray jsonArray = jsonRoot.getJSONArray(DBBackup.JSON_CHATTINGMSGS);
				for(int i = 0; i < jsonArray.length(); i++){

					JSONObject roomObject = jsonArray.getJSONObject(i);
					String strRoomID = roomObject.getString(DBBackup.JSON_ROOMID).split("@")[0];
					
					//개인방 만들기
					
					if(strRoomID.length() < 8){
						ChattingRoomInfoData singleRoomData = RoomDBManager.getChattingRoom(context, strRoomID);				

						if (singleRoomData == null) {

						UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(context, Integer.parseInt(strRoomID));

							String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
							ChattingRoomInfoData data;
							try {
								LocalAesCrypto crypto = new LocalAesCrypto();
								data = new ChattingRoomInfoData(strRoomID, crypto.encrypt(strFriendUserName), true,
										App.m_MyUserInfo.m_nUserNo, false);
								RoomDBManager.insertRoom(context, data);
							} catch (Exception e) {
								// TODO Auto-generated
								// catch block
								e.printStackTrace();
							}

						
						}
					}
					boolean isRoomFavorite = roomObject.getBoolean(DBBackup.JSON_ROOMBOOKMARKED);
					String strRoomName = null;
					if(!roomObject.isNull(DBBackup.JSON_CTROOMTITLE))
						strRoomName = roomObject.getString(DBBackup.JSON_CTROOMTITLE);
									
					ChattingDBManagerForDelayMessage chattingDBMng = new ChattingDBManagerForDelayMessage(context);
					int nRoomUserCount = chattingDBMng.getChattingUser(strRoomID).size();
					//ChattingDBManager chattingDBMngd = new ChattingDBManager(context);
					//chattingDBMngd.openWritable(strRoomID);
					JSONArray jsonArrayMsg = roomObject.getJSONArray(DBBackup.JSON_MSGS);
					for(int j = 0; j < jsonArrayMsg.length(); j ++){
						ChattingMessageData data = new ChattingMessageData();
						JSONObject msgObject = jsonArrayMsg.getJSONObject(j);
						data.m_strMsgId = msgObject.getString(DBBackup.JSON_MESSAGEID);
						
						boolean isMe = false;
						int nSendID = msgObject.getInt(DBBackup.JSON_SENDERID);
						if(nSendID == App.m_EntryData.m_nUserNo){
							data.m_nSendUserId = 0;
							isMe = true;
						} else {
							data.m_nSendUserId = nSendID;
						}
						data.m_lnMsgSendTime = msgObject.getLong(DBBackup.JSON_MESSAGETIMESTAMP);
						data.m_isRead = msgObject.getBoolean(DBBackup.JSON_ISREAD);
						if(msgObject.getString(DBBackup.JSON_READCOUNT).equals("undefine")){
							data.m_nNoReadUserCount = nRoomUserCount; 
						} else {
							data.m_nNoReadUserCount = Integer.parseInt(msgObject.getString(DBBackup.JSON_READCOUNT));
						}
						data.m_nSendStatus = 2;
						
						int nTempMessageType = msgObject.getInt(DBBackup.JSON_MESSAGETYPE);
						if(nTempMessageType == DBBackup.MESSAGETYPE_SYSTEM){
							data.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
							data.m_strMsgText = msgObject.getString(DBBackup.JSON_MESSAGE);
							data.m_isRead = true;
						} else if(nTempMessageType == DBBackup.MESSAGETYPE_TEXT){
							data.m_nMsgType = 0;						
							data.m_strMsgText = msgObject.getString(DBBackup.JSON_MESSAGE);
							if(msgObject.has(DBBackup.JSON_EMOTICON)) {
								data.m_strEmoticon = msgObject.getString(DBBackup.JSON_EMOTICON);
								if(isMe){
									data.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
								} else {
									data.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
								}
							}
						} else if(nTempMessageType == DBBackup.MESSAGETYPE_URGENT){
							data.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
							data.m_strMsgText = msgObject.getString(DBBackup.JSON_MESSAGE);
						} else if(nTempMessageType == DBBackup.MESSAGETYPE_FILE){
							String strTempFileType = msgObject.getString(DBBackup.JSON_FILETYPE);
							if(strTempFileType.equals(StaticString.FILE_TYPE_IMAGE)){
								if(isMe)
									data.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;
								else
									data.m_nMsgType = StaticString.CHAT_ROOM_OTHER_IMAGE;
								
								JSONObject jsonImageSize = msgObject.getJSONObject(DBBackup.JSON_IMAGESIZE);

								XmppUtils utils = new XmppUtils();
								utils.strMimeType = StaticString.FILE_TYPE_IMAGE;
								utils.strUrl = msgObject.getString(DBBackup.JSON_FILEURL);
								utils.strWidth = jsonImageSize.getString(DBBackup.JSON_IMAGEWIDTH);
								utils.strHeight = jsonImageSize.getString(DBBackup.JSON_IMAGEHEIGHT);
								utils.strThumb = msgObject.getString(DBBackup.JSON_THUMBNAILURL);
								data.m_strMsgText = utils.getFileExText();
							} else if(strTempFileType.equals(StaticString.FILE_TYPE_NORMAL)){
								if(isMe)
									data.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
								else
									data.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
								String strCreateTime = "";
								if(!msgObject.isNull(DBBackup.JSON_FILETIMESTAMP)){
									strCreateTime = msgObject.getString(DBBackup.JSON_FILETIMESTAMP);
								}
								else {
									strCreateTime = msgObject.getString(DBBackup.JSON_MESSAGETIMESTAMP);
								}
								XmppUtils utils = new XmppUtils();
								utils.strFileName = msgObject.getString(DBBackup.JSON_FILENAME);
								utils.strMimeType = StaticString.FILE_TYPE_NORMAL;
								utils.strUrl = msgObject.getString(DBBackup.JSON_FILEURL);
								utils.strCreateTime = strCreateTime;
								data.m_strMsgText = utils.getFileExText();
								
							} else if(strTempFileType.equals(StaticString.FILE_TYPE_VIDEO)) {
								if(isMe)
									data.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
								else
									data.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
								String strCreateTime = "";
								if(!msgObject.isNull(DBBackup.JSON_FILETIMESTAMP)){
									strCreateTime = msgObject.getString(DBBackup.JSON_FILETIMESTAMP);
								}
								else {
									strCreateTime = msgObject.getString(DBBackup.JSON_MESSAGETIMESTAMP);
								}
								XmppUtils utils = new XmppUtils();
								utils.strMimeType = StaticString.FILE_TYPE_VIDEO;
								utils.strUrl = msgObject.getString(DBBackup.JSON_FILEURL);
								utils.strThumb = msgObject.getString(DBBackup.JSON_THUMBNAILURL);
								utils.strCreateTime = strCreateTime;
								data.m_strMsgText = utils.getFileExText();
							}

							else if(strTempFileType.equals(StaticString.FILE_TYPE_CONTACT)) {
								if(isMe)
									data.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
								else
									data.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;

								XmppUtils utils = new XmppUtils();
								utils.strFileName = msgObject.getString(DBBackup.JSON_FILENAME);
								utils.strMimeType = StaticString.FILE_TYPE_CONTACT;
								utils.strUrl = msgObject.getString(DBBackup.JSON_FILEURL);
								data.m_strMsgText = utils.getFileExText();

							}
						} 
						
						
						chattingDBMng.insertChattingMessage(strRoomID, data);
						
					}
					chattingDBMng.end();
					//chattingDBMngd.close();
					if(strRoomName != null){
						LocalAesCrypto crypto = new LocalAesCrypto();
						RoomDBManager.updateRoom(context, strRoomID, crypto.encrypt(strRoomName), true);
					}
					if(isRoomFavorite){
						RoomDBManager.updateRoomFavorite(context, strRoomID, isRoomFavorite);
					}
				}
			}
			if(!jsonRoot.isNull(DBBackup.JSON_GROUPS)){
				JSONArray jsonArrayGroups = jsonRoot.getJSONArray(DBBackup.JSON_GROUPS);
				JSONObject roomFavoriteObject = jsonArrayGroups.getJSONObject(0);				
				String strRoomFavorites = roomFavoriteObject.getString(DBBackup.JSON_GROUPFAVORITE);
				
				SharedPref pref = SharedPref.getInstance(context);
				pref.setStringPref(SharedPref.PREF_BACKUP_GROUP_FAVORITE, strRoomFavorites);
//				if(!strRoomFavorites.contains("|")){
//					String strFavoriteRoomID = strRoomFavorites;
//					SNSGroupDBManager.updateSNSMyGroupInfoFavorite(context, Integer.parseInt(strFavoriteRoomID), true);
//				} else {
//					String[] arrayFavoriteRoom = strRoomFavorites.split("\\|");	
//					int nFavoriteRoomCount = arrayFavoriteRoom.length;
//					for(int i = 0; i < nFavoriteRoomCount; i++){
//						String strFavoriteRoomID = arrayFavoriteRoom[i];
//						SNSGroupDBManager.updateSNSMyGroupInfoFavorite(context, Integer.parseInt(strFavoriteRoomID), true);
//					}
//				}
				
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
