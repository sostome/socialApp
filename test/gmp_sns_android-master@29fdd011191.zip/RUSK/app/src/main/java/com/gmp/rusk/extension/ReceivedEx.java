package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class ReceivedEx implements PacketExtension{
		public static final String NAMESPACE = "urn:xmpp:receipts";
		public static final String ELEMENT_NAME = "received";
		
		private String id;
		private boolean isGroup;
		
		public ReceivedEx(){}
		public ReceivedEx(String id){
			this.id = id;
			this.isGroup = false;
		}
		public ReceivedEx(String id, boolean isGroup){
			this.id = id;
			this.isGroup = isGroup;
		} 
		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}
		
		public String getId(){
			return id;
		}

		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();
			// 1.5.5 에서 규격 수정됨
//			if(isGroup){
//				buf.append("<query xmlns='").append(MultiChatMsgEx.NAMESPACE).append("'/>");
//			}
			buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
			return buf.toString();
		}
		
		public static class Provider implements PacketExtensionProvider {

			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
	            String id = "";
				boolean done = false;
				int cnt = parser.getAttributeCount();
				for(int i = 0; i < cnt; i++){
					if(parser.getAttributeName(i).equals("id")){
						id = parser.getAttributeValue(i);		
					}
				}
				while(!done){
					int eventType = parser.next();					
					if (eventType == XmlPullParser.START_TAG) {
		                if (parser.getName().equals("id")) {
		                	id = parser.nextText();
		                }
		            }
		            else if (eventType == XmlPullParser.END_TAG) {
		                if (parser.getName().equals(ELEMENT_NAME)) {
		                    done = true;
		                }
		            }
				}
				return new ReceivedEx(id);
			}
		}
	}