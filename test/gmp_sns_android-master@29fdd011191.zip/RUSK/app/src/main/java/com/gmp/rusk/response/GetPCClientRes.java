package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class GetPCClientRes extends Res{
	
	private final String JSON_HOSTNAME				= "hostname";
	private final String JSON_DEVICEUID				= "deviceUID";
	
	private String m_strHostName = "";
	private String m_strDeviceUID = "";
	
	public GetPCClientRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if(jsonRoot.has(JSON_HOSTNAME))
				m_strHostName = jsonRoot.getString(JSON_HOSTNAME);
			if(jsonRoot.has(JSON_DEVICEUID))
				m_strDeviceUID = jsonRoot.getString(JSON_DEVICEUID);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getHostName()
	{
		return m_strHostName;
	}
	
	public String getDeviceUID()
	{
		return m_strDeviceUID;
	}
}