package com.gmp.rusk.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.FindIdPwTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostFindPartnerIdReq;
import com.gmp.rusk.request.PostSendEmailFindPartnerIdReq;
import com.gmp.rusk.response.PostFindPartnerIdRes;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.Utils;


/**
 * FindIdFlag
 * @author subi78
 * FindIdFlag - ID 찾기 Fragment
 */
public class FindIdFlag extends Fragment implements OnClickListener{

	public MyApp App = MyApp.getInstance();
	private View m_vFindId = null;	
	
	private FragmentActivity m_Activity = null;
	
	EditText et_findid_name;
	EditText et_findid_email;

	LinearLayout layout_comment;
	LinearLayout layout_findid;
	LinearLayout layout_find_result;
	
	String m_strName = "";
	String m_strEmail = "";
	
	private ProgressDlg m_Progress = null;
	
	private CommonPopup m_Popup = null;
	public boolean m_isRunning = false;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        m_Activity = getActivity();

    }
    
    /**
     * The Fragment's UI is just a simple text view showing its
     * instance number.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    	
    	m_vFindId = inflater.inflate(R.layout.fragact_findid, container, false);
    	
    	((FindIdPwTabAct)m_Activity).setTitle(getString(R.string.findidpwtab_title));

		layout_comment = (LinearLayout)m_vFindId.findViewById(R.id.layout_comment);
    	layout_findid = (LinearLayout)m_vFindId.findViewById(R.id.layout_findid);
    	layout_find_result = (LinearLayout)m_vFindId.findViewById(R.id.layout_find_result);
    	
    	initSetUI();
    	
        return m_vFindId;
    }
    
    @Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
    

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_ok)
		{
			m_strName = et_findid_name.getText().toString();
			m_strEmail = et_findid_email.getText().toString();
			
			if(m_strName.length() == 0)
			{
				m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_name_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(!Utils.isEmailAddress(m_strEmail))
			{
				m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_email_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			requestPostFindPartnerId(m_strName, m_strEmail);
		}
		else if(v.getId() == R.id.ib_email)
		{
			requestPostSendEmailFindPartnerId(m_strName, m_strEmail);
		}
		/*else if(v.getId() == R.id.ib_go_login)
		{
			m_Activity.finish();
		}*/
		else if(v.getId() == R.id.ib_pop_ok)
		{
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			popup_ok.cancel();
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		else if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(m_Activity);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_REQ_ID_EMAIL)
			{
				popup_ok_long.cancel();
				m_Activity.finish();
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Activity);
			}
			else
			{
				popup_ok_long.cancel();
			}
		}
	}
	
    private void initSetUI()
    {
		layout_comment.setVisibility(View.VISIBLE);
    	layout_findid.setVisibility(View.VISIBLE);
    	layout_find_result.setVisibility(View.INVISIBLE);
    	et_findid_name = (EditText)m_vFindId.findViewById(R.id.et_findid_name);
    	et_findid_email = (EditText)m_vFindId.findViewById(R.id.et_findid_email);
    	
    	Button ib_ok = (Button)m_vFindId.findViewById(R.id.ib_ok);
    	ib_ok.setOnClickListener(this);
    }
    
    private void initSetFindResultUI(String a_strFindId)
    {
		layout_comment.setVisibility(View.INVISIBLE);
    	layout_findid.setVisibility(View.INVISIBLE);
    	layout_find_result.setVisibility(View.VISIBLE);
    	TextView et_findid_id = (TextView)m_vFindId.findViewById(R.id.et_findid_id);
    	et_findid_id.setText(a_strFindId);
    	Button ib_email = (Button)m_vFindId.findViewById(R.id.ib_email);
    	ib_email.setOnClickListener(this);
    	
    	/*ImageButton ib_go_login = (ImageButton)m_vFindId.findViewById(R.id.ib_go_login);
    	ib_go_login.setOnClickListener(this);*/
    }
	
    
	private void requestPostFindPartnerId(String a_strName, String a_strEmail)
	{
		showProgress();
		PostFindPartnerIdReq req = new PostFindPartnerIdReq(a_strName, a_strEmail);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				PostFindPartnerIdRes res = new PostFindPartnerIdRes(a_strData);
				initSetFindResultUI(res.m_strUserId);
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(getActivity(), FindIdFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_FOUND)
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_no_idpw));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
	private void requestPostSendEmailFindPartnerId(String a_strName, String a_strEmail)
	{
		showProgress();
		PostSendEmailFindPartnerIdReq req = new PostSendEmailFindPartnerIdReq(a_strName, a_strEmail);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_REQ_ID_EMAIL);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_findidpw_requestid_email).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(getActivity(), FindIdFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, FindIdFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
	
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}

}