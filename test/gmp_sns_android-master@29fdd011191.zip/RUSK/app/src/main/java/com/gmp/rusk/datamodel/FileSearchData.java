package com.gmp.rusk.datamodel;

public class FileSearchData {
	public String m_strFileName = "";
	public String m_strFilePath = "";
	public long m_lnFileSize = 0L;
}
