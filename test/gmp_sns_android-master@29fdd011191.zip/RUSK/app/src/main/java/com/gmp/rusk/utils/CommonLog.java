package com.gmp.rusk.utils;

import android.content.Context;
import android.util.Log;

public class CommonLog {
	
	public static void i(Context context, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.i(context.toString(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(context.toString(), a_strLogMsg);
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static void i(Class c, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.i(c.toString(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(c.toString(), a_strLogMsg);
			}
			
		}
	}
	
	public static void i(String a_strLogTitle, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.i(a_strLogTitle, a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(a_strLogTitle, a_strLogMsg);
			}
			
		}
	}
	
	public static void v(Context context, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.v(context.toString(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(context.toString(), a_strLogMsg);
			}
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static void v(Class c, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.v(c.getName(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(c.getName(), a_strLogMsg);
			}
			
		}
	}
	
	public static void v(String a_strLogTitle, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.v(a_strLogTitle, a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(a_strLogTitle, a_strLogMsg);
			}
			
		}
	}
	
	public static void d(Context context, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.d(context.toString(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(context.toString(), a_strLogMsg);
			}
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static void d(Class c, String a_strLogMsg)
	{		
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.d(c.getName(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(c.getName(), a_strLogMsg);
			}
			
		}
	}
	
	public static void d(String a_strLogTitle, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.d(a_strLogTitle, a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(a_strLogTitle, a_strLogMsg);
			}
			
		}
	}
	
	public static void w(Context context, String a_strLogMsg)
	{
		Log.w(context.toString(), a_strLogMsg);
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.d(context.toString(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(context.toString(), a_strLogMsg);
			}
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static void w(Class c, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.w(c.getName(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(c.getName(), a_strLogMsg);
			}
			
		}
	}
	
	public static void w(String a_strLogTitle, String a_strLogMsg)
	{
		
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.w(a_strLogTitle, a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(a_strLogTitle, a_strLogMsg);
			}
			
		}
	}
	
	public static void e(Context context, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.e(context.toString(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(context.toString(), a_strLogMsg);
			}
			
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static void e(Class c, String a_strLogMsg)
	{
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.e(c.getName(), a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(c.getName(), a_strLogMsg);
			}
			
		}
	}
	
	public static void e(String a_strLogTitle, String a_strLogMsg)
	{
		
		if(AppSetting.FEATURE_DEBUG)
		{
			Log.e(a_strLogTitle, a_strLogMsg);
			
			if(AppSetting.FEATURE_FILELOG) {
				FileLog.o(a_strLogTitle, a_strLogMsg);
			}
			
		}
	}
}
