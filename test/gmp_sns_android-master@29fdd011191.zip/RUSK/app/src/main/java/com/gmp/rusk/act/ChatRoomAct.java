package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.provider.ContactsContract;
import android.provider.ContactsContract.Contacts;
import android.provider.OpenableColumns;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.SparseArray;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.service.XmppUtils;
import com.kris520.apngdrawable.ApngDrawable;
import com.kris520.apngdrawable.ApngImageUtils;
import com.kris520.apngdrawable.ApngLoader;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomImageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.FileInfo;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.datamodel.ReadCountData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.ChattingSelectDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.fragment.ChatRoomEmoticonViewpagerItemFrag;
import com.gmp.rusk.layout.adapter.ChatRoomAdapter;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.PriorityAsyncTask;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostFileUploadReq;
import com.gmp.rusk.request.PostReadCountReq;
import com.gmp.rusk.request.PostRecommendReq;

import com.gmp.rusk.response.PostFileUploadRes;
import com.gmp.rusk.response.PostReadCountRes;
import com.gmp.rusk.service.XMPPConnectionComplete;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.ScaleImage;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.jivesoftware.smack.packet.Packet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

/**
 * ChatRoomAct
 * 
 * @author kch 채팅방 Activity
 */
public class ChatRoomAct extends CustomActivity implements OnTouchListener {

	private final int REQUEST_CODE_INVITE = 2;
	private final int REQUEST_CODE_SENDMESSAGE = 3;
	private final int REQUEST_CODE_SEND_FILE = 5;
	private final int REQUEST_CODE_CLOUD = 6;
	private final int REQUEST_CODE_PICK_CONTACTS = 7;
	private final int REQUEST_CODE_PREVIEW_CONTACT = 8;
	private final int REQUEST_CODE_ALARM = 9;
	private final int PRINT_MESSAGE_SCROLL = 11;
	private final int PRINT_MESSAGE_NOT_SCROLL = 12;
	private final int PRINT_MESSAGE_PAGING = 13;
	private final int PRINT_MESSAGE_SEARCH = 14;

	private final int ATTACH_FILE_MAX_COUNT = 10;
	private final long ATTACH_FILE_MAX_SIZE = 104857600L;

	String[][] apng = {
			{"skt_anicon01", "skt_anicon02", "skt_anicon03", "skt_anicon04", "skt_anicon05", "skt_anicon06", "skt_anicon07", "skt_anicon08"}
			,{"skt_anicon09", "skt_anicon10", "skt_anicon11", "skt_anicon12", "skt_anicon13", "skt_anicon14", "skt_anicon15", "skt_anicon16"}
			,{"skt_anicon17", "skt_anicon18", "skt_anicon19", "skt_anicon20", "skt_anicon21", "skt_anicon22", "skt_anicon23", "skt_anicon24"}
	};
	String[][] sticon = {
			{"skt_sticon01","skt_sticon02","skt_sticon03","skt_sticon04","skt_sticon05","skt_sticon06","skt_sticon07","skt_sticon08"},
			{"skt_sticon09","skt_sticon10","skt_sticon11","skt_sticon12","skt_sticon13","skt_sticon14","skt_sticon15","skt_sticon16"},
			{"skt_sticon17","skt_sticon18","skt_sticon19","skt_sticon20","skt_sticon21","skt_sticon22","skt_sticon23","skt_sticon24"},
	};

	ListView m_lvChat;
	ChatRoomAdapter m_ChatAdapter;
	ChatRoomData m_RoomData;
	ImageButton m_btnAttach, m_btnSend;
	ImageButton m_btnSendPicture, m_btnSendFile, m_btnVideo, m_btnCamera, m_btnEmoticon, m_btnSendContact;
	ImageButton m_btnEmo01, m_btnEmo02, m_btnEmo03, m_btnEmo04, m_btnEmo05, m_btnEmo06, m_btnEmo07, m_btnEmo08, m_btnEmo09, m_btnEmo10;
	ImageButton m_btnEmo11, m_btnEmo12, m_btnEmo13, m_btnEmo14, m_btnEmo15, m_btnEmo16, m_btnEmo17, m_btnEmoDel, m_btnEmoticonAdd;
	ImageView m_ivBack;
	ImageView m_ivSearchCancel, m_ivSearch;
	TextView m_tvTitle;
	TextView m_tvChatMenuTitle;
	ImageView m_ivChatMenuFavorite;
	RelativeLayout m_ChatTitle;
	RelativeLayout m_ChatSearch;
	DrawerLayout m_layoutDrawerLayout;
	//LinearLayout m_BottomMenu;
	ViewPager m_BottomPager;
	LinearLayout m_EmoticonMenu;
	RelativeLayout m_UrgentMessageClose;
	LinearLayout m_UrgentMessage, m_NewMessage;
	LinearLayout m_MenuRegular2, m_MenuPartner2;
	LinearLayout m_ChatBottom;
	LinearLayout m_SystemRoomLayout;
	LinearLayout m_BottomTotal;
	LinearLayout m_BottomSearch;
	RelativeLayout m_MenuRegular, m_MenuPartner;
	EditText m_etMessage;

	String m_strMessage;
	Packet m_pacMsg;

	// 긴급 메시지
	TextView m_tvUrgentMessage;
	TextView m_tvUrgentMessageInfo;
	ImageView m_ivUrgentImage;
	ImageView m_ivUrgentNotFellowImage;

	// 해당 방 안의 신규 메시지
	TextView m_tvNewMessage;
	TextView m_tvNewMessageInfo;
	ImageView m_ivNewMessageImage;
	ImageView m_ivNewMessageNotFellowImage;

	int m_nBeforeMessageTime = 0;

	boolean m_isReadCountChange = false;
	boolean m_isSearchUpEnd = false;
	boolean m_isSearchDownEnd = false;

	int m_nNoReadCount;
	Intent extras;
	UserListData m_UserData;
	String m_strFriendUserName;
	String m_strFriendUserType;
	int m_nFriendUserNumber;
	String m_strRoomId;
	boolean m_isFavoriteRoom = false;

	ArrayList<Integer> m_arrThisRoomUser;
	ArrayList<String> m_arrNoReadMessageID;
	HashMap<String, Boolean> mapNoReadMessageID;
	
	HashMap<String, ReadCountData> mapBeforeReadCountData;

	// 아직 안 읽은 사람이 있는 메시지
	// ArrayList<String> m_arrNoReadOhterMessageID;
	boolean m_isGetReadUserCount = false;

	// 전달 받은 메시지
	String m_strSendMessage;
	String m_strType;
	// 어디까지 읽었는지
	int m_nReadPosition = -1;
	// 오프라인 메세지를 받아 온 후
	boolean m_isGetOfflineMessage = false;
	// 채팅창에 처음 진입
	boolean m_isFirstRead = true;
	boolean m_isOnStop = false;

	// DB의 메세지 갯수
	int m_nDBMessageCount = 0;
	// 화면에 보여줄 메시지 갯수
	int m_nScreenMessageCount = 20;
	// 현재 어댑터에 들어가있는(혹은 넣을) 리스트의 총 갯수
	int m_nAdapterCount = 200;
	// 페이징 전의 리스트 뷰 아이템 갯수
	int m_nBeforeListViewItemCount = 0;
	CommonPopup m_Popup = null;
	//int m_nPopupType;

	private TakeMediaIntent m_TakeMedia = null;

	boolean m_isAlarm = true;
	// 공지전송 준비 상태
	boolean m_isNotice = false;
	// boolean m_isPush;
	ProgressDlg m_Progress;
	ConnectivityManager cManager;

	NetworkInfo mobile;
	NetworkInfo wifi;

	public static Activity m_Activity = null;
	boolean m_isRefresh = false;
	SparseArray<UserListData> m_arrContacts;
	ArrayList<ChattingMessageData> m_arrChattingMessageData;
	ArrayList<ChatRoomData> m_arrRoomData;

	// 최초에는 모든 메시지에서 noReadCount 체크, 그 후엔 메모리에 있는것만
	boolean m_isFirstGetReadCount = true;

	// 긴급 공지 ID, time
	String m_strUrgentID = "";
	long m_lUrgentTime = 0;

	// Handler m_ReadHandler;
	// Runnable m_ReadRunnable;
	
	//xmpp이상 여부를 체크할 수단이 없어 프로그레스 바가 10초이상 유지될 경우 네트워크 에러 팝업을 띄우게 하였으나,
	//정상적으로 처리 된 후에 다시 프로그레스바가 뜰때에도 이전 handler내의 if문이 적용 되기에 구분을 위해 넣음.
	private int m_nProgressCount = 0;
	private int m_nDoneProgressCount = 0;

	private ArrayList<ChattingRoomImageData> m_RoomImageData;
	
	//하단 메뉴 페이저 아이콘
	private LinearLayout m_ChatMenuIconLayout;
	private ImageView m_ivChatMenuIcon1;
	private ImageView m_ivChatMenuIcon2;

	//하단 메뉴 아이콘 2
	private LinearLayout m_EmoticonSelelctLayout;
	private LinearLayout m_EmoticonContainer;
	private ImageView m_ivEmoticonDisplay;
	private ImageView m_addEmoticonClose;
	private HorizontalScrollView m_hscroll;
	private LinearLayout m_hscroll_badge;

	private boolean m_isGetReadCount = false;

	private int[] m_arrUserID = new int[1];

	private String m_strCopyText;

	Fragment current_frag;
	LinearLayout m_layout_indicator;
	LinearLayout m_layout_basic_emoticon;
	ViewPager m_vpEmoticonPager;
	ImageView m_ivEmoindicator1;
	ImageView m_ivEmoindicator2;
	ImageView m_ivEmoindicator3;
	int max_page = 5;
	int m_nSelect = 0;
	ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

	View[] views = new View[3];
	int m_nemoticonTab_drawIds[][] = {
						{R.drawable.icon_emoticon_small,R.drawable.icon_emoticon_small},
						{R.drawable.skt_sticon_off,R.drawable.skt_sticon_on},
						{R.drawable.skt_acticon_off,R.drawable.skt_acticon_on}};

	//기본 이모티콘을 edittext에 추가하면 위치가 변경되는 현상을 제거하기 위해서 추가
	int m_Edittext_paddingTop;
	int m_nEmoticonAddCount = 0;
	boolean m_isBasicEmoticonPaddingChange = false;
	boolean m_isBasicEmoticonRemain = false;

	//키보드 올라와있는지 아닌지 확인
	boolean m_isKeyboardUP = false;
	//키보드가 아닌 다른것이 올라갔다 내려갔는지 확인
	boolean m_isBeforeOtherBoard = false;
	View m_layout_Chatroom;
	int m_nCurrentSel = 0;
	int m_nCurrentPos = 0;
	int m_nCurrentTag = 0;

	//임시, 대화방 검색
	EditText m_etSearch;

	ImageView m_ivSearchUP, m_ivSearchDown;
	ArrayList<Integer> m_arrSearchOrder = new ArrayList<Integer>();
	ArrayList<String> m_arrSearchID = new ArrayList<String>();
	int m_nNowSearchingIndex = 0;


	String m_strSearchWord = "";

	public String m_strBounceID = "";
	private String m_strCurrentSelectApngEmoticonUrl ="";
	private String m_nCurrentSelectPngEmoticonName = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		/*getWindow().setFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);*/
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatroom);
		m_Activity = ChatRoomAct.this;

		m_arrNoReadMessageID = new ArrayList<String>();
		// m_arrNoReadOhterMessageID = new ArrayList<String>();
		mapNoReadMessageID = new HashMap<String, Boolean>();
		m_arrChattingMessageData = new ArrayList<ChattingMessageData>();

		cManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		mobile = cManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		wifi = cManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

		extras = getIntent();

		// m_isPush =
		// extras.getBooleanExtra(IntentKeyString.INTENT_KEY_CHATROOMGROUP_FROM_PUSH,
		// false);
		m_strCopyText = extras.getStringExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDTEXT);
		m_nFriendUserNumber = extras.getIntExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, 0);
		m_strSendMessage = extras.getStringExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE);
		m_strType = extras.getStringExtra(IntentKeyString.INTENT_KEY_SEND_FILE);
		m_ivBack = (ImageView) findViewById(R.id.iv_chat_back);
		m_ivBack.setOnClickListener(this);


		if (App.m_MyUserInfo == null) {
			CommonLog.e(ChatRoomAct.this, "myUserInfo or AesCrypto is Null");
			m_isListenLoginSuccess = true;
		} else
			initProcess();

	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		super.onConfigurationChanged(newConfig);
	}

	@Override
	protected void onLoginSuccess() {
		// TODO Auto-generated method stub
		initProcess();
		m_isListenLoginSuccess = false;
		super.onLoginSuccess();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_Activity = null;

		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}

	}

	private void initProcess() {
		if (m_nFriendUserNumber != 0) {

			PushController.cancelNotification(this, "" + m_nFriendUserNumber);
			m_UserData = TTalkDBManager.ContactsDBManager.getContacts(this, m_nFriendUserNumber);
			if (m_UserData == null) {
				requestAddedByUserList(m_nFriendUserNumber);
			} else {
				setInfo();
			}

		}
	}

	private void setInfo() {

		//ArrayList<ChattingMessageData> arrChattingMessageData;
		ArrayList<ChattingRoomInfoData> arrChattingRoomInfoData;
		//arrChattingMessageData = new ArrayList<ChattingMessageData>();
		arrChattingRoomInfoData = new ArrayList<ChattingRoomInfoData>();



		if(m_UserData == null){
			m_strFriendUserName = getString(R.string.not_in_db_user);
		} else {
			if(m_UserData.m_strUserType.equals("R")){
				m_strFriendUserType = "R";
			} else {
				m_strFriendUserType = "P";
			}
			if(m_nFriendUserNumber != App.m_MyUserInfo.m_nUserNo){
				m_strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
			} else {
				m_strFriendUserName = getString(R.string.app_name);
			}
		}
		arrChattingRoomInfoData = RoomDBManager.getChattingRoom(this);
		//ChattingDBManager chattingDBMng = new ChattingDBManager(this);

		boolean isRoom = false;
		for (ChattingRoomInfoData data : arrChattingRoomInfoData) {
			if (data.m_strRoomId.equals(Integer.toString(m_nFriendUserNumber))) {
				m_strRoomId = data.m_strRoomId;
				m_isFavoriteRoom = data.m_isFavorite;
				isRoom = true;
				//chattingDBMng.openReadable(m_strRoomId);
				//arrChattingMessageData = chattingDBMng.getChattingMessage(0, 200);
				//chattingDBMng.close();
			}
		}
		//if (arrChattingMessageData == null || arrChattingMessageData.isEmpty()) {
		if(!isRoom){
			// 임시, 자기 아이디가 들어감, 방 아이디에는 친구 번호를

			ChattingRoomInfoData data;
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				data = new ChattingRoomInfoData(Integer.toString(m_nFriendUserNumber), crypto.encrypt(m_strFriendUserName), true,
						App.m_MyUserInfo.m_nUserNo, false);
				
				RoomDBManager.insertRoom(this, data);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			m_strRoomId = Integer.toString(m_nFriendUserNumber);
			if (m_arrContacts == null)
				m_arrContacts = ContactsDBManager.getContactsReturnSparseArray(ChatRoomAct.this);
			UserListData userData = m_arrContacts.get(m_nFriendUserNumber);
			// UserListData userData = ContactsDBManager.getContacts(this,
			// m_nFriendUserNumber);
			CommonLog.e(this, "액티브 : " + userData.m_isActive + " 스테이터스 : " + userData.m_strUserStatus);
			if (!userData.m_isActive || !userData.m_strUserStatus.equals("A")) {

				m_arrUserID[0] = userData.m_nUserNo;

				m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_NOT_USE);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_makeroom_title), getString(R.string.popup_fail_makeroom_text));
				m_Popup.setCancelable(false);
				m_Popup.show();
				//isCheckShowPopup();

			}
			CommonLog.e(this, "방 생성");
		} else {
			if (m_arrContacts == null)
				m_arrContacts = ContactsDBManager.getContactsReturnSparseArray(ChatRoomAct.this);
			UserListData userData = m_arrContacts.get(m_nFriendUserNumber);
			if (m_nFriendUserNumber != App.m_MyUserInfo.m_nUserNo && (!userData.m_isActive || !userData.m_strUserStatus.equals("A"))) {
				m_arrUserID[0] = userData.m_nUserNo;
				m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_NOT_USE);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_makeroom_title), getString(R.string.popup_fail_makeroom_text));
				m_Popup.setCancelable(false);
				m_Popup.show();;
				//isCheckShowPopup();
			}
		}
		m_arrThisRoomUser = new ArrayList<Integer>();
		m_arrThisRoomUser.add(App.m_MyUserInfo.m_nUserNo);
		m_arrThisRoomUser.add(m_nFriendUserNumber);

		init();
	}

	@Override
	protected void onXMPPServiceConnected() {
		// TODO Auto-generated method stub

		super.onXMPPServiceConnected();
		closeProgress();
		mService.addPacketListener(mPacketListener);
		if (mService.isConnected()) {
			if (m_ChatAdapter != null) {
				// m_ChatAdapter.notifyDataSetChanged();
				if (m_isFirstRead)
					printMessage(PRINT_MESSAGE_SCROLL);
				else
					printMessage(PRINT_MESSAGE_NOT_SCROLL);

			}
		} else
			mService.startConnection(m_XMPPConnectionComplete);

	}

	@Override
	protected void onXMPPServiceDisConnected() {
		// TODO Auto-generated method stub
		super.onXMPPServiceDisConnected();
		mService.removePacketListener();
	}

	@Override
	protected void onNetworkChange() {
		// TODO Auto-generated method stub
		super.onNetworkChange();
		mService.removePacketListener();
		mService.addPacketListener(mPacketListener);
	}
	// 방 진입시 읽음 카운트 가져오기
	public void getReadCount() {

		PriorityAsyncTask<Void, Void, Void> task = new PriorityAsyncTask<Void, Void, Void>() {

			ArrayList<String> arrMessageIds = new ArrayList<String>();

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();
				if(m_isFirstGetReadCount && m_arrChattingMessageData.size() > 500){
					showProgress();
				}
			}
			@Override
			protected Void doInBackground(Void... params) {
				// TODO Auto-generated method stub
				m_isGetReadCount = true;
				ChattingDBManager dbMng = new ChattingDBManager(ChatRoomAct.this);
				dbMng.openWritable(m_strRoomId);
				if(m_isFirstGetReadCount){
					ArrayList<ChattingMessageData> arrNoReadMine = dbMng.getChattingMessageNotNoReadMine();
					for(ChattingMessageData noReadMine : arrNoReadMine){
						if(!m_arrNoReadMessageID.contains(noReadMine.m_strMsgId)){
							m_arrNoReadMessageID.add(noReadMine.m_strMsgId);
						}
						mapNoReadMessageID.put(noReadMine.m_strMsgId, true);
					}
				}
				dbMng.updateReadMessageInGetReadCount(mapNoReadMessageID);
				dbMng.close();
				SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
				int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
				int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
				if (nUpdateBadgeCount < 0) {
					nUpdateBadgeCount = 0;
				}
				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
				IconBadge.updateIconBadge(ChatRoomAct.this);
				
				if (!m_arrNoReadMessageID.isEmpty()) {
					mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
				}
				ArrayList<ChattingMessageData> chatData;
				if (m_isFirstGetReadCount) {
					CommonLog.e(getClass().getSimpleName(), "First get no read count!!!");
//					ChattingDBManager dbMng = new ChattingDBManager(ChatRoomAct.this);
//					dbMng.openReadable(m_strRoomId);
//					chatData = dbMng.getChattingMessageNotNoReadCount0();
//					dbMng.close();
					ArrayList<ChattingMessageData> arrTempData = new ArrayList<ChattingMessageData>();
					for (int i = m_arrChattingMessageData.size() - 1; i >= 0; i--) {
						if (m_arrChattingMessageData.get(i).m_nNoReadUserCount > 0) {
							arrTempData.add(m_arrChattingMessageData.get(i));
						}
					}
					chatData = new ArrayList<ChattingMessageData>(arrTempData);
					m_isFirstGetReadCount = false;
				} else {
					ArrayList<ChattingMessageData> arrTempData = new ArrayList<ChattingMessageData>();
					for (int i = m_arrChattingMessageData.size() - 1; i >= 0; i--) {
						if (m_arrChattingMessageData.get(i).m_nNoReadUserCount > 0) {
							arrTempData.add(m_arrChattingMessageData.get(i));
						}
					}
					chatData = new ArrayList<ChattingMessageData>(arrTempData);
				}

				for (ChattingMessageData data : chatData) {
					arrMessageIds.add(data.m_strMsgId + "|" + data.m_lnMsgSendTime);
				}
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				if (arrMessageIds.size() != 0) {
					PostReadCountReq req = new PostReadCountReq(arrMessageIds);
					WebAPI webApi = new WebAPI(ChatRoomAct.this);
					webApi.request(req, new WebListener() {

						@Override
						public void onPreRequest() {
							// TODO Auto-generated method stub
							if(mapBeforeReadCountData == null)
								mapBeforeReadCountData = new HashMap<String, ReadCountData>();
						}

						@Override
						public void onPostRequest(final String a_strData) {
							// TODO Auto-generated method stub
							final PostReadCountRes res = new PostReadCountRes(a_strData);
							
							//서버에서 내려온 리드 카운트 리스트
							ArrayList<ReadCountData> arrReadCountData = res.getReadCountList();
							//최종적으로 사용할 리드 카운트 리스트
							ArrayList<ReadCountData> arrUseReadCountData = new ArrayList<ReadCountData>();
							//서버에서 내려온 리드 카운트를 토대로 만들어진 맵
							HashMap<String, ReadCountData> mapTempReadCountData = new HashMap<String, ReadCountData>();
							for(int i = 0; i < arrReadCountData.size(); i++){
								mapTempReadCountData.put(arrReadCountData.get(i).m_strMessageId, arrReadCountData.get(i));
							} 
							
							for(String key : mapTempReadCountData.keySet() ){
								if(!mapBeforeReadCountData.containsKey(key)){
									//기존의 맵에 값이 없다면 넣음
									arrUseReadCountData.add(mapTempReadCountData.get(key));
									if(mapTempReadCountData.get(key).m_nCount == 1){
									}else {
										m_isReadCountChange = true;
									}
								} else {
								if(mapBeforeReadCountData.get(key).m_nCount != mapTempReadCountData.get(key).m_nCount){
									//기존의 리드 카운트에서 변화가 있을 경우 넣음
									m_isReadCountChange = true;
									arrUseReadCountData.add(mapTempReadCountData.get(key));
									}
								}
					        }
							//최종 적으로 사용될 리드 카운트 리스트
							final ArrayList<ReadCountData> arrFinalReadCountData = arrUseReadCountData;
							
							mapBeforeReadCountData.clear();
							mapBeforeReadCountData.putAll(mapTempReadCountData);
							
							
							PriorityAsyncTask<ArrayList<ReadCountData>, Void, ArrayList<ReadCountData>> task2 = new PriorityAsyncTask<ArrayList<ReadCountData>, Void, ArrayList<ReadCountData>>() {

								@Override
								protected ArrayList<ReadCountData> doInBackground(ArrayList<ReadCountData>... params) {

									ChattingDBManager dbMng = new ChattingDBManager(ChatRoomAct.this);
									dbMng.openWritable(m_strRoomId);
									if(arrFinalReadCountData.size() != 0){
										CommonLog.e(getClass().getSimpleName(), "Read count change!!! : " + arrFinalReadCountData.size());
										dbMng.updateNoReadUserCount(arrFinalReadCountData);
									} else {
										m_isReadCountChange = false;
										CommonLog.e(getClass().getSimpleName(), "Read count same!!!");
									}
//									dbMng.updateReadMessage(mapNoReadMessageID);
									dbMng.close();
//									SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
//									int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
//									int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
//									if (nUpdateBadgeCount < 0) {
//										nUpdateBadgeCount = 0;
//									}
//									pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);500
//									IconBadge.updateIconBadge(ChatRoomAct.this);
//									
//									if (!m_arrNoReadMessageID.isEmpty()) {
//										mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//									}
									m_arrNoReadMessageID.clear();
									mapNoReadMessageID.clear();
									
									final ArrayList<ReadCountData> arrFReadCountData = arrFinalReadCountData;
									int nDataSize = arrFReadCountData.size();
									int nMessageDataSize = m_arrChattingMessageData.size();
									for (int j = 0; j < nDataSize; j++) {
										for (int i = nMessageDataSize - 1; i >= 0; i--) {
											if (arrFReadCountData.get(j).m_strMessageId.equals(m_arrChattingMessageData.get(i).m_strMsgId)) {
												m_arrChattingMessageData.get(i).m_nNoReadUserCount = arrFReadCountData.get(j).m_nCount;
												break;
											}
										}
									}
									return arrFReadCountData;
								}

								@Override
								protected void onPostExecute(final ArrayList<ReadCountData> result) {
									closeProgress();
									if (m_isReadCountChange){
										runOnUiThread(new Runnable() {

											@Override
											public void run() {
												// TODO Auto-generated method stub
												if (m_lvChat != null) {
													m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
													m_ChatAdapter.setChangeCountData(result);
													m_ChatAdapter.dataSetChanged();
												}
												m_isGetReadCount = false;
											}
										});
									} else {
										m_isGetReadCount = false;
									}
								}
							};
							task2.execute();
							
						}
						

						@Override
						public void onNetworkError(int a_nErrorCode, String a_strMessage) {
							closeProgress();
							m_isGetReadCount = false;
							// TODO Auto-generated method stub
							// if (a_nErrorCode ==
							// ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
							// {
							// m_Popup = new CommonPopup(ChatRoomAct.this,
							// ChatRoomAct.this,
							// CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							// PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
							// m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title),
							// a_strMessage);
							// m_Popup.setCancelable(false);
							// isCheckShowPopup();
							// } else if (a_nErrorCode ==
							// ApiResult.HTTP_SERVER_CHANGE_DEVICE ||
							// a_nErrorCode ==
							// ApiResult.HTTP_SERVER_UNAUTHORIZED) {
							// m_Popup = new CommonPopup(ChatRoomAct.this,
							// ChatRoomAct.this,
							// CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							// PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
							// m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(),
							// a_strMessage);
							// m_Popup.setCancelable(false);
							// isCheckShowPopup();
							// } else if (a_nErrorCode ==
							// ApiResult.HTTP_ERR_DISCONNECTED) {
							// m_nPopupType =
							// CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE;
							// m_Popup = new CommonPopup(ChatRoomAct.this,
							// ChatRoomAct.this,
							// CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							// m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(),
							// getString(R.string.network_bad).toString());
							// m_Popup.setCancelable(false);
							// isCheckShowPopup();
							// } else {
							// m_nPopupType =
							// CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE;
							// m_Popup = new CommonPopup(ChatRoomAct.this,
							// ChatRoomAct.this,
							// CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							// m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(),
							// a_strMessage);
							// m_Popup.setCancelable(false);
							// isCheckShowPopup();
							// }
						}
					});
				} else {
					CommonLog.e(getClass().getSimpleName(), "All messages 0");
					m_isReadCountChange = false;
					closeProgress();
					AsyncTask<Void, Void, Void> task3 = new AsyncTask<Void, Void, Void>() {
						@Override
						protected Void doInBackground(Void... params) {
//							ChattingDBManager dbMng = new ChattingDBManager(ChatRoomAct.this);
//							dbMng.openWritable(m_strRoomId);
//							dbMng.updateReadMessage(mapNoReadMessageID);
//							SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
//							int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
//							int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
//							if (nUpdateBadgeCount < 0) {
//								nUpdateBadgeCount = 0;
//							}
//			  				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
//							IconBadge.updateIconBadge(ChatRoomAct.this);
//							
//							if (!m_arrNoReadMessageID.isEmpty()) {
//								mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//							}
//							m_arrNoReadMessageID.clear();
//							mapNoReadMessageID.clear();
//							dbMng.close();
							return null;
						}

						@Override
						protected void onPostExecute(Void result) {
							if(m_isReadCountChange) {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									// TODO Auto-generated method stub
										if (m_lvChat != null) {
											m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
											m_ChatAdapter.dataSetChanged();
										}
										m_isGetReadCount = false;
									}
								});
							} else {
								m_isGetReadCount = false;
							}
						}
					};
					task3.execute();
				}
			}
		};
		task.execute();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

			m_hReadCount.removeMessages(0);
			m_hReadCount.sendEmptyMessageDelayed(0, 100);

	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isOnStop = true;
		// if(m_ReadRunnable != null){
		// CommonLog.e(getClass().getSimpleName(), "Stop get read hanler!!!");
		// m_ReadHandler.removeCallbacks(m_ReadRunnable);
		// }
		// m_arrNoReadOhterMessageID.clear();
		CommonLog.e(getClass().getSimpleName(), "Stop get read hanler!!!");

		m_hReadCount.removeMessages(0);

		if (mService != null)
			mService.removePacketListener();
		else
			CommonLog.e(ChatRoomAct.class.getSimpleName(), "onStop mService is null");

		if (m_lvChat != null)
			m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);
	}

	private XMPPConnectionComplete m_XMPPConnectionComplete = new XMPPConnectionComplete() {

		@Override
		public void onConnectionComplete() {
			// TODO Auto-generated method stub

			if (m_isFirstRead)
				printMessage(PRINT_MESSAGE_SCROLL);
			else
				printMessage(PRINT_MESSAGE_NOT_SCROLL);
		}
	};
	public interface TiniItemSelectListener{
		public void setSelectTiniItem(String selectItem);
		public String getSelectTiniItem();
	}
	private  TiniItemSelectListener mTiniSelectListener = new TiniItemSelectListener(){
		@Override
		public String getSelectTiniItem() {
			return null;
		}

		@Override
		public void setSelectTiniItem(String selectItem) {
			sendMessage(selectItem,false);
		}
	};
	private PacketListener mPacketListener = new PacketListener() {

		@Override
		public void onPrintMessage(String strText, int nFriendNumber) {
			// TODO Auto-generated method stub
			if (m_nFriendUserNumber == nFriendNumber) {
				// runOnUiThread(new Runnable() {
				// @Override
				// public void run() {

				printMessage(PRINT_MESSAGE_SCROLL);
				// }
				// });
			}

		}

		@Override
		public void onPrintImage(final Packet message, int nFriendNumber) {
			// TODO Auto-generated method stub
			if (m_nFriendUserNumber == nFriendNumber) {
				// runOnUiThread(new Runnable() {
				// @Override
				// public void run() {
				// CommonLog.e(ChatRoomAct.this, "onPrintImage : Success");
				// DelayInformation delay = (DelayInformation)
				// message.getExtension("x", "jabber:x:delay");
				// changeDay(delay.getStamp().getTime());
				// ArrayList<Integer> arrMyId = new
				// ArrayList<Integer>();
				//
				// FileEx fileEx = (FileEx)
				// message.getExtension(FileEx.NAMESPACE);
				//
				// arrMyId.add(App.m_MyUserInfo.m_nUserNo);
				// // 처음 글을 올리는 순간은 무조건 나만 본것
				//
				// UserListData data =
				// ContactsDBManager.getContacts(ChatRoomAct.this,
				// Integer.parseInt(message.getFrom().split("@")[0]));
				// if
				// (message.getFrom().split("@")[0].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo)))
				// {
				// setMyImage(StaticString.CHAT_ROOM_MY_IMAGE,
				// StaticString.CHAT_SEND_STATUS_SUCCESS, m_strRoomId,
				// 0, fileEx.getUrl(),
				// Integer.parseInt(fileEx.getWidth()),
				// Integer.parseInt(fileEx.getHeight()),
				// fileEx.getThumb(), delay.getStamp().getTime(),
				// arrMyId, m_arrThisRoomUser, message.getPacketID());
				// } else {
				// setOtherImage(StaticString.CHAT_ROOM_OTHER_IMAGE,
				// StaticString.CHAT_SEND_STATUS_SUCCESS, m_strRoomId,
				// 0, m_strFriendUserName, fileEx.getUrl(),
				// Integer.parseInt(fileEx.getWidth()),
				// Integer.parseInt(fileEx.getHeight()),
				// fileEx.getThumb(), delay.getStamp().getTime(),
				// arrMyId, m_arrThisRoomUser,
				// message.getPacketID(), data.);
				// }
				// m_ChatAdapter.notifyDataSetChanged();
				printMessage(PRINT_MESSAGE_SCROLL);
				// }
				// });
			}

		}

		@Override
		public void onPrintFile(final Packet message, int nFriendNumber) {
			// TODO Auto-generated method stub
			if (m_nFriendUserNumber == nFriendNumber) {
				// runOnUiThread(new Runnable() {
				// @Override
				// public void run() {
				// DelayInformation delay = (DelayInformation)
				// message.getExtension("x", "jabber:x:delay");
				// changeDay(delay.getStamp().getTime());
				// ArrayList<Integer> arrMyId = new
				// ArrayList<Integer>();
				//
				// // 파일의 이름을 구하기 위해
				// FileEx fileEx = (FileEx)
				// message.getExtension(FileEx.NAMESPACE);
				// String fileName = fileEx.getFileName();
				// // 임시
				// arrMyId.add(App.m_MyUserInfo.m_nUserNo);
				// // 처음 글을 올리는 순간은 무조건 나만 본것
				//
				// if
				// (message.getFrom().split("@")[0].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo)))
				// {
				// setMyFile(StaticString.CHAT_ROOM_MY_FILE,
				// StaticString.CHAT_SEND_STATUS_SUCCESS, m_strRoomId,
				// 0, fileName, fileEx.getUrl(),
				// delay.getStamp().getTime(), arrMyId,
				// m_arrThisRoomUser, message.getPacketID());
				// } else {
				// setOtherFile(StaticString.CHAT_ROOM_OTHER_FILE,
				// m_strRoomId, 0, m_strFriendUserName, fileName,
				// fileEx.getUrl(), delay.getStamp().getTime(), arrMyId,
				// m_arrThisRoomUser, message.getPacketID());
				// }
				// m_ChatAdapter.notifyDataSetChanged();
				printMessage(PRINT_MESSAGE_SCROLL);
				// }
				// });
			}

		}

		@Override
		public void onReadCheck(int nFriendNumber, final Packet message) {
			// TODO Auto-generated method stub
			if (m_nFriendUserNumber == nFriendNumber) {
				// runOnUiThread(new Runnable() {
				// @Override
				// public void run() {
				// mService.sendReadMessage(message);
				// }
				// });
			}
		}

		@Override
		public void viewErrorMessage(final String strErrorMessage) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					closeProgress();
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_title), strErrorMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			});
		}

		@Override
		public void setReadMessage(final ArrayList<String> arrIDs, final int nFriendNumber) {
			// TODO Auto-generated method stub
			if (m_nFriendUserNumber == nFriendNumber) {

				ArrayList<ReadCountData> arrReadCountData = new ArrayList<ReadCountData>();
				ChattingDBManager chattingDBMngd = new ChattingDBManager(ChatRoomAct.this);
				chattingDBMngd.openWritable(Integer.toString(m_nFriendUserNumber));

				for (String readId : arrIDs) {
					ReadCountData readCountData = new ReadCountData();

					ChattingMessageData chattingMsg = chattingDBMngd.getChattingMessage(readId);
					readCountData.m_strMessageId = readId;
					readCountData.m_nCount = chattingMsg.m_nNoReadUserCount - 1;
					arrReadCountData.add(readCountData);
				}
				chattingDBMngd.updateNoReadUserCount(arrReadCountData);
				chattingDBMngd.close();
				final ArrayList<ReadCountData> arrFReadCountData = arrReadCountData;
				int nDataSize = arrFReadCountData.size();
				int nMessageDataSize = m_arrChattingMessageData.size();
				for (int j = 0; j < nDataSize; j++) {
					for (int i = nMessageDataSize - 1; i >= 0; i--) {
						if (arrFReadCountData.get(j).m_strMessageId.equals(m_arrChattingMessageData.get(i).m_strMsgId)) {
							m_arrChattingMessageData.get(i).m_nNoReadUserCount = arrFReadCountData.get(j).m_nCount;
							break;
						}
					}
				}
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (m_nFriendUserNumber == nFriendNumber) {
							m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
							m_ChatAdapter.setChangeData(arrFReadCountData);
							m_ChatAdapter.notifyDataSetChanged();
						}
					}
				});
			}
		}

		@Override
		public String getRoomID() {
			// TODO Auto-generated method stub
			return m_strRoomId;
		}

		@Override
		public void onClearRoom(String strText, int nFriendNumber) {
			// TODO Auto-generated method stub
			if (m_nFriendUserNumber == nFriendNumber) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						closeProgress();
						m_UrgentMessageClose.setVisibility(View.GONE);
						m_UrgentMessage.setVisibility(View.GONE);
						// ChattingDBManager chattingDBMngFindUrgent = new
						// ChattingDBManager(ChatRoomAct.this);
						// chattingDBMngFindUrgent.openWritable(m_strRoomId);
						// ArrayList<ChattingMessageData> findUrgentData =
						// chattingDBMngFindUrgent.getChattingMessage();
						//
						// for (ChattingMessageData data : findUrgentData) {
						// if (data.m_nMsgType ==
						// StaticString.CHAT_ROOM_URGENT_MESSAGE) {
						// chattingDBMngFindUrgent.deleteChattingMessage(data.m_strMsgId);
						// data.m_nMsgType = 0;
						// chattingDBMngFindUrgent.insertMessage(data);
						// break;
						// }
						// }
						// chattingDBMngFindUrgent.close();

						printMessage(PRINT_MESSAGE_SCROLL);
					}
				});
			}
		}

		@Override
		public void onResumeScreen() {
			// TODO Auto-generated method stub
			m_isGetReadUserCount = false;
			// m_arrNoReadOhterMessageID.clear();
			m_isFirstRead = true;
			m_isGetOfflineMessage = true;
			printMessage(PRINT_MESSAGE_SCROLL);
		}

		@Override
		public void printAddMessage(final ChattingMessageData a_chattingMsgData, int nFriendNumber) {
			// TODO Auto-generated method stub
			if(nFriendNumber == m_nFriendUserNumber){
				int nUserNo;
				String strUserMessage = null;
				JSONObject jsonUserMessage = null;
				int nNoReadCount;
				long lSendTime;
				int nMessageType = 0;
				int nSendStatus;
				boolean isRead = true;
				String strEmoticonName ="";

				nUserNo = a_chattingMsgData.m_nSendUserId;

				UserListData tData = null;

				if (m_arrContacts == null)
					m_arrContacts = ContactsDBManager.getContactsReturnSparseArray(ChatRoomAct.this);

				if (nMessageType != 1) {
					if (nUserNo == 0) {
						// data =
						// ContactsDBManager.getContacts(ChatRoomGroupAct.this,
						// App.m_MyUserInfo.m_nUserNo);
						tData = m_arrContacts.get(App.m_MyUserInfo.m_nUserNo);
					} else {
						// data =
						// ContactsDBManager.getContacts(ChatRoomGroupAct.this,
						// nUserNo);
						tData = m_arrContacts.get(nUserNo);
					}

				}

				final UserListData data = tData;

				boolean isSmileView = false;

				if(a_chattingMsgData.m_nMsgType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE || a_chattingMsgData.m_nMsgType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){
					strUserMessage = a_chattingMsgData.m_strMsgText;
					strEmoticonName = a_chattingMsgData.m_strEmoticon;
				} else {
					strUserMessage = a_chattingMsgData.m_strMsgText;
					try {
						jsonUserMessage = new JSONObject(strUserMessage);
					} catch (JSONException e){
					}
					strEmoticonName = "";
				}



				lSendTime = a_chattingMsgData.m_lnMsgSendTime;
				final String strMessageID = a_chattingMsgData.m_strMsgId;
				nNoReadCount = a_chattingMsgData.m_nNoReadUserCount;
				isRead = a_chattingMsgData.m_isRead;
				nMessageType = a_chattingMsgData.m_nMsgType;
				nSendStatus = a_chattingMsgData.m_nSendStatus;
				changeDay(lSendTime, true);

				// 긴급 공지는 우선 처리한후, 메세지 부분으로 다시 처리
				if (nMessageType == StaticString.CHAT_ROOM_URGENT_MESSAGE) {
					nMessageType = 0;
					if (!strMessageID.equals(m_strUrgentID) && lSendTime > m_lUrgentTime) {
						setUrgentNotice(a_chattingMsgData);
						m_strUrgentID = strMessageID;
						m_lUrgentTime = lSendTime;
					}
				}

				if (nMessageType == StaticString.CHAT_ROOM_SYSTEM_MSG) {

					setSystemMsgAdd(StaticString.CHAT_ROOM_SYSTEM_MSG, strUserMessage);
				} else if (nMessageType == StaticString.CHAT_ROOM_MY_FILE) {
					setMyFileAdd(StaticString.CHAT_ROOM_MY_FILE, nSendStatus, m_strRoomId, 0, lSendTime, nNoReadCount, strMessageID, jsonUserMessage);
				} else if(nMessageType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){
					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
							m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
							mapNoReadMessageID.put(strMessageID, true);
					}

					setOtherEmoticonMsgAdd(StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE, nSendStatus, m_strRoomId, m_nFriendUserNumber, m_strFriendUserName,m_strFriendUserType,
							strEmoticonName,strUserMessage ,lSendTime, nNoReadCount, strMessageID, m_UserData != null && m_UserData.m_isImageAvailable, isSmileView);

				} else if (nMessageType == StaticString.CHAT_ROOM_OTHER_FILE) {

					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
						m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
						mapNoReadMessageID.put(strMessageID, true);
					}
					setOtherFileAdd(StaticString.CHAT_ROOM_OTHER_FILE, m_strRoomId, m_nFriendUserNumber, m_strFriendUserName,m_strFriendUserType, lSendTime, nNoReadCount, strMessageID,
							m_UserData != null && m_UserData.m_isImageAvailable, isSmileView, jsonUserMessage);

				} else if (nMessageType == StaticString.CHAT_ROOM_MY_IMAGE) {
					if ((nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) || nSendStatus == StaticString.CHAT_SEND_STATUS_FAIL) {
						// 보내는 중이거나 실패 했을때

						setMyImageAdd(StaticString.CHAT_ROOM_MY_IMAGE, nSendStatus, m_strRoomId, 0, lSendTime,
								nNoReadCount, strMessageID, jsonUserMessage);
					} else {

						setMyImageAdd(StaticString.CHAT_ROOM_MY_IMAGE, nSendStatus, m_strRoomId, 0, lSendTime, nNoReadCount, strMessageID, jsonUserMessage);
					}
				} else if(nMessageType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE){
				/*	if(!m_strCurrentSelectApngEmoticonUrl.equals("") && m_nCurrentSelectPngEmoticonId == 0) {
						a_chattingMsgData.m_strEmoticon = m_strCurrentSelectApngEmoticonUrl;
					} else if(m_strCurrentSelectApngEmoticonUrl.equals("") && m_nCurrentSelectPngEmoticonId != 0) {
						a_chattingMsgData.m_strEmoticon = String.valueOf(m_nCurrentSelectPngEmoticonId);
					}*/
					setMyEmoticonMsgAdd(StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE, nSendStatus, Integer.toString(m_nFriendUserNumber), 0, strUserMessage, nNoReadCount,
							lSendTime, strMessageID,strEmoticonName);

				} else if (nMessageType == StaticString.CHAT_ROOM_OTHER_IMAGE) {

					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
						m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
						mapNoReadMessageID.put(strMessageID, true);
					}

					setOtherImageAdd(StaticString.CHAT_ROOM_OTHER_IMAGE, nSendStatus, m_strRoomId, m_nFriendUserNumber, m_strFriendUserName,m_strFriendUserType,
							lSendTime, nNoReadCount, strMessageID, m_UserData != null && m_UserData.m_isImageAvailable, isSmileView, jsonUserMessage);
				}
				// 아래는 모두 메세지, 타입은 0이다
				else if (nUserNo == 0 && nMessageType == 0) {
					// if (!isRead && nSendStatus ==
					// StaticString.CHAT_SEND_STATUS_SUCCESS) {
					// // chattingDBMng.updateReadMessage(strMessageID, true);
					// m_arrNoReadMessageID.add(strMessageID);
					// mapNoReadMessageID.put(strMessageID, true);
					// }

					setMyMsgAdd(StaticString.CHAT_ROOM_MY_MESSAGE, nSendStatus, Integer.toString(m_nFriendUserNumber), 0, strUserMessage, nNoReadCount,
							lSendTime, strMessageID);

				} else {

					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
						m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
						mapNoReadMessageID.put(strMessageID, true);
					}
					setOtherMsgAdd(StaticString.CHAT_ROOM_OTHER_MESSAGE, m_nFriendUserNumber, m_strRoomId, m_strFriendUserName,m_strFriendUserType,strUserMessage, nNoReadCount,
							lSendTime, strMessageID, m_UserData != null && m_UserData.m_isImageAvailable, isSmileView,strEmoticonName);
				}
				runOnUiThread(new Runnable() {
					public void run() {
						m_ChatAdapter.notifyDataSetChanged();
					}
				});

				if (nMessageType != StaticString.CHAT_ROOM_SYSTEM_MSG
						&& a_chattingMsgData.m_strMsgId.split("_")[1].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))) {
					m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				} else if (m_lvChat.getLastVisiblePosition() == m_lvChat.getCount() - 2) {
					m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
					// m_lvChat.setSelection(m_lvChat.getCount() + 5);
				} else {
					if (!isRead) {
						// 스크롤 올렸을때 다른 사람의 메시지가 올 경우
						m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);

						final String strUserName = data.m_PersonalData.mapPersonalData.get(PersonalData.NAME);

						final int nFinalMessageType = nMessageType;
						final String strFinalUserMessage = strUserMessage;

						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								m_NewMessage.setVisibility(View.VISIBLE);
								// TODO Auto-generated method stub
								if (nFinalMessageType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
									m_tvNewMessage.setText(R.string.chatroom_file_img);
								} else if (nFinalMessageType == StaticString.CHAT_ROOM_OTHER_FILE) {
									try {
										JSONObject jsonUserMessage = new JSONObject(strFinalUserMessage);
										if (jsonUserMessage.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
											m_tvNewMessage.setText(R.string.chatroom_file_movie);
										} else {
											m_tvNewMessage.setText(jsonUserMessage.getString(StaticString.XMPP_TEXT_FILENAME));
										}
									} catch (JSONException e) {
										e.printStackTrace();
									}
								} else if(nFinalMessageType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){
									EmoticonUtils utils = new EmoticonUtils();
									m_tvNewMessage.setText(getString(R.string.emoticon)+utils.parsingEmoticonText(ChatRoomAct.this, strFinalUserMessage, (int) m_tvNewMessage.getTextSize()));
								} else {
									EmoticonUtils utils = new EmoticonUtils();
									m_tvNewMessage
											.setText(utils.parsingEmoticonText(ChatRoomAct.this, strFinalUserMessage, (int) m_tvNewMessage.getTextSize()));
								}
								m_tvNewMessageInfo.setText(strUserName);
								if (data != null && data.m_isImageAvailable) {
									App.imageloader.cancelDownload(m_ivNewMessageImage);
									App.imageloader.getProfileImage(m_ivNewMessageImage, App.getImageDownLoaderUrl(data.m_nUserNo, true), R.drawable.profile_pic_default, false);

								} else {
									App.imageloader.cancelDownload(m_ivNewMessageImage);
									m_ivNewMessageImage.setImageResource(R.drawable.profile_pic_default);
								}

								m_ivNewMessageNotFellowImage.setVisibility(View.GONE);
							}
						});

					}
				}
				ChattingMessageData refreshData = a_chattingMsgData;
				refreshData.m_isRead = true;
				// for문을 돌리는 이유는 혹시나 마지막 메시지가 아님을 대비하기 위한것, 보통 맨 마지막 메시지 이므로
				// for문을 도는 일은 거의 없다.
				for (int x = m_arrChattingMessageData.size() - 1; x >= 0; x--) {
					if (m_arrChattingMessageData.get(x).m_strMsgId.equals(a_chattingMsgData.m_strMsgId)) {
						m_arrChattingMessageData.remove(x);
						break;
					}
				}
				m_arrChattingMessageData.add(refreshData);

				ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
				chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
				chattingDBMng.updateReadMessage(mapNoReadMessageID);
				chattingDBMng.close();
				SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
				int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
				int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
				if (nUpdateBadgeCount < 0) {
					nUpdateBadgeCount = 0;
				}
				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
				IconBadge.updateIconBadge(ChatRoomAct.this);
				
				if (!m_arrNoReadMessageID.isEmpty()) {
					mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
				}
				m_arrNoReadMessageID.clear();
				mapNoReadMessageID.clear();
			}
		}

		@Override
		public void onOtherLogin() {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			});
		}

		@Override
		public void onBindService() {
			doBindXmppSerivce();
		}

	};

	public interface PacketListener {
		public void onPrintMessage(String strText, int nFriendNumber);

		public void onPrintImage(Packet message, int nFriendNumber);

		public void onPrintFile(Packet message, int nFriendNumber);

		// 메세지를 받을때 그 액티비티에 들어가 있는지
		public void onReadCheck(int nFriendNumber, Packet message);

		public void viewErrorMessage(String strErrorMessage);

		public void setReadMessage(ArrayList<String> arrIDs, int nFriendNumber);

		public String getRoomID();

		public void onClearRoom(String strText, int nFriendNumber);

		public void onResumeScreen();

		public void printAddMessage(ChattingMessageData a_chattingMsgData, int nFriendNumber);

		public void onOtherLogin();

		public void onBindService();

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == RESULT_OK) {

			if (requestCode == REQUEST_CODE_INVITE) {
				inviteOther(data);
			} else if(requestCode == REQUEST_CODE_ALARM) {
				ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(this, m_strRoomId);
				if (roomData != null)
					m_isAlarm = roomData.m_isAlarmOn;
			}
			else if (requestCode == REQUEST_CODE_SENDMESSAGE) {
				finish();
			} else if (requestCode == REQUEST_CODE_SEND_FILE) {
				if (data != null && data.getData() != null) {
					Uri uri = data.getData();
					CommonLog.e(this, "uri getPath : " + uri.getPath());
					CommonLog.e(this, "uri getScheme : " + uri.getScheme());
					if (uri.getScheme().equals("file")) {
						File f = new File(new String(uri.getPath()));
						CommonLog.e(this, "File Size : " + f.length());
						if (f.length() > 104857600) {
							m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_text));
							m_Popup.setCancelable(false);
							// isCheckShowPopup();
							m_Popup.show();

						} else if(f.length() == 0){
							m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_zero));
							m_Popup.setCancelable(false);
							// isCheckShowPopup();
							m_Popup.show();
						}
						else {
							sendFile(uri.getLastPathSegment(), uri, null);
						}
					} else {
						Cursor cursor = getContentResolver().query(uri, null, null, null, null);
						if (cursor != null && cursor.moveToFirst()) {
							String strDisplayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
							String strSize = cursor.getString(cursor.getColumnIndex(OpenableColumns.SIZE));
							CommonLog.e(this, "displayName : " + strDisplayName);
							CommonLog.e(this, "Size : " + strSize);
							if (Integer.parseInt(strSize) > 104857600) {
								m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
								m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_text));
								m_Popup.setCancelable(false);
								// isCheckShowPopup();
								m_Popup.show();

							} else if(Integer.parseInt(strSize) == 0){
								m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
								m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_zero));
								m_Popup.setCancelable(false);
								// isCheckShowPopup();
								m_Popup.show();
							}
							else {
								sendFile(strDisplayName, uri, null);
							}
						}

						if (cursor != null)
							cursor.close();
					}
				}
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_FILE){
				if(data.hasExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST))
				{
					ArrayList<Parcelable> parcelList = data.getParcelableArrayListExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST);
					if(parcelList != null)
					{
						ArrayList<FileInfo> arrAttachFile = (ArrayList<FileInfo>)parcelList.clone();
						long lnFileSize = 0;
						for(FileInfo fileData : arrAttachFile){
							lnFileSize += fileData.m_lnSize;
						}
						if(lnFileSize > 104857600){
							m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_text));
							m_Popup.setCancelable(false);
							// isCheckShowPopup();
							m_Popup.show();
						} else if(lnFileSize == 0){
							m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_zero));
							m_Popup.setCancelable(false);
							// isCheckShowPopup();
							m_Popup.show();
						}
						else {
							for(FileInfo fileData : arrAttachFile)
							{

							
								Uri uri = Uri.fromFile(new File(fileData.m_strPath));
								sendFile(fileData.m_strName, uri, null);
//							SNSBoardFileData snsFileData = new SNSBoardFileData();
//							snsFileData.m_strFileName = fileData.m_strName;
//							snsFileData.m_strFileURL = fileData.m_strPath;
//							snsFileData.m_lnFileSize = fileData.m_lnSize;
//							snsFileData.m_strFileType = SNSBoardFileData.FILETYPE_ETC;
							
							//m_arrAttachFile.add(snsFileData);
							}
						}
						//setAttachFileUI();
					}
				}
			}
			else if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM) {
				// Album에서 Image 선택후 Crop 실행
				// m_TakeMedia.scaleAlbumImage(data.getData());
				//m_TakeMedia.doCropImageFromAlbumWithoutAspect(data.getData());
				// processSendImage();
				
				SelectImageProcessTask task = new SelectImageProcessTask();
				task.execute(data);
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CAMERA) {
				// 카메라 촬영후 Crop 실행
				//m_TakeMedia.doCropImageFromCameraWithoutAspect();
				m_TakeMedia.scaleCameraImage();
				//UKey 사용자의 경우에만 XMPP로그인 전에 사진을 보내어 정상 처리가 되지 않음
				//이유는 모르겠으나... 일단 약간의 딜레이를 줌으로써 해결
				final ProgressDlg progress = new ProgressDlg(ChatRoomAct.this, getString(R.string.progress_scaleimage));
				progress.show();
				Handler mHandler = new Handler();
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						processSendCameraImage();
						progress.cancel();
					}
				}, 500);


				// processSendImage();
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				// Crop이 완료된 이미지를 가져옴
				m_TakeMedia.scaleCropImage();
				//processSendImage();
				processSendCameraImage();
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_VIDEO) {
				// Album에서 Video 선택
				Uri uriVideo = data.getData();
				CommonLog.e(getClass(), "uriVideo : " + uriVideo);
				String strPath = Utils.getPathFromUri(this, uriVideo);

				File f = new File(new String(strPath));
				CommonLog.e(this, "File Size : " + f.length());
				if (f.length() > 104857600) {
					m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_video_text));
					m_Popup.setCancelable(false);
					// isCheckShowPopup();
					m_Popup.show();

				} else if(f.length() == 0){
					m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_zero));
					m_Popup.setCancelable(false);
					// isCheckShowPopup();
					m_Popup.show();
				}
				else {
					if (!TextUtils.isEmpty(strPath))
						sendFile("", uriVideo, null);
					else {

					}
				}
			}

			else if (requestCode == REQUEST_CODE_PICK_CONTACTS) {
				// 주소록 선택 
				Uri uri = data.getData();
				
				Cursor cursor = getContentResolver().query(uri, null, null, null, null);
				cursor.moveToFirst();
				String strName = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
				String strLookupKey = cursor.getString(cursor.getColumnIndex(Contacts.LOOKUP_KEY));
				cursor.close();
				startPreviewContact(strName, strLookupKey);
			} else if (requestCode == REQUEST_CODE_PREVIEW_CONTACT) {
				// 주소록 전송
				String strName = data.getStringExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_NAME);
				String strLookupKey = data.getStringExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_LOOKUPKEY);
				sendContacts(strName, strLookupKey);
			}
		} else {
			CommonLog.e(this, "Result not OK : " + resultCode);
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM || requestCode == TakeMediaIntent.REQUESTCODE_CAMERA
					|| requestCode == TakeMediaIntent.REQUESTCODE_CROP || requestCode == TakeMediaIntent.REQUESTCODE_VIDEO) {
				// 취소등에 의한 후처리 필요
				m_TakeMedia.deleteDirectory();
				m_TakeMedia = null;
			} else if(requestCode == REQUEST_CODE_PREVIEW_CONTACT) {
				startPickContacts();
			}
		}

	}

	private class SelectImageProcessTask extends AsyncTask<Intent, Void, Boolean>
	{
		ProgressDlg progress = new ProgressDlg(ChatRoomAct.this, getString(R.string.progress_scaleimage));
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			m_RoomImageData = new ArrayList<ChattingRoomImageData>();
			progress.show();
			super.onPreExecute();
			
			
		}
		
		@Override
		protected Boolean doInBackground(Intent... params) {
			// TODO Auto-generated method stub
			Intent data = params[0];
			Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
			ArrayList<GalleryListData> arrAttachImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);
			
			if(arrAttachImage != null && arrAttachImage.size() > 0)
			{
				String strScaleSaveDirectory = getFilesDir().getAbsolutePath();
				for(GalleryListData galleryListData : arrAttachImage)
				{
					
					ChattingRoomImageData imageData = new ChattingRoomImageData();
					
					String strImagePath = galleryListData.getSdcardPath();
					
					ScaleImage scaleImage = new ScaleImage();
					scaleImage.scaleImage(strImagePath, strScaleSaveDirectory);
					
					imageData.byteBmp = scaleImage.getCropImageByte();
					imageData.strPath = scaleImage.getSavedScaleImagePath();
					imageData.bitmap = scaleImage.getBitmap();
					m_RoomImageData.add(imageData);
					
				}
				
				return true;
			}
			else
				return false;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub	
			progress.cancel();
			processSendImage();	
			super.onPostExecute(result);
		}
	}

	private void processSendImage() {
		for(int i = 0; i < m_RoomImageData.size(); i++){
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		//Bitmap bmp;
		//byte[] byteBmp = m_TakeMedia.getCropImageByte();
		//String strPath = m_TakeMedia.getCropImageFilePath();
		//bmp = m_TakeMedia.getCropImageBitmap();
		File f = new File(new String(m_RoomImageData.get(i).strPath));
		CommonLog.e(this, "File Size : " + f.length());
		CommonLog.e(this, "File Path : " + m_RoomImageData.get(i).strPath);
		CommonLog.e(this, "Bitmap Width : " + m_RoomImageData.get(i).bitmap.getWidth());
		CommonLog.e(this, "Bitmap Height : " + m_RoomImageData.get(i).bitmap.getHeight());

		if (f.length() > 10485760) {
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_image_text));
			m_Popup.setCancelable(false);
			// isCheckShowPopup();
			m_Popup.show();

		} else if(f.length() == 0){
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_zero));
			m_Popup.setCancelable(false);
			// isCheckShowPopup();
			m_Popup.show();
		}
		else {
			final long lTime = System.currentTimeMillis() + i;
			sendImage(lTime, m_RoomImageData.get(i).bitmap, m_RoomImageData.get(i).byteBmp, m_RoomImageData.get(i).strPath);
		}
		}
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				m_ChatAdapter.notifyDataSetChanged();
			}
		});
	}
	
	private void processSendCameraImage() {

		Bitmap bmp;
		byte[] byteBmp = m_TakeMedia.getCropImageByte();
		String strPath = m_TakeMedia.getCropImageFilePath();
		bmp = m_TakeMedia.getCropImageBitmap();
		File f = new File(new String(strPath));
		CommonLog.e(this, "File Size : " + f.length());
		CommonLog.e(this, "File Path : " + strPath);
		CommonLog.e(this, "Bitmap Width : " + bmp.getWidth());
		CommonLog.e(this, "Bitmap Height : " + bmp.getHeight());

		if (f.length() > 10485760) {
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_image_text));
			m_Popup.setCancelable(false);
			// isCheckShowPopup();
			m_Popup.show();

		} else if(f.length() == 0){
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_memory_title), getString(R.string.popup_fail_memory_zero));
			m_Popup.setCancelable(false);
			// isCheckShowPopup();
			m_Popup.show();
		}
		else {
			final long lTime = System.currentTimeMillis();
			sendImage(lTime, bmp, byteBmp, strPath);
		}
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		// Menu가 표시되었을때는 Menu를 닫고
		// Menu가 표시 안되어있을때는 Activity를 닫자

		if(m_BottomSearch != null && m_BottomSearch.getVisibility() == View.VISIBLE){
			m_ChatSearch.setVisibility(View.GONE);
			m_ChatTitle.setVisibility(View.VISIBLE);
			m_BottomTotal.setVisibility(View.VISIBLE);
			m_BottomSearch.setVisibility(View.GONE);
			m_strBounceID = "";
			m_nNowSearchingIndex = -1;
			m_strSearchWord = "";
			printMessage(PRINT_MESSAGE_NOT_SCROLL);
			m_ivSearchUP.setImageResource(R.drawable.btn_search_up_off);
			m_ivSearchDown.setImageResource(R.drawable.btn_search_down_off);
		} else if (m_layoutDrawerLayout == null || m_EmoticonMenu == null || m_BottomPager == null || m_EmoticonSelelctLayout == null || (!m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT) && m_EmoticonMenu.getVisibility() == View.GONE && m_BottomPager.getVisibility() == View.GONE && m_EmoticonSelelctLayout.getVisibility() == View.GONE)) {
			super.onBackPressed();
		} else {
			m_isBeforeOtherBoard = true;
			m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
			m_EmoticonMenu.setVisibility(View.GONE);
			m_BottomPager.setVisibility(View.GONE);
			m_ChatMenuIconLayout.setVisibility(View.GONE);
			m_btnAttach.setImageResource(R.drawable.btn_file_add);
			m_EmoticonSelelctLayout.setVisibility(View.GONE);
			m_btnEmoticonAdd.setImageResource(R.drawable.btn_emoticon_2);
		}

	}

	private void init() {

		LinearLayout layoutChatRoomAlarm = (LinearLayout)findViewById(R.id.layout_draw_chat_room_alarm);
		layoutChatRoomAlarm.setOnClickListener(this);
		layoutChatRoomAlarm.setVisibility(View.GONE);
		LinearLayout layoutChatRoomMember = (LinearLayout)findViewById(R.id.layout_draw_chat_room_member);
		layoutChatRoomMember.setOnClickListener(this);
		LinearLayout layoutChatRoomInvite = (LinearLayout)findViewById(R.id.layout_draw_chat_room_invite);
		layoutChatRoomInvite.setOnClickListener(this);
		LinearLayout layoutChatRoomFileBox = (LinearLayout)findViewById(R.id.layout_draw_chat_room_filebox);
		layoutChatRoomFileBox.setOnClickListener(this);
		LinearLayout layoutChatRoomOut = (LinearLayout)findViewById(R.id.layout_draw_chat_room_out);
		layoutChatRoomOut.setVisibility(View.GONE);
		LinearLayout layoutChatRoomDelete = (LinearLayout)findViewById(R.id.layout_draw_chat_room_delete);
		layoutChatRoomDelete.setOnClickListener(this);
		LinearLayout layoutChatRoomMandate = (LinearLayout)findViewById(R.id.layout_draw_chat_room_mandate);
		layoutChatRoomMandate.setVisibility(View.GONE);
		TextView tvChatRoomExit = (TextView)findViewById(R.id.tv_draw_chat_room_exit);
		tvChatRoomExit.setOnClickListener(this);

		ImageView btnMenu = (ImageView) findViewById(R.id.btn_chat_menu);
		m_btnAttach = (ImageButton) findViewById(R.id.btn_chat_attach);
		m_layoutDrawerLayout = (DrawerLayout) findViewById(R.id.layout_chat_room_drawer);
		//m_BottomMenu = (LinearLayout) findViewById(R.id.layout_chat_input_menu);

		m_btnEmoticonAdd = (ImageButton) findViewById(R.id.btn_emoticon_add);

		m_BottomPager = (ViewPager) findViewById(R.id.vp_chat_input_menu);
		m_UrgentMessage = (LinearLayout) findViewById(R.id.layout_chat_room_urgent);
		m_NewMessage = (LinearLayout) findViewById(R.id.layout_chat_room_new_message_bottom);
		m_EmoticonMenu = (LinearLayout) findViewById(R.id.layout_chat_input_emoticon);
		m_UrgentMessageClose = (RelativeLayout) findViewById(R.id.layout_chat_room_urgent_close);
		m_btnSend = (ImageButton) findViewById(R.id.btn_chat_send);
		SharedPref pref = SharedPref.getInstance(this);
		int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
		m_etMessage = (EditText) findViewById(R.id.et_chat_text);

		m_Edittext_paddingTop = m_etMessage.getPaddingTop();

		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			m_etMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			m_etMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20.8f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			m_etMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25.6f);
		}
		m_tvTitle = (TextView) findViewById(R.id.tv_chat_title);
		m_tvChatMenuTitle = (TextView) findViewById(R.id.tv_draw_chat_room_name);
		m_ivChatMenuFavorite = (ImageView) findViewById(R.id.iv_chatroom_favorite);
		m_tvUrgentMessage = (TextView) findViewById(R.id.tv_chat_room_urgent);

		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			m_tvUrgentMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.33f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			m_tvUrgentMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19.92f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			m_tvUrgentMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 24.528f);
		}

		m_layout_indicator = (LinearLayout) findViewById(R.id.layout_indicator);
		m_ivEmoindicator1 = (ImageView) findViewById(R.id.indicator1);
		m_ivEmoindicator2 = (ImageView) findViewById(R.id.indicator2);
		m_ivEmoindicator3 = (ImageView) findViewById(R.id.indicator3);
		m_vpEmoticonPager = (ViewPager) findViewById(R.id.viewpager_emoticon_select);
		m_vpEmoticonPager.setAdapter(adapter);
		m_vpEmoticonPager.setCurrentItem(1,false);

		m_tvUrgentMessageInfo = (TextView) findViewById(R.id.tv_chat_room_urgent_info);
		m_ivUrgentImage = (ImageView) findViewById(R.id.iv_profile_pic);
		m_ivUrgentNotFellowImage = (ImageView) findViewById(R.id.iv_profile_notfellow_pic);
		m_tvNewMessage = (TextView) findViewById(R.id.tv_chat_room_new_message);
		m_tvNewMessageInfo = (TextView) findViewById(R.id.tv_chat_room_new_message_info);
		m_ivNewMessageImage = (ImageView) findViewById(R.id.iv_new_message_profile_pic);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
			m_ivNewMessageImage.setBackground(new ShapeDrawable(new OvalShape()));
		} else {
			m_ivNewMessageImage.setBackgroundDrawable(new ShapeDrawable(new OvalShape()));
		}
		m_ivNewMessageNotFellowImage = (ImageView) findViewById(R.id.iv_new_message_profile_notfellow_pic);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
			m_ivNewMessageNotFellowImage.setBackground(new ShapeDrawable(new OvalShape()));
		} else {
			m_ivNewMessageNotFellowImage.setBackgroundDrawable(new ShapeDrawable(new OvalShape()));
		}
		/*m_btnCloud = (ImageButton) findViewById(R.id.btn_chat_cloud);*/
		m_btnSendPicture = (ImageButton) findViewById(R.id.btn_chat_send_picture);
		m_btnVideo = (ImageButton) findViewById(R.id.btn_chat_send_video);
		m_btnCamera = (ImageButton) findViewById(R.id.btn_chat_send_camera);
		if (AppSetting.FEATURE_VARIANT.equals("R")) {
			/*m_btnEmoticon = (ImageButton) findViewById(R.id.btn_chat_send_emoticon);*/
			m_btnSendContact = (ImageButton) findViewById(R.id.btn_chat_send_contacts);
			m_btnSendFile = (ImageButton) findViewById(R.id.btn_chat_send_file);
			ImageButton btnCall = (ImageButton) findViewById(R.id.btn_chat_call_regular);
			btnCall.setBackgroundResource(R.drawable.chat_bmenu_non);
		} else {
		/*	m_btnEmoticon = (ImageButton) findViewById(R.id.btn_chat_send_emoticon_partner);*/
			m_btnSendContact = (ImageButton) findViewById(R.id.btn_chat_send_contacts_partner);
			ImageButton btnCall = (ImageButton) findViewById(R.id.btn_chat_call_partner);
			btnCall.setBackgroundResource(R.drawable.chat_bmenu_non);
			m_btnSendFile = (ImageButton) findViewById(R.id.btn_chat_send_file_partner);
		}
		m_btnEmo01 = (ImageButton) findViewById(R.id.ib_chat_input_e1_2);
		m_btnEmo02 = (ImageButton) findViewById(R.id.ib_chat_input_e2_2);
		m_btnEmo03 = (ImageButton) findViewById(R.id.ib_chat_input_e3_2);
		m_btnEmo04 = (ImageButton) findViewById(R.id.ib_chat_input_e4_2);
		m_btnEmo05 = (ImageButton) findViewById(R.id.ib_chat_input_e5_2);
		m_btnEmo06 = (ImageButton) findViewById(R.id.ib_chat_input_e6_2);
		m_btnEmo07 = (ImageButton) findViewById(R.id.ib_chat_input_e7_2);
		m_btnEmo08 = (ImageButton) findViewById(R.id.ib_chat_input_e8_2);
		m_btnEmo09 = (ImageButton) findViewById(R.id.ib_chat_input_e9_2);
		m_btnEmo10 = (ImageButton) findViewById(R.id.ib_chat_input_e10_2);
		m_btnEmo11 = (ImageButton) findViewById(R.id.ib_chat_input_e11_2);
		m_btnEmo12 = (ImageButton) findViewById(R.id.ib_chat_input_e12_2);
		m_btnEmo13 = (ImageButton) findViewById(R.id.ib_chat_input_e13_2);
		m_btnEmo14 = (ImageButton) findViewById(R.id.ib_chat_input_e14_2);
		m_btnEmo15 = (ImageButton) findViewById(R.id.ib_chat_input_e15_2);
		m_btnEmo16 = (ImageButton) findViewById(R.id.ib_chat_input_e16_2);
		m_btnEmo17 = (ImageButton) findViewById(R.id.ib_chat_input_e17_2);
		m_btnEmoDel = (ImageButton) findViewById(R.id.ib_chat_input_e_delete_2);
		m_MenuRegular = (RelativeLayout) findViewById(R.id.layout_chat_menu_regular);
		m_MenuPartner = (RelativeLayout) findViewById(R.id.layout_chat_menu_partner);
		m_MenuRegular2 = (LinearLayout) findViewById(R.id.layout_chat_menu_regular2);
		m_MenuPartner2 = (LinearLayout) findViewById(R.id.layout_chat_menu_partner2);
		m_ChatMenuIconLayout = (LinearLayout) findViewById(R.id.layout_pager_icon);
		m_ivChatMenuIcon1 = (ImageView) findViewById(R.id.iv_chat_menu_pager_one);
		m_ivChatMenuIcon2 = (ImageView) findViewById(R.id.iv_chat_menu_pager_two);
		m_ChatBottom = (LinearLayout) findViewById(R.id.layout_chat_bottom);
		m_SystemRoomLayout = (LinearLayout) findViewById(R.id.layout_system_room);

		//이모티콘 이미지 버튼 클릭 시 나오는 창
		m_EmoticonSelelctLayout = (LinearLayout)findViewById(R.id.layout_emoticon_select);
		m_EmoticonContainer = (LinearLayout)findViewById(R.id.layout_chat_room_emoticon_display);
		m_ivEmoticonDisplay = (ImageView)findViewById(R.id.iv_emoticon_display);
		m_addEmoticonClose = (ImageView)findViewById(R.id.iv_add_emoticon_close);
		m_hscroll = (HorizontalScrollView) findViewById(R.id.horizontalScroll);
		m_hscroll_badge = (LinearLayout) findViewById(R.id.layout_hscroll_badge);

		m_layout_basic_emoticon = (LinearLayout) findViewById(R.id.layout_chat_input_emoticon_2);

		for(int i = 0; i<views.length; i++){
			views[i] = getLayoutInflater().inflate(R.layout.layout_emoticon_what,null);
			m_hscroll_badge.addView(views[i]);
			final View tempview = views[i];
			final ImageView iv_image = (ImageView) views[i].findViewById(R.id.iv_emoticon_tab);
			views[i].setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					m_nSelect = m_hscroll_badge.indexOfChild(tempview);
					if(m_nSelect != 0) {
						m_layout_indicator.setVisibility(View.VISIBLE);
						m_vpEmoticonPager.setVisibility(View.VISIBLE);
						m_layout_basic_emoticon.setVisibility(View.GONE);
						adapter.notifyDataSetChanged();
						m_vpEmoticonPager.setAdapter(adapter);
						m_vpEmoticonPager.setCurrentItem(1, false);
					}else {
						m_layout_indicator.setVisibility(View.GONE);
						m_vpEmoticonPager.setVisibility(View.GONE);
						m_layout_basic_emoticon.setVisibility(View.VISIBLE);
					}
					for(int j = 0 ; j< views.length;j++) {
						if(views[j] == v) {
							v.setBackgroundColor(Color.parseColor("#33000000"));
							final ImageView iv_image = (ImageView) views[j].findViewById(R.id.iv_emoticon_tab);
							iv_image.setImageResource(m_nemoticonTab_drawIds[j][1]);
						} else {
							views[j].setBackgroundColor(Color.parseColor("#ffffff"));
							final ImageView iv_image = (ImageView) views[j].findViewById(R.id.iv_emoticon_tab);
							iv_image.setImageResource(m_nemoticonTab_drawIds[j][0]);
						}
					}
				}
			});
			iv_image.setImageResource(m_nemoticonTab_drawIds[i][0]);
		}
		views[0].setBackgroundColor(Color.parseColor("#33000000"));
		m_vpEmoticonPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

			}

			@Override
			public void onPageSelected(int position) {

			}

			@Override
			public void onPageScrollStateChanged(int state) {
				if(state == ViewPager.SCROLL_STATE_IDLE) {
					if(m_vpEmoticonPager.getCurrentItem()== (max_page-1))
						m_vpEmoticonPager.setCurrentItem(1,false);
					else if(m_vpEmoticonPager.getCurrentItem() == 0)
						m_vpEmoticonPager.setCurrentItem(max_page-2,false);
				}
			}
		});

		if(m_strRoomId.equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))){
			m_ChatBottom.setVisibility(View.GONE);
			m_SystemRoomLayout.setVisibility(View.VISIBLE);
			btnMenu.setVisibility(View.GONE);
			ImageView ivChatmenuRightUp = (ImageView) findViewById(R.id.iv_chat_menu_right_up);
			ivChatmenuRightUp.setVisibility(View.GONE);
		} else if(m_strRoomId.equals(Integer.toString(App.m_nChatbot))){
			btnMenu.setVisibility(View.GONE);
			ImageView ivChatmenuRightUp = (ImageView) findViewById(R.id.iv_chat_menu_right_up);
			ivChatmenuRightUp.setVisibility(View.GONE);
		}
		m_arrRoomData = new ArrayList<ChatRoomData>();

		if (AppSetting.FEATURE_VARIANT.equals("R")) {
			m_MenuRegular.setVisibility(View.VISIBLE);
			m_MenuPartner.setVisibility(View.GONE);
			m_MenuRegular2.setVisibility(View.VISIBLE);
			m_MenuPartner2.setVisibility(View.GONE);
		} else {
			m_MenuRegular.setVisibility(View.GONE);
			m_MenuPartner.setVisibility(View.VISIBLE);
			m_MenuRegular2.setVisibility(View.GONE);
			m_MenuPartner2.setVisibility(View.VISIBLE);
		}

		m_ivSearchCancel = (ImageView) findViewById(R.id.iv_chat_search_cancel);
		m_ivSearch = (ImageView) findViewById(R.id.iv_chat_search);
		m_ChatTitle = (RelativeLayout) findViewById(R.id.layout_chat_title);
		m_ChatSearch = (RelativeLayout) findViewById(R.id.layout_chat_search);
		m_BottomTotal = (LinearLayout) findViewById(R.id.layout_chat_bottom_total);
		m_BottomSearch = (LinearLayout) findViewById(R.id.layout_chat_bottom_search);
		m_ivSearchUP = (ImageView) findViewById(R.id.iv_search_up);
		m_ivSearchDown = (ImageView) findViewById(R.id.iv_search_down);

		m_ChatAdapter = new ChatRoomAdapter(ChatRoomAct.this);
		m_lvChat = (ListView) findViewById(R.id.lv_chat_room);
		m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
		m_lvChat.setAdapter(m_ChatAdapter);
		m_lvChat.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				if(m_strRoomId.equals(String.valueOf(App.m_nChatbot))){
					if(view.getAdapter().getCount()!=0){
						int firstVisiblePosition = view.getFirstVisiblePosition();
						m_ChatAdapter.setInvisibleTiniMessageIsFirst(firstVisiblePosition,visibleItemCount,totalItemCount);
					}
				}

				if (!m_isFirstRead && !m_isRefresh && firstVisibleItem == 0) {

					// ChattingDBManager chattingDBMng = new
					// ChattingDBManager(ChatRoomAct.this);
					// chattingDBMng.openReadable(m_strRoomId);
					// ArrayList<ChattingMessageData> chattingMessageData =
					// chattingDBMng.getChattingMessage();
					// chattingDBMng.close();

					m_nBeforeListViewItemCount = totalItemCount;
					if (m_arrChattingMessageData.size() > m_nScreenMessageCount) {
						m_nScreenMessageCount += 20;

						if (m_nScreenMessageCount > m_nAdapterCount) {
							ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
							chattingDBMng.openWritable(m_strRoomId);
							ArrayList<ChattingMessageData> newMessageData = new ArrayList<ChattingMessageData>();
							newMessageData = chattingDBMng.getChattingMessage(m_arrChattingMessageData.get(0).m_lnMsgSendTime, 200);
							chattingDBMng.close();
							CommonLog.e(getClass().getSimpleName(), "Get dB and add message");
							m_arrChattingMessageData.addAll(0, newMessageData);
							m_nAdapterCount += 200;
						}

						printMessage(PRINT_MESSAGE_PAGING);

					}

				}
				if (totalItemCount > 0 && firstVisibleItem + visibleItemCount == totalItemCount) {
					m_NewMessage.setVisibility(View.GONE);
				}

			}
		});

		//임시
		m_etSearch = (EditText)findViewById(R.id.et_search_keyword);
		m_etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if(actionId == EditorInfo.IME_ACTION_SEARCH){
					if (v.getText().toString().trim().length() > 0) {
						m_BottomTotal.setVisibility(View.GONE);
						m_BottomSearch.setVisibility(View.VISIBLE);
						m_ivSearchUP.setOnClickListener(ChatRoomAct.this);
						m_ivSearchDown.setOnClickListener(ChatRoomAct.this);
						doSearchMessage(v.getText().toString());
					} else {
						m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.popup_search_not_input));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
				}
				return false;
			}
		});

		m_tvUrgentMessage.setLinkTextColor(Color.BLUE);

		ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(this, m_strRoomId);
		if (roomData != null)
			m_isAlarm = roomData.m_isAlarmOn;

		if (roomData != null && roomData.m_isTitleEdited){
			LocalAesCrypto crypto;
			try {
				crypto = new LocalAesCrypto();
				m_tvTitle.setText(crypto.decrypt(roomData.m_strRoomTitle));
				m_tvChatMenuTitle.setText(crypto.decrypt(roomData.m_strRoomTitle));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		} else {
			m_tvTitle.setText(m_strFriendUserName);
			m_tvChatMenuTitle.setText(m_strFriendUserName);
		}

		if(m_isFavoriteRoom)
			m_ivChatMenuFavorite.setVisibility(View.VISIBLE);
		else
			m_ivChatMenuFavorite.setVisibility(View.GONE);

	/*	m_btnCloud.setOnClickListener(this);*/
		MenuPagerAdapter menuAdapter = new MenuPagerAdapter();
		m_BottomPager.setAdapter(menuAdapter);
		btnMenu.setOnClickListener(this);
		if(!m_strRoomId.equals(Integer.toString(App.m_nChatbot))){
			m_btnAttach.setOnClickListener(this);
		}else{
			m_btnAttach.setImageResource(R.drawable.img_chatbot);
			/*m_btnAttach.setScaleType(ImageView.ScaleType.FIT_CENTER);
			LinearLayout.LayoutParams control = (LinearLayout.LayoutParams)m_btnAttach.getLayoutParams();
			control.bottomMargin = (int)(7*getResources().getDisplayMetrics().density);
			control.height = (int)(39*getResources().getDisplayMetrics().density);*/
		}

		m_btnSend.setOnClickListener(this);
		m_etMessage.setOnTouchListener(this);
		m_btnSendPicture.setOnClickListener(this);
		m_btnVideo.setOnClickListener(this);
		m_btnSendFile.setOnClickListener(this);
		m_btnCamera.setOnClickListener(this);
		if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageSharingEnabled) {
			m_btnSendPicture.setBackgroundResource(R.drawable.btn_file_photo_disabled);
			m_btnVideo.setBackgroundResource(R.drawable.btn_file_move_disabled);
			m_btnCamera.setBackgroundResource(R.drawable.btn_file_camera_disabled);
			m_btnSendPicture.setOnClickListener(null);
			m_btnVideo.setOnClickListener(null);
			m_btnCamera.setOnClickListener(null);
		} else if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageSharingEnabled) {
			m_btnSendPicture.setBackgroundResource(R.drawable.btn_file_photo_disabled);
			m_btnVideo.setBackgroundResource(R.drawable.btn_file_move_disabled);
			m_btnCamera.setBackgroundResource(R.drawable.btn_file_camera_disabled);
			m_btnSendPicture.setOnClickListener(null);
			m_btnVideo.setOnClickListener(null);
			m_btnCamera.setOnClickListener(null);
		}
		if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileSharingEnabled) {
			m_btnSendFile.setBackgroundResource(R.drawable.btn_file_file_disabled);
			m_btnSendFile.setOnClickListener(null);
		} else if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileSharingEnabled) {
			m_btnSendFile.setBackgroundResource(R.drawable.btn_file_file_disabled);
			m_btnSendFile.setOnClickListener(null);
		}



		m_UrgentMessage.setOnClickListener(this);
		m_UrgentMessageClose.setOnClickListener(this);
		m_NewMessage.setOnClickListener(this);
		/*m_btnEmoticon.setOnClickListener(this);*/

		m_btnEmoticonAdd.setOnClickListener(this);

		m_btnSendContact.setOnClickListener(this);
		m_btnEmo01.setOnClickListener(this);
		m_btnEmo02.setOnClickListener(this);
		m_btnEmo03.setOnClickListener(this);
		m_btnEmo04.setOnClickListener(this);
		m_btnEmo05.setOnClickListener(this);
		m_btnEmo06.setOnClickListener(this);
		m_btnEmo07.setOnClickListener(this);
		m_btnEmo08.setOnClickListener(this);
		m_btnEmo09.setOnClickListener(this);
		m_btnEmo10.setOnClickListener(this);
		m_btnEmo11.setOnClickListener(this);
		m_btnEmo12.setOnClickListener(this);
		m_btnEmo13.setOnClickListener(this);
		m_btnEmo14.setOnClickListener(this);
		m_btnEmo15.setOnClickListener(this);
		m_btnEmo16.setOnClickListener(this);
		m_btnEmo17.setOnClickListener(this);
		m_btnEmoDel.setOnClickListener(this);
		m_ivSearchCancel.setOnClickListener(this);
		m_ivSearch.setOnClickListener(this);
		m_ivSearchUP.setOnClickListener(this);
		m_ivSearchDown.setOnClickListener(this);

		m_ivEmoticonDisplay.setOnClickListener(this);


		m_etMessage.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				m_nEmoticonAddCount = 0;
				// TODO Auto-generated method stub
				String strMessage = m_etMessage.getText().toString();
				if (strMessage.isEmpty() || strMessage.trim().equals("")) {
					if(m_EmoticonContainer.getVisibility() == View.VISIBLE){
						m_btnSend.setBackgroundResource(R.drawable.btn_send_talk_on);
					} else {
					m_btnSend.setBackgroundResource(R.drawable.btn_send_talk);
					}
				} else {
					char[] szText = strMessage.toCharArray();
					boolean isEmoticon = false;
					String strTempEmoticonText = "";

					for(int i = 0; i < szText.length; i++)
					{
						char c = szText[i];

						if(!isEmoticon && c == '(')
						{
							isEmoticon = true;
						}
						else if(isEmoticon && c == ')')
						{
							if(strTempEmoticonText.length() == 2)
							{
								m_nEmoticonAddCount++;
							}

							isEmoticon = false;
							strTempEmoticonText = "";
						}
						else if(isEmoticon)
						{
							strTempEmoticonText += c;

							if(strTempEmoticonText.length() > 2)
							{
								isEmoticon = false;
								strTempEmoticonText = "";
							}
						}
					}
					if(m_nEmoticonAddCount !=0) {
						if ((s.length() % m_nEmoticonAddCount) != 0 && !m_isBasicEmoticonPaddingChange) {
							m_isBasicEmoticonPaddingChange = true;
							m_etMessage.setPadding(m_etMessage.getPaddingLeft(), m_Edittext_paddingTop - 24, m_etMessage.getPaddingRight(), m_etMessage.getPaddingBottom());
						} else if ((s.length() % m_nEmoticonAddCount) == 0) {
							m_etMessage.setPadding(m_etMessage.getPaddingLeft(), m_Edittext_paddingTop, m_etMessage.getPaddingRight(), m_etMessage.getPaddingBottom());
						}
					}
					if(!isEmoticon) {
						m_isBasicEmoticonPaddingChange = false;
						m_isBasicEmoticonRemain = false;
						m_etMessage.setPadding(m_etMessage.getPaddingLeft(), m_Edittext_paddingTop, m_etMessage.getPaddingRight(), m_etMessage.getPaddingBottom());
					}
					m_btnSend.setBackgroundResource(R.drawable.btn_send_talk_on);
				}
				if (m_etMessage.getText().toString().length() > 2999) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.popup_limit_text));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});
		if(m_strCopyText !=null){
			m_etMessage.requestFocus();
			m_etMessage.setText(m_strCopyText);
			m_etMessage.setSelection(m_strCopyText.length());
			m_strCopyText = null;
			Handler mHandler = new Handler();
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					showSoftkeyboard(m_etMessage);
				}
			}, 500);
		}
		if (m_strSendMessage != null && m_strType == null) {
			m_etMessage.requestFocus();
			m_etMessage.setText(m_strSendMessage);
			m_etMessage.setSelection(m_strSendMessage.length());
			m_strSendMessage = null;
			Handler mHandler = new Handler();
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					showSoftkeyboard(m_etMessage);
				}
			}, 500);

		}
		
//		 Utils.processStorageBackup(this, "ttalk_contacts.db", "ttalk_temp_contacts.db");
//		 Utils.processStorageBackup(this, "ttalk_chatting_" + m_strRoomId
//		 + ".db", "ttalktemp_ttt" + m_strRoomId + ".db");


		if(m_strRoomId.equals(""+App.m_nChatbot)){
			m_ChatAdapter.setTiniSelectItemListener(mTiniSelectListener);
			setTINIMessage();
		}
		printMessage(PRINT_MESSAGE_PAGING);
	}

	public class ViewPagerAdapter extends FragmentStatePagerAdapter {

		public ViewPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public int getItemPosition(Object object) {

			current_frag = new ChatRoomEmoticonViewpagerItemFrag();
			((ChatRoomEmoticonViewpagerItemFrag)current_frag).setSelect(m_nSelect);
			return POSITION_NONE;
		}

		@Override
		public Fragment getItem(int position) {
			if(position<0||max_page<=position)
				return null;
			current_frag = new ChatRoomEmoticonViewpagerItemFrag();
			((ChatRoomEmoticonViewpagerItemFrag)current_frag).setSelect(m_nSelect);
			((ChatRoomEmoticonViewpagerItemFrag)current_frag).setPosition(position);
			((ChatRoomEmoticonViewpagerItemFrag)current_frag).setMaxPage(max_page);
			return current_frag;
		}

		@Override
		public int getCount() {
			return max_page;
		}


		@Override
		public void finishUpdate(ViewGroup container) {
			super.finishUpdate(container);
			int postion = m_vpEmoticonPager.getCurrentItem();
			if(postion == 1){
				m_ivEmoindicator1.setImageResource(R.drawable.icon_num_on);
				m_ivEmoindicator2.setImageResource(R.drawable.icon_num);
				m_ivEmoindicator3.setImageResource(R.drawable.icon_num);
			}else if(postion == 2){
				m_ivEmoindicator1.setImageResource(R.drawable.icon_num);
				m_ivEmoindicator2.setImageResource(R.drawable.icon_num_on);
				m_ivEmoindicator3.setImageResource(R.drawable.icon_num);
			}else if(postion == 3){
				m_ivEmoindicator1.setImageResource(R.drawable.icon_num);
				m_ivEmoindicator2.setImageResource(R.drawable.icon_num);
				m_ivEmoindicator3.setImageResource(R.drawable.icon_num_on);
			}

		}
	}




	// 날짜 변경시 표시
	private void changeDay(long lSendTime, boolean isAddMessage) {

		String pattern = "dd";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		int date = Integer.parseInt(format.format(new Timestamp(lSendTime)));
		if (date != m_nBeforeMessageTime) {
			String patternFull = getString(R.string.chatroom_day_format);
			SimpleDateFormat formatFull = new SimpleDateFormat(patternFull);
			String dateFull = (String) formatFull.format(new Timestamp(lSendTime));
			if(isAddMessage){
				setSystemMsgAddDate(StaticString.CHAT_ROOM_SYSTEM_MSG_DAY, dateFull);
			} else {
				setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG_DAY, dateFull);
			}
		}
		m_nBeforeMessageTime = date;
	}

	// 자신의 글일때와 상대의 글일때를 구분해서 화면에 표시
	private synchronized void printMessage(int a_nState) {
//		m_arrNoReadMessageID.clear();
//		mapNoReadMessageID.clear();
		// '여기까지 읽으셨습니다'를 처음 확인할때
		int n_chattingMessageDataSize = 0;
		// ArrayList<ChattingMessageData> chattingMessageData = new
		// ArrayList<ChattingMessageData>();
		ChattingDBManager chattingDBMng = new ChattingDBManager(this);
		chattingDBMng.openReadable(m_strRoomId);
		if (m_isFirstRead) {
			m_nNoReadCount = chattingDBMng.getNoReadMessageCount();
			if (m_nNoReadCount > 160) {
				m_nAdapterCount = m_nAdapterCount + m_nNoReadCount;
			}
		}
		if ((a_nState != PRINT_MESSAGE_PAGING) && (a_nState != PRINT_MESSAGE_SEARCH)) {
			m_arrChattingMessageData = chattingDBMng.getChattingMessage(0, m_nAdapterCount);
			// chattingMessageData = chattingDBMng.getChattingMessage(0,
			// m_nAdapterCount);
			// m_arrChattingMessageData = new
			// ArrayList<ChattingMessageData>(chattingMessageData);
		} else {
			// chattingMessageData = m_arrChattingMessageData;
		}
		m_nBeforeMessageTime = 0;
		if (m_arrChattingMessageData != null) {
			n_chattingMessageDataSize = m_arrChattingMessageData.size();
		}

		if (m_arrChattingMessageData == null || m_arrChattingMessageData.isEmpty()) {

		} else {
			int nUserNo;
			String strUserMessage = null;
			JSONObject jsonUserMessage = null;
			int nNoReadCount;
			long lSendTime;
			int nMessageType = 0;
			int nSendStatus;
			boolean isRead = true;
			String strEmoticonName ="";


			// 최초 진입시 안 읽은 메시지가 많은경우 화면에 보여줄 메시지 갯수를 정하기 위해
			if (m_isFirstRead && m_nNoReadCount > 20) {
				for (int j = 0; j < n_chattingMessageDataSize; j++) {
					if (!m_arrChattingMessageData.get(j).m_isRead) {
						//if (m_arrChattingMessageData.get(j).m_nMsgType == 9 || m_arrChattingMessageData.get(j).m_nMsgType == 0) {
						if(m_arrChattingMessageData.get(j).m_nMsgType != StaticString.CHAT_ROOM_SYSTEM_MSG && m_arrChattingMessageData.get(j).m_nMsgType != StaticString.CHAT_ROOM_SYSTEM_MSG_DAY) {
							// +5는 좀더 여유롭게 보여 주기 위해
							m_nScreenMessageCount = n_chattingMessageDataSize - j + 5;
							break;
						}
					}
				}
			}
			// 긴급공지
			if (m_isFirstRead && a_nState != PRINT_MESSAGE_PAGING) {
				ChattingMessageData urgentData = chattingDBMng.getCurrentUrgentMessage();
				if (urgentData.m_nIdx != -1) {
					setUrgentNotice(urgentData);
					m_strUrgentID = urgentData.m_strMsgId;
					m_lUrgentTime = urgentData.m_lnMsgSendTime;
				}
				// for (ChattingMessageData findUrgentData :
				// chattingMessageData) {
				// if (findUrgentData.m_nMsgType ==
				// StaticString.CHAT_ROOM_URGENT_MESSAGE) {
				// setUrgentNotice(findUrgentData);
				// break;
				// }
				// }
			}
			// 맨 위의 글이 사라지는 문제 해결
			if (n_chattingMessageDataSize < m_nScreenMessageCount || m_nScreenMessageCount + 1 == n_chattingMessageDataSize)
				m_nScreenMessageCount = n_chattingMessageDataSize;
			m_isRefresh = true;
			m_arrRoomData = new ArrayList<ChatRoomData>();
			for (int i = n_chattingMessageDataSize - m_nScreenMessageCount; i < n_chattingMessageDataSize; i++) {

				try {
					nUserNo = m_arrChattingMessageData.get(i).m_nSendUserId;

					if(m_arrChattingMessageData.get(i).m_nMsgType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE || m_arrChattingMessageData.get(i).m_nMsgType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){
						strUserMessage = m_arrChattingMessageData.get(i).m_strMsgText;
						strEmoticonName = m_arrChattingMessageData.get(i).m_strEmoticon;
					} else {
						strUserMessage = m_arrChattingMessageData.get(i).m_strMsgText;
							try {
								jsonUserMessage = new JSONObject(strUserMessage);
							} catch (JSONException e){
							}
						strEmoticonName = "";
					}

				// 해당 메세지를 안읽은 유저의 수이다
				nNoReadCount = m_arrChattingMessageData.get(i).m_nNoReadUserCount;
				lSendTime = m_arrChattingMessageData.get(i).m_lnMsgSendTime;
				final String strMessageID = m_arrChattingMessageData.get(i).m_strMsgId;
				isRead = m_arrChattingMessageData.get(i).m_isRead;
				nMessageType = m_arrChattingMessageData.get(i).m_nMsgType;
				nSendStatus = m_arrChattingMessageData.get(i).m_nSendStatus;

				UserListData tData = null;

				if (m_arrContacts == null)
					m_arrContacts = ContactsDBManager.getContactsReturnSparseArray(ChatRoomAct.this);

				if (nMessageType != 1) {
					if (nUserNo == 0) {
						// data =
						// ContactsDBManager.getContacts(ChatRoomGroupAct.this,
						// App.m_MyUserInfo.m_nUserNo);
						tData = m_arrContacts.get(App.m_MyUserInfo.m_nUserNo);
					} else {
						// data =
						// ContactsDBManager.getContacts(ChatRoomGroupAct.this,
						// nUserNo);
						tData = m_arrContacts.get(nUserNo);
					}

				}

				final UserListData data = tData;

				boolean isSmileView = false;

				// if(nNoReadCount != 0){
				// m_arrNoReadOhterMessageID.add(strMessageID);
				// }
				changeDay(lSendTime, false);

				// 긴급 공지는 우선 처리한후, 메세지 부분으로 다시 처리
				if (nMessageType == StaticString.CHAT_ROOM_URGENT_MESSAGE) {
					nMessageType = 0;
					if (!strMessageID.equals(m_strUrgentID) && lSendTime > m_lUrgentTime) {
						setUrgentNotice(m_arrChattingMessageData.get(i));
						m_strUrgentID = strMessageID;
						m_lUrgentTime = lSendTime;
					}
				}

				if (nMessageType == StaticString.CHAT_ROOM_SYSTEM_MSG) {

					setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, strUserMessage);
				} else if (nMessageType == StaticString.CHAT_ROOM_MY_FILE) {

					setMyFile(StaticString.CHAT_ROOM_MY_FILE, nSendStatus, m_strRoomId, 0, lSendTime, nNoReadCount, strMessageID, jsonUserMessage);
				} else if (nMessageType == StaticString.CHAT_ROOM_OTHER_FILE) {
					// 마지막으로 읽은 부분
					if (m_nNoReadCount != 0 && !m_arrChattingMessageData.get(i).m_isRead && m_nReadPosition == -1 && m_isFirstRead) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");

						m_nReadPosition = i;
						CommonLog.e(this, "m_nReadPostion : " + m_nReadPosition + "MessageSize : " + n_chattingMessageDataSize + "No Read Count : "
								+ m_nNoReadCount);
					} else if (!m_isFirstRead && m_nReadPosition != -1 && m_nReadPosition == i) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");
					}
					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
						m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
						mapNoReadMessageID.put(strMessageID, true);
						m_arrChattingMessageData.get(i).m_isRead = true;
					}

					setOtherFile(StaticString.CHAT_ROOM_OTHER_FILE, m_strRoomId, m_nFriendUserNumber, m_strFriendUserName,m_strFriendUserType, lSendTime, nNoReadCount, strMessageID,
							m_UserData != null && m_UserData.m_isImageAvailable, isSmileView, jsonUserMessage);
				} else if (nMessageType == StaticString.CHAT_ROOM_MY_IMAGE) {
					if ((nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) || nSendStatus == StaticString.CHAT_SEND_STATUS_FAIL) {
						// 보내는 중이거나 실패 했을때

							setMyImage(StaticString.CHAT_ROOM_MY_IMAGE, nSendStatus, m_strRoomId, 0, lSendTime,
								nNoReadCount, strMessageID, jsonUserMessage);
					} else {

							setMyImage(StaticString.CHAT_ROOM_MY_IMAGE, nSendStatus, m_strRoomId, 0, lSendTime, nNoReadCount, strMessageID, jsonUserMessage);
					}
				} else if (nMessageType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
					// 마지막으로 읽은 부분
					if (m_nNoReadCount != 0 && !m_arrChattingMessageData.get(i).m_isRead && m_nReadPosition == -1 && m_isFirstRead) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");

						m_nReadPosition = i;
						CommonLog.e(this, "m_nReadPostion : " + m_nReadPosition + "MessageSize : " + n_chattingMessageDataSize + "No Read Count : "
								+ m_nNoReadCount);
					} else if (!m_isFirstRead && m_nReadPosition != -1 && m_nReadPosition == i) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");
					}
					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
						m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
						mapNoReadMessageID.put(strMessageID, true);
						m_arrChattingMessageData.get(i).m_isRead = true;
					}

						setOtherImage(StaticString.CHAT_ROOM_OTHER_IMAGE, nSendStatus, m_strRoomId, m_nFriendUserNumber, m_strFriendUserName,m_strFriendUserType,
								lSendTime, nNoReadCount, strMessageID, m_UserData != null && m_UserData.m_isImageAvailable, isSmileView, jsonUserMessage);
					} else if(nMessageType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE){

					if ((nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) || nSendStatus == StaticString.CHAT_SEND_STATUS_FAIL) {
						// 보내는 중이거나 실패 했을때
						setMyEmoticonMsg(StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE, nSendStatus, Integer.toString(m_nFriendUserNumber), 0,
								strUserMessage, nNoReadCount, lSendTime,strMessageID ,"","");
					} else {
						String strSearchText = "";
						if(!m_strSearchWord.trim().equals("") && strUserMessage.contains(m_strSearchWord)){
							strSearchText = m_strSearchWord;
						}
						setMyEmoticonMsg(StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE, nSendStatus, Integer.toString(m_nFriendUserNumber), 0,
								strUserMessage, nNoReadCount, lSendTime,strMessageID , strEmoticonName,strSearchText);
					}
				} else if(nMessageType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){

					if (m_nNoReadCount != 0 && !m_arrChattingMessageData.get(i).m_isRead && m_nReadPosition == -1 && m_isFirstRead) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");

						m_nReadPosition = i;
						CommonLog.e(this, "m_nReadPostion : " + m_nReadPosition + "MessageSize : " + n_chattingMessageDataSize + "No Read Count : "
								+ m_nNoReadCount);
					} else if (!m_isFirstRead && m_nReadPosition != -1 && m_nReadPosition == i) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");
					}
					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
							m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
							mapNoReadMessageID.put(strMessageID, true);
						m_arrChattingMessageData.get(i).m_isRead = true;
					}
					String strSearchText = "";
					if(!m_strSearchWord.trim().equals("") && strUserMessage.contains(m_strSearchWord)){
						strSearchText = m_strSearchWord;
					}
					setOtherEmoticonMsg(StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE, nSendStatus, m_strRoomId, m_nFriendUserNumber, m_strFriendUserName,m_strFriendUserType,
							strEmoticonName,strUserMessage, lSendTime, nNoReadCount, strMessageID, m_UserData != null && m_UserData.m_isImageAvailable, isSmileView,strSearchText);
				}
				// 아래는 모두 메세지, 타입은 0이다
				else if (nUserNo == 0 && nMessageType == 0) {
					// if (!isRead && nSendStatus ==
					// StaticString.CHAT_SEND_STATUS_SUCCESS) {
					// // chattingDBMng.updateReadMessage(strMessageID, true);
					// m_arrNoReadMessageID.add(strMessageID);
					// mapNoReadMessageID.put(strMessageID, true);
					// }

					String strSearchText = "";
					if(!m_strSearchWord.trim().equals("") && strUserMessage.contains(m_strSearchWord)){
						strSearchText = m_strSearchWord;
					}
					setMyMsg(StaticString.CHAT_ROOM_MY_MESSAGE, nSendStatus, Integer.toString(m_nFriendUserNumber), 0, strUserMessage, nNoReadCount, lSendTime,
							strMessageID ,strSearchText);

				} else {
					// 마지막으로 읽은 부분
					if (m_nNoReadCount != 0 && !m_arrChattingMessageData.get(i).m_isRead && m_nReadPosition == -1 && m_isFirstRead) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");

						m_nReadPosition = i;
						CommonLog.e(this, "m_nReadPostion : " + m_nReadPosition + "MessageSize : " + n_chattingMessageDataSize + "No Read Count : "
								+ m_nNoReadCount);
					} else if (!m_isFirstRead && m_nReadPosition != -1 && m_nReadPosition == i) {
						if (m_nNoReadCount > 10)
							setSystemMsg(StaticString.CHAT_ROOM_SYSTEM_MSG, "여기까지 읽으셨습니다.");
					}

					if (!isRead) {
						// chattingDBMng.updateReadMessage(strMessageID, true);
						if(!m_arrNoReadMessageID.contains(strMessageID))
						m_arrNoReadMessageID.add(strMessageID);
						if(!mapNoReadMessageID.containsKey(strMessageID))
						mapNoReadMessageID.put(strMessageID, true);
						m_arrChattingMessageData.get(i).m_isRead = true;
					}
					String strSearchText = "";
					if(!m_strSearchWord.trim().equals("") && strUserMessage.contains(m_strSearchWord)){
						strSearchText = m_strSearchWord;
					}
					setOtherMsg(StaticString.CHAT_ROOM_OTHER_MESSAGE, m_nFriendUserNumber, m_strRoomId, m_strFriendUserName,m_strFriendUserType, strUserMessage, nNoReadCount,
							lSendTime, strMessageID, m_UserData != null && m_UserData.m_isImageAvailable, isSmileView,strEmoticonName,strSearchText);
				}
				} catch (Exception e){

			}
			}
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					// m_ChatAdapter.notifyDataSetChanged();
					// m_ChatAdapter.dataSetChanged();
					m_ChatAdapter.addAll(m_arrRoomData);
					m_ChatAdapter.dataSetChanged();
				}
			});
			if (a_nState == PRINT_MESSAGE_SCROLL) {
				if (m_isFirstRead && m_nReadPosition != -1) {
					m_isFirstRead = false;
					// setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//					if (mService != null && m_isGetReadUserCount) {
//						chattingDBMng.updateReadMessage(mapNoReadMessageID);
//						SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
//						int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
//						int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
//						if (nUpdateBadgeCount < 0) {
//							nUpdateBadgeCount = 0;
//						}
//						pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
//						IconBadge.updateIconBadge(ChatRoomAct.this);
//						
//						if (!m_arrNoReadMessageID.isEmpty()) {
//							mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//						}
//						m_arrNoReadMessageID.clear();
//						mapNoReadMessageID.clear();
//					}
					final int n_chattingMessageData = n_chattingMessageDataSize;
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							m_lvChat.setSelection(m_nScreenMessageCount - (n_chattingMessageData - m_nReadPosition));
						}
					});

				} else if (m_isFirstRead && m_nReadPosition == -1) {
					m_isFirstRead = false;
					// setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//					if (mService != null && m_isGetReadUserCount) {
//						chattingDBMng.updateReadMessage(mapNoReadMessageID);
//						SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
//						int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
//						int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
//						if (nUpdateBadgeCount < 0) {
//							nUpdateBadgeCount = 0;
//						}
//						pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
//						IconBadge.updateIconBadge(ChatRoomAct.this);
//						
//						if (!m_arrNoReadMessageID.isEmpty()) {
//							mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//						}
//						m_arrNoReadMessageID.clear();
//						mapNoReadMessageID.clear();
//					}
					if (m_isGetOfflineMessage) {
						m_isGetOfflineMessage = false;
					} else {
						runOnUiThread(new Runnable() {

							@Override
							public void run() {
								m_lvChat.setSelection(21);
							}
						});
					}
				} else {
					CommonLog.e(this, "LastVisiible : " + m_lvChat.getLastVisiblePosition() + "Get Count : " + m_lvChat.getCount());
					// 마지막 메시지가 내 메시지면
					if (n_chattingMessageDataSize > 1) {
						if (nMessageType != StaticString.CHAT_ROOM_SYSTEM_MSG
								&& m_arrChattingMessageData.get(n_chattingMessageDataSize - 1).m_strMsgId.split("_")[1].equals(Integer
										.toString(App.m_MyUserInfo.m_nUserNo))) {
							m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
						} else if (m_lvChat.getLastVisiblePosition() == m_lvChat.getCount() - 2) {
							m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
							// m_lvChat.setSelection(m_lvChat.getCount() + 5);
						} else {
							if (!isRead) {
								// 스크롤 올렸을때 다른 사람의 메시지가 올 경우
								m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);

								if (m_arrContacts == null)
									m_arrContacts = ContactsDBManager.getContactsReturnSparseArray(ChatRoomAct.this);
								final UserListData userData = m_arrContacts.get(m_nFriendUserNumber);

								final String strUserName = userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);

								final int nFinalMessageType = nMessageType;
								final String strFinalUserMessage = strUserMessage;


								runOnUiThread(new Runnable() {

									@Override
									public void run() {
										m_NewMessage.setVisibility(View.VISIBLE);
										// TODO Auto-generated method stub


										if (nFinalMessageType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
											m_tvNewMessage.setText(R.string.chatroom_file_img);
										} else if (nFinalMessageType == StaticString.CHAT_ROOM_OTHER_FILE) {
											try {
												JSONObject jsonUserMessage = new JSONObject(strFinalUserMessage);
											if (jsonUserMessage.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
												m_tvNewMessage.setText(R.string.chatroom_file_movie);
											} else {
												m_tvNewMessage.setText(jsonUserMessage.getString(StaticString.XMPP_TEXT_FILENAME));
											}
											} catch (JSONException e) {
												e.printStackTrace();
											}
										} else if(nFinalMessageType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE){
											EmoticonUtils utils = new EmoticonUtils();
											m_tvNewMessage.setText(getString(R.string.emoticon)+utils.parsingEmoticonText(ChatRoomAct.this, strFinalUserMessage, (int) m_tvNewMessage.getTextSize()));
										} else {
											EmoticonUtils utils = new EmoticonUtils();
											m_tvNewMessage.setText(utils.parsingEmoticonText(ChatRoomAct.this, strFinalUserMessage,
													(int) m_tvNewMessage.getTextSize()));
										}
										m_tvNewMessageInfo.setText(strUserName);
										if (userData != null && userData.m_isImageAvailable) {
											App.imageloader.cancelDownload(m_ivNewMessageImage);
											App.imageloader.getProfileImage(m_ivNewMessageImage, App.getImageDownLoaderUrl(userData.m_nUserNo, true),
													R.drawable.profile_pic_default, false);

										} else {
											App.imageloader.cancelDownload(m_ivNewMessageImage);
											m_ivNewMessageImage.setImageResource(R.drawable.profile_pic_default);
										}
										m_ivNewMessageNotFellowImage.setVisibility(View.GONE);

									}
								});

							}
						}
					}
				}

			} else {
				if (a_nState == PRINT_MESSAGE_PAGING) {
					// 상단에 이전 메세지가 표시된 후에도 현재의 위치를 보여 주기 위해

					m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
					m_lvChat.setSelection(m_lvChat.getCount() - m_nBeforeListViewItemCount + 1);
				} else if (a_nState == PRINT_MESSAGE_SEARCH) {
					m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);

				}
			}
			if (m_nDBMessageCount != n_chattingMessageDataSize)
				m_nScreenMessageCount += 1;

			m_nDBMessageCount = n_chattingMessageDataSize;

			// if (m_isOnStop)
			// setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//			if (mService != null && m_isGetReadUserCount) {
//				chattingDBMng.updateReadMessage(mapNoReadMessageID);
//				SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
//				int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
//				int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
//				if (nUpdateBadgeCount < 0) {
//					nUpdateBadgeCount = 0;
//				}
//				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
//				IconBadge.updateIconBadge(ChatRoomAct.this);
//				
//				if (!m_arrNoReadMessageID.isEmpty()) {
//					mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
//				}
//				m_arrNoReadMessageID.clear();
//				mapNoReadMessageID.clear();
//			}
			// else
			// m_arrNoReadMessageID.clear();
			m_isRefresh = false;
		}
		if (m_strSendMessage != null && m_strType != null) {
			// final String strPacketID =
			// Long.toString(System.currentTimeMillis()) + "_" +
			// App.m_MyUserInfo.m_nUserNo;
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if (mService != null) {
						String strSendMessage = m_strSendMessage;
						try {
							JSONObject jsonSendMessage = new JSONObject(strSendMessage);

						String strType = m_strType;
						m_strSendMessage = null;
						m_strType = null;

						if (strType.equals(StaticString.FILE_TYPE_IMAGE)) {

							passImageOther(jsonSendMessage.getInt(StaticString.XMPP_TEXT_WIDTH), jsonSendMessage.getInt(StaticString.XMPP_TEXT_HEIGHT),
									jsonSendMessage.getString(StaticString.XMPP_TEXT_URL), jsonSendMessage.getString(StaticString.XMPP_TEXT_THUMB));
						} else {

							passFileOther(strType, jsonSendMessage);
						}
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				}
			});

		}
		chattingDBMng.close();
		if (!m_isGetReadUserCount) {
			m_isGetReadUserCount = true;
			// m_ReadHandler = new Handler(Looper.getMainLooper());
			//
			// m_ReadRunnable = new Runnable() {
			//
			// @Override
			// public void run() {
			// // TODO Auto-generated method stub
			// CommonLog.e(getClass().getSimpleName(), "Run get read count!!!");
			// getReadCount();
			// m_ReadHandler.postDelayed(this, 5000);
			// }
			// };
			//
			// m_ReadHandler.postDelayed(m_ReadRunnable, 100);

				m_hReadCount.removeMessages(0);
				m_hReadCount.sendEmptyMessageDelayed(0, 100);

			// m_arrNoReadOhterMessageID.clear();
		}
	}

	private Handler m_hReadCount = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			CommonLog.e(getClass().getSimpleName(), "Run get read count!!!");

			/*if(m_strRoomId.equals(String.valueOf(App.m_nChatbot))){
				m_lvChat.setSelection(10000);
				ChattingDBManager dbMng = new ChattingDBManager(ChatRoomAct.this);
				dbMng.openWritable(m_strRoomId);
					ArrayList<ChattingMessageData> arrNoReadMine = dbMng.getChattingMessageNotNoReadMine();
					for(ChattingMessageData noReadMine : arrNoReadMine){
						if(!m_arrNoReadMessageID.contains(noReadMine.m_strMsgId)){
							m_arrNoReadMessageID.add(noReadMine.m_strMsgId);
						}
						mapNoReadMessageID.put(noReadMine.m_strMsgId, true);
					}

				dbMng.updateReadMessageInGetReadCount(mapNoReadMessageID);
				dbMng.close();

				SharedPref pref = SharedPref.getInstance(ChatRoomAct.this);
				int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
				int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
				if (nUpdateBadgeCount < 0) {
					nUpdateBadgeCount = 0;
				}
				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
				IconBadge.updateIconBadge(ChatRoomAct.this);

				if (!m_arrNoReadMessageID.isEmpty()) {
					mService.setReadRoomMessage(m_arrNoReadMessageID, m_strRoomId);
				}
			} else{*/
				if(!m_isGetReadCount){
					getReadCount();
				}
				m_hReadCount.sendEmptyMessageDelayed(0, 5000);
			//}
			super.handleMessage(msg);
		}
	};

	// 긴급 공지 설정
	public void setUrgentNotice(final ChattingMessageData chattingMessageData) {
		if (chattingMessageData.m_nSendUserId == 0)
			chattingMessageData.m_nSendUserId = App.m_MyUserInfo.m_nUserNo;
		// final UserListData userData =
		// TTalkDBManager.ContactsDBManager.getContacts(this,
		// chattingMessageData.m_nSendUserId);
		if (m_arrContacts == null)
			m_arrContacts = ContactsDBManager.getContactsReturnSparseArray(ChatRoomAct.this);
		final UserListData userData = m_arrContacts.get(chattingMessageData.m_nSendUserId);
		String[] aesData;
		String strName;
		if(userData == null){
			strName = getString(R.string.not_in_db_user);
		} else {
			strName = userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
		}
		final String strUserName = strName;

		String pattern = "MM.dd a h:mm";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		final String dateFull = (String) format.format(new Timestamp(chattingMessageData.m_lnMsgSendTime));

		final EmoticonUtils utils = new EmoticonUtils();

		String strText = chattingMessageData.m_strMsgText;
		String strLastChar = " ";
		String strFirstChar = " ";

		if (strText != null && strText.length() != 0) {
			while (strLastChar.equals(" ") || strLastChar.equals("\n")) {
				strLastChar = (String) strText.subSequence(strText.length() - 1, strText.length());
				if (strLastChar.equals(" ") || strLastChar.equals("\n")) {
					strText = (String) strText.subSequence(0, strText.length() - 1);
				}
			}
			while (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
				strFirstChar = (String) strText.subSequence(0, 1);
				if (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
					strText = (String) strText.subSequence(1, strText.length());
				}
			}
		}

		String strViewText = "";
		if(strText.length() > 100){
			strViewText = strText.substring(0, 97);
			char[] cText = strViewText.toCharArray();
			for(int i = 94; i < 97; i++){
				if(cText[i] == '('){
					strViewText = strText.substring(0, i);
					break;
				}
			}
			strViewText = strViewText + "...";
			strText = strViewText;
		} else {

		}
		final String strFinalTest = strText;
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				m_UrgentMessage.setVisibility(View.VISIBLE);
				m_tvUrgentMessage.setText(utils.parsingEmoticonText(ChatRoomAct.this, strFinalTest, (int) m_tvUrgentMessage.getTextSize()));
				CustomLinkify.addLinks(m_tvUrgentMessage, CustomLinkify.ALL);
				m_tvUrgentMessage.setOnClickListener(ChatRoomAct.this);
				m_tvUrgentMessageInfo.setText(strUserName + " | " + dateFull);
				if (userData != null && userData.m_isImageAvailable) {
					App.imageloader.cancelDownload(m_ivUrgentImage);
					App.imageloader.getProfileImage(m_ivUrgentImage, App.getImageDownLoaderUrl(chattingMessageData.m_nSendUserId, true),
							R.drawable.profile_pic_default, false);

				} else {
					App.imageloader.cancelDownload(m_ivUrgentImage);
					m_ivUrgentImage.setImageResource(R.drawable.profile_pic_default);
				}
				m_ivUrgentNotFellowImage.setVisibility(View.GONE);
				if (chattingMessageData.m_nSendUserId == App.m_MyUserInfo.m_nUserNo) {
					chattingMessageData.m_nSendUserId = 0;
				}
			}
		});

	}

	// 자신이 글을 읽었음을 알림
	public void setReadRoomMessage(ArrayList<String> arrNoReadMessageID, String strRoomId) {
		// ChattingDBManager chattingDBMng2 = new ChattingDBManager(this);
		// chattingDBMng2.openWritable(m_strRoomId);
		// if (!arrNoReadMessageID.isEmpty()) {
		// CommonLog.e(this, "Ready Send Read Message");
		// for(String strNoReadMessageID : arrNoReadMessageID)
		// chattingDBMng2.updateReadMessage(strNoReadMessageID, true);
		// //mService.setReadRoomMessage(arrNoReadMessageID, strRoomId);
		// }
		// chattingDBMng2.close();

		m_isOnStop = false;
		// m_arrNoReadMessageID.clear();

	}

	// 메시지 삭제
	public void deleteMessage(String strMessageID) {
		ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
		chattingDBMng.openWritable(m_strRoomId);
		chattingDBMng.deleteChattingMessage(strMessageID);
		chattingDBMng.close();
		m_nReadPosition -= 1;
		m_nAdapterCount -= 1;
		m_nScreenMessageCount -= 1;
		printMessage(PRINT_MESSAGE_SCROLL);
	}
	//tiniMessage의 선택지 삭제
	public void deleteTiniSelectMsg(String strMessageID){
		ChattingSelectDBManager chattingSelectDBMng = new ChattingSelectDBManager(ChatRoomAct.this);
		chattingSelectDBMng.openWritable();
		chattingSelectDBMng.deleteChattingMessage(strMessageID);
		chattingSelectDBMng.close();
		printMessage(PRINT_MESSAGE_SCROLL);
	}

	public void setDataChanged() {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {

				m_ChatAdapter.notifyDataSetChanged();
			}
		});
	}

	// 초기화 되었을때
	public void clearRoom() {

		// runOnUiThread(new Runnable() {
		// @Override
		// public void run() {
		//
		printMessage(PRINT_MESSAGE_SCROLL);
		// }
		// });
	}

	// 재전송
	public void reSendMessage(String sendMessage, final String strPacketID) {

		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				m_etMessage.setText("");
			}
		});
		// mService.sendMessage(sendMessage, "", m_nFriendUserNumber,
		// strPacketID);
		sendMessage(sendMessage, false);

	}

	// 재전송 시 기존 메세지 어댑터 에서 제거
	public void reSendDelete(final ChatRoomData data) {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i = 0; i < m_arrChattingMessageData.size(); i++) {
					if (m_arrChattingMessageData.get(i).m_strMsgId.equals(data.m_strMessageID)) {
						m_arrChattingMessageData.remove(i);
						break;
					}

				}
				// m_arrChattingMessageData.remove(data);

				m_ChatAdapter.deleteResendMessage(data);
				m_ChatAdapter.notifyDataSetChanged();
			}
		});

	}

	// 초대
	public void inviteOther(Intent data) {

		ArrayList<Integer> arrUserData = data.getIntegerArrayListExtra(IntentKeyString.INTENT_KEY_ARR_USERNO);

		arrUserData.add(m_nFriendUserNumber);

		Intent intent = new Intent(this, ChatRoomGroupAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, arrUserData);
		startActivity(intent);
		finish();

	}

	// 채팅 내용 전달
	public void sendMessageOther(String strMessage) {
		Intent intentInvite = new Intent(ChatRoomAct.this, ChatInviteTabAct.class);
		intentInvite.putExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE, strMessage);
		startActivityForResult(intentInvite, REQUEST_CODE_SENDMESSAGE);
	}

	// 파일 전달
	public void sendFileOther(String strMessage) {

		String strType = "";
		try {
			JSONObject jsonObject = new JSONObject(strMessage);
			strType = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		Intent intentInvite = new Intent(ChatRoomAct.this, ChatInviteTabAct.class);
		intentInvite.putExtra(IntentKeyString.INTENT_KEY_SEND_FILE, strType);
		intentInvite.putExtra(IntentKeyString.INTENT_KEY_SEND_MESSAGE, strMessage);
		startActivityForResult(intentInvite, REQUEST_CODE_SENDMESSAGE);
	}

	// Menu Button Click 처리
	private void clickMenuButton() {
		if (!m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
			hideKeyPad(m_etMessage);
			m_layoutDrawerLayout.openDrawer(Gravity.RIGHT);

		} else {
			m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
		}
	}

	//TINI 챗봇 기본 메시지 삽입
	public void setTINIMessage(){
		ChattingDBManager chattingDBMng = new ChattingDBManager(this);
		chattingDBMng.openWritable(m_strRoomId);
		ArrayList<ChattingMessageData> arrData = chattingDBMng.getChattingMessage(0, m_nAdapterCount);
		if(arrData == null || arrData.isEmpty()) {
			final long lTime = System.currentTimeMillis();
			String strPacketID = null;

			if(m_strRoomId.equals(String.valueOf(App.m_nChatbot)))//Mock TINI를 위해 100번 분리
				strPacketID = Long.toString(lTime) + "_" + App.m_nChatbot;
			else
				strPacketID = Long.toString(lTime) + "_" + "100";

			ChattingMessageData a_chattingMsgData;
			a_chattingMsgData = new ChattingMessageData();
			if(m_strRoomId.equals(String.valueOf(App.m_nChatbot)))
				a_chattingMsgData.m_nSendUserId = App.m_nChatbot;
			else
				a_chattingMsgData.m_nSendUserId = 100;
			a_chattingMsgData.m_nMsgType = 0;
			a_chattingMsgData.m_strMsgText = getString(R.string.chat_chatbot_default_message).toString();
			a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;

			a_chattingMsgData.m_isRead = true;
			a_chattingMsgData.m_strMsgId = strPacketID;
			a_chattingMsgData.m_lnMsgSendTime = lTime;

			chattingDBMng.insertMessage(a_chattingMsgData);
		}
		chattingDBMng.close();

	}

	// 파일 전송
	public void sendFile(final String strFileName, final Uri a_FileUri, final String strUserName) {
		// TODO Auto-generated method stub
		CommonLog.e(this, "Name : " + strFileName);
		CommonLog.e(this, "Path : " + a_FileUri.getPath());

		PostFileUploadReq req = new PostFileUploadReq(App.m_MyUserInfo.m_nUserNo);
		if (strFileName.equals("")) {
			req.setFileInfo(this, a_FileUri, strFileName, StaticString.FILE_TYPE_VIDEO);
		} else if(!strFileName.equals("") && strUserName != null){
			req.setFileInfo(this, a_FileUri, strFileName, StaticString.FILE_TYPE_CONTACT);
		} else {
			req.setFileInfo(this, a_FileUri, strFileName, StaticString.FILE_TYPE_NORMAL);
		}

		// 전송 시작시 표시
		final long lTime = System.currentTimeMillis();
		ChattingMessageData a_chattingMsgData;
		a_chattingMsgData = new ChattingMessageData();
		a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
		XmppUtils utils = new XmppUtils();
		if (strFileName.equals("")) {
			utils.strFileName = strFileName;
			utils.strMimeType = StaticString.FILE_TYPE_VIDEO;
			utils.strUrl = a_FileUri.toString();
			utils.strCreateTime = "" + lTime;
			utils.strVdi = "false";
			a_chattingMsgData.m_strMsgText = utils.getFileExText();
		} else if(!strFileName.equals("") && strUserName != null){
			utils.strFileName = strUserName;
			utils.strMimeType = StaticString.FILE_TYPE_CONTACT;
			utils.strUrl = a_FileUri.toString();
			utils.strVdi = "false";
			utils.strContactFileName = strFileName;
			a_chattingMsgData.m_strMsgText = utils.getFileExText();
		} else {
			utils.strFileName = strFileName;
			utils.strMimeType = StaticString.FILE_TYPE_NORMAL;
			utils.strUrl = a_FileUri.toString();
			utils.strCreateTime = "" + lTime;
			utils.strVdi = "false";
			a_chattingMsgData.m_strMsgText = utils.getFileExText();
		}
		a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_LOADING;
		a_chattingMsgData.m_isRead = true;
		a_chattingMsgData.m_strMsgId = lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
		a_chattingMsgData.m_lnMsgSendTime = lTime;
		final ArrayList<Integer> arrID = new ArrayList<Integer>();
		arrID.add(0);
		// 아직 전달 되지 않은 메세지 이므로 일은 사람 표시를 하지 않는다.
		// a_chattingMsgData.m_arrReadUser = arrID;
		// a_chattingMsgData.m_arrCurrentUser = arrID;

		ChattingDBManager chattingDBMng = new ChattingDBManager(this);
		chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
		chattingDBMng.insertMessage(a_chattingMsgData);
		chattingDBMng.close();
		m_arrRoomData = new ArrayList<ChatRoomData>();
		// runOnUiThread(new Runnable() {
		// @Override
		// public void run() {
		changeDay(lTime, true);
		if (strFileName.equals("")) {
			setMyFile(StaticString.CHAT_ROOM_MY_FILE, StaticString.CHAT_SEND_STATUS_LOADING, m_strRoomId, 0, lTime, 0,
					lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), utils.getFileExObject());
		} else if(!strFileName.equals("") && strUserName != null){
			setMyFile(StaticString.CHAT_ROOM_MY_FILE, StaticString.CHAT_SEND_STATUS_LOADING, m_strRoomId, 0, lTime,
					0, lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), utils.getFileExObject());
		} else {
			setMyFile(StaticString.CHAT_ROOM_MY_FILE, StaticString.CHAT_SEND_STATUS_LOADING, m_strRoomId, 0, lTime, 0,
					lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), utils.getFileExObject());
		}

		// }
		// });

		// setPrintMessage();

		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// setMyMsg(StaticString.CHAT_ROOM_MY_MESSAGE,
				// StaticString.CHAT_SEND_STATUS_LOADING, m_strThisRoomId, 0,
				// m_strMessage, m_arrRoomUser, m_arrRoomUser,
				// System.currentTimeMillis(), strPacketID);
				m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				m_ChatAdapter.add(m_RoomData);
				m_nAdapterCount += 1;
				m_nScreenMessageCount += 1;
				m_ChatAdapter.notifyDataSetChanged();
			}
		});

		WebAPI webApi = new WebAPI(this);

		webApi.requestUpload(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String strData) {
				// TODO Auto-generated method stub

				final PostFileUploadRes res = new PostFileUploadRes(strData);
				CommonLog.e(ChatRoomAct.this, "Result : " + res.m_strUrl);

				boolean isContacts = false;
				String strName = "";
				if (strUserName != null) {
					isContacts = true;
					strName = strUserName;
				} else {
					strName = strFileName;
				}
				String strPreviewUrl = "";
				if(res.m_strPreviewUrl != null && !res.m_strPreviewUrl.equals("")){
					strPreviewUrl = res.m_strPreviewUrl;
				}
				mService.sendFile(lTime, strName, res.m_strUrl, strPreviewUrl, m_nFriendUserNumber, null, isContacts, "false");

				Handler mHandler = new Handler();
				mHandler.postDelayed(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						ChattingDBManager chattingDBMngMsg = new ChattingDBManager(ChatRoomAct.this);
						chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
						ChattingMessageData chattingData = chattingDBMngMsg.getChattingMessage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));

						if (chattingData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {
							chattingDBMngMsg.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
							setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
							setDataChanged();
						}
						chattingDBMngMsg.close();
					}

				}, 30000);

			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				} else if (a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();

					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_NOT_DEFINED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.zerobite_error).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();

					deleteMessage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
				}
				else {
					CommonLog.e(ChatRoomAct.this, "Error : " + a_strMessage);
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				}
			}
		});
	}

	// 파일 전달
	public void passFileOther(String a_strType, JSONObject jsonObject) {
		// TODO Auto-generated method stub
		try {
			String strFileName = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);
			String strPreviewUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
			String strVdi = jsonObject.getString(StaticString.XMPP_TEXT_VDI);
			String strUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
			// 전송 시작시 표시
			final long lTime = System.currentTimeMillis();
			ChattingMessageData a_chattingMsgData;
			a_chattingMsgData = new ChattingMessageData();
			a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
			String createTime = "";
			if (jsonObject.getString(StaticString.XMPP_TEXT_CREATETIME) != null) {
				createTime = jsonObject.getString(StaticString.XMPP_TEXT_CREATETIME);
			} else {
				createTime = "0";
			}
			XmppUtils utils = new XmppUtils();
			if (a_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
				utils.strFileName = strFileName;
				utils.strMimeType = StaticString.FILE_TYPE_VIDEO;
				utils.strThumb = strPreviewUrl;
				utils.strCreateTime = createTime;
				utils.strUrl = strUrl;
				utils.strVdi = strVdi;
				a_chattingMsgData.m_strMsgText = utils.getFileExText();
			} else if (a_strType.equals(StaticString.FILE_TYPE_CONTACT)) {
				utils.strFileName = strFileName;
				utils.strMimeType = StaticString.FILE_TYPE_CONTACT;
				utils.strUrl = strUrl;
				utils.strVdi = strVdi;
				a_chattingMsgData.m_strMsgText = utils.getFileExText();
			} else {
				utils.strFileName = strFileName;
				utils.strMimeType = StaticString.FILE_TYPE_NORMAL;
				utils.strUrl = strUrl;
				utils.strCreateTime = createTime;
				utils.strVdi = strVdi;
				a_chattingMsgData.m_strMsgText = utils.getFileExText();
			}
			a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_LOADING;
			a_chattingMsgData.m_isRead = true;
			a_chattingMsgData.m_strMsgId = lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
			a_chattingMsgData.m_lnMsgSendTime = lTime;
			final ArrayList<Integer> arrID = new ArrayList<Integer>();
			arrID.add(0);
			// 아직 전달 되지 않은 메세지 이므로 일은 사람 표시를 하지 않는다.
			a_chattingMsgData.m_nNoReadUserCount = 0;

			ChattingDBManager chattingDBMng = new ChattingDBManager(this);
			chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
			chattingDBMng.insertMessage(a_chattingMsgData);
			chattingDBMng.close();
			m_arrRoomData = new ArrayList<ChatRoomData>();
			// runOnUiThread(new Runnable() {
			// @Override
			// public void run() {

			changeDay(lTime, true);
			setMyFile(StaticString.CHAT_ROOM_MY_FILE, StaticString.CHAT_SEND_STATUS_LOADING, m_strRoomId, 0, lTime,
						0, lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), utils.getFileExObject());


			// }
			// });

			// setPrintMessage();
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					// setMyMsg(StaticString.CHAT_ROOM_MY_MESSAGE,
					// StaticString.CHAT_SEND_STATUS_LOADING, m_strThisRoomId, 0,
					// m_strMessage, m_arrRoomUser, m_arrRoomUser,
					// System.currentTimeMillis(), strPacketID);
					m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
					m_ChatAdapter.add(m_RoomData);
					m_nAdapterCount += 1;
					m_nScreenMessageCount += 1;
					m_ChatAdapter.notifyDataSetChanged();
				}
			});
			Handler mHandler = new Handler();
			mHandler.postDelayed(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					ChattingDBManager chattingDBMngMsg = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
					ChattingMessageData chattingData = chattingDBMngMsg.getChattingMessage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));

					if (chattingData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {

						chattingDBMngMsg.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
						setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
						setDataChanged();
					}
					chattingDBMngMsg.close();

				}

			}, 30000);
			boolean isContacts = false;
			if (a_strType.equals(StaticString.FILE_TYPE_CONTACT)) {
				isContacts = true;
			}
			mService.sendFile(lTime, strFileName, strUrl, strPreviewUrl, m_nFriendUserNumber, createTime, isContacts, strVdi);
		} catch (JSONException e){

		}
	}

	// 파일 전송 성공, 혹은 수신 성공 후
	public void printFile(final Packet packet) {
		// runOnUiThread(new Runnable() {
		// @Override
		// public void run() {
		// DelayInformation delay = (DelayInformation)
		// packet.getExtension("x", "jabber:x:delay");
		// changeDay(delay.getStamp().getTime());
		// ArrayList<Integer> arrMyId = new ArrayList<Integer>();
		//
		// // 파일의 이름을 구하기 위해
		// FileEx fileEx = (FileEx)
		// packet.getExtension(FileEx.NAMESPACE);
		// String fileName = fileEx.getFileName();
		// // 임시
		// arrMyId.add(App.m_MyUserInfo.m_nUserNo);
		// // 처음 글을 올리는 순간은 무조건 나만 본것
		//
		// if
		// (packet.getFrom().split("@")[0].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo)))
		// {
		// setMyFile(StaticString.CHAT_ROOM_MY_FILE,
		// StaticString.CHAT_SEND_STATUS_SUCCESS, m_strRoomId, 0,
		// fileName, fileEx.getUrl(), delay.getStamp().getTime(),
		// arrMyId, m_arrThisRoomUser, packet.getPacketID());
		// } else {
		// setOtherFile(StaticString.CHAT_ROOM_OTHER_FILE, m_strRoomId,
		// 0, m_strFriendUserName, fileName, fileEx.getUrl(),
		// delay.getStamp().getTime(), arrMyId, m_arrThisRoomUser,
		// packet.getPacketID(), m_UserData.m_isImageAvailable);
		// }
		// m_ChatAdapter.notifyDataSetChanged();
		printMessage(PRINT_MESSAGE_NOT_SCROLL);
		// }
		// });
	}

	// 이미지 전송
	public void sendImage(final long lTime, final Bitmap a_Bitmap, byte[] a_BitmapByte, final String a_strPath) {

		PostFileUploadReq req = new PostFileUploadReq(App.m_MyUserInfo.m_nUserNo);
		req.setImageFileInfo(a_BitmapByte, a_strPath);

		// 전송 시작시 표시
		ChattingMessageData a_chattingMsgData;
		a_chattingMsgData = new ChattingMessageData();
		a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;

		XmppUtils utils = new XmppUtils();
		utils.strMimeType = StaticString.FILE_TYPE_IMAGE;
		utils.strUrl = a_strPath;
		utils.strWidth = "" + a_Bitmap.getWidth();
		utils.strHeight = "" + a_Bitmap.getHeight();
		utils.strVdi = "false";

		a_chattingMsgData.m_strMsgText = utils.getFileExText();
		a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_LOADING;
		a_chattingMsgData.m_isRead = true;
		a_chattingMsgData.m_strMsgId = lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
		a_chattingMsgData.m_lnMsgSendTime = lTime;
		final ArrayList<Integer> arrID = new ArrayList<Integer>();
		arrID.add(0);
		// 아직 전달 되지 않은 메세지 이므로 일은 사람 표시를 하지 않는다.
		// a_chattingMsgData.m_arrReadUser = arrID;
		// a_chattingMsgData.m_arrCurrentUser = arrID;

		ChattingDBManager chattingDBMng = new ChattingDBManager(this);
		chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
		chattingDBMng.insertMessage(a_chattingMsgData);
		chattingDBMng.close();
		m_arrRoomData = new ArrayList<ChatRoomData>();
		// runOnUiThread(new Runnable() {
		// @Override
		// public void run() {
		changeDay(lTime, true);
		setMyImage(StaticString.CHAT_ROOM_MY_IMAGE, StaticString.CHAT_SEND_STATUS_LOADING, m_strRoomId, 0, lTime, 0, "" + lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), utils.getFileExObject());
		// }
		// });
		// setPrintMessage();

		m_ChatAdapter.add(m_RoomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;

		WebAPI webApi = new WebAPI(this);
		webApi.requestUpload(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String strData) {
				// TODO Auto-generated method stub

				final PostFileUploadRes res = new PostFileUploadRes(strData);
				CommonLog.e(ChatRoomAct.this, "Result : " + res.m_strUrl);

				mService.sendImage(lTime, a_Bitmap, res.m_strUrl, res.m_strPreviewUrl, m_nFriendUserNumber);

				// 전송이 완성되지 않는다면 프로그레스바 표시
				Handler mHandler = new Handler();
				mHandler.postDelayed(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						ChattingDBManager chattingDBMngMsg = new ChattingDBManager(ChatRoomAct.this);
						chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
						ChattingMessageData chattingData = chattingDBMngMsg.getChattingMessage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));

						if (chattingData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {

							chattingDBMngMsg.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
							setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
							setDataChanged();
						}
						chattingDBMngMsg.close();

					}

				}, 60000);
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				} else if (a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();

					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_NOT_DEFINED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.zerobite_error).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();

					deleteMessage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
				}
				else {
					ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
					chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
					chattingDBMng.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					chattingDBMng.close();

					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				}
			}
		});
	}

	// 이미지 전송
	public void passImageOther(final int a_nWidth, final int a_nHeight, final String a_strImageUrl, final String a_strImageThumbUrl) {

		// 전송 시작시 표시
		final long lTime = System.currentTimeMillis();
		ChattingMessageData a_chattingMsgData;
		a_chattingMsgData = new ChattingMessageData();
		a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;

		XmppUtils utils = new XmppUtils();
		utils.strMimeType = StaticString.FILE_TYPE_IMAGE;
		utils.strUrl = a_strImageUrl;
		utils.strWidth = "" + a_nWidth;
		utils.strHeight = "" + a_nHeight;
		utils.strVdi = "false";
		a_chattingMsgData.m_strMsgText = utils.getFileExText();
		a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_LOADING;
		a_chattingMsgData.m_isRead = true;
		a_chattingMsgData.m_strMsgId = lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
		a_chattingMsgData.m_lnMsgSendTime = lTime;
		final ArrayList<Integer> arrID = new ArrayList<Integer>();
		arrID.add(0);
		// 아직 전달 되지 않은 메세지 이므로 일은 사람 표시를 하지 않는다.
		a_chattingMsgData.m_nNoReadUserCount = 0;

		ChattingDBManager chattingDBMng = new ChattingDBManager(this);
		chattingDBMng.openWritable(Integer.toString(m_nFriendUserNumber));
		chattingDBMng.insertMessage(a_chattingMsgData);
		chattingDBMng.close();
		m_arrRoomData = new ArrayList<ChatRoomData>();
		// runOnUiThread(new Runnable() {
		// @Override
		// public void run() {
		changeDay(lTime, true);
		setMyImage(StaticString.CHAT_ROOM_MY_IMAGE, StaticString.CHAT_SEND_STATUS_LOADING, m_strRoomId, 0, lTime, 0, ""
				+ lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), utils.getFileExObject());
		// }
		// });
		// setPrintMessage();
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// setMyMsg(StaticString.CHAT_ROOM_MY_MESSAGE,
				// StaticString.CHAT_SEND_STATUS_LOADING, m_strThisRoomId, 0,
				// m_strMessage, m_arrRoomUser, m_arrRoomUser,
				// System.currentTimeMillis(), strPacketID);
				m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				m_ChatAdapter.add(m_RoomData);
				m_nAdapterCount += 1;
				m_nScreenMessageCount += 1;
				m_ChatAdapter.notifyDataSetChanged();
			}
		});
		Handler mHandler = new Handler();
		mHandler.postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ChattingDBManager chattingDBMngMsg = new ChattingDBManager(ChatRoomAct.this);
				chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
				ChattingMessageData chattingData = chattingDBMngMsg.getChattingMessage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));

				if (chattingData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {
					chattingDBMngMsg.updateSendStatus(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo), StaticString.CHAT_SEND_STATUS_FAIL);
					setFailChage(lTime + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo));
					setDataChanged();
				}
				chattingDBMngMsg.close();
			}

		}, 30000);

		mService.sendImageOther(lTime, a_nWidth, a_nHeight, a_strImageUrl, a_strImageThumbUrl, m_nFriendUserNumber);

	}

	public void sendEmoticon(String strSendMessage){
		final long lTime = System.currentTimeMillis();
		final String strPacketID = Long.toString(lTime) + "_" + App.m_MyUserInfo.m_nUserNo;
		ChattingMessageData a_chattingMsgData;
		a_chattingMsgData = new ChattingMessageData();
		a_chattingMsgData.m_nSendUserId = 0;
		a_chattingMsgData.m_nMsgType = 0;
		a_chattingMsgData.m_strMsgText = strSendMessage;
		if(!m_strCurrentSelectApngEmoticonUrl.equals("") && m_nCurrentSelectPngEmoticonName.equals("")) {
			a_chattingMsgData.m_strEmoticon = m_strCurrentSelectApngEmoticonUrl;
		} else if(m_strCurrentSelectApngEmoticonUrl.equals("") && !m_nCurrentSelectPngEmoticonName.equals("")) {
			a_chattingMsgData.m_strEmoticon = m_nCurrentSelectPngEmoticonName;
		}
		a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_LOADING;

		a_chattingMsgData.m_isRead = true;
		a_chattingMsgData.m_strMsgId = strPacketID;
		a_chattingMsgData.m_lnMsgSendTime = lTime;
		// 아직 전달 되지 않은 메세지 이므로 일은 사람 표시를 하지 않는다.
		// a_chattingMsgData.m_arrReadUser = m_arrThisRoomUser;
		// a_chattingMsgData.m_arrCurrentUser = m_arrThisRoomUser;

		ChattingDBManager chattingDBMngMsg = new ChattingDBManager(this);
		chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
		chattingDBMngMsg.insertMessage(a_chattingMsgData);
		chattingDBMngMsg.close();
		m_arrRoomData = new ArrayList<ChatRoomData>();
		changeDay(lTime, true);
		if(m_strRoomId.equals(String.valueOf(App.m_nChatbot)))
			hideKeyPad(m_etMessage);
		setMyEmoticonMsg(StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE, StaticString.CHAT_SEND_STATUS_LOADING, Integer.toString(m_nFriendUserNumber), 0,
				a_chattingMsgData.m_strMsgText, 0, a_chattingMsgData.m_lnMsgSendTime, a_chattingMsgData.m_strMsgId, a_chattingMsgData.m_strEmoticon,"");
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				m_etMessage.setText("");
				m_btnSend.setBackgroundResource(R.drawable.btn_send_talk);
				m_ChatAdapter.add(m_RoomData);
				m_nAdapterCount += 1;
				m_nScreenMessageCount += 1;
				m_ChatAdapter.notifyDataSetChanged();
			}
		});

		if (m_isFirstRead)
			printMessage(PRINT_MESSAGE_SCROLL);
		Handler mHandler = new Handler();
		mHandler.postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ChattingDBManager chattingDBMngMsg = new ChattingDBManager(ChatRoomAct.this);
				chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
				ChattingMessageData chattingData = chattingDBMngMsg.getChattingMessage(strPacketID);

				if (chattingData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {
					chattingDBMngMsg.updateSendStatus(strPacketID, StaticString.CHAT_SEND_STATUS_FAIL);
					setFailChage(strPacketID);
					setDataChanged();
				}
				chattingDBMngMsg.close();
			}

		}, 30000);
		// if (mService.isConnected()) {


		mService.sendEmoticon(strSendMessage, a_chattingMsgData.m_strEmoticon,m_nFriendUserNumber,strPacketID);
	}

	public void sendMessage(String strSendMessage, boolean isNotice) {

		if (isNotice) {
			m_isNotice = true;
		}
		final long lTime = System.currentTimeMillis();
		final String strPacketID = Long.toString(lTime) + "_" + App.m_MyUserInfo.m_nUserNo;

		ChattingMessageData a_chattingMsgData;
		a_chattingMsgData = new ChattingMessageData();
		a_chattingMsgData.m_nSendUserId = 0;
		a_chattingMsgData.m_nMsgType = 0;
		a_chattingMsgData.m_strMsgText = strSendMessage;
		a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_LOADING;

		a_chattingMsgData.m_isRead = true;
		a_chattingMsgData.m_strMsgId = strPacketID;
		a_chattingMsgData.m_lnMsgSendTime = lTime;
		// 아직 전달 되지 않은 메세지 이므로 일은 사람 표시를 하지 않는다.
		// a_chattingMsgData.m_arrReadUser = m_arrThisRoomUser;
		// a_chattingMsgData.m_arrCurrentUser = m_arrThisRoomUser;

		ChattingDBManager chattingDBMngMsg = new ChattingDBManager(this);
		chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
		chattingDBMngMsg.insertMessage(a_chattingMsgData);
		chattingDBMngMsg.close();
		m_arrRoomData = new ArrayList<ChatRoomData>();
		changeDay(lTime, true);
		if(m_strRoomId.equals(String.valueOf(App.m_nChatbot)))
			hideKeyPad(m_etMessage);
		setMyMsg(StaticString.CHAT_ROOM_MY_MESSAGE, StaticString.CHAT_SEND_STATUS_LOADING, Integer.toString(m_nFriendUserNumber), 0,
				a_chattingMsgData.m_strMsgText, 0, a_chattingMsgData.m_lnMsgSendTime, a_chattingMsgData.m_strMsgId,"");
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				m_etMessage.setText("");
				m_ChatAdapter.add(m_RoomData);
				m_nAdapterCount += 1;
				m_nScreenMessageCount += 1;
				m_ChatAdapter.notifyDataSetChanged();
			}
		});

		if (m_isFirstRead)
			printMessage(PRINT_MESSAGE_SCROLL);
		Handler mHandler = new Handler();
		mHandler.postDelayed(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				ChattingDBManager chattingDBMngMsg = new ChattingDBManager(ChatRoomAct.this);
				chattingDBMngMsg.openWritable(Integer.toString(m_nFriendUserNumber));
				ChattingMessageData chattingData = chattingDBMngMsg.getChattingMessage(strPacketID);

				if (chattingData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {
					chattingDBMngMsg.updateSendStatus(strPacketID, StaticString.CHAT_SEND_STATUS_FAIL);
					setFailChage(strPacketID);
					setDataChanged();
				}
				chattingDBMngMsg.close();
			}

		}, 30000);
		// if (mService.isConnected()) {
		if (m_isNotice) {
			mService.sendUrgentMessage(strSendMessage, m_nFriendUserNumber, strPacketID);
			m_isNotice = false;

		} else {
			mService.sendMessage(strSendMessage, "", m_nFriendUserNumber, strPacketID);
		}

	}

	// 메세지를 보내고 자기 화면에 표시해 주는 부분을 모두 이것으로 대체 계획
	// public void setPrintMessage() {
	//
	// // runOnUiThread(new Runnable() {
	// // @Override
	// // public void run() {
	// // // m_ChatAdapter.notifyDataSetChanged();
	// //
	//
	// printMessage(PRINT_MESSAGE_SCROLL);
	// // }
	// // });
	// }

	@Override
	public void onClick(View v) {
		super.onClick(v);
		// EmoticonUtils utils = new EmoticonUtils();
		switch (v.getId()) {
		case R.id.btn_chat_menu:
			clickMenuButton();
//			String strOriginalName = "ttalk_chatting_" + m_strRoomId + ".db";
//			Utils.processStorageBackup(this, strOriginalName, strOriginalName);
			break;
		case R.id.btn_chat_attach:
			if (m_BottomPager.getVisibility() == View.GONE && m_EmoticonMenu.getVisibility() == View.GONE) {
				// if (m_lvChat.getLastVisiblePosition() == m_lvChat.getCount()
				// - 1)
				// m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
				// else
				m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
				hideKeyPad(m_etMessage);
				m_EmoticonSelelctLayout.setVisibility(View.GONE);
				m_btnEmoticonAdd.setImageResource(R.drawable.btn_emoticon_2);
				TimerTask task = new TimerTask() {

					@Override
					public void run() {
						// TODO Auto-generated method stub

						runOnUiThread(new Runnable() {
							public void run() {
								m_BottomPager.setVisibility(View.VISIBLE);
								if(AppSetting.FEATURE_VARIANT.equals("R")){
									m_ChatMenuIconLayout.setVisibility(View.VISIBLE);
									m_ChatMenuIconLayout.setVisibility(View.GONE);
								}
								m_btnAttach.setImageResource(R.drawable.btn_file_close);
								m_EmoticonMenu.setVisibility(View.GONE);
							}
						});

					}
				};

				Timer mTimer = new Timer();
				mTimer.schedule(task, 500);

			} else if (m_EmoticonMenu.getVisibility() == View.VISIBLE) {
				m_EmoticonMenu.setVisibility(View.GONE);
				m_BottomPager.setVisibility(View.GONE);
				m_ChatMenuIconLayout.setVisibility(View.GONE);
				m_btnAttach.setImageResource(R.drawable.btn_file_add);
				InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
				imm.showSoftInput(m_etMessage, 0);
			} else {
				m_BottomPager.setVisibility(View.GONE);
				m_ChatMenuIconLayout.setVisibility(View.GONE);
				m_btnAttach.setImageResource(R.drawable.btn_file_add);
			}
			break;
			case R.id.btn_emoticon_add:
				m_BottomPager.setVisibility(View.GONE);
				m_ChatMenuIconLayout.setVisibility(View.GONE);
				m_EmoticonMenu.setVisibility(View.GONE);
				m_btnAttach.setImageResource(R.drawable.btn_file_add);
				if(m_EmoticonSelelctLayout.getVisibility() == View.GONE) {

					m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
					hideKeyPad(m_etMessage);
					TimerTask task = new TimerTask() {

						@Override
						public void run() {
							// TODO Auto-generated method stub

							runOnUiThread(new Runnable() {
								public void run() {
									m_btnEmoticonAdd.setImageResource(R.drawable.btn_emoticon_2_selected);
									if(m_nSelect == 0) {
										m_layout_indicator.setVisibility(View.GONE);
										m_vpEmoticonPager.setVisibility(View.GONE);
										m_layout_basic_emoticon.setVisibility(View.VISIBLE);
									}
								    m_EmoticonSelelctLayout.setVisibility(View.VISIBLE);
								}
							});

						}
					};

					Timer mTimer = new Timer();
					mTimer.schedule(task, 500);
				} else {
					m_btnEmoticonAdd.setImageResource(R.drawable.btn_emoticon_2);
					m_EmoticonSelelctLayout.setVisibility(View.GONE);
					if(m_etMessage.length() > 0){
						showSoftkeyboard(m_etMessage);
					}
				}
				break;

			case R.id.iv_add_emoticon_close:
				LinearLayout innerlayout = (LinearLayout) findViewById(R.id.layout_chat_room_emoticon_display);
				innerlayout.setVisibility(View.GONE);
				break;

			case R.id.btn_chat_send:

			// TODO Auto-generated method stub
			m_strMessage = m_etMessage.getText().toString();

			String strRemoveEnter = m_strMessage.replace("\n", "");
			String strRemoveSpace = strRemoveEnter.replace(" ", "");
			if (m_strMessage.isEmpty() || m_strMessage.equals("") || strRemoveSpace.equals("")) {
				if(m_EmoticonContainer.getVisibility() == View.VISIBLE){
					sendEmoticon(m_strMessage);
				} else {

				}
			} else {
				if(m_EmoticonContainer.getVisibility() == View.VISIBLE)
					sendEmoticon(m_strMessage);
				else
					sendMessage(m_strMessage, false);
			}
				m_EmoticonContainer.setVisibility(View.GONE);
				m_ivEmoticonDisplay.setImageBitmap(null);
			break;
		case R.id.layout_draw_chat_room_invite:
			if (m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
				m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
			}
			App.m_arrRoomUserList = m_arrThisRoomUser;
			Intent intentInvite = new Intent(ChatRoomAct.this, ChatInviteTabAct.class);
			intentInvite.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, m_arrThisRoomUser);
			intentInvite.putExtra(IntentKeyString.INTENT_KEY_INVITE, true);
			intentInvite.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_strRoomId);
			startActivityForResult(intentInvite, REQUEST_CODE_INVITE);
			break;
		case R.id.tv_draw_chat_room_exit:
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_SEND_EXIT);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_exit_room_title), getString(R.string.popup_exit_room_text));
			m_Popup.setCancelable(false);
			isCheckShowPopup();

			break;
		case R.id.layout_draw_chat_room_member:
			if (m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
				m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
			}
			Intent intentMember = new Intent(ChatRoomAct.this, ChatRoomMemberAct.class);
			intentMember.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, m_arrThisRoomUser);
			intentMember.putExtra(IntentKeyString.INTENT_KEY_OWNERNO, 0);
			startActivity(intentMember);
			break;

		case R.id.layout_draw_chat_room_filebox:
			if (m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
				m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
			}
			Intent intentFileBox = new Intent(ChatRoomAct.this, FileBoxAct.class);
			intentFileBox.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPFILEBOX_CHATROOMID, m_strRoomId);
			startActivity(intentFileBox);
			break;

		case R.id.layout_draw_chat_room_delete:
			if (m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
				m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
			}
			m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_CLEARROOM);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_clear_room_title), getString(R.string.popup_clear_room_text));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
			break;
		case R.id.ib_pop_ok_long:
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE) {
				popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			} else {
				if (popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_LIMIT_SIZE) {
					popup_ok_long.cancel();
				} else if (popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE) {
					popup_ok_long.cancel();
				} else {
					popup_ok_long.cancel();
				}
			}
			break;
		case R.id.ib_pop_ok:
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_CLEARROOM) {
				showProgress();
				mService.clearRoom(m_nFriendUserNumber);
				popup_ok.cancel();
			} else if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SEND_MOVIE) {
				m_TakeMedia = new TakeMediaIntent(this);
				m_TakeMedia.doGetVideoFromAlbum();
				popup_ok.cancel();
				SharedPref pref = SharedPref.getInstance(this);
				pref.setBooleanPref(SharedPref.PREF_DOWNLOAD_POPUP, false);
			} else if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SEND_FILE) {
				Intent multiSelector = new Intent(this,FileMultiSelectorAct.class);
				multiSelector.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILECOUNT, 10);
				multiSelector.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILEMAXSIZE, 104857600L);
				startActivityForResult(multiSelector,TakeMediaIntent.REQUESTCODE_FILE);
				popup_ok.cancel();
				SharedPref pref = SharedPref.getInstance(this);
				pref.setBooleanPref(SharedPref.PREF_DOWNLOAD_POPUP, false);
			} else if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SEND_URGENT) {
				m_isNotice = true;

				popup_ok.cancel();
			} else if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SEND_EXIT) {
				/*PostOneRoomSyncReq req = new PostOneRoomSyncReq(m_strRoomId);
				WebAPI webApi = new WebAPI(this);
				webApi.request(req, new WebListener() {

					@Override
					public void onPreRequest() {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void onNetworkError(int nErrorCode, String strMessage) {
						// TODO Auto-generated method stub
						m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}

					@Override
					public void onPostRequest(String a_strData) {
						// TODO Auto-generated method stub
						RoomDBManager.deleteRoom(ChatRoomAct.this, m_strRoomId);
						App.m_isRoomDelete = true;
						ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
						chattingDBMng.openWritable(m_strRoomId);
						chattingDBMng.deleteChattingMessage();
						chattingDBMng.close();
						finish();
					}
					
				});*/
				RoomDBManager.deleteRoom(ChatRoomAct.this, m_strRoomId);
				App.m_isRoomDelete = true;
				ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
				chattingDBMng.openWritable(m_strRoomId);
				chattingDBMng.deleteChattingMessage();
				chattingDBMng.close();
				finish();
				popup_ok.cancel();
			} else if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_NOT_USE) {
				popup_ok.cancel();
				PostRecommendReq req = new PostRecommendReq(m_arrUserID);
				WebAPI webApi = new WebAPI(this);
				webApi.request(req, new WebListener() {

					@Override
					public void onPreRequest() {
						// TODO Auto-generated method stub

					}

					@Override
					public void onPostRequest(String a_strData) {
						// TODO Auto-generated method stub
						m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.profile_recommand_success).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}

					@Override
					public void onNetworkError(int a_nErrorCode, String a_strMessage) {
						// TODO Auto-generated method stub
						if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
									PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED){
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
									PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
						else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
									PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
								m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						} else if (a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						} else {
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
					}
				});
			}
			break;
		case R.id.ib_pop_cancel:
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			break;
		case R.id.btn_chat_send_picture:
			m_TakeMedia = new TakeMediaIntent(this);
			//m_TakeMedia.doGetImageFromAlbum();
			m_TakeMedia.doGetMultiSelectImageFromGallery(GalleryMultiselectorListAct.FROMACTIVITY_CHATTING, ATTACH_FILE_MAX_COUNT, ATTACH_FILE_MAX_SIZE);
			break;
		case R.id.iv_chat_back:
			onBackPressed();
			break;
		case R.id.layout_draw_chat_room_alarm:
			if (m_layoutDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
				m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
			}
			Intent intent = new Intent(ChatRoomAct.this, ChatRoomAlarmSetAct.class);
			intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID,m_strRoomId);
			intent.putExtra(IntentKeyString.INTENT_KEY_ISALARM_ON, m_isAlarm);
			startActivityForResult(intent, REQUEST_CODE_ALARM);
//			if(!m_isRunningTestSend3000MessageTask)
//			{
//				TestSend3000MessageTask task = new TestSend3000MessageTask();
//				task.execute();
//			}
			// for (int i = 1; i < 101; i++){
			//
			// sendMessage("" + i + "번째 메세지", false);
			// try {
			// Thread.sleep(100);
			// } catch (InterruptedException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// }
			break;
		 case R.id.btn_chat_send_file:
		 case R.id.btn_chat_send_file_partner:
		
		 SharedPref prefF = SharedPref.getInstance(this);
		 	boolean isFileDataPopup =
		 			prefF.getBooleanPref(SharedPref.PREF_DOWNLOAD_POPUP, true);
		 if (isFileDataPopup) {
			m_Popup = new CommonPopup(this, this,
					 CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_SEND_FILE);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_data_title),
					 getString(R.string.popup_data_file_text));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		 } else {
			Intent multiSelector = new Intent(this,FileMultiSelectorAct.class);
			multiSelector.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILECOUNT, 10);
			multiSelector.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILEMAXSIZE, 104857600L);
			startActivityForResult(multiSelector,TakeMediaIntent.REQUESTCODE_FILE);
		 }
		 break;
		case R.id.btn_chat_send_video:
			SharedPref prefV = SharedPref.getInstance(this);
			boolean isVideoPopup = prefV.getBooleanPref(SharedPref.PREF_DOWNLOAD_POPUP, true);
			if (isVideoPopup) {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_SEND_MOVIE);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_data_title), getString(R.string.popup_data_video_text));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_TakeMedia = new TakeMediaIntent(this);
				m_TakeMedia.doGetVideoFromAlbum();
			}

			break;
		case R.id.btn_chat_send_camera:
			m_TakeMedia = new TakeMediaIntent(this);
			m_TakeMedia.doTakeImageFromCamera();
			break;
	/*	case R.id.btn_chat_send_emoticon:
		case R.id.btn_chat_send_emoticon_partner:*/
			/*m_btnAttach.setImageResource(R.drawable.btn_btn_attach_close);*/
		/*	m_ChatMenuIconLayout.setVisibility(View.GONE);
			m_BottomPager.setVisibility(View.GONE);
			m_EmoticonMenu.setVisibility(View.VISIBLE);
			break;*/
		case R.id.btn_chat_send_contacts:
		case R.id.btn_chat_send_contacts_partner:
			startPickContacts();
			break;
		case R.id.layout_chat_room_urgent:
		case R.id.tv_chat_room_urgent:
			if (m_UrgentMessageClose.getVisibility() == View.VISIBLE) {
				m_UrgentMessageClose.setVisibility(View.GONE);
				m_tvUrgentMessage.setSingleLine(true);
				m_tvUrgentMessage.setMovementMethod(null);
				CustomLinkify.addLinks(m_tvUrgentMessage, CustomLinkify.ALL);
			} else {
				m_UrgentMessageClose.setVisibility(View.VISIBLE);
				m_tvUrgentMessage.setSingleLine(false);
				m_tvUrgentMessage.setMaxLines(5);
				m_tvUrgentMessage.setMovementMethod(new ScrollingMovementMethod());
				CustomLinkify.addLinks(m_tvUrgentMessage, CustomLinkify.ALL);
			}
			break;
		case R.id.layout_chat_room_urgent_close:
			m_UrgentMessageClose.setVisibility(View.GONE);
			m_UrgentMessage.setVisibility(View.GONE);
			ChattingDBManager chattingDBMngFindUrgent = new ChattingDBManager(this);
			chattingDBMngFindUrgent.openWritable(m_strRoomId);
			ArrayList<ChattingMessageData> findUrgentData = chattingDBMngFindUrgent.getChattingMessage();

			for (ChattingMessageData data : findUrgentData) {
				if (data.m_nMsgType == StaticString.CHAT_ROOM_URGENT_MESSAGE) {
					// chattingDBMngFindUrgent.deleteChattingMessage(data.m_strMsgId);
					data.m_nMsgType = 0;
					chattingDBMngFindUrgent.updateChattingMessage(data);
					// break;
				}
			}
			chattingDBMngFindUrgent.close();
			printMessage(PRINT_MESSAGE_SCROLL);
			break;
		case R.id.layout_chat_room_new_message_bottom:
			m_lvChat.setSelection(m_nScreenMessageCount);
			m_NewMessage.setVisibility(View.GONE);
			break;

		case R.id.ib_chat_input_e1_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_01));
			break;
		case R.id.ib_chat_input_e2_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_02));

			break;
		case R.id.ib_chat_input_e3_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_03));

			break;
		case R.id.ib_chat_input_e4_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_04));
			break;
		case R.id.ib_chat_input_e5_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_05));
			break;
		case R.id.ib_chat_input_e6_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_06));
			break;
		case R.id.ib_chat_input_e7_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_07));
			break;
		case R.id.ib_chat_input_e8_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_08));
			break;
		case R.id.ib_chat_input_e9_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_09));
			break;
		case R.id.ib_chat_input_e10_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_10));
			break;
		case R.id.ib_chat_input_e11_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_11));
			break;
		case R.id.ib_chat_input_e12_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_12));
			break;
		case R.id.ib_chat_input_e13_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_13));
			break;
		case R.id.ib_chat_input_e14_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_14));
			break;
		case R.id.ib_chat_input_e15_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_15));
			break;
		case R.id.ib_chat_input_e16_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_16));
			break;
		case R.id.ib_chat_input_e17_2:
			EmoticonUtils.inputEmoticonText(m_etMessage, getString(R.string.emoticon_17));
			break;
		case R.id.ib_chat_input_e_delete_2:
			clickEmoticonDelete();
			break;
			case R.id.iv_chat_search_cancel:
				m_ChatSearch.setVisibility(View.GONE);
				m_ChatTitle.setVisibility(View.VISIBLE);
				m_BottomSearch.setVisibility(View.GONE);
				m_BottomTotal.setVisibility(View.VISIBLE);
				m_strBounceID = "";
				m_nNowSearchingIndex = -1;
				m_strSearchWord = "";
				printMessage(PRINT_MESSAGE_NOT_SCROLL);
				m_ivSearchUP.setImageResource(R.drawable.btn_search_up_off);
				m_ivSearchDown.setImageResource(R.drawable.btn_search_down_off);
				break;
			case R.id.iv_chat_search:
				m_etSearch.setText("");
				m_ChatSearch.setVisibility(View.VISIBLE);
				m_ChatTitle.setVisibility(View.GONE);
				m_BottomTotal.setVisibility(View.GONE);
				m_layoutDrawerLayout.closeDrawer(Gravity.RIGHT);
				m_EmoticonContainer.setVisibility(View.GONE);
				m_ivEmoticonDisplay.setImageBitmap(null);
				m_EmoticonMenu.setVisibility(View.GONE);
				m_BottomPager.setVisibility(View.GONE);
				m_ChatMenuIconLayout.setVisibility(View.GONE);
				m_btnAttach.setImageResource(R.drawable.btn_file_add);
				m_EmoticonSelelctLayout.setVisibility(View.GONE);
				m_btnEmoticonAdd.setImageResource(R.drawable.btn_emoticon_2);
				Handler mHandler = new Handler();
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						m_etSearch.requestFocus();
						m_BottomSearch.setVisibility(View.VISIBLE);
						/*m_ivSearchUP.setOnClickListener(null);
						m_ivSearchDown.setOnClickListener(null);*/
						showSoftkeyboard(m_etSearch);
					}
				}, 100);
				break;
			case R.id.iv_search_up:
				if(m_arrSearchOrder.size() > 1) {
					if (!m_isSearchUpEnd) {
						m_isSearchDownEnd = false;
						m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);
						if (m_nNowSearchingIndex + 1 != m_arrSearchOrder.size()) {
							m_nNowSearchingIndex++;
							if (m_lvChat.getChildCount() < m_arrSearchOrder.get(m_nNowSearchingIndex)) {
								m_nBeforeListViewItemCount = m_nScreenMessageCount;
								m_nScreenMessageCount = m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex) + 30;
								if (m_nScreenMessageCount > m_arrChattingMessageData.size()) {
									m_nScreenMessageCount = m_arrChattingMessageData.size();
								}
								printMessage(PRINT_MESSAGE_PAGING);
							}
				/*	m_nBouncePosition = m_nScreenMessageCount - (m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex)) + 1;*/
							m_strBounceID = m_arrSearchID.get(m_nNowSearchingIndex);
							m_ChatAdapter.notifyDataSetChanged();

							m_lvChat.postDelayed(new Runnable() {
								@Override
								public void run() {
									m_lvChat.setSelection(m_nScreenMessageCount - (m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex)));
								}
							}, 100);

							m_ivSearchUP.setImageResource(R.drawable.btn_search_up_on);
							m_ivSearchDown.setImageResource(R.drawable.btn_search_down_on);


						} else {
							m_ivSearchUP.setImageResource(R.drawable.btn_search_up_off);
							m_isSearchUpEnd = true;
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_search_not_found));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
					}
				}
				break;
			case R.id.iv_search_down:
				if(m_arrSearchOrder.size() > 1) {
					if (!m_isSearchDownEnd) {
						m_isSearchUpEnd = false;
						m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_DISABLED);
						if (m_nNowSearchingIndex != 0) {
							m_nNowSearchingIndex--;
				/*	m_nBouncePosition = m_nScreenMessageCount - (m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex)) + 1;*/
							m_strBounceID = m_arrSearchID.get(m_nNowSearchingIndex);
							m_ChatAdapter.notifyDataSetChanged();

							m_lvChat.postDelayed(new Runnable() {
								@Override
								public void run() {
									m_lvChat.setSelection(m_nScreenMessageCount - (m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex)));

								}
							}, 100);

							m_ivSearchUP.setImageResource(R.drawable.btn_search_up_on);
							m_ivSearchDown.setImageResource(R.drawable.btn_search_down_on);
						} else {
							m_ivSearchDown.setImageResource(R.drawable.btn_search_down_off);
							m_isSearchDownEnd = true;
							m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
							m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_search_not_found));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}
					}
				}
				break;

			default:
			break;
		}
	}

	// 이모티콘 삭제 클릭 처리
	private void clickEmoticonDelete() {
		int nSelStart = m_etMessage.getSelectionStart();
		int nSelEnd = m_etMessage.getSelectionEnd();
		String strMesseage = m_etMessage.getText().toString();
		if (nSelStart == 0) {
			return;
		}

		String strSelStart = "" + strMesseage.charAt(nSelStart - 1);
		String strSelStart2 = "";

		if (nSelStart >= 4)
			strSelStart2 = "" + strMesseage.charAt(nSelStart - 4); // start
																	// 커서위치의 앞의
																	// 4번쨰가 ( 인자
																	// 확인 용도

		String strNewMessage;
		int nDeleteCharSize = 0;

		if (nSelStart < 4 || !strSelStart2.equals("(") || !strSelStart.equals(")") || nSelStart != nSelEnd) {
			// 1 : 시작커서위치가 4보다 작으면 이모티콘 아님.
			// 2 : 시작커서위치 4글자 앞의 Char가 '(' 아니면 이모티콘이라고 판단하지 않음
			// 3 : 시작커서위치 앞의 Char가 ')' 아니면 이모티콘이라고 판단하지 않음
			// 4 : 시작 커서 위치와 마지막 커서 위치가 틀리면 블럭 삭제라고 판단
			if (nSelStart == nSelEnd)
				// 앞 문자 삭제
				strNewMessage = strMesseage.substring(0, nSelStart - 1) + strMesseage.substring(nSelEnd, strMesseage.length());
			else
				// 블럭 삭제
				strNewMessage = strMesseage.substring(0, nSelStart) + strMesseage.substring(nSelEnd, strMesseage.length());

			nDeleteCharSize = nSelStart - 1;

		} else {
			// 이모티콘 삭제
			strNewMessage = strMesseage.substring(0, nSelStart - 4) + strMesseage.substring(nSelEnd, strMesseage.length());
			nDeleteCharSize = nSelStart - 4;
		}

		m_etMessage.setText(strNewMessage);
		m_etMessage.setSelection(nDeleteCharSize);
	}

	// 단말 DB에 해당 사용자 정보가 없을때
	private void requestAddedByUserList(int nUserID) {
		showProgress();
		int[] nSelects = new int[1];
		nSelects[0] = nUserID;
		GetUserInfoReq req = new GetUserInfoReq(nSelects);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);
				UserListData getItem = res.getUserListData().get(0);
				closeProgress();
				if (getItem != null)
					ContactsDBManager.insertContacts(ChatRoomAct.this, getItem);

				m_UserData = TTalkDBManager.ContactsDBManager.getContacts(ChatRoomAct.this, m_nFriendUserNumber);
				setInfo();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {

				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED){
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	int st_index;
	int et_index;
	Spannable span;
	Bitmap bm;
	int nSize;
	Bitmap bmpResize;


	private void showSoftkeyboard(EditText a_etText) {
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.showSoftInput(a_etText, 0);
	}

	private void hideKeyPad(EditText a_etText) {
		InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(a_etText.getWindowToken(), 0);
	}

	private void messageADD(final ChatRoomData roomData) {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				m_ChatAdapter.add(roomData);
				m_ChatAdapter.notifyDataSetChanged();
			}
		});

	}

	private void setSystemMsg(int aType, String aSystemMSG) {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_strRoomID = m_strRoomID;
		m_RoomData.m_nType = aType;
		m_RoomData.m_strSystemMSG = aSystemMSG;
		m_arrRoomData.add(m_RoomData);
	}

	private void setSystemMsgAdd(int a_nType, String a_strSystemMSG) {
		ChatRoomData roomData = new ChatRoomData();
		roomData.m_strRoomID = m_strRoomID;
		roomData.m_nType = a_nType;
		roomData.m_strSystemMSG = a_strSystemMSG;

		final ChatRoomData finalRoomData = roomData;
		messageADD(finalRoomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;
	}
	
	private void setSystemMsgAddDate(int a_nType, String a_strSystemMSG) {
		ChatRoomData roomData = new ChatRoomData();
		roomData.m_strRoomID = m_strRoomID;
		roomData.m_nType = a_nType;
		roomData.m_strSystemMSG = a_strSystemMSG;

		m_ChatAdapter.add(roomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;
	}

	private void setOtherMsg(int a_nType, int a_nNumber, String a_strRoomID, String a_strName,String a_strSenderType ,String a_strOtherMSG, int a_nNoReadCount, long m_lSendTime,
			String a_strMessageID, boolean a_isAvailable, boolean a_isSmileView,String a_strEmoticonName,String a_strSearchText) {
		m_RoomData = new ChatRoomData();
		if(m_strRoomId.equals(""+App.m_nChatbot)) {
			m_RoomData.m_nType = StaticString.CHAT_ROOM_TINI_MESSAGE;
			m_RoomData.m_EmoticonName = a_strEmoticonName;
			ChattingSelectDBManager dbMng = new ChattingSelectDBManager(ChatRoomAct.this);
			dbMng.openWritable();
			HashMap<String, String> tiniSelectList = dbMng.getSelectList(a_strMessageID);
			dbMng.close();
			String strSelectList = tiniSelectList.get(a_strMessageID);
			if (strSelectList != null){
				try {
					JSONArray jsonArray = new JSONArray(strSelectList);
					String realSelectList = jsonArray.get(0).toString();
					String[] pairs = realSelectList.split(",");
					for (int j = 0; j < pairs.length; j++) {
						String pair = pairs[j];
						String[] keyValue = pair.split("=");
						if (keyValue[0].contains("{"))
							m_RoomData.m_tiniSelectItem.add(keyValue[0].replace("{", ""));
						else
							m_RoomData.m_tiniSelectItem.add(keyValue[0].replace("}", ""));

					}
				} catch (JSONException e) {
					e.printStackTrace();
				} finally {

				}
			}else {
				m_RoomData.m_tiniSelectItem.clear();
			}
		}
		else
			m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_strName = a_strName;
		m_RoomData.m_strSenderType = a_strSenderType;
		m_RoomData.m_strOtherMSG = a_strOtherMSG;
		m_RoomData.m_lDate = m_lSendTime;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_strMessageID = a_strMessageID;
		m_RoomData.m_isImageAvailable = a_isAvailable;
		m_RoomData.m_isSmileView = a_isSmileView;
		m_RoomData.m_strSearchText = a_strSearchText;
		m_arrRoomData.add(m_RoomData);
	}

	private void setOtherMsgAdd(int a_nType, int a_nNumber, String a_strRoomID, String a_strName,String a_strSenderType,String a_strOtherMSG, int a_nNoReadCount, long a_lSendTime,
			String a_strMessageID, boolean isAvailable, boolean a_isSmileView,String a_strEmoticonName) {
		ChatRoomData roomData = new ChatRoomData();
		if(m_strRoomId.equals(""+App.m_nChatbot)) {
			roomData.m_nType = StaticString.CHAT_ROOM_TINI_MESSAGE;
			ChattingSelectDBManager dbMng = new ChattingSelectDBManager(ChatRoomAct.this);
			dbMng.openWritable();
			HashMap<String,String> tiniSelectList = dbMng.getSelectList(a_strMessageID);
			String strSelectList = tiniSelectList.get(a_strMessageID);
			try {
				JSONArray jsonArray = new JSONArray(strSelectList);
				String realSelectList = jsonArray.get(0).toString();
				String[] pairs = realSelectList.split(",");
				for(int j=0;j<pairs.length;j++){
					String pair = pairs[j];
					String[] keyValue = pair.split("=");
					if(keyValue[0].contains("{"))
						roomData.m_tiniSelectItem.add(keyValue[0].replace("{",""));
					else
						roomData.m_tiniSelectItem.add(keyValue[0].replace("}",""));

				}
			} catch (JSONException e) {
				e.printStackTrace();
			}finally {
				dbMng.close();
			}

		}
		else
			roomData.m_nType = a_nType;
		roomData.m_nNO = a_nNumber;
		roomData.m_strRoomID = a_strRoomID;
		roomData.m_strName = a_strName;
		roomData.m_strSenderType = a_strSenderType;
		roomData.m_strOtherMSG = a_strOtherMSG;
		roomData.m_lDate = a_lSendTime;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		roomData.m_nNoReadCount = a_nNoReadCount;
		roomData.m_strMessageID = a_strMessageID;
		roomData.m_isImageAvailable = isAvailable;
		roomData.m_isSmileView = a_isSmileView;
		roomData.m_EmoticonName = a_strEmoticonName;
		final ChatRoomData finalRoomData = roomData;
		messageADD(finalRoomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;
	}
	private void setMyEmoticonMsg(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strMyMSG, int a_nNoReadCount, long a_lSendTime,
								  String a_strPacketID,String a_strEmoticon,String a_strSearchText){

		m_RoomData = new ChatRoomData();
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyMSG = a_strMyMSG;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_lDate = a_lSendTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_EmoticonName = a_strEmoticon;
		m_RoomData.m_strSearchText = a_strSearchText;
		m_arrRoomData.add(m_RoomData);
	}

	private void setMyEmoticonMsgAdd(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strMyMSG, int a_nNoReadCount, long a_lSendTime,
								  String a_strPacketID,String a_strEmoticon){
		m_RoomData = new ChatRoomData();
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyMSG = a_strMyMSG;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_lDate = a_lSendTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_EmoticonName = a_strEmoticon;
		m_ChatAdapter.setMyMessageChange(m_RoomData);
	}

	private void setMyMsg(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strMyMSG, int a_nNoReadCount, long a_lSendTime,
			String a_strPacketID,String a_strSearchText) {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyMSG = a_strMyMSG;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_lDate = a_lSendTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_strSearchText = a_strSearchText;
		m_arrRoomData.add(m_RoomData);
	}

	private void setMyMsgAdd(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strMyMSG, int a_nNoReadCount, long a_lSendTime,
			String a_strPacketID) {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_strMyMSG = a_strMyMSG;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_lDate = a_lSendTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_ChatAdapter.setMyMessageChange(m_RoomData);
	}

	private void setMyImage(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, long a_lTime, int a_nNoReadCount, String a_strPacketID, JSONObject jsonObject) {
		try {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyImageUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		m_RoomData.m_nWidht = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_WIDTH));
		m_RoomData.m_nHeight = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_HEIGHT));
		m_RoomData.m_strMyImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_JsonObject = jsonObject;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_arrRoomData.add(m_RoomData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setMyImageAdd(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, long a_lTime, int a_nNoReadCount, String a_strPacketID, JSONObject jsonObject) {
		try {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyImageUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		m_RoomData.m_nWidht = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_WIDTH));
		m_RoomData.m_nHeight = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_HEIGHT));
		m_RoomData.m_strMyImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_JsonObject = jsonObject;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_ChatAdapter.setMyDataChange(m_RoomData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setOtherImage(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strOtherName,String a_strSenderType,
							   long a_lTime, int a_nNoReadCount, String a_strPacketID, boolean a_isAvailable, boolean a_isSmileView, JSONObject jsonObject) {
		try {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strName = a_strOtherName;
		m_RoomData.m_strSenderType = a_strSenderType;
		m_RoomData.m_strOtherImageUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		m_RoomData.m_nWidht = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_WIDTH));
		m_RoomData.m_nHeight = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_HEIGHT));
		m_RoomData.m_strOtherImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_isImageAvailable = a_isAvailable;
		m_RoomData.m_isSmileView = a_isSmileView;
		m_RoomData.m_JsonObject = jsonObject;
		m_arrRoomData.add(m_RoomData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	private void setOtherEmoticonMsg(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strOtherName,String a_strSenderType, String a_OtherEmoticon, String a_OtherMsg,
									 long a_lTime, int a_nNoReadCount, String a_strPacketID, boolean a_isAvailable, boolean a_isSmileView,String a_strSearchText){
		
		m_RoomData = new ChatRoomData();
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strName = a_strOtherName;
		m_RoomData.m_strSenderType = a_strSenderType;
		m_RoomData.m_EmoticonName = a_OtherEmoticon;
		m_RoomData.m_strOtherMSG = a_OtherMsg;
		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_strSearchText = a_strSearchText;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_isImageAvailable = a_isAvailable;
		m_RoomData.m_isSmileView = a_isSmileView;
		m_arrRoomData.add(m_RoomData);
	}

	private void setOtherEmoticonMsgAdd(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strOtherName,String a_strSenderType , String a_OtherEmoticon, String a_OtherMsg,
										long a_lTime, int a_nNoReadCount, String a_strPacketID, boolean a_isAvailable, boolean a_isSmileView){
		ChatRoomData roomData = new ChatRoomData();
		roomData.m_strRoomID = a_strRoomID;
		roomData.m_nSendStatus = a_nSendStatus;
		roomData.m_nType = a_nType;
		roomData.m_nNO = a_nNumber;
		roomData.m_strName = a_strOtherName;
		roomData.m_strSenderType = a_strSenderType;
		roomData.m_strOtherMSG = a_OtherMsg;
		roomData.m_EmoticonName = a_OtherEmoticon;
		roomData.m_lDate = a_lTime;
		roomData.m_strMessageID = a_strPacketID;
		roomData.m_nNoReadCount = a_nNoReadCount;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		roomData.m_isImageAvailable = a_isAvailable;
		roomData.m_isSmileView = a_isSmileView;
		final ChatRoomData finalRoomData = roomData;
		messageADD(finalRoomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;
	}

	private void setOtherImageAdd(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, String a_strOtherName,String a_strSenderType,
								  long a_lTime, int a_nNoReadCount, String a_strPacketID, boolean a_isAvailable, boolean a_isSmileView, JSONObject jsonObject) {
		try {
		ChatRoomData roomData = new ChatRoomData();
		roomData.m_strRoomID = a_strRoomID;
		roomData.m_nSendStatus = a_nSendStatus;
		roomData.m_nType = a_nType;
		roomData.m_nNO = a_nNumber;
		roomData.m_strName = a_strOtherName;
		roomData.m_strSenderType = a_strSenderType;
		roomData.m_strOtherImageUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		roomData.m_nWidht = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_WIDTH));
		roomData.m_nHeight = Integer.parseInt(jsonObject.getString(StaticString.XMPP_TEXT_HEIGHT));
		roomData.m_strOtherImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
		roomData.m_lDate = a_lTime;
		roomData.m_strMessageID = a_strPacketID;
		roomData.m_nNoReadCount = a_nNoReadCount;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		roomData.m_isImageAvailable = a_isAvailable;
		roomData.m_isSmileView = a_isSmileView;
		roomData.m_JsonObject = jsonObject;
		final ChatRoomData finalRoomData = roomData;
		messageADD(finalRoomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setOtherFile(int a_nType, String a_strRoomID, int a_nNumber, String a_strOtherName,
							  String a_strSenderType, long a_lTime, int a_nNoReadCount, String a_strPacketID, boolean a_isAvailable, boolean a_isSmileView, JSONObject jsonObject) {
		try {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strName = a_strOtherName;
		m_RoomData.m_strOtherMSG = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);
		if(jsonObject.getString(StaticString.XMPP_TEXT_FILENAME).contains(m_strSearchWord)){
			m_RoomData.m_strSearchText = m_strSearchWord;
		}
		m_RoomData.m_strSenderType = a_strSenderType;
		m_RoomData.m_strMimetype = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
		m_RoomData.m_strOtherFile = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		m_RoomData.m_strOtherImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);

		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_RoomData.m_isImageAvailable = a_isAvailable;
		m_RoomData.m_isSmileView = a_isSmileView;
		m_RoomData.m_lCreateTime = Long.parseLong(jsonObject.getString(StaticString.XMPP_TEXT_CREATETIME));
		m_RoomData.m_strCloudUrl = jsonObject.getString(StaticString.XMPP_TEXT_DOCID);
		m_RoomData.m_strVdi = jsonObject.getString(StaticString.XMPP_TEXT_VDI);
		m_RoomData.m_JsonObject = jsonObject;
		m_arrRoomData.add(m_RoomData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setOtherFileAdd(int a_nType, String a_strRoomID, int a_nNumber, String a_strOtherName,
								 String a_strSenderType, long a_lTime, int a_nNoReadCount, String a_strPacketID, boolean a_isAvailable, boolean a_isSmileView, JSONObject jsonObject) {
		ChatRoomData roomData = new ChatRoomData();
		try {
		roomData.m_strRoomID = a_strRoomID;
		roomData.m_nType = a_nType;
		roomData.m_nNO = a_nNumber;
		roomData.m_strName = a_strOtherName;
		roomData.m_strOtherMSG = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);
		roomData.m_strSenderType = a_strSenderType;
		roomData.m_strMimetype = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
		roomData.m_strOtherFile = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		roomData.m_strOtherImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
		roomData.m_lDate = a_lTime;
		roomData.m_strMessageID = a_strPacketID;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		roomData.m_nNoReadCount = a_nNoReadCount;
		roomData.m_isImageAvailable = a_isAvailable;
		roomData.m_isSmileView = a_isSmileView;
		roomData.m_lCreateTime = Long.parseLong(jsonObject.getString(StaticString.XMPP_TEXT_CREATETIME));
		roomData.m_strCloudUrl = jsonObject.getString(StaticString.XMPP_TEXT_DOCID);
		roomData.m_strVdi = jsonObject.getString(StaticString.XMPP_TEXT_VDI);
		roomData.m_JsonObject = jsonObject;
		final ChatRoomData finalRoomData = roomData;
		messageADD(finalRoomData);
		m_nAdapterCount += 1;
		m_nScreenMessageCount += 1;
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setMyFile(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, long a_lTime, int a_nNoReadCount, String a_strPacketID, JSONObject jsonObject) {

		try {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyMSG = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);
		if(jsonObject.getString(StaticString.XMPP_TEXT_FILENAME).contains(m_strSearchWord)){
			m_RoomData.m_strSearchText = m_strSearchWord;
		}
		m_RoomData.m_strMimetype = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
		m_RoomData.m_strMyFile = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		m_RoomData.m_strMyImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);

		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_lCreateTime = Long.parseLong(jsonObject.getString(StaticString.XMPP_TEXT_CREATETIME));
		m_RoomData.m_strCloudUrl = jsonObject.getString(StaticString.XMPP_TEXT_DOCID);
		m_RoomData.m_strVdi = jsonObject.getString(StaticString.XMPP_TEXT_VDI);
		m_RoomData.m_JsonObject = jsonObject;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_arrRoomData.add(m_RoomData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setMyFileAdd(int a_nType, int a_nSendStatus, String a_strRoomID, int a_nNumber, long a_lTime, int a_nNoReadCount, String a_strPacketID, JSONObject jsonObject) {
		try {
		m_RoomData = new ChatRoomData();
		m_RoomData.m_strRoomID = a_strRoomID;
		m_RoomData.m_nSendStatus = a_nSendStatus;
		m_RoomData.m_nType = a_nType;
		m_RoomData.m_nNO = a_nNumber;
		m_RoomData.m_strMyMSG = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);

		m_RoomData.m_strMimetype = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
		m_RoomData.m_strMyFile = jsonObject.getString(StaticString.XMPP_TEXT_URL);
		m_RoomData.m_strMyImageThumbUrl = jsonObject.getString(StaticString.XMPP_TEXT_THUMB);
		m_RoomData.m_lDate = a_lTime;
		m_RoomData.m_strMessageID = a_strPacketID;
		m_RoomData.m_nNoReadCount = a_nNoReadCount;
		m_RoomData.m_lCreateTime = Long.parseLong(jsonObject.getString(StaticString.XMPP_TEXT_CREATETIME));
		m_RoomData.m_strCloudUrl = jsonObject.getString(StaticString.XMPP_TEXT_DOCID);
		m_RoomData.m_strVdi = jsonObject.getString(StaticString.XMPP_TEXT_VDI);
		m_RoomData.m_JsonObject = jsonObject;
		// m_RoomData.m_arrRead = a_arrRead;
		// m_RoomData.m_arrTotalRead = a_arrTotalUser;
		m_ChatAdapter.setMyMessageChange(m_RoomData);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	private void setFailChage(String strMsgID) {
		m_ChatAdapter.setFailChange(strMsgID);
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
			m_nProgressCount++;
			Handler mHandler = new Handler(Looper.getMainLooper());
			mHandler.postDelayed(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					m_nDoneProgressCount++;
					if (m_Progress != null && m_Progress.isShowing() && m_nDoneProgressCount == m_nProgressCount){
						m_Progress.cancel();
						m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
				}

			}, 10000);
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
//			m_nProgressCount++;
//			Handler mHandler = new Handler();
//			mHandler.postDelayed(new Runnable() {
//
//				@Override
//				public void run() {
//					// TODO Auto-generated method stub
//					m_nDoneProgressCount++;
//					if (m_Progress != null && m_Progress.isShowing() && m_nDoneProgressCount == m_nProgressCount) {
//						m_Progress.cancel();
//						m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
//						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
//						m_Popup.setCancelable(false);
//						isCheckShowPopup();
//					}
//				}
//
//			}, 10000);
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing()){
			m_Progress.cancel();
			
		}
	}

	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (event.getAction() == MotionEvent.ACTION_UP) {
			m_etMessage.requestFocus();
			// if (m_lvChat.getLastVisiblePosition() == m_lvChat.getCount() - 1)
			// m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
			// else
			m_lvChat.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
			m_BottomPager.setVisibility(View.GONE);
			m_ChatMenuIconLayout.setVisibility(View.GONE);
			m_EmoticonMenu.setVisibility(View.GONE);
			m_EmoticonSelelctLayout.setVisibility(View.GONE);
			m_btnEmoticonAdd.setImageResource(R.drawable.btn_emoticon_2);
			if(!m_strRoomId.equals(Integer.toString(App.m_nChatbot))) {
				m_btnAttach.setImageResource(R.drawable.btn_file_add);
			}
			else {
				m_btnAttach.setImageResource(R.drawable.img_chatbot);
			}
			showSoftkeyboard(m_etMessage);
		}
		return false;
	}
	
	private void startPickContacts()
	{
		Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
		startActivityForResult(intent, REQUEST_CODE_PICK_CONTACTS);
	}
	
	private void startPreviewContact(String a_strName, String a_strLookupKey)
	{
		Intent intent = new Intent(this, ContactPreviewAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_NAME, a_strName);
		intent.putExtra(IntentKeyString.INTENT_KEY_CONTACTSPREVIEW_LOOKUPKEY, a_strLookupKey);
		startActivityForResult(intent, REQUEST_CODE_PREVIEW_CONTACT);
	}
	
	private void sendContacts(String a_strName, String a_strLookupKey)
	{
		CommonLog.e(ChatRoomAct.class.getSimpleName(), "Contact Name : " + a_strName);
		CommonLog.e(ChatRoomAct.class.getSimpleName(), "Contact LookupKey : " + a_strLookupKey);
		Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI, a_strLookupKey);
		AssetFileDescriptor fd;
		try {
			fd = getContentResolver().openAssetFileDescriptor(uri, "r");
			FileInputStream fis = fd.createInputStream();
			String strVCFFilePath = getFilesDir().getAbsolutePath() + File.separator + System.currentTimeMillis() + ".vcf";
			FileOutputStream fos = new FileOutputStream(strVCFFilePath);
			int data = 0;
			while((data=fis.read())!=-1)
			{
				fos.write(data);
			}
			fis.close();
			fos.close();
			
			Uri resultUri = Uri.parse(strVCFFilePath);
			sendFile(resultUri.getLastPathSegment(), resultUri, a_strName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	class MenuPagerAdapter extends PagerAdapter {

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			// TODO Auto-generated method stub
			int resId = 0;
			switch (position){
			case 0:
				resId = R.id.layout_chat_input_menu;
				break;
			case 1:
				resId = R.id.layout_chat_input_menu2;
				break;
			}
			return findViewById(resId);
		}
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if(AppSetting.FEATURE_VARIANT.equals("R")){
				return 1;
			} else {
				return 1;
			}
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0 == ((View) arg1);
		}
		
		@Override
		public void finishUpdate(View arg0) {
			// TODO Auto-generated method stub
			int nCurrentItem = m_BottomPager.getCurrentItem();
			if(nCurrentItem == 0){
				m_ivChatMenuIcon1.setImageResource(R.drawable.page_select);
				m_ivChatMenuIcon2.setImageResource(R.drawable.page_normal);
			} else {
				m_ivChatMenuIcon1.setImageResource(R.drawable.page_normal);
				m_ivChatMenuIcon2.setImageResource(R.drawable.page_select);
			}
		}
		
	}
	public void itemClick(int sel,int pos, int tag){
		m_btnSend.setBackgroundResource(R.drawable.btn_send_talk_on);
		m_nCurrentSel = sel;
		m_nCurrentPos = pos;
		m_nCurrentTag = tag;
		if(m_nCurrentSel==1) {
			m_nCurrentSelectPngEmoticonName = sticon[pos - 1][tag - 1];
			m_strCurrentSelectApngEmoticonUrl = "";
		}
		else if(m_nCurrentSel==2) {
			m_strCurrentSelectApngEmoticonUrl = apng[pos-1][tag-1];
			m_nCurrentSelectPngEmoticonName = "";
		}

		m_EmoticonContainer.setVisibility(View.VISIBLE);
		if(!m_strCurrentSelectApngEmoticonUrl.equals("") && m_nCurrentSelectPngEmoticonName.equals("")) {
			if(Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT){
				String strChangeName = m_strCurrentSelectApngEmoticonUrl.replace("_anicon", "_anicon_cover");
				int resID = getResources().getIdentifier(strChangeName, "drawable", ChatRoomAct.this.getPackageName());
				m_ivEmoticonDisplay.setImageResource(resID);
			} else {
				ApngLoader.loadImage(ApngImageUtils.Scheme.ASSETS.wrap(m_strCurrentSelectApngEmoticonUrl + ".png"), m_ivEmoticonDisplay, null);
				m_ivEmoticonDisplay.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						ApngDrawable apngDrawable = ApngDrawable.getFromView(m_ivEmoticonDisplay);
						if (apngDrawable != null) {
							apngDrawable.setNumPlays(4);
							apngDrawable.start();

						}
					}
				});
			}
		} else if(m_strCurrentSelectApngEmoticonUrl.equals("") && !m_nCurrentSelectPngEmoticonName.equals("")){
			int resourceID = getResources().getIdentifier(m_nCurrentSelectPngEmoticonName,"drawable",getPackageName());
			m_ivEmoticonDisplay.setImageResource(resourceID);
		}

		m_EmoticonContainer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (m_etMessage.getText().toString().isEmpty() || m_etMessage.getText().toString().equals("")) {
				m_btnSend.setBackgroundResource(R.drawable.btn_send_talk);
				} else {
					m_btnSend.setBackgroundResource(R.drawable.btn_send_talk_on);
				}
				m_EmoticonContainer.setVisibility(View.GONE);
			}
		});
	}
	//대화내용 검색
	private void doSearchMessage(String strText){
		hideKeyPad(m_etSearch);

		m_isSearchDownEnd = true;
		m_arrSearchOrder = new ArrayList<Integer>();
		m_arrSearchID = new ArrayList<String>();
		m_nNowSearchingIndex = 0;
		ChattingDBManager chattingDBMng = new ChattingDBManager(ChatRoomAct.this);
		chattingDBMng.openWritable(m_strRoomId);
		ArrayList<ChattingMessageData> newMessageData = new ArrayList<ChattingMessageData>();
		newMessageData = chattingDBMng.getChattingMessage();
		chattingDBMng.close();
		m_arrChattingMessageData = newMessageData;
		m_nAdapterCount = newMessageData.size();
		for(int i = m_arrChattingMessageData.size() - 1; i >= 0; i--){
			if (m_arrChattingMessageData.get(i).m_nMsgType == 0 || m_arrChattingMessageData.get(i).m_nMsgType == 9 || m_arrChattingMessageData.get(i).m_nMsgType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE || m_arrChattingMessageData.get(i).m_nMsgType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE) {
				if (m_arrChattingMessageData.get(i).m_strMsgText.contains(strText)) {
					m_arrSearchOrder.add(i);
					m_arrSearchID.add(m_arrChattingMessageData.get(i).m_strMsgId);
				}
			}
			if(m_arrChattingMessageData.get(i).m_nMsgType == StaticString.CHAT_ROOM_MY_FILE || m_arrChattingMessageData.get(i).m_nMsgType == StaticString.CHAT_ROOM_OTHER_FILE){
				try {
					JSONObject jsonObject = new JSONObject(m_arrChattingMessageData.get(i).m_strMsgText);
					String strFileName = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);
					String strMimeType = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
					if(strMimeType.equals(StaticString.FILE_TYPE_NORMAL) && strFileName.contains(strText)){
						m_arrSearchOrder.add(i);
						m_arrSearchID.add(m_arrChattingMessageData.get(i).m_strMsgId);
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		}
		//printMessage(PRINT_MESSAGE_PAGING);
		if(!m_arrSearchOrder.isEmpty()) {
			m_strSearchWord = strText;
			if(m_lvChat.getChildCount() < m_arrSearchOrder.get(m_nNowSearchingIndex)){
				m_nBeforeListViewItemCount = m_nScreenMessageCount;
				m_nScreenMessageCount = m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex) + 30;
			}
			printMessage(PRINT_MESSAGE_SEARCH);
			//m_nBouncePosition = m_nScreenMessageCount - (m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex)) + 1;
			m_strBounceID = m_arrSearchID.get(m_nNowSearchingIndex);

			m_lvChat.postDelayed(new Runnable() {
				@Override
				public void run() {
						m_lvChat.setSelection(m_nScreenMessageCount - (m_arrChattingMessageData.size() - m_arrSearchOrder.get(m_nNowSearchingIndex)));
				}
			}, 100);

			if(m_arrSearchOrder.size() > 1){
				m_ivSearchUP.setImageResource(R.drawable.btn_search_up_on);
			}
		} else {
			m_ivSearchUP.setImageResource(R.drawable.btn_search_up_off);
			m_ivSearchDown.setImageResource(R.drawable.btn_search_down_off);
			m_Popup = new CommonPopup(ChatRoomAct.this, ChatRoomAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_search_not_found));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	}

	public String getBounceID(){
		return m_strBounceID;
	}

	public void setBounceIDEmpty() {
		m_strBounceID = "";
	}
//    pri



//	private boolean m_isRunningTestSend3000MessageTask = false;
//	private class TestSend3000MessageTask extends AsyncTask<Void, Void, Void>
//	{
//		@Override
//		protected Void doInBackground(Void... params) {
//			// TODO Auto-generated method stub
//			m_isRunningTestSend3000MessageTask = true;
//			for (int i = 1; i <= 3000; i++) {
////				sendMessage("" + i + "번째 메세지", false);
//				sendMessage("MASS/서부본부\nKT/트리플통신\n1016/14시30분/59.9기준\nG928  17/22/25/16\nG925  29/22/25/16\nG920  29/22/19/16\nA500  32/18/25/16\nA700  30/15/19/16\nA800\nL800\nG906\nG850\nG720  28/18/25/12\nJ500  26/18/18/12\nN920  17/24/21/16\nN916\nN915  27/19/19/16\nN910\nF600  17/29/25/22\nF570\nF520  28/06/14/05\nF500  30/22/25/16\nF480  26/06/14/05\nF460  29/22/25/16\nF350\nAIP6  07/22/25/12\nAIP6P 07/22/25/12\n\n변동없음.", false);
//				try {
//					Thread.sleep(30);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
//			return null;
//		}
//		@Override
//		protected void onPostExecute(Void result) {
//			// TODO Auto-generated method stub
//			m_isRunningTestSend3000MessageTask = false;
//			super.onPostExecute(result);
//		}
//	}
}
