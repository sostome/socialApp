package com.gmp.rusk.datamodel;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-14.
 */

public class ChannelThreadData {


    public int m_nThreadNo = -1;
    public int m_nUserNo = -1;
    public String m_strBody = "";
    public boolean m_isNotice = false;
    public boolean m_isRead = false;
    public String m_strCreatedDate = "";
    public String m_strUpdatedTime = "";
    public int m_nLikeCount = -1;
    public boolean m_isLiked = false;
    public int m_nCommentCount = -1;
    public String m_strThreadType = "";
    public String m_strCreateType = "";

    public ArrayList<ChannelFileData> m_arrChannelFileData = new ArrayList<ChannelFileData>();

}
