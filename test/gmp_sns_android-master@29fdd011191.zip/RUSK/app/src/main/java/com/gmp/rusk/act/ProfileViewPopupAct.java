package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils.TruncateAt;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.PriorityAsyncTask;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostAddBuddysReq;
import com.gmp.rusk.request.PostRecommendReq;

import com.gmp.rusk.request.TCallReq;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;
import com.nostra13.universalimageloader.utils.L;

import java.util.HashMap;

public class ProfileViewPopupAct extends CustomActivity  {

	/**
	 * 프로필 팝업 상단
	 */
	ImageView iv_profile_pic; // 프로필 이미지
	ImageView iv_notfellow_Profile_pic;
	TextView tv_profile_name; // 이름
	LinearLayout layout_profile_position;
	TextView tv_profile_position;
	LinearLayout layout_profile_charge;
	TextView tv_profile_charge;
/*	View profile_info_space; // 이름과 부서 사이의 공백 / 부서와 소속이 없을 경우 Gone 처리 필요*/
	TextView tv_profile_company; // 부서
	TextView tv_profile_department; // 소속
//	TextView tv_profile_company; // 파트너 회사명
/*	LinearLayout layout_plus_department; // 겸직 표시 layout 겸직이 없을 경우 Gone 처리 필요*/
	TextView tv_secondparentdepartment; // 겸직
	TextView tv_phonenumber; // 폰번호
	TextView tv_email;
	/*RelativeLayout layout_not_hello;*/ // 미가입 또는 인사말 없을 경우 layout 인사말이 있으면 Gone
	TextView tv_not_hello; // 인사말이 없을 경우 Text
	RelativeLayout layout_hello; // 인사말 layout 인사말이 없을 경우 Gone, Default Gone
	TextView tv_hello_title; //인사말 타이틀(미설치자의 서비스 미사용 여부 보여주기 위해서도 사용)
	TextView tv_hello; // 인사말

	/**
	 * 프로필 팝업 하단 버튼
	 */

	ImageView iv_profile_ttalk_recommend; 		//cork추천
	ImageView iv_profile_chat;					//1:1대화
	ImageView iv_profile_addedbyfellow;			//친구 추가
	ImageView iv_profile_call;					//전화 걸기
	ImageView iv_profile_edit;					//프로필 수정
	ImageView iv_profile_partner_management;	//파트너 관리
	ImageView iv_profile_account_management;	//계정관리
	ImageView iv_profile_icon_partner;			//파트너 아이콘

	private int m_nUserNo = 0;

	private UserInfoData m_UserInfoData;

	private CommonPopup m_Popup = null;
	private ProgressDlg m_Progress = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.act_popup_profileview);

		// select UserNo 가져 오는 부분 구현
		Bundle bundle = getIntent().getExtras();

		if (bundle != null){
			m_nUserNo = bundle.getInt(IntentKeyString.INTENT_KEY_USERNO);
			super.m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID, "");
		}
	
		iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
		iv_notfellow_Profile_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);
		tv_profile_name = (TextView)findViewById(R.id.tv_profile_name);									// 이름
		layout_profile_position = (LinearLayout)findViewById(R.id.layout_position);
		layout_profile_charge = (LinearLayout)findViewById(R.id.layout_charge);
		tv_profile_position = (TextView)findViewById(R.id.tv_position);
		tv_profile_charge = (TextView)findViewById(R.id.tv_charge);

		/*profile_info_space = (View)findViewById(R.id.profile_info_space);		*/						// 이름과 부서 사이의 공백 / 부서와 소속이 없을 경우 Gone 처리 필요
		tv_profile_company = (TextView)findViewById(R.id.tv_profile_company);			// 소속 회사
		tv_profile_department = (TextView)findViewById(R.id.tv_profile_department);						// 소속
		/*layout_plus_department = (LinearLayout)findViewById(R.id.layout_plus_department);*/				// 겸직 표시 layout 겸직이 없을 경우 Gone 처리 필요
		/*tv_secondparentdepartment = (TextView)findViewById(R.id.tv_secondparentdepartment);*/				// 겸직
//		tv_profile_company = (TextView)findViewById(R.id.tv_profile_company);							// 파트너 회사명
		tv_phonenumber = (TextView)findViewById(R.id.tv_phonenumber);									// 폰번호
		tv_email = (TextView)findViewById(R.id.tv_email);
		/*layout_not_hello = (RelativeLayout)findViewById(R.id.layout_not_hello);	*/						// 미가입 또는 인사말 없을 경우 layout 인사말이 있으면 Gone
		/*tv_not_hello = (TextView)findViewById(R.id.tv_not_hello);*/										// 인사말이 없을 경우 Text
		layout_hello = (RelativeLayout)findViewById(R.id.layout_hello);									// 인사말 layout 인사말이 없을 경우 Gone, Default Gone
		tv_hello = (TextView)findViewById(R.id.tv_hello); // 인사말
		tv_hello_title = (TextView) findViewById(R.id.tv_hello_title);


		iv_profile_ttalk_recommend = (ImageView) findViewById(R.id.iv_profile_recommend);
		iv_profile_chat = (ImageView) findViewById(R.id.iv_profile_chat);
		iv_profile_addedbyfellow = (ImageView) findViewById(R.id.iv_profile_addedbyfellow);
		iv_profile_call = (ImageView) findViewById(R.id.iv_profile_call);
		iv_profile_edit = (ImageView) findViewById(R.id.iv_profile_edit);
		iv_profile_partner_management = (ImageView) findViewById(R.id.iv_partner_management);
		iv_profile_account_management = (ImageView) findViewById(R.id.iv_account_management);
		iv_profile_icon_partner = (ImageView)findViewById(R.id.iv_profile_icon_partner);
//		setResult(Activity.RESULT_CANCELED);
		requestGetUserInfo();
		//requestTest();
		
		iv_profile_pic.setOnClickListener(this);
//		setResult(Activity.RESULT_CANCELED);
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		closeProgress();
		super.onDestroy();
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == Activity.RESULT_OK)
		{
			if(requestCode == StaticString.REQUESTCODE_PROFILE_EDIT)
			{
				requestGetUserInfo();
				App.m_isChangeFellow = true;
			}
			else if(requestCode == StaticString.REQUESTCODE_ACCOUNTMANAGEMENT)
			{
				setResult(Activity.RESULT_OK);
				finish();
			}
			else if(requestCode == StaticString.REQUESTCODE_PROFILEIMAGEVIEW)
			{
				App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_nUserNo, true), R.drawable.profile_pic_default, true);
				setResult(StaticString.RESULT_PROFILE_NOTIFYCHANGE_IMAGE);
				App.m_isChangeFellow = true;
			}
		}
	}
	
	
	
	private void setRegularMyProfile() {
		if(m_UserInfoData.m_isImageAvailable)
		{
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_nUserNo, true), R.drawable.profile_pic_default, false);
		}
		else
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		
		
		String strName = m_UserInfoData.m_strName;
		
		tv_profile_name.setText(strName);
		if(m_UserInfoData.m_strPosition!=null && !m_UserInfoData.m_strPosition.equals("")){
			layout_profile_position.setVisibility(View.VISIBLE);
			tv_profile_position.setText(m_UserInfoData.m_strPosition);
		} else {
			layout_profile_position.setVisibility(View.GONE);
		}

		if(m_UserInfoData.m_strCharge!=null && !m_UserInfoData.m_strCharge.equals("")){
			layout_profile_charge.setVisibility(View.VISIBLE);
			tv_profile_charge.setText(m_UserInfoData.m_strCharge);
		} else {
			layout_profile_charge.setVisibility(View.GONE);
		}
		
/*		profile_info_space.setVisibility(View.VISIBLE);*/
		tv_profile_company.setVisibility(View.VISIBLE);
		tv_profile_department.setVisibility(View.VISIBLE);
	/*	if (m_UserInfoData.m_strParentDepartment.length() == 0 && m_UserInfoData.m_strDepartment.length() == 0) {
			profile_info_space.setVisibility(View.GONE);
		}*/

		if (m_UserInfoData.m_strCompanyName.length() == 0)
			tv_profile_company.setVisibility(View.GONE);
		else
			tv_profile_company.setText(m_UserInfoData.m_strCompanyName);

		if (m_UserInfoData.m_strDepartment.length() == 0)
			tv_profile_department.setVisibility(View.GONE);
		else
		{
			tv_profile_department.setSingleLine(true);
			tv_profile_department.setEllipsize(TruncateAt.END);
			tv_profile_department.setText(m_UserInfoData.m_strDepartment);
		}

		if (m_UserInfoData.m_strSecondParentDepartment.length() == 0 && m_UserInfoData.m_strSecondDepartment.length() == 0 && m_UserInfoData.m_strSecondCharge.length() == 0) {
			/*layout_plus_department.setVisibility(View.GONE);*/
		}
		else
		{
			String strDepartments = "";
			if(m_UserInfoData.m_strSecondParentDepartment.length() > 0 && m_UserInfoData.m_strSecondDepartment.length() > 0)
				strDepartments = m_UserInfoData.m_strSecondParentDepartment +" > " + m_UserInfoData.m_strSecondDepartment;
			else if(m_UserInfoData.m_strSecondParentDepartment.length() == 0)
				strDepartments = m_UserInfoData.m_strSecondDepartment;
			else if(m_UserInfoData.m_strSecondDepartment.length() == 0)	
				strDepartments = m_UserInfoData.m_strSecondParentDepartment;
			
			strDepartments = strDepartments + m_UserInfoData.m_strSecondCharge;
			SpannableStringBuilder builder2 = new SpannableStringBuilder(strDepartments);
			builder2.setSpan(new ForegroundColorSpan(Color.parseColor("#636363")), strDepartments.length()-m_UserInfoData.m_strSecondCharge.length(), strDepartments.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			
			tv_secondparentdepartment.setText(builder2);
		}

		if(m_UserInfoData.m_strMobile.equals("-")){
			tv_phonenumber.setText("");
		} else {
			tv_phonenumber.setText(Utils.getPhoneNumberWithHyphen(m_UserInfoData.m_strMobile)); // 폰번호
		}
		if(m_UserInfoData.m_strEmail.equals("-")){
			tv_email.setText("");
		} else {
			tv_email.setText(m_UserInfoData.m_strEmail);
		}
		if(m_UserInfoData.m_isAvailable)
		{

			layout_hello.setVisibility(View.VISIBLE);
			tv_hello.setText(m_UserInfoData.m_strGreeting);
			if(m_UserInfoData.m_strGreeting.isEmpty()){
				tv_hello.setText(getString(R.string.profile_pop_no_greeting));
			}
		}
		else
		{

			layout_hello.setVisibility(View.VISIBLE);
			tv_hello_title.setText(getString(R.string.profile_pop_not_active).toString());
			tv_hello_title.setTextColor(Color.parseColor("#d63b33"));
		}


		iv_profile_edit.setVisibility(View.VISIBLE);
		iv_profile_partner_management.setVisibility(View.VISIBLE);
		iv_profile_edit.setOnClickListener(this);
		iv_profile_partner_management.setOnClickListener(this);
	}

	private void setPartnerMyProfile() {
		if(m_UserInfoData.m_isImageAvailable)
		{
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_nUserNo, true), R.drawable.profile_pic_default, false);
		}
		else 
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);

		iv_profile_icon_partner.setVisibility(View.VISIBLE);

		String strName;
		SpannableStringBuilder builder;

		strName = m_UserInfoData.m_strName;

		tv_profile_name.setText(strName);
		if(m_UserInfoData.m_strPosition!=null && !m_UserInfoData.m_strPosition.equals("")){
			layout_profile_position.setVisibility(View.VISIBLE);
			tv_profile_position.setText(m_UserInfoData.m_strPosition);

		} else {
			layout_profile_position.setVisibility(View.GONE);
		}
		if(m_UserInfoData.m_strCharge!=null && !m_UserInfoData.m_strCharge.equals("")){
			layout_profile_charge.setVisibility(View.VISIBLE);
			tv_profile_charge.setText(m_UserInfoData.m_strCharge);
		} else {
			layout_profile_charge.setVisibility(View.GONE);
		}

	/*	profile_info_space.setVisibility(View.VISIBLE);*/
		//tv_profile_company.setVisibility(View.VISIBLE);
		tv_profile_department.setVisibility(View.VISIBLE);
		/*if (m_UserInfoData.m_strParentDepartment.length() == 0 && m_UserInfoData.m_strDepartment.length() == 0) {
			profile_info_space.setVisibility(View.GONE);
		}*/

		/*if (m_UserInfoData.m_strCompanyName.length() == 0)
			tv_profile_company.setVisibility(View.GONE);
		else
			tv_profile_company.setText(m_UserInfoData.m_strCompanyName);*/

		if (m_UserInfoData.m_strAffiliation.length() == 0) {
		/*	profile_info_space.setVisibility(View.GONE);*/
		} else
		{
			String strCompany = m_UserInfoData.m_strAffiliation.replace("\n", "");
			tv_profile_department.setText(strCompany);
		}

		if (m_UserInfoData.m_strSecondParentDepartment.length() == 0 && m_UserInfoData.m_strSecondDepartment.length() == 0 && m_UserInfoData.m_strSecondCharge.length() == 0) {
			
		}
		else
		{
			String strDepartments = "";
			if(m_UserInfoData.m_strSecondParentDepartment.length() > 0 && m_UserInfoData.m_strSecondDepartment.length() > 0)
				strDepartments = m_UserInfoData.m_strSecondParentDepartment +" > " + m_UserInfoData.m_strSecondDepartment;
			else if(m_UserInfoData.m_strSecondParentDepartment.length() == 0)
				strDepartments = m_UserInfoData.m_strSecondDepartment;
			else if(m_UserInfoData.m_strSecondDepartment.length() == 0)	
				strDepartments = m_UserInfoData.m_strSecondParentDepartment;
			
			strDepartments = strDepartments + m_UserInfoData.m_strSecondCharge;
			SpannableStringBuilder builder2 = new SpannableStringBuilder(strDepartments);
			builder2.setSpan(new ForegroundColorSpan(Color.parseColor("#636363")), strDepartments.length()-m_UserInfoData.m_strSecondCharge.length(), strDepartments.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			
			tv_secondparentdepartment.setText(builder2);
		}
		if(m_UserInfoData.m_strMobile.equals("-")){
			tv_phonenumber.setText("");
		} else {
			tv_phonenumber.setText(Utils.getPhoneNumberWithHyphen(m_UserInfoData.m_strMobile)); // 폰번호
		}
		if(m_UserInfoData.m_strEmail.equals("-")){
			tv_email.setText("");
		} else {
			tv_email.setText(m_UserInfoData.m_strEmail);
		}
		if(m_UserInfoData.m_isAvailable)
		{

				layout_hello.setVisibility(View.VISIBLE);
				tv_hello.setText(m_UserInfoData.m_strGreeting);
			if(m_UserInfoData.m_strGreeting.isEmpty()){
				tv_hello.setText(getString(R.string.profile_pop_no_greeting));
			}
			
		}
		else
		{
			layout_hello.setVisibility(View.VISIBLE);
			tv_hello_title.setText(getString(R.string.profile_pop_not_active).toString());
			tv_hello_title.setTextColor(Color.parseColor("#d63b33"));
		}


		iv_profile_edit.setVisibility(View.VISIBLE);
		iv_profile_account_management.setVisibility(View.VISIBLE);
		iv_profile_edit.setOnClickListener(this);
		iv_profile_account_management.setOnClickListener(this);

	}

	private void setRegularProfile() {
		if(m_UserInfoData.m_isImageAvailable)
		{
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_nUserNo, true), R.drawable.profile_pic_default, false);
		}
		else
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		
		String strName = m_UserInfoData.m_strName;
		tv_profile_name.setText(strName);
		if(m_UserInfoData.m_strPosition!=null && !m_UserInfoData.m_strPosition.equals("")){
			layout_profile_position.setVisibility(View.VISIBLE);
			tv_profile_position.setText(m_UserInfoData.m_strPosition);
		} else {
			layout_profile_position.setVisibility(View.GONE);
		}

		if(m_UserInfoData.m_strCharge!=null && !m_UserInfoData.m_strCharge.equals("")){
			layout_profile_charge.setVisibility(View.VISIBLE);
			tv_profile_charge.setText(m_UserInfoData.m_strCharge);
		} else {
			layout_profile_charge.setVisibility(View.GONE);
		}

		/*profile_info_space.setVisibility(View.VISIBLE);*/
		tv_profile_company.setVisibility(View.VISIBLE);
		tv_profile_department.setVisibility(View.VISIBLE);
		/*if (m_UserInfoData.m_strParentDepartment.length() == 0 && m_UserInfoData.m_strDepartment.length() == 0)

		{
			profile_info_space.setVisibility(View.GONE);
		}*/

		if (m_UserInfoData.m_strCompanyName.length() == 0)
			tv_profile_company.setVisibility(View.GONE);
		else
			tv_profile_company.setText(m_UserInfoData.m_strCompanyName);

		if (m_UserInfoData.m_strDepartment.length() == 0)
			tv_profile_department.setVisibility(View.GONE);
		else
		{
			tv_profile_department.setSingleLine(true);
			tv_profile_department.setEllipsize(TruncateAt.END);
			tv_profile_department.setText(m_UserInfoData.m_strDepartment);
		}

		if (m_UserInfoData.m_strSecondParentDepartment.length() == 0 && m_UserInfoData.m_strSecondDepartment.length() == 0 && m_UserInfoData.m_strSecondCharge.length() == 0) {
			/*layout_plus_department.setVisibility(View.GONE);*/
		}
		else
		{
			String strDepartments = "";
			if(m_UserInfoData.m_strSecondParentDepartment.length() > 0 && m_UserInfoData.m_strSecondDepartment.length() > 0)
				strDepartments = m_UserInfoData.m_strSecondParentDepartment +" > " + m_UserInfoData.m_strSecondDepartment;
			else if(m_UserInfoData.m_strSecondParentDepartment.length() == 0)
				strDepartments = m_UserInfoData.m_strSecondDepartment;
			else if(m_UserInfoData.m_strSecondDepartment.length() == 0)	
				strDepartments = m_UserInfoData.m_strSecondParentDepartment;
			
			strDepartments = strDepartments + m_UserInfoData.m_strSecondCharge;
			SpannableStringBuilder builder2 = new SpannableStringBuilder(strDepartments);
			builder2.setSpan(new ForegroundColorSpan(Color.parseColor("#636363")), strDepartments.length()-m_UserInfoData.m_strSecondCharge.length(), strDepartments.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			
		/*	tv_secondparentdepartment.setText(builder2);*/
		}

		String strPhoneNumber = Utils.getPhoneNumberWithHyphen(m_UserInfoData.m_strMobile);


		UserListData userListData = ContactsDBManager.getContacts(this, m_nUserNo);

			/*if(!m_UserInfoData.m_isAvailable && !AppSetting.FEATURE_VARIANT.equals("R")){
				iv_profile_call.setVisibility(View.GONE);
			} 
			else {
			}
			*/
		if(m_UserInfoData.m_strMobile.equals("-")){
			iv_profile_call.setVisibility(View.VISIBLE);
			iv_profile_call.setOnClickListener(null);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
				iv_profile_call.getBackground().setAlpha(50);
			}
		} else {
			iv_profile_call.setVisibility(View.VISIBLE);
			iv_profile_call.setOnClickListener(this);
		}
			
			iv_notfellow_Profile_pic.setVisibility(View.GONE);
		

		if(m_UserInfoData.m_strMobile.equals("-")){
			tv_phonenumber.setText("");
		} else {
			tv_phonenumber.setText(strPhoneNumber); // 폰번호
		}
		if(m_UserInfoData.m_strEmail.equals("-")){
			tv_email.setText("");
		} else {
			tv_email.setText(m_UserInfoData.m_strEmail);
		}
		if(m_UserInfoData.m_isAvailable)
		{

			layout_hello.setVisibility(View.VISIBLE);
			tv_hello.setText(m_UserInfoData.m_strGreeting);
			if(m_UserInfoData.m_strGreeting.isEmpty()){
				tv_hello.setText(getString(R.string.profile_pop_no_greeting));
			}
		}
		else
		{
			layout_hello.setVisibility(View.VISIBLE);
			tv_hello_title.setText(getString(R.string.profile_pop_not_active).toString());
			tv_hello_title.setTextColor(Color.parseColor("#d63b33"));
		}

		if (m_UserInfoData.m_isAvailable) {
			if(ChatRoomAct.m_Activity == null){

				iv_profile_chat.setVisibility(View.VISIBLE);
				iv_profile_chat.setOnClickListener(this);
			}
		} else {

			if(m_UserInfoData.m_strMobile.equals("-")){
				iv_profile_ttalk_recommend.setVisibility(View.VISIBLE);
				iv_profile_ttalk_recommend.setOnClickListener(null);
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
					iv_profile_ttalk_recommend.getBackground().setAlpha(50);
				}
			} else {
				iv_profile_ttalk_recommend.setVisibility(View.VISIBLE);
				iv_profile_ttalk_recommend.setOnClickListener(this);
			}
		}

		if (m_UserInfoData.m_isAvailable && (userListData == null || !userListData.m_isFellow)) {

				iv_profile_addedbyfellow.setVisibility(View.VISIBLE);
				iv_profile_addedbyfellow.setOnClickListener(this);
		}

	}

	private void setPartnerProfile() {
		if(m_UserInfoData.m_isImageAvailable)
		{
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_nUserNo, true), R.drawable.profile_pic_default, false);
		}
		else
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);

		iv_profile_icon_partner.setVisibility(View.VISIBLE);

		String strName;
		SpannableStringBuilder builder;

		strName = m_UserInfoData.m_strName;

		tv_profile_name.setText(strName);
		if(m_UserInfoData.m_strPosition!=null && !m_UserInfoData.m_strPosition.equals("")){
			layout_profile_position.setVisibility(View.VISIBLE);
			tv_profile_position.setText(m_UserInfoData.m_strPosition);
		} else {
			layout_profile_position.setVisibility(View.GONE);
		}

		if(m_UserInfoData.m_strCharge!=null && !m_UserInfoData.m_strCharge.equals("")){
			layout_profile_charge.setVisibility(View.VISIBLE);
			tv_profile_charge.setText(m_UserInfoData.m_strCharge);
		} else {
			layout_profile_charge.setVisibility(View.GONE);
		}

		tv_profile_company.setVisibility(View.GONE);
//		tv_profile_department.setVisibility(View.GONE);
		//layout_plus_department.setVisibility(View.GONE);
//		profile_info_space.setVisibility(View.GONE);
		
		if (m_UserInfoData.m_strAffiliation.length() == 0) {
		/*	profile_info_space.setVisibility(View.GONE);*/
		} else
		{
			String strCompany = m_UserInfoData.m_strAffiliation.replace("\n", "");
			tv_profile_department.setText(strCompany);
		}
		String strPhoneNumber = Utils.getPhoneNumberWithHyphen(m_UserInfoData.m_strMobile);
		UserListData userListData = TTalkDBManager.ContactsDBManager.getContacts(this, m_nUserNo);

			/*if(!m_UserInfoData.m_isAvailable && !AppSetting.FEATURE_VARIANT.equals("R")){

				iv_profile_call.setVisibility(View.GONE);
			} else {*/

		if(m_UserInfoData.m_strMobile.equals("-")){
			iv_profile_call.setVisibility(View.VISIBLE);
			iv_profile_call.setOnClickListener(null);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
				iv_profile_call.getBackground().setAlpha(50);
			}
		} else {
			iv_profile_call.setVisibility(View.VISIBLE);
			iv_profile_call.setOnClickListener(this);
		}
			//}
			iv_notfellow_Profile_pic.setVisibility(View.GONE);


		if(m_UserInfoData.m_strMobile.equals("-")){
			tv_phonenumber.setText("");
		} else {
			tv_phonenumber.setText(strPhoneNumber); // 폰번호
		}
		if(m_UserInfoData.m_strEmail.equals("-")){
			tv_email.setText("");
		} else {
			tv_email.setText(m_UserInfoData.m_strEmail);
		}
		if(m_UserInfoData.m_isAvailable)
		{

			layout_hello.setVisibility(View.VISIBLE);
			tv_hello.setText(m_UserInfoData.m_strGreeting);
			if(m_UserInfoData.m_strGreeting.isEmpty()){
				tv_hello.setText(getString(R.string.profile_pop_no_greeting));
			}
		}
		else
		{
			layout_hello.setVisibility(View.VISIBLE);
			tv_hello_title.setText(getString(R.string.profile_pop_not_active).toString());
			tv_hello_title.setTextColor(Color.parseColor("#d63b33"));

		}

		if (m_UserInfoData.m_isAvailable) {
			if(ChatRoomAct.m_Activity == null){

				iv_profile_chat.setVisibility(View.VISIBLE);
				iv_profile_chat.setOnClickListener(this);
			}
		} else {

			if(m_UserInfoData.m_strMobile.equals("-")){
				iv_profile_ttalk_recommend.setVisibility(View.VISIBLE);
				iv_profile_ttalk_recommend.setOnClickListener(null);
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
					iv_profile_ttalk_recommend.getBackground().setAlpha(50);
				}
			} else {
				iv_profile_ttalk_recommend.setVisibility(View.VISIBLE);
				iv_profile_ttalk_recommend.setOnClickListener(this);
			}
		}
		
		
		if (m_UserInfoData.m_isAvailable && (userListData == null  || !userListData.m_isFellow)) {
				iv_profile_addedbyfellow.setVisibility(View.VISIBLE);
				iv_profile_addedbyfellow.setOnClickListener(this);
		}
	}

	private void requestGetUserInfo() {
		showProgress();
		GetUserInfoReq req = new GetUserInfoReq(m_nUserNo, true);
		WebAPI webApi = new WebAPI(ProfileViewPopupAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				CommonLog.e("GetUserInfo", a_strData);
				
				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_INFO_SINGLE);

				if (res.getUserInfoDatas() != null && res.getUserInfoDatas().size() != 0) {
					m_UserInfoData = res.getUserInfoDatas().get(0);
					if(ContactsDBManager.getContacts(ProfileViewPopupAct.this, m_UserInfoData.m_nUserNo) == null){
						GetUserInfoRes dbRes = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);
						ContactsDBManager.insertContacts(ProfileViewPopupAct.this, dbRes.getUserListData());
					}
/*					PersonalData testPData = new PersonalData(m_UserInfoData.m_strName, m_UserInfoData.m_strEmail, m_UserInfoData.m_strMobile,
							m_UserInfoData.m_strCompany, m_UserInfoData.m_strDepartment, m_UserInfoData.m_strParentDepartment, m_UserInfoData.m_strCharge,
							m_UserInfoData.m_strPosition, m_UserInfoData.m_strSecondCharge, m_UserInfoData.m_strAffiliation);
					UserListData testData = new UserListData(m_UserInfoData.m_nUserNo, testPData, m_UserInfoData.m_strUserType, m_UserInfoData.m_isImageAvailable, m_UserInfoData.m_isAvailable,
							m_UserInfoData.m_strGreeting, m_UserInfoData.m_strStatus, false, "0");
					TTalkDBManager.ContactsDBManager.insertContacts(ProfileViewPopupAct.this, testData);

					UserListData testData2 = ContactsDBManager.getContacts(ProfileViewPopupAct.this, App.m_MyUserInfo.m_nUserNo, false);*/

					if (m_UserInfoData.m_strUserType.equals("R")) {
						if (m_nUserNo == App.m_EntryData.m_nUserNo) {
							setRegularMyProfile();
						} else {
							setRegularProfile();
						}
					} else {
						if (m_nUserNo == App.m_EntryData.m_nUserNo) {
							setPartnerMyProfile();
						} else {
							setPartnerProfile();
						}
					}
				}
				closeProgress();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}  else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.setNetworkStatusCode(a_nErrorCode);
					isCheckShowPopup();
				}
			}
		});
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		if (v.getId() == R.id.iv_profile_recommend) {
//			doRecommand();
			m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, 
					CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_REQRECOMMAND);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.profile_recommand_confirm).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
			
		} else if (v.getId() == R.id.iv_profile_chat) {

			finish();
			PriorityAsyncTask<Void, Void, Void> task = new PriorityAsyncTask<Void, Void, Void>() {

				@Override
				protected Void doInBackground(Void... params) {
					//for(Activity activity : App.m_arrActivitys){

						Intent intentNewTask;
						intentNewTask = new Intent(ProfileViewPopupAct.this, MainTabAct.class);
						intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISMOVETAB, true);
						intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
						startActivity(intentNewTask);

						Intent intent = new Intent(ProfileViewPopupAct.this, ChatRoomAct.class);
						intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, m_nUserNo);
						startActivity(intent);
						setResult(RESULT_OK);
						//}

					//}

					return null;
				}
			};

			task.execute();

		} else if (v.getId() == R.id.iv_profile_addedbyfellow) {
			requestAddBuddys();
		} else if (v.getId() == R.id.iv_profile_call) {
			doCall();
		} else if (v.getId() == R.id.iv_profile_edit) {
			doProfileEdit();
		} else if (v.getId() == R.id.iv_partner_management) {
			doPartnerManagement();
		} else if (v.getId() == R.id.iv_account_management) {
			doAccountManagement();
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_FINISH)
			{
				popup_ok_long.cancel();
				finish();
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_NOT_FINISH)
			{
				popup_ok_long.cancel();
			}
			else
			{
				popup_ok_long.cancel();
				finish();
			}
		}
		else if(v.getId() == R.id.ib_pop_ok)
		{
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOP_REQRECOMMAND)
			{
				doRecommand();
			}
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		else if(v.getId() == R.id.iv_profile_pic)
		{
			if(m_UserInfoData.m_isImageAvailable)
			{
//				String strPhoneNumber = Utils.getPhoneNumberWithHyphen(m_UserInfoData.m_strMobile);

				Intent intent = new Intent(ProfileViewPopupAct.this, ProfileImageAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_PROFILEIMAGE_USERNO, m_nUserNo);
				startActivityForResult(intent, StaticString.REQUESTCODE_PROFILEIMAGEVIEW);
			}
		}
	}
 
	private void doRecommand()
	{
		requestRecommad();
	}
	
	// 전화를 걸자
	private void doCall() {
		if (m_UserInfoData != null) {
			if (m_UserInfoData.m_strMobile != null && m_UserInfoData.m_strMobile.length() > 10) {
				//정직원이 파트너에게 는 일반전화
				//나머지는 전부 t전화 검
				if(App.m_MyUserInfo.m_strUserType.equals("R") && !m_UserInfoData.m_strUserType.equals("R")){
					Uri uri = Uri.parse("tel:" + m_UserInfoData.m_strMobile);
					Intent intent = new Intent(Intent.ACTION_CALL, uri);
					startActivity(intent);
				} else {
					TCallReq req = new TCallReq(m_UserInfoData.m_strMobile);
					WebAPI webAPI = new WebAPI(this);
					webAPI.request(req, new WebListener() {
						@Override
						public void onPreRequest() {

						}

						@Override
						public void onNetworkError(int nErrorCode, String strMessage) {
							Uri uri = Uri.parse("tel:" + m_UserInfoData.m_strMobile);
							Intent intent = new Intent(Intent.ACTION_CALL, uri);
							startActivity(intent);
						}

						@Override
						public void onPostRequest(String a_strData) {
							Uri uri = Uri.parse("tel:" + m_UserInfoData.m_strMobile);
							Intent intent = new Intent(Intent.ACTION_CALL, uri);
							startActivity(intent);
						}
					});


				}

			}
			else 
			{
				//전화 번호.... 오류 팝업
				m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_NOT_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.popup_verify_phonenum).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}

	private void doProfileEdit()
	{
		Intent intent = new Intent(ProfileViewPopupAct.this, SetProfileAct.class);
		startActivityForResult(intent, StaticString.REQUESTCODE_PROFILE_EDIT);
	}
	
	private void doPartnerManagement()
	{
		Intent intent = new Intent(ProfileViewPopupAct.this, ApprovalTabAct.class);
		startActivityForResult(intent, StaticString.REQUESTCODE_APPROVALTAB);
	}
	
	private void doAccountManagement()
	{
		Intent intent = new Intent(ProfileViewPopupAct.this, SetAccountManagementAct.class);
		startActivityForResult(intent, StaticString.REQUESTCODE_ACCOUNTMANAGEMENT);
	}
	
	private void requestRecommad()
	{
		showProgress();
		int[] nUserNos = new int[1];
		nUserNos[0] = m_nUserNo;
		PostRecommendReq req = new PostRecommendReq(nUserNos);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
				// TODO Auto-generated method stub
				m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.profile_recommand_success).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
	private void requestAddBuddys() {
		showProgress();
		int[] nSelects = new int[1];
		nSelects[0] = m_nUserNo;
		PostAddBuddysReq req = new PostAddBuddysReq(nSelects);
		WebAPI webApi = new WebAPI(ProfileViewPopupAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				UserListData getItem = TTalkDBManager.ContactsDBManager.getContacts(ProfileViewPopupAct.this, m_nUserNo);

				if (getItem != null) {
					closeProgress();
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();

					TTalkDBManager.ContactsDBManager.updateContacts(ProfileViewPopupAct.this, getItem);

					iv_profile_addedbyfellow.setVisibility(View.GONE);
					if(ChatRoomAct.m_Activity == null){

						iv_profile_chat.setVisibility(View.VISIBLE);
						iv_profile_chat.setOnClickListener(ProfileViewPopupAct.this);
					}
					HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;

					if (getItem.m_strUserType.equals("R")) {
						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
								personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
						App.buddyAdd(fellowListData);
					} else {
						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
								getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
						App.buddyAdd(fellowListData);
					}
					mService.addBuddy(Integer.toString(getItem.m_nUserNo));
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_fellowadd_title), getString(R.string.pop_fellowadd_success));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					
					Intent intent = new Intent();
					intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, getItem.m_nUserNo);
					setResult(StaticString.RESULT_PROFILE_NOTIFYCHANGE, intent);
				} else {
					// 사용자 추가 구현
					//Toast.makeText(ProfileViewPopupAct.this, m_nUserNo + "[" + m_UserInfoData.m_strName + "]은 사용자 정보 DB에 없습니다.", Toast.LENGTH_SHORT).show();
					requestAddedByUserList();
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	private void requestAddedByUserList() {
		int[] nSelects = new int[1];
		nSelects[0] = m_nUserNo;
		GetUserInfoReq req = new GetUserInfoReq(nSelects);
		WebAPI webApi = new WebAPI(ProfileViewPopupAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				UserListData getItem = res.getUserListData().get(0);
				if (getItem != null) {
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();
					if (ContactsDBManager.insertContacts(ProfileViewPopupAct.this, getItem) > 0) {

						iv_profile_addedbyfellow.setVisibility(View.GONE);
						if(ChatRoomAct.m_Activity == null){

							iv_profile_chat.setVisibility(View.VISIBLE);
							iv_profile_chat.setOnClickListener(ProfileViewPopupAct.this);
						}
						HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
						if (getItem.m_strUserType.equals("R")) {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
									personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						} else {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
									getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						}
						mService.addBuddy(Integer.toString(getItem.m_nUserNo));
						m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_fellowadd_title), getString(R.string.pop_fellowadd_success));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
						Intent intent = new Intent();
						intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, getItem.m_nUserNo);
						setResult(StaticString.RESULT_PROFILE_NOTIFYCHANGE, intent);
					}
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(ProfileViewPopupAct.this, ProfileViewPopupAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
