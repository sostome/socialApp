package com.gmp.rusk.request;

import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;

/**
 *	@author kch
 *			이미지 변경
 *			method : post
 *			Accept Media Type: multipart/form-data
 */

public class PostChangeImageReq extends UploadReq{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
		
	public PostChangeImageReq(int a_nUserNo)
	{
		APINAME = APINAME + "/" + a_nUserNo + "/image";
		
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
	
//	private String m_strImgFilePath = "";
//	public void setFilePath(String a_strFilePath)
//	{
//		m_strImgFilePath = a_strFilePath;
//	}
	
	private byte[] m_byteImgFileData = null;
	
	public void setFileData(byte[] a_byteFileData)
	{
		m_byteImgFileData = a_byteFileData;
	}
	
	private final String MULTIPART_KEY_IMAGEFILE = "imageFile";
	
	@Override
	public MultipartEntity getMultiPartEntity()
	{
//		byte[] data = getFileByte();
		byte[] data = m_byteImgFileData;
		if(data != null)
		{
			MultipartEntity multiPart = new MultipartEntity();
			String strFileName = System.currentTimeMillis() + ".jpg";
			ContentBody byteBody = new ByteArrayBody(data, strFileName);
			multiPart.addPart(MULTIPART_KEY_IMAGEFILE, byteBody);
			return multiPart;
		}
		else 
			return null;
	}
	
//	private byte[] getFileByte()
//	{
//		byte[] bArData = null;
//		File file = new File(m_strImgFilePath);
//		if(file != null && file.exists())
//		{
//			try {
//				FileInputStream isFile = new FileInputStream(file);
//				int nCount = isFile.available();
//				if(nCount > 0)
//				{
//					bArData = new byte[nCount];
//					isFile.read(bArData);
//				}
//				if(isFile != null)
//				{
//					isFile.close();
//				}
//			} 
//			catch (FileNotFoundException e) {
//				e.printStackTrace();
//			} 
//			catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//		
//		return bArData;
//	}
}
