package com.gmp.rusk.utils;

public class AppSetting {

	public enum APISERVER_LIST
	{
		DEV_SERVER,			// 테스트 서버
		COMMON_SERVER		// 상용 서버
	}

//	public static final APISERVER_LIST USING_SERVER = APISERVER_LIST.COMMON_SERVER;
// 	public static final APISERVER_LIST USING_SERVER = APISERVER_LIST.DEV_SERVER;
	
//	// FEATURE
	public final static boolean FEATURE_DEBUG = false;
	public final static boolean FEATURE_FILELOG = false;
	public final static boolean FEATURE_SCREENSHOT = false;

	public final static String FEATURE_VARIANT = StaticString.VARIANT_REGULAR;	// t: 정직원
//	public final static String FEATURE_VARIANT = "S";	// s: 임시 조직도 보이는 버전
//	public final static String FEATURE_VARIANT = StaticString.VARIANT_PARTNER;	// f:가사번 & 파트너
	
	public final static boolean FEATURE_PERSONA = false;

	public final static boolean ISHTTPS = true;		//

	
//	에러 로그 전송
	public final static boolean CRASHLOG_MAIL = false;
}


