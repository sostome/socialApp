package com.gmp.rusk.fragment;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatInviteTabAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.ChatroomInviteListItemLayout;
import com.gmp.rusk.listview.SectionListAdapter;
import com.gmp.rusk.listview.SectionListItem;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserListReq;
import com.gmp.rusk.response.GetUserListRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StringMatcher;
import com.gmp.rusk.utils.Utils;

/**
 * ChatRoomFellowListFlag
 * 
 * @author kch ChatInviteTabAct - 동료리스트 Fragment
 */
public class ChatRoomFellowListFlag extends Fragment implements OnClickListener, CompoundButton.OnCheckedChangeListener, View.OnTouchListener {

	public MyApp App = MyApp.getInstance();
	private View m_vFellowList = null;

	private FragmentActivity m_Activity = null;

	private ListView m_lvFellowList = null;
	private FellowListAdapter m_FellowListAdapter = null;
	private SearchFellowListAdapter m_SearchFellowListAdapter = null;
	private SectionListAdapter m_SectionListAdapter = null;

	private ArrayList<SectionListItem> m_SectionListItems = null; // SectionListView
																	// 에 넣는 Item
																	// 생성

	private ArrayList<FellowListData> m_arrNewFellowListData = null;

	private ArrayList<FellowListData> m_arrSearchFellowListData = null;

	private SectionListItem item = null;

	EditText et_search_keyword;
	CheckBox m_cbAllcheck;
	ImageButton ib_cancel;
	boolean m_isTouchCheckBox = false;
	private ArrayList<FellowListData> m_ListItems = null;
	TextView m_tvSectionText;

	private InputMethodManager imm;
	private CommonPopup m_Popup = null;
	public final ArrayList<Integer> m_nInviteSelectId = new ArrayList<Integer>();

	private ProgressDlg m_Progress = null;

	static ChatRoomFellowListFlag newInstance() {
		ChatRoomFellowListFlag f = new ChatRoomFellowListFlag();
		return f;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		m_Activity = getActivity();
		App.m_arrRegularSearchListDatas = new ArrayList<RegularSearchListData>();
		App.m_arrSearchListCheckData = new ArrayList<SearchListCheckData>();

		imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);

	}

	/**
	 * The Fragment's UI is just a simple text view showing its instance number.
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		m_vFellowList = inflater.inflate(R.layout.fragact_invitebyfellow, container, false);

		((ChatInviteTabAct) m_Activity).setNotifyListener(m_NotifyListner);

		requestUpdateUserList();
		//initSearch();
		//initSectionListViewUi();

		return m_vFellowList;
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (imm != null && et_search_keyword != null)
			imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);

	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		if(m_FellowListAdapter != null)
			m_FellowListAdapter.notifyDataSetChanged();
		if(m_SearchFellowListAdapter != null)
			m_SearchFellowListAdapter.notifyDataSetChanged();
		
		super.onResume();
	}

	private void initSearch() {
		et_search_keyword = (EditText) m_vFellowList.findViewById(R.id.et_search_keyword);
		et_search_keyword.setText("");
		m_tvSectionText = (TextView) m_vFellowList.findViewById(R.id.tv_sectiontext);
		m_cbAllcheck = (CheckBox) m_vFellowList.findViewById(R.id.cb_chat_allmember);
		m_cbAllcheck.setOnCheckedChangeListener(this);
		m_cbAllcheck.setOnTouchListener(this);
		ib_cancel = (ImageButton) m_vFellowList.findViewById(R.id.ib_cancel);
		ib_cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				et_search_keyword.setText("");
			}
		});

		et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				CommonLog.e("EditAction", "actionId1 : " + actionId);

				/*switch (actionId) {
				case EditorInfo.IME_ACTION_SEARCH:
					if (!Utils.UseChar(v.getText().toString())) {
						m_Popup = new CommonPopup(m_Activity, ChatRoomFellowListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.regular_expression_search).toString());
						m_Popup.setCancelable(false);
						m_Popup.show();
						return false;
					}
					break;
				}*/
				return true;
			}
		});

		et_search_keyword.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				m_cbAllcheck.setChecked(false);
				if (s.toString().length() > 0) {
					ib_cancel.setVisibility(View.VISIBLE);
					SearchListViewUi(s.toString());
				} else {
					ib_cancel.setVisibility(View.INVISIBLE);
					initSectionListViewUi();
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});

	}

	private ArrayList<FellowListData> sortFellowListData() {
		ArrayList<FellowListData> arrBufFellowListData = new ArrayList<FellowListData>();

		for (FellowListData data : App.m_arrFellowListData)
			arrBufFellowListData.add(data);

		Collections.sort(arrBufFellowListData, myComparator);

		App.m_arrFellowListData = null;
		App.m_arrFellowListData = new ArrayList<FellowListData>();

		for (FellowListData data : arrBufFellowListData)
			App.m_arrFellowListData.add(data);

		return App.m_arrFellowListData;
	}

	private ArrayList<FellowListData> SearchFellowList(String a_Keyword) {
		a_Keyword = a_Keyword.trim().replace(" ", "").toLowerCase();
		m_arrSearchFellowListData = null;
		m_arrSearchFellowListData = new ArrayList<FellowListData>();
		String strLowerKeyword = a_Keyword.toLowerCase();
		if(a_Keyword.length() != 0) {
			if (App.m_arrFellowListData != null) {
				for (FellowListData data : App.m_arrFellowListData) {
					if (data.m_strName != null) {
						if (data.m_strUserType.equals("R")) {
							if(StringMatcher.match(data.m_strName.toLowerCase(),strLowerKeyword)||StringMatcher.match(data.m_strDepartment.toLowerCase(),strLowerKeyword)||StringMatcher.match(data.m_strCompany.toLowerCase(),strLowerKeyword))
								m_arrSearchFellowListData.add(data);
						} else {
							if (StringMatcher.match(data.m_strName.toLowerCase(), strLowerKeyword)||StringMatcher.match(data.m_strAffiliation.toLowerCase(),strLowerKeyword)) {
								m_arrSearchFellowListData.add(data);
							}
						}
					}
				}
			}
		}
		return m_arrSearchFellowListData;
	}

	private void initSectionListViewUi() {
		if (App.m_arrFellowListData != null)
			sortFellowListData();
		sortFellowListData();

		m_lvFellowList = (ListView) m_vFellowList.findViewById(R.id.lv_fellowlist_list);

		m_ListItems = new ArrayList<FellowListData>();

		if (m_arrNewFellowListData != null) {
			for (FellowListData data : m_arrNewFellowListData) {
				// for (RegularSearchListData beforeData :
				// App.m_arrRegularSearchListDatas) {
				// if (beforeData.m_isChecked) {
				// if (data.m_nUserNo == beforeData.m_nUserNo) {
				// data.m_isChecked = true;
				// }
				//
				// }
				// }
				for (SearchListCheckData beforeData : App.m_arrSearchListCheckData) {
					// if (beforeData.m_isChecked) {
					if (data.m_nUserNo == beforeData.m_nUserNo) {
						data.m_isChecked = true;
					}
					// }
				}
				m_tvSectionText.setText(getString(R.string.layout_sectionstring_fellows) + "(" + m_arrNewFellowListData.size() + ")");
				m_ListItems.add(data);
			}
		}

		if (App.m_arrFellowListData != null) {
			for (FellowListData data : App.m_arrFellowListData) {
				// for (RegularSearchListData beforeData :
				// App.m_arrRegularSearchListDatas) {
				// if (beforeData.m_isChecked) {
				// if (data.m_nUserNo == beforeData.m_nUserNo) {
				// data.m_isChecked = true;
				// }
				//
				// }
				// }
				for (SearchListCheckData beforeData : App.m_arrSearchListCheckData) {
					// if (beforeData.m_isChecked) {
					if (data.m_nUserNo == beforeData.m_nUserNo) {
						data.m_isChecked = true;
					}
					// }
				}
				m_tvSectionText.setText(getString(R.string.layout_sectionstring_fellows) + "(" + App.m_arrFellowListData.size() + ")");
				m_ListItems.add(data);
			}
			if(App.m_arrFellowListData.size() == 0){
				m_cbAllcheck.setVisibility(View.GONE);
			}
		}

		m_FellowListAdapter = new FellowListAdapter();
		m_FellowListAdapter.areAllItemsEnabled();
		m_lvFellowList.setAdapter(m_FellowListAdapter);
	}

	private void SearchListViewUi(String a_Keyword) {
		m_lvFellowList = (ListView) m_vFellowList.findViewById(R.id.lv_fellowlist_list);

		SearchFellowList(a_Keyword.trim());

		m_ListItems = new ArrayList<FellowListData>();

		if (m_arrSearchFellowListData != null) {
			for (FellowListData data : m_arrSearchFellowListData) {
				// for (RegularSearchListData beforeData :
				// App.m_arrRegularSearchListDatas) {
				// if (beforeData.m_isChecked) {
				// if (data.m_nUserNo == beforeData.m_nUserNo) {
				// data.m_isChecked = true;
				// }
				//
				// }
				// }
				for (SearchListCheckData beforeData : App.m_arrSearchListCheckData) {
					// if (beforeData.m_isChecked) {
					if (data.m_nUserNo == beforeData.m_nUserNo) {
						data.m_isChecked = true;
					}
					// }
				}
				m_tvSectionText.setText(getString(R.string.layout_sectionstring_fellows) + " " + m_arrSearchFellowListData.size());
				m_ListItems.add(data);
			}
			if(m_arrSearchFellowListData.size() == 0){
				m_tvSectionText.setText(getString(R.string.layout_sectionstring_fellows) + " 0");
			}
		}

		m_SearchFellowListAdapter = new SearchFellowListAdapter();
		m_SearchFellowListAdapter.areAllItemsEnabled();
		m_lvFellowList.setAdapter(m_SearchFellowListAdapter);

	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		if(buttonView.getId() == R.id.cb_chat_allmember){
			if (m_isTouchCheckBox) {
				int nCheckList = 0;
				if (isChecked) {
					for (int i = 0; i < m_ListItems.size(); i++) {
						if(m_ListItems.get(i).m_isActive && m_ListItems.get(i).m_nUserNo != App.m_nChatbot && m_ListItems.get(i).m_nUserNo != 100) {
							SearchListCheckData addData = new SearchListCheckData(m_ListItems.get(i).m_nUserNo, m_ListItems.get(i).m_strName);
							((ChatInviteTabAct) m_Activity).addSearchList(addData);
							FellowListData data = m_ListItems.get(i);
							data.m_isChecked = true;
							m_ListItems.set(i, data);
							nCheckList++;
						}
					}
					if(nCheckList == 0) {
						m_isTouchCheckBox = false;
						m_cbAllcheck.setChecked(false);
					}
				} else {
					for (int i = 0; i < m_ListItems.size(); i++) {
						((ChatInviteTabAct) m_Activity).removeListData(m_ListItems.get(i).m_nUserNo);
						FellowListData data = m_ListItems.get(i);
						data.m_isChecked = false;
						m_ListItems.set(i, data);
					}
				}
				m_isTouchCheckBox = false;
				if(m_SectionListAdapter != null)
					m_SectionListAdapter.notifyDataSetChanged();
				if(m_SearchFellowListAdapter != null)
					m_SearchFellowListAdapter.notifyDataSetChanged();
				if(m_FellowListAdapter != null)
					m_FellowListAdapter.notifyDataSetChanged();
			} else {

			}
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if(v.getId() == R.id.cb_chat_allmember){
			m_isTouchCheckBox = true;
		}
		return false;
	}

	// FellowList Adapter
	private class FellowListAdapter extends BaseAdapter {

		public FellowListAdapter() {
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_ListItems != null)
				return m_ListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (m_ListItems != null)
				return m_ListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			FellowListData data = (FellowListData) m_ListItems.get(nPosition);

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new ChatroomInviteListItemLayout(m_Activity);

			((ChatroomInviteListItemLayout) convertView).setFellowListData(data);
			((ChatroomInviteListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);
			CheckBox cb_redaction = (CheckBox) ((ChatroomInviteListItemLayout) convertView).findViewById(R.id.cb_invite);

			if(!data.m_isActive || data.m_nUserNo == App.m_nChatbot && data.m_nUserNo != 100){
				cb_redaction.setVisibility(View.INVISIBLE);
			}

			if (cb_redaction.getVisibility() != View.INVISIBLE) {
				if (data.m_isChecked) {
					boolean is_redaction = false;
					ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;
					for (int i = 0; i < arrSearchListCheckData.size(); i++) {
						if (data.m_nUserNo == arrSearchListCheckData.get(i).m_nUserNo) {
							is_redaction = true;
							cb_redaction.setChecked(true);
							break;
						}
					}
					if (!is_redaction) {
						cb_redaction.setChecked(false);
					}

				} else
					cb_redaction.setChecked(false);
			}

			return convertView;
		}
	}

	// FellowList Adapter
	private class SearchFellowListAdapter extends BaseAdapter {

		public SearchFellowListAdapter() {
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_ListItems != null)
				return m_ListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (m_ListItems != null)
				return m_ListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			FellowListData data = (FellowListData) m_ListItems.get(position);

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new ChatroomInviteListItemLayout(m_Activity);

			((ChatroomInviteListItemLayout) convertView).setFellowListData(data);
			((ChatroomInviteListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);
			CheckBox cb_redaction = (CheckBox) ((ChatroomInviteListItemLayout) convertView).findViewById(R.id.cb_invite);
			if(!data.m_isActive || data.m_nUserNo == App.m_nChatbot && data.m_nUserNo != 100){
				cb_redaction.setVisibility(View.INVISIBLE);
			}

			if (cb_redaction.getVisibility() != View.INVISIBLE) {
				if (data.m_isChecked) {
					boolean is_redaction = false;
					ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;
					for (int i = 0; i < arrSearchListCheckData.size(); i++) {
						if (data.m_nUserNo == arrSearchListCheckData.get(i).m_nUserNo) {
							is_redaction = true;
							cb_redaction.setChecked(true);
							break;
						}
					}
					if (!is_redaction) {
						cb_redaction.setChecked(false);
					}

				} else
					cb_redaction.setChecked(false);
			}

			return convertView;
		}
	}

	ChatInviteTabAct.OnNotifyListener m_NotifyListner = new ChatInviteTabAct.OnNotifyListener() {

		@Override
		public void onNotify() {
			// TODO Auto-generated method stub

			if (m_SearchFellowListAdapter != null) {
				if (m_ListItems != null) {
					for (int i = 0; i < m_ListItems.size(); i++) {
						FellowListData listData = m_ListItems.get(i);
						if (App.m_arrSearchListCheckData.size() != 0) {
							for (SearchListCheckData data : App.m_arrSearchListCheckData) {
								if (listData.m_nUserNo == data.m_nUserNo) {
									listData.m_isChecked = true;
									m_ListItems.set(i, listData);
									break;
								} else {
									listData.m_isChecked = false;
									m_ListItems.set(i, listData);
								}
							}
						} else {
							listData.m_isChecked = false;
							m_ListItems.set(i, listData);
						}
					}
				}
				m_SearchFellowListAdapter.notifyDataSetChanged();
				m_cbAllcheck.setChecked(false);
			}
			if (m_FellowListAdapter != null) {
				if (m_ListItems != null) {
					for (int i = 0; i < m_ListItems.size(); i++) {
						FellowListData listData = m_ListItems.get(i);
						String strSetionName = getString(R.string.layout_sectionstring_fellows);
						if (App.m_arrSearchListCheckData.size() != 0) {
							for (SearchListCheckData data : App.m_arrSearchListCheckData) {
								if (listData.m_nUserNo == data.m_nUserNo) {
									listData.m_isChecked = true;
									m_ListItems.set(i, listData);
									break;
								} else {
									listData.m_isChecked = false;
									m_ListItems.set(i, listData);
								}
							}
						} else {
							listData.m_isChecked = false;
							m_ListItems.set(i, listData);
						}
					}
				}
				m_FellowListAdapter.notifyDataSetChanged();
				m_cbAllcheck.setChecked(false);
			}

		}
	};

	ChatroomInviteListItemLayout.OnCheckedChangedListener m_CheckedChangedListner = new ChatroomInviteListItemLayout.OnCheckedChangedListener() {

		@Override
		public void onChecked(boolean a_isChecked, int a_nUserId) {
			// TODO Auto-generated method stub
			if (a_isChecked) {
				boolean isSame = false;
				if (App.m_arrSearchListCheckData != null) {
					for (int i = 0; i < m_ListItems.size(); i++) {
						for (SearchListCheckData data : App.m_arrSearchListCheckData) {
							if (data.m_nUserNo == m_ListItems.get(i).m_nUserNo) {
								isSame = true;
								break;
							}  else if(!m_ListItems.get(i).m_isActive || m_ListItems.get(i).m_nUserNo == App.m_nChatbot || m_ListItems.get(i).m_nUserNo == 100){
								isSame = true;
								break;
							}
							else {
								isSame = false;
							}

						}
						if (!isSame) {
							break;
						}
					}
				}
				if (isSame) {
					m_cbAllcheck.setChecked(true);
				} else {
					m_cbAllcheck.setChecked(false);
				}
			} else {
				m_cbAllcheck.setChecked(false);
			}
		}
		
		@Override
		public void onDataSetChagnged() {
			// TODO Auto-generated method stub
			if(m_SectionListAdapter != null)
			m_SectionListAdapter.notifyDataSetChanged();
			if(m_SearchFellowListAdapter != null)
			m_SearchFellowListAdapter.notifyDataSetChanged();
			if(m_FellowListAdapter != null)
			m_FellowListAdapter.notifyDataSetChanged();
		}
	};
	private final static Comparator<FellowListData> myComparator = new Comparator<FellowListData>() {
		private final Collator collator = Collator.getInstance(new Locale("ko"));

		@Override
		public int compare(FellowListData lhs, FellowListData rhs) {
			// TODO Auto-generated method stub
			boolean isLeftNumber = true;
			boolean isRightNumber = true;
			char leftChar = lhs.m_strName.charAt(0);
			char rightChar = rhs.m_strName.charAt(0);

			if(leftChar < '0' || leftChar > '9'){
				isLeftNumber = false;
			} 
			if(rightChar < '0' || rightChar > '9'){
				isRightNumber = false;
			}
			
			if(isLeftNumber && !isRightNumber){
				return 1;
			} else if(!isLeftNumber && isRightNumber){
				return -1;
			} else
				return collator.compare(lhs.m_strName, rhs.m_strName);
		}

	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		}
	}

	private void requestUpdateUserList(){
		SharedPref pref = SharedPref.getInstance(m_Activity);
		String strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

		GetUserListReq req = new GetUserListReq(strTimeStamp);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);
				if (res.getUserListData() != null) {
					SparseArray<UserListData> savedUserListData = TTalkDBManager.ContactsDBManager.getContactsReturnSparseArray(m_Activity);
					ArrayList<UserListData> arrInsertUserListData = new ArrayList<UserListData>();
					ArrayList<UserListData> arrUpdateUserListData = new ArrayList<UserListData>();

					for (UserListData data : res.getUserListData()) {
//						UserListData getitem = ContactsDBManager.getContacts(m_Activity, data.m_nUserNo);
						UserListData getitem = savedUserListData.get(data.m_nUserNo);
						if (getitem == null) {
							UserListData item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable,
									data.m_isActive, data.m_strGreeting, data.m_strUserStatus, false, "");
//							ContactsDBManager.insertContacts(m_Activity, item);
							arrInsertUserListData.add(item);
						} else {
							UserListData item = null;
							if (data.m_strUserStatus.equals("A"))
								item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, getitem.m_strFellowAddTime);
							else
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, "");

//							ContactsDBManager.updateContacts(m_Activity, item);
							arrUpdateUserListData.add(item);
						}
					}
					if(arrInsertUserListData.size() > 0 )
						TTalkDBManager.ContactsDBManager.insertContacts(m_Activity, arrInsertUserListData);
					if(arrUpdateUserListData.size() > 0 )
						TTalkDBManager.ContactsDBManager.updateContacts(m_Activity, arrUpdateUserListData);
				}

				SharedPref pref = SharedPref.getInstance(m_Activity);
				pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);

				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					initSearch();
					initSectionListViewUi();
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				((ChatInviteTabAct)m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
			}
		});
	}

	private ArrayList<FellowListData> setFellowList() throws Exception {
		ArrayList<UserListData> arrAddedFellowListData = TTalkDBManager.ContactsDBManager.getContactsByFellows(m_Activity);
		App.m_arrFellowListData = new ArrayList<FellowListData>();
		CommonLog.e("", "setFellowList() lol : " + App.m_EntryData.m_strLol);
		for (UserListData data : arrAddedFellowListData) {
			HashMap<String, String> personalData = data.m_PersonalData.mapPersonalData;
			if (data.m_strUserType.equals("R")) {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_NAME),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
						personalData.get(PersonalData.CHARGE), data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			} else {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME), "", "",personalData.get(PersonalData.POSITION),"","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
						data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			}
		}
		return App.m_arrFellowListData;
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}