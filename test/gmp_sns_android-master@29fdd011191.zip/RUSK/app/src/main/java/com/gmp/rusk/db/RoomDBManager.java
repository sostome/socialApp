package com.gmp.rusk.db;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;

import com.gmp.rusk.datamodel.ChattingRoomInfoData;

public class RoomDBManager {
	
	private RoomDBAdapter m_dbAdapter = null;
	
	public RoomDBManager(Context a_Context)
	{
		m_dbAdapter = new RoomDBAdapter(a_Context);
	}
	
	public void open()
	{
		m_dbAdapter.open();
	}
	
	public void openReadOnly()
	{
		m_dbAdapter.openReadOnly();
	}
	
	public void close()
	{
		m_dbAdapter.close();
	}
	
	/**
	 * insertRoom 채팅방 ArrayList 추가
	 * 
	 * @param a_Context
	 * @param a_arrRoomListData
	 * @return 추가한 Item의 개수
	 */
	public int insertRoom(ArrayList<ChattingRoomInfoData> a_arrRoomListData) {
		return m_dbAdapter.insertRoom(a_arrRoomListData);
	}

	/**
	 * insertRoom 채팅방 단일 추가
	 * 
	 * @param a_Context
	 * @param a_roomData
	 * @return 추가한 Item의 개수
	 */
	public int insertRoom(ChattingRoomInfoData a_roomData) {
		return m_dbAdapter.insertRoom(a_roomData);
	}

	/**
	 * updateRoom 채팅방 Array 수정 roomid == roomid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_arrRoomData
	 * @return 수정한 Item의 개수
	 */
	public int updateRoom(ArrayList<ChattingRoomInfoData> a_arrRoomData) {
		return m_dbAdapter.updateRoom(a_arrRoomData);
	}

	/**
	 * updateRoom 채팅방 단일 수정 roomid == roomid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_roomData
	 * @return 수정한 Item의 개수
	 */
	public int updateRoom(ChattingRoomInfoData a_roomData) {
		return m_dbAdapter.updateRoom(a_roomData);
	}
	
	/**
	 * updateRoom 채팅방 방장 수정 roomid == roomid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_strRoomId
	 * @param a_nRoomOwnerId
	 * @return 수정한 Item의 개수
	 */
	public int updateRoom(String a_strRoomId, int a_nRoomOwnerId) {
		return m_dbAdapter.updateRoom(a_strRoomId, a_nRoomOwnerId);
	}
	
	/**
	 * updateRoom 채팅방 Title 수정 roomid == roomid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_strRoomId
	 * @param a_strTitle
	 * @param a_isTitleEdited
	 * @return 수정한 Item의 개수
	 */
	public int updateRoom(String a_strRoomId, String a_strTitle, boolean a_isTitleEdited) {
		return m_dbAdapter.updateRoom(a_strRoomId, a_strTitle, a_isTitleEdited);
	}
	
	/**
	 * updateRoom 채팅방 Alarm 수정 roomid == roomid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_strRoomId
	 * @param a_isAlarmOn
	 * @return 수정한 Item의 개수
	 */
	public int updateRoom(String a_strRoomId, boolean a_isAlarmOn) {
		return m_dbAdapter.updateRoom(a_strRoomId, a_isAlarmOn);
	}
	
	/**
	 * updateRoomFavorite 채팅방 즐겨찾기 수정 roomid == roomid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_strRoomId
	 * @param a_isFavorite
	 * @return 수정한 Item의 개수
	 */
	public int updateRoomFavorite(String a_strRoomId, boolean a_isFavorite) {
		return m_dbAdapter.updateRoomFavorite(a_strRoomId, a_isFavorite);
	}

	/**
	 * deleteRoom 채팅방 전체 삭제
	 * 
	 * @param a_Context
	 * @return 삭제한 Item의 개수
	 */
	public int deleteRoom() {
		return m_dbAdapter.deleteRoom();
	}

	/**
	 * deleteRoom 채팅방 삭제
	 * 
	 * @param a_Context
	 * @param a_nUserNo
	 *            삭제할 UserNo
	 * @return 삭제한 Item의 개수
	 */
	public int deleteRoom(String a_strRoomId) {
		return m_dbAdapter.deleteRoom(a_strRoomId);
	}

	public ArrayList<ChattingRoomInfoData> getChattingRoom() {
		ArrayList<ChattingRoomInfoData> arrRoomInfo = new ArrayList<ChattingRoomInfoData>();
		Cursor cursor = m_dbAdapter.getRoomList();
		if (cursor.moveToFirst()) {
			do {
				String strRoomId = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMID));
				String strRoomTitle = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMTITLE));
				int nRoomOwnerId = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMOWNERID));
				boolean isAlarmOn = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
				boolean isTitleEdited = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISTITLEDITED)) == 1 ? true : false;
				boolean isFavorite = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISFAVORITE)) == 1 ? true : false;

				ChattingRoomInfoData data = new ChattingRoomInfoData(strRoomId, strRoomTitle, isAlarmOn, nRoomOwnerId, isTitleEdited, isFavorite);
				arrRoomInfo.add(data);

			} while (cursor.moveToNext());
		}

		cursor.close();
		return arrRoomInfo;
	}
	
	public ChattingRoomInfoData getChattingRoom(String a_strRoomId) {
		ChattingRoomInfoData roomInfoData = null;

		Cursor cursor = m_dbAdapter.getRoom(a_strRoomId);
		if (cursor.moveToFirst()) {
			String strRoomId = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMID));
			String strRoomTitle = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMTITLE));
			int nRoomOwnerId = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMOWNERID));
			boolean isAlarmOn = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
			boolean isTitleEdited = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISTITLEDITED)) == 1 ? true : false;
			boolean isFavorite = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISFAVORITE)) == 1 ? true : false;

			roomInfoData = new ChattingRoomInfoData(strRoomId, strRoomTitle, isAlarmOn, nRoomOwnerId, isTitleEdited, isFavorite);
		}

		cursor.close();

		return roomInfoData;
	}
	
	public boolean isRoomAlarm(String a_strRoomId)
	{
		boolean isAlarm = true;
		Cursor cursor = m_dbAdapter.getRoom(a_strRoomId);
		if (cursor.moveToFirst()) {
			isAlarm = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
		}

		cursor.close();
		
		return isAlarm;
	}
	
	public boolean isRoomFavorite(String a_strRoomId)
	{
		boolean isAlarm = true;
		Cursor cursor = m_dbAdapter.getRoom(a_strRoomId);
		if (cursor.moveToFirst()) {
			isAlarm = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISFAVORITE)) == 1 ? true : false;
		}

		cursor.close();
		
		return isAlarm;
	}
}
