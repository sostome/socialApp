package com.gmp.rusk.datamodel;

public class AesDecoderData {
	public String m_strName = "";			//이름
	public String m_strDepartment = "";		//부서
	public String m_strParentDepartment = "";			//소속	
	
	public AesDecoderData(String a_strName, String a_strDepartment, String a_strParentDepartment) {
		m_strName = a_strName;
		m_strDepartment = a_strDepartment;
		m_strParentDepartment = a_strParentDepartment;
	}
}
