package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.CompanyEntryData;
import com.gmp.rusk.datamodel.NoticeChannelData;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface ChannelResObject {

    public final String JSON_CHANNELNO = "channelNo";
    public final String JSON_NAME = "name";
    public final String JSON_OWNER = "owner";
    public final String JSON_OWNERUSERNO = "ownerUserNo";
    public final String JSON_INVITATIONCOUNT = "invitaionCount";
    public final String JSON_MEMBERCOUNT = "memberCount";
    public final String JSON_STATUS = "status";
    public final String JSON_CHANNELNOTICONFIG = "channelNotiConfig";
    public final String JSON_THREADNOTIFICATION = "threadNotification";
    public final String JSON_COMMENTNOTIFICATION = "commentNotification";
    public final String JSON_NOTICECHANNELNO = "noticeChannelNo";
    public final String JSON_NOTICECHANNELNAME = "noticeChannelName";

    public final String JSON_NOTICECHANNELS = "noticeChannels";
    public final String JSON_RESULTS = "results";
    public final String JSON_INVITATIONS = "invitations";

    public void parseChannelData();
    public void parseChannelListData();
    public ChannelData getChannelData();
    public ArrayList<NoticeChannelData> getNoticeChannelListData();
    public ArrayList<ChannelData> getMemberChannelListData();
    public ArrayList<ChannelData> getInvitingChannelListData();
}
