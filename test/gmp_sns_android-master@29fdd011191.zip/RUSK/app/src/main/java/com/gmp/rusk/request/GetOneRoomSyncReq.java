package com.gmp.rusk.request;



/**
 *	@author kch
 *			개인방 동기화 요청
 *			method : get
 */

public class GetOneRoomSyncReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";
	
	
	public GetOneRoomSyncReq()
	{
		APINAME = APINAME + "/" + App.m_MyUserInfo.m_nUserNo + "/sync";
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
