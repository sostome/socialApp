package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.ApprovalListData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.ApprovalUserListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetSearchApprovalUserReq;
import com.gmp.rusk.request.PostSearchUserReq;
import com.gmp.rusk.response.GetSearchApprovalUserRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;

public class PartnerApprovalReqAct extends Activity implements OnClickListener, AdapterView.OnItemSelectedListener {
	public MyApp App = MyApp.getInstance();
	private LinearLayout m_layoutApprovalList = null;
	private ListView m_lvApprovalList = null;
	private ApprovalListAdapter m_ApprovalListAdapter = null;
	TextView m_tvSearchList = null;

	ArrayList<UserInfoData> m_arrApprovalSearchListDatas = null;

	EditText et_search_keyword;
	ImageButton ib_cancel;

	LinearLayout layout_hinttext,layout_nolisttext;

	public String m_strImageUrlTemplate = "";
	public String m_strUserId = "";
	public String m_strPassword = "";
	public String m_strMobile = "";

	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;
	private boolean m_isPartner = true;

	public boolean m_isRunning = false;

	Spinner spn_search_type;
	TextView tv_spinner_text;
	String m_strCurrentSelTeamCode = "";

	ArrayAdapter<String> adspin;
	ArrayList<String> m_arrSKTTeamList = null;
	ArrayList<String> m_arrSKTTeamCodeList = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_partner_approvalreq);

		// data 가져 오는 부분 구현
		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_isPartner = bundle.getBoolean(IntentKeyString.INTENT_KEY_USERID_TYPE, true);
			m_strUserId = bundle.getString(IntentKeyString.INTENT_KEY_USERID_ID);
			m_strPassword = bundle.getString(IntentKeyString.INTENT_KEY_USERID_PW);
			m_strMobile = bundle.getString(IntentKeyString.INTENT_KEY_USERID_MOBILE);
		}
		setResult(Activity.RESULT_CANCELED);
		initSearchRegular();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == StaticString.REQUESTCODE_PARTNER_SIGNUP) {
			if (resultCode == Activity.RESULT_OK) {
				setResult(Activity.RESULT_OK);
				finish();
			}
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	private void initSearchRegular() {
		ImageView ivCancel = (ImageView)findViewById(R.id.btn_cancel);
		ivCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		m_layoutApprovalList = (LinearLayout) findViewById(R.id.layout_search_list);
		m_layoutApprovalList.setVisibility(View.GONE);
		m_tvSearchList = (TextView) findViewById(R.id.tv_search_result);
		m_lvApprovalList = (ListView) findViewById(R.id.lv_approvallist_list);
		m_lvApprovalList.setVisibility(View.GONE);

		layout_hinttext = (LinearLayout) findViewById(R.id.layout_hinttext);
		layout_hinttext.setVisibility(View.VISIBLE);

		layout_nolisttext = (LinearLayout) findViewById(R.id.layout_no_list);
		layout_nolisttext.setVisibility(View.GONE);

		et_search_keyword = (EditText) findViewById(R.id.et_search_keyword);
		// et_search_keyword.setImeOptions(EditorInfo.IME_ACTION_SEARCH);

		m_arrSKTTeamList = new ArrayList<>();
		m_arrSKTTeamCodeList = new ArrayList<>();
		for (int i = 0 ; i < App.m_EntryData.m_arrCompanyData.size() ; i++) {
				m_arrSKTTeamList.add(App.m_EntryData.m_arrCompanyData.get(i).strName);
				m_arrSKTTeamCodeList.add(App.m_EntryData.m_arrCompanyData.get(i).strCode);
		}
		adspin = new ArrayAdapter<String>(this, R.layout.layout_spinner_textview, m_arrSKTTeamList);
		tv_spinner_text = (TextView) findViewById(R.id.tv_spinner_text);
		spn_search_type = (Spinner) findViewById(R.id.spn_search_type);
		adspin.setDropDownViewResource(R.layout.spinner_custom_list_item);
		spn_search_type.setAdapter(adspin);
		spn_search_type.setOnItemSelectedListener(this);

		ib_cancel = (ImageButton) findViewById(R.id.ib_cancel);
		ib_cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				et_search_keyword.setText("");
				//initSearchRegular();
			}
		});

		et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				CommonLog.e("EditAction", "actionId1 : " + actionId);

				switch (actionId) {
				case EditorInfo.IME_ACTION_SEARCH:
					if(!Utils.UseChar(v.getText().toString()))
					{
						m_Popup = new CommonPopup(PartnerApprovalReqAct.this, PartnerApprovalReqAct.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(
								getString(R.string.pop_error_title).toString(),
								getString(R.string.regular_expression_search).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
						return false;
					}
					
					if(v.getText().toString().trim().length() > 1)
						requestApprovalUser(m_strCurrentSelTeamCode, v.getText().toString());
					else
					{
						m_Popup = new CommonPopup(PartnerApprovalReqAct.this, PartnerApprovalReqAct.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(
								getString(R.string.pop_error_title).toString(),
								getString(R.string.popup_search_length).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
					break;
				}
				return false;
			}
		});

		et_search_keyword.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if (s.toString().length() > 0) {
					ib_cancel.setVisibility(View.VISIBLE);
				} else {
					ib_cancel.setVisibility(View.INVISIBLE);
					layout_hinttext.setVisibility(View.VISIBLE);
					m_layoutApprovalList.setVisibility(View.GONE);
					m_lvApprovalList.setVisibility(View.GONE);
					layout_nolisttext.setVisibility(View.GONE);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			}
			else
				popup_ok_long.cancel();
		}
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		tv_spinner_text.setText(m_arrSKTTeamList.get(position));
		m_strCurrentSelTeamCode = m_arrSKTTeamCodeList.get(position);
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {

	}

	// AddedByPartnerList Adapter
	private class ApprovalListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_arrApprovalSearchListDatas != null)
				return m_arrApprovalSearchListDatas.size();

			return 0;
		}

		@Override
		public Object getItem(int position) {
			// if(position == 0) return header;

			if (m_arrApprovalSearchListDatas != null)
				return m_arrApprovalSearchListDatas.get(position);

			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			UserInfoData data = m_arrApprovalSearchListDatas.get(nPosition);

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new ApprovalUserListItemLayout(PartnerApprovalReqAct.this);

			((ApprovalUserListItemLayout) convertView).setApprovalSearchListData(data, m_strImageUrlTemplate);

			((ApprovalUserListItemLayout) convertView).setApprovalRequestListener(m_ApprovalRequestListner);

			return convertView;
		}
	}

	private void setRegularSearchApdapter() {
		m_layoutApprovalList.setVisibility(View.VISIBLE);
		m_lvApprovalList.setVisibility(View.VISIBLE);
		if (m_arrApprovalSearchListDatas != null && m_arrApprovalSearchListDatas.size() > 0) {
			m_tvSearchList.setText(getString(R.string.layout_sectionstring_search_result)+" "+m_arrApprovalSearchListDatas.size());
			layout_hinttext.setVisibility(View.GONE);
			layout_nolisttext.setVisibility(View.GONE);
			m_ApprovalListAdapter = new ApprovalListAdapter();

			m_lvApprovalList.setAdapter(m_ApprovalListAdapter);

			m_lvApprovalList.setOnScrollListener(new OnScrollListener() {

				@Override
				public void onScrollStateChanged(AbsListView view, int scrollState) {
					// TODO Auto-generated method stub

				}

				@Override
				public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
					// TODO Auto-generated method stub

				}
			});
		}
		else
    	{
			m_layoutApprovalList.setVisibility(View.GONE);
			m_lvApprovalList.setVisibility(View.GONE);
    		layout_hinttext.setVisibility(View.GONE);
			layout_nolisttext.setVisibility(View.VISIBLE);
    	}
	}

	private void requestApprovalUser(String a_strCompanyCode, String a_strKeyword) {
		showProgress();
		GetSearchApprovalUserReq req = new GetSearchApprovalUserReq(a_strCompanyCode, a_strKeyword);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetSearchApprovalUserRes res = new GetSearchApprovalUserRes(a_strData, Res.RES_TYPE_USER_INFO);

				m_arrApprovalSearchListDatas = null;
				if(res.getUserInfoDatas() != null)
				{
					m_arrApprovalSearchListDatas = res.getUserInfoDatas();
				}
				else
				{
				}
				
				closeProgress();
				setRegularSearchApdapter();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(PartnerApprovalReqAct.this, PartnerApprovalReqAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(PartnerApprovalReqAct.this, PartnerApprovalReqAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(PartnerApprovalReqAct.this, PartnerApprovalReqAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(PartnerApprovalReqAct.this, PartnerApprovalReqAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}

			}
		});
	}

	ApprovalUserListItemLayout.OnApprovalRequestListener m_ApprovalRequestListner = new ApprovalUserListItemLayout.OnApprovalRequestListener() {

		@Override
		public void onApprovalRequest(int a_nApprovalUserNo, String a_strApprovalUserName) {
			// TODO Auto-generated method stub
			Intent intent = new Intent(PartnerApprovalReqAct.this, PartnerSignUpAct.class);
			intent.putExtra(IntentKeyString.INTENT_KEY_USERID_TYPE, m_isPartner);
			if (!m_isPartner) {
				intent.putExtra(IntentKeyString.INTENT_KEY_USERID_ID, m_strUserId);
			}

			intent.putExtra(IntentKeyString.INTENT_KEY_USERID_APPROVAL_USERNO, a_nApprovalUserNo);
			intent.putExtra(IntentKeyString.INTENT_KEY_USERID_APPROVAL_USERNAME, a_strApprovalUserName);
			startActivityForResult(intent, StaticString.REQUESTCODE_PARTNER_SIGNUP);
		}
	};

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}
}
