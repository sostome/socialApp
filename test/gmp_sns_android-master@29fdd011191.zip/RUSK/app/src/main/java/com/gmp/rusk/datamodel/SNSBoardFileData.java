package com.gmp.rusk.datamodel;

public class SNSBoardFileData {

	public static final String FILETYPE_ETC		= "N";
	public static final String FILETYPE_THUMBNAIL = "T";
	
	public int m_nFileId = -1;
	
	public String m_strFileName = "";
	public long m_lnFileSize = 0L;
	
	// 일반 첨부파일
	public String m_strFileURL = "";
	public String m_strPreviewFileURL = "";
	public String m_strFileType = "";
	
	// 클라우드 파일
	public String m_strDocId = "";
}
