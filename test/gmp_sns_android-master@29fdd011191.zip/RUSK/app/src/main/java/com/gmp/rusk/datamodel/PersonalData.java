package com.gmp.rusk.datamodel;

import java.util.HashMap;

/**
 * Created by K on 2017-08-07.
 */

public class PersonalData {

    final public static String NAME = "name";
    final public static String EMAIL = "email";
    final public static String MOBILE = "mobile";
    final public static String COMPANY_CODE = "company_code";
    final public static String COMPANY_NAME = "company_name";
    final public static String DEPARTMENT = "department";
    final public static String PARENT_DEPARTMENT = "parent_department";
    final public static String CHARGE = "charge";
    final public static String POSITION = "position";
    final public static String SECOND_CHARGE = "second_charge";
    final public static String AFFILIATION = "affiliation";

    public HashMap<String, String> mapPersonalData = new HashMap<String, String>();

    public PersonalData(HashMap<String, String> mapData){
        mapPersonalData = mapData;
    }
    public PersonalData(String a_strName, String a_strEmail, String a_strMobile, String a_strCompanyCode, String a_strCompanyName, String a_strDepartment, String a_strParentDepartment, String a_strCharge, String a_strPosition, String a_strSecondCharge, String a_strAffiliation){

        mapPersonalData.put(NAME, a_strName);
        mapPersonalData.put(EMAIL, a_strEmail);
        mapPersonalData.put(MOBILE, a_strMobile);
        mapPersonalData.put(COMPANY_CODE, a_strCompanyCode);
        if(a_strCompanyName == null)
            a_strCompanyName = "";
        mapPersonalData.put(COMPANY_NAME, a_strCompanyName);
        if(a_strDepartment == null)
            a_strDepartment = "";
        mapPersonalData.put(DEPARTMENT, a_strDepartment);
        if(a_strParentDepartment == null)
            a_strParentDepartment = "";
        mapPersonalData.put(PARENT_DEPARTMENT, a_strParentDepartment);
        if(a_strCharge == null)
            a_strCharge = "";
        mapPersonalData.put(CHARGE, a_strCharge);
        if(a_strPosition == null)
            a_strPosition = "";
        mapPersonalData.put(POSITION, a_strPosition);
        if(a_strSecondCharge == null)
            a_strSecondCharge = "";
        mapPersonalData.put(SECOND_CHARGE, a_strSecondCharge);
        if(a_strAffiliation == null)
            a_strAffiliation = "";
        mapPersonalData.put(AFFILIATION, a_strAffiliation);

    }

}
