package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChannelNoticeData;
import com.gmp.rusk.datamodel.ChannelThreadData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.datamodel.SNSGroupSearchListData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.fragment.MainChannelFlag;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.listview.LoadMoreListView;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteBoardLikeReq;
import com.gmp.rusk.request.GetChannelNoticeListReq;
import com.gmp.rusk.request.GetGroupBoardReq;
import com.gmp.rusk.request.PostBoardLikeReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetChannelNoticeListRes;
import com.gmp.rusk.response.GetGroupBoardRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SNSNoticeSearchAct extends CustomActivity implements OnClickListener{

    private int m_nGroupId = -1;
    private String m_strGroupName = "";
    private ArrayList<ChannelNoticeData> m_arrChannelNoticeData;

    CommonPopup m_Popup = null;

    EditText et_search_keyword;
    ImageView m_btnTopClose;
    ImageButton ib_cancel;
    TextView tv_search_count;
    RelativeLayout layout_hinttext;
    RelativeLayout layout_notfound;
    TextView m_ivHashTagIcon;


    ArrayAdapter<CharSequence>  adspin;
    private InputMethodManager imm;

    private FrameLayout layout_groupdetail_searchbylist_list = null;

    @Override
    protected void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);

        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.act_snsnotice_search);
        //이미 검색 창이 떠있다면 제거
        boolean isAlreadyActivity = false;
        Activity alreadyActivity = null;
        for(Activity activity : App.m_arrActivitys){
            if(activity.getClass().getSimpleName().equals("SNSNoticeSearchAct")){
                if(!isAlreadyActivity){
                    isAlreadyActivity = true;
                    alreadyActivity = activity;
                } else {
                    alreadyActivity.finish();
                    break;
                }
            }

        }
        getIntentData();
        initSearchRegular();
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
    }

    private void getIntentData()
    {
        m_nGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID,0);
        m_strGroupName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME);
    }


    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        int nId = v.getId();
        if(nId == R.id.ib_pop_ok_long)
        {
            CommonPopup popup_cancel = (CommonPopup)v.getTag();
            popup_cancel.cancel();
        }
        else if(nId == R.id.ib_pop_ok)
        {
            CommonPopup popup_cancel = (CommonPopup)v.getTag();
            popup_cancel.cancel();
        }
        else if(nId == R.id.ib_pop_cancel)
        {
            CommonPopup popup_cancel = (CommonPopup)v.getTag();
            popup_cancel.cancel();
        }

        super.onClick(v);
    }


    private void initSearchRegular()
    {
        TextView tvSNSNoticeTitle = (TextView)findViewById(R.id.tv_snsnotice_title);
        tvSNSNoticeTitle.setText(m_strGroupName);
        m_ivHashTagIcon = (TextView) findViewById(R.id.tv_icon_hash);
        layout_groupdetail_searchbylist_list = (FrameLayout) findViewById(R.id.layout_groupdetail_searchbylist_list);
        m_btnTopClose = (ImageView) findViewById(R.id.btn_top_close);
        m_btnTopClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        layout_groupdetail_searchbylist_list.setVisibility(View.GONE);

        tv_search_count = (TextView)findViewById(R.id.tv_search_count);

        adspin = ArrayAdapter.createFromResource(this, R.array.arr_groupdetail_search_type, R.layout.layout_spinner_textview);


        layout_hinttext = (RelativeLayout)findViewById(R.id.layout_hinttext);
        layout_notfound = (RelativeLayout)findViewById(R.id.layout_notfound);

        //해시태그 페이지가 제일 처음
        layout_hinttext.setVisibility(View.VISIBLE);
        layout_notfound.setVisibility(View.GONE);
        et_search_keyword = (EditText)findViewById(R.id.et_search_keyword);
        if(imm != null && et_search_keyword != null)
            imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
        ib_cancel = (ImageButton) findViewById(R.id.ib_cancel);
        ib_cancel.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                et_search_keyword.setText("");
                initSearchRegular();
            }
        });

        et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // TODO Auto-generated method stub
                CommonLog.e("EditAction", "actionId1 : "+actionId);

                switch(actionId) {
                    case EditorInfo.IME_ACTION_SEARCH:
                        if(v.getText().toString().trim().length() > 1)
                        {
                            getChannelNoticeDetail(m_nGroupId,v.getText().toString().trim());
                        }
                        else
                        {
                            m_Popup = new CommonPopup(SNSNoticeSearchAct.this, SNSNoticeSearchAct.this,
                                    CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                            m_Popup.setBodyAndTitleText(
                                    getString(R.string.pop_error_title).toString(),
                                    getString(R.string.popup_search_length_in_notice_channel).toString());
                            m_Popup.setCancelable(false);
                            isCheckShowPopup();
                        }
                        break;
                }
                return false;
            }
        });

        et_search_keyword.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
                if(s.toString().length()>0)
                {
                    ib_cancel.setVisibility(View.VISIBLE);
                }
                else
                {
                    ib_cancel.setVisibility(View.INVISIBLE);
                    layout_notfound.setVisibility(View.INVISIBLE);
                    layout_hinttext.setVisibility(View.VISIBLE);
                    layout_groupdetail_searchbylist_list.setVisibility(View.GONE);

                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });

    }

    private void getChannelNoticeDetail(final int a_nChannelId,String a_strKeyword){
        GetChannelNoticeListReq req = new GetChannelNoticeListReq(a_nChannelId,a_strKeyword);
        WebAPI webAPI = new WebAPI(this);
        webAPI.request(req, new WebListener() {
            @Override
            public void onPreRequest() {

            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                closeProgress();
                if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(SNSNoticeSearchAct.this, new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();

                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
                else
                    showErrorPopup(nErrorCode, strMessage);
            }

            @Override
            public void onPostRequest(String a_strData) {
                closeProgress();
                GetChannelNoticeListRes res = new GetChannelNoticeListRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_NOTICE_LIST);
                m_arrChannelNoticeData = res.getChannelNoticeListData();
           /*     CommonLog.e("dddddddddddd","채널 노티스 : "+m_arrChannelNoticeData.size());
                CommonLog.e("dddddddddddd","채널 노티스 0번째 :"+m_arrChannelNoticeData.get(0).m_strTitle);*/
                if(m_arrChannelNoticeData.size() != 0 )
                    setNoticeUI();
                else{
                    layout_groupdetail_searchbylist_list.setVisibility(View.GONE);
                    layout_hinttext.setVisibility(View.GONE);
                    layout_notfound.setVisibility(View.VISIBLE);
                }

            }
        });
    }

    private void setNoticeUI(){
        layout_groupdetail_searchbylist_list.setVisibility(View.VISIBLE);
        layout_hinttext.setVisibility(View.GONE);
        layout_notfound.setVisibility(View.GONE);
        ListView lvChannelNoticeList = (ListView)findViewById(R.id.lv_channel_content_notice);
        ChannelNoticeListAdapter noticeListAdapter = new ChannelNoticeListAdapter();
        lvChannelNoticeList.setAdapter(noticeListAdapter);
    }

    private class ChannelNoticeListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return m_arrChannelNoticeData.size();
        }

        @Override
        public Object getItem(int position) {
            return m_arrChannelNoticeData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null)
            {
                LayoutInflater li = LayoutInflater.from(getApplicationContext());
                convertView = li.inflate(R.layout.layout_channel_noticelist_item, parent, false);
            }

            final ChannelNoticeData noticeData = m_arrChannelNoticeData.get(position);
            RelativeLayout layoutNoticeList = (RelativeLayout)convertView.findViewById(R.id.layout_channel_noticelist);
            TextView tvNoticeListText = (TextView)convertView.findViewById(R.id.tv_channel_noticelist_text);
            tvNoticeListText.setText(noticeData.m_strTitle);

            layoutNoticeList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(SNSNoticeSearchAct.this, ChannelNoticeDetailAct.class);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_NAME, m_strGroupName);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_TITLE, noticeData.m_strTitle);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_BODY, noticeData.m_strBody);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_FILE, "");
                    startActivity(intent);
                }
            });
            return convertView;
        }
    }


    private void isCheckShowPopup() {
        if (super.m_isRunning) {
            m_Popup.show();
        }
    }

}
