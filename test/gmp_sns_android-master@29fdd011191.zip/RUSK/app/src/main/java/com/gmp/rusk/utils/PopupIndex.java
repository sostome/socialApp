package com.gmp.rusk.utils;

public class PopupIndex {

	public final static int INDEX_PREVPOP_CHANGE_DEVICE = 1;
	public final static int INDEX_PREVPOPUP_OUT = 2;
	public final static int INDEX_PREVPOPUP_OUT_SUCCESS = 3;
	public final static int INDEX_PREVPOPUP_COMPLETE_ALL = 4;
	public final static int INDEX_PREVPOPUP_COMPLETE = 5;
	public final static int INDEX_PREVPOPUP_DENIAL = 6;
	public final static int INDEX_PREVPOPUP_COMPLETE_ALL_SUCCESS = 7;
	public final static int INDEX_PREVPOPUP_COMPLETE_SUCCESS = 8;
	public final static int INDEX_PREVPOPUP_DENIAL_SUCCESS = 9;
	public final static int INDEX_PREVPOPUP_REQ_ID_EMAIL = 10;
	public final static int INDEX_PREVPOPUP_SAVEGREETING = 11;
	public final static int INDEX_PREVPOPUP_CHANGE_PASSWORD = 12;
	public final static int INDEX_PREVPOP_SESSION_EXPIRE = 13;
	public final static int INDEX_PREVPOP_REQRECOMMAND = 14;
	public final static int INDEX_PREVPOP_ADDEDBYFELLOW = 15;
	public final static int INDEX_PREVPOP_SEND_NOTICE = 16;
	public final static int INDEX_PREVPOPUP_REAPPROVAL = 17;
	public final static int INDEX_PREVPOPUP_SEND_URL = 18;
	
	
	public final static int INDEX_PREVPOP_NOT_FINISH = 99;
	public final static int INDEX_PREVPOPUP_APP_FINISH = 100;
	public final static int INDEX_PREVPOPUP_FINISH = 101;
	public final static int INDEX_PREVPOPUP_HTTP_SERVER_UNAUTHORIZED = 102;
	public final static int INDEX_PREVPOPUP_NEW_VERSION = 103;
	public final static int INDEX_PREVPOPUP_XMPP_ERROR = 104;
	public final static int INDEX_PREVPOPUP_SYSNOTICE = 105;
	public final static int INDEX_PREVEPOPUP_PERMISSION_FAIL = 106;
	public final static int INDEX_PREVPOPUP_NEW_VERSION_PARTNER_FIRST = 107;
	public final static int INDEX_PREVPOPUP_CONFIRM_SNS_INVITE = 108;

}
