package com.gmp.rusk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.utils.CommonLog;

/**
 * Created by kang on 2017-08-22.
 */

public class MainUserSearchFlag extends Fragment {

    private FragmentActivity m_Activity = null;
    private InputMethodManager imm;
    public boolean m_isRunning = false;
    MyApp App = MyApp.getInstance();
    EditText et_search_keyword;

    View m_UserSearchTab;
    FrameLayout m_TabComtainer;
    FragmentTabHost tabHost;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        m_Activity = getActivity();
        imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
    }
    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        m_isRunning = false;
    }

    @Override
    public void onStop() {
        // TODO Auto-generated method stub
        super.onStop();
        m_isRunning = false;
    }
    @Override
    public void onResume() {
        super.onResume();
        m_isRunning = true;
    }

    @Override
    public void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        if (imm != null && et_search_keyword != null)
            imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
    }

    @Override
    public void onStart() {
        super.onStart();
        if(App.m_isProfileImageView){
            App.m_isProfileImageView = false;
        } else {
            if(App.m_isTouchSearchTab) {
                tabHost.setCurrentTab(0);
                App.m_isTouchSearchTab = false;
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        m_UserSearchTab = inflater.inflate(R.layout.fragact_user_search_tab,container,false);
        ((MainTabAct) m_Activity).setTitle(getString(R.string.maintab_usersearch));
        ((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_ORGANCHART);
        tabHost = (FragmentTabHost)m_UserSearchTab.findViewById(R.id.tabhost);
        tabHost.setup(getActivity(), getChildFragmentManager(),R.id.realtabcontent);
        View tabIndicator1 = inflater.inflate(R.layout.layout_tabitem,null);
        TextView textView = (TextView) tabIndicator1.findViewById(R.id.tv_tab_title);
        textView.setText(R.string.mainusersearch_usersearch);
        textView.setBackgroundResource(R.drawable.tabitem_background);
        View tabIndicator2 = inflater.inflate(R.layout.layout_tabitem,null);
        TextView textView2 = (TextView) tabIndicator2.findViewById(R.id.tv_tab_title);
        textView2.setText(R.string.mainusersearch_organchart);
        textView2.setBackgroundResource(R.drawable.tabitem_background);
        View tabIndicator3 = inflater.inflate(R.layout.layout_tabitem,null);
        TextView textView3 = (TextView) tabIndicator3.findViewById(R.id.tv_tab_title);
        textView3.setText(R.string.mainusersearch_fellowlist);
        textView3.setBackgroundResource(R.drawable.tabitem_background);
        tabHost.addTab(tabHost.newTabSpec("tab1").setIndicator(tabIndicator1), SearchBrowseListFrag.class ,null);
        if(App.m_MyUserInfo.m_strUserType.equals("R"))
            tabHost.addTab(tabHost.newTabSpec("tab2").setIndicator(tabIndicator2), MainOrganChartFlag.class ,null);
        tabHost.addTab(tabHost.newTabSpec("tab3").setIndicator(tabIndicator3), MainFellowListFlag.class ,null);


        return m_UserSearchTab;
    }


}