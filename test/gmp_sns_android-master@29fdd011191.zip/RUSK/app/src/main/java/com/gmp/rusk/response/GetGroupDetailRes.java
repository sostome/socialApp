package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelThreadData;
import com.gmp.rusk.datamodel.SNSGroupData;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetGroupDetailRes extends ChannelRes{


	public GetGroupDetailRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}

}
