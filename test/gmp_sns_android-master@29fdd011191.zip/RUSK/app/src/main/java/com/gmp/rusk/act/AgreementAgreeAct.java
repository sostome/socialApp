package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.utils.AppSetting;

/**
 * Created by kang on 2017-09-18.
 */

public class AgreementAgreeAct extends Activity {

    CommonPopup m_Popup = null;
    private ProgressDlg m_Progress = null;
    CheckBox cb_check;
    Button m_btnCancel, m_btnOk;
    @Override
    protected void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);
        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_agreement_agree);

        init();
    }

    private void init(){
        ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        LinearLayout layoutAgreement = (LinearLayout)findViewById(R.id.layout_service_agree);
        layoutAgreement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AgreementAgreeAct.this, SetTermsAct.class);
                startActivity(intent);
            }
        });
        final CheckBox checkBox = (CheckBox)findViewById(R.id.cb_service_agree);
        checkBox.setChecked(true);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    m_btnOk.setBackgroundColor(Color.parseColor("#323145"));
                } else{
                    m_btnOk.setBackgroundColor(Color.parseColor("#85848f"));
                }
            }
        });

        m_btnCancel = (Button)findViewById(R.id.btn_agreement_cancel);
        m_btnOk = (Button)findViewById(R.id.btn_agreement_ok);

        m_btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        m_btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkBox.isChecked()){
                    Intent intent = new Intent(AgreementAgreeAct.this, PartnerApprovalReqAct.class);
                    startActivity(intent);
                    finish();
                } else {

                }
            }
        });
    }
}