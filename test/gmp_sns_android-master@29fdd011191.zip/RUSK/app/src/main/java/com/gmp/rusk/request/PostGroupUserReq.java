package com.gmp.rusk.request;

import java.util.ArrayList;

/**
 *	@author dym
 *			모임 멤버 추가 
 *			method : post
 */

public class PostGroupUserReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	public PostGroupUserReq(int a_nGroupId, int a_nUserNo)
	{
		APINAME = APINAME + "/" + a_nGroupId + "/member/invitation/" + a_nUserNo;
	}
	
	public PostGroupUserReq(int a_nGroupId, ArrayList<Integer> a_arrUserNo)
	{
		String strUserNo = "";
		int nUserNoSize = a_arrUserNo.size();
		for(int i = 0; i < nUserNoSize; i++)
		{
			strUserNo += a_arrUserNo.get(i);
			
			if(i < nUserNoSize - 1)
				strUserNo += ",";
		}
		APINAME = APINAME + "/" + a_nGroupId + "/member/invitation/" + strUserNo;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
