package com.gmp.rusk.request;



/**
 *	@author dym
 *			인증한 PCClient 목록을 조회하기 위한 API.
 *			method : get
 */

public class GetPCClientReq extends Req{
	
	private String APINAME = "user";
	
	private String AUTHENTIFICATION = "true";
	
	private final String METHOD = "GET";
	
	
	public GetPCClientReq()
	{
		APINAME = APINAME + "/" + App.m_EntryData.m_nUserNo + "/pc-client";
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
