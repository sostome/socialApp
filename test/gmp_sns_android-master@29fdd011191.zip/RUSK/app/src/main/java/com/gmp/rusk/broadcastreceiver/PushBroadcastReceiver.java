package com.gmp.rusk.broadcastreceiver;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.act.IntroAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PushBroadcastReceiver extends BroadcastReceiver{

	public MyApp App = MyApp.getInstance();
	private final String TAG = PushBroadcastReceiver.class.getSimpleName();
	
	public static String ACTION_PUSH_MESSAGE_NORMAL = "com.gmp.rusk.intent.receive.PUSH_MESSAGE_NORMAL";
	public static String ACTION_PUSH_MESSAGE_GROUP = "com.gmp.rusk.intent.receive.PUSH_MESSAGE_GROUP";
	public static String ACTION_PUSH_KICK = "com.gmp.rusk.intent.receive.KICK";
	public static String ACTION_PUSH_APPROVALREQUEST = "com.gmp.rusk.intent.receive.APPROVALREQUEST";
	public static String ACTION_PUSH_SNS_BOARD = "com.gmp.rusk.intent.receive.SNSBOARD";
	public static String ACTION_PUSH_SNS_REPLY = "com.gmp.rusk.intent.receive.SNSREPLY";
	public static String ACTION_PUSH_SNS_INVITE = "com.gmp.rusk.intent.receive.SNSINVITE";
	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		String strAction = intent.getAction();
		if(strAction == null)
			return;
		
		if(strAction.equals(ACTION_PUSH_MESSAGE_NORMAL))
		{
			CommonLog.e(TAG, "action is push message normal");
			int nUserNo = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_USERID, -1);
			Intent intentNewTask;
			if(isAppInit())
			{
				// Intro 
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_PUSH);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FRIENDNO, nUserNo);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO, nUserNo);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM, true);
			}
			
			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
		else if(strAction.equals(ACTION_PUSH_MESSAGE_GROUP))
		{	
			String strGroupId = intent.getStringExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_GROUPID);
			CommonLog.e(TAG, "action is push message group : " + strGroupId);
			Intent intentNewTask;
			if(isAppInit())
			{
				// Intro
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_PUSH);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_GROUPID, strGroupId);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID, strGroupId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP, true);
			}
			
			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
		else if(strAction.equals(ACTION_PUSH_KICK))
		{
			Intent intentNewTask;
			
			if(isAppInit())
			{
				// Intro
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_KICK);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISKICK, true);
			}
			
			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
		else if(strAction.equals(ACTION_PUSH_APPROVALREQUEST))
		{
			Intent intentNewTask;
			
			if(isAppInit())
			{
				// Intro
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_REQUEST);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_APPROVAL, true);
			}
			
			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
		else if(strAction.equals(ACTION_PUSH_SNS_INVITE))
		{
			Intent intentNewTask;

			if(isAppInit())
			{
				// Intro
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_SNSINVITE);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSINVITE, true);
			}

			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
		else if(strAction.equals(ACTION_PUSH_SNS_BOARD))
		{
			Intent intentNewTask;
			int nSNSGroupId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSGROUPID, -1);
			int nSNSBoardId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSBOARDID, -1);
			CommonLog.e(getClass(), "groupId: " + nSNSGroupId);
			CommonLog.e(getClass(), "boardId: " + nSNSBoardId);
			SharedPref pref = SharedPref.getInstance(context);
			pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, nSNSGroupId);
			pref.setIntegerPref(SharedPref.PREF_CHANNEL_PUSH_BOARD, nSNSBoardId);
			if(isAppInit())
			{
				// Intro
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_SNSBOARD);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_SNSGROUPID, nSNSGroupId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_SNSBOARDID, nSNSBoardId);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSBOARD, true);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID, nSNSGroupId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID, nSNSBoardId);
				
			}
			
			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
		else if(strAction.equals(ACTION_PUSH_SNS_REPLY))
		{
			Intent intentNewTask;
			int nSNSGroupId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSGROUPID, -1);
			int nSNSBoardId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSBOARDID, -1);
			int nSNSReplyId = intent.getIntExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSREPLYID, -1);
			CommonLog.e(getClass(), "groupId: " + nSNSGroupId);
			CommonLog.e(getClass(), "boardId: " + nSNSBoardId);
			CommonLog.e(getClass(), "replyId: " + nSNSReplyId);
			SharedPref pref = SharedPref.getInstance(context);
			pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, nSNSGroupId);
			pref.setIntegerPref(SharedPref.PREF_CHANNEL_PUSH_BOARD, nSNSBoardId);
			if(isAppInit())
			{
				// Intro
				intentNewTask = new Intent(context, IntroAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_FROM_APP, IntentKeyString.INTENT_VALUE_INTRO_FROM_SNSBOARD);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_SNSGROUPID, nSNSGroupId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_SNSBOARDID, nSNSBoardId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_INTRO_SNSREPLYID, nSNSReplyId);
			}
			else
			{
				// MainTab
				intentNewTask = new Intent(context, MainTabAct.class);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, true);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID, nSNSGroupId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID, nSNSBoardId);
				intentNewTask.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID, nSNSReplyId);
				
			}
			
			intentNewTask.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
			context.startActivity(intentNewTask);
		}
	}
	
	public boolean isAppInit()
	{
		if(App.m_EntryData == null)
			return true;
		
		if(App.m_MyUserInfo == null)
			return true;
		
		return false;
	}
}
