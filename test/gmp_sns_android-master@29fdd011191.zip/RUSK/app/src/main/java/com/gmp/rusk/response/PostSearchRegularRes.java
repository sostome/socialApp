package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.utils.CommonLog;

public class PostSearchRegularRes extends Res{
	
//	private final String JSON_RESULTCOUNT				= "resultCount";
	private final String JSON_RESULTS 					= "results";
	private final String JSON_USERNO 					= "userNo";
	private final String JSON_NAME	 					= "name";
	private final String JSON_CHARGE					= "charge";
	private final String JSON_DEPARTMENT				= "department";
	private final String JSON_PARENTDEPARTMENT					= "parentDepartment";
	private final String JSON_IMAGEAVAILABLE			= "imageAvailable";
	private final String JSON_AVAILABLE					= "available";
	
	ArrayList<RegularSearchListData> m_arrRegularSearchListDatas = null;
	
	public PostSearchRegularRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_RESULTS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_RESULTS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrRegularSearchListDatas = new ArrayList<RegularSearchListData>();
//					for(int j=0; j<1000;j++)
//					{
						for (int i = 0; i < nArrCount; i++) {
							JSONObject jsonItem = jsonArray.getJSONObject(i);
							
							int nUserNo = jsonItem.optInt(JSON_USERNO);
							String strName = jsonItem.optString(JSON_NAME);
							String strCharge = jsonItem.optString(JSON_CHARGE);
							String strDepartment = jsonItem.optString(JSON_DEPARTMENT);
							String strParentDepartment = jsonItem.optString(JSON_PARENTDEPARTMENT);
							boolean isImageAvailable = jsonItem.optBoolean(JSON_IMAGEAVAILABLE);
							boolean isAvailable = jsonItem.optBoolean(JSON_AVAILABLE);
							
							RegularSearchListData item = new RegularSearchListData(nUserNo, strName, strCharge, strDepartment, strParentDepartment, isImageAvailable, isAvailable);
							
							m_arrRegularSearchListDatas.add(item);
						}
//					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	public ArrayList<RegularSearchListData> getRegularSearchListData()
	{
		return m_arrRegularSearchListDatas;
	}
	
}
