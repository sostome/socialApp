package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class GetAdminNoticeRes extends Res{
	
	private final String JSON_NOTICENO				= "noticeNo";
	private final String JSON_BODY				= "body";
		
	private int m_nNoticeNo = 0;
	private String m_strContent = "";
	
	public GetAdminNoticeRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			m_nNoticeNo = jsonRoot.getInt(JSON_NOTICENO);
			m_strContent = jsonRoot.getString(JSON_BODY);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int getNoticeNo()
	{
		return m_nNoticeNo;
	}
	
	public String getContent()
	{
		return m_strContent;
	}
}