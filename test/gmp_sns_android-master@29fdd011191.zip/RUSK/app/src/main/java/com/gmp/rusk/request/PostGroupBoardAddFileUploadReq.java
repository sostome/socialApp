package com.gmp.rusk.request;

import android.content.Context;
import android.graphics.Bitmap;

import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.ResolveText;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;

/**
 *	@author kch
 *			모임 게시글 파일 업로드
 *			method : post
 *			Accept Media Type: multipart/form-data
 */

public class PostGroupBoardAddFileUploadReq extends UploadReq{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	
	public PostGroupBoardAddFileUploadReq(int a_nChannelNo, int a_nThreadNo)
	{
		APINAME = APINAME  + "/" + a_nChannelNo + "/thread/" + a_nThreadNo + "/file";
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}

	
	private Context m_Context = null;
	private ArrayList<SNSBoardUploadFileData> m_arrFileData = new ArrayList<SNSBoardUploadFileData>();
	private class SNSBoardUploadFileData
	{
		public String m_strFileType = "";
		public String m_strFileName = "";
		public String m_strFilePath = "";
	}
	
	public void addFileInfo(Context a_Context, String a_strFileName, String a_strFilePath)
	{
		m_Context = a_Context;
		SNSBoardUploadFileData data = new SNSBoardUploadFileData();
		data.m_strFileType = StaticString.FILE_TYPE_NORMAL;
		data.m_strFileName = a_strFileName;
		data.m_strFilePath = a_strFilePath;
		m_arrFileData.add(data);
	}
	
	public void addImageFileInfo(Context a_Context, String a_strFilePath)
	{
		m_Context = a_Context;
		SNSBoardUploadFileData data = new SNSBoardUploadFileData();
		data.m_strFileType = StaticString.FILE_TYPE_IMAGE;
		data.m_strFilePath = a_strFilePath;
		m_arrFileData.add(data);
	}
	
	public void addVodFileInfo(Context a_Context, String a_strFilePath)
	{
		m_Context = a_Context;
		SNSBoardUploadFileData data = new SNSBoardUploadFileData();
		data.m_strFileType = StaticString.FILE_TYPE_VIDEO;
		data.m_strFilePath = a_strFilePath;
		m_arrFileData.add(data);
	}
	
	//private final String MULTIPART_KEY_AUTHKEY = "authKey";
	//private final String MULTIPART_KEY_ENCPWD = "encPwd";
	private final String MULTIPART_KEY_FILES = "files";
	private final String MULTIPART_KEY_TYPES = "types";
	
	@Override
	public MultipartEntity getMultiPartEntity()
	{
		MultipartEntity multiPart = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE, null, Charset.forName("UTF-8"));
		
		/*if(AppSetting.FEATURE_VARIANT.equals("R"))
		{
			try {
				ContentBody authKeyBody = new StringBody(App.m_GMPData.m_strAuthKey, Charset.forName("UTF-8"));
				multiPart.addPart(MULTIPART_KEY_AUTHKEY, authKeyBody);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				ContentBody authKeyBody = new StringBody(App.m_GMPData.m_strEncPwd, Charset.forName("UTF-8"));
				multiPart.addPart(MULTIPART_KEY_ENCPWD, authKeyBody);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		
		int nFileSize = m_arrFileData.size();
		String strTypes = "";
		for(int i = 0; i < nFileSize; i++)
		{
			SNSBoardUploadFileData uploadFileData = m_arrFileData.get(i);
			byte[] data = null;
			String strFileName;
			if(uploadFileData.m_strFileType.equals(StaticString.FILE_TYPE_IMAGE))
			{
				String[] strsFileNames = uploadFileData.m_strFilePath.split("/");
				String tempFileName = strsFileNames[strsFileNames.length - 1];
				String strRemoveDotName = "";
				if(tempFileName.contains("."))
					strRemoveDotName = tempFileName.split("\\.")[0];
				strFileName = strRemoveDotName + ".jpg";
//				data = uploadFileData.m_byteFileData;
				data = getFileByte(uploadFileData.m_strFilePath);
			}
			else if(uploadFileData.m_strFileType.equals(StaticString.FILE_TYPE_VIDEO))
			{
//				String strPath = Utils.getPathFromUri(m_Context, uploadFileData.m_uri);
				data = getFileByte(uploadFileData.m_strFilePath);
				String[] strsFileNames = uploadFileData.m_strFilePath.split("/");
				strFileName = strsFileNames[strsFileNames.length - 1];
			}
			else
			{
				data = getFileByte(uploadFileData.m_strFilePath);
				strFileName = uploadFileData.m_strFileName;
			}
			
			if(data != null)
			{
				CommonLog.e(PostGroupBoardAddFileUploadReq.class.getSimpleName(), "file name : " + strFileName);
				ContentBody fileBody = new ByteArrayBody(data, strFileName);
				multiPart.addPart(MULTIPART_KEY_FILES, fileBody);
				
				if(i != 0)
					strTypes += "_";
				strTypes += uploadFileData.m_strFileType;
				
				if(uploadFileData.m_strFileType.equals(StaticString.FILE_TYPE_VIDEO))
				{
					String strThumbnailFileName = "";
					String[] strsThumbFileNames = strFileName.split("\\.");
					for(int j = 0; j < strsThumbFileNames.length - 1; j++)
					{
						strThumbnailFileName += strsThumbFileNames[j];
						strThumbnailFileName += ".";
					}
					
					strThumbnailFileName += "jpg";
					Bitmap bmp = Utils.getMiniThumbnailFromVideo(m_Context, uploadFileData.m_strFilePath); 
					byte[] byteThumb  = Utils.bmpToByte(bmp);
					CommonLog.e(PostGroupBoardAddFileUploadReq.class.getSimpleName(), "thumb name : " + strThumbnailFileName);
					CommonLog.e(PostGroupBoardAddFileUploadReq.class.getSimpleName(), "thumb size : " + byteThumb.length);
					ContentBody thumbBody = new ByteArrayBody(byteThumb, strThumbnailFileName);
					multiPart.addPart(MULTIPART_KEY_FILES, thumbBody);
					
					strTypes += "_";
					strTypes += SNSBoardFileData.FILETYPE_THUMBNAIL;
				}
			}
		}
		
		try {
			CommonLog.e(PostGroupBoardAddFileUploadReq.class.getSimpleName(), "file type : " + strTypes);
			ContentBody typeBody = new StringBody(strTypes, Charset.forName("UTF-8"));
			multiPart.addPart(MULTIPART_KEY_TYPES, typeBody);
			ContentBody isVdiBody = new StringBody("false", Charset.forName("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return multiPart;
	}
	
	private byte[] getFileByte(String a_strPath)
	{
		byte[] bArData = null;
		File file = new File(a_strPath);
		if(file != null && file.exists())
		{
			try {
				FileInputStream isFile = new FileInputStream(file);
				int nCount = isFile.available();
				if(nCount > 0)
				{
					bArData = new byte[nCount];
					isFile.read(bArData);
				}
				if(isFile != null)
				{
					isFile.close();
				}
			} 
			catch (FileNotFoundException e) {
				e.printStackTrace();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return bArData;
	}
}
