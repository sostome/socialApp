package com.gmp.rusk.extension;

import java.util.ArrayList;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class PCSyncEx implements PacketExtension{
		public static final String NAMESPACE = "urn:utalk:sync";
		public static final String ELEMENT_NAME = "info";
		
		private String type;
		private String jid;
		private String newName;
		private ArrayList<Integer> user;
		private ArrayList<Integer> groupId;
		
		
		public PCSyncEx(){}
		public PCSyncEx(String type, String jid, String newName, ArrayList<Integer> user, ArrayList<Integer> groupId){
			this.type = type;
			this.newName = newName;
			this.jid = jid;
			this.user = user;
			this.groupId = groupId;

		}

		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}
		
		public String getType(){
			return this.type;
		}
		
		public String getJid(){
			return this.jid;
		}
		
		public String getName(){
			return this.newName;
		}
		
		public ArrayList<Integer> getUsers() {
			return this.user;
		}
		
		public ArrayList<Integer> getGroupId() {
			return this.groupId;
		}

		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();
			buf.append("SystemEx : ");
			buf.append("<type : " + this.type + ">");
			buf.append("<jid : " + this.jid + ">");
			buf.append("<newName : " + this.newName + ">");
			buf.append("<user : " + this.user + ">");
			buf.append("<groupId : " + this.groupId + ">");
			return buf.toString();
		}
		
		public static class Provider implements PacketExtensionProvider {

			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
	            String type = "";
	            String jid = "";
	            String newName = "";
	            ArrayList<Integer> user = new ArrayList<Integer>();
	            ArrayList<Integer> groupId = new ArrayList<Integer>();
	            
				boolean done = false;
				int cnt = parser.getAttributeCount();
				for(int i = 0; i < cnt; i++){
					if(parser.getAttributeName(i).equals("type")){
						type = parser.getAttributeValue(i);		
					}
				}
				while(!done){
					int eventType = parser.next();					
					if (eventType == XmlPullParser.START_TAG) {
		                if(parser.getName().equals("jid")){
		                	jid = parser.nextText();
		                } else if(parser.getName().equals("newName")){
		                	newName = parser.nextText();
		                } else if(parser.getName().equals("user")){
		                	user.add(Integer.parseInt(parser.nextText()));
		                } else if(parser.getName().equals("groupId")){
		                	groupId.add(Integer.parseInt(parser.nextText()));
		                } 
		            }
		            else if (eventType == XmlPullParser.END_TAG) {
		                if (parser.getName().equals(ELEMENT_NAME)) {
		                    done = true;
		                }
		            }
				}
				return new PCSyncEx(type, jid, newName, user, groupId);
			}
		}
	}