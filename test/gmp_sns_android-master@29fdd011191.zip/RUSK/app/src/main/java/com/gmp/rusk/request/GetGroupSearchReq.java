package com.gmp.rusk.request;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 *	@author kch
 *			모임 검색 
 *			method : get
 */

public class GetGroupSearchReq extends Req{

	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";


	public GetGroupSearchReq(int a_nGroupId, String a_strType, String a_strKeyword)
	{
		try {
			a_strKeyword = URLEncoder.encode(a_strKeyword, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		APINAME = APINAME +"/"+a_nGroupId + "/search" + "?keyword=" + a_strKeyword + "&type=" + a_strType + "&size=10000";


	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub

			return "";

	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
