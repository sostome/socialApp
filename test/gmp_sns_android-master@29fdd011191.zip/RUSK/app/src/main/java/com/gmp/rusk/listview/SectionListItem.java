package com.gmp.rusk.listview;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**  * Item definition including the section.  */
@SuppressWarnings("serial")
public class SectionListItem {

	public Object item;
	public String section;

	public SectionListItem(final Object item, final String section) {
		super();
		this.item = item;
		this.section = section;
	}
}
