package com.gmp.rusk.datamodel;

/**
 * Created by K on 2017-08-14.
 */

public class ChannelData {

    public final static String STATUS_TYPE_I = "I";
    public final static String STATUS_TYPE_A = "a";

    public int m_nChannelNo = -1;
    public String m_strName = "";
    public boolean m_isOwner = false;
    public int m_nOwnerUserNo = -1;
    public int m_nInvitaionCount = -1;
    public int m_nMemberCount = -1;
    public String m_strStatus = "";
    public boolean m_isThreadNotificationOn = true;
    public boolean m_isCommentNotificationOn = true;

    public int m_nViewType = -1;
}
