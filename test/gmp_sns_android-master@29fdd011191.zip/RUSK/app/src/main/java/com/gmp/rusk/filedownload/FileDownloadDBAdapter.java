package com.gmp.rusk.filedownload;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

import com.gmp.rusk.utils.LocalAesCrypto;

public class FileDownloadDBAdapter {
	
	// Database File Name
	private static final String DATABASE_NAME 				= "filedownload.db";
	
	// Database Version
	private static final int DATABASE_VERSION 				= 1;
	
	// Room Table Name
	private static final String TABLE_FILEDOWNLOAD			= "FileDownload";
	
	// Room Table Field Name
	public static final String KEY_IDX								= "idx";
	public static final String KEY_FILEDOWNLOAD_ROOMID				= "roomId";
	public static final String KEY_FILEDOWNLOAD_MSGID				= "msgId";
	public static final String KEY_FILEDOWNLOAD_FILEPATH			= "filePath";
	
	// Create Table Query
	private final String FILEDOWNLOAD_CREATE = "create table " + TABLE_FILEDOWNLOAD + " (" + 
													KEY_IDX 						+ " integer primary key autoincrement, " +
													KEY_FILEDOWNLOAD_ROOMID 		+ " text not null, " +
													KEY_FILEDOWNLOAD_MSGID 			+ " text not null, " +
													KEY_FILEDOWNLOAD_FILEPATH		+ " text not null);";
	
	// Drop Table Query 
	private final String FILEDOWNLOAD_DROP = "DROP TABLE IF EXISTS " + TABLE_FILEDOWNLOAD;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private FileDownloadDBHelper m_dbHelper = null;
	
	public FileDownloadDBAdapter(Context context)
	{
		m_context = context;
		m_dbHelper = new FileDownloadDBHelper(m_context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	// Database Open Read & Write Permission
	public FileDownloadDBAdapter open() throws SQLException
	{
		m_db = m_dbHelper.getWritableDatabase();
		return this;
	}
	
	// Database Open Read Permission
	public FileDownloadDBAdapter openReadOnly() throws SQLException
	{
		m_db = m_dbHelper.getReadableDatabase();
		return this;
	}
	
	// Database Close
	public void close()
	{
		m_db.close();
	}
	
	public int insertRoom(String a_strRoomId, String a_strMsgId, String a_strFilePath)
	{
		int nCount = 0;
	
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_FILEDOWNLOAD_ROOMID, a_strRoomId);
			value.put(KEY_FILEDOWNLOAD_MSGID, a_strMsgId);
			LocalAesCrypto crypto = new LocalAesCrypto();
			value.put(KEY_FILEDOWNLOAD_FILEPATH, crypto.encrypt(a_strFilePath));
			
			m_db.insert(TABLE_FILEDOWNLOAD, null, value);
			nCount++;
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int deleteFileDownload()
	{
		return m_db.delete(TABLE_FILEDOWNLOAD, null, null);
	}
	
	public int deleteFileDownload(String a_strRoomId)
	{
		return m_db.delete(TABLE_FILEDOWNLOAD, KEY_FILEDOWNLOAD_ROOMID + "=\"" + a_strRoomId + "\"", null);
	}
	
	public int deleteFileDownload(String a_strRoomId, String a_strMsgId)
	{
		return m_db.delete(TABLE_FILEDOWNLOAD, KEY_FILEDOWNLOAD_ROOMID + "=\"" + a_strRoomId + "\" AND " + KEY_FILEDOWNLOAD_MSGID + "=\"" + a_strMsgId + "\"" , null);
	}
	
	public Cursor getFileDownload(String a_strRoomId, String a_strMsgId)
	{
		return m_db.query(TABLE_FILEDOWNLOAD, null, KEY_FILEDOWNLOAD_ROOMID + "=\"" + a_strRoomId + "\" AND " + KEY_FILEDOWNLOAD_MSGID + "=\"" + a_strMsgId + "\"", null, null, null, null);
	}
	
	// SQLite Open Helper Class
	private class FileDownloadDBHelper extends SQLiteOpenHelper
	{

		public FileDownloadDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(FILEDOWNLOAD_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			db.execSQL(FILEDOWNLOAD_DROP);
			onCreate(db);
		}
	}
}
