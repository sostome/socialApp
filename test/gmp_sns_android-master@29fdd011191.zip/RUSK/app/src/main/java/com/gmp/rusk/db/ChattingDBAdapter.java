package com.gmp.rusk.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.locks.Lock;


import com.google.gson.Gson;
import com.gmp.rusk.MyApp;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ReadCountData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.StaticString;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.support.v4.util.CircularArray;

public class ChattingDBAdapter {

	public MyApp App = MyApp.getInstance();
	// Database File Name
	// ex:ttalk_chatting_roomid.db
	private static final String DATABASE_FILE_NAME 				= "ttalk_chatting_";
	private static final String DATABASE_FILE_EXTENSION 		= ".db";
	
	// Chatting Table Name
	private static final String TABLE_CHATTING 			= "Chatting";
	// Chatting User Table Name
	private static final String TABLE_CHATTINGUSER 		= "ChattingUser";
	
	public static final String KEY_IDX					= "idx";
	
	// Chatting Table Field Name
	public static final String KEY_CHATTING_MSGID				= "msgId";				// Message Id
	public static final String KEY_CHATTING_SENDUSERID			= "sendUserId";			// Message Send User Id
	public static final String KEY_CHATTING_MSGSENDTIME			= "msgSendTime";		// Message Send Millisecond Time
	public static final String KEY_CHATTING_MSGTYPE				= "msgType";			// Message Type
	public static final String KEY_CHATTING_MSG					= "msg";				// Message String
	public static final String KEY_CHATTING_ISREAD				= "isRead";				// Message 읽었는지 유/무
	public static final String KEY_CHATTING_SENDSTATUS			= "sendStatus";			// Message Send 상태 (0:보내는중, 1:실패, 2:성공)
	@Deprecated
	public static final String KEY_CHATTING_READUSERIDLIST		= "readUserIdList";		// Message 읽은 User Id List('|' 로 구분)
	@Deprecated
	public static final String KEY_CHATTING_CURRENTUSERIDLIST	= "currentUserIdList";	// Message Insert 당시의 채팅 참여자
	public static final String KEY_CHATTING_NOREADUSERCOUNT		= "noReadUserCount";	// No Read User Count
	public static final String KEY_SNSNOTICE_ADDEDLIST			= "snsNoticeAddedList"; // 모임 공지 공유에서 글 이외에 추가된 목록들 그룹 id,게시글no,이미지 수,이미지,파일 수, 파일 크기, 파일 이름 순

	// Chatting User Table Field Name
	public static final String KEY_CHATTINGUSER_USERID			= "userId";				// Chatting User Id
	
	// Create Table Query
	private final String CHATTING_CREATE = "create table " + TABLE_CHATTING			+ " (" + 
												KEY_IDX 							+ " integer primary key autoincrement, " +
												KEY_CHATTING_MSGID 					+ " text not null, " +
												KEY_CHATTING_SENDUSERID 			+ " integer not null, " +
												KEY_CHATTING_MSGSENDTIME			+ " long not null, " +
												KEY_CHATTING_MSGTYPE 				+ " integer not null, " +
												KEY_CHATTING_MSG					+ " text not null, " +
												KEY_CHATTING_ISREAD					+ " integer not null, " +
												KEY_CHATTING_SENDSTATUS				+ " integer, " +
												KEY_CHATTING_NOREADUSERCOUNT		+ " integer not null, " +
												KEY_SNSNOTICE_ADDEDLIST				+ " text);";
//												KEY_CHATTING_READUSERIDLIST			+ " text, " +
//												KEY_CHATTING_CURRENTUSERIDLIST		+ " text not null);";
	
	private final String CHATTINGUSER_CREATE = "create table " + TABLE_CHATTINGUSER + " (" + 
												KEY_IDX 							+ " integer primary key autoincrement, " +
												KEY_CHATTINGUSER_USERID				+ " integer not null);";
	
	// Drop Table Query 
	private final String CHATTING_DROP = "DROP TABLE IF EXISTS " + TABLE_CHATTING;
	private final String CHATTINGUSER_DROP = "DROP TABLE IF EXISTS " + TABLE_CHATTINGUSER;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private ChattingDBHelper m_dbHelper = null;
	private String m_strRoomId;
	private Lock w_recv;
	
	public ChattingDBAdapter(Context context, String a_strRoomId)
	{
		m_context = context;
		m_strRoomId = a_strRoomId;
		String strDatabaseName = DATABASE_FILE_NAME + a_strRoomId + DATABASE_FILE_EXTENSION;
		m_dbHelper = new ChattingDBHelper(m_context, strDatabaseName, null, DatabaseDefine.DATABASE_CHATTINGDB_VERSION);
		
		w_recv = App.rwl.writeLock();
	}
	
	// Database Open Read & Write Permission
	public ChattingDBAdapter open() throws SQLException
	{
//		if(App.m_mapOpeningDB == null){
//			App.m_mapOpeningDB = new HashMap<String, Integer>();
//			App.m_mapDB = new HashMap<String, SQLiteDatabase>();
//		}
//		if(App.m_mapOpeningDB.get(m_strRoomId) == null || App.m_mapOpeningDB.get(m_strRoomId) == 0){
//			App.m_mapDB.put(m_strRoomId, m_dbHelper.getWritableDatabase());
//			App.m_mapOpeningDB.put(m_strRoomId, 1);
//			m_db = App.m_mapDB.get(m_strRoomId);
//		} else {
//			int nOpenDBRequest = App.m_mapOpeningDB.get(m_strRoomId);
//			App.m_mapOpeningDB.put(m_strRoomId, nOpenDBRequest+1);
//			m_db = App.m_mapDB.get(m_strRoomId);
//		}
		
		w_recv.lock();
		m_db = m_dbHelper.getWritableDatabase();
//		m_db.rawQuery("PRAGMA journal_mode=OFF", null);
//		m_db.rawQuery("PRAGMA synchronous=OFF", null);
		//m_db.execSQL("PRAGMA journal_mode=OFF");
		return this;
	}
	
	// Database Open Read Permission
	public ChattingDBAdapter openReadOnly() throws SQLException
	{
//		if(App.m_mapOpeningDB == null){
//			App.m_mapOpeningDB = new HashMap<String, Integer>();
//			App.m_mapDB = new HashMap<String, SQLiteDatabase>();
//		}
//		if(App.m_mapOpeningDB.get(m_strRoomId) == null || App.m_mapOpeningDB.get(m_strRoomId) == 0){
//			App.m_mapDB.put(m_strRoomId, m_dbHelper.getWritableDatabase());
//			App.m_mapOpeningDB.put(m_strRoomId, 1);
//			m_db = App.m_mapDB.get(m_strRoomId);
//		} else {
//			int nOpenDBRequest = App.m_mapOpeningDB.get(m_strRoomId);
//			App.m_mapOpeningDB.put(m_strRoomId, nOpenDBRequest+1);
//			m_db = App.m_mapDB.get(m_strRoomId);
//		}
		w_recv.lock();
		m_db = m_dbHelper.getReadableDatabase();
//		m_db.rawQuery("PRAGMA journal_mode=OFF", null);
//		m_db.rawQuery("PRAGMA synchronous=OFF", null);
		return this;
	}
	
	// Database Close
	public void close()
	{
//		if(App.m_mapOpeningDB.get(m_strRoomId) == null || App.m_mapOpeningDB.get(m_strRoomId) == 1){
//			m_db.close();
//			//App.m_mapDB.put(m_strRoomId, null);
//			//App.closeDB(m_strRoomId);
//			//App.m_mapDB.get(m_strRoomId).close();
//			//App.m_mapDB.put(m_strRoomId, null);
//			App.m_mapOpeningDB.put(m_strRoomId, 0);
//		} else {
//			int nOpenDBRequest = App.m_mapOpeningDB.get(m_strRoomId);
//			App.m_mapOpeningDB.put(m_strRoomId, nOpenDBRequest-1);
//		}
		m_db.close();
		w_recv.unlock();
	}
	
	public void beginTransaction()
	{
		m_db.beginTransaction();
	}
	
	public void setTransactionSuccessful()
	{
		m_db.setTransactionSuccessful();
	}
	
	public void endTransaction()
	{
		m_db.endTransaction();
	}
	
	/**
	 * insertChattingMessage 
	 * Message 단일 추가 Insert Query
	 * @param a_chattingMsgData ChattingMessageData : 추가할 ChattingMessageData 
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertChattingMessage(ChattingMessageData a_chattingMsgData)
	{
		int nCount = 0;
		
		if(a_chattingMsgData == null)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_CHATTING_MSGID, a_chattingMsgData.m_strMsgId);
			value.put(KEY_CHATTING_SENDUSERID, a_chattingMsgData.m_nSendUserId);
			value.put(KEY_CHATTING_MSGSENDTIME, a_chattingMsgData.m_lnMsgSendTime);
			value.put(KEY_CHATTING_MSGTYPE, a_chattingMsgData.m_nMsgType);
			
			String strMsgText = "";
			ArrayList<String> arrMsgNEmoticon = new ArrayList<>();
			try
			{
				LocalAesCrypto crypto = new LocalAesCrypto();
				if(!a_chattingMsgData.m_strEmoticon.equals("")){
					strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
					arrMsgNEmoticon.add(strMsgText);
					arrMsgNEmoticon.add(a_chattingMsgData.m_strEmoticon);
				} else {
					strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				if(!a_chattingMsgData.m_strEmoticon.equals("")){
					arrMsgNEmoticon.add(a_chattingMsgData.m_strMsgText);
					arrMsgNEmoticon.add(a_chattingMsgData.m_strEmoticon);
				} else {
					strMsgText = a_chattingMsgData.m_strMsgText;
				}
			}
			Gson gson = new Gson();
			if(!a_chattingMsgData.m_strEmoticon.equals("")){
				String strMsgNEmoticon = gson.toJson(arrMsgNEmoticon);
				value.put(KEY_CHATTING_MSG, strMsgNEmoticon);
			}else {
				value.put(KEY_CHATTING_MSG, strMsgText);
			}
			if(a_chattingMsgData.m_isRead)
				value.put(KEY_CHATTING_ISREAD, 1);
			else
				value.put(KEY_CHATTING_ISREAD, 0);
			value.put(KEY_CHATTING_SENDSTATUS, a_chattingMsgData.m_nSendStatus);
			value.put(KEY_CHATTING_NOREADUSERCOUNT, a_chattingMsgData.m_nNoReadUserCount);
			String inputString = gson.toJson(a_chattingMsgData.m_SNSNoticeAddedList);
			value.put(KEY_SNSNOTICE_ADDEDLIST,inputString);
			
			m_db.insert(TABLE_CHATTING, null, value);
			nCount++;
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * insertChattingUser 
	 * Chatting User 단일 추가 Insert Query
	 * @param a_nUserId 추가할 User Id 
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertChattingUser(int a_nUserId)
	{
		int nCount = 0;
		
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_CHATTINGUSER_USERID, a_nUserId);
			m_db.insert(TABLE_CHATTINGUSER, null, value);
			nCount++;
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * insertChattingUser 
	 * Chatting User 복수 추가 Insert Query
	 * @param a_arrUserIdList 추가할 User Id List Array
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertChattingUser(ArrayList<Integer> a_arrUserIdList)
	{
		int nCount = 0;
		
		try
		{
			m_db.beginTransaction();
			for(Integer nUserId : a_arrUserIdList)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_CHATTINGUSER_USERID, nUserId);
				m_db.insert(TABLE_CHATTINGUSER, null, value);
				nCount++;
			}
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateMsg
	 * Message Update 
	 * msgId를 비교하여 Update를 수행
	 * @param ChattingMessageData Message Data
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsg(ChattingMessageData a_chattingMsgData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			
			value.put(KEY_CHATTING_MSGSENDTIME, a_chattingMsgData.m_lnMsgSendTime);
			value.put(KEY_CHATTING_SENDUSERID, a_chattingMsgData.m_nSendUserId);
			value.put(KEY_CHATTING_MSGTYPE, a_chattingMsgData.m_nMsgType);

			String strMsgText = "";
			ArrayList<String> arrMsgNEmoticon = new ArrayList<>();
			try
			{
				LocalAesCrypto crypto = new LocalAesCrypto();
				if(!a_chattingMsgData.m_strEmoticon.equals("")){
					strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
					arrMsgNEmoticon.add(strMsgText);
					arrMsgNEmoticon.add(a_chattingMsgData.m_strEmoticon);
				} else {
					strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
				if(!a_chattingMsgData.m_strEmoticon.equals("")){
					arrMsgNEmoticon.add(a_chattingMsgData.m_strMsgText);
					arrMsgNEmoticon.add(a_chattingMsgData.m_strEmoticon);
				} else {
					strMsgText = a_chattingMsgData.m_strMsgText;
				}
			}
			Gson gson = new Gson();
			if(!a_chattingMsgData.m_strEmoticon.equals("")){
				String strMsgNEmoticon = gson.toJson(arrMsgNEmoticon);
				value.put(KEY_CHATTING_MSG, strMsgNEmoticon);
			}else {
				value.put(KEY_CHATTING_MSG, strMsgText);
			}
			
			if(a_chattingMsgData.m_isRead)
				value.put(KEY_CHATTING_ISREAD, 1);
			else
				value.put(KEY_CHATTING_ISREAD, 0);
			value.put(KEY_CHATTING_SENDSTATUS, a_chattingMsgData.m_nSendStatus);
			value.put(KEY_CHATTING_NOREADUSERCOUNT, a_chattingMsgData.m_nNoReadUserCount);
			
			nCount = m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + a_chattingMsgData.m_strMsgId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateMsgRead
	 * 복수 Message 내가 읽었는지에 대한 Field Update 
	 * msgId를 비교하여 Update를 수행
	 * @param a_mapIsReadData MsgId와 isRead가 쌍으로 이루어진 HashMap
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsgRead(HashMap<String, Boolean> a_mapIsReadData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			Iterator<String> iterator = a_mapIsReadData.keySet().iterator();
			
			while(iterator.hasNext())
			{
				String strMsgId = iterator.next();
				Boolean isRead = a_mapIsReadData.get(strMsgId);
				ContentValues value = new ContentValues();
				if(isRead)
					value.put(KEY_CHATTING_ISREAD, 1);
				else
					value.put(KEY_CHATTING_ISREAD, 0);
				
				nCount = m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + strMsgId + "\"", null);
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateMsgRead
	 * 복수 Message 내가 읽었는지에 대한 Field Update 
	 * msgId를 비교하여 Update를 수행
	 * 방 최초 진입시에 한번 사용
	 * @param a_mapIsReadData MsgId와 isRead가 쌍으로 이루어진 HashMap
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsgReadInGetReadCount(HashMap<String, Boolean> a_mapIsReadData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			//long lnStartTime = System.currentTimeMillis();
			String strOrderBy = "case" +
					" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
					" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED DESC";

			Cursor cc = m_db.query(TABLE_CHATTING, null, null, null, null, null, strOrderBy);
			HashMap<String, Integer> indexMap = new HashMap<String, Integer>();
			if (cc.moveToFirst()) {
				do {
					
					int nIsRead = cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD));
					if(nIsRead == 0){
						//String strUpdateMsgId = cc.getString(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
						//nIDX = cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_IDX));
						indexMap.put(cc.getString(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID)), cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_IDX)));
					}
				} while (cc.moveToNext());
			}
			Iterator<String> iterator = a_mapIsReadData.keySet().iterator();
			while(iterator.hasNext())
			{
				String strMsgId = iterator.next();
				Boolean isRead = a_mapIsReadData.get(strMsgId);
				ContentValues value = new ContentValues();

				if(isRead)
					value.put(KEY_CHATTING_ISREAD, 1);
				else
					value.put(KEY_CHATTING_ISREAD, 0);
				
//				int nIDX = 0;			
//				if (cc.moveToFirst()) {
//					
//					do {
//						String strUpdateMsgId = cc.getString(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
//						int nIsRead = cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD));
//						if(strMsgId.equals(strUpdateMsgId) && (nIsRead == 0)){
//							nIDX = cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_IDX));
//							break;
//						}
//					} while (cc.moveToNext());
//				}
				
				nCount = m_db.update(TABLE_CHATTING, value, KEY_IDX + "=" + indexMap.get(strMsgId), null);
			}
			//long lnEndTime = System.currentTimeMillis();
			//CommonLog.e("aaa", "Update Count Result Time : " + (lnEndTime - lnStartTime));
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateMsgRead
	 * 단일 Message 내가 읽었는지에 대한 Field Update 
	 * msgId를 비교하여 Update를 수행
	 * @param a_userListData UserListData ArrayList : Update 할 UserListData의 ArrayList
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsgRead(String a_strMsgId, boolean a_isRead)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			if(a_isRead)
				value.put(KEY_CHATTING_ISREAD, 1);
			else
				value.put(KEY_CHATTING_ISREAD, 0);
			
			nCount = m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateSendStatus
	 * Message Send Status Update 
	 * msgId를 비교하여 Update를 수행
	 * @param a_strMsgId MsgId
	 * @param a_nSendStatus SendStatus
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateSendStatus(String a_strMsgId, int a_nSendStatus)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_CHATTING_SENDSTATUS, a_nSendStatus);
			nCount = m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateNoReadUserCount(String a_strMsgId, int a_nCount)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_CHATTING_NOREADUSERCOUNT, a_nCount);
			String strWhere = KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"" + " AND " + KEY_CHATTING_NOREADUSERCOUNT + ">" + a_nCount;
			nCount = m_db.update(TABLE_CHATTING, value, strWhere, null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateNoReadUserCount(ArrayList<ReadCountData> a_arrNoReadCountData)
	{
		int nCount = 0;
		try
		{		
			m_db.beginTransaction();
			//long lnStartTime = System.currentTimeMillis();
			String strOrderBy = "case" +
					" when (" + KEY_CHATTING_SENDSTATUS + "!=2" + ") then 1" + 
					" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED DESC";
			
			Cursor cc =  m_db.query(TABLE_CHATTING, null, null, null, null, null, strOrderBy);
			
			HashMap<String, Integer> indexMap = new HashMap<String, Integer>();
			if (cc.moveToFirst()) {
				do {
					
					//String strUpdateMsgId = cc.getString(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
					//nIDX = cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_IDX));
					indexMap.put(cc.getString(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID)), cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_IDX)));
				} while (cc.moveToNext());
			}
			
			for(ReadCountData data : a_arrNoReadCountData)
			{
				
				
//				if (cc.moveToFirst()) {
//					
//					do {
//						String strMsgId = cc.getString(cc.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
//						if(strMsgId.equals(data.m_strMessageId)){
//							nIDX = cc.getInt(cc.getColumnIndex(ChattingDBAdapter.KEY_IDX));
//							break;
//						}
//					} while (cc.moveToNext());
//				}
						
				ContentValues value = new ContentValues();
				value.put(KEY_CHATTING_NOREADUSERCOUNT, data.m_nCount);
				//String strWhere = KEY_CHATTING_MSGID + "=\"" + data.m_strMessageId + "\"" + " AND " + KEY_CHATTING_NOREADUSERCOUNT + ">" + data.m_nCount;
				String strWhere = KEY_IDX + "=" + indexMap.get(data.m_strMessageId);
				
				m_db.update(TABLE_CHATTING, value, strWhere, null);
				nCount++;
				
			}
			//long lnEndTime = System.currentTimeMillis();
			//CommonLog.e("aaa", "Read Result Time : " + (lnEndTime - lnStartTime));
			m_db.setTransactionSuccessful();
			
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * deleteChattingMessage
	 * Chatting Message 전체 삭제
	 * @return int 삭제한 개수
	 */
	public int deleteChattingMessage()
	{
		return m_db.delete(TABLE_CHATTING, null, null);
	}
	
	/**
	 * deleteChattingMessage
	 * Chatting Message 단일 삭제
	 * MsgId를 비교하여 삭제 수행
	 * @param a_strMsgId 삭제할 Msg Id
	 * @return int 삭제한 개수
	 */
	public int deleteChattingMessage(String a_strMsgId)
	{
		return m_db.delete(TABLE_CHATTING, KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"", null);
	}
	
	public int deleteChattingMessageTimeAfter(long a_lnTime)
	{
		String strWhere = KEY_CHATTING_MSGSENDTIME + "<" + a_lnTime;
		return m_db.delete(TABLE_CHATTING, strWhere, null);
	}
	
	/**
	 * deleteChattingUser
	 * Chatting User 전체 삭제
	 * @return int 삭제한 개수
	 */
	public int deleteChattingUser()
	{
		return m_db.delete(TABLE_CHATTINGUSER, null, null);
	}
	
	/**
	 * deleteChattingUser
	 * Chatting User 전체 삭제
	 * @return int 삭제한 개수
	 */
	public int deleteChattingUser(int a_nUserId)
	{
		return m_db.delete(TABLE_CHATTINGUSER,  KEY_CHATTINGUSER_USERID + "=" + a_nUserId, null);
	}
	
	/**
	 * getChattingMessage
	 * @return Cursor 검색된 Cursor
	 */
	public Cursor getChattingMessage()
	{
		String strOrderBy = "case" +
				" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
				" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED ASC";

		return m_db.query(TABLE_CHATTING, null, null, null, null, null, strOrderBy);
		
//		String strQuery = "select * from " + TABLE_CHATTING;
//		strQuery += " where " + "rowid in (select max(rowid) from " + TABLE_CHATTING + " group by " + KEY_CHATTING_MSGID + ")";
//		strQuery += " order by " + "case" +
//				" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
//				" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED ASC";
//		
//		return m_db.rawQuery(strQuery, null);
	}
	
	public Cursor getChattingMessage(long a_lnLastMessageTime, int a_nLimit)
	{
		String strOrderBy = "case" +
				" when (" + KEY_CHATTING_SENDSTATUS + "!=2" + ") then 1" + 
				" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED DESC";
		
		String strLimit = "" + a_nLimit;
		
		String strWhere = null;
		if(a_lnLastMessageTime > 0)
			strWhere = KEY_CHATTING_MSGSENDTIME + " < " + a_lnLastMessageTime;

		return m_db.query(TABLE_CHATTING, null, strWhere, null, null, null, strOrderBy, strLimit);
		
//		String strQuery = "select * from " + TABLE_CHATTING;
//		if(a_lnLastMessageTime > 0)
//		{
//			strQuery += " where " + KEY_CHATTING_MSGSENDTIME + " < " + a_lnLastMessageTime;
//			strQuery += " and " + "rowid in (select max(rowid) from " + TABLE_CHATTING + " group by " + KEY_CHATTING_MSGID + ")";
//		}
//		else
//			strQuery += " where " + "rowid in (select max(rowid) from " + TABLE_CHATTING + " group by " + KEY_CHATTING_MSGID + ")";
//		
//		strQuery += " order by " + "case" +
//				" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
//				" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED ASC";
//		strQuery += " limit " + a_nLimit;
//		CommonLog.e(getClass(), "strQuery : " + strQuery);
//		return m_db.rawQuery(strQuery, null);
	}
		
	public Cursor getChattingMessage(String a_strPacketId)
	{
		String strOrderBy = "case" +
				" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
				" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED ASC";
		String strWhere = KEY_CHATTING_MSGID + "=\"" + a_strPacketId + "\"";
		return m_db.query(TABLE_CHATTING, null, strWhere, null, null, null, strOrderBy);
	}
	
	public Cursor getCurrentUrgentMessage()
	{
		String strOrderBy = "case" +
				" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
				" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED DESC";
		String strWhere = KEY_CHATTING_MSGTYPE + "=" + StaticString.CHAT_ROOM_URGENT_MESSAGE;
		return m_db.query(TABLE_CHATTING, null, strWhere, null, null, null, strOrderBy, "1");
	}
	
	public Cursor getCurrentMessage()
	{
		String strOrderBy = KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED DESC";
		return m_db.query(TABLE_CHATTING, null, null, null, null, null, strOrderBy, "1");
	}
	
	public Cursor getChattingMessageNotNoReadCount0()
	{
		String strWhere = KEY_CHATTING_NOREADUSERCOUNT + ">0";
		return m_db.query(TABLE_CHATTING, null, strWhere, null, null, null, null);
	}
	
	public Cursor getChattingMessageNotNoReadMine()
	{
		String strWhere = KEY_CHATTING_ISREAD + "=0";
		return m_db.query(TABLE_CHATTING, null, strWhere, null, null, null, null);
	}
	
	public int getNoReadMessageCount()
	{
		int nCount = 0;
		String strQuery = "select count(DISTINCT " + KEY_CHATTING_MSGID + ") from " + TABLE_CHATTING + " where " + KEY_CHATTING_ISREAD + "=0 AND " + KEY_CHATTING_MSG + " != \"\"";
		Cursor cursor = m_db.rawQuery(strQuery, null);
		if(cursor.moveToFirst())
		{
			nCount = cursor.getInt(0);
		}
		cursor.close();
		return nCount;
	}
	
	public Cursor getChattingUser()
	{
		return m_db.query(true, TABLE_CHATTINGUSER, new String[]{KEY_CHATTINGUSER_USERID}, null, null, null, null, null, null);
	}
	
	public int insertChattingMessageNonTransaction(ChattingMessageData a_chattingMsgData)
	{
		
		if(a_chattingMsgData == null)
			return 0;
		
		ContentValues value = new ContentValues();
		value.put(KEY_CHATTING_MSGID, a_chattingMsgData.m_strMsgId);
		value.put(KEY_CHATTING_SENDUSERID, a_chattingMsgData.m_nSendUserId);
		value.put(KEY_CHATTING_MSGSENDTIME, a_chattingMsgData.m_lnMsgSendTime);
		value.put(KEY_CHATTING_MSGTYPE, a_chattingMsgData.m_nMsgType);
		
		String strMsgText = "";
		ArrayList<String> arrMsgNEmoticon = new ArrayList<>();
		try
		{
			LocalAesCrypto crypto = new LocalAesCrypto();
			if(!a_chattingMsgData.m_strEmoticon.equals("")){
				strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
				arrMsgNEmoticon.add(strMsgText);
				arrMsgNEmoticon.add(a_chattingMsgData.m_strEmoticon);
			} else {
				strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			if(!a_chattingMsgData.m_strEmoticon.equals("")){
				arrMsgNEmoticon.add(a_chattingMsgData.m_strMsgText);
				arrMsgNEmoticon.add(a_chattingMsgData.m_strEmoticon);
			} else {
				strMsgText = a_chattingMsgData.m_strMsgText;
			}
		}
		Gson gson = new Gson();
		if(!a_chattingMsgData.m_strEmoticon.equals("")){
			String strMsgNEmoticon = gson.toJson(arrMsgNEmoticon);
			value.put(KEY_CHATTING_MSG, strMsgNEmoticon);
		}else {
			value.put(KEY_CHATTING_MSG, strMsgText);
		}
		if(a_chattingMsgData.m_isRead)
			value.put(KEY_CHATTING_ISREAD, 1);
		else
			value.put(KEY_CHATTING_ISREAD, 0);
		value.put(KEY_CHATTING_SENDSTATUS, a_chattingMsgData.m_nSendStatus);
		value.put(KEY_CHATTING_NOREADUSERCOUNT, a_chattingMsgData.m_nNoReadUserCount);
		String inputString = gson.toJson(a_chattingMsgData.m_SNSNoticeAddedList);
		value.put(KEY_SNSNOTICE_ADDEDLIST,inputString);
		
		return (int)m_db.insert(TABLE_CHATTING, null, value);
		
	
		
	}
	
	/**
	 * insertChattingUser 
	 * Chatting User 단일 추가 Insert Query
	 * @param a_nUserId 추가할 User Id 
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertChattingUserNonTransaction(int a_nUserId)
	{
		
		ContentValues value = new ContentValues();
		value.put(KEY_CHATTINGUSER_USERID, a_nUserId);
		return (int)m_db.insert(TABLE_CHATTINGUSER, null, value);
		
	}
	
	/**
	 * insertChattingUser 
	 * Chatting User 복수 추가 Insert Query
	 * @param a_arrUserIdList 추가할 User Id List Array
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertChattingUserNonTransaction(ArrayList<Integer> a_arrUserIdList)
	{
		int nCount = 0;
		
		for(Integer nUserId : a_arrUserIdList)
		{
			int nResult = 0;
			ContentValues value = new ContentValues();
			value.put(KEY_CHATTINGUSER_USERID, nUserId);
			nResult = (int)m_db.insert(TABLE_CHATTINGUSER, null, value);
			if(nResult == -1){
				nCount = -1;
				break;
			} else {
				nCount++;
			}
		}
		
		return nCount;
	}
	
	/**
	 * updateMsg
	 * Message Update 
	 * msgId를 비교하여 Update를 수행
	 * @param ChattingMessageData Message Data
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsgNonTransaction(ChattingMessageData a_chattingMsgData)
	{
		ContentValues value = new ContentValues();
		
		value.put(KEY_CHATTING_MSGSENDTIME, a_chattingMsgData.m_lnMsgSendTime);
		value.put(KEY_CHATTING_SENDUSERID, a_chattingMsgData.m_nSendUserId);
		value.put(KEY_CHATTING_MSGTYPE, a_chattingMsgData.m_nMsgType);
		String strMsgText = "";
		try
		{
			LocalAesCrypto crypto = new LocalAesCrypto();
			strMsgText = crypto.encrypt(a_chattingMsgData.m_strMsgText);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			strMsgText = a_chattingMsgData.m_strMsgText;
		}
		value.put(KEY_CHATTING_MSG, strMsgText);
		if(a_chattingMsgData.m_isRead)
			value.put(KEY_CHATTING_ISREAD, 1);
		else
			value.put(KEY_CHATTING_ISREAD, 0);
		value.put(KEY_CHATTING_SENDSTATUS, a_chattingMsgData.m_nSendStatus);
		value.put(KEY_CHATTING_NOREADUSERCOUNT, a_chattingMsgData.m_nNoReadUserCount);
		
		return m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + a_chattingMsgData.m_strMsgId + "\"", null);
	}
	
	/**
	 * updateMsgRead
	 * 복수 Message 내가 읽었는지에 대한 Field Update 
	 * msgId를 비교하여 Update를 수행
	 * @param a_mapIsReadData MsgId와 isRead가 쌍으로 이루어진 HashMap
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsgReadNonTransaction(HashMap<String, Boolean> a_mapIsReadData)
	{
		int nCount = 0;
		
		Iterator<String> iterator = a_mapIsReadData.keySet().iterator();
		
		while(iterator.hasNext())
		{
			int nResult = 0;
			String strMsgId = iterator.next();
			Boolean isRead = a_mapIsReadData.get(strMsgId);
			ContentValues value = new ContentValues();
			if(isRead)
				value.put(KEY_CHATTING_ISREAD, 1);
			else
				value.put(KEY_CHATTING_ISREAD, 0);
			
			nResult = (int)m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + strMsgId + "\"", null);
			if(nResult == -1){
				nCount = -1;
				break;
			} else {
				nCount++;
			}
		}
		
		return nCount;
	}
	
	/**
	 * updateMsgRead
	 * 단일 Message 내가 읽었는지에 대한 Field Update 
	 * msgId를 비교하여 Update를 수행
	 * @param a_userListData UserListData ArrayList : Update 할 UserListData의 ArrayList
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateMsgReadNonTransaction(String a_strMsgId, boolean a_isRead)
	{
		ContentValues value = new ContentValues();
		if(a_isRead)
			value.put(KEY_CHATTING_ISREAD, 1);
		else
			value.put(KEY_CHATTING_ISREAD, 0);
		
		return m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"", null);
	}
	
	/**
	 * updateSendStatus
	 * Message Send Status Update 
	 * msgId를 비교하여 Update를 수행
	 * @param a_strMsgId MsgId
	 * @param a_nSendStatus SendStatus
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateSendStatusNonTransaction(String a_strMsgId, int a_nSendStatus)
	{
		ContentValues value = new ContentValues();
		value.put(KEY_CHATTING_SENDSTATUS, a_nSendStatus);
		return m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"", null);
	}
	
	public int updateChattingMessageNonTransaction(ChattingMessageData data)
	{
		ContentValues value = new ContentValues();
		value.put(KEY_CHATTING_MSGSENDTIME, data.m_lnMsgSendTime);
		value.put(KEY_CHATTING_SENDUSERID, data.m_nSendUserId);
		value.put(KEY_CHATTING_MSGTYPE, data.m_nMsgType);
		String strMsgText = "";
		try
		{
			LocalAesCrypto crypto = new LocalAesCrypto();
			strMsgText = crypto.encrypt(data.m_strMsgText);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			strMsgText = data.m_strMsgText;
		}
		value.put(KEY_CHATTING_MSG, strMsgText);
		if(data.m_isRead)
			value.put(KEY_CHATTING_ISREAD, 1);
		else
			value.put(KEY_CHATTING_ISREAD, 0);
		value.put(KEY_CHATTING_SENDSTATUS, data.m_nSendStatus);
		value.put(KEY_CHATTING_NOREADUSERCOUNT, data.m_nNoReadUserCount);
		
		return m_db.update(TABLE_CHATTING, value, KEY_CHATTING_MSGID + "=\"" + data.m_strMsgId + "\"", null);
	}
	
	public int updateNoReadUserCountNonTransaction(String a_strMsgId, int a_nCount)
	{
		ContentValues value = new ContentValues();
		value.put(KEY_CHATTING_NOREADUSERCOUNT, a_nCount);
		String strWhere = KEY_CHATTING_MSGID + "=\"" + a_strMsgId + "\"" + " AND " + KEY_CHATTING_NOREADUSERCOUNT + ">" + a_nCount;
		return m_db.update(TABLE_CHATTING, value, strWhere, null);
	}
	
	public int updateNoReadUserCountNonTransaction(ArrayList<ReadCountData> a_arrNoReadCountData)
	{
		int nCount = 0;
		for(ReadCountData data : a_arrNoReadCountData)
		{
			int nResult = 0;
			ContentValues value = new ContentValues();
			value.put(KEY_CHATTING_NOREADUSERCOUNT, data.m_nCount);
			String strWhere = KEY_CHATTING_MSGID + "=\"" + data.m_strMessageId + "\"" + " AND " + KEY_CHATTING_NOREADUSERCOUNT + ">" + data.m_nCount;
			nResult = m_db.update(TABLE_CHATTING, value, strWhere, null);
			if(nResult == -1){
				nCount = -1;
				break;
			} else {
				nCount++;
			}
		}
		
		return nCount;
	}
	
	// SQLite Open Helper Class
	private class ChattingDBHelper extends SQLiteOpenHelper
	{

		public ChattingDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(CHATTING_CREATE);
			db.execSQL(CHATTINGUSER_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			if(oldVersion == 1 && newVersion == 2)
			{
				ArrayList<ChattingMessageData> arrOldChattingMessageData = getChattingMessageFromChattingDBVersion1(db);
				ArrayList<Integer> arrChattingUser = getChattingUserFromChattingDBVersion1(db);
				db.execSQL(CHATTING_DROP);
				db.execSQL(CHATTINGUSER_DROP);
				onCreate(db);
				insertChattingMessageToChattingDBVersion2(db, arrOldChattingMessageData);
				insertChattingUserToChattingDBVersion2(db, arrChattingUser);
				
			}
		}
		
		private Cursor getChattingMessage(SQLiteDatabase db)
		{
			String strOrderBy = "case" +
					" when (" + KEY_CHATTING_SENDSTATUS + "=2" + ") then 1" + 
					" else 2 end, " + KEY_CHATTING_MSGSENDTIME + " COLLATE LOCALIZED ASC";

			return db.query(TABLE_CHATTING, null, null, null, null, null, strOrderBy);
		}
		
		private ArrayList<ChattingMessageData> getChattingMessageFromChattingDBVersion1(SQLiteDatabase db)
		{
			ArrayList<ChattingMessageData> arrChattingMsgData = new ArrayList<ChattingMessageData>();
			
			Cursor cursor = getChattingMessage(db);
			if (cursor.moveToFirst()) {
				do {
					String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGID));
					if(strMsgId == null || strMsgId.equals(""))
						continue;
					
					String strMsgText = cursor.getString(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSG));
					if(strMsgText == null || strMsgText.equals(""))
						continue;
					
					int nMsgIdx = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_IDX));
					
					int nSendUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDUSERID));
					long lnSendTime = cursor.getLong(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGSENDTIME));
					int nMsgType = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_MSGTYPE));
					boolean isRead = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_ISREAD)) == 1 ? true : false;
					int nSendStatus = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTING_SENDSTATUS));
					int nNoReadUserCount = 0;
					
					ChattingMessageData data = new ChattingMessageData();
					data.m_nIdx = nMsgIdx;
					data.m_strMsgId = strMsgId;
					data.m_nSendUserId = nSendUserId;
					data.m_lnMsgSendTime = lnSendTime;
					data.m_nMsgType = nMsgType;
					data.m_strMsgText = strMsgText;
					data.m_isRead = isRead;
					data.m_nSendStatus = nSendStatus;
					data.m_nNoReadUserCount = nNoReadUserCount;
					
					arrChattingMsgData.add(data);
						
				} while (cursor.moveToNext());
			}

			cursor.close();
			
			return arrChattingMsgData;
		}
		
		private ArrayList<Integer> getChattingUserFromChattingDBVersion1(SQLiteDatabase db)
		{
			ArrayList<Integer> arrChattingUser = new ArrayList<Integer>();
			Cursor cursor = getChattingUser(db);
			if(cursor.moveToFirst())
			{
				do
				{
					int nUserId = cursor.getInt(cursor.getColumnIndex(ChattingDBAdapter.KEY_CHATTINGUSER_USERID));
					arrChattingUser.add(nUserId);
				}while(cursor.moveToNext());
			}
			
			cursor.close();
			return arrChattingUser;
		}
		public Cursor getChattingUser(SQLiteDatabase db)
		{
			return db.query(true, TABLE_CHATTINGUSER, new String[]{KEY_CHATTINGUSER_USERID}, null, null, null, null, null, null);
		}
		
		private int insertChattingMessageToChattingDBVersion2(SQLiteDatabase db, ArrayList<ChattingMessageData> a_arrData)
		{
			int nCount = 0;
			
			if(a_arrData == null || a_arrData.size() == 0)
				return 0;
			
			try
			{
				db.beginTransaction();
				
				for(ChattingMessageData data : a_arrData)
				{
					ContentValues value = new ContentValues();
					value.put(KEY_CHATTING_MSGID, data.m_strMsgId);
					value.put(KEY_CHATTING_SENDUSERID, data.m_nSendUserId);
					value.put(KEY_CHATTING_MSGSENDTIME, data.m_lnMsgSendTime);
					value.put(KEY_CHATTING_MSGTYPE, data.m_nMsgType);
					
					String strMsgText = "";
					try
					{
						LocalAesCrypto crypto = new LocalAesCrypto();
						strMsgText = crypto.encrypt(data.m_strMsgText);
					}
					catch(Exception e)
					{
						e.printStackTrace();
						strMsgText = data.m_strMsgText;
					}
					
					value.put(KEY_CHATTING_MSG, strMsgText);
					
					if(data.m_isRead)
						value.put(KEY_CHATTING_ISREAD, 1);
					else
						value.put(KEY_CHATTING_ISREAD, 0);
					value.put(KEY_CHATTING_SENDSTATUS, data.m_nSendStatus);
					value.put(KEY_CHATTING_NOREADUSERCOUNT, data.m_nNoReadUserCount);
					
					db.insert(TABLE_CHATTING, null, value);
					nCount++;
				}
				db.setTransactionSuccessful();
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				nCount = -1;
			}
			finally{
				db.endTransaction();
			}
			
			return nCount;
		}
		
		private int insertChattingUserToChattingDBVersion2(SQLiteDatabase db, ArrayList<Integer> a_arrUserIdList)
		{
			int nCount = 0;
			
			try
			{
				db.beginTransaction();
				for(Integer nUserId : a_arrUserIdList)
				{
					ContentValues value = new ContentValues();
					value.put(KEY_CHATTINGUSER_USERID, nUserId);
					db.insert(TABLE_CHATTINGUSER, null, value);
					nCount++;
				}
				
				db.setTransactionSuccessful();
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				nCount = -1;
			}
			finally{
				db.endTransaction();
			}
			
			return nCount;
		}
	}
}
