package com.gmp.rusk.act;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.util.Pair;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.customview.CustomFragmentActivity;
import com.gmp.rusk.customview.SysNoticePopupAct;
import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.ChannelUnreadsData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.NoticeChannelData;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.fragment.MainChannelFlag;
import com.gmp.rusk.fragment.MainChatListFlag;
import com.gmp.rusk.fragment.MainSettingFlag;
import com.gmp.rusk.fragment.MainUserSearchFlag;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.request.DeleteOneRoomSyncReq;
import com.gmp.rusk.request.GetAdminNoticeReq;
import com.gmp.rusk.request.GetGroupListReq;
import com.gmp.rusk.request.GetGroupUnreadsReq;
import com.gmp.rusk.request.GetGroupUserReq;
import com.gmp.rusk.request.GetOneRoomSyncReq;
import com.gmp.rusk.request.PutGroupExitReq;
import com.gmp.rusk.request.PutGroupInviteAcceptReq;
import com.gmp.rusk.request.PutGroupInviteRejectionReq;
import com.gmp.rusk.request.PutGroupPositionReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetAdminNoticeRes;
import com.gmp.rusk.response.GetGroupListRes;
import com.gmp.rusk.response.GetGroupUnreadsRes;
import com.gmp.rusk.response.GetGroupUserRes;
import com.gmp.rusk.response.GetOneRoomSyncRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;
import com.woxthebox.draglistview.DragItem;
import com.woxthebox.draglistview.DragItemAdapter;
import com.woxthebox.draglistview.DragListView;

import java.util.ArrayList;
import java.util.HashMap;

import me.thanel.swipeactionview.SwipeActionView;

/**
 * MainTabAct
 * 
 * @author subi78 MainTab Menu Activity
 */
public class MainTabAct extends CustomFragmentActivity implements OnClickListener{
	// Tab Tag
	//private final String TAB_FELLOWLIST 		= "FellowList"; // 동료 리스트
	private final String TAB_CHATLIST 			= "ChatList"; // 채팅 리스트
	private final String TAB_SNSLIST			= "SNS";	// 모임
	private final String TAB_ORGANCHART 		= "OrganChart"; // 조직도
	private final String TAB_SETTING 			= "Setting"; // 설정

	//private final int TAB_INDEX_FELLOWLIST 		= 0;
	private final int TAB_INDEX_SNSLIST 		= 0;
	private final int TAB_INDEX_CHATLIST 		= 1;
	private final int TAB_INDEX_ORGANCHART 		= 2;
	private final int TAB_INDEX_SETTING 		= 3;
	private final int TAB_INDEX_MAX 			= 4;

	//public final int TAB_RIGHTBTN_FELLOWLIST 	= 0;
	static public final int TAB_BTN_SNSLIST_NOLIST = -1;
	static public final int TAB_BTN_SNSLIST 		= 0;
	static public final int TAB_BTN_CHATLIST 		= 1;
	static public final int TAB_BTN_ORGANCHART 	= 2;
	static public final int TAB_BTN_SETTTING 		= 3;
	static public final int TAB_BTN_SNSLIST_NOTICE = 5;
	static public final int TAB_BTN_ERROR_CASE = 6;

	static public final int TAB_BTN_ORGANCHART_MAKEROOM 	= 7;



	public TabHost mTabHost;
	TabManager mTabManager;
	//TextView m_tvFellowListTabCount;
	TextView m_tvChatListTabCount;
	TextView m_tvSNSListTabCount;
	TextView m_tvSettingTabCount;
	OnNotifyListener m_NotifyListener;
	OnNotifyChatListListener m_NotifyChatListListener;
	private OnNotifySNSPushListener m_notifySNSPushListenter;

	int m_nCurrentTabType = -1;

	CommonPopup m_Popup;
	//int m_nPopupType;

	//방장 전달할 사람 ID 
	int m_nPassOwner = 0;
	//해당 방 ID
	String m_strRoomID = null;
	private boolean isTwo = false;

	int m_nBadgeCount = 0;
	
	private String m_strLastChatRoomId = "";
	private int m_nLastChatRoomBadge = -1;
	
	private ApprovalRequestBadgeBroadcastReceiver m_recvBadge = null;
	private SNSPushBadgeBroadcastReceiver m_recvSNSPushBadge = null;
	private ChatRoomReadBroadcastReceiver m_recvRead = null;
	private FinishChatRoomBroadcastReceiver m_recvFinishChatRoom = null;

	private int m_nSysNoticeNo = 0;

	boolean m_isNowOnTutorail = false;


	GestureDetector m_GestureDetector;
	public SwipeActionView m_SwipeActionView;

	private DragListView m_draglvList = null;
	private DrawerLayout m_DrawerLayout = null;
	public ArrayList<NoticeChannelData> m_arrNoticeChannel = null;
	public ArrayList<ChannelData> m_arrInvitingGroup = null;
	public ArrayList<ChannelData> m_arrMemberGroup = null;
	private ChannelListAdapter m_ChannelListAdapter = null;
	private ArrayList<Pair<Long, ChannelData>> m_arrItem = null;
	//채널별 뱃지 카운트
	private SparseArray<Integer> m_arrBadgetCount;

	OnChannelInfoListener m_ChannelInfoListener;
	public int m_nChannelNo = -1;
	public String m_strChannelName = "";
	public boolean m_isChannelOwner = false;
	public int m_nChannelUserCount = -1;
	public boolean m_isChannelThreadAlarmOn = true;
	public boolean m_isChannelCommentAlarmOn = true;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

		setContentView(R.layout.act_maintab);

		m_GestureDetector = new GestureDetector(MainTabAct.this, mGestureListener);
		Bundle bundle = getIntent().getExtras();
		if (bundle == null) {
			SharedPref pref = SharedPref.getInstance(this);
			if (pref.getBooleanPref(SharedPref.PREF_TUTORIAL_NEVERSHOW, false)) {
				initUI();
			} else {
				m_isNowOnTutorail = true;
				Intent intent = new Intent(this, TutorialAct.class);
				startActivityForResult(intent, StaticString.REQUESTCODE_TUTORIAL);
			}
		} else {
			initUI();
		}

	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == StaticString.REQUESTCODE_TUTORIAL){
			m_isNowOnTutorail = false;
			initUI();
		}
		else if(requestCode == MainChannelFlag.REQUEST_CODE_GROUPEDIT && resultCode == RESULT_OK){
			m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
			m_ChannelInfoListener.setInfo(m_nChannelNo, m_strChannelName, false);
		} else if(requestCode == MainChannelFlag.REQUEST_CODE_GROUPCREATE && resultCode == RESULT_OK){
			int a_nChannelNo = data.getIntExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPID,0);
			String a_strChannelName = data.getStringExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPNAME);
			m_nChannelNo = a_nChannelNo;
			m_strChannelName = a_strChannelName;
			m_ChannelInfoListener.setInfo(a_nChannelNo, a_strChannelName, false);
			m_DrawerLayout.closeDrawer(Gravity.LEFT, false);
			m_DrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
		} else if((requestCode == MainChannelFlag.REQUEST_CODE_OWNER || requestCode == MainChannelFlag.REQUEST_CODE_EXIT_OTHER) && resultCode == RESULT_OK){
			m_ChannelInfoListener.setRefresh(m_nChannelNo);
		} else if(requestCode == MainChannelFlag.REQUEST_CODE_OWNER_EXIT && resultCode == RESULT_OK){
			m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
			SharedPref pref = SharedPref.getInstance(MainTabAct.this);
			pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, -1);
			getSNSGroupList();
		} else if(requestCode == MainChannelFlag.REQUEST_CODE_ALARMSET && resultCode == RESULT_OK){
			m_isChannelThreadAlarmOn = data.getExtras().getBoolean(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISTHREAD_ALARMON);
			m_isChannelCommentAlarmOn = data.getExtras().getBoolean(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISCOMMENT_ALARMON);
		}
	}

	public void setTopButton(int a_nType){

		ImageView ivBtnLeft = (ImageView)findViewById(R.id.iv_maintab_left_btn_one);
		ImageView ivBtnRightTwoFirst = (ImageView)findViewById(R.id.iv_maintab_right_btn_two_first);
		ImageView ivBtnRightTwoSecond = (ImageView)findViewById(R.id.iv_maintab_right_btn_two_second);
		ImageView ivBtnRightOne = (ImageView)findViewById(R.id.iv_maintab_right_btn_one);
		LinearLayout layoutBtnRightTwo = (LinearLayout)findViewById(R.id.layout_maintab_right_btn_two);
		LinearLayout layoutBtnRightOne = (LinearLayout)findViewById(R.id.layout_maintab_right_btn_one);
		if(a_nType == TAB_BTN_SNSLIST){
			m_nCurrentTabType = TAB_BTN_SNSLIST;
			ivBtnLeft.setBackgroundResource(R.drawable.btn_btn_top_menu);
			ivBtnLeft.setVisibility(View.VISIBLE);
			layoutBtnRightOne.setVisibility(View.GONE);
			layoutBtnRightTwo.setVisibility(View.VISIBLE);
			ivBtnRightTwoFirst.setBackgroundResource(R.drawable.btn_btn_top_search);
			ivBtnRightTwoSecond.setBackgroundResource(R.drawable.btn_btn_top_edit);
			ivBtnRightTwoFirst.setEnabled(true);
			ivBtnRightTwoSecond.setEnabled(true);

			ivBtnLeft.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					m_DrawerLayout.openDrawer(Gravity.LEFT);
				}
			});
			ivBtnRightTwoFirst.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(MainTabAct.this, SNSGroupDetailSearchAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, m_nChannelNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, m_strChannelName);
					startActivity(intent);
				}
			});

			ivBtnRightTwoSecond.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					m_DrawerLayout.openDrawer(Gravity.RIGHT);
				}
			});
		} else if(a_nType == TAB_BTN_SNSLIST_NOLIST){
			m_nCurrentTabType = TAB_BTN_SNSLIST_NOLIST;
			ivBtnLeft.setBackgroundResource(R.drawable.btn_btn_top_menu);
			ivBtnLeft.setVisibility(View.VISIBLE);
			layoutBtnRightOne.setVisibility(View.GONE);
			layoutBtnRightTwo.setVisibility(View.VISIBLE);
			ivBtnRightTwoFirst.setBackgroundResource(R.drawable.btn_top_search_pressed);
			ivBtnRightTwoSecond.setBackgroundResource(R.drawable.btn_top_edit_disabled);
			ivBtnRightTwoFirst.setEnabled(false);
			ivBtnRightTwoSecond.setEnabled(false);

			ivBtnLeft.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					m_DrawerLayout.openDrawer(Gravity.LEFT);
				}
			});


			m_DrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED,Gravity.RIGHT);

		} else if(a_nType == TAB_BTN_SNSLIST_NOTICE){
			m_nCurrentTabType = TAB_BTN_SNSLIST_NOTICE;
			ivBtnLeft.setBackgroundResource(R.drawable.btn_btn_top_menu);
			ivBtnLeft.setVisibility(View.VISIBLE);
			layoutBtnRightOne.setVisibility(View.VISIBLE);
			layoutBtnRightTwo.setVisibility(View.GONE);
			ivBtnRightOne.setBackgroundResource(R.drawable.btn_btn_top_search_2);
			ivBtnRightOne.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(MainTabAct.this, SNSNoticeSearchAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID,m_nChannelNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME,m_strChannelName);
					startActivity(intent);

				}
			});

			ivBtnLeft.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					m_DrawerLayout.openDrawer(Gravity.LEFT);
				}
			});


		}
		else if(a_nType == TAB_BTN_CHATLIST){
			m_nCurrentTabType = TAB_BTN_CHATLIST;
			ivBtnLeft.setVisibility(View.GONE);
			layoutBtnRightOne.setVisibility(View.VISIBLE);
			layoutBtnRightTwo.setVisibility(View.GONE);
			ivBtnRightOne.setBackgroundResource(R.drawable.btn_btn_top_add);
			ivBtnRightOne.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(MainTabAct.this, ChatInviteTabAct.class);
					startActivity(intent);
				}
			});
		} else if(a_nType == TAB_BTN_ORGANCHART){
			m_nCurrentTabType = TAB_BTN_ORGANCHART;
			ivBtnLeft.setVisibility(View.GONE);
			layoutBtnRightOne.setVisibility(View.GONE);
			layoutBtnRightTwo.setVisibility(View.GONE);

		} else if(a_nType == TAB_BTN_ORGANCHART_MAKEROOM){
			m_nCurrentTabType = TAB_BTN_ORGANCHART_MAKEROOM;
			ivBtnLeft.setVisibility(View.GONE);
			layoutBtnRightOne.setVisibility(View.VISIBLE);
			layoutBtnRightTwo.setVisibility(View.GONE);
			ivBtnRightOne.setBackgroundResource(R.drawable.btn_btn_top_add);
			ivBtnRightOne.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent intent = new Intent(MainTabAct.this, OrganChartMakeChatAct.class);
					startActivity(intent);
				}
			});
		}
		else if(a_nType == TAB_BTN_SETTTING){
			m_nCurrentTabType = TAB_BTN_SETTTING;
			ivBtnLeft.setVisibility(View.GONE);
			layoutBtnRightOne.setVisibility(View.GONE);
			layoutBtnRightTwo.setVisibility(View.GONE);
		} else if(a_nType == TAB_BTN_ERROR_CASE){
			m_nCurrentTabType = TAB_BTN_ERROR_CASE;
			ivBtnLeft.setBackgroundResource(R.drawable.btn_btn_top_menu);
			ivBtnLeft.setVisibility(View.VISIBLE);
			layoutBtnRightOne.setVisibility(View.GONE);
			layoutBtnRightTwo.setVisibility(View.GONE);

			ivBtnLeft.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					m_DrawerLayout.openDrawer(Gravity.LEFT);
				}
			});
		}

	}
	//다른 앱에서 진입시 사용자 검색으로 이동 되는데, 그때 CurrnetTab 값을 이용해서
	//UI를 정리함. 채널 리스트로 다시 돌아올때 CurrentTab값을 제거해 주기 위해 사용
	public void setCurrentTabIndexChange(){
		m_nCurrentTabType = -1;
	}

	private void initUI(){

		m_draglvList = (DragListView)findViewById(R.id.layout_drag_listview);
		m_DrawerLayout = (DrawerLayout)findViewById(R.id.layout_channel_drawer);
		m_DrawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
			@Override
			public void onDrawerSlide(View drawerView, float slideOffset) {

			}

			@Override
			public void onDrawerOpened(View drawerView) {
				if(m_DrawerLayout.isDrawerOpen(Gravity.LEFT)) {
					getSNSGroupList();
				} else if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
					setChannelMenuUI();
				}
			}

			@Override
			public void onDrawerClosed(View drawerView) {

			}

			@Override
			public void onDrawerStateChanged(int newState) {

			}
		});
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(StaticString.BROADCAST_APPROVALREQUESTBADGE_RECEIVER);

		if (m_recvBadge == null)
			m_recvBadge = new ApprovalRequestBadgeBroadcastReceiver();

		registerReceiver(m_recvBadge, intentFilter, StaticString.BROADCAST_PERMISSION_APPROVALREQUESTBADGE, null);

		setSNSPushBadgeReceiver();
		setFinishChatRoomReceiver();

		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();

		View[] viewTabs = new View[TAB_INDEX_MAX];
		for (int i = 0; i < TAB_INDEX_MAX; i++) {
			LayoutInflater inflater = getLayoutInflater();
			viewTabs[i] = inflater.inflate(R.layout.layout_tabitem_main, null);
		}

		//ImageView ivFellowListTab = (ImageView) viewTabs[TAB_INDEX_FELLOWLIST].findViewById(R.id.iv_tabitem_mainitem); // 동료 리스트 Tab
		//m_tvFellowListTabCount = (TextView) viewTabs[TAB_INDEX_FELLOWLIST].findViewById(R.id.tv_tabitem_count); // 동료 리스트 New
		ImageView ivSNSListTab = (ImageView) viewTabs[TAB_INDEX_SNSLIST].findViewById(R.id.iv_tabitem_mainitem); // 모임 리스트 Tab
		m_tvSNSListTabCount = (TextView) viewTabs[TAB_INDEX_SNSLIST].findViewById(R.id.tv_tabitem_count); // 모임 리스트 안 읽은 글 갯수 합
		ImageView ivChatListTab = (ImageView) viewTabs[TAB_INDEX_CHATLIST].findViewById(R.id.iv_tabitem_mainitem); // 채팅 리스트 Tab
		m_tvChatListTabCount = (TextView) viewTabs[TAB_INDEX_CHATLIST].findViewById(R.id.tv_tabitem_count); // 채팅 리스트 안 읽은 글 갯수 합
		m_tvChatListTabCount.setBackgroundResource(R.drawable.menu_badge_ta);
		ImageView ivOrganChartTab = (ImageView) viewTabs[TAB_INDEX_ORGANCHART].findViewById(R.id.iv_tabitem_mainitem); // 조직도 Tab
		ImageView ivSettingTab = (ImageView) viewTabs[TAB_INDEX_SETTING].findViewById(R.id.iv_tabitem_mainitem); // Setting Tab
		m_tvSettingTabCount = (TextView) viewTabs[TAB_INDEX_SETTING].findViewById(R.id.tv_tabitem_count); // 설정 New

		// Tab Image 설정
		//ivFellowListTab.setImageResource(R.drawable.tabitem_main_fellowlist);
		ivChatListTab.setImageResource(R.drawable.tabitem_main_chatlist);
		ivChatListTab.setBackgroundResource(R.drawable.tabitem_background);

		ivSNSListTab.setImageResource(R.drawable.tabitem_main_snslist);
		ivSNSListTab.setBackgroundResource(R.drawable.tabitem_background);

		ivOrganChartTab.setImageResource(R.drawable.tabitem_main_organchart);
		ivOrganChartTab.setBackgroundResource(R.drawable.tabitem_background);

		ivSettingTab.setImageResource(R.drawable.tabitem_main_setting);
		ivSettingTab.setBackgroundResource(R.drawable.tabitem_background);

		mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

		//mTabManager.addTab(mTabHost.newTabSpec(TAB_FELLOWLIST).setIndicator(viewTabs[TAB_INDEX_FELLOWLIST]), MainFellowListFlag.class, null);
		mTabManager.addTab(mTabHost.newTabSpec(TAB_SNSLIST).setIndicator(viewTabs[TAB_INDEX_SNSLIST]), MainChannelFlag.class, null);
		mTabManager.addTab(mTabHost.newTabSpec(TAB_CHATLIST).setIndicator(viewTabs[TAB_INDEX_CHATLIST]), MainChatListFlag.class, null);
		mTabManager.addTab(mTabHost.newTabSpec(TAB_ORGANCHART).setIndicator(viewTabs[TAB_INDEX_ORGANCHART]), MainUserSearchFlag.class, null);
		mTabManager.addTab(mTabHost.newTabSpec(TAB_SETTING).setIndicator(viewTabs[TAB_INDEX_SETTING]), MainSettingFlag.class, null);
		Bundle bundle = getIntent().getExtras();
		if (bundle != null) {
			if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH, false))
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISKICK, false))
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_APPROVAL, false)) {
				// mTabHost.setCurrentTab(3);
				m_handlerMoveTab.sendEmptyMessage(3);
				Intent intent = new Intent(MainTabAct.this, ApprovalTabAct.class);
				startActivity(intent);
			} else if(bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISMOVETAB)){
				m_handlerMoveTab.sendEmptyMessage(1);
			}
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM)) {
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
				int nUserNo = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO);
				Intent intent = new Intent(MainTabAct.this, ChatRoomAct.class);
				if(nUserNo == 1){
					nUserNo = App.m_MyUserInfo.m_nUserNo;
				}
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO, nUserNo);
				startActivity(intent);
			} else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP)) {
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
				String strRoomId = bundle.getString(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID);
				Intent intent = new Intent(MainTabAct.this, ChatRoomGroupAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID, strRoomId);
				intent.putExtra(IntentKeyString.INTENT_KEY_CHATROOMGROUP_FROM_PUSH, true);
				startActivity(intent);
			}  else if(bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSINVITE)){
				m_handlerMoveTab.sendEmptyMessage(0);
			}
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSBOARD, false)) {
				// mTabHost.setCurrentTab(3);
				Message message = new Message();

				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);

				Bundle bundleSNS = new Bundle();
				bundleSNS.putBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSBOARD, true);
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nSNSGroupId);
				bundleSNS.putString(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, "");
				message.what = 0;
				message.setData(bundle);
				m_handlerMoveTab.sendMessage(message);
			}
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, false)) {
				// mTabHost.setCurrentTab(3);
//				m_handlerMoveTab.sendEmptyMessage(2);
//				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
//				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
//				int nSNSReplyId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID);
//
//				Intent intent = new Intent(this, SNSBoardDetailAct.class);
//				intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPID, nSNSGroupId);
//				intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPNAME, "");
//				intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, nSNSBoardId);
//				intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, true);
//				startActivity(intent);
				Message message = new Message();

				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
				int nSNSReplyId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID);

				Bundle bundleSNS = new Bundle();
				bundleSNS.putBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, true);
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID, nSNSGroupId);
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID, nSNSBoardId);
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID, nSNSReplyId);
				message.what = 0;
				message.setData(bundle);
				m_handlerMoveTab.sendMessage(message);
			}
		}
		if(App.m_isOtherApp){
			App.m_isOtherApp = false;
			m_handlerMoveTab.sendEmptyMessage(2);
		}
		requestGetAdminNotice();
	}
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		if (m_recvBadge != null) {
			unregisterReceiver(m_recvBadge);
			m_recvBadge = null;
		}
		
		removeSNSPushBadgeReceiver();
		removeFinishChatRoomReceiver();
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if(m_OnKeyBackPressedListener != null){
			m_OnKeyBackPressedListener.onBack();
		}
		else if(m_DrawerLayout.isDrawerOpen(Gravity.LEFT)){
			m_DrawerLayout.closeDrawer(Gravity.LEFT);
		} else if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
			m_DrawerLayout.closeDrawer(Gravity.RIGHT);
		}
		else if (!isTwo) {
			Toast.makeText(this, getString(R.string.press_back_key), Toast.LENGTH_SHORT).show();
			myTimer timer = new myTimer(2000, 1); // 2초동안 수행
			timer.start(); // 타이머를 이용해줍시다
		} else // super.onBackPressed();
		{
			// android.os.Process.killProcess(android.os.Process.myPid()); //프로세스 끝내기
			//super.onBackPressed();

			/*Intent intent = new Intent();
			intent.setAction("android.intent.action.MAIN");
			intent.addCategory("android.intent.category.HOME");
			startActivity(intent);*/
			moveTaskToBack(true);
		}
	}

	public void setSwipeView(SwipeActionView view){
		m_SwipeActionView = view;
	}

/*	@Override
	public boolean onTouchEvent(MotionEvent event) {
		this.m_GestureDetector.onTouchEvent(event);
		return super.onTouchEvent(event);
	}*/

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		this.m_GestureDetector.onTouchEvent(ev);
		return super.dispatchTouchEvent(ev);
	}

	GestureDetector.SimpleOnGestureListener mGestureListener = new GestureDetector.SimpleOnGestureListener()

	{
		@Override
		public boolean onDown(MotionEvent e) {
			if(m_SwipeActionView != null){
				m_SwipeActionView.moveToOriginalPosition();
				m_SwipeActionView = null;
			}
			return false;
		}

		@Override
		public void onShowPress(MotionEvent e) {

		}

		@Override
		public boolean onSingleTapUp(MotionEvent e) {
			return false;
		}

		@Override
		public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
			if(m_SwipeActionView != null){
				m_SwipeActionView.moveToOriginalPosition();
				m_SwipeActionView = null;
			}
			return false;
		}

		@Override
		public void onLongPress(MotionEvent e) {

		}

		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
			return false;
		}
	};




	public interface onKeyBackPressedListener {
		public void onBack();
	}
	private onKeyBackPressedListener m_OnKeyBackPressedListener;

	public void setOnKeyBackPressedListener(onKeyBackPressedListener listener) {
		m_OnKeyBackPressedListener = listener;
	}
	@Override
	protected void onPostResume() {
		super.onPostResume();
		if(!m_isNowOnTutorail) {
			int nNewFellowCount = 0;
			setChatListNoReadCountBadge(m_strLastChatRoomId);
			if (App.m_EntryData != null) {
				String nYesterdayTime = Utils.getPrevHourTime();
				if (App.m_arrFellowListData != null) {
					for (FellowListData data : App.m_arrFellowListData) {
//				CommonLog.e("", "addtime : " + data.m_strFellowAddTime);
//				CommonLog.e("", "hidetime : " + nYesterdayTime);
						if (data.m_strFellowAddTime != null && !data.m_strFellowAddTime.equals("")) {
							if (Long.parseLong(data.m_strFellowAddTime) > Long.parseLong(nYesterdayTime)) {
								nNewFellowCount++;
							}
						}
					}
				}
			}
			/*if (nNewFellowCount != 0) {
				m_tvFellowListTabCount.setVisibility(View.VISIBLE);
				m_tvFellowListTabCount.setText("" + nNewFellowCount);
			} else {
				m_tvFellowListTabCount.setVisibility(View.GONE);
			}*/
			CommonLog.e("MainTabAct", "MainTabAct : resume");

			setAppRovalBadgeUi();
			notifySNSListFragment();
		}
	}
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(m_DrawerLayout != null && m_DrawerLayout.isDrawerOpen(Gravity.LEFT)){
			getSNSGroupList();
		} else {
			getSNSBadgeCount();
		}
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		m_hInitLastChatRoomInfo.sendEmptyMessage(0);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		CommonLog.e(this, "onNewIntent");
		Bundle bundle = intent.getExtras();
		if (bundle != null) {
			if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH, false))
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISKICK, false))
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_APPROVAL, false)) {
				// mTabHost.setCurrentTab(3);
				m_handlerMoveTab.sendEmptyMessage(3);
				Intent intentApprovalTabAct = new Intent(MainTabAct.this, ApprovalTabAct.class);
				startActivity(intentApprovalTabAct);
			} else if(bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISMOVETAB)){
				m_handlerMoveTab.sendEmptyMessage(1);
			}
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM)) {
				// mTabHost.setCurrentTab(1);
				m_handlerMoveTab.sendEmptyMessage(1);
				int nUserNo = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO);
				Intent intentChatRoom = new Intent(MainTabAct.this, ChatRoomAct.class);
				if(nUserNo == 1){
					nUserNo = App.m_MyUserInfo.m_nUserNo;
				}
				intentChatRoom.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intentChatRoom.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOM_USERNO, nUserNo);
				startActivity(intentChatRoom);
			} else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP)) {
				m_handlerMoveTab.sendEmptyMessage(1);

				String strRoomId = bundle.getString(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID);
				Intent intentChatRoomGroup = new Intent(MainTabAct.this, ChatRoomGroupAct.class);
				intentChatRoomGroup.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intentChatRoomGroup.putExtra(IntentKeyString.INTENT_KEY_MAINTAB_ISPUSH_CHATROOMGROUP_ID, strRoomId);
				intentChatRoomGroup.putExtra(IntentKeyString.INTENT_KEY_CHATROOMGROUP_FROM_PUSH, true);
				startActivity(intentChatRoomGroup);
			}  else if(bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSINVITE)){
				m_handlerMoveTab.sendEmptyMessage(0);
			}
			else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSBOARD, false)) {
				// mTabHost.setCurrentTab(3);
//				m_handlerMoveTab.sendEmptyMessage(2);
//				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
//				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
//				
//				Intent intentSNSBoard = new Intent(MainTabAct.this, SNSGroupDetailAct.class);
//				intentSNSBoard.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nSNSGroupId);
//				intentSNSBoard.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, "");
//				startActivity(intentSNSBoard);
				
				Message message = new Message();
				
				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
				
				Bundle bundleSNS = new Bundle();
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nSNSGroupId);
				bundleSNS.putString(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, "");
				message.what = 0;
				message.setData(bundle);
				m_handlerMoveTab.sendMessage(message);
				
			} else if (bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, false)) {
				// mTabHost.setCurrentTab(3);
//				m_handlerMoveTab.sendEmptyMessage(2);
//				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
//				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
//				int nSNSReplyId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID);
//				
//				Intent intentSNSReply = new Intent(this, SNSBoardDetailAct.class);
//				intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPID, nSNSGroupId);
//				intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPNAME, "");
//				intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, nSNSBoardId);
//				intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, true);
//				startActivity(intentSNSReply);
				
				Message message = new Message();
				
				int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
				int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
				int nSNSReplyId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID);
				
				Bundle bundleSNS = new Bundle();
				bundleSNS.putBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, true);
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nSNSGroupId);
				bundleSNS.putString(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, "");
				bundleSNS.putInt(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, nSNSBoardId);
				bundleSNS.putBoolean(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, true);
				message.what = 0;
				message.setData(bundle);
				m_handlerMoveTab.sendMessage(message);
			}
		}
		if(App.m_isOtherApp){
			App.m_isOtherApp = false;
			m_handlerMoveTab.sendEmptyMessage(2);
		}
		super.onNewIntent(intent);
	}

	@Override
	protected void onXMPPServiceConnected() {
		// TODO Auto-generated method stub
		super.onXMPPServiceConnected();

		mService.addNotifyListner(m_XmppNotifyListener);
		if(m_nPassOwner != 0 && m_strRoomID != null){
			mService.passOwner(m_nPassOwner, m_strRoomID);
			m_nPassOwner = 0;
			m_strRoomID = null;
		}
	}

	@Override
	protected void onXMPPServiceDisConnected() {
		// TODO Auto-generated method stub
		super.onXMPPServiceDisConnected();
		mService.removeNotifyListener();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		CommonLog.e(this, "Remove Listener");
		if (mService != null)
			mService.removeNotifyListener();
	}

	// public void setNotify() {
	// runOnUiThread(new Runnable() {
	// @Override
	// public void run() {
	// int nNoReadCount = 0;
	// ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(MainTabAct.this);
	// for (ChattingRoomInfoData roomData : arrRoomData) {
	// ChattingDBManager chattingDBManager = new ChattingDBManager(MainTabAct.this);
	// chattingDBManager.openReadable(roomData.m_strRoomId);
	// nNoReadCount += chattingDBManager.getNoReadMessageCount();
	// chattingDBManager.close();
	// }
	// if (nNoReadCount != 0) {
	// m_tvChatListTabCount.setVisibility(View.VISIBLE);
	// m_tvChatListTabCount.setText("" + nNoReadCount);
	// } else {
	// m_tvChatListTabCount.setVisibility(View.GONE);
	// }
	// }
	// });
	// m_NotifyListener.onNotify();
	// }

	public void setNotifyListener(OnNotifyChatListListener a_Listener) {
		m_NotifyChatListListener = a_Listener;
	}
	
	public void setNotifySNSPushListener(OnNotifySNSPushListener a_Listener)
	{
		m_notifySNSPushListenter = a_Listener;
	}

	public OnNotifyListener m_XmppNotifyListener = new OnNotifyListener() {
		@Override
		public void onNotify(String strRoomID, String strPacketID, boolean isSystemMessage) {
			// TODO Auto-generated method stub

			
			//삭제일때 표시는?
			if(!isSystemMessage){
				if(!strPacketID.split("_")[1].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))){
					m_nBadgeCount += 1;
				}
				runOnUiThread(new Runnable() {
					public void run() {
						if (m_nBadgeCount > 0) {
							m_tvChatListTabCount.setVisibility(View.VISIBLE);
							if (m_nBadgeCount > 999)
								m_tvChatListTabCount.setText("999+");
							else
								m_tvChatListTabCount.setText("" + m_nBadgeCount);
						} else {
							m_tvChatListTabCount.setVisibility(View.GONE);
						}
					}
				});
			}
			else 
			{
				setChatListNoReadCountBadge(m_strLastChatRoomId);	
			}
//			insertDbTask task = new insertDbTask();
//			task.execute();
			if(m_NotifyChatListListener != null)
				m_NotifyChatListListener.onNotify(strRoomID, strPacketID);
		}

		@Override
		public void onExitRoom(String strRoomID) {
			// TODO Auto-generated method stub
			mService.exitRoom(strRoomID);

		}

		@Override
		public void onDeleteRoom(String strRoomID) {
			// TODO Auto-generated method stub
//			RoomDBManager.deleteRoom(MainTabAct.this, strRoomID);
//			ChattingDBManager chattingDBMng = new ChattingDBManager(MainTabAct.this);
//			chattingDBMng.openWritable(strRoomID);
//			chattingDBMng.deleteChattingMessage();
//			chattingDBMng.deleteChattingUser();
//			chattingDBMng.close();
			PushController.cancelNotification(MainTabAct.this, strRoomID);
			// ChattingDBManager.deleteChattingMessage(ChatRoomGroupAct.this, m_strThisRoomId);
			// ChattingDBManager.deleteChattingUser(ChatRoomGroupAct.this, m_strThisRoomId);
			// finish();
			if(m_NotifyChatListListener != null) {
				m_NotifyChatListListener.onNotify(strRoomID, null);
			}
		}

		@Override
		public void onErrorPopup(String strRoomID, final String strErrorText) {
			// TODO Auto-generated method stub
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					m_Popup = new CommonPopup(MainTabAct.this, MainTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), strErrorText);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			});

		}

		@Override
		public void onResumeScreen() {
			// TODO Auto-generated method stub
			runOnUiThread(new Runnable() {
				public void run() {
					
				
			int nNewFellowCount = 0;
			setChatListNoReadCountBadge(m_strLastChatRoomId);
			if (App.m_EntryData != null) {
				String nYesterdayTime = Utils.getPrevHourTime();
				if (App.m_arrFellowListData != null) {
					for (FellowListData data : App.m_arrFellowListData) {
//					CommonLog.e("", "addtime : " + data.m_strFellowAddTime);
//					CommonLog.e("", "hidetime : " + nYesterdayTime);
						if (data.m_strFellowAddTime != null && !data.m_strFellowAddTime.equals("")) {
							if (Long.parseLong(data.m_strFellowAddTime) > Long.parseLong(nYesterdayTime)) {
								nNewFellowCount++;
							}
						}
					}
				}
			}
			/*if (nNewFellowCount != 0) {
				m_tvFellowListTabCount.setVisibility(View.VISIBLE);
				m_tvFellowListTabCount.setText("" + nNewFellowCount);
			} else {
				m_tvFellowListTabCount.setVisibility(View.GONE);
			}*/
			CommonLog.e("MainTabAct", "MainTabAct : resume");

			setAppRovalBadgeUi();
			
				if(m_NotifyChatListListener != null) {
					if(m_nCurrentTabType == TAB_BTN_CHATLIST) {
						m_NotifyChatListListener.onResumeScreen();
					}
				}
				}
			});
		}

		@Override
		public void onOtherLogin() {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					m_Popup = new CommonPopup(MainTabAct.this, MainTabAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			});
		}


		@Override
		public void onBindService() {
			doBindXmppSerivce();
		}

		@Override
		public void onReadNotify(String strRoomID, ArrayList<String> arrPacketID) {
			// TODO Auto-generated method stub
			m_nBadgeCount = m_nBadgeCount - arrPacketID.size();
			
			runOnUiThread(new Runnable() {
				public void run() {
					if (m_nBadgeCount > 0) {
						m_tvChatListTabCount.setVisibility(View.VISIBLE);
						if (m_nBadgeCount > 999)
							m_tvChatListTabCount.setText("999+");
						else
							m_tvChatListTabCount.setText("" + m_nBadgeCount);
					} else {
						m_tvChatListTabCount.setVisibility(View.GONE);
					}
				}
			});
			if(m_NotifyChatListListener != null)
				m_NotifyChatListListener.onReadNotify(strRoomID, arrPacketID);
		}

		@Override
		public void onTitleChanged() {

			if(m_NotifyChatListListener != null) {
				m_NotifyChatListListener.onResumeScreen();
			}
		}

		@Override
		public void onChannelNotify(final int nChannelNo, int nThreadNo, final int nCommentNo) {

			runOnUiThread(new Runnable() {
				@Override
				public void run() {

					SharedPref pref = SharedPref.getInstance(MainTabAct.this);
					int nCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT);
					setChannelListNoReadCountBadge(nCount + 1);

					if (m_DrawerLayout != null && m_DrawerLayout.isDrawerOpen(Gravity.LEFT)) {
						int nChannelCount = 0;
						if (m_arrBadgetCount.get(nChannelNo) != null) {
							nChannelCount = m_arrBadgetCount.get(nChannelNo);
						}
						m_arrBadgetCount.put(nChannelNo, nChannelCount + 1);
						m_ChannelListAdapter.notifyDataSetChanged();
					}

					if(nChannelNo == m_nChannelNo && nCommentNo == 0)
						m_ChannelInfoListener.setNewMessage();
				}
			});

		}

		@Override
		public void onChannelInviteNotify(final int nChannelNo) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {

					SharedPref pref = SharedPref.getInstance(MainTabAct.this);
					int nCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT);
					setChannelListNoReadCountBadge(nCount + 1);

					if (m_DrawerLayout != null && m_DrawerLayout.isDrawerOpen(Gravity.LEFT)) {
						getSNSGroupList();
					}

				}
			});
		}
	};

	public interface OnNotifyListener {
		
		public void onNotify(String strRoomID, String strPacketID, boolean isSystemMessage);
		
		public void onReadNotify(String strRoomID, ArrayList<String> arrPacketID);

		public void onExitRoom(String strRoomID);

		public void onDeleteRoom(String strRoomID);

		public void onErrorPopup(String strRoomID, String strErrorText);
		
		public void onResumeScreen();

		public void onOtherLogin();

		public void onBindService();

		public void onTitleChanged();

		public void onChannelNotify(int nChannelNo, int nThreadNo, int nCommentNo);

		public void onChannelInviteNotify(int nChannelNo);
	}
	
	public interface OnNotifyChatListListener {
		
		public void onNotify(String strRoomID, String strPacketID);
		
		public void onReadNotify(String strRoomID, ArrayList<String> arrPacketID);
		
		public void onResumeScreen();
	}
	
	public interface OnNotifySNSPushListener {
		public void onNotify();
	}

//	private class insertDbTask extends AsyncTask<String, Void, Integer> {
//
//		@Override
//		protected Integer doInBackground(String... params) {
//			// TODO Auto-generated method stub
//			int nNoReadCount = 0;
//			ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(MainTabAct.this);
//			ChattingDBManager chattingDBManager = new ChattingDBManager(MainTabAct.this);
//			for (ChattingRoomInfoData roomData : arrRoomData) {
//				boolean isLoof = true;
//				
//				while(isLoof)
//				{
//					try
//					{
//						chattingDBManager.openReadable(roomData.m_strRoomId);
//						isLoof = false;
//					}
//					catch(SQLException e)
//					{
//						e.printStackTrace();
//					}
//				}
//				nNoReadCount += chattingDBManager.getNoReadMessageCount();
//				chattingDBManager.close();
//			}
//			
//			return nNoReadCount;
//		}
//
//		@Override
//		protected void onPostExecute(Integer result) {
//			// TODO Auto-generated method stub
//			super.onPostExecute(result);
//			final int nNoReadCountFinal = result;
//			runOnUiThread(new Runnable() {
//				@Override
//				public void run() {
//					if (nNoReadCountFinal > 0) {
//						m_tvChatListTabCount.setVisibility(View.VISIBLE);
//						if (nNoReadCountFinal > 999)
//							m_tvChatListTabCount.setText("999+");
//						else
//							m_tvChatListTabCount.setText("" + nNoReadCountFinal);
//					} else {
//						m_tvChatListTabCount.setVisibility(View.GONE);
//					}
//				}
//			});
//		}
//
//	}

	public void setTitle(String a_strTitle) {
		TextView tvTitle = (TextView) findViewById(R.id.tv_tabact_main_title);
		tvTitle.setText(a_strTitle);
	}


	private void setAppRovalBadgeUi() {
		SharedPref pref = SharedPref.getInstance(this);
		if (pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, 0) > 0) {
			m_tvSettingTabCount.setVisibility(View.VISIBLE);
			m_tvSettingTabCount.setText("" + pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, 0));
		} else {
			m_tvSettingTabCount.setVisibility(View.GONE);
		}
	}

	public class TabManager implements TabHost.OnTabChangeListener {
		private final FragmentActivity mActivity;
		private final TabHost mTabHost;
		private final int mContainerId;
		private final HashMap<String, TabInfo> mTabs = new HashMap<String, TabInfo>();
		TabInfo mLastTab;

		final class TabInfo {
			private final String tag;
			private final Class<?> clss;
			private final Bundle args;
			private Fragment fragment;

			TabInfo(String _tag, Class<?> _class, Bundle _args) {
				tag = _tag;
				clss = _class;
				args = _args;
			}
		}

		class DummyTabFactory implements TabHost.TabContentFactory {
			private final Context mContext;

			public DummyTabFactory(Context context) {
				mContext = context;
			}

			@Override
			public View createTabContent(String tag) {
				View v = new View(mContext);
				v.setMinimumWidth(0);
				v.setMinimumHeight(0);
				return v;
			}
		}

		public TabManager(FragmentActivity activity, TabHost tabHost, int containerId) {
			mActivity = activity;
			mTabHost = tabHost;
			mContainerId = containerId;
			mTabHost.setOnTabChangedListener(this);
		}

		public void addTab(TabHost.TabSpec tabSpec, Class<?> clss, Bundle args) {
			tabSpec.setContent(new DummyTabFactory(mActivity));
			String tag = tabSpec.getTag();

			TabInfo info = new TabInfo(tag, clss, args);

			// Check to see if we already have a fragment for this tab, probably
			// from a previously saved state. If so, deactivate it, because our
			// initial state is that a tab isn't shown.
			info.fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
			if (info.fragment != null && !info.fragment.isDetached()) {
				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				ft.detach(info.fragment);
				ft.commitAllowingStateLoss();
			}

			mTabs.put(tag, info);
			mTabHost.addTab(tabSpec);
		}

		@Override
		public void onTabChanged(String tabId) {
			TabInfo newTab = mTabs.get(tabId);
			App.m_isProfileImageView = false;
			if(!tabId.equals("ChatList")){
				getRoomSync();
				if(m_OnKeyBackPressedListener != null){
					m_OnKeyBackPressedListener.onBack();
				}
			}
			if(tabId.equals(TAB_SNSLIST)){
				App.m_isInChannelList = true;
				m_DrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
			} else {
				App.m_isInChannelList = false;
				m_DrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
			}
			if(tabId.equals(TAB_ORGANCHART)){
				App.m_isTouchSearchTab = true;
			} else {
				App.m_isTouchSearchTab = false;
			}
			if (mLastTab != newTab) {
				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				if (mLastTab != null) {
					if (mLastTab.fragment != null) {
						ft.detach(mLastTab.fragment);
					}
				}
				if (newTab != null) {
					if (newTab.fragment == null) {
						newTab.fragment = Fragment.instantiate(mActivity, newTab.clss.getName(), newTab.args);
						ft.add(mContainerId, newTab.fragment, newTab.tag);
					} else {
						ft.attach(newTab.fragment);
					}
				}

				mLastTab = newTab;
				ft.commitAllowingStateLoss();
				mActivity.getSupportFragmentManager().executePendingTransactions();
			}
		}
	}

	public void exitRoom(final String strRoomID) {
		mService.exitRoom(strRoomID);

	}

	// 방장 위임
	public void passOwner(final int nUserID, final String strRoomID) {

		m_nPassOwner = nUserID;
		m_strRoomID = strRoomID;
		//mService.passOwner(m_nPassOwner, m_strRoomID);
		// exitRoom(strRoomID);
	}

	public void onResumeChatList() {
		this.getSupportFragmentManager().findFragmentByTag(TAB_CHATLIST).onResume();
	}
	
	private void startSNSCreateGroupAct()
	{
		//((MainSNSListFrag)this.getSupportFragmentManager().findFragmentByTag(TAB_SNSLIST)).startSNSCreateGroupAct();
	}

	public class myTimer extends CountDownTimer {

		public myTimer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
			// TODO Auto-generated constructor stub
			isTwo = true;
		}

		@Override
		public void onFinish() {
			isTwo = false;
		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub

		}
	}
	
	public int getChatListNoReadCountBadge()
	{
		return m_nBadgeCount;
	}

	public void setChannelListNoReadCountBadge(int nBadgeCount){

		int nChannelBadgeCount = 0;
		if(m_tvSNSListTabCount != null) {
			if (nBadgeCount > 0) {
				m_tvSNSListTabCount.setVisibility(View.VISIBLE);
				if (nBadgeCount > 999)
					m_tvSNSListTabCount.setText("999+");
				else
					m_tvSNSListTabCount.setText("" + nBadgeCount);
				nChannelBadgeCount = nBadgeCount;
			} else {
				m_tvSNSListTabCount.setVisibility(View.GONE);
				nChannelBadgeCount = 0;
			}
		} else {
			nChannelBadgeCount = nBadgeCount;
		}
		SharedPref pref = SharedPref.getInstance(MainTabAct.this);
		int nUpdateBadgeCount = nChannelBadgeCount;
		if(nUpdateBadgeCount < 0){
			nUpdateBadgeCount = 0;
		}
		pref.setIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, nUpdateBadgeCount);
		IconBadge.updateIconBadge(MainTabAct.this);

	}
	public void setChatListNoReadCountBadge(int a_nBadgeCount)
	{
		if (a_nBadgeCount > 0) {
			m_tvChatListTabCount.setVisibility(View.VISIBLE);
			if (a_nBadgeCount > 999)
				m_tvChatListTabCount.setText("999+");
			else
				m_tvChatListTabCount.setText("" + a_nBadgeCount);
			m_nBadgeCount = a_nBadgeCount;
		} else {
			m_tvChatListTabCount.setVisibility(View.GONE);
			m_nBadgeCount = 0;
		}
		SharedPref pref = SharedPref.getInstance(MainTabAct.this);
		int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
		int nUpdateBadgeCount = m_nBadgeCount;
		if(nUpdateBadgeCount < 0){
			nUpdateBadgeCount = 0;
		}
		pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
		IconBadge.updateIconBadge(MainTabAct.this);
	}

	public void setChatListNoReadCountBadge(final String strEnteredRoomID) {
		AsyncTask<Void, Void, Integer> task = new AsyncTask<Void, Void, Integer>() {

			@Override
			protected Integer doInBackground(Void... params) {
				// TODO Auto-generated method stub
				int nNoReadCount = 0;
				ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(MainTabAct.this);
				ChattingDBManager chattingDBManager = new ChattingDBManager(MainTabAct.this);
				
				for (ChattingRoomInfoData roomData : arrRoomData) {
					if(!roomData.m_strRoomId.equals(strEnteredRoomID) || m_nLastChatRoomBadge == -1){
						chattingDBManager.openReadable(roomData.m_strRoomId);
						nNoReadCount += chattingDBManager.getNoReadMessageCount();	
						chattingDBManager.close();
					} else {
						nNoReadCount += m_nLastChatRoomBadge;
					}
				}
				
				
				return nNoReadCount;
			}

			@Override
			protected void onPostExecute(Integer result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
				
				if(m_tvChatListTabCount != null) {
				if (result > 0) {
					m_tvChatListTabCount.setVisibility(View.VISIBLE);
					if (result > 999)
						m_tvChatListTabCount.setText("999+");
					else
						m_tvChatListTabCount.setText("" + result);
					m_nBadgeCount = result;
				} else {
					m_tvChatListTabCount.setVisibility(View.GONE);
					m_nBadgeCount = 0;
				}
				} else {
					m_nBadgeCount = result;
				}
				SharedPref pref = SharedPref.getInstance(MainTabAct.this);
				int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
				int nUpdateBadgeCount = m_nBadgeCount;
				if(nUpdateBadgeCount < 0){
					nUpdateBadgeCount = 0;
				}
				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
				IconBadge.updateIconBadge(MainTabAct.this);
				
			}
		};
		task.execute();
		
		
	}

	public class ApprovalRequestBadgeBroadcastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			setAppRovalBadgeUi();
		}
	}
	
	public class SNSPushBadgeBroadcastReceiver extends BroadcastReceiver {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			notifySNSListFragment();
		}
	}
	
	public class FinishChatRoomBroadcastReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			m_strLastChatRoomId = intent.getStringExtra(IntentKeyString.INTENT_KEY_FINISHCHATROOMBROADCAST_ROOMID);
			m_nLastChatRoomBadge = 0;
			m_hInitLastChatRoomInfo.removeMessages(0);
			m_hInitLastChatRoomInfo.sendEmptyMessageDelayed(0, HANDLER_INITLASTCHATROOMINFO_DELAYTIME);
		}
		
	}

	public class ChatRoomReadBroadcastReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if(m_NotifyChatListListener != null)
				m_NotifyChatListListener.onResumeScreen();
		}
		
	}
	
	public boolean isChatRoomReadReceiver(){
		
		if(m_recvRead != null){
			return true;
		} else {
			return false;
		}
	}
	
	public void setChatRoomReadReceiver(){
		if(m_recvRead == null){
			CommonLog.e(getClass().getSimpleName(), "Set ChatRoomReadReceiver!!!");
			m_recvRead = new ChatRoomReadBroadcastReceiver();
			IntentFilter intentFilter = new IntentFilter();
			intentFilter.addAction(StaticString.BROADCAST_CHATREAD_RECEIVER);
			registerReceiver(m_recvRead, intentFilter, StaticString.BROADCAST_PERMISSION_CHATROOMREAD, null);
		}
	}
	
	public void removeChatRoomReadReceiver(){
		if(m_recvRead != null){
			CommonLog.e(getClass().getSimpleName(), "Remove ChatRoomReadReceiver!!!");
			unregisterReceiver(m_recvRead);
			m_recvRead = null;
		}
	}
	
	private void setSNSPushBadgeReceiver()
	{
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(StaticString.BROADCAST_SNSPUSH_RECEIVER);
		
		if (m_recvSNSPushBadge == null)
			m_recvSNSPushBadge = new SNSPushBadgeBroadcastReceiver();


		registerReceiver(m_recvSNSPushBadge, intentFilter, StaticString.BROADCAST_PERMISSION_SNSPUSH, null);
	}
	
	private void removeSNSPushBadgeReceiver(){
		if(m_recvSNSPushBadge != null){
			unregisterReceiver(m_recvSNSPushBadge);
			m_recvSNSPushBadge = null;
		}
	}
	
	private void setFinishChatRoomReceiver()
	{
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(StaticString.BROADCAST_FINISHCHATROOM_RECEIVER);
		
		if (m_recvFinishChatRoom == null)
			m_recvFinishChatRoom = new FinishChatRoomBroadcastReceiver();


		registerReceiver(m_recvFinishChatRoom, intentFilter, StaticString.BROADCAST_PERMISSION_FINISHCHATROOM, null);
	}
	
	private void removeFinishChatRoomReceiver(){
		if(m_recvFinishChatRoom != null){
			unregisterReceiver(m_recvFinishChatRoom);
			m_recvFinishChatRoom = null;
		}
	}
	
	private void notifySNSListFragment()
	{
		if(mTabHost.getCurrentTab() == TAB_INDEX_SNSLIST)
		{
			if(m_notifySNSPushListenter != null)
				m_notifySNSPushListenter.onNotify();
		}
	}

	private Handler m_handlerMoveTab = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			int nBeforeIndex = mTabHost.getCurrentTab();
			int nTabIndex = msg.what;
			if(mTabHost != null)
			mTabHost.setCurrentTab(nTabIndex);
			if(nTabIndex == 0)
			{
				Bundle bundle = msg.getData();
				if(bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSBOARD, false))
				{
					int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
					int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);

					//일반적인 상황에서는 MainChannelFlag에서 푸시 받은 게시글로 진입 시켜 준다.(onCreatView에서 처리)
					//현재 위치하고 있는 곳이 MainChannelFlag라면 새로 화면을 그려주지 못하므로, 강제로 이동 시켜 준다.
					//앱을 완전히 처음 실행 한 경우는 이미 MainChannelFlag에서 그려 주면서 nPushBoardNo 이 -1로 변화되므로 실행되지 않는다.
					if(nBeforeIndex == nTabIndex){
						SharedPref pref = SharedPref.getInstance(MainTabAct.this);
						int nPushBoardNo = pref.getIntegerPref(SharedPref.PREF_CHANNEL_PUSH_BOARD, -1);
						if(nPushBoardNo != -1){
							m_ChannelInfoListener.setRefresh(nSNSGroupId);
						}

					}
					/*Intent intentSNSBoard = new Intent(MainTabAct.this, SNSGroupDetailAct.class);
					intentSNSBoard.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GOBOARDDETAIL, true);
					intentSNSBoard.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nSNSGroupId);
					intentSNSBoard.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, nSNSBoardId);
					intentSNSBoard.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, "");
					mTabManager.mTabs.get(TAB_SNSLIST).fragment.startActivityForResult(intentSNSBoard, MainSNSListFrag.REQUESTCODE_SNSGROUPDETAIL);*/
				}
				else if(bundle.getBoolean(IntentKeyString.INTENT_KEY_MAINTAB_ISSNSREPLY, false)){
					int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
					int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
					int nSNSReplyId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID);

					//일반적인 상황에서는 MainChannelFlag에서 푸시 받은 게시글로 진입 시켜 준다.(onCreatView에서 처리)
					//현재 위치하고 있는 곳이 MainChannelFlag라면 새로 화면을 그려주지 못하므로, 강제로 이동 시켜 준다.
					//앱을 완전히 처음 실행 한 경우는 이미 MainChannelFlag에서 그려 주면서 nPushBoardNo 이 -1로 변화되므로 실행되지 않는다.
					if(nBeforeIndex == nTabIndex){
						SharedPref pref = SharedPref.getInstance(MainTabAct.this);
						int nPushBoardNo = pref.getIntegerPref(SharedPref.PREF_CHANNEL_PUSH_BOARD, -1);
						if(nPushBoardNo != -1){
							m_ChannelInfoListener.setRefresh(nSNSGroupId);
						}

					}
				}
				else
				{
					/*int nSNSGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_GROUPID);
					int nSNSBoardId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_BOARDID);
					int nSNSReplyId = bundle.getInt(IntentKeyString.INTENT_KEY_MAINTAB_ISSNS_REPLYID);
					
					Intent intentSNSReply = new Intent(MainTabAct.this, SNSGroupDetailAct.class);
					intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GOBOARDDETAIL, true);
					intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nSNSGroupId);
					intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, "");
					intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, nSNSBoardId);
					intentSNSReply.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, true);
					mTabManager.mTabs.get(TAB_SNSLIST).fragment.startActivityForResult(intentSNSReply, MainSNSListFrag.REQUESTCODE_SNSGROUPDETAIL);*/
				}
			}
			super.handleMessage(msg);
		}
	};

	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE) {
				popup_ok_long.cancel();
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			}
		}
		super.onClick(v);
	}
	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
	
	public String getLastChatRoomId()
	{
		return m_strLastChatRoomId;
	}
	
	public void setLastChatRoomId(String a_strLastRoomId)
	{
		m_strLastChatRoomId = a_strLastRoomId;
	}
	
	public int getLastChatRoomBadge()
	{
		return m_nLastChatRoomBadge;
	}
	
	public void setLastChatRoomBadge(int a_nBadge)
	{
		m_nLastChatRoomBadge = a_nBadge;
	}
	
	private final int HANDLER_INITLASTCHATROOMINFO_DELAYTIME = 10000;
	private Handler m_hInitLastChatRoomInfo = new Handler()
	{
		@Override
		public void handleMessage(Message msg) {
			CommonLog.e(MainTabAct.class.getSimpleName(), "initLastChatRoomInfo Handler");
			m_strLastChatRoomId = "";
			m_nLastChatRoomBadge = -1;
			super.handleMessage(msg);
		}
	};
	
	/**
	 * 공지 사항
	 */
	private void requestGetAdminNotice() {
		showProgress();
		SharedPref pref = SharedPref.getInstance(this);
		GetAdminNoticeReq req = new GetAdminNoticeReq(pref.getIntegerPref(SharedPref.PREF_ADMIN_NOTICENO));
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();

				GetAdminNoticeRes res = new GetAdminNoticeRes(a_strData);

				Intent intent;
				intent = new Intent(MainTabAct.this, SysNoticePopupAct.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_TITLE, getString(R.string.pop_sysnotice_title).toString());
				intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BODY, res.getContent());
				intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_SYSNOTICEID, res.getNoticeNo());
				startActivity(intent);

			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
			}
		});
	}
	
	// 개인방 동기화
	public void getRoomSync(){
		if(App.m_MyUserInfo == null){
			CommonLog.e("MainTabAct", "MaintTabAct : App.m_myUserInfo is null");
		} 
		else {
		GetOneRoomSyncReq req = new GetOneRoomSyncReq();
		
		WebAPI webApi = new WebAPI(MainTabAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				
				GetOneRoomSyncRes res = new GetOneRoomSyncRes(a_strData);
				
				HashMap<String, Long> map = res.getIdAndTimeStamp();
				if(!map.isEmpty()){
					for( String key : map.keySet() ){
//					CommonLog.e("aaa", "테스트 ID : " + key);
//					CommonLog.e("aaa", "테스트 Time : " + map.get(key));
						long lnTimeStamp = map.get(key);
						ChattingDBManager chattingDBMng = new ChattingDBManager(MainTabAct.this);
						chattingDBMng.openWritable(key);
						ChattingMessageData lastMessage = chattingDBMng.getCurrentMessage();
						if(lastMessage != null && lastMessage.m_lnMsgSendTime > lnTimeStamp){
							chattingDBMng.deleteChattingMessageTimeAfter(lnTimeStamp);
							chattingDBMng.close();
						} else {
							chattingDBMng.deleteChattingMessage();
							chattingDBMng.close();
							RoomDBManager.deleteRoom(MainTabAct.this, key);
						}
					
					}
					deleteRoomSync(res.getMessageIds());
				}
				else {
				}
//				CommonLog.e("aaa", "테스트 IDs : " + res.getMessageIds());
//				CommonLog.e("aaa", "테스트 Map : " + res.getIdAndTimeStamp());
			}
			
		});
		}
	}
	
	public void deleteRoomSync(ArrayList<String> arrList){
		DeleteOneRoomSyncReq req = new DeleteOneRoomSyncReq(arrList);

		WebAPI webApi = new WebAPI(MainTabAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
			}
			
		});
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode,event);
	}
    /*//채팅리스트에서 홈버튼 등으로 나갔는지 판단하기 위해 추가
    private boolean m_isUserLeave = false;

    public boolean getIsUSerLeave(){
        return m_isUserLeave;
    }
    public void setIsUserLeave(boolean a_isUserLeave){
        m_isUserLeave = a_isUserLeave;
    }
    @Override
    protected void onUserLeaveHint() {

        m_isUserLeave = true;
        super.onUserLeaveHint();
    }*/

	public int getCurrentTab(){
		return m_nCurrentTabType;
	}

	public void getSNSBadgeCount(){
		GetGroupUnreadsReq req = new GetGroupUnreadsReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {

			}

			@Override
			public void onPostRequest(String a_strData) {
				GetGroupUnreadsRes res = new GetGroupUnreadsRes((a_strData));
				int nBadgeCount = 0;
				ArrayList<ChannelUnreadsData> unreadData = res.getChannelUnreadsData();
				for(int i = 0; i < unreadData.size(); i++){
					nBadgeCount = nBadgeCount + unreadData.get(i).m_arrThreadAndCommentNo.size();
				}
				nBadgeCount = nBadgeCount + res.m_nInvitedChannelCount;
				setChannelListNoReadCountBadge(nBadgeCount);
			}
		});
	}
	public void getSNSGroupList()
	{
		if(App.m_EntryData != null)
		{
			GetGroupListReq req = new GetGroupListReq();
			WebAPI webApi = new WebAPI(this);
			webApi.request(req, m_WebGetGroupListListener);
		}
	}

	private void setChannelMenuUI()
	{
		//StartActivity 가 너무 산발되어 onclick을 모두 이안에서 처리
		if(m_nChannelNo != -1){
			TextView tvChannelName = (TextView)findViewById(R.id.tv_draw_channel_name);
			tvChannelName.setText(m_strChannelName);

			final int nChannelNo = m_nChannelNo;
			final String strChannelName = m_strChannelName;

			LinearLayout layoutOwnerLayout = (LinearLayout)findViewById(R.id.layout_draw_channel_owner);

			LinearLayout layoutChannelAlarm = (LinearLayout)findViewById(R.id.layout_draw_channel_alarm);
			layoutChannelAlarm.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, SNSAlarmSetAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nChannelNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_USERIDS, App.m_MyUserInfo.m_nUserNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISTHREAD_ALARMON,m_isChannelThreadAlarmOn);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_ISCOMMENT_ALARMON,m_isChannelCommentAlarmOn);
					startActivityForResult(intent,MainChannelFlag.REQUEST_CODE_ALARMSET);
				}
			});

			LinearLayout layoutChannelMemeber = (LinearLayout)findViewById(R.id.layout_draw_channel_member);
			layoutChannelMemeber.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, SNSGroupMemberListAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID, nChannelNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_ISOWNER, m_isChannelOwner);
					startActivity(intent);
				}
			});
			LinearLayout layoutChannelInvite = (LinearLayout)findViewById(R.id.layout_draw_channel_invite);
			layoutChannelInvite.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

					GetGroupUserReq req = new GetGroupUserReq(nChannelNo);
					WebAPI api = new WebAPI(MainTabAct.this);
					api.request(req, new WebListener() {
						ArrayList<Integer> arrUserNumbers = new ArrayList<Integer>();
						@Override
						public void onPreRequest() {
							// TODO Auto-generated method stub
							showProgress();
						}

						@Override
						public void onPostRequest(String a_strData) {
							// TODO Auto-generated method stub
							closeProgress();
							GetGroupUserRes res = new GetGroupUserRes(a_strData);
							ArrayList<SNSGroupMemberData> arrUserData = res.getGroupMemberList();
							ArrayList<Integer> arrInvitingUserData = res.getGroupInvitedMemberList();
							for(int i = 0; i < arrUserData.size(); i++){
								arrUserNumbers.add(arrUserData.get(i).m_nUserNo);
							}
							for(int j = 0; j < arrInvitingUserData.size(); j++){
								arrUserNumbers.add(arrInvitingUserData.get(j));
							}
							if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
								m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
							}
							Intent intent = new Intent(MainTabAct.this, SNSGroupMemeberInviteAct.class);
							intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, nChannelNo);
							intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME,strChannelName);
							intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_USERIDS, arrUserNumbers);
							startActivity(intent);
						}

						@Override
						public void onNetworkError(int nErrorCode, String strMessage) {
							// TODO Auto-generated method stub
							closeProgress();
							if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
								m_Popup = new CommonPopup(MainTabAct.this, new View.OnClickListener() {

									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
										CommonPopup popup = (CommonPopup)v.getTag();
										popup.cancel();
										popup.dismiss();

									}
								}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
								m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
								m_Popup.setCancelable(false);
								isCheckShowPopup();
							}
							else
								showErrorPopup(nErrorCode, strMessage);
						}
					});
				}
			});
			LinearLayout layoutChannelOut = (LinearLayout)findViewById(R.id.layout_draw_channel_out);
			layoutChannelOut.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, SNSExitOtherAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID, nChannelNo);
					startActivityForResult(intent, MainChannelFlag.REQUEST_CODE_EXIT_OTHER);
				}
			});
			LinearLayout layoutChannelName = (LinearLayout)findViewById(R.id.layout_draw_channel_name);
			layoutChannelName.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, SNSCreateGroupAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_ISEDIT, true);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPID, nChannelNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSCREATEGROUP_GROUPNAME, strChannelName);

					startActivityForResult(intent, MainChannelFlag.REQUEST_CODE_GROUPEDIT);
				}
			});
			LinearLayout layoutChannelMandate = (LinearLayout)findViewById(R.id.layout_draw_channel_mandate);
			layoutChannelMandate.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, SNSOwnerAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID, nChannelNo);
					startActivityForResult(intent, MainChannelFlag.REQUEST_CODE_OWNER);

				}
			});
			LinearLayout layoutChannelFilebox = (LinearLayout)findViewById(R.id.layout_draw_channel_filebox);
			layoutChannelFilebox.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, FileBoxAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPFILEBOX_GROUPID, m_nChannelNo);
					startActivity(intent);
				}
			});
			LinearLayout layoutChannelHashtag = (LinearLayout)findViewById(R.id.layout_draw_channel_hashtag);
			layoutChannelHashtag.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
						m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
					}
					Intent intent = new Intent(MainTabAct.this, SNSGroupDetailHashtagAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, m_nChannelNo);
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, m_strChannelName);
					startActivity(intent);
				}
			});
			TextView tvChannelExit = (TextView)findViewById(R.id.tv_draw_channel_exit);
			tvChannelExit.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

					if(m_isChannelOwner && m_nChannelUserCount > 1){
						m_Popup = new CommonPopup(MainTabAct.this, new OnClickListener() {
							@Override
							public void onClick(View v) {
								CommonPopup popup = (CommonPopup)v.getTag();
								if(v.getId() == R.id.ib_pop_ok){
									if(m_DrawerLayout.isDrawerOpen(Gravity.RIGHT)){
										m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
									}
									Intent intent = new Intent(MainTabAct.this, SNSOwnerAct.class);
									intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID, m_nChannelNo);
									startActivityForResult(intent, MainChannelFlag.REQUEST_CODE_OWNER_EXIT);
								}
								popup.cancel();
								popup.dismiss();


							}
						}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.snsgroupexit_owner_popup_title), getString(R.string.snsgroupexit_owner_popup_text));
						m_Popup.setCancelable(false);
						isCheckShowPopup();

					} else {
						if(m_isChannelOwner){
							m_Popup = new CommonPopup(MainTabAct.this, new OnClickListener() {
								@Override
								public void onClick(View v) {
									CommonPopup popup = (CommonPopup) v.getTag();
									if (v.getId() == R.id.ib_pop_ok) {
										PutGroupExitReq req = new PutGroupExitReq(m_nChannelNo, App.m_MyUserInfo.m_nUserNo);
										WebAPI webAPI = new WebAPI(MainTabAct.this);
										webAPI.request(req, new WebListener() {
											@Override
											public void onPreRequest() {
												showProgress();
											}

											@Override
											public void onNetworkError(int nErrorCode, String strMessage) {
												closeProgress();
												showErrorPopup(nErrorCode, strMessage);
											}

											@Override
											public void onPostRequest(String a_strData) {
												closeProgress();

												SharedPref pref = SharedPref.getInstance(MainTabAct.this);
												pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, -1);
												getSNSGroupList();
											}
										});
									}
									m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
									popup.cancel();
									popup.dismiss();
								}
							}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_SNS_EXIT);
							m_Popup.setBodyAndTitleText(getString(R.string.snsgroupexit_user_popup_title), getString(R.string.cork_pop_owner_exit_solo_text));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						} else {
							m_Popup = new CommonPopup(MainTabAct.this, new OnClickListener() {
								@Override
								public void onClick(View v) {
									CommonPopup popup = (CommonPopup) v.getTag();
									if (v.getId() == R.id.ib_pop_ok) {
										PutGroupExitReq req = new PutGroupExitReq(m_nChannelNo, App.m_MyUserInfo.m_nUserNo);
										WebAPI webAPI = new WebAPI(MainTabAct.this);
										webAPI.request(req, new WebListener() {
											@Override
											public void onPreRequest() {
												showProgress();
											}

											@Override
											public void onNetworkError(int nErrorCode, String strMessage) {
												closeProgress();
												showErrorPopup(nErrorCode, strMessage);
											}

											@Override
											public void onPostRequest(String a_strData) {
												closeProgress();

												SharedPref pref = SharedPref.getInstance(MainTabAct.this);
												pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, -1);
												getSNSGroupList();
											}
										});
									}
									m_DrawerLayout.closeDrawer(Gravity.RIGHT, false);
									popup.cancel();
									popup.dismiss();
								}
							}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_SNS_EXIT);
							m_Popup.setBodyAndTitleText(getString(R.string.snsgroupexit_user_popup_title), getString(R.string.snsgroupexit_user_popup_text));
							m_Popup.setCancelable(false);
							isCheckShowPopup();
						}

					}
				}
			});
			if(m_isChannelOwner){
				layoutOwnerLayout.setVisibility(View.VISIBLE);
				if(m_nChannelUserCount == 1){
					TextView tvChannelOut = (TextView) findViewById(R.id.tv_draw_channel_out);
					TextView tvChannelMandate = (TextView) findViewById(R.id.tv_draw_channel_mandate);
					tvChannelOut.setTextColor(Color.parseColor("#d1d1d1"));
					tvChannelMandate.setTextColor(Color.parseColor("#d1d1d1"));
					layoutChannelMandate.setOnClickListener(null);
					layoutChannelOut.setOnClickListener(null);

				} else {
					TextView tvChannelOut = (TextView) findViewById(R.id.tv_draw_channel_out);
					TextView tvChannelMandate = (TextView) findViewById(R.id.tv_draw_channel_mandate);
					tvChannelOut.setTextColor(Color.parseColor("#505050"));
					tvChannelMandate.setTextColor(Color.parseColor("#505050"));
				}
			} else {
				layoutOwnerLayout.setVisibility(View.GONE);
			}
		}
	}
	public WebListener m_WebGetGroupListListener = new WebListener() {

		@Override
		public void onPreRequest() {
			showProgress();
		}

		@Override
		public void onNetworkError(int nErrorCode, String strMessage) {
			closeProgress();
			showErrorPopup(nErrorCode, strMessage);
			setTitle("");
			setTopButton(MainTabAct.TAB_BTN_ERROR_CASE);
		}

		@Override
		public void onPostRequest(String a_strData) {
			GetGroupListRes res = new GetGroupListRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_LIST);
			m_arrNoticeChannel = res.getNoticeChannelListData();
			m_arrInvitingGroup = res.getInvitingChannelListData();
			m_arrMemberGroup = res.getMemberChannelListData();

			if(m_DrawerLayout.isDrawerOpen(Gravity.LEFT)) {
				setChannelUI();
			} else {
				if(m_arrMemberGroup.size() != 0) {
					m_nChannelNo = m_arrMemberGroup.get(0).m_nChannelNo;
					m_strChannelName = m_arrMemberGroup.get(0).m_strName;
					m_ChannelInfoListener.setFirstChannelView(m_arrMemberGroup.get(0).m_nChannelNo, m_arrMemberGroup.get(0).m_strName);
				} else {
					m_ChannelInfoListener.setFirstChannelView(-1, "");
				}
				closeProgress();
			}

		}
	};

	private void setChannelUI(){

		GetGroupUnreadsReq req = new GetGroupUnreadsReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {

			}

			@Override
			public void onPostRequest(String a_strData) {
				GetGroupUnreadsRes res = new GetGroupUnreadsRes((a_strData));
				m_arrBadgetCount = new SparseArray<Integer>();
				ArrayList<ChannelUnreadsData> unreadData = res.getChannelUnreadsData();
				for(int i = 0; i < unreadData.size(); i++){
					m_arrBadgetCount.put(unreadData.get(i).m_nChannelNo, unreadData.get(i).m_arrThreadAndCommentNo.size());
				}
				final ImageView iv_btnAddCh = (ImageView)findViewById(R.id.iv_btn_add_ch);
				if(App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) || (App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && App.m_EntryData.m_MultiTenancy.isPartnerChannelCreationEnabled)){
					iv_btnAddCh.setBackgroundResource(R.drawable.btn_add_ch);
					iv_btnAddCh.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							if(m_DrawerLayout.isDrawerOpen(Gravity.LEFT)){
								m_DrawerLayout.closeDrawer(Gravity.LEFT, false);
							}
							Intent intent = new Intent(MainTabAct.this, SNSCreateGroupAct.class);
							startActivityForResult(intent, MainChannelFlag.REQUEST_CODE_GROUPCREATE);
						}
					});
				} else {
					iv_btnAddCh.setBackgroundResource(R.drawable.btn_add_ch_disabled);
				}

				LinearLayout layoutChannelListNotice = (LinearLayout)findViewById(R.id.layout_channel_list_notice);
				layoutChannelListNotice.removeAllViews();
				LayoutInflater li = getLayoutInflater();
				for(int a = 0; a < m_arrNoticeChannel.size(); a++) {
					View v_channelListNoticeItem = li.inflate(R.layout.layout_channellist_notice, null);
					TextView tv_channelName = (TextView) v_channelListNoticeItem.findViewById(R.id.tv_channellist_notice_name);
					tv_channelName.setText(m_arrNoticeChannel.get(a).m_strNoticeName);
					final int nNoticePosition = a;
					v_channelListNoticeItem.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							m_nChannelNo = m_arrNoticeChannel.get(nNoticePosition).m_nNoticeChannelNo;
							m_strChannelName = m_arrNoticeChannel.get(nNoticePosition).m_strNoticeName;
							m_ChannelInfoListener.setInfo(m_nChannelNo, m_strChannelName, true);
							m_DrawerLayout.closeDrawer(Gravity.LEFT, false);
						}
					});
					layoutChannelListNotice.addView(v_channelListNoticeItem);
				}

				m_arrItem = new ArrayList<>();

				//새로운 초대 텍스트
				int nInvitingTextSize = 0; //"새로운 초대" 라는 타이틀 사이즈
				if(m_arrInvitingGroup != null && m_arrInvitingGroup.size() > 0) {
					ChannelData invitingChannelListText = new ChannelData();
					invitingChannelListText.m_nViewType = 0;
					m_arrItem.add(new Pair<>((long) 0, invitingChannelListText));
					nInvitingTextSize = 1;

					//새로운 초대 리스트
					for (int i = 0; i < m_arrInvitingGroup.size(); i++) {
						m_arrInvitingGroup.get(i).m_nViewType = 1;
						m_arrItem.add(new Pair<>((long) (i + 1), m_arrInvitingGroup.get(i)));
					}
				}

				//채널 목록 텍스트
				if(m_arrMemberGroup != null && m_arrMemberGroup.size() > 0) {
					ChannelData memberChannelListText = new ChannelData();
					memberChannelListText.m_nViewType = 2;
					m_arrItem.add(new Pair<>((long) (m_arrInvitingGroup.size() + nInvitingTextSize), memberChannelListText));
					//채널 목록
					for (int j = 0; j < m_arrMemberGroup.size(); j++) {
						m_arrItem.add(new Pair<>((long) (m_arrInvitingGroup.size() + nInvitingTextSize + 1 + j), m_arrMemberGroup.get(j)));
					}
				}
				m_draglvList.setLayoutManager(new LinearLayoutManager(MainTabAct.this));

				LinearLayout layoutNoList = (LinearLayout) findViewById(R.id.layout_drag_nolist);
				if((m_arrMemberGroup == null || m_arrMemberGroup.size() == 0) && (m_arrInvitingGroup == null || m_arrInvitingGroup.size() == 0)) {
					layoutNoList.setVisibility(View.VISIBLE);
				} else {
					layoutNoList.setVisibility(View.GONE);
				}
				m_ChannelListAdapter = new ChannelListAdapter(m_arrItem, R.layout.layout_channel_list_item, R.id.iv_channel_list_item_move, false);
				m_draglvList.setAdapter(m_ChannelListAdapter, true);
				m_draglvList.setCanDragHorizontally(false);
				m_draglvList.setDragListCallback(new DragListView.DragListCallbackAdapter(){
					@Override
					public boolean canDropItemAtPosition(int dropPosition) {
						boolean isCanDrop = true;
						int nDragPossible = 0;
						if(m_arrInvitingGroup.size() != 0){
							nDragPossible = m_arrInvitingGroup.size() + 1;
						}
						if(dropPosition <= nDragPossible){
							isCanDrop = false;
						} else {
							isCanDrop = true;
						}
						return isCanDrop;
					}
				});
				m_draglvList.setCustomDragItem(new MyDragItem(MainTabAct.this, R.layout.layout_channel_list_item));

				m_draglvList.setDragListListener(new DragListView.DragListListener() {
					@Override
					public void onItemDragStarted(int position) {

					}

					@Override
					public void onItemDragging(int itemPosition, float x, float y) {

					}

					@Override
					public void onItemDragEnded(int fromPosition, int toPosition) {
						if(fromPosition != toPosition) {
							int nMinusDefault = 2;
							if (m_arrInvitingGroup == null || m_arrInvitingGroup.size() == 0) {
								nMinusDefault = 1;
							}
							final int nOriginalPosition = fromPosition - m_arrInvitingGroup.size() - nMinusDefault;
							int nTargetPosition = 0;
							if (fromPosition > toPosition) {
								nTargetPosition = toPosition - m_arrInvitingGroup.size() - nMinusDefault - 1;
							} else if (fromPosition < toPosition) {
								nTargetPosition = toPosition - m_arrInvitingGroup.size() - nMinusDefault;
							}
							int nChannelNo = 0;
							if (nTargetPosition == -1) {
								nChannelNo = 0;
							} else {
								nChannelNo = m_arrMemberGroup.get(nTargetPosition).m_nChannelNo;
							}
							PutGroupPositionReq req = new PutGroupPositionReq(m_arrMemberGroup.get(nOriginalPosition).m_nChannelNo, nChannelNo);
							WebAPI webAPI = new WebAPI(MainTabAct.this);
							int nMovePosition = 0;
							if (fromPosition > toPosition) {
								nMovePosition = nTargetPosition + 1;
							} else {
								nMovePosition = nTargetPosition;
							}
							final int nFinalTargetPosition = nMovePosition;
							webAPI.request(req, new WebListener() {
								@Override
								public void onPreRequest() {
									showProgress();
								}

								@Override
								public void onNetworkError(int a_nErrorCode, String a_strMessage) {
									closeProgress();
									showErrorPopup(a_nErrorCode, a_strMessage);
								}

								@Override
								public void onPostRequest(String a_strData) {
									ChannelData tempData = new ChannelData();
									tempData = m_arrMemberGroup.get(nOriginalPosition);
									m_arrMemberGroup.remove(nOriginalPosition);
									m_arrMemberGroup.add(nFinalTargetPosition, tempData);
									closeProgress();
								}
							});
						}
					}
				});
				closeProgress();
			}
		});




	}

	private class MyDragItem extends DragItem {
		public MyDragItem(Context context, int layoutId){
			super(context, layoutId);
		}

		@Override
		public void onBindDragView(View clickedView, View dragView) {
			CharSequence text = ((TextView) clickedView.findViewById(R.id.tv_channel_list_item_title)).getText();
			((TextView) dragView.findViewById(R.id.tv_channel_list_item_title)).setText(text);
			((ImageView) dragView.findViewById(R.id.iv_channel_list_item_move)).setVisibility(View.VISIBLE);
			((TextView) dragView.findViewById(R.id.tv_channel_list_item_count)).setVisibility(View.GONE);
			dragView.setBackgroundColor(Color.parseColor("#59ffffff"));
		}
	}
	public void setChannelInfoListener(OnChannelInfoListener listener){
		m_ChannelInfoListener = listener;
	}
	public interface OnChannelInfoListener{
		public void setInfo(int a_nChannelNo, String a_strName, boolean a_isNotice);
		public void setFirstChannelView(int a_nChannelNo, String a_strName);
		public void setNewMessage();
		public void setRefresh(int a_nChannelNo);
	}
	private class ChannelListAdapter extends DragItemAdapter<Pair<Long, ChannelData>, ChannelListAdapter.ViewHolder> {

		private int mLayoutId;
		private int mGrabHandleId;
		private boolean mDragOnLongPress;
		private ArrayList<Pair<Long, ChannelData>> m_List;
		private boolean m_isEditMode = false;

		ChannelListAdapter(ArrayList<Pair<Long, ChannelData>> list, int layoutId, int grabHandleId, boolean dragOnLongPress) {
			mLayoutId = layoutId;
			mGrabHandleId = grabHandleId;
			mDragOnLongPress = dragOnLongPress;
			setHasStableIds(true);
			m_List = list;
			setItemList(list);
		}

		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			View view = LayoutInflater.from(MainTabAct.this).inflate(mLayoutId, parent, false);
			return new ViewHolder(view);
		}

		@Override
		public void onBindViewHolder(ViewHolder holder, int position) {
			super.onBindViewHolder(holder, position);
			if(m_arrItem.get(position).second.m_nViewType == 0){
				holder.m_layoutUnInvitedListText.setVisibility(View.VISIBLE);
				holder.m_layoutUninvitedList.setVisibility(View.GONE);
				holder.m_layoutChannelListText.setVisibility(View.GONE);
				holder.m_layoutChannelList.setVisibility(View.GONE);
				holder.m_ivChannelListMoveBtn.setVisibility(View.GONE);
				holder.m_ivChannelListMoveTouchArea.setVisibility(View.GONE);
				holder.m_tvChannelListNoseeCount.setVisibility(View.GONE);
			} else if(m_arrItem.get(position).second.m_nViewType == 1) {
				holder.m_layoutUnInvitedListText.setVisibility(View.GONE);
				holder.m_layoutUninvitedList.setVisibility(View.VISIBLE);
				holder.m_layoutChannelListText.setVisibility(View.GONE);
				holder.m_layoutChannelList.setVisibility(View.GONE);
				holder.m_tvUninvitedTitle.setText(m_arrItem.get(position).second.m_strName);
				holder.m_ivChannelListMoveBtn.setVisibility(View.GONE);
				holder.m_ivChannelListMoveTouchArea.setVisibility(View.GONE);
				holder.m_tvChannelListNoseeCount.setVisibility(View.GONE);
				final int nPosition = position;
				holder.m_tvUninvitedOk.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						PutGroupInviteAcceptReq req = new PutGroupInviteAcceptReq(m_arrItem.get(nPosition).second.m_nChannelNo, App.m_MyUserInfo.m_nUserNo);
						WebAPI webAPI = new WebAPI(MainTabAct.this);
						webAPI.request(req, new WebListener() {
							@Override
							public void onPreRequest() {
								showProgress();
							}

							@Override
							public void onNetworkError(int a_nErrorCode, String a_strMessage) {
								closeProgress();
								showErrorPopup(a_nErrorCode, a_strMessage);
							}

							@Override
							public void onPostRequest(String a_strData) {
								getSNSGroupList();
								getSNSBadgeCount();
								m_ChannelInfoListener.setInfo(m_arrItem.get(nPosition).second.m_nChannelNo, m_arrItem.get(nPosition).second.m_strName, false);
								if(m_DrawerLayout.isDrawerOpen(Gravity.LEFT)){
									m_DrawerLayout.closeDrawer(Gravity.LEFT, false);
								}
							}
						});
					}
				});
				holder.m_tvUninvitedCancel.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						PutGroupInviteRejectionReq req = new PutGroupInviteRejectionReq(m_arrItem.get(nPosition).second.m_nChannelNo, App.m_MyUserInfo.m_nUserNo);
						WebAPI webAPI = new WebAPI(MainTabAct.this);
						webAPI.request(req, new WebListener() {
							@Override
							public void onPreRequest() {
								showProgress();
							}

							@Override
							public void onNetworkError(int a_nErrorCode, String a_strMessage) {
								closeProgress();
								showErrorPopup(a_nErrorCode, a_strMessage);
							}

							@Override
							public void onPostRequest(String a_strData) {
								getSNSGroupList();
								getSNSBadgeCount();
							}
						});
					}
				});
			} else if(m_arrItem.get(position).second.m_nViewType == 2){
				holder.m_layoutUnInvitedListText.setVisibility(View.GONE);
				holder.m_layoutUninvitedList.setVisibility(View.GONE);
				holder.m_layoutChannelListText.setVisibility(View.VISIBLE);
				holder.m_layoutChannelList.setVisibility(View.GONE);
				holder.m_ivChannelListMoveBtn.setVisibility(View.VISIBLE);
				if(m_isEditMode){
					holder.m_ivChannelListMoveBtn.setBackgroundResource(R.drawable.btn_move_ok);
				} else {
					holder.m_ivChannelListMoveBtn.setBackgroundResource(R.drawable.btn_move_edit);
				}
				holder.m_ivChannelListMoveTouchArea.setVisibility(View.GONE);
				holder.m_tvChannelListNoseeCount.setVisibility(View.GONE);
				if(m_arrInvitingGroup != null && m_arrInvitingGroup.size() != 0){
					holder.m_vLine.setVisibility(View.VISIBLE);
				} else {
					holder.m_vLine.setVisibility(View.GONE);
				}
			} else {
				holder.m_layoutUnInvitedListText.setVisibility(View.GONE);
				holder.m_layoutUninvitedList.setVisibility(View.GONE);
				holder.m_layoutChannelListText.setVisibility(View.GONE);
				holder.m_layoutChannelList.setVisibility(View.VISIBLE);
				holder.m_tvChannelTitle.setText(m_arrItem.get(position).second.m_strName);
				holder.m_nNo = m_arrItem.get(position).second.m_nChannelNo;
				holder.m_strName = m_arrItem.get(position).second.m_strName;
				holder.m_ivChannelListMoveBtn.setVisibility(View.GONE);
				if(m_isEditMode){
					holder.m_ivChannelListMoveTouchArea.setVisibility(View.VISIBLE);
					holder.m_tvChannelListNoseeCount.setVisibility(View.GONE);
				} else {
					holder.m_ivChannelListMoveTouchArea.setVisibility(View.GONE);
					holder.m_tvChannelListNoseeCount.setVisibility(View.VISIBLE);
					if(m_arrBadgetCount != null){
						if(m_arrBadgetCount.get(holder.m_nNo) != null && m_arrBadgetCount.get(holder.m_nNo) != 0){
							holder.m_tvChannelListNoseeCount.setText("" + m_arrBadgetCount.get(holder.m_nNo));
						} else {
							holder.m_tvChannelListNoseeCount.setVisibility(View.GONE);
						}
					}
				}
			}
			holder.itemView.setTag(m_arrItem.get(position));
		}

		@Override
		public long getItemId(int position) {
			return m_arrItem.get(position).first;
		}

		class ViewHolder extends DragItemAdapter.ViewHolder {
			RelativeLayout m_layoutUnInvitedListText, m_layoutUninvitedList, m_layoutChannelListText, m_layoutChannelList;

			TextView m_tvUninvitedTitle, m_tvChannelTitle;
			int m_nNo = -1;
			String m_strName = "";
			View m_vLine;
			TextView m_tvUninvitedOk, m_tvUninvitedCancel;
			ImageView m_ivChannelListMoveBtn;
			ImageView m_ivChannelListMoveTouchArea;
			TextView m_tvChannelListNoseeCount;

			ViewHolder(final View itemView) {
				super(itemView, mGrabHandleId, mDragOnLongPress);
				m_layoutUnInvitedListText = (RelativeLayout) itemView.findViewById(R.id.layout_uninvited_list_text);
				m_layoutUninvitedList = (RelativeLayout) itemView.findViewById(R.id.layout_uninvited_list);
				m_layoutChannelListText = (RelativeLayout) itemView.findViewById(R.id.layout_channel_list_text);
				m_layoutChannelList = (RelativeLayout) itemView.findViewById(R.id.layout_channel_list);

				m_vLine = (View) itemView.findViewById(R.id.v_channel_list_line);

				m_tvUninvitedTitle = (TextView) itemView.findViewById(R.id.tv_uninvited_list_item_title);
				m_tvChannelTitle = (TextView) itemView.findViewById(R.id.tv_channel_list_item_title);
				m_tvChannelTitle.setHorizontallyScrolling(true);
				m_tvChannelTitle.setMaxLines(1);
				m_tvChannelTitle.setEllipsize(TextUtils.TruncateAt.END);

				m_tvUninvitedOk = (TextView) itemView.findViewById(R.id.tv_uninvited_list_item_ok);
				m_tvUninvitedCancel = (TextView) itemView.findViewById(R.id.tv_uninvited_list_item_cancel);

				m_ivChannelListMoveBtn = (ImageView) itemView.findViewById(R.id.iv_channel_list_move_btn);
				m_ivChannelListMoveTouchArea = (ImageView) itemView.findViewById(R.id.iv_channel_list_item_move);
				m_tvChannelListNoseeCount = (TextView) itemView.findViewById(R.id.tv_channel_list_item_count);
				m_ivChannelListMoveBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						if(m_isEditMode){
							m_isEditMode = false;
						} else {
							m_isEditMode = true;
						}
						setItemList(m_List);
					}
				});
			}

			@Override
			public void onItemClicked(View view) {
				/*Intent intent = new Intent(MainTabAct.this, SNSGroupDetailAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, m_nChannelNo);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME, m_strName);
				startActivityForResult(intent, 0);*/
				if(m_nNo != -1) {
					m_nChannelNo = m_nNo;
					m_strChannelName = m_strName;
					m_ChannelInfoListener.setInfo(m_nNo, m_strName, false);
					m_DrawerLayout.closeDrawer(Gravity.LEFT, false);
					m_DrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
				}
			}

			@Override
			public boolean onItemLongClicked(View view) {
				return true;
			}

		}
	}
	/*private class ChannelListAdapter extends BaseAdapter {


		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if(convertView == null)
			{
				LayoutInflater li = LayoutInflater.from(MainTabAct.this);
				convertView = li.inflate(R.layout.layout_channel_list_item, parent, false);
			}

			TextView tvChannelListTitle = (TextView)convertView.findViewById(R.id.tv_channel_list_item_title);
			tvChannelListTitle.setText(m_arrInvitedGroup.get(position).m_strGroupName);
			return convertView;
		}

		@Override
		public int getCount() {
			return m_arrInvitedGroup.size();
		}

		@Override
		public Object getItem(int position) {
			return m_arrInvitedGroup.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}
	}*/
}

