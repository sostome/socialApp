package com.gmp.rusk.request;

import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by kang on 2017-09-18.
 */

public class TCallReq extends Req {

    private String APINAME = "internal";
    private String AUTHENTIFICATION = "true";
    private final String METHOD = "POST";

    private final String JSON_PHONENUMBER = "phoneNumber";

    private String m_strPhoneNum = "";

    // 클라우드 파일
    private ArrayList<SNSBoardFileData> m_arrCloudFileData = null;

    public TCallReq(String a_strPhoneNum) {
        APINAME = APINAME + "/t-call";
        m_strPhoneNum = a_strPhoneNum;
    }


    public String getAPIName() {
        return APINAME;
    }

    public String getMethod() {
        return METHOD;
    }

    @Override
    public String getJsonData() {
        // TODO Auto-generated method stub
        try {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put(JSON_PHONENUMBER, m_strPhoneNum);

            return jsonObj.toString();
        } catch (Exception e) {
            CommonLog.e(PostGroupBoardReq.class.getSimpleName(), "" + e.toString());
            return "";
        }
    }

    @Override
    public String getParamData() {
        // TODO Auto-generated method stu
        return null;
    }

    @Override
    public String getNameValuePair() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String getIsAuthentification() {
        // TODO Auto-generated method stub
        return AUTHENTIFICATION;
    }
}