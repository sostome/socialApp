package com.gmp.rusk.act;

import java.util.ArrayList;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.FileInfo;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.FileExplorer;
import com.gmp.rusk.utils.IntentKeyString;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class FileMultiSelectorAct extends CustomActivity implements OnItemClickListener,OnClickListener {

	private final String TAG = FileMultiSelectorAct.class.getSimpleName();
	public static final int VIEW_TYPE_ROW_1 = 0; //directory 
	public static final int VIEW_TYPE_ROW_2 = 1; //file
	
	private LinearLayout m_directory_info = null;
	private TextView m_tvTitle = null;
	private ListView m_lvSelectFile = null;
	private ImageView m_btnUpperFolder = null;
	
	private FileListAdapter m_FileListAdapter = null;
	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup;
	
	private ImageView m_btnComplete = null;
	
	private HorizontalScrollView m_BadgeScroll;
	private LinearLayout m_LayoutBadge;
	private LayoutInflater inflater;
	
	private int m_nAbleFileCount = 10;
	private long m_lnAbleFileMaxSize = 104857600L;
	
	private long m_lnSelectedFileTotalSize = 0L;
	private String homeDir = "";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_filemultiselector);
		checkIntent();
		init();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
//		if(!m_FileListAdapter.getCurrentDir().equalsIgnoreCase(m_FileListAdapter.getHomeDir()))
//		{
		if(!m_FileListAdapter.getNowFolder().equalsIgnoreCase("/")){
			m_FileListAdapter.getPreviousFolder();
			m_FileListAdapter.notifyDataSetChanged();
//			if(m_FileListAdapter.getCurrentDir().equalsIgnoreCase(m_FileListAdapter.getHomeDir()))
//				m_directory_info.setVisibility(View.GONE);
			m_tvTitle.setText(m_FileListAdapter.getNowFolder());
		}
		else
			super.onBackPressed();
	}
	
	private void checkIntent()
	{
		m_nAbleFileCount = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILECOUNT, 10);
		m_lnAbleFileMaxSize = getIntent().getLongExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILEMAXSIZE, 104857600L);
	}
	
	public void init() {
		m_directory_info = (LinearLayout)findViewById(R.id.layout_filemultiselector_info);
		m_lvSelectFile = (ListView) findViewById(R.id.lv_filemultiselector_filelist);
		FileExplorer fileExplorer = new FileExplorer();
		m_FileListAdapter = new FileListAdapter(fileExplorer);
		m_FileListAdapter.getFileInfo();
		
		m_lvSelectFile.setAdapter(m_FileListAdapter);
		m_lvSelectFile.setOnItemClickListener(this);

		m_tvTitle = (TextView) findViewById(R.id.tv_filemultiselector_currentfoldername);
		m_tvTitle.setText(m_FileListAdapter.getNowFolder());
		
		ImageView btnBack = (ImageView) findViewById(R.id.btn_filemultiselector_back);
		m_btnComplete = (ImageView) findViewById(R.id.btn_filemultiselector_complete);
		m_btnUpperFolder = (ImageView)findViewById(R.id.btn_filemultiselector_upperfolder);
		
		btnBack.setOnClickListener(this);
		m_btnComplete.setOnClickListener(this);
		m_btnUpperFolder.setOnClickListener(this);
		
		
		m_BadgeScroll = (HorizontalScrollView) findViewById(R.id.sv_badge);
		m_LayoutBadge = (LinearLayout) findViewById(R.id.layout_badge);
		inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
		m_BadgeScroll.setVisibility(View.GONE);
		m_btnComplete.setVisibility(View.GONE);
//		m_directory_info.setVisibility(View.GONE);
		m_directory_info.setVisibility(View.VISIBLE);
		//기존에 선택된 파일리스트도 가져오기 위해 작성됨 
		//기능 사용하지 않기 때문에 주석처리 
//		Intent intent = getIntent();
//		if(intent.hasExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST))
//		{
//			ArrayList<Parcelable> parcelList = intent.getParcelableArrayListExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST);
//			ArrayList<FileInfo> receiveList = (ArrayList<FileInfo>)parcelList.clone();
//			for(FileInfo fi : receiveList)
//			{
//				addSearchList(fi);
//			}
//		}
	}
	
	private void showAlertPopup(int a_nStringRes)
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(a_nStringRes));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
	
	public class FileListAdapter extends BaseAdapter {
		public ImageView m_ivSelectFile =  null;
		public TextView m_tvSelectFile, m_tvSelectFolder , m_tvAddFile;
		public RelativeLayout m_layoutSelectFile, m_layoutSelectFolder;
		
		private FileExplorer mFileExplorer;
		public ArrayList<FileInfo> mDataSourceList;
		public ArrayList<FileInfo> mSelectedDataList;
		public LayoutInflater mInflater;
		
		public View convertView_Dir;
		public View convertView_File;
		
		public FileListAdapter(FileExplorer fileexplorer)
		{
			mFileExplorer = fileexplorer;
			mInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			mSelectedDataList = new ArrayList<FileInfo>();
		}
		
		public void getFileInfo()
		{
			CommonLog.e(TAG,Environment.getExternalStorageDirectory().getPath());
			homeDir = Environment.getExternalStorageDirectory().getPath();
			mDataSourceList = mFileExplorer.setFolder(homeDir, FileExplorer.TYPE_ROOT);
		}
		
		public void getNextDir(String path)
		{
			mDataSourceList = mFileExplorer.setFolder(path, FileExplorer.TYPE_NEXT);
		}
		
		@Override
		public void notifyDataSetChanged() {
			
			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nUserListDataSize = 0;

			if ( !mDataSourceList.isEmpty())
				nUserListDataSize = mDataSourceList.size();

			return nUserListDataSize;
		}

		@Override
		public FileInfo getItem(int position) {
			// TODO Auto-generated method stub
			
			return mDataSourceList.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}
		
		@Override
		public int getItemViewType(int position)
		{
			return getItem(position).m_intType;
		}
		
		@Override
		public int getViewTypeCount()
		{
			// type -> directory 0, file 1
			return 2;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub			
			int type = getItemViewType(position);
			
			FileInfo selectedFile = getItem(position);
			
			if(type == VIEW_TYPE_ROW_1)
			{
				if(convertView == null)
				{
					convertView =  mInflater.inflate(R.layout.layout_listitem_multiselect_folder, parent,false);
				}
				m_layoutSelectFolder = (RelativeLayout)convertView.findViewById(R.id.layout_select_folder);
				m_tvSelectFolder = (TextView) convertView.findViewById(R.id.tv_select_folder_listitem);
				m_tvSelectFolder.setText(selectedFile.m_strName);
			}
			else if (type == VIEW_TYPE_ROW_2)
			{
				if(convertView == null)
				{
					convertView =  mInflater.inflate(R.layout.layout_listitem_multiselect_file, parent,false);
				}
				m_layoutSelectFile = (RelativeLayout) convertView.findViewById(R.id.layout_select_file);
				m_ivSelectFile = (ImageView) convertView.findViewById(R.id.iv_select_file_listitem);
				m_tvAddFile = (TextView) convertView.findViewById(R.id.tv_add_file_listitem);
				m_tvSelectFile = (TextView) convertView.findViewById(R.id.tv_select_file_listitem);
				m_tvSelectFile.setText(selectedFile.m_strName);
				String extension = selectedFile.m_strName.substring(selectedFile.m_strName.lastIndexOf(".") + 1, selectedFile.m_strName.length());
				extension = extension.toLowerCase();
				if(extension.equalsIgnoreCase("txt") || extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx") ||
						extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv") ||
						extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx") ||
						extension.equalsIgnoreCase("pdf") || extension.equalsIgnoreCase("hwp") ||
						extension.equalsIgnoreCase("png") || extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("jpeg") || extension.equalsIgnoreCase("bmp") ||
						extension.equalsIgnoreCase("avi") || extension.equalsIgnoreCase("asf") || extension.equalsIgnoreCase("mov") || extension.equalsIgnoreCase("mp4") || extension.equalsIgnoreCase("wmv") ||
						extension.equalsIgnoreCase("vcf") || extension.equalsIgnoreCase("zip")) {
					m_tvAddFile.setVisibility(View.VISIBLE);
				} else {
					m_tvAddFile.setVisibility(View.GONE);
				}
				m_tvAddFile.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						FileInfo fi = m_FileListAdapter.getItem(position);
//			m_FileListAdapter.addSelectedFile(fi);
						if(!fi.m_intSelected)
						{
							long lnSelectFileTotalSize = m_lnSelectedFileTotalSize + fi.m_lnSize;
							if(m_FileListAdapter.mSelectedDataList.size() < m_nAbleFileCount && lnSelectFileTotalSize <= m_lnAbleFileMaxSize && lnSelectFileTotalSize != 0L)
							{
								addSearchList(fi);
								m_FileListAdapter.notifyDataSetChanged();
							}
							else
							{
								if(m_FileListAdapter.mSelectedDataList.size() == m_nAbleFileCount)
								{
									showAlertPopup(R.string.popup_sns_attach_maxcount);
								}
								else if(lnSelectFileTotalSize > m_lnAbleFileMaxSize)
								{
									showAlertPopup(R.string.popup_attach_maxsize);
								}
								else if(lnSelectFileTotalSize == 0L)
								{
									showAlertPopup(R.string.popup_attach_minsize);
								}
							}

						}
						else
						{
							/*ArrayList<FileInfo> f_arrayListComp = m_FileListAdapter.isSelectedFile();
							for(int f = 0;f < f_arrayListComp.size();f ++)
							{
								if(f_arrayListComp.get(f).m_strPath.equalsIgnoreCase(fi.m_strPath))
									removeListData(f_arrayListComp.get(f).m_intSelectIndex);
							}*/
						}
					}
				});
				if(!getSelectedPosition(position)) {
					m_tvAddFile.setBackgroundResource(R.drawable.btn_assent);
					m_tvAddFile.setTextColor(Color.parseColor("#333333"));
				}
				else {
					m_tvAddFile.setBackgroundResource(R.drawable.btn_assent_disabled);
					m_tvAddFile.setTextColor(Color.parseColor("#cdcdcd"));
				}
				
				/*if(mSelectedDataList.size() !=0)
				{
					if(mSelectedDataList == null || mSelectedDataList.size() == 0)
						m_btnComplete.setText(R.string.act_filemultiselector_complete);
					else
						m_btnComplete.setText(getString(R.string.act_filemultiselector_complete) + mSelectedDataList.size());
				}*/
			}

			return convertView;
		}

		public void addSelectedFile(int index, FileInfo selectFile)
		{
			if(!mSelectedDataList.contains(selectFile))
			{
				selectFile.m_intSelectIndex = index;
				selectFile.m_intSelected = true;
				m_lnSelectedFileTotalSize += selectFile.m_lnSize;
				mSelectedDataList.add(index,selectFile);
			}
		}
		
		public void removeSelectedFile(int index,  FileInfo selectFile)
		{
			selectFile.m_intSelectIndex = -1;
			selectFile.m_intSelected = false;
			m_lnSelectedFileTotalSize -= selectFile.m_lnSize;
			mSelectedDataList.remove(index);
		}
		
		public void replaceSelectdFile(ArrayList<FileInfo> removeFileList)
		{
			if(!mSelectedDataList.isEmpty())
			{
				mSelectedDataList.clear();
			}
			
			for(int i =0;i < removeFileList.size(); i++)
			{
				removeFileList.get(i).m_intSelectIndex = i;
				mSelectedDataList.add(i, removeFileList.get(i));
			}
		}
		
		public boolean getSelectedPosition(int position)
		{
			FileInfo fi = getItem(position);
			
			for(int i =0;i< mSelectedDataList.size();i++)
			{
				if(mSelectedDataList.get(i).m_strPath.equalsIgnoreCase(fi.m_strPath))
					return true;
			}

			return false;
		}
		
		public int getPathToPosition(String path)
		{
			for(int i =0;i< mDataSourceList.size();i++)
			{
				if(mDataSourceList.get(i).m_strPath.equalsIgnoreCase(path))
					return i;
			}
			
			return -1;
		}
		
		public ArrayList<FileInfo> isSelectedFile()
		{
			return mSelectedDataList;
		}
		
		public void setSelectedFile(ArrayList<FileInfo> selectArray)
		{
			mSelectedDataList = selectArray;
		}
		
		public String getNowFolder()
		{
			return mFileExplorer.getNowFolder();
		}

		public void getPreviousFolder()
		{
			mDataSourceList = mFileExplorer.setFolder("", FileExplorer.TYPE_PREVIOUS);
		}
		
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.btn_filemultiselector_back)
		{
			//취소 버튼 클릭
			setResult(RESULT_CANCELED);
			finish();
		}
		else if(v.getId() == R.id.btn_filemultiselector_complete)
		{
			//완료 버튼 클릭
			if(m_FileListAdapter.isSelectedFile().size() < 0)
				return;
			
			Intent i = new Intent();
			i.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST, m_FileListAdapter.isSelectedFile());
			setResult(RESULT_OK, i);
			finish();
		}
		else if(v.getId() == R.id.btn_filemultiselector_upperfolder )
		{
			//상위 폴더로 이동
			if(!m_FileListAdapter.getNowFolder().equalsIgnoreCase("/"))
			{
				m_FileListAdapter.getPreviousFolder();
				m_FileListAdapter.notifyDataSetChanged();
//				if(m_FileListAdapter.getCurrentDir().equalsIgnoreCase(m_FileListAdapter.getHomeDir()))
//					m_directory_info.setVisibility(View.GONE);
				m_tvTitle.setText(m_FileListAdapter.getNowFolder());
			}
		}
	}
	
	//개별적으로 아이템을 클릭했을 경우 디렉토리 혹은 파일의 경우로 나누어서 기능을 수행합니다.
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
		// TODO Auto-generated method stub
		FileInfo finfo = m_FileListAdapter.getItem(position);
		
		if(finfo.m_intType == VIEW_TYPE_ROW_1)	//디렉토리 
		{
//			if(m_directory_info.getVisibility() == View.GONE)
//				m_directory_info.setVisibility(View.VISIBLE);
			
			m_FileListAdapter.getNextDir(finfo.m_strName);
			m_tvTitle.setText(m_FileListAdapter.getNowFolder());
			m_FileListAdapter.notifyDataSetChanged();
		}
		else if (finfo.m_intType == VIEW_TYPE_ROW_2)	//파일
		{
			//TODO ADD -> Add the item where black bar under the title bar
			/*FileInfo fi = m_FileListAdapter.getItem(position);
//			m_FileListAdapter.addSelectedFile(fi);
			if(!fi.m_intSelected)
			{
				long lnSelectFileTotalSize = m_lnSelectedFileTotalSize + fi.m_lnSize;
				if(m_FileListAdapter.mSelectedDataList.size() < m_nAbleFileCount && lnSelectFileTotalSize <= m_lnAbleFileMaxSize && lnSelectFileTotalSize != 0L)
				{
					addSearchList(fi);
					m_FileListAdapter.notifyDataSetChanged();
				}
				else
				{
					if(m_FileListAdapter.mSelectedDataList.size() == m_nAbleFileCount)
					{
						showAlertPopup(R.string.popup_sns_attach_maxcount);
					}
					else if(lnSelectFileTotalSize > m_lnAbleFileMaxSize)
					{
						showAlertPopup(R.string.popup_attach_maxsize);
					}
					else if(lnSelectFileTotalSize == 0L)
					{
						showAlertPopup(R.string.popup_attach_minsize);
					}
				}
			}
			else
			{
				ArrayList<FileInfo> f_arrayListComp = m_FileListAdapter.isSelectedFile();
				for(int f = 0;f < f_arrayListComp.size();f ++)
				{
					if(f_arrayListComp.get(f).m_strPath.equalsIgnoreCase(fi.m_strPath))
						removeListData(f_arrayListComp.get(f).m_intSelectIndex);
				}
			}*/
			
		}

	}
	
	public void showProgress(String a_strMsg) 
	{
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);
		
		if (!m_Progress.isShowing())
			m_Progress.show();
	}

	public void closeProgress() 
	{
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
		
		m_Progress = null;
	}

	//선택된 아이템과 같은 인덱스의 UI 아이템이 존재할 경우 인덱스 번호를 받아서 삭제 처리를 진행합니다.
	public void removeListData(int removeFileIndex) {
		boolean isCollect = false;	//선택된 아이템이 맞는지 확인 하기 위한 플래그 변
		
		ArrayList<FileInfo> originSelectList =  m_FileListAdapter.isSelectedFile();
		FileInfo removeFile = originSelectList.get(removeFileIndex);
		ArrayList<FileInfo> tempList = new ArrayList<FileInfo>();	//선택된 아이템 삭제 후 결과를 저장할 리스트 
		//선택된 파일 리스트 중에 삭제 아이템을 확인하고 삭제 후의 결과를 tempList에 저장한다.
		int i = 0;
		for (int r = 0;r < originSelectList.size(); r++) {
			if (originSelectList.get(r).m_intSelectIndex == removeFileIndex) 
			{
				isCollect = true;
			}
			else
			{
				FileInfo addFile = originSelectList.get(r);
				addFile.m_intSelectIndex = i;//개별 인덱스 갱신
				tempList.add(addFile);
				i++;
			}
		}
		
		//삭제 파일이 있을 경우 삭제 진행
		if(isCollect)
		{
			//int removeOriginIndex = m_FileListAdapter.getPathToPosition(removeFile.m_strPath); 						//선택된 파일 경로를 이용해 파일 리스트의 인덱스를 추출
			//m_FileListAdapter.removeSelectedFile(removeFileIndex, m_FileListAdapter.getItem(removeOriginIndex));	//선택된 파일 리스트에서 아이템 삭제 및 상태값 갱신
			m_FileListAdapter.removeSelectedFile(removeFileIndex, removeFile);
			m_LayoutBadge.removeViewAt(removeFileIndex);			//아이템 UI 삭제 
		}
		
		//선택된 파일이 없을 경우 UI를 초기화를 해줍니다.
		if ( m_FileListAdapter.isSelectedFile().isEmpty()) {
			m_BadgeScroll.setVisibility(View.GONE);
			m_btnComplete.setVisibility(View.GONE);
		}
		m_FileListAdapter.notifyDataSetChanged();
	}
	
	
	//파일을 선택 했을 경우 check box 표시와 상단 선택 리스트에 아이템 추가를 담당합니다.
	public void addSearchList(FileInfo a_SearchListData) {
		if (m_FileListAdapter.isSelectedFile().isEmpty()) {
			m_BadgeScroll.setVisibility(View.VISIBLE);	//상단 아이템 선택 바를 볼수 있도록 해줍니다.
			m_btnComplete.setVisibility(View.VISIBLE);  //우측 상단에 추가 버튼을 볼수 있도록 해줍니다.
		}
		
		boolean isSame = false;
		/*
		 * 이미 추가되어있는 파일인지 검사합니다.
		 * isSame = true -> pass
		 * isSame = false -> add
		 */
		ArrayList<FileInfo> selectedFileArrayList = m_FileListAdapter.isSelectedFile();
		for (int a = 0;a < selectedFileArrayList.size(); a++) {

			if (selectedFileArrayList.get(a).m_strPath.equalsIgnoreCase(a_SearchListData.m_strPath)) {
				isSame = true;
			}
		}
		
		//추가된 아이템이 아니라면 추가하는 작업을 진행합니다.
		if (!isSame) {
			int addIndex = m_FileListAdapter.isSelectedFile().size();
			m_FileListAdapter.addSelectedFile(addIndex, a_SearchListData);	//추가된 순서대로 아이템이 보여지도록 리스트를 설정합니다. ex) addIndex ->첫번째 0, 두번째 1, 세번째 2
			final LinearLayout inviteScrollItem = (LinearLayout) inflater.inflate(R.layout.layout_invite_scroll_item, null); 
			m_LayoutBadge.addView(inviteScrollItem, addIndex);				//추가된 순서대로 아이템이 보여지도록 UI를 설정합니다. ex) addIndex -> 첫번째 0, 두번째 1, 세번째 2
			final TextView tvInviteScrollItem = (TextView) inviteScrollItem.findViewById(R.id.tv_invite_scroll_item);
			tvInviteScrollItem.setText(a_SearchListData.m_strName);
			inviteScrollItem.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// 추가된 아이템의 위치를 확인하고 선택된 파일의 인덱스와 UI 인덱스가 같으면 삭제를 진행합니다.
					int index = m_LayoutBadge.indexOfChild(inviteScrollItem);
					ArrayList<FileInfo> compArrayList = m_FileListAdapter.isSelectedFile();
					for (int i = 0;i < compArrayList.size();i++) {
						if (compArrayList.get(i).m_intSelectIndex == index) {
							removeListData(index);
							break;
						}

					}

				}
			});
		}
	}
		
	
}