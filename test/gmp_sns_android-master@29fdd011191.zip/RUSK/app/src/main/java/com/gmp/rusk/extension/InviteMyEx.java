package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

public class InviteMyEx extends IQ {
	public final static String NAMESPACE = "jabber:iq:invite";
	private final String NAMESPACE_Q = "<query xmlns=\"jabber:iq:invite\">";

	private String namespace = null;

	public InviteMyEx() {
	}

	public InviteMyEx(String namespace) {
		this.namespace = namespace;
	}

	@Override
	public String getChildElementXML() {
		StringBuilder buf = new StringBuilder();
		buf.append(NAMESPACE_Q);
		if (namespace != null) {
			buf.append("<user>").append(namespace).append("</user>");
		}
		buf.append("</query>");
		return buf.toString();
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getNamespace() {
		return namespace;
	}

	public static class Provider implements IQProvider {

		@Override
		public IQ parseIQ(XmlPullParser parser) throws Exception {
			// TODO Auto-generated method stub

			String namespace = null;
			boolean done = false;
			while (!done) {
				int eventType = parser.next();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("query")) {

					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals("query")) {
						namespace = parser.getNamespace();
						done = true;

					}
				}
			}
			return new InviteMyEx(namespace);
		}

	}

}