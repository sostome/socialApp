package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class PostGroupImageUploadRes extends Res{
	
	private final String JSON_URL					= "url";
	private final String JSON_PREVIEWURL			= "previewUrl";
	
	private String m_strUrl = "";
	private String m_strPreviewUrl = "";
	
	public PostGroupImageUploadRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			m_strUrl = jsonRoot.getString(JSON_URL);
			m_strPreviewUrl = jsonRoot.getString(JSON_PREVIEWURL);
		}
		catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getUrl()
	{
		return m_strUrl;
	}
	
	public String getPreviewUrl()
	{
		return m_strPreviewUrl;
	}
}
