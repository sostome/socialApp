package com.gmp.rusk.request;



/**
 *	@author subi78
 *			파트너 승인 
 *			method : put
 */

public class PutApprovedPartnerReq extends Req{
	
	private String APINAME = "regular";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";
	
	
	public PutApprovedPartnerReq(int[] a_nPartnerNo)
	{
		String strTargetUserNos = "";
		for(int i=0;i<a_nPartnerNo.length;i++)
		{
			strTargetUserNos = strTargetUserNos + a_nPartnerNo[i];
			
			if(i < a_nPartnerNo.length-1)
				strTargetUserNos = strTargetUserNos + ",";
		}
		
		APINAME = APINAME +"/"+App.m_EntryData.m_nUserNo+"/partner/"+strTargetUserNos;
	}
	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
