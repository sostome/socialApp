package com.gmp.rusk.db;

public class DatabaseDefine {
	
	public static final int DATABASE_VERSION = 1;
	public static final int DATABASE_ROOMDB_VERSION = 3;
	public static final int DATABASE_CHATTINGDB_VERSION = 2;
}
