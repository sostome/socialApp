package com.gmp.rusk.act;

import android.os.Bundle;
import android.util.SparseArray;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostSendURLReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.PopupIndex;

import java.util.ArrayList;

/**
 * Created by kang on 2017-08-27.
 */

public class RecommendCorkAct extends CustomActivity implements View.OnClickListener{

    CommonPopup m_Popup = null;
    private ProgressDlg m_Progress = null;

    TextView tv_m_spText;
    EditText m_et_phoneNumMid;
    EditText m_et_phoneNumEnd;

    Spinner spn_search_type;

    ArrayAdapter<CharSequence> adspin;


    @Override
    protected void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);
        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_recommend_cork);

        init();
    }

    private void init(){
        ImageView iv_Cancel = (ImageView) findViewById(R.id.btn_cancel);
        tv_m_spText = (TextView) findViewById(R.id.tv_spinner_text);
        spn_search_type = (Spinner)findViewById(R.id.spn_search_type);
        adspin = ArrayAdapter.createFromResource(this, R.array.arr_recommend_cork_num, R.layout.layout_spinner_textview);
        adspin.setDropDownViewResource(R.layout.spinner_custom_list_item);
        spn_search_type.setAdapter(adspin);
        spn_search_type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position == 0) {
                    tv_m_spText.setText("010");
                } else if(position == 1) {
                    tv_m_spText.setText("011");
                } else if(position == 2) {
                    tv_m_spText.setText("016");
                } else if(position == 3) {
                    tv_m_spText.setText("017");
                } else if(position == 4) {
                    tv_m_spText.setText("018");
                } else if(position == 5) {
                    tv_m_spText.setText("019");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        iv_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        m_et_phoneNumMid = (EditText) findViewById(R.id.et_phone_num_mid);
        m_et_phoneNumEnd = (EditText) findViewById(R.id.et_phone_num_end);
        Button btn_Recommend = (Button) findViewById(R.id.btn_recommend);
        btn_Recommend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(m_et_phoneNumMid.length() > 2 && m_et_phoneNumEnd.length() > 3) {
                    m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_confirm), getString(R.string.cork_pop_cork_recommand_partner));
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                } else if(m_et_phoneNumMid.length() == 0 && m_et_phoneNumEnd.length() == 0){
                    m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_confirm), getString(R.string.cork_pop_cork_recommand_partner_no_number));
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
                else if(m_et_phoneNumMid.length() < 3 || m_et_phoneNumEnd.length() < 4){
                    m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_confirm), getString(R.string.cork_pop_cork_recommand_partner_not_enough_number));
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
            }
        });
    }

    public void requestSendURL(){
        String phoneNum = tv_m_spText.getText().toString()+m_et_phoneNumMid.getText().toString()+m_et_phoneNumEnd.getText().toString();
        ArrayList<String> phoneNums = new ArrayList<>();
        phoneNums.add(phoneNum);
        PostSendURLReq req = new PostSendURLReq(App.m_MyUserInfo.m_nUserNo,phoneNums);
        WebAPI webApi = new WebAPI(this);
        webApi.request(req, new WebListener() {
            @Override
            public void onPreRequest() {
                showProgress();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                closeProgress();
                if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
                    m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }  else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
                    m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
                else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {

                    SparseArray<UserListData> checkUserList = TTalkDBManager.ContactsDBManager.getContactsReturnSparseArray(RecommendCorkAct.this);
                    if(AppSetting.FEATURE_VARIANT.equals("R") && checkUserList.size() == 0){
                        m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
                        m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
                    } else {
                        m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
                        m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
                    }

                    m_Popup.setCancelable(false);
                    m_Popup.show();
                } else {
                    m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
            }

            @Override
            public void onPostRequest(String a_strData) {
                closeProgress();
                m_Popup = new CommonPopup(RecommendCorkAct.this, RecommendCorkAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_cork_recommand_partner_complete));
                m_Popup.setCancelable(false);
                m_Popup.show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        int nId = v.getId();
        if(nId == R.id.ib_pop_ok_long)
        {
            CommonPopup popup_ok_long = (CommonPopup)v.getTag();
            popup_ok_long.cancel();
        }

        else if(nId == R.id.ib_pop_ok)
        {
            requestSendURL();
            CommonPopup popup_ok_long = (CommonPopup)v.getTag();
            popup_ok_long.cancel();
        }
        else if(nId == R.id.ib_pop_cancel)
        {
            CommonPopup popup_ok_long = (CommonPopup)v.getTag();
            popup_ok_long.cancel();
        }
    }
}
