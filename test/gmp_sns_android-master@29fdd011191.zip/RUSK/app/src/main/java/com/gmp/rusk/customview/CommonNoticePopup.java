package com.gmp.rusk.customview;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;

/**
 * Created by kang on 2017-08-29.
 */

public class CommonNoticePopup extends Dialog {

    public int m_nPrevAction = 10000;

    private int m_nHttpStatusCode = -1;

    public CommonNoticePopup(Context context, View.OnClickListener a_Listener, int a_nType) {
        super(context);
        // TODO Auto-generated constructor stub
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        setContentView(R.layout.act_dlg_custom_popup);

        if(a_nType == CommonPopupBtnTypeInt.POP_BTNTYPE_YES)
        {
            LinearLayout layout_one_btn = (LinearLayout)findViewById(R.id.layout_one_btn);
            layout_one_btn.setVisibility(View.VISIBLE);

            ((Button) findViewById(R.id.ib_pop_ok_long)).setOnClickListener(a_Listener);
            ((Button) findViewById(R.id.ib_pop_ok_long)).setTag(this);
        }
        else if(a_nType == CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO)
        {
            LinearLayout layout_two_btn = (LinearLayout)findViewById(R.id.layout_two_btn);
            layout_two_btn.setVisibility(View.VISIBLE);

            ((ImageButton) findViewById(R.id.ib_pop_ok)).setOnClickListener(a_Listener);
            ((ImageButton) findViewById(R.id.ib_pop_ok)).setTag(this);
            ((ImageButton) findViewById(R.id.ib_pop_cancel)).setOnClickListener(a_Listener);
            ((ImageButton) findViewById(R.id.ib_pop_cancel)).setTag(this);
        }
    }

    public CommonNoticePopup(Context context, View.OnClickListener a_Listener, int a_nType, int nPrevAction) {
        super(context);
        // TODO Auto-generated constructor stub
        m_nPrevAction = nPrevAction;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        setContentView(R.layout.act_dlg_custom_popup);

        if(a_nType == CommonPopupBtnTypeInt.POP_BTNTYPE_YES)
        {
            LinearLayout layout_one_btn = (LinearLayout)findViewById(R.id.layout_one_btn);
            layout_one_btn.setVisibility(View.VISIBLE);

            ((ImageButton) findViewById(R.id.ib_pop_ok_long)).setOnClickListener(a_Listener);
            ((ImageButton) findViewById(R.id.ib_pop_ok_long)).setTag(this);
        }
        else if(a_nType == CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO)
        {
            LinearLayout layout_two_btn = (LinearLayout)findViewById(R.id.layout_two_btn);
            layout_two_btn.setVisibility(View.VISIBLE);

            ((ImageButton) findViewById(R.id.ib_pop_ok)).setOnClickListener(a_Listener);
            ((ImageButton) findViewById(R.id.ib_pop_ok)).setTag(this);
            ((ImageButton) findViewById(R.id.ib_pop_cancel)).setOnClickListener(a_Listener);
            ((ImageButton) findViewById(R.id.ib_pop_cancel)).setTag(this);
        }
    }

    private CommonNoticePopup(Context context, int theme, int nAction) {
        super(context, theme);
    }

    @Override
    public void cancel() {
        // TODO Auto-generated method stub
        super.cancel();
        m_nPrevAction = 10000;
    }

    @Override
    public void onDetachedFromWindow() {
        //
        super.onDetachedFromWindow();
    }

    public void setBodyAndTitleText(String a_Title, String a_Body) {
        TextView tv_pop_title = (TextView) findViewById(R.id.tv_pop_title);
        tv_pop_title.setText(a_Title);

        TextView titleTextview = (TextView) findViewById(R.id.tv_pop_body);
        titleTextview.setText(a_Body);
    }

    public void setBodyAndTitleText(String a_Title, String a_Body,String a_Body2) {
        TextView tv_pop_title = (TextView) findViewById(R.id.tv_pop_title);
        tv_pop_title.setText(a_Title);

        TextView titleTextview = (TextView) findViewById(R.id.tv_pop_body);
        titleTextview.setText(a_Body);

        TextView bodyTextview = (TextView) findViewById(R.id.tv_pop_body2);
        bodyTextview.setVisibility(View.VISIBLE);
        bodyTextview.setText(a_Body2);

        LinearLayout layoutCheckbox = (LinearLayout)findViewById(R.id.layout_checkbox);
        layoutCheckbox.setVisibility(View.VISIBLE);
    }

    public int getNetworkStatusCode()
    {
        return m_nHttpStatusCode;
    }

    public void setNetworkStatusCode(int a_nCode)
    {
        m_nHttpStatusCode = a_nCode;
    }
}
