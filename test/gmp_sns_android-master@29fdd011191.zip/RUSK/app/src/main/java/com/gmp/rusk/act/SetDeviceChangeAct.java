package com.gmp.rusk.act;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.db.DBBackup;
import com.gmp.rusk.dialog.BackupDlg;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.NetworkManager;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetBackUpCheckReq;
import com.gmp.rusk.request.PutBackUpFileUploadReq;
import com.gmp.rusk.response.GetBackUpCheckRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;

/**
 * SetDeviceChangeAct
 * @author kch
 * 기기변경 백업  Activity
 */

public class SetDeviceChangeAct extends CustomActivity implements OnClickListener{

	SharedPref pref;
	CommonPopup m_Popup = null;
	private BackupDlg m_Progress = null;
	
	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_set_devicechange);
		pref = SharedPref.getInstance(SetDeviceChangeAct.this);
		init();
	}
	
	private void init(){
		ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
		ivCancel.setOnClickListener(this);
		Button btn_DeviceChange = (Button) findViewById(R.id.btn_set_device_change);
		btn_DeviceChange.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.btn_set_device_change)
		{
			getBackUpCheck();
			
			
		} else if(nId == R.id.btn_cancel) {
			finish();
		}else if(nId== R.id.ib_pop_ok){
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if(popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_BACKUP){
				popup_ok.cancel();
				showProgress(getString(R.string.progress_now_backup));
				DataSyncTask task = new DataSyncTask();
				task.execute();
			} else {
				popup_ok.cancel();
			}
			
			
		} else if(nId == R.id.ib_pop_cancel) {
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			
		} else if(nId == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		}
		super.onClick(v);
	}

	private class DataSyncTask extends AsyncTask<Void, Void, String>
	{
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String strJson = DBBackup.makeJsonByte(SetDeviceChangeAct.this);
			CommonLog.e(PCClientAuthAct.class.getSimpleName(), "DB Backup Json : " + strJson);
			return strJson;
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			sendBackUpData(result);
		}
	}
	
	private void sendBackUpData(String a_strJson)
	{
		PutBackUpFileUploadReq req = new PutBackUpFileUploadReq();
		req.setSyncFileInfo(a_strJson.getBytes());
		WebAPI api = new WebAPI(this);
		api.requestUpload(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				//setAuthState(AUTHSTATE_COMPLETE);
				closeProgress();
				m_Popup = new CommonPopup(SetDeviceChangeAct.this, SetDeviceChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_set_backup_title), getString(R.string.popup_set_backup_complete));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				//setAuthState(AUTHSTATE_DATASYNCERROR);
				closeProgress();
				if(nErrorCode == ApiResult.HTTP_SERVER_BACKUP_FAIL){
					m_Popup = new CommonPopup(SetDeviceChangeAct.this, SetDeviceChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_set_backup_title), getString(R.string.popup_set_backup_fail_server));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonPopup(SetDeviceChangeAct.this, SetDeviceChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_set_backup_title), getString(R.string.popup_set_backup_fail_network));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
	private void getBackUpCheck()
	{
		GetBackUpCheckReq req = new GetBackUpCheckReq();
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetBackUpCheckRes res = new GetBackUpCheckRes(a_strData);
				
				if(!res.getResult().equals("true")){
					m_Popup = new CommonPopup(SetDeviceChangeAct.this, SetDeviceChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_BACKUP);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_set_backup_title), getString(R.string.popup_set_backup_first));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else{
					m_Popup = new CommonPopup(SetDeviceChangeAct.this, SetDeviceChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_BACKUP);
					m_Popup.setBodyAndTitleText(getString(R.string.popup_set_backup_title), getString(R.string.popup_set_backup_not_first));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
					
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				m_Popup = new CommonPopup(SetDeviceChangeAct.this, SetDeviceChangeAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_set_backup_title), strMessage);
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		});
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
	
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new BackupDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
