package com.gmp.rusk.request;

import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 *	@author kch
 *			모임 초대 수락
 *			method : put
 */

public class PutGroupInviteAcceptReq extends Req{

	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";


	public PutGroupInviteAcceptReq(int a_nGroupId, int a_nUserNo)
	{
		APINAME = APINAME +"/" + a_nGroupId + "/member/" + a_nUserNo;

	}

	public PutGroupInviteAcceptReq(int a_nGroupId, ArrayList<Integer> a_arrUserNo)
	{
		String strUserNo = "";
		int nUserNoSize = a_arrUserNo.size();
		for(int i = 0; i < nUserNoSize; i++)
		{
			strUserNo += a_arrUserNo.get(i);
			
			if(i < nUserNoSize - 1)
				strUserNo += ",";
		}
		
		APINAME = APINAME +"/" + a_nGroupId + "/member/" + strUserNo;

	}
	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub

			return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
