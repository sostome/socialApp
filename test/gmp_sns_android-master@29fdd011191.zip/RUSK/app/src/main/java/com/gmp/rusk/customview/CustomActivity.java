package com.gmp.rusk.customview;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.request.GetProvisioningReq;
import com.gmp.rusk.request.GetUserListReq;
import com.gmp.rusk.response.GetProvisioningRes;
import com.gmp.rusk.response.GetUserListRes;
import com.gmp.rusk.response.Res;
import com.jakewharton.processphoenix.ProcessPhoenix;
import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.IntroAct;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.GMPData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.datamodel.UserUpdateListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.gmp.AuthUtil;
import com.gmp.rusk.gmp.SimpleCrypto;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetEntryReq;
import com.gmp.rusk.response.GetEntryRes;
import com.gmp.rusk.service.XmppConnectionService;
import com.gmp.rusk.service.XmppConnectionService.LocalBinder;

import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class CustomActivity extends FragmentActivity implements OnClickListener {

	public MyApp App;
	private final String ENTRY_USERNO = "entry_userno";
	private final String ENTRY_TNAUSER = "entry_tnauser";
	private final String ENTRY_DEPARTMENTCODE = "entry_departmentcode";
	private final String ENTRY_IMAGEURLTEMPLATE = "entry_imageurltemplate";
	private final String ENTRY_PREVIEWIMAGEURLTEMPLATE = "entry_previewimageurltemplate";
	private final String ENTRY_LATESTVERSION = "entry_latestversion";
	private final String ENTRY_LOL = "entry_lol";
	private final String ENTRY_MOBILE = "entry_mobile";

	public final int RESULTCODE_NOTINVITED_SNSGROUP 		= -1000;

	public final int RESULTCODE_SNSGROUPPROFILE_AGREE 		= -2001;
	public final int RESULTCODE_SNSGROUPPROFILE_REJECT 		= -2002;

	public XmppConnectionService mService; // 연결 타입 서비스
//	public ChattingDBManagerService mChattingDBManagerService;
	public boolean mBound = false; // 서비스 연결 여부
//	public boolean mChattingDBManagerBound = false;

	private ConnectivityChangeBroadcastReceiver m_receiverConnChange = null;
	private KickMessageBroadcastReceiver m_kickmessageReceiver = null;

	public static final String ID_MDN = "MDN";
	public static final String ID_APP_ID = "APPID";
	public static final String ID_AUTH_KEY = "authKey";
	public static final String ID_COMPANY_CD = "companyCd";
	public static final String ID_ENC_PWD = "encPwd";

	public static final String TYPE_MOBILE = "mobile";
	public static final String TYPE_WIFI = "wifi";
	public static final String TYPE_DISCONNECT = "disconnect";

	SharedPref pref;
	private ArrayList<UserListData> m_arrAddedFellowListData = null;
	private String m_strTimeStamp = "";
	private CommonSubPopup m_Popup = null;
	private ProgressDlg m_Progress = null;

	// private boolean m_isFirstCon = false;

	protected boolean m_isListenLoginSuccess = false;
	public String m_strRoomID = "no_room";

	public boolean m_isRunning = false;
	public boolean m_isForeground = true;
	ConnectivityManager cManager;
	NetworkInfo mobile;
	NetworkInfo wifi;

	String m_strNetworkType;


	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		App = MyApp.getInstance();
		pref = SharedPref.getInstance(CustomActivity.this);
		App.m_arrActivitys.add(this);

		/*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Window window = getWindow();
			window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			window.setStatusBarColor(Color.parseColor("#d33700"));
		}*/

		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(StaticString.BROADCAST_KICK_RECEIVER);

		if (m_kickmessageReceiver == null) {
			m_kickmessageReceiver = new KickMessageBroadcastReceiver();
		}

		registerReceiver(m_kickmessageReceiver, intentFilter, StaticString.BROADCAST_PERMISSION_KICK, null);

		cManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		mobile = cManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		wifi = cManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

		if (mobile.isConnected()) {
			m_strNetworkType = TYPE_MOBILE;
		} else if (wifi.isConnected()) {
			m_strNetworkType = TYPE_WIFI;
		} else if (!mobile.isConnected() && !wifi.isConnected()) {
			m_strNetworkType = TYPE_DISCONNECT;
		}
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		CommonLog.e(getClass().getSimpleName(), "State : onSaveInstance");
//		outState.putInt(ENTRY_USERNO, App.m_EntryData.m_nUserNo);
//		outState.putBoolean(ENTRY_TNAUSER, App.m_EntryData.m_isTNaUser);
//		outState.putString(ENTRY_DEPARTMENTCODE, App.m_EntryData.m_strDepartmentCode);
//		outState.putString(ENTRY_IMAGEURLTEMPLATE, App.m_EntryData.m_strImageUrlTemplate);
//		outState.putString(ENTRY_PREVIEWIMAGEURLTEMPLATE, App.m_EntryData.m_strPreviewImageUrlTemplate);
//		outState.putString(ENTRY_LATESTVERSION, App.m_EntryData.m_strLatestVersion);
//		outState.putString(ENTRY_LOL, App.m_EntryData.m_strDepartmentCode);
//		outState.putString(ENTRY_MOBILE, App.m_EntryData.m_strMobile);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		CommonLog.e(getClass().getSimpleName(), "State : onRestoreInstance");
//		if(savedInstanceState != null){
//			CommonLog.e(getClass().getSimpleName(), "State : onRestoreInstance2");
//			App.m_EntryData = new EntryData(savedInstanceState.getInt(ENTRY_USERNO), savedInstanceState.getBoolean(ENTRY_TNAUSER), savedInstanceState.getString(ENTRY_DEPARTMENTCODE), savedInstanceState.getString(ENTRY_IMAGEURLTEMPLATE),
//					savedInstanceState.getString(ENTRY_PREVIEWIMAGEURLTEMPLATE), savedInstanceState.getString(ENTRY_LATESTVERSION), savedInstanceState.getString(ENTRY_LOL), savedInstanceState.getString(ENTRY_MOBILE));
//
//
//		}
		//if (App.m_arrFellowListData == null || App.m_GMPData == null || App.m_MyUserInfo == null) {
			//App.restartApplication(this);

			/*Intent launchIntent = new Intent(this, IntroAct.class);
			launchIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			launchIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
			launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			PendingIntent intent = PendingIntent.getActivity(getApplicationContext(), 0, launchIntent, 0);
			AlarmManager manager = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
			manager.set(AlarmManager.RTC, System.currentTimeMillis() + 100, intent);

			android.os.Process.killProcess(android.os.Process.myPid());*/
			Intent nextIntent = new Intent(this, IntroAct.class);
			ProcessPhoenix.triggerRebirth(this, nextIntent);
		//}
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		m_isRunning = true;
		/*if (App.m_arrFellowListData == null){
			Intent launchIntent = new Intent(this, IntroAct.class);
		      launchIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		      launchIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
		      launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		      PendingIntent intent = PendingIntent.getActivity(getApplicationContext(), 0, launchIntent , 0);
		      AlarmManager manager = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
		      manager.set(AlarmManager.RTC, System.currentTimeMillis() + 100, intent);

		      android.os.Process.killProcess(android.os.Process.myPid());
		}*/
		//	App.restartApplication(this);
		super.onResume();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
		closeProgress();
		App.m_arrActivitys.remove(this);
		if (m_kickmessageReceiver != null) {
			unregisterReceiver(m_kickmessageReceiver);
			m_kickmessageReceiver = null;
		}
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();

		doCheck();
	}

	private void doCheck(){
		// if (mService != null && !mService.isServiceAlive()) {
		// if (AppSetting.FEATURE_VARIANT.equals("R")) {
		// if (!AuthUtil.isLogin(CustomActivity.this, App.m_Mdn, App.m_AppID))
		// doGMPLogin();
		// else
		// new ReqVersionInfoTask().execute(null, null, null);
		// // new ReqGMPInfoTask().execute(null, null, null);
		// } else
		// requestEntry();
		//
		// } else {
		// if (App.m_EntryData == null || App.m_AesCrypto == null) {
		// if (AppSetting.FEATURE_VARIANT.equals("R")) {
		// if (!AuthUtil.isLogin(CustomActivity.this, App.m_Mdn, App.m_AppID))
		// doGMPLogin();
		// else
		// new ReqVersionInfoTask().execute(null, null, null);
		// // new ReqGMPInfoTask().execute(null, null, null);
		// } else
		// requestEntry();
		// } else {
		// Intent intent = new Intent(this, XmppConnectionService.class);
		// bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
		// }
		// }
		// 2014-12-02 dym Background 내린 후 톡톡 로그아웃시 톡톡 인증화면이 안나오는 이슈 때문에 수정

		//세션 만료가 되어 로그인 화면으로 넘어 갔을때, 재 로그인 하지 않은 상태로 다시 푸쉬를 눌러 진입하는 경우를 막기 위함
		if (pref.getStringPref(SharedPref.PREF_LOGIN_TIME, "0").equals("0")) {
			m_isRunning = true;
			m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
					PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.session_expire));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
		else if (AppSetting.FEATURE_VARIANT.equals("R")) {
			if (!AuthUtil.isLogin(CustomActivity.this, App.m_Mdn, App.m_AppID)){
				doGMPLogin();
			}
			else
			{
				if (App.m_EntryData == null){
					//new ReqVersionInfoTask().execute(null, null, null);
				}
				else
				{
					doSessionCheck();
				}
			}
			// new ReqGMPInfoTask().execute(null, null, null);
		}
		else
		{
			if (App.m_EntryData == null) {
				//requestEntry();
			}
			else {
				doSessionCheck();
			}
		}

		if(mService == null)
			CommonLog.e(getClass().getSimpleName(), "mService is Null");
		else
			CommonLog.e(getClass().getSimpleName(), "mService has Value");
		if(mService != null)
			CommonLog.e(getClass().getSimpleName(), "mService : " + mService.isServiceAlive());

//		if (mService == null || !mService.isServiceAlive()) {
//			CommonLog.e(getClass().getSimpleName(), "Activity Onstart Check");
		if (!App.isReturnedForgroud() && App.m_EntryData != null) {
			CommonLog.e(getClass().getSimpleName(), "onStart XMPP Bind");
			Intent intent = new Intent(this, XmppConnectionService.class);
			bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
		}
//		}

//		if(mChattingDBManagerService == null || mChattingDBManagerService.isServiceAlive())
//		{
//			Intent intent = new Intent(this, ChattingDBManagerService.class);
//			bindService(intent, mChttingDBManagerServiceConnection, Context.BIND_AUTO_CREATE);
//		}

		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);

		if (m_receiverConnChange == null) {
			m_receiverConnChange = new ConnectivityChangeBroadcastReceiver();
			// m_isFirstCon = true;
		}

		registerReceiver(m_receiverConnChange, intentFilter, StaticString.BROADCAST_PERMISSION_NETWORKCONNECTIVITYCHANGE, null);
	}
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
		if (mBound) {
			unbindService(mConnection);

			mBound = false;
		}

//		if(mChattingDBManagerBound)
//		{
//			unbindService(mChttingDBManagerServiceConnection);
//			mChattingDBManagerBound = false;
//		}

		if (m_receiverConnChange != null) {
			unregisterReceiver(m_receiverConnChange);
			m_receiverConnChange = null;
		}

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		CommonLog.e("", "customActivity....... click");

		if (v.getId() == R.id.ib_subpop_cancel) {
			CommonSubPopup popup_cancel = (CommonSubPopup)v.getTag();
			CommonLog.e("onClick", "CANCEL : " + v.getId());
			if (popup_cancel.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION) {
				popup_cancel.cancel();
				if (AppSetting.FEATURE_VARIANT.equals("R"))
					new ReqGMPInfoTask().execute(null, null, null);
				else {
					m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

					CommonLog.e(getClass(), "UserList DB update");
					requestUpdateUserList(m_strTimeStamp);
				}
			} else {
				popup_cancel.cancel();
				finish();
			}
		} else if (v.getId() == R.id.ib_subpop_ok) {
			CommonSubPopup popup_ok = (CommonSubPopup)v.getTag();
			CommonLog.e("onClick", "OK : " + v.getId());
			if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_HTTP_SERVER_UNAUTHORIZED) {
				popup_ok.cancel();
				App.allActivityDestroy();
			} else if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_APP_FINISH) {
				popup_ok.cancel();
				App.allActivityDestroy();
			} else if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION) {
				popup_ok.cancel();
				CommonLog.e("", "update..... gogo");
				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					// 버전 업데이트 처리
					try {

						Intent intent = new Intent("com.sk.pe.group.store.detail"); // GMP
																					// 스마트폰
																					// 스토어의
																					// 상세화면
						// Intent intent = new
						// Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿
						// 스토어의 상세화면

						intent.putExtra("APP_ID", App.m_AppID); // 대상 어플 아이디
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // Activity
																			// 남기지
																			// 않음
						startActivity(intent);
						App.allActivityDestroy();
					} catch (ActivityNotFoundException e) {
						Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
						startActivity(intent);
						App.allActivityDestroy();
					}
				} else {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
					startActivity(intent);
					App.allActivityDestroy();
				}
			} else {
				popup_ok.cancel();
			}

		} else if (v.getId() == R.id.ib_subpop_ok_long) {
			CommonSubPopup popup_ok_long = (CommonSubPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
				popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_APP_FINISH) {
				popup_ok_long.cancel();
				App.allActivityDestroy();
			} else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_FINISH) {
				popup_ok_long.cancel();
			}
			else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION) {
				popup_ok_long.cancel();
				CommonLog.e("", "update..... gogo");
				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					// 버전 업데이트 처리
					try {

						Intent intent = new Intent("com.sk.pe.group.store.detail"); // GMP
																					// 스마트폰
																					// 스토어의
																					// 상세화면
						// Intent intent = new
						// Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿
						// 스토어의 상세화면

						intent.putExtra("APP_ID", App.m_AppID); // 대상 어플 아이디
						intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // Activity
																			// 남기지
																			// 않음
						startActivity(intent);
						App.allActivityDestroy();
					} catch (ActivityNotFoundException e) {
						Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
						startActivity(intent);
						App.allActivityDestroy();
					}
				} else {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
					startActivity(intent);
					App.allActivityDestroy();
				}
			} else
				popup_ok_long.cancel();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

		if (requestCode == 1007) {
			AuthUtil.m_isRunGMPLogin = false;
			if (resultCode == Activity.RESULT_OK) {
				Toast.makeText(CustomActivity.this, "로그인 되었습니다", Toast.LENGTH_SHORT).show();
				new ReqVersionInfoTask().execute(null, null, null);
				// new ReqGMPInfoTask().execute(null, null, null);

			} else {
				finish();
			}
		} else if (requestCode == StaticString.REQUESTCODE_REGULARLOGIN) {
			if (resultCode == Activity.RESULT_OK) {
				doUserListSync();
			} else if (resultCode == Activity.RESULT_CANCELED) {
				finish();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/*
	 * 사용자 목록 조회 및 Update
	 */

	private void doUserListSync() {
		SharedPref pref = SharedPref.getInstance(CustomActivity.this);
		if (!AppSetting.FEATURE_VARIANT.equals("R")) {
			int nUpdateType = Utils.CheckVersion(CustomActivity.this, App.m_EntryData.m_strLatestVersion);
			if (nUpdateType == 1) {
				m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
						PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			} else if (nUpdateType == 2) {
				if (!pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(App.m_EntryData.m_strLatestVersion)) {
					pref.setStringPref(SharedPref.PREF_GMP_VERSION, App.m_EntryData.m_strLatestVersion);
					m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO,
							PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.update_version).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}
		}

		m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

		CommonLog.e(getClass(), "UserList DB update");
		requestUpdateUserList(m_strTimeStamp);
	}

	/*
	 * GMPLogin
	 */
	private void doGMPLogin() {

		// GMP 인증
		if (!AuthUtil.isLogin(CustomActivity.this, App.m_Mdn, App.m_AppID)) {
			AuthUtil.runGMPLogin(CustomActivity.this);
		} else {
			requestEntry();
		}
	}

	private class ReqGMPInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			try {
				Map<String, String> map = new HashMap<String, String>();

				CommonLog.e(getClass(), "CustomActivity getGMPAuthPwd start");
				map = AuthUtil.getAuthInfo(CustomActivity.this, App.m_Mdn, App.m_AppID);

				CommonLog.e(getClass(), "CustomActivity getGMPAuthPwd end");
				// String secretkeydecrypt = null;
				strResultCode = map.get("result_code");
				if (strResultCode.equals("1000")) { // 정상 처리일 경우정상 처리 코드 넣어주시기
													// 바랍니다.
					CommonLog.e(getClass(), "result_code : 1000");
					String strRegularID = "";
					String secretkey = AuthUtil.getSecretKey(CustomActivity.this); // 비밀키
																					// 얻어오기
					try {
						strRegularID = SimpleCrypto.decrypt(secretkey, map.get("result_user_num")); // 복호화
					} catch (Exception e) {
						Log.e("TnaMoblieDecrypt", "error");
						Log.e("TnaMoblieDecrypt", "secretkey = " + secretkey);
						Log.e("TnaMoblieDecrypt", "ServerEmpId = " + map.get("result_user_num"));
						strRegularID = "-2"; // 복호화 실패시 아이디 값에 넣어줌
					}

					App.m_GMPData = new GMPData(map.get(ID_COMPANY_CD), strRegularID, map.get(ID_AUTH_KEY), map.get(ID_ENC_PWD));

				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (result.equals("1000"))
				requestEntry();
			else if (result.equals("7009")) {
				try {
					AuthUtil.logout(CustomActivity.this);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					doGMPLogin();
				}
			} else if (result.equals("3205")) {
				m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
						PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}

	private class ReqVersionInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		String strAppVersion = "";

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub

			try {
				Map<String, String> map = new HashMap<String, String>();

				CommonLog.e(getClass(), "getVersionInfo start");
				map = AuthUtil.getVersionInfo(CustomActivity.this, App.m_Mdn, App.m_AppID);

				CommonLog.e(getClass(), "getVersionInfo end");
				// String secretkeydecrypt = null;
				strResultCode = map.get("result");
				if (strResultCode.equals("1000")) { // 정상 처리일 경우정상 처리 코드 넣어주시기
													// 바랍니다.
					CommonLog.e(getClass(), "result : 1000");
					strAppVersion = map.get("appVer");
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (result.equals("1000")) {
				if (strAppVersion.equals("")) {
					new ReqGMPInfoTask().execute(null, null, null);
				} else {
					SharedPref pref = SharedPref.getInstance(CustomActivity.this);
					int nUpdateType = Utils.CheckVersion(CustomActivity.this, strAppVersion);
					if (nUpdateType == 2 && !pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(strAppVersion)) {
						pref.setStringPref(SharedPref.PREF_GMP_VERSION, strAppVersion);
						m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO,
								PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.update_version).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					} else {
						new ReqGMPInfoTask().execute(null, null, null);
					}
				}
			} else if (result.equals("7009")) {
				try {
					AuthUtil.logout(CustomActivity.this);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					doGMPLogin();
				}
			} else if (result.equals("3205")) {
				m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
						PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
						PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}

	public void requestEntry() {
		// showProgress(getString(R.string.progress_entry).toString());
		GetProvisioningReq req = new GetProvisioningReq();

		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {

			}

			@Override
			public void onPostRequest(String a_strData) {
				GetProvisioningRes res = new GetProvisioningRes(a_strData, Res.RES_TYPE_USER_COMPANY);
				App.m_EntryData.m_strImageUrlTemplate = res.getUserImageUrlTemplate();
				App.m_EntryData.m_strPreviewImageUrlTemplate = res.getUserPreviewImageUrlTemplate();
				App.m_EntryData.m_arrCompanyData = res.getCompanies();

				requestEntryStep2();

			}
		});

	}

	public void requestEntryStep2(){
		GetEntryReq req = new GetEntryReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetEntryRes res = new GetEntryRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				/*App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate,
						res.m_strPreviewImageUrlTemplate,res.m_strEmoticonTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);*/
				App.m_MyUserInfo = res.getEntryUserData(getApplicationContext());
				// closeProgress();
				doUserListSync();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// closeProgress();
				// TODO Auto-generated method stub
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	public void requestUpdateUserList(String a_strTimeStamp) {
		// showProgress(getString(R.string.progress_getfellowlist));
		GetUserListReq req = new GetUserListReq(a_strTimeStamp);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);

				if (res.getUserListData() != null) {

					SparseArray<UserListData> savedUserListData = ContactsDBManager.getContactsReturnSparseArray(CustomActivity.this);
					ArrayList<UserListData> arrInsertUserListData = new ArrayList<UserListData>();
					ArrayList<UserListData> arrUpdateUserListData = new ArrayList<UserListData>();
					
					for (UserListData data : res.getUserListData()) {
//						UserListData getitem = ContactsDBManager.getContacts(CustomActivity.this, data.m_nUserNo);
						UserListData getitem = savedUserListData.get(data.m_nUserNo);
						if (getitem == null) {
							UserListData item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable,
									data.m_isActive, data.m_strGreeting, data.m_strUserStatus, false, "");
//							ContactsDBManager.insertContacts(CustomActivity.this, item);
							arrInsertUserListData.add(item);
						} else {
							UserListData item = null;
							if (data.m_strUserStatus.equals("A"))
								item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, getitem.m_strFellowAddTime);
							else
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, "");
//							ContactsDBManager.updateContacts(CustomActivity.this, item);
							arrUpdateUserListData.add(item);
						}
					}
					
					if(arrInsertUserListData.size() > 0 )
						ContactsDBManager.insertContacts(CustomActivity.this, arrInsertUserListData);
					if(arrUpdateUserListData.size() > 0 )
						ContactsDBManager.updateContacts(CustomActivity.this, arrUpdateUserListData);
					
					App.m_isChangeFellow = true;
				}
				pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);

				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					if (mBound) {
						CommonLog.e(getClass().getSimpleName(), "mService : Login and Unbind");
						unbindService(mConnection);

						mBound = false;
					}
					Intent intent = new Intent(CustomActivity.this, XmppConnectionService.class);
					bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
					if (m_isListenLoginSuccess)
						onLoginSuccess();
				}
				// closeProgress();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				// closeProgress();
				// if (m_Popup.m_nPrevAction ==
				// PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE) {
				// m_Popup.cancel();
				// App.expirePartnerLogin(CustomActivity.this);
				// }
				if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					if (mBound) {
						CommonLog.e(getClass().getSimpleName(), "mService : Login and Unbind");
						unbindService(mConnection);

						mBound = false;
					}
					Intent intent = new Intent(CustomActivity.this, XmppConnectionService.class);
					bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
					if (m_isListenLoginSuccess)
						onLoginSuccess();
				}
			}
		});
	}

	private ArrayList<FellowListData> setFellowList() throws Exception {
		m_arrAddedFellowListData = TTalkDBManager.ContactsDBManager.getContactsByFellows(this);
		App.m_arrFellowListData = new ArrayList<FellowListData>();
		//CommonLog.e("", "setFellowList() lol : " + App.m_EntryData.m_strLol);
		for (UserListData data : m_arrAddedFellowListData) {
			HashMap<String, String> personalData = data.m_PersonalData.mapPersonalData;
			if (data.m_strUserType.equals("R")) {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
						personalData.get(PersonalData.CHARGE), data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			} else {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
						data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			}
		}

		return App.m_arrFellowListData;
	}

	public void doBindXmppSerivce(){
		if (mBound) {
			CommonLog.e(getClass().getSimpleName(), "mService : Login and Unbind");
			unbindService(mConnection);

			mBound = false;
		}

		Intent intent = new Intent(CustomActivity.this, XmppConnectionService.class);
		bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

	public ServiceConnection mConnection = new ServiceConnection() {

		@Override
		public void onServiceDisconnected(ComponentName arg0) {
			CommonLog.e(CustomActivity.this, "onServiceDisconnected");
			mBound = false;
			onXMPPServiceDisConnected();

		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			CommonLog.e(CustomActivity.this, "onServiceConnected");
			LocalBinder binder = (LocalBinder) service;
			mService = binder.getService();
			// mService.addPacketListener(mPacketListener);
			// mService.addGroupPacketListener(mPacketListener);
			mBound = true;
			onXMPPServiceConnected();

		}
	};
	
//	public ServiceConnection mChttingDBManagerServiceConnection = new ServiceConnection() {
//
//		@Override
//		public void onServiceDisconnected(ComponentName arg0) {
//			mChattingDBManagerBound = false;
//		}
//
//		@Override
//		public void onServiceConnected(ComponentName name, IBinder service) {
//			// TODO Auto-generated method stub
//			ChattingDBManagerService.LocalBinder binder = (ChattingDBManagerService.LocalBinder) service;
//			mChattingDBManagerService = binder.getService();
//			mChattingDBManagerBound = true;
//
//		}
//	};

	protected void onXMPPServiceConnected() {

	}

	protected void onXMPPServiceDisConnected() {

	}

	protected void onNetworkChange() {
		
	}

	protected void onLoginSuccess() {

	}

	public class ConnectivityChangeBroadcastReceiver extends BroadcastReceiver {
		String strAction;

		Context m_Context;

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			cManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
			mobile = cManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
			wifi = cManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

			strAction = intent.getAction();
			CommonLog.e(CustomActivity.class.getSimpleName(), "Action : " + strAction);

			if (strAction.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {

				if (wifi.isConnected()) {
					if (m_strNetworkType == TYPE_DISCONNECT) {
						CommonLog.e(CustomActivity.class.getSimpleName(), "Connected");
						if (mService != null)
							mService.setConnect();
						onNetworkChange();
						m_strNetworkType = TYPE_WIFI;
					} else if (m_strNetworkType == TYPE_MOBILE) {
						CommonLog.e(CustomActivity.class.getSimpleName(), "Change Network Type");
						if (mService != null) {
							mService.setTaskNull();
							mService.setConnect();
						}
						onNetworkChange();
						m_strNetworkType = TYPE_WIFI;
					} else if (m_strNetworkType == TYPE_WIFI) {
						CommonLog.e(CustomActivity.class.getSimpleName(), "Same Network Type");
					}
				} else if (mobile.isConnected()) {
					if (m_strNetworkType == TYPE_DISCONNECT) {
						CommonLog.e(CustomActivity.class.getSimpleName(), "Connected");
						if (mService != null)
							mService.setConnect();
						onNetworkChange();
						m_strNetworkType = TYPE_MOBILE;
					} else if (m_strNetworkType == TYPE_WIFI) {
						CommonLog.e(CustomActivity.class.getSimpleName(), "Change Network Type");
						if (mService != null) {
							mService.setTaskNull();
							mService.setConnect();
						}
						onNetworkChange();
						m_strNetworkType = TYPE_MOBILE;
					} else if (m_strNetworkType == TYPE_MOBILE) {
						CommonLog.e(CustomActivity.class.getSimpleName(), "Same Network Type");
					}
				} else if (!wifi.isConnected() && !mobile.isConnected()) {
					CommonLog.e(CustomActivity.class.getSimpleName(), "Network Disconnect");
					if (mService != null)
						mService.setTaskNull();

					m_strNetworkType = TYPE_DISCONNECT;
				}

				// if (mobile.isConnected() || wifi.isConnected()) {
				// // if (mobile.isConnected()) {
				// // CommonLog.e(CustomActivity.class.getSimpleName(), "모바일");
				// // } else if (wifi.isConnected()) {
				// // CommonLog.e(CustomActivity.class.getSimpleName(), "와이파이");
				// //
				// // } else {
				// // CommonLog.e(CustomActivity.class.getSimpleName(),
				// "이건 뭐지?");
				// // }
				//
				// if (m_isFirstCon) {
				// CommonLog.e(CustomActivity.class.getSimpleName(), "Ignore");
				// m_isFirstCon = false;
				// } else {
				// m_isFirstCon = true;
				//
				// CommonLog.e(CustomActivity.class.getSimpleName(),
				// "Connected");
				// mService.setConnect();
				//
				// }
				//
				// } else {
				// mService.setTaskNull();
				// m_isFirstCon = false;
				// }
				//
			}

		}
	}

	public class KickMessageBroadcastReceiver extends BroadcastReceiver {

		String strAction;

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			strAction = intent.getAction();

			if (strAction.equals(StaticString.BROADCAST_KICK_RECEIVER)) {
				Bundle bundle = intent.getExtras();
				if (bundle != null)
					onKick(bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID_KICK));
			}
		}

	}

	protected void onKick(String a_strRoomId) {
		if (m_strRoomID.equals(a_strRoomId)) {
			finish();
		}
	}

	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}
	
	private void doSessionCheck(){
		String prefTime = pref.getStringPref(SharedPref.PREF_LOGIN_TIME, "0");
		//String prefTime = "2015031702";
		String day = "";
		String hour = "";
		if(prefTime.length() > 7)
			day = prefTime.substring(0,8);
		if(prefTime.length() > 9)
			hour = prefTime.substring(8,10);
		String formatDate = new String("yyyyMMdd");
		String formatTime = new String("HH");

		SimpleDateFormat sdf = new SimpleDateFormat(formatDate, Locale.KOREA);
		SimpleDateFormat sdfH = new SimpleDateFormat(formatTime, Locale.KOREA);
		long nowTime = Long.parseLong(sdf.format(new Date()));
		long nowHour = Long.parseLong(sdfH.format(new Date()));
		long beforeTime = Long.parseLong(day);
		long beforeHour = Long.parseLong(hour);
		
		CommonLog.e(getClass().getSimpleName(), "Now Time : " + nowTime);
		CommonLog.e(getClass().getSimpleName(), "Now Hour : " + nowHour);
		CommonLog.e(getClass().getSimpleName(), "Before Time : " + beforeTime);
		CommonLog.e(getClass().getSimpleName(), "Before Hour : " + beforeHour);
		if(App.isReturnedForgroud() || (nowHour >= 3 && beforeHour < 3) || nowTime > beforeTime){
			CommonLog.e(getClass().getSimpleName(), "Start Request Entry!!!");

			if (AppSetting.FEATURE_VARIANT.equals("R")) {
				new ReqVersionInfoTask().execute(null, null, null);
			}
			else
			{
				requestEntry();
			}
		}	
	}
	
	private OnClickListener m_onClickSessionListener = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			CommonSubPopup popup = (CommonSubPopup)v.getTag();
			popup.cancel();
			App.expirePartnerLogin(CustomActivity.this);
		}
	};
	
	private OnClickListener m_onClickChangeDeviceListener = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			CommonSubPopup popup = (CommonSubPopup)v.getTag();
			popup.cancel();
			App.initPartnerLogin(CustomActivity.this);
		}
	};
	private OnClickListener m_onClickDisconnectListener = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			CommonSubPopup popup = (CommonSubPopup)v.getTag();
			popup.cancel();
		}
	};
	private OnClickListener m_onClickFinishListener = new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			CommonSubPopup popup = (CommonSubPopup)v.getTag();
			popup.cancel();
			//App.allActivityDestroy();
		}
	};
	public void showErrorPopup(int a_nErrorCode, String a_strMessage){

		if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
			m_Popup = new CommonSubPopup(CustomActivity.this, m_onClickSessionListener, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
					PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
			m_Popup = new CommonSubPopup(CustomActivity.this, CustomActivity.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
			m_Popup.setCancelable(false);
			m_Popup.show();
		} else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
			m_Popup = new CommonSubPopup(CustomActivity.this, m_onClickChangeDeviceListener, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
					PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		} else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
			m_Popup = new CommonSubPopup(CustomActivity.this, m_onClickDisconnectListener, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 
					PopupIndex.INDEX_PREVPOPUP_FINISH);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(),getString(R.string.network_bad).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
		else {
			m_Popup = new CommonSubPopup(CustomActivity.this, m_onClickFinishListener, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
					PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	}
}