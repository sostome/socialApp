package com.gmp.rusk.fragment;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.SNSGroupMemeberInviteAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.datamodel.ChatRoomListData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.layout.SNSInviteChatMemberListItemLayout;
import com.gmp.rusk.listview.SectionListAdapter;
import com.gmp.rusk.listview.SectionListItem;
import com.gmp.rusk.listview.SectionListView;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import me.thanel.swipeactionview.SwipeActionView;
import me.thanel.swipeactionview.SwipeDirection;

public class SNSInviteChatRoomListFlag extends Fragment implements OnClickListener, OnCheckedChangeListener, OnTouchListener {

	public MyApp App = MyApp.getInstance();
	private FragmentActivity m_Activity = null;
	private SectionListView m_ListView;
	private ListView m_MemberList;
	private FrameLayout m_FrameList;
	private LinearLayout m_LayoutMemberList;

	ChatListAdapter m_ChatAdapter;

	SectionListAdapter m_SectionListAdapter = null;
	MemberListAdapter m_MemberListAdapter = null;
	CommonPopup m_Popup;
//	int m_nPopupType;
	public boolean m_isRunning = false;
	public boolean m_isFirstView = true;
	ArrayList<ChatRoomListData> m_arrChatRoomListData = null;
	HashMap<String, ChatRoomListData> mapChatRoomListData = null;

	private SectionListItem item = null;
	private ArrayList<SectionListItem> m_SectionListItems = null;

	ArrayList<ChatRoomListData> sortListData;
	View m_vList;
	int m_nVisibleNumber = 0;

	int m_nFavoriteCount = 0;
	int m_nNormalCount = 0;

	boolean m_isNowOnInit = false;

	private ArrayList<UserListData> m_ListItems = null;

	CheckBox m_cbAllcheck;

	TextView m_tvSectionText;

	// 사용자가 눌러서 터치를 한것인지, 앱에서 판단해서 체크하는지
	boolean m_isTouchCheckBox = false;

	ArrayList<Integer> m_arrUserNumbers;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		m_arrChatRoomListData = new ArrayList<ChatRoomListData>();
		mapChatRoomListData = new HashMap<String, ChatRoomListData>();
		App.m_arrDepartmentUserListData = null;
		m_Activity = getActivity();

	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		if(m_MemberListAdapter != null)
			m_MemberListAdapter.notifyDataSetChanged();
		if(m_ChatAdapter != null)
			m_ChatAdapter.notifyDataSetChanged();
		super.onResume();
		m_isRunning = true;

		// init();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		m_vList = inflater.inflate(R.layout.fragact_chat_list, container, false);
		m_arrUserNumbers = ((SNSGroupMemeberInviteAct) m_Activity).getUserNumbers();
		((SNSGroupMemeberInviteAct) m_Activity).setNotifyListener(m_NotifyListner);
		// onCreateView에서 그려야지만 리스트뷰의 위치가 유지된다. 어째서 일까.
		RelativeLayout layotSearch = (RelativeLayout) m_vList.findViewById(R.id.layout_chat_room_search);
		layotSearch.setVisibility(View.GONE);
		App.m_arrSearchListCheckData = new ArrayList<>();
		if (m_isFirstView) {
			sortListData = firstDataSort();
			firstFavoriteInit(sortListData);
			firstInit(sortListData);
		} else {
			m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);
			m_MemberList = (ListView) m_vList.findViewById(R.id.lv_chat_list_member);
			m_FrameList = (FrameLayout) m_vList.findViewById(R.id.layout_chat_list);
			m_LayoutMemberList = (LinearLayout) m_vList.findViewById(R.id.layout_member_list);
			m_ListItems = new ArrayList<UserListData>();
			m_cbAllcheck = (CheckBox) m_vList.findViewById(R.id.cb_sns_allmember);
			m_cbAllcheck.setOnCheckedChangeListener(this);
			m_cbAllcheck.setOnTouchListener(this);
			m_tvSectionText = (TextView) m_vList.findViewById(R.id.tv_sectiontext);

			m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);

			m_ListView.setAdapter(m_SectionListAdapter);
		}
		return m_vList;
	}

	public ArrayList<ChatRoomListData> firstDataSort() {

		m_isNowOnInit = true;
		m_nFavoriteCount = 0;
		m_nNormalCount = 0;
		if (m_SectionListItems == null)
			m_SectionListItems = new ArrayList<SectionListItem>();

		ArrayList<ChatRoomListData> data = new ArrayList<ChatRoomListData>();
		ArrayList<ChattingRoomInfoData> roomInfoData = RoomDBManager.getChattingRoom(m_Activity);
		for (int i = 0; i < roomInfoData.size(); i++) {

			ChatRoomListData chattingRoomInfoData = getLastMessage(roomInfoData.get(i));
			if (chattingRoomInfoData == null) {
				CommonLog.e(MainChatListFlag.class.getSimpleName(), "chattingRoomInfoData is null!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				for (int j = 0; j < 5; j++) {
					chattingRoomInfoData = getLastMessage(roomInfoData.get(i));
					if (chattingRoomInfoData != null)
						break;
				}
			}
			
			if(chattingRoomInfoData != null){
				if(!chattingRoomInfoData.getRoomID().equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))){
					if (chattingRoomInfoData.getFavorite()) {
						m_nFavoriteCount += 1;
					} else {
						m_nNormalCount += 1;
					}
			
					data.add(chattingRoomInfoData);
				}
			}
		}

		// m_ChatAdapter.clear();

		return sortFellowListData(data);
	}

	public void firstFavoriteInit(ArrayList<ChatRoomListData> data) {
		m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);
		m_MemberList = (ListView) m_vList.findViewById(R.id.lv_chat_list_member);
		m_FrameList = (FrameLayout) m_vList.findViewById(R.id.layout_chat_list);
		m_LayoutMemberList = (LinearLayout) m_vList.findViewById(R.id.layout_member_list);
		m_ListItems = new ArrayList<UserListData>();
		m_cbAllcheck = (CheckBox) m_vList.findViewById(R.id.cb_sns_allmember);
		m_cbAllcheck.setOnCheckedChangeListener(this);
		m_cbAllcheck.setOnTouchListener(this);
		m_tvSectionText = (TextView) m_vList.findViewById(R.id.tv_sectiontext);
		m_SectionListItems.clear();
		m_arrChatRoomListData.clear();
		mapChatRoomListData.clear();
		for (int j = data.size() - 1; j >= 0; j--) {
			ChatRoomListData roomListData = data.get(j);
			if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
				RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
			} else {

				if (roomListData.getFavorite()) {
					item = new SectionListItem(roomListData, getString(R.string.chat_favorite) + " " + m_nFavoriteCount);
					m_SectionListItems.add(item);

					// m_ChatAdapter.add(roomListData);
					m_arrChatRoomListData.add(roomListData);
					mapChatRoomListData.put(roomListData.getRoomID(), roomListData);
				}
			}

		}

	}

	public void firstInit(ArrayList<ChatRoomListData> data) {

		for (int j = data.size() - 1; j >= 0; j--) {
			ChatRoomListData roomListData = data.get(j);
			if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
				RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
			} else {
				if (!roomListData.getFavorite()) {
					item = new SectionListItem(roomListData, getString(R.string.chat_roomlist) + " " + m_nNormalCount);
					m_SectionListItems.add(item);

					// m_ChatAdapter.add(roomListData);
					m_arrChatRoomListData.add(roomListData);
					mapChatRoomListData.put(roomListData.getRoomID(), roomListData);
				}
			}

		}

		m_isFirstView = false;

		m_ChatAdapter = new ChatListAdapter(m_Activity);
		m_ChatAdapter.areAllItemsEnabled();
		m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);

		m_ListView.setAdapter(m_SectionListAdapter);

		m_ListView.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				m_nVisibleNumber = firstVisibleItem;
				if (m_SectionListAdapter != null)
					m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
			}
		});
		m_isNowOnInit = false;

	}

	private ArrayList<ChatRoomListData> sortFellowListData(ArrayList<ChatRoomListData> a_Data) {

		Collections.sort(a_Data, myComparator);

		ArrayList<ChatRoomListData> roomData = new ArrayList<ChatRoomListData>();

		for (ChatRoomListData data : a_Data)
			roomData.add(data);

		return roomData;
	}

	private ChatRoomListData getLastMessage(final ChattingRoomInfoData data) {

		// GetLastMessageThread thread = new GetLastMessageThread(data);
		// thread.start();
		// try {
		// thread.join();
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// CommonLog.e(MainChatListFlag.class.getSimpleName(),
		// "GetLastMessageThread InterruptedException!!!!!!!!!!");
		// e.printStackTrace();
		// }
		//
		// return thread.getResultData();

		ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
		chattingDBMng.openReadable(data.m_strRoomId);
		// ArrayList<ChattingMessageData> arrChattingMessageData =
		// chattingDBMng.getChattingMessage();

		ChattingMessageData lastMessage = chattingDBMng.getCurrentMessage();
		ChatRoomListData roomData = null;
		if (lastMessage == null) {
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				roomData = new ChatRoomListData(data.m_strRoomId, crypto.decrypt(data.m_strRoomTitle), 0, "", 0, chattingDBMng.getNoReadMessageCount(),
						data.m_nRoomOwnerId, data.m_isAlarmOn, 2, data.m_isFavorite,data.m_backgroundColor, data.m_isTitleEdited);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			chattingDBMng.close();
			return roomData;
		} else {
			// ChattingMessageData lastMessage =
			// arrChattingMessageData.get(arrChattingMessageData.size() - 1);
			String text = null;
			if (lastMessage.m_nMsgType == StaticString.CHAT_ROOM_MY_FILE || lastMessage.m_nMsgType == StaticString.CHAT_ROOM_OTHER_FILE) {
				// 파일 이름과 클라우드 파일 이름이 상관없이 무조건 '파일', '클라우드'로 변경하기 위함
				try {
					JSONObject jsonObject = new JSONObject(lastMessage.m_strMsgText);

					if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO))
						text = getString(R.string.chatlist_movie);
					else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL))
						text = getString(R.string.chatlist_file);
					else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT))
						text = getString(R.string.chatlist_contact);
				} catch (JSONException e) {
					e.printStackTrace();
				}

			} else if (lastMessage.m_nMsgType == StaticString.CHAT_ROOM_MY_IMAGE || lastMessage.m_nMsgType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
				text = getString(R.string.chatlist_image);
			} else {
				text = lastMessage.m_strMsgText;
			}
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				roomData = new ChatRoomListData(data.m_strRoomId, crypto.decrypt(data.m_strRoomTitle), lastMessage.m_nMsgType, text,
						lastMessage.m_lnMsgSendTime, chattingDBMng.getNoReadMessageCount(), data.m_nRoomOwnerId, data.m_isAlarmOn, lastMessage.m_nSendStatus,
						data.m_isFavorite,data.m_backgroundColor, data.m_isTitleEdited);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			chattingDBMng.close();
			return roomData;
		}

	}

	public class GetLastMessageThread extends Thread {
		ChatRoomListData resultData = null;
		ChattingRoomInfoData infoData = null;

		public GetLastMessageThread() {

		}

		public GetLastMessageThread(ChattingRoomInfoData data) {
			infoData = data;
		}

		public void setResultData(ChatRoomListData result) {
			resultData = result;
		}

		public ChatRoomListData getResultData() {
			return resultData;
		}

		public void run() {
			ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
			chattingDBMng.openReadable(infoData.m_strRoomId);
			ArrayList<ChattingMessageData> arrChattingMessageData = chattingDBMng.getChattingMessage();

			ChatRoomListData roomData = null;
			if (arrChattingMessageData.isEmpty()) {
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					roomData = new ChatRoomListData(infoData.m_strRoomId, crypto.decrypt(infoData.m_strRoomTitle), 0, "", 0,
							chattingDBMng.getNoReadMessageCount(), infoData.m_nRoomOwnerId, infoData.m_isAlarmOn, 2, infoData.m_isFavorite,infoData.m_backgroundColor, infoData.m_isTitleEdited);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				chattingDBMng.close();
				setResultData(roomData);
			} else {
				ChattingMessageData lastMessage = arrChattingMessageData.get(arrChattingMessageData.size() - 1);
				String text = null;
				if (lastMessage.m_nMsgType == StaticString.CHAT_ROOM_MY_FILE || lastMessage.m_nMsgType == StaticString.CHAT_ROOM_OTHER_FILE) {
					// 파일 이름과 클라우드 파일 이름이 상관없이 무조건 '파일', '클라우드'로 변경하기 위함
					try {
						JSONObject jsonObject = new JSONObject(lastMessage.m_strMsgText);

						if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO))
							text = getString(R.string.chatlist_movie);
						else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL))
							text = getString(R.string.chatlist_file);
						else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT))
							text = getString(R.string.chatlist_contact);
					} catch (JSONException e) {
						e.printStackTrace();
					}

				} else if (lastMessage.m_nMsgType == StaticString.CHAT_ROOM_MY_IMAGE || lastMessage.m_nMsgType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
					text = getString(R.string.chatlist_image);
				} else {
					text = lastMessage.m_strMsgText;
				}
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					roomData = new ChatRoomListData(infoData.m_strRoomId, crypto.decrypt(infoData.m_strRoomTitle), lastMessage.m_nMsgType, text,
							lastMessage.m_lnMsgSendTime, chattingDBMng.getNoReadMessageCount(), infoData.m_nRoomOwnerId, infoData.m_isAlarmOn,
							lastMessage.m_nSendStatus, infoData.m_isFavorite,infoData.m_backgroundColor, infoData.m_isTitleEdited);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				chattingDBMng.close();
				setResultData(roomData);
			}
		}

	}

	public class ViewHolder {
		public TextView m_tvListName, m_tvListMessage, m_tvListUserCount,m_tvNoSee;
		public ImageView m_ivprofile_pic, m_ivIcon, m_ivNotFellow_pic,m_iv_profile_pic_frame,m_iv_partner_icon;
		public CheckBox m_checkBox;
		public LinearLayout layout;
		public SwipeActionView m_layoutSwipe;
	}

	public class ChatListAdapter extends BaseAdapter {

		Context m_Context;
		LayoutInflater m_Inflater;
		ChatRoomListData m_Data;
		int m_nPosition;
		// TextView m_tvListName, m_tvListMessage, m_tvListNosee,
		// m_tvListMessageTime, m_tvListUserCount;
		// ImageView m_ivprofile_pic, m_ivIcon, m_ivAlarm, m_ivStatus;
		// ImageButton m_btnExit;

		ViewHolder viewHolder;

		public ChatListAdapter(Context context) {

			m_Context = context;
			// m_Inflater = LayoutInflater.from(context);
			m_Inflater = (LayoutInflater) m_Activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			// TODO Auto-generated constructor stub
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			m_Data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
			// m_Data = getItem(position);

			if (convertView == null) {
				viewHolder = new ViewHolder();
				convertView = m_Inflater.inflate(R.layout.layout_chat_listitem, parent, false);
				viewHolder.m_layoutSwipe = (SwipeActionView) convertView.findViewById(R.id.layout_chat_swipe);
				viewHolder.layout = (LinearLayout) convertView.findViewById(R.id.layout_chat_listitem);
				viewHolder.m_tvListName = (TextView) convertView.findViewById(R.id.tv_chatlist_name);
				viewHolder.m_tvListMessage = (TextView) convertView.findViewById(R.id.tv_chatlist_chat);
				viewHolder.m_ivprofile_pic = (ImageView) convertView.findViewById(R.id.iv_profile_pic);
				viewHolder.m_iv_profile_pic_frame = (ImageView) convertView.findViewById(R.id.iv_profile_pic_frame);
				viewHolder.m_iv_partner_icon = (ImageView) convertView.findViewById(R.id.iv_chatlist_icon_partner);
				viewHolder.m_tvListUserCount = (TextView) convertView.findViewById(R.id.tv_profile_num);
				viewHolder.m_ivIcon = (ImageView) convertView.findViewById(R.id.iv_chatlist_icon);
				viewHolder.m_tvNoSee = (TextView) convertView.findViewById(R.id.tv_chatlist_nosee);
			/*	viewHolder.m_checkBox = (CheckBox) convertView.findViewById(R.id.cb_invite);
				viewHolder.m_checkBox.setVisibility(View.GONE);*/
				convertView.setTag(viewHolder);
			} else {
				viewHolder = (ViewHolder) convertView.getTag();
			}
			if (m_Data != null) {
				viewHolder.m_tvNoSee.setVisibility(View.GONE);
				viewHolder.m_layoutSwipe.setDirectionEnabled(SwipeDirection.Left, false);
				viewHolder.m_layoutSwipe.setDirectionEnabled(SwipeDirection.Right, false);
				if (m_Data.getRoomID().length() > 8) {
					ChattingDBManager chattingDBMng = new ChattingDBManager(m_Context);
					chattingDBMng.openReadable(m_Data.getRoomID());
					ArrayList<Integer> arrUserNo = chattingDBMng.getChattingUser();
					chattingDBMng.close();
					viewHolder.m_tvListUserCount.setVisibility(View.VISIBLE);
					viewHolder.m_tvListUserCount.setText("" + arrUserNo.size());
					UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_Data.getOwnerID());
					if (userData != null && userData.m_isImageAvailable) {
						App.imageloader.cancelDownload(viewHolder.m_ivprofile_pic);

						App.imageloader.getProfileImage(viewHolder.m_ivprofile_pic, App.getImageDownLoaderUrl(m_Data.getOwnerID(), true),
								R.drawable.profile_pic_default, false);
					} else
					{
						App.imageloader.cancelDownload(viewHolder.m_ivprofile_pic);
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.profile_pic_default);
					}

					if(userData.m_strUserType.equals("R")){
						viewHolder.m_iv_partner_icon.setVisibility(View.GONE);
					} else {
						viewHolder.m_iv_partner_icon.setVisibility(View.VISIBLE);
					}

					if (arrUserNo.size() == 1) {
						viewHolder.m_tvListUserCount.setVisibility(View.GONE);
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.profile_pic_default);
						if(m_Data.getTitleEdited()){
							viewHolder.m_tvListName.setText(m_Data.getName());
						} else {
							viewHolder.m_tvListName.setText(R.string.layout_chatroom_nobody);
						}
						viewHolder.m_iv_partner_icon.setVisibility(View.GONE);
					}
					else {
						viewHolder.m_tvListUserCount.setVisibility(View.VISIBLE);
						viewHolder.m_tvListName.setText(m_Data.getName());
					}
				} else {
					UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, Integer.parseInt(m_Data.getRoomID()));
					if (userData != null && userData.m_isImageAvailable) {
						App.imageloader.getImage(viewHolder.m_ivprofile_pic, App.getImageDownLoaderUrl(Integer.parseInt(m_Data.getRoomID()), true),
								R.drawable.profile_pic_default);

					} else
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.profile_pic_default);
					if(userData.m_strUserType.equals("R")){
						viewHolder.m_iv_partner_icon.setVisibility(View.GONE);
					} else {
						viewHolder.m_iv_partner_icon.setVisibility(View.VISIBLE);
					}
					viewHolder.m_tvListName.setText(m_Data.getName());
					viewHolder.m_tvListUserCount.setVisibility(View.GONE);
				}

				if(m_Data.getBackgroundColor() != 0)
					viewHolder.layout.setBackgroundColor(m_Data.getBackgroundColor());
				else
					viewHolder.layout.setBackgroundResource(R.drawable.chatroom_listitem_selecter);


				EmoticonUtils utils = new EmoticonUtils();
				viewHolder.m_ivIcon.setVisibility(View.GONE);
				if (m_Data.getType() == StaticString.CHAT_ROOM_MY_FILE || m_Data.getType() == StaticString.CHAT_ROOM_OTHER_FILE) {
					if (m_Data.getText().equals(getString(R.string.chatlist_movie))) {
						viewHolder.m_ivIcon.setVisibility(View.VISIBLE);
						viewHolder.m_ivIcon.setImageResource(R.drawable.icon_movie);
					} else {
						viewHolder.m_ivIcon.setVisibility(View.VISIBLE);
						if (m_Data.getText().equals(getString(R.string.chatlist_file)))
							viewHolder.m_ivIcon.setImageResource(R.drawable.icon_file);
						else if (m_Data.getText().equals("클라우드"))
							viewHolder.m_ivIcon.setImageResource(R.drawable.icon_cloud);
						else if (m_Data.getText().equals(getString(R.string.chatlist_contact)))
							viewHolder.m_ivIcon.setImageResource(R.drawable.icon_phone);
					}
				} else if (m_Data.getType() == StaticString.CHAT_ROOM_MY_IMAGE || m_Data.getType() == StaticString.CHAT_ROOM_OTHER_IMAGE) {
					viewHolder.m_ivIcon.setVisibility(View.VISIBLE);
					viewHolder.m_ivIcon.setImageResource(R.drawable.icon_image);
				}
				// 파일, 클라우드시 파일 이름 보여주지 않고 그냥 '파일', '클라우드'로 적용
				// if (m_Data.getText().equals(getString(R.string.chatlist_movie)) ||
				// m_Data.getText().equals(getString(R.string.chatlist_image)))
				// m_tvListMessage.setText(utils.parsingEmoticonText(m_Context,
				// m_Data.getText(), (int) m_tvListMessage.getTextSize()));
				// else{
				String strText = m_Data.getText();
				String strLastChar = " ";
				String strFirstChar = " ";

				if (strText != null && strText.length() != 0) {
					while (strLastChar.equals(" ") || strLastChar.equals("\n")) {
						strLastChar = (String) strText.subSequence(strText.length() - 1, strText.length());
						if (strLastChar.equals(" ") || strLastChar.equals("\n")) {
							strText = (String) strText.subSequence(0, strText.length() - 1);
						}
					}
					while (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
						strFirstChar = (String) strText.subSequence(0, 1);
						if (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
							strText = (String) strText.subSequence(1, strText.length());
						}
					}
				}
				viewHolder.m_tvListMessage.setText(utils.parsingEmoticonText(m_Context, strText, (int) viewHolder.m_tvListMessage.getTextSize()));

				// }

			}

			viewHolder.layout.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;

					ArrayList<Integer> arrUserList = new ArrayList<Integer>();
					if (data.getRoomID().length() < 8) {
						arrUserList.add(Integer.parseInt(data.getRoomID()));
					} else {
						ChattingDBManager dbMng = new ChattingDBManager(m_Context);
						dbMng.openReadable(data.getRoomID());
						arrUserList = dbMng.getChattingUser();
						dbMng.close();
					}
					for (int i = 0; i < arrUserList.size(); i++) {
						m_ListItems.add(ContactsDBManager.getContacts(m_Context, arrUserList.get(i)));
					}
					m_cbAllcheck.setChecked(false);
					m_MemberListAdapter = new MemberListAdapter();
					m_MemberListAdapter.areAllItemsEnabled();
					m_MemberList.setAdapter(m_MemberListAdapter);

					m_tvSectionText.setText(getString(R.string.snsgroupdetail_invite_member) + " " + m_ListItems.size());
					// m_ListView.setVisibility(View.GONE);
					m_FrameList.setVisibility(View.GONE);
					m_LayoutMemberList.setVisibility(View.VISIBLE);
					((SNSGroupMemeberInviteAct) m_Activity).setOnKeyBackPressedListener(m_OnKeyBackPressedListener);
					((SNSGroupMemeberInviteAct) m_Activity).inChatRoomMemberList(true);

				}
			});

			// 알림끄기 아이콘이 있을때는 방제목과 채팅 텍스트 오른쪽에 마진 20

			return convertView;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (m_SectionListItems != null)
				return m_SectionListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_SectionListItems != null)
				return m_SectionListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub
			super.notifyDataSetChanged();
		}
	}

	private class MemberListAdapter extends BaseAdapter {

		public MemberListAdapter() {
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_ListItems != null)
				return m_ListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (m_ListItems != null)
				return m_ListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			UserListData data = m_ListItems.get(nPosition);

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new SNSInviteChatMemberListItemLayout(m_Activity);

			((SNSInviteChatMemberListItemLayout) convertView).setUserListData(data);
			((SNSInviteChatMemberListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);
			CheckBox cb_redaction = (CheckBox) ((SNSInviteChatMemberListItemLayout) convertView).findViewById(R.id.cb_invite);
			ImageView ivSelected = (ImageView) ((SNSInviteChatMemberListItemLayout) convertView).findViewById(R.id.iv_invite_selected);

			// if (data.m_isChecked){
			if (m_arrUserNumbers.contains(data.m_nUserNo)) {

				cb_redaction.setVisibility(View.INVISIBLE);
				ivSelected.setVisibility(View.VISIBLE);
			} else {
				cb_redaction.setVisibility(View.VISIBLE);
				ivSelected.setVisibility(View.INVISIBLE);
			}
			if(!data.m_isActive || data.m_nUserNo == App.m_nChatbot || data.m_nUserNo == 100){
				cb_redaction.setVisibility(View.INVISIBLE);
				ivSelected.setVisibility(View.INVISIBLE);
			}
			if (cb_redaction.getVisibility() != View.INVISIBLE) {
				boolean is_redaction = false;
				ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;
				for (int i = 0; i < arrSearchListCheckData.size(); i++) {
					if (data.m_nUserNo == arrSearchListCheckData.get(i).m_nUserNo) {
						is_redaction = true;
						cb_redaction.setChecked(true);
						break;
					}
				}
				if (!is_redaction) {
					cb_redaction.setChecked(false);
				}
			}
			// }
			// else
			// cb_redaction.setChecked(false);
			return convertView;
		}
	}

	SNSGroupMemeberInviteAct.OnNotifyListener m_NotifyListner = new SNSGroupMemeberInviteAct.OnNotifyListener() {

		@Override
		public void onNotify() {
			// TODO Auto-generated method stub

			if (m_MemberListAdapter != null) {
				m_MemberListAdapter.notifyDataSetChanged();
				m_cbAllcheck.setChecked(false);
			}

		}
	};

	SNSInviteChatMemberListItemLayout.OnCheckedChangedListener m_CheckedChangedListner = new SNSInviteChatMemberListItemLayout.OnCheckedChangedListener() {

		@Override
		public void onChecked(boolean a_isChecked, int a_nUserId) {
			// TODO Auto-generated method stub
			if (a_isChecked) {
				boolean isSame = false;
				if (App.m_arrSearchListCheckData != null) {
					for (int i = 0; i < m_ListItems.size(); i++) {
						for (SearchListCheckData data : App.m_arrSearchListCheckData) {
							if (data.m_nUserNo == m_ListItems.get(i).m_nUserNo) {
								isSame = true;
								break;
							} else if (m_arrUserNumbers.contains(m_ListItems.get(i).m_nUserNo)) {
								isSame = true;
								break;
							} else if(!m_ListItems.get(i).m_isActive || m_ListItems.get(i).m_nUserNo == App.m_nChatbot && m_ListItems.get(i).m_nUserNo != 100){
								isSame = true;
								break;
							}
							else {
								isSame = false;
							}

						}
						if (!isSame) {
							break;
						}
					}
				}
				if (isSame) {
					m_cbAllcheck.setChecked(true);
				} else {
					m_cbAllcheck.setChecked(false);
				}
			} else {

				m_cbAllcheck.setChecked(false);
			}
		}

		@Override
		public void onDataSetChagnged() {
			// TODO Auto-generated method stub

		}
	};

	private final static Comparator<ChatRoomListData> myComparator = new Comparator<ChatRoomListData>() {
		private final Collator collator = Collator.getInstance();

		@Override
		public int compare(ChatRoomListData lhs, ChatRoomListData rhs) {
			// TODO Auto-generated method stub
			return collator.compare(Long.toString(lhs.getLastMessageTime()), Long.toString(rhs.getLastMessageTime()));
		}

	};

	SNSGroupMemeberInviteAct.onKeyBackPressedListener m_OnKeyBackPressedListener = new SNSGroupMemeberInviteAct.onKeyBackPressedListener() {

		@Override
		public void onBack() {
			// TODO Auto-generated method stub
			m_LayoutMemberList.setVisibility(View.GONE);
			m_FrameList.setVisibility(View.VISIBLE);
			m_ListItems = new ArrayList<UserListData>();
			((SNSGroupMemeberInviteAct) m_Activity).inChatRoomMemberList(false);
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if (buttonView.getId() == R.id.cb_sns_allmember) {
			if (m_isTouchCheckBox) {
				if (isChecked) {
					int nCheckList = 0;
					for (int i = 0; i < m_ListItems.size(); i++) {
						if (!m_arrUserNumbers.contains(m_ListItems.get(i).m_nUserNo)) {
							SearchListCheckData addData = new SearchListCheckData(m_ListItems.get(i).m_nUserNo,
									m_ListItems.get(i).m_PersonalData.mapPersonalData.get(PersonalData.NAME));
							if(m_ListItems.get(i).m_isActive && m_ListItems.get(i).m_nUserNo != App.m_nChatbot && m_ListItems.get(i).m_nUserNo != 100) {
								((SNSGroupMemeberInviteAct) m_Activity).addSearchList(addData);
								nCheckList++;
							}
						}
					}
					if(nCheckList == 0){
						m_isTouchCheckBox = false;
						m_cbAllcheck.setChecked(false);
					}
				} else {
					for (int i = 0; i < m_ListItems.size(); i++) {
						((SNSGroupMemeberInviteAct) m_Activity).removeListData(m_ListItems.get(i).m_nUserNo);

					}
				}
				m_isTouchCheckBox = false;
				if (m_MemberListAdapter != null)
					m_MemberListAdapter.notifyDataSetChanged();
			} else {

			}

		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.cb_sns_allmember) {
			m_isTouchCheckBox = true;
		}
		return false;
	}
}
