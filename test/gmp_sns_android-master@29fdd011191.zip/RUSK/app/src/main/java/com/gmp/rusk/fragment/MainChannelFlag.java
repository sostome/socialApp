package com.gmp.rusk.fragment;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.SpannableString;
import android.text.TextUtils;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChannelNoticeDetailAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.act.SNSBoardDetailAct;
import com.gmp.rusk.act.SNSBoardWriteAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.SNSGroupDetailSwifeRefreshLayout;
import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChannelNoticeData;
import com.gmp.rusk.datamodel.ChannelThreadData;
import com.gmp.rusk.datamodel.ChannelUnreadsData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.listview.LoadMoreListView;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteBoardLikeReq;
import com.gmp.rusk.request.GetChannelNoticeListReq;
import com.gmp.rusk.request.GetGroupBoardReq;
import com.gmp.rusk.request.GetGroupDetailReq;
import com.gmp.rusk.request.GetGroupThreadListReq;
import com.gmp.rusk.request.GetGroupUnreadsReq;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostBoardLikeReq;
import com.gmp.rusk.request.PutGroupReadThreadReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetChannelNoticeListRes;
import com.gmp.rusk.response.GetGroupBoardRes;
import com.gmp.rusk.response.GetGroupDetailRes;
import com.gmp.rusk.response.GetGroupThreadListRes;
import com.gmp.rusk.response.GetGroupUnreadsRes;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by K on 2017-08-25.
 */

public class MainChannelFlag extends Fragment implements View.OnClickListener {

    public MyApp App = MyApp.getInstance();

    private RelativeLayout m_layoutChannelNolist, m_layoutChannelView;
    private RelativeLayout m_layoutChannelContentDetail, m_layoutChannelContentNotice;
    private TextView m_tvBubble;
    private SNSBoardListAdapter m_adapterBoardList = null;
    private ArrayList<ChannelThreadData> m_arrSNSGroupNoticeBoardDatas = null;
    private ArrayList<ChannelThreadData> m_arrThreadData = null;
    private ArrayList<ChannelNoticeData> m_arrChannelNoticeData = null;
    private ChannelData m_SNSGroupDetailData = null;
    private int m_nGroupId = -1;
    private String m_strGroupName = "";
    private int m_nImageIndex = 0;
    private String m_strImageURL = "";

    private int m_nPage = 0;
    private boolean m_isGetLastBoard = false;
    private ArrayList<Integer> m_arrUserNumbers;
    private ArrayList<Integer> m_arrInvitingUserNumbers;
    private SparseBooleanArray m_arrReadTrueList;
    private Button btnMemberInvite, btnMemberQuit, btnEditGroup, btnChangeOwner, btnWriteBoard;
    CommonPopup m_Popup = null;
    private String m_strBoardText;
//	int m_nPopupType;

    //강퇴, 권한 양도를 하였을때 상당 메뉴 UI 갱신을 위함
    boolean m_isMenuUIChange = false;

    public static final int REQUEST_CODE_OWNER_EXIT = 101;
    public static final int REQUEST_CODE_MAKEROOM = 102;
    public static final int REQUEST_CODE_OWNER = 103;
    public static final int REQUEST_CODE_EXIT_OTHER = 104;
    public static final int REQUEST_CODE_BOARDWRITE = 105;
    public static final int REQUEST_CODE_BOARDDETAIL = 106;
    public static final int REQUEST_CODE_GROUPEDIT = 107;
    public static final int REQUEST_CODE_GROUPCHAT = 108;
    public static final int REQUEST_CODE_ALARMSET = 109;
    public static final int REQUEST_CODE_GROUPCREATE = 110;

    static final public int RESULT_CODE_GROUPCHAT = 20000;
    boolean m_isListViewHeader = false;

    public View m_vChannelView;
    private ProgressDlg m_Progress = null;

    private final String JSON_THREAD_TYPE_CAPTURE = "C";

    //새 게시글에 대한 버블 카운트
    private int m_nBubbleCount = 0;

    private int m_nPushBoardNo = -1;
    private boolean m_isAlreadyNewBar = false;
    @Override
    public void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        m_vChannelView = inflater.inflate(R.layout.act_snsgroupdetail, container, false);

        //       getIntentData();
        ((MainTabAct)getContext()).setChannelInfoListener(m_ChannelListListener);
        ((MainTabAct)getContext()).setCurrentTabIndexChange();
        initUI();
        SharedPref pref = SharedPref.getInstance(getActivity());
        int nLastViewChannelNo =  pref.getIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, -1);
        m_nGroupId = nLastViewChannelNo;
        m_nPage = 0;
        if(m_nGroupId != -1)
		    getSNSGroupDetail(m_nGroupId);
        else {
            ((MainTabAct)getActivity()).getSNSGroupList();

        }

        return m_vChannelView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_BOARDWRITE){
                getSNSGroupDetail(m_nGroupId);
            }

            else if (requestCode == REQUEST_CODE_BOARDDETAIL) {

                final int nBoardId = data.getIntExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, -1);
                final boolean isNoticeCancel = data.getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_CANCELNOTICE, false);
                if (nBoardId != -1) {
                    boolean isDeleted = data.getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISDELETE, false);
                    if (isDeleted) {
                        try {
                            if (m_arrThreadData != null) {
                                for (ChannelThreadData ChannelThreadData : m_arrThreadData) {
                                    if (nBoardId == ChannelThreadData.m_nThreadNo) {
                                        m_arrThreadData.remove(ChannelThreadData);
                                        // 이유는 모르겠지만 m_nNoticed 로 하면 false로 체크되어서 m_nBoardNo으로 비교
                                        if (m_arrSNSGroupNoticeBoardDatas != null) {
                                            for (int i = 0; i < m_arrSNSGroupNoticeBoardDatas.size(); i++) {
                                                if (ChannelThreadData.m_nThreadNo == m_arrSNSGroupNoticeBoardDatas.get(i).m_nThreadNo) {
                                                    m_arrSNSGroupNoticeBoardDatas.remove(i);
                                                    break;
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                        } catch (Exception e){

                        }
                        m_adapterBoardList.notifyDataSetChanged();
                    } else {

                        m_arrReadTrueList = new SparseBooleanArray();
                        m_arrReadTrueList.append((Integer) nBoardId, true);


                        if (isNoticeCancel) {
                            for (int i = 0; i < m_arrSNSGroupNoticeBoardDatas.size(); i++) {
                                if (nBoardId == m_arrSNSGroupNoticeBoardDatas.get(i).m_nThreadNo)
                                    m_arrSNSGroupNoticeBoardDatas.remove(i);
                            }
                        }
                        try {
                            if (m_arrThreadData != null) {
                                getBoardDetailData(nBoardId);
                            }
                        } catch (Exception e){

                        }
//									getSNSGroupNotice(m_nGroupId, nBoardId);
//								}
//
//								@Override
//								public void onNetworkError(int nErrorCode, String strMessage) {
//									// TODO Auto-generated method stub
//									if(m_arrNoReadBoard != null)
//									{
//										m_arrNoReadBoard.remove((Integer)nBoardId);
//									}
//									getSNSGroupNotice(m_nGroupId, nBoardId);
//								}
//							});
                    }
                }
        }
        }


    }


    private void initUI()
    {
        if(m_strGroupName != null && !m_strGroupName.equals(""))
        {
            ((MainTabAct)getActivity()).setTitle(m_strGroupName);
        }
        m_layoutChannelNolist = (RelativeLayout)m_vChannelView.findViewById(R.id.layout_channel_nolist);
        m_layoutChannelView = (RelativeLayout)m_vChannelView.findViewById(R.id.layout_channel_view);
        m_layoutChannelContentDetail = (RelativeLayout)m_vChannelView.findViewById(R.id.layout_channel_content_detail);
        m_layoutChannelContentNotice = (RelativeLayout)m_vChannelView.findViewById(R.id.layout_channel_content_notice);
        m_tvBubble = (TextView) m_vChannelView.findViewById(R.id.tv_channel_new_bubble);
        LinearLayout layoutMenu = (LinearLayout)m_vChannelView.findViewById(R.id.layout_snsgroupdetail_menu);
        //btnGroupChat = (ImageButton)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_chatgroup);
        //ImageButton btnMenu = (ImageButton)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_menu);
        Button btnNewBoardAlarm = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_newboardalarm);
        Button btnNewReplyAlarm = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_newreplyalarm);
        Button btnMemberList = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_memberlist);
        Button btnGroupQuit = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_groupquit);
        btnMemberInvite = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_memberinvite);
        btnMemberQuit = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_memberquit);
        btnEditGroup = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_editgroup);
        btnChangeOwner = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_changeowner);
        btnWriteBoard = (Button)m_vChannelView.findViewById(R.id.btn_snsgroupdetail_writeboard);

        layoutMenu.setOnClickListener(MainChannelFlag.this);
        //btnGroupChat.setOnClickListener(MainChannelFlag.this);
        //btnMenu.setOnClickListener(MainChannelFlag.this);
        btnNewBoardAlarm.setOnClickListener(MainChannelFlag.this);
        btnNewReplyAlarm.setOnClickListener(MainChannelFlag.this);
        btnMemberList.setOnClickListener(MainChannelFlag.this);
        btnGroupQuit.setOnClickListener(MainChannelFlag.this);
        btnMemberInvite.setOnClickListener(MainChannelFlag.this);
        btnMemberQuit.setOnClickListener(MainChannelFlag.this);
        btnEditGroup.setOnClickListener(MainChannelFlag.this);
        btnChangeOwner.setOnClickListener(MainChannelFlag.this);
        btnWriteBoard.setOnClickListener(MainChannelFlag.this);



        SwipeRefreshLayout layoutSwipeRefresh = (SwipeRefreshLayout)m_vChannelView.findViewById(R.id.layout_snsgroupdetail_swiperefresh);
        layoutSwipeRefresh.setOnRefreshListener(m_onTimeLineRefreshListener);

        LoadMoreListView lvBoardList = (LoadMoreListView)m_vChannelView.findViewById(R.id.lv_snsgroupdetail_boardlist);
        lvBoardList.setOnLoadMoreListener(m_onTimeLineLoadMoreListener);
        lvBoardList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if(m_tvBubble != null && m_tvBubble.getVisibility() == View.VISIBLE){
                    m_tvBubble.setVisibility(View.GONE);
                    m_nBubbleCount = 0;
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });
        //lvBoardList.setOnItemClickListener(getContext());
    }

    MainTabAct.OnChannelInfoListener m_ChannelListListener = new MainTabAct.OnChannelInfoListener() {
        @Override
        public void setInfo(int a_nChannelNo, String a_strName, boolean a_isNotice) {
            m_nPage = 0;
            m_nGroupId = a_nChannelNo;
            m_strGroupName = a_strName;
            if(a_isNotice){
                m_layoutChannelContentNotice.setVisibility(View.VISIBLE);
                m_layoutChannelContentDetail.setVisibility(View.GONE);
                getChannelNoticeDetail(m_nGroupId);
            } else {
                m_layoutChannelContentNotice.setVisibility(View.GONE);
                m_layoutChannelContentDetail.setVisibility(View.VISIBLE);
                getSNSGroupDetail(m_nGroupId);
            }
        }


        @Override
        public void setFirstChannelView(int a_nChannelNo, String a_strName) {
            m_nPage = 0;
            if(a_nChannelNo != -1 && !a_strName.equals("")) {
                m_layoutChannelView.setVisibility(View.VISIBLE);
                m_layoutChannelNolist.setVisibility(View.GONE);
                m_nGroupId = a_nChannelNo;
                m_strGroupName = a_strName;
                m_layoutChannelContentNotice.setVisibility(View.GONE);
                m_layoutChannelContentDetail.setVisibility(View.VISIBLE);
                getSNSGroupDetail(m_nGroupId);
            } else {
                ((MainTabAct)getActivity()).setTitle(getString(R.string.channel_text));
                ((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_SNSLIST_NOLIST);
                m_layoutChannelView.setVisibility(View.GONE);
                m_layoutChannelNolist.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void setNewMessage() {
            m_nBubbleCount++;
            m_tvBubble.setVisibility(View.VISIBLE);
            m_tvBubble.setText(getString(R.string.groupdetail_newboard) + m_nBubbleCount);

            m_tvBubble.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getSNSGroupDetail(m_nGroupId);
                }
            });
        }

        @Override
        public void setRefresh(int a_nChannelNo) {
            getSNSGroupDetail(a_nChannelNo);
        }


    };

    private void setNoticeUI(){
        m_layoutChannelView.setVisibility(View.VISIBLE);
        m_layoutChannelNolist.setVisibility(View.GONE);
        ((MainTabAct)getActivity()).setTitle(m_strGroupName);
        ((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_SNSLIST_NOTICE);
        ListView lvChannelNoticeList = (ListView)m_vChannelView.findViewById(R.id.lv_channel_content_notice);
        ChannelNoticeListAdapter noticeListAdapter = new ChannelNoticeListAdapter();
        lvChannelNoticeList.setAdapter(noticeListAdapter);
    }
    private void setUI()
    {

        if(((MainTabAct)getActivity()).getCurrentTab() != MainTabAct.TAB_BTN_ORGANCHART) {
            m_layoutChannelView.setVisibility(View.VISIBLE);
            m_layoutChannelNolist.setVisibility(View.GONE);
            m_strGroupName = m_SNSGroupDetailData.m_strName;

            ((MainTabAct) getActivity()).setTitle(m_strGroupName);

            LoadMoreListView lvBoardList = (LoadMoreListView) m_vChannelView.findViewById(R.id.lv_snsgroupdetail_boardlist);


            m_adapterBoardList = new SNSBoardListAdapter();
            lvBoardList.setAdapter(m_adapterBoardList);
            btnWriteBoard.setVisibility(View.VISIBLE);

            setMenuUI();
        }
    }

    private void setMenuUI(){
        ((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_SNSLIST);
        if(m_SNSGroupDetailData.m_isOwner){
            //btnGroupChat.setVisibility(View.VISIBLE);
            btnMemberInvite.setVisibility(View.VISIBLE);
            btnMemberQuit.setVisibility(View.VISIBLE);
            btnEditGroup.setVisibility(View.VISIBLE);
            btnChangeOwner.setVisibility(View.VISIBLE);
            if(m_SNSGroupDetailData.m_nMemberCount == 1){
                btnChangeOwner.setBackgroundResource(R.drawable.timeline_topmenu08_unactive);

                btnChangeOwner.setOnClickListener(null);
                //btnGroupChat.setVisibility(View.INVISIBLE);
            } else {
                btnChangeOwner.setBackgroundResource(R.drawable.btn_timeline_topmenu_08);
                btnChangeOwner.setOnClickListener(MainChannelFlag.this);
                //btnGroupChat.setVisibility(View.VISIBLE);
            }
        } else {
            //btnGroupChat.setVisibility(View.INVISIBLE);
            //btnGroupChat.setVisibility(View.INVISIBLE);
            /*if(isCreateSNSGroupChatRoom())
                btnGroupChat.setVisibility(View.VISIBLE);*/

            btnMemberInvite.setVisibility(View.GONE);
            btnMemberQuit.setVisibility(View.GONE);
            btnEditGroup.setVisibility(View.GONE);
            btnChangeOwner.setVisibility(View.GONE);
        }
    }


    private void getChannelNoticeDetail(final int a_nChannelId){
        GetChannelNoticeListReq req = new GetChannelNoticeListReq(a_nChannelId);
        WebAPI webAPI = new WebAPI(getContext());
        webAPI.request(req, new WebListener() {
            @Override
            public void onPreRequest() {

            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                closeProgress();
                if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(getContext(), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();

                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
                else
                    ((MainTabAct)getContext()).showErrorPopup(nErrorCode, strMessage);
            }

            @Override
            public void onPostRequest(String a_strData) {
                closeProgress();
                GetChannelNoticeListRes res = new GetChannelNoticeListRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_NOTICE_LIST);
                m_arrChannelNoticeData = res.getChannelNoticeListData();
                setNoticeUI();
            }
        });
    }
    private void getSNSGroupDetail(final int a_nGroupId)
    {
        SharedPref pref = SharedPref.getInstance(getContext());
        m_nPushBoardNo = pref.getIntegerPref(SharedPref.PREF_CHANNEL_PUSH_BOARD, -1);
        pref.setIntegerPref(SharedPref.PREF_CHANNEL_PUSH_BOARD, -1);
        m_isAlreadyNewBar = false;
        m_tvBubble.setVisibility(View.GONE);
        m_nBubbleCount = 0;
        final SwipeRefreshLayout layoutSwipeRefresh = (SwipeRefreshLayout)m_vChannelView.findViewById(R.id.layout_snsgroupdetail_swiperefresh);
        GetGroupDetailReq req = new GetGroupDetailReq(a_nGroupId);
        WebAPI webApi = new WebAPI(getContext());
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                showProgress();
                // TODO Auto-generated method stub
                SharedPref pref = SharedPref.getInstance(getActivity());
                pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, a_nGroupId);
            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                layoutSwipeRefresh.setRefreshing(false);
                /*if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(getContext(), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                           
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
                else
                    ((MainTabAct)getContext()).showErrorPopup(nErrorCode, strMessage);*/

                ((MainTabAct)getActivity()).setTitle("");
                ((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_ERROR_CASE);


                if (nErrorCode == ApiResult.HTTP_SERVER_CHANNEL_OUT) {
                    SharedPref pref = SharedPref.getInstance(getContext());
                    pref.setIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW, -1);
                    m_Popup = new CommonPopup(getContext(), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                            ((MainTabAct)getActivity()).getSNSGroupList();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                } else {
                    m_Popup = new CommonPopup(getContext(), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                    //((MainTabAct) getActivity()).getSNSGroupList();
                }

            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                GetGroupDetailRes res = new GetGroupDetailRes(a_strData, ChannelRes.RES_TYPE_CHANNEL);
                m_SNSGroupDetailData = res.getChannelData();
                if(m_SNSGroupDetailData != null){
                    //제대로 된 값이 내려 오지 않으므로 임시
                    //((MainTabAct)getActivity()).m_nChannelNo = m_SNSGroupDetailData.m_nChannelNo;
                    ((MainTabAct)getActivity()).m_nChannelNo = a_nGroupId;
                    ((MainTabAct)getActivity()).m_strChannelName = m_SNSGroupDetailData.m_strName;
                    ((MainTabAct)getActivity()).m_isChannelOwner = m_SNSGroupDetailData.m_isOwner;
                    ((MainTabAct)getActivity()).m_nChannelUserCount = m_SNSGroupDetailData.m_nMemberCount;
                    ((MainTabAct)getActivity()).m_isChannelThreadAlarmOn = m_SNSGroupDetailData.m_isThreadNotificationOn;
                    ((MainTabAct)getActivity()).m_isChannelCommentAlarmOn = m_SNSGroupDetailData.m_isCommentNotificationOn;
                }
                getChannelThreadData(a_nGroupId, m_nPage);
            }
        });
    }

    private void getChannelThreadData(final int a_nGroupId, final int a_nPage)
    {
        final SwipeRefreshLayout layoutSwipeRefresh = (SwipeRefreshLayout)m_vChannelView.findViewById(R.id.layout_snsgroupdetail_swiperefresh);
        long lLastThreadNo = 0;
        if(m_arrThreadData != null && m_arrThreadData.size() > 0){
            lLastThreadNo = m_arrThreadData.get(m_arrThreadData.size() - 1).m_nThreadNo;
        }
        GetGroupThreadListReq req = new GetGroupThreadListReq(a_nGroupId, a_nPage, lLastThreadNo);
        WebAPI webApi = new WebAPI(getContext());
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                layoutSwipeRefresh.setRefreshing(false);
                if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(getContext(), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                            
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
                else
                    ((MainTabAct)getContext()).showErrorPopup(nErrorCode, strMessage);
            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                closeProgress();
                GetGroupThreadListRes res = new GetGroupThreadListRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_THREAD_LIST);

                //읽음 처리에만 사용하기 위한 데이터
                ArrayList<ChannelThreadData> arrThreadData = new ArrayList<ChannelThreadData>();
                if(a_nPage == 0) {
                    m_arrThreadData = res.getChannelThreadListData();
                    m_arrSNSGroupNoticeBoardDatas = res.getChannelThreadNoticeListData();
                    arrThreadData = res.getChannelThreadListData();
                    layoutSwipeRefresh.setRefreshing(false);
                }
                else {
                    m_arrThreadData.addAll(res.getChannelThreadListData());
                    arrThreadData = res.getChannelThreadListData();
                    completeLoadMore();
                }

                /*if(res.m_nSize == m_nPage){
                    m_isGetLastBoard = true;
                }*/
                ArrayList<Integer> arrUserID = new ArrayList<Integer>();
                UserListData data;
                for(int i = 0; i < m_arrThreadData.size(); i++){
                    data = TTalkDBManager.ContactsDBManager.getContacts(getActivity(), m_arrThreadData.get(i).m_nUserNo);
                    if(data == null){
                        if(!arrUserID.contains(m_arrThreadData.get(i).m_nUserNo)){
                            arrUserID.add(m_arrThreadData.get(i).m_nUserNo);
                        }
                    }
                }
                int[] nNotInDBUsers = new int[arrUserID.size()];
                for(int j = 0; j < arrUserID.size(); j++){
                    nNotInDBUsers[j] = arrUserID.get(j);
                }
                if(nNotInDBUsers.length > 0){
                    requestAddedByUserList(nNotInDBUsers, arrThreadData);
                } else {
                    if(m_nPage > 0){
                        m_adapterBoardList.notifyDataSetChanged();
                    } else {
                        setUI();
                    }
                }
                requestReadThread(arrThreadData);


                if(m_nPushBoardNo != -1){
                    //푸시로 들어와도 무조건 채널 정보를 가지게 되므로 필요 없음
                    startSNSBoardDetailAct(false, m_nGroupId, m_strGroupName, m_nPushBoardNo, false, false, false);
                }
            }
        });
    }

    private void requestReadThread(ArrayList<ChannelThreadData> arrThreadData){
        //현재 표시된 페이지 중 안읽은 게시글 번호를 담기 위한 array
        final ArrayList<Integer> arrUnreadThreadNos = new ArrayList<Integer>();

        for(int i = 0; i < arrThreadData.size(); i++){
            if(!arrThreadData.get(i).m_isRead){
                arrUnreadThreadNos.add(arrThreadData.get(i).m_nThreadNo);
            }
        }
        if(arrUnreadThreadNos.size() != 0){
            GetGroupUnreadsReq req = new GetGroupUnreadsReq();
            WebAPI webApi = new WebAPI(getActivity());
            webApi.request(req, new WebListener() {
                @Override
                public void onPreRequest() {

                }

                @Override
                public void onNetworkError(int nErrorCode, String strMessage) {

                }

                @Override
                public void onPostRequest(String a_strData) {
                    GetGroupUnreadsRes res = new GetGroupUnreadsRes(a_strData);
                    ArrayList<ChannelUnreadsData> unreadDatas = res.getChannelUnreadsData();
                    //서버에서 내려준 안읽은 글 목록을 넣어두기 위한 array
                    ArrayList<Integer> arrForSendThreadNosInAPI = new ArrayList<Integer>();
                    for(int i = 0; i < unreadDatas.size(); i++){
                        //보고 있는 페이지의 게시글 들과, 서버의 안읽은 목록을 비교하여 게시글과 댓글의 번호를 저장
                        if(unreadDatas.get(i).m_nChannelNo == m_nGroupId){
                            ArrayList<String> arrUnreads = unreadDatas.get(i).m_arrThreadAndCommentNo;
                            if(arrUnreads != null){
                                for(String strUnread : arrUnreads){

                                    arrForSendThreadNosInAPI.add((Integer.parseInt(strUnread)));

                                }
                            }
                            break;
                        }
                    }
                    if(arrForSendThreadNosInAPI.size() > 0){
                        sendRequestReadThread(arrForSendThreadNosInAPI);
                    }
                }
            });
        }

    }

    private void sendRequestReadThread(ArrayList<Integer> arrNos){

        ArrayList<Integer> arrRealNos = new ArrayList<Integer>();
        for(int i = 0; i < arrNos.size(); i++){
            if(!arrRealNos.contains(arrNos.get(i))){
                arrRealNos.add(arrNos.get(i));
            }
        }
        final int nSendNoSize = arrNos.size();
        int[] nSendNos = new int[arrRealNos.size()];
        for(int j = 0; j < arrRealNos.size(); j++){
            nSendNos[j] = arrRealNos.get(j);
        }

        PutGroupReadThreadReq req = new PutGroupReadThreadReq(m_nGroupId, nSendNos);
        WebAPI webApi = new WebAPI(getActivity());
        webApi.request(req, new WebListener() {
            @Override
            public void onPreRequest() {

            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {

            }

            @Override
            public void onPostRequest(String a_strData) {
                SharedPref pref = SharedPref.getInstance(getActivity());
                int nChannelBadgeCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT);
                ((MainTabAct)getActivity()).setChannelListNoReadCountBadge(nChannelBadgeCount - nSendNoSize);
            }
        });

    }

    private void startWriteBoardAct()
    {
        Intent intent = new Intent(getContext(), SNSBoardWriteAct.class);
        if(m_SNSGroupDetailData!=null)
            intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDWRITE_GROUPID, m_nGroupId);
        else{
            intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDTEXT,m_strBoardText);
            intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDWRITE_GROUPID, m_nGroupId);
        }
        startActivityForResult(intent, REQUEST_CODE_BOARDWRITE);
    }

    private void startSNSBoardDetailAct(boolean a_isPush, int a_nGroupId, String a_strGroupName, final int a_nBoardId, boolean a_isReply, boolean a_isWriteReply, boolean a_isLastScroll)
    {
        boolean isShowChatBtn = false;
        /*if(btnGroupChat != null && btnGroupChat.getVisibility() == View.VISIBLE){
            isShowChatBtn = true;
        }*/

        for(int i = 0; i < m_arrThreadData.size(); i++){
            if(m_arrThreadData.get(i).m_nThreadNo == a_nBoardId){
                m_arrThreadData.get(i).m_isRead = true;
                break;
            }
        }
        Intent intent = new Intent(getContext(), SNSBoardDetailAct.class);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISPUSH, a_isPush);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPID, a_nGroupId);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPNAME, a_strGroupName);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, a_nBoardId);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, a_isReply);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_WRITEREPLY, a_isWriteReply);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_SHOWCHATBTN, isShowChatBtn);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISLASTSCROLL, a_isLastScroll);
        intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISOWNER, m_SNSGroupDetailData.m_isOwner);
        startActivityForResult(intent, REQUEST_CODE_BOARDDETAIL);

    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        int nId = v.getId();
        if(nId == R.id.btn_snsgroupdetail_writeboard)
        {
            startWriteBoardAct();
        }

    }


    private void completeLoadMore()
    {
        LoadMoreListView lvBoardList = (LoadMoreListView)m_vChannelView.findViewById(R.id.lv_snsgroupdetail_boardlist);
        lvBoardList.onLoadMoreComplete();
    }


    private void getBoardDetailData(final int a_nBoardId)
    {
        GetGroupBoardReq req = new GetGroupBoardReq(m_nGroupId, a_nBoardId);
        WebAPI api = new WebAPI(getContext());
        api.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                boolean isBeforeNoticed = false;
                GetGroupBoardRes res = new GetGroupBoardRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_THREAD);
                ChannelThreadData ChannelThreadData = res.getChannelThreadData();

                for(ChannelThreadData data : m_arrThreadData)
                {
                    if(a_nBoardId == data.m_nThreadNo)
                    {
                        data.m_strBody = ChannelThreadData.m_strBody;
                        data.m_nCommentCount = ChannelThreadData.m_nCommentCount;
                        data.m_arrChannelFileData = ChannelThreadData.m_arrChannelFileData;
                        data.m_isLiked = ChannelThreadData.m_isLiked;
                        data.m_nLikeCount = ChannelThreadData.m_nLikeCount;
                        if(ChannelThreadData.m_isNotice){
                            for(int i=0;i<m_arrSNSGroupNoticeBoardDatas.size();i++){
                                if(m_arrSNSGroupNoticeBoardDatas.get(i).m_nThreadNo == a_nBoardId){
                                    m_arrSNSGroupNoticeBoardDatas.get(i).m_strUpdatedTime = ChannelThreadData.m_strUpdatedTime;
                                    m_arrSNSGroupNoticeBoardDatas.get(i).m_nCommentCount = ChannelThreadData.m_nCommentCount;
                                    isBeforeNoticed = true;
                                }
                            }
                            if(!isBeforeNoticed) {
                                ChannelThreadData snsGroupNoticeBoardData = new ChannelThreadData();
                                snsGroupNoticeBoardData.m_nThreadNo = ChannelThreadData.m_nThreadNo;
                                snsGroupNoticeBoardData.m_strCreatedDate = ChannelThreadData.m_strCreatedDate;
                                snsGroupNoticeBoardData.m_strUpdatedTime = ChannelThreadData.m_strUpdatedTime;
                                snsGroupNoticeBoardData.m_strBody = ChannelThreadData.m_strBody;
                                m_arrSNSGroupNoticeBoardDatas.add(0, snsGroupNoticeBoardData);
                            }
                        }
                        break;
                    }
                }
                m_adapterBoardList.notifyDataSetChanged();
            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                // TODO Auto-generated method stub
                if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
                    m_Popup = new CommonPopup(getContext(), new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup)v.getTag();
                            popup.cancel();
                            popup.dismiss();
                            
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                } else if (nErrorCode == ApiResult.HTTP_SERVER_REQUEST_FAIL) {
                    if (m_arrThreadData != null) {
                        for (ChannelThreadData ChannelThreadData : m_arrThreadData) {
                            if (a_nBoardId == ChannelThreadData.m_nThreadNo) {
                                m_arrThreadData.remove(ChannelThreadData);
                                // 이유는 모르겠지만 m_nNoticed 로 하면 false로 체크되어서 m_nBoardNo으로 비교
                                if (m_arrSNSGroupNoticeBoardDatas != null) {
                                    for (int i = 0; i < m_arrSNSGroupNoticeBoardDatas.size(); i++) {
                                        if (ChannelThreadData.m_nThreadNo == m_arrSNSGroupNoticeBoardDatas.get(i).m_nThreadNo) {
                                            m_arrSNSGroupNoticeBoardDatas.remove(i);
                                            break;
                                        }
                                    }
                                }
                                break;
                            }
                        }
                    }
                    m_adapterBoardList.notifyDataSetChanged();
                }
                else
                    ((MainTabAct)getContext()).showErrorPopup(nErrorCode, strMessage);
            }
        });
    }

    private SwipeRefreshLayout.OnRefreshListener m_onTimeLineRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {

        @Override
        public void onRefresh() {
            // TODO Auto-generated method stub
            SNSGroupDetailSwifeRefreshLayout layoutSwipeRefresh = (SNSGroupDetailSwifeRefreshLayout)m_vChannelView.findViewById(R.id.layout_snsgroupdetail_swiperefresh);
            layoutSwipeRefresh.initFlag();
//			getSNSAlarm(PostGroupDetailReq.DIRECTION_TYPE_UP);
            //getSNSAlarm(PostGroupDetailReq.CALL_ALL);
            m_isGetLastBoard = false;
            m_nPage = 0;
            getSNSGroupDetail(m_nGroupId);
//			if(m_SNSGroupDetailData.m_arrBoardData != null && m_SNSGroupDetailData.m_arrBoardData.size() > 0)
//				getSNSGroupDetail(m_nGroupId, m_SNSGroupDetailData.m_arrBoardData.get(0).m_strUpdateDate, PostGroupDetailReq.DIRECTION_TYPE_UP);
//			else
//				getSNSGroupDetail(m_nGroupId , "", PostGroupDetailReq.DIRECTION_TYPE_UP);
        }
    };

    private LoadMoreListView.OnLoadMoreListener m_onTimeLineLoadMoreListener = new LoadMoreListView.OnLoadMoreListener() {

        @Override
        public void onLoadMore() {
            // TODO Auto-generated method stub
            if(!m_isGetLastBoard) {
                m_nPage++;
                getChannelThreadData(m_nGroupId, m_nPage);
            }
        }
    };

    private class ChannelNoticeListAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return m_arrChannelNoticeData.size();
        }

        @Override
        public Object getItem(int position) {
            return m_arrChannelNoticeData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null)
            {
                LayoutInflater li = LayoutInflater.from(getContext());
                convertView = li.inflate(R.layout.layout_channel_noticelist_item, parent, false);
            }

            final ChannelNoticeData noticeData = m_arrChannelNoticeData.get(position);
            RelativeLayout layoutNoticeList = (RelativeLayout)convertView.findViewById(R.id.layout_channel_noticelist);
            TextView tvNoticeListText = (TextView)convertView.findViewById(R.id.tv_channel_noticelist_text);
            tvNoticeListText.setText(noticeData.m_strTitle);

            final ArrayList<String> arrUrl = new ArrayList<String>();
            for(int i = 0; i < noticeData.m_arrChannelFileData.size(); i++){
                arrUrl.add(noticeData.m_arrChannelFileData.get(i).m_strPreviewUrl);
            }
            layoutNoticeList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), ChannelNoticeDetailAct.class);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_NAME, m_strGroupName);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_TITLE, noticeData.m_strTitle);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_BODY, noticeData.m_strBody);
                    intent.putExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_FILE, arrUrl);
                    startActivity(intent);
                }
            });
            return convertView;
        }
    }
    private class SNSBoardListAdapter extends BaseAdapter
    {
        //		private final int VIEWTYPE_SEARCH 	= 0;
        private final int VIEWTYPE_NOTICE 	= 0;
        private final int VIEWTYPE_BOARD 	= 1;
        private final int VIEWTYPE_MAX 		= 2;

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            if(m_arrSNSGroupNoticeBoardDatas == null && m_SNSGroupDetailData == null)
                return 0;

            int nCount = 0;
            if(m_arrSNSGroupNoticeBoardDatas !=null && m_arrSNSGroupNoticeBoardDatas.size() >0)
                nCount = m_arrSNSGroupNoticeBoardDatas.size();
            if(m_SNSGroupDetailData != null && m_arrThreadData.size() > 0)
                nCount += m_arrThreadData.size();

            return nCount;
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub

            if(m_arrSNSGroupNoticeBoardDatas == null && (m_SNSGroupDetailData == null || m_arrThreadData.size() == 0))
                return null;
            if(m_arrSNSGroupNoticeBoardDatas == null){
                return m_arrThreadData.get(position);
            }
            else {
                if(position < m_arrSNSGroupNoticeBoardDatas.size()){
                    return m_arrSNSGroupNoticeBoardDatas.get(position);
                }

                else {
                    if(position >= (m_arrThreadData.size() + m_arrSNSGroupNoticeBoardDatas.size())) {
                        return null;
                    } else {
                        return m_arrThreadData.get(position - m_arrSNSGroupNoticeBoardDatas.size());
                    }
                }
            }
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return 0;
        }

        @Override
        public int getViewTypeCount() {
            // TODO Auto-generated method stub
            return VIEWTYPE_MAX;
        }

        @Override
        public int getItemViewType(int position) {
            // TODO Auto-generated method stub
            if(m_arrSNSGroupNoticeBoardDatas == null)
                return VIEWTYPE_BOARD;
            else{
                if(position < m_arrSNSGroupNoticeBoardDatas.size()){
                    return VIEWTYPE_NOTICE;
                }
                else
                    return VIEWTYPE_BOARD;
            }
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            int nViewType = getItemViewType(position);
            if(convertView == null)
            {
                LayoutInflater li = LayoutInflater.from(getContext());
                if(nViewType == VIEWTYPE_NOTICE)
                    convertView = li.inflate(R.layout.layout_snsgroupdetail_notice_listitem, parent, false);
                else
                    convertView = li.inflate(R.layout.layout_snsgroupdetail_board_listitem, parent, false);
            }


            final ChannelThreadData data = (ChannelThreadData)getItem(position);

            if(nViewType == VIEWTYPE_NOTICE)
            {

                TextView tvDate = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_notice_listitem_date);
                TextView tvComment = (TextView)convertView.findViewById(R.id.tv_snsgroupdetail_notice_listitem_comment);
                SharedPref pref = SharedPref.getInstance(getContext());
                int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
                if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
                    tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14.33f);
                } else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
                    tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18.62f);
                } else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
                    tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 22.93f);
                }

                SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());
                String strDate = "";
                try {
                    Date date = sdfOriginal.parse(data.m_strCreatedDate);

                    SimpleDateFormat sdfUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
                    strDate = sdfUIPrint.format(date);
                } catch (ParseException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                if(strDate != null && !strDate.equals(""))
                    tvDate.setText(strDate);
                else
                    tvDate.setText(data.m_strCreatedDate);
                if(data.m_strBody.equals("")){
                    tvComment.setVisibility(View.GONE);
                    tvComment.setTag(data.m_nThreadNo);
                    tvComment.setOnClickListener(m_onBackgroundClickListener);
                    convertView.setTag(data.m_nThreadNo);
                    convertView.setOnClickListener(m_onBackgroundClickListener);
                } else {
                    tvComment.setVisibility(View.VISIBLE);
                    tvComment.setSingleLine(false);
                    tvComment.setEllipsize(TextUtils.TruncateAt.END);
                    tvComment.setMaxLines(2);
                    //tvComment.setMovementMethod(new Utils.MovementMethod());
                    SpannableString spanText = Utils.getHashtagString(getContext(), data.m_strBody, m_nGroupId, m_strGroupName, "", false);
                    tvComment.setOnTouchListener(new Utils.MovementMethod(spanText));
                    tvComment.setText(spanText);
                    CustomLinkify.addLinks(tvComment, CustomLinkify.ALL);

                    tvComment.setTag(data.m_nThreadNo);
                    tvComment.setOnClickListener(m_onBackgroundClickListener);
                    convertView.setTag(data.m_nThreadNo);
                    convertView.setOnClickListener(m_onBackgroundClickListener);
                }
            }
            else
            {
                RelativeLayout layoutBoard = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board);
                LinearLayout layoutCapture = (LinearLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_capture);
                LinearLayout layoutNewbar = (LinearLayout) convertView.findViewById(R.id.layout_snsgroupdetail_new_thread_bar);
                if(data.m_strThreadType.equals(JSON_THREAD_TYPE_CAPTURE)) {
                    layoutBoard.setVisibility(View.GONE);
                    layoutCapture.setVisibility(View.VISIBLE);
                    layoutNewbar.setVisibility(View.GONE);
                    TextView tvCapture = (TextView)convertView.findViewById(R.id.tv_board_capture);

                    final UserListData userInfo = TTalkDBManager.ContactsDBManager.getContacts(getContext(), data.m_nUserNo);
                    SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());
                    String strDate = "";
                    try {
                        Date createDate = sdfOriginal.parse(data.m_strCreatedDate);

                        SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
                        strDate = sdfCreateDateUIPrint.format(createDate);



                    } catch (ParseException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    tvCapture.setText(data.m_strBody);
                } else {

                    layoutBoard.setVisibility(View.VISIBLE);
                    layoutCapture.setVisibility(View.GONE);

                    LinearLayout layoutBackground = (LinearLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_background);
                    RelativeLayout layoutProfile = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_userimg);
                    ImageView ivUserImg = (ImageView) convertView.findViewById(R.id.iv_snsgroupdetail_board_listitem_userimg);
                    ImageView ivNoReadIcon = (ImageView) convertView.findViewById(R.id.iv_snsgroupdetail_board_listitem_dot);
                    TextView tvUserName = (TextView) convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_username);
                    TextView tvCompanyOrDepartment = (TextView) convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_companyordepartment);
                    TextView tvDate = (TextView) convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_date);
                    TextView tvComment = (TextView) convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_comment);
                    ImageView ivPartnerMark = (ImageView) convertView.findViewById(R.id.iv_partner_mark);


                    layoutBackground.setTag(data.m_nThreadNo);
                    layoutBackground.setOnClickListener(m_onBackgroundClickListener);
                    SharedPref pref = SharedPref.getInstance(getContext());
                    int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
                    if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL) {
                        tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14.33f);
                    } else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL) {
                        tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18.62f);
                    } else if (nSaveTextSize == StaticString.SETTEXTSIZE_BIG) {
                        tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 22.93f);
                    }
                    TextView tvReplyCount = (TextView) convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_replycount);

                    layoutProfile.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            doShowProfile(data.m_nUserNo);
                        }
                    });

                    App.imageloader.cancelDownload(ivUserImg);
                    App.imageloader.getProfileImage(ivUserImg, App.getImageDownLoaderUrl(data.m_nUserNo, true), R.drawable.profile_pic_default, false);

                    final UserListData userInfo = TTalkDBManager.ContactsDBManager.getContacts(getContext(), data.m_nUserNo);

                    tvUserName.setText(userInfo.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
                    //파트너 마크표사
                    if (App.m_arrUserListData.get(data.m_nUserNo) != null) {
                        String a_userType = App.m_arrUserListData.get(data.m_nUserNo).m_strUserType;
                        if (a_userType.equals("P")) {
                            ivPartnerMark.setVisibility(View.VISIBLE);
                            tvCompanyOrDepartment.setText(userInfo.m_PersonalData.mapPersonalData.get(PersonalData.AFFILIATION));
                        } else {
                            tvCompanyOrDepartment.setText(userInfo.m_PersonalData.mapPersonalData.get(PersonalData.DEPARTMENT) + " | " + userInfo.m_PersonalData.mapPersonalData.get(PersonalData.COMPANY_NAME));
                            ivPartnerMark.setVisibility(View.GONE);
                        }
                    }

                    if (!data.m_isRead) {
                        ivNoReadIcon.setVisibility(View.VISIBLE);

                        if(getItem(position + 1) != null) {
                            ChannelThreadData afterData = (ChannelThreadData) getItem(position + 1);
                            if(afterData.m_isRead && !m_isAlreadyNewBar){
                                layoutNewbar.setVisibility(View.VISIBLE);
                                m_isAlreadyNewBar = true;
                            } else {
                                layoutNewbar.setVisibility(View.GONE);
                            }
                        } else {
                            layoutNewbar.setVisibility(View.GONE);
                        }
                    } else {
                        ivNoReadIcon.setVisibility(View.GONE);
                        layoutNewbar.setVisibility(View.GONE);
                    }
				/*if(m_arrNoReadBoard.contains(data.m_nBoardNo)){
					ivNoReadIcon.setVisibility(View.VISIBLE);
				} else {
					ivNoReadIcon.setVisibility(View.GONE);
				}*/

                    SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());
                    String strDate = "";
                    try {
                        Date createDate = sdfOriginal.parse(data.m_strCreatedDate);

                        SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
                        strDate = sdfCreateDateUIPrint.format(createDate);



                    } catch (ParseException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    if (strDate != null && !strDate.equals(""))
                        tvDate.setText(strDate);
                    else
                        tvDate.setText(data.m_strCreatedDate);

                    String strComment;
                    if (data.m_strBody.length() > 300)
                        strComment = data.m_strBody.substring(0, 299) + "...";
                    else
                        strComment = data.m_strBody;

                    if (data.m_strBody.equals("")) {
                        tvComment.setVisibility(View.GONE);
                    } else {
                        tvComment.setVisibility(View.VISIBLE);
                        //tvComment.setText(Utils.getHashtagString(getContext(), strComment, m_nGroupId, m_strGroupName, "", false));

                        //tvComment.setLinksClickable(false);
                        tvComment.setTag(data.m_nThreadNo);
                        tvComment.setSingleLine(false);
                        tvComment.setEllipsize(TextUtils.TruncateAt.END);
                        tvComment.setMaxLines(3);
                        tvComment.setOnClickListener(m_onBackgroundClickListener);
                        SpannableString spanText = Utils.getHashtagString(getContext(), data.m_strBody, m_nGroupId, m_strGroupName, "", false);
                        tvComment.setOnTouchListener(new Utils.MovementMethod(spanText));
                        tvComment.setText(spanText);
                        CustomLinkify.addLinks(tvComment, CustomLinkify.ALL);
                    }
                    tvReplyCount.setText("" + data.m_nCommentCount);

                    RelativeLayout layoutReply = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_reply);
                    //LinearLayout layoutWriteReply = (LinearLayout)convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_writereply);
                    RelativeLayout layoutLike = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_like);
                    final ImageView ivLike = (ImageView) convertView.findViewById(R.id.iv_snsgroupdetail_board_listitem_like);
                    final TextView tvLike = (TextView) convertView.findViewById(R.id.tv_snsgroupdetail_board_listitem_like);
                    layoutReply.setTag(data.m_nThreadNo);
                    layoutLike.setTag(data.m_isLiked);
                    if (data.m_isLiked) {
                        ivLike.setBackgroundResource(R.drawable.ic_btn_like_click);
                        tvLike.setText("" + data.m_nLikeCount);
                    } else {
                        ivLike.setBackgroundResource(R.drawable.ic_btn_like);
                        tvLike.setText("" + data.m_nLikeCount);
                    }
                    layoutReply.setOnClickListener(m_onReplyClickListener);
                    layoutLike.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(final View v) {
                            if (!(boolean) v.getTag()) {

                                PostBoardLikeReq reqGroupBoardLike = new PostBoardLikeReq(m_nGroupId, data.m_nThreadNo);
                                WebAPI webApi = new WebAPI(getContext());
                                webApi.request(reqGroupBoardLike, new WebListener() {

                                    @Override
                                    public void onPreRequest() {
                                        // TODO Auto-generated method stub
                                        showProgress();
                                    }

                                    @Override
                                    public void onNetworkError(int nErrorCode, String strMessage) {
                                        // TODO Auto-generated method stub
                                        closeProgress();
                                        ((MainTabAct) getContext()).showErrorPopup(nErrorCode, strMessage);
                                    }

                                    @Override
                                    public void onPostRequest(String a_strData) {
                                        // TODO Auto-generated method stub
                                        closeProgress();
                                        //원래 좋아요 상태가 아니었던 경우
                                        ivLike.setBackgroundResource(R.drawable.ic_btn_like_click);
                                        if (!data.m_isLiked)
                                            tvLike.setText("" + (data.m_nLikeCount + 1));
                                            //원래 좋아요 상태 였던 경우
                                        else
                                            tvLike.setText("" + (data.m_nLikeCount));
                                        v.setTag(true);
                                    }
                                });
                            } else {
                                DeleteBoardLikeReq reqGroupBoardLike = new DeleteBoardLikeReq(m_nGroupId, data.m_nThreadNo);
                                WebAPI webApi = new WebAPI(getContext());
                                webApi.request(reqGroupBoardLike, new WebListener() {

                                    @Override
                                    public void onPreRequest() {
                                        // TODO Auto-generated method stub
                                        showProgress();
                                    }

                                    @Override
                                    public void onNetworkError(int nErrorCode, String strMessage) {
                                        // TODO Auto-generated method stub
                                        closeProgress();
                                        ((MainTabAct) getContext()).showErrorPopup(nErrorCode, strMessage);
                                    }

                                    @Override
                                    public void onPostRequest(String a_strData) {
                                        // TODO Auto-generated method stub
                                        closeProgress();
                                        //원래 좋아요 상태가 아니었던 경우
                                        ivLike.setBackgroundResource(R.drawable.ic_btn_like);
                                        if (!data.m_isLiked)
                                            tvLike.setText("" + (data.m_nLikeCount));
                                            //원래 좋아요 상태 였던 경우
                                        else
                                            tvLike.setText("" + (data.m_nLikeCount - 1));
                                        v.setTag(false);
                                    }
                                });
                            }
                        }
                    });

                    RelativeLayout layoutAttachFileList = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_listitem_contents_attachfiles);
                    RelativeLayout layoutAttachFile = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_listitem_contents_attachfile);
                    RelativeLayout layoutPicture1 = (RelativeLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_contents_pics_1);
                    ImageView ivPicture1 = (ImageView) convertView.findViewById(R.id.iv_one_pic_image);
                    ImageView ivVodPic1 = (ImageView) convertView.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay_for_oneImage);
                    LinearLayout layoutPicture2 = (LinearLayout) convertView.findViewById(R.id.layout_snsgroupdetail_board_listitem_contents_pics_2);
                    ImageView ivPicture2_1 = (ImageView) convertView.findViewById(R.id.iv_two_pic_image1);
                    ImageView ivVodPic2_1 = (ImageView) convertView.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay_image1);
                    ImageView ivPicture2_2 = (ImageView) convertView.findViewById(R.id.iv_two_pic_image2);
                    ImageView ivVodPic2_2 = (ImageView) convertView.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay_image2);
                    HorizontalScrollView hsImages = (HorizontalScrollView) convertView.findViewById(R.id.hs_sns_images);
                    LinearLayout layoutImage = (LinearLayout) convertView.findViewById(R.id.layout_sns_image);
                    ArrayList<ChannelFileData> arrPictureData = new ArrayList<ChannelFileData>();
                    ArrayList<ChannelFileData> arrFileData = new ArrayList<ChannelFileData>();
                    if (data.m_arrChannelFileData != null && data.m_arrChannelFileData.size() > 0) {
                        for (ChannelFileData fileData : data.m_arrChannelFileData) {
                            if (fileData.m_strType.equals(StaticString.FILE_TYPE_IMAGE) || (fileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) && !fileData.m_strPreviewUrl.isEmpty())) {

                                arrPictureData.add(fileData);
                            } else {
                                arrFileData.add(fileData);
                            }
                        }
                        if (arrFileData.size() == 1) {
                            ImageView ivFileIcon = (ImageView) layoutAttachFile.findViewById(R.id.iv_file_icon);
                            TextView tvFileName = (TextView) layoutAttachFile.findViewById(R.id.tv_snsgroupdetail_listitem_file_filename_1);
                            TextView tvFileSize = (TextView) layoutAttachFile.findViewById(R.id.tv_snsboarddetail_listitem_file_filesize);
                            TextView tvFileLinker = (TextView) layoutAttachFile.findViewById(R.id.tv_snsboarddetail_listitem_file_filelinkername);

                            if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
                                tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f);
                            } else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
                                tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f);
                            } else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
                                tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f);
                            }
                            String extension = arrFileData.get(0).m_strFileName.substring(arrFileData.get(0).m_strFileName.lastIndexOf(".") + 1, arrFileData.get(0).m_strFileName.length());
                            extension = extension.toLowerCase();
                            if (extension.equalsIgnoreCase("txt")) {
                                ivFileIcon.setImageResource(R.drawable.icon_text_s);
                                tvFileLinker.setText(R.string.snsfile_text);
                            } else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
                                ivFileIcon.setImageResource(R.drawable.icon_word_s);
                                tvFileLinker.setText(R.string.snsfile_word);
                            } else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
                                ivFileIcon.setImageResource(R.drawable.icon_excel);
                                tvFileLinker.setText(R.string.snsfile_excel);
                            } else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
                                ivFileIcon.setImageResource(R.drawable.icon_ppt);
                                tvFileLinker.setText(R.string.snsfile_ppt);
                            } else if (extension.equalsIgnoreCase("pdf")) {
                                ivFileIcon.setImageResource(R.drawable.icon_pdf);
                                tvFileLinker.setText(R.string.snsfile_pdf);
                            } else if (extension.equalsIgnoreCase("hwp")) {
                                ivFileIcon.setImageResource(R.drawable.icon_han_s);
                                tvFileLinker.setText(R.string.snsfile_han);
                            } else if (extension.equalsIgnoreCase("png") || extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("jpeg") || extension.equalsIgnoreCase("bmp")){
                                ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                                tvFileLinker.setText(R.string.snsfile_image);
                            } else if (extension.equalsIgnoreCase("avi") || extension.equalsIgnoreCase("asf") || extension.equalsIgnoreCase("mov") || extension.equalsIgnoreCase("mp4") || extension.equalsIgnoreCase("wmv")){
                                ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                                tvFileLinker.setText(R.string.snsfile_video);
                            } else if (extension.equalsIgnoreCase("vcf")) {
                                ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                                tvFileLinker.setText(R.string.snsfile_vcf);
                            } else if (extension.equalsIgnoreCase("zip")) {
                                ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                                tvFileLinker.setText(R.string.snsfile_zip);
                            }
                            else {
                                ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                            }
                            float fFileSize = Utils.bytesToMegabyteFloat(arrFileData.get(0).m_lnFileSize);
                            if (fFileSize == 0.0)
                                fFileSize = 0.1F;
                            tvFileSize.setText(fFileSize + " MB");
                            layoutAttachFile.setVisibility(View.VISIBLE);
                            layoutAttachFileList.setVisibility(View.GONE);

                            //View vFile = li.inflate(R.layout.layout_snsboarddetail_listitem_file, layoutAttachFileList, false);
						/*TextView tvFileSize = (TextView)layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_listitem_file_filesize);*/

                            tvFileName.setText(arrFileData.get(0).m_strFileName);
						/*float fFileSize = Utils.bytesToMegabyteFloat(arrFileData.get(0).m_lnFileSize);
						if(fFileSize == 0.0)
							fFileSize = 0.1F;*/

						/*tvFileSize.setText(String.format(getString(R.string.snsboarddetail_filesize), fFileSize));*/
                        } else if (arrFileData.size() > 1) {
                            TextView tvAllFileCount = (TextView) layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_allfilecount);
                            tvAllFileCount.setText("" + arrFileData.size());
                            layoutAttachFile.setVisibility(View.GONE);
                            layoutAttachFileList.setVisibility(View.VISIBLE);
                            //View vFile = li.inflate(R.layout.layout_snsboarddetail_listitem_file, layoutAttachFileList, false);
                            TextView tvFileName = (TextView) layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_listitem_file_filename);
						/*TextView tvFileSize = (TextView)layoutAttachFileList.findViewById(R.id.tv_snsgroupdetail_listitem_file_filesize);*/
                            if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
                                tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 10f);
                            } else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
                                tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f);
                            } else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
                                tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f);
                            }
                            tvFileName.setText(arrFileData.get(0).m_strFileName);
						/*float fFileSize = Utils.bytesToMegabyteFloat(arrFileData.get(0).m_lnFileSize);
						if(fFileSize == 0.0)
							fFileSize = 0.1F;*/

						/*tvFileSize.setText(String.format(getString(R.string.snsboarddetail_filesize), fFileSize));*/
                        } else {
                            layoutAttachFile.setVisibility(View.GONE);
                            layoutAttachFileList.setVisibility(View.GONE);
                        }
                        if (arrPictureData != null && arrPictureData.size() == 1) {
                            layoutPicture1.setVisibility(View.VISIBLE);
                            ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(getContext());
                            imageLoaderMng.cancelDownload(ivPicture1);
                            Bitmap bmp = imageLoaderMng.getLocalImage(arrPictureData.get(0).m_strPreviewUrl);
                            if (bmp == null)
                                imageLoaderMng.getImage(ivPicture1, arrPictureData.get(0).m_strPreviewUrl, 0);
                            else
                                ivPicture1.setImageBitmap(bmp);
                            layoutPicture2.setVisibility(View.GONE);
                            hsImages.setVisibility(View.GONE);
                            if (arrPictureData.get(0).m_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
                                ivVodPic1.setVisibility(View.VISIBLE);
                            } else
                                ivVodPic1.setVisibility(View.GONE);
                        } else if (arrPictureData != null && arrPictureData.size() == 2) {
                            layoutPicture2.setVisibility(View.VISIBLE);
                            ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(getContext());
                            imageLoaderMng.cancelDownload(ivPicture2_1);
                            Bitmap bmp = imageLoaderMng.getLocalImage(arrPictureData.get(0).m_strPreviewUrl);
                            if (bmp == null)
                                imageLoaderMng.getImage(ivPicture2_1, arrPictureData.get(0).m_strPreviewUrl, 0);
                            else
                                ivPicture2_1.setImageBitmap(bmp);
                            if (arrPictureData.get(0).m_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
                                ivVodPic2_1.setVisibility(View.VISIBLE);
                            } else
                                ivVodPic2_1.setVisibility(View.GONE);


                            imageLoaderMng.cancelDownload(ivPicture2_2);
                            Bitmap bmp2 = imageLoaderMng.getLocalImage(arrPictureData.get(1).m_strPreviewUrl);
                            if (bmp == null)
                                imageLoaderMng.getImage(ivPicture2_2, arrPictureData.get(1).m_strPreviewUrl, 0);
                            else
                                ivPicture2_2.setImageBitmap(bmp2);
                            if (arrPictureData.get(1).m_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
                                ivVodPic2_2.setVisibility(View.VISIBLE);
                            } else
                                ivVodPic2_2.setVisibility(View.GONE);

                            layoutPicture1.setVisibility(View.GONE);
                            hsImages.setVisibility(View.GONE);
                        } else if (arrPictureData != null && arrPictureData.size() >= 3) {
                            hsImages.setVisibility(View.VISIBLE);
                            layoutImage.removeAllViews();
                            ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(getContext());
                            for (ChannelFileData fileData : arrPictureData) {
                                final RelativeLayout snsScrollImage = (RelativeLayout) getActivity().getLayoutInflater().inflate(R.layout.layout_snsgroupdetail_listitem_picture, null);
                                ImageView ivSNSImage = (ImageView) snsScrollImage.findViewById(R.id.iv_snsgroupdetail_listitem_picture);
                                imageLoaderMng.cancelDownload(ivSNSImage);
                                Bitmap bmp = imageLoaderMng.getLocalImage(fileData.m_strPreviewUrl);
                                if (bmp == null)
                                    imageLoaderMng.getImage(ivSNSImage, fileData.m_strPreviewUrl, 0);
                                else
                                    ivSNSImage.setImageBitmap(bmp);

                                ImageView ivVodPlay = (ImageView) snsScrollImage.findViewById(R.id.iv_snsgroupdetail_listitem_vodplay);
                                if (fileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
                                    ivVodPlay.setVisibility(View.VISIBLE);
                                } else
                                    ivVodPlay.setVisibility(View.GONE);

                                snsScrollImage.setOnClickListener(new View.OnClickListener() {

                                    @Override
                                    public void onClick(View v) {
                                        // TODO Auto-generated method stub
                                        startSNSBoardDetailAct(false, m_nGroupId, m_SNSGroupDetailData.m_strName, data.m_nThreadNo, false, false, false);
                                    }
                                });
                                layoutImage.addView(snsScrollImage);
                            }
                            layoutPicture1.setVisibility(View.GONE);
                            layoutPicture2.setVisibility(View.GONE);
                        } else {
                            layoutPicture1.setVisibility(View.GONE);
                            layoutPicture2.setVisibility(View.GONE);
                            hsImages.setVisibility(View.GONE);
                        }
                    } else {
                        layoutAttachFileList.setVisibility(View.GONE);
                        layoutAttachFile.setVisibility(View.GONE);
                        layoutPicture1.setVisibility(View.GONE);
                        layoutPicture2.setVisibility(View.GONE);
                        hsImages.setVisibility(View.GONE);
                    }
                }
            }
            return convertView;
        }

        private View.OnClickListener m_onReplyClickListener = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Integer nBoardId = (Integer)v.getTag();
                startSNSBoardDetailAct(false, m_nGroupId, m_SNSGroupDetailData.m_strName, nBoardId, false, false, true);
            }
        };

        private View.OnClickListener m_onBackgroundClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer nBoardId = (Integer)v.getTag();
                startSNSBoardDetailAct(false, m_nGroupId, m_SNSGroupDetailData.m_strName, nBoardId, false, false, false);
            }
        };


        private View.OnClickListener m_onLikeClickListener = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                PostBoardLikeReq reqGroupNotice = new PostBoardLikeReq(m_nGroupId, (Integer)v.getTag());
                WebAPI webApi = new WebAPI(getContext());
                webApi.request(reqGroupNotice, new WebListener() {

                    @Override
                    public void onPreRequest() {
                        // TODO Auto-generated method stub

                    }

                    @Override
                    public void onNetworkError(int nErrorCode, String strMessage) {
                        // TODO Auto-generated method stub
                        ((MainTabAct)getContext()).showErrorPopup(nErrorCode, strMessage);
                    }

                    @Override
                    public void onPostRequest(String a_strData) {
                        // TODO Auto-generated method stub


                    }
                });
            }
        };
    }


    private void isCheckShowPopup() {
        if (((MainTabAct)getContext()).m_isRunning) {
            m_Popup.show();
        }
    }

    private void doShowProfile(int a_nUserNo)
    {
        Intent intent = new Intent(getContext(), ProfileViewPopupAct.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, a_nUserNo);
        startActivityForResult(intent, StaticString.REQUESTCODE_PROFILEVIEW);
    }

    public void showProgress() {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(getContext());

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void showProgress(String a_strMsg) {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(getContext(), a_strMsg);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void closeProgress() {
        if (m_Progress != null && m_Progress.isShowing())
            m_Progress.cancel();
    }

    synchronized public void requestAddedByUserList(int[] nUserIDs, final ArrayList<ChannelThreadData> arrThreadData){
        GetUserInfoReq req = new GetUserInfoReq(nUserIDs);
        WebAPI webApi = new WebAPI(getActivity());
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                closeProgress();
                GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

                for (int i = 0; i < res.getUserListData().size(); i++) {
                    UserListData getItem = res.getUserListData().get(i);
                    if (getItem != null) {
                        TTalkDBManager.ContactsDBManager.insertContacts(getActivity(), getItem);
                    }
                }
                if(m_nPage > 0){
                    m_adapterBoardList.notifyDataSetChanged();
                } else {
                    setUI();
                }
                requestReadThread(arrThreadData);
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((MainTabAct) getContext()).showErrorPopup(a_nErrorCode, a_strMessage);
            }
        });
    }
}
