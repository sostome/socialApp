package com.gmp.rusk.request;



/**
 *	@author subi78
 *			동료 목록 조회 - 초기
 *			method : get
 */

public class GetFellowListReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";
	
	
	public GetFellowListReq()
	{
		APINAME = APINAME +"/"+App.m_EntryData.m_nUserNo+"/buddy";
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
