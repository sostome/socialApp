package com.gmp.rusk.request;

/**
 *	@author dym
 *			모임 권한 양도
 *			method : put
 */

public class PutGroupOwnerReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";
	
	public PutGroupOwnerReq(int a_nGroupId, int a_nUserNo)
	{
		APINAME = APINAME +"/" + a_nGroupId + "/member/" + a_nUserNo + "/owner";
	}
	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
