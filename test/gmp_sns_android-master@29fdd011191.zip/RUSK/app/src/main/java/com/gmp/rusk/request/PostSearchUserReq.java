package com.gmp.rusk.request;

import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 *	@author dym
 *			파트너 검색 
 *			method : post
 */

public class PostSearchUserReq extends Req{

	public static final String SEARCH_ALL = "all";
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";
	
	private final String JSON_KEYWORD = "keyword";
	
	private String m_strKeyword = "";
	
	public PostSearchUserReq(String a_strKeyword, String a_strCompanyCode)
	{
		try {
			a_strKeyword = URLEncoder.encode(a_strKeyword, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if(!a_strCompanyCode.equals(SEARCH_ALL))
			APINAME = APINAME +"/search/" + "?keyword=" + a_strKeyword + "&companyCode=" + a_strCompanyCode + "&sort=name" + "&size=100000";
		else
			APINAME = APINAME +"/search/" + "?keyword=" + a_strKeyword + "&companyCode=ALL" + "&sort=name" + "&size=100000";

		m_strKeyword = a_strKeyword;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		/*try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_KEYWORD, m_strKeyword);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PostSearchUserReq", "" + e.toString());
			return "";
		}*/
		return  "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
