package com.gmp.rusk.db;

import java.util.ArrayList;
import java.util.Calendar;

import com.gmp.rusk.datamodel.SNSAlarmData;
import com.gmp.rusk.datamodel.SNSGroupData;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.util.SparseArray;
import android.util.SparseBooleanArray;

public class SNSGroupDBAdapter {
	
	// Database File Name
	private static final String DATABASE_NAME 					= "ttalk_snsgroup.db";
	
	// SNS Alarm Table
	private static final String TABLE_SNSALARM		 			= "SNSAlarm";
	
	// SNS My Group Info Table
	private static final String TABLE_SNSMYGROUPINFO	 		= "SNSMyGroupInfo";
	
	// Common Table Field Name
	public static final String KEY_IDX							= "idx";				// idx

	// SNS Alarm Table Field Name
	public static final String KEY_SNSALARM_GROUPID				= "groupId";				// SNS Group ID
	public static final String KEY_SNSALARM_GROUPNAME			= "groupName";				// SNS Group Name
	public static final String KEY_SNSALARM_BOARDNO				= "boardNo";				// SNS Board NO
	public static final String KEY_SNSALARM_REPLYNO				= "replyNo";				// SNS Reply NO
	public static final String KEY_SNSALARM_MSG					= "msg";					// Alarm Message
	public static final String KEY_SNSALARM_COMMENT				= "comment";				// Alarm Comment
	public static final String KEY_SNSALARM_USERNO				= "userNo";					// User No
	public static final String KEY_SNSALARM_BOARDUSERIMAGEURL	= "boardUserImageUser";		// Board User Image Url
	public static final String KEY_SNSALARM_TYPE				= "type";					// Alarm Type
	public static final String KEY_SNSALARM_CREATEDDATE			= "createdDate";			// Create Date
	public static final String KEY_SNSALARM_UPDATEDDATE			= "updatedDate";			// Update Date
	public static final String KEY_SNSALARM_ISDELETED			= "isDeleted";				// is Deleted
	public static final String KEY_SNSALARM_ISALARMREAD			= "isAlarmRead";			// is Alarm Read
	public static final String KEY_SNSALARM_ISBOARDREAD			= "isBoardRead";			// is Board Read
	public static final String KEY_SNSALARM_CREATEMS			= "createMS";				// Create Millisecond
	
	// SNS My Group Info Table Field Name
	public static final String KEY_SNSMYGROUPINFO_GROUPID		= "groupId";				// SNS Group ID
	public static final String KEY_SNSMYGROUPINFO_ISFAVORITE	= "isFavorite";				// is Favorite

	// Create Table Query
	private final String SNSALARM_CREATE = "create table " + TABLE_SNSALARM + " (" + 
												KEY_IDX 						+ " integer primary key autoincrement, " +
												KEY_SNSALARM_GROUPID 			+ " integer not null, " +
												KEY_SNSALARM_GROUPNAME			+ " text, " +
												KEY_SNSALARM_BOARDNO 			+ " integer not null, " +
												KEY_SNSALARM_REPLYNO 			+ " integer, " +
												KEY_SNSALARM_MSG				+ " text, " +
												KEY_SNSALARM_COMMENT			+ " text, " +
												KEY_SNSALARM_USERNO 			+ " integer, " +
												KEY_SNSALARM_BOARDUSERIMAGEURL 	+ " text, " +
												KEY_SNSALARM_TYPE 				+ " text not null, " +
												KEY_SNSALARM_CREATEDDATE 		+ " text not null, " +
												KEY_SNSALARM_UPDATEDDATE 		+ " text not null, " +
												KEY_SNSALARM_ISDELETED 			+ " interger not null, " +
												KEY_SNSALARM_ISALARMREAD 		+ " interger not null, " +
												KEY_SNSALARM_ISBOARDREAD 		+ " interger not null, " +
												KEY_SNSALARM_CREATEMS			+ " long not null);";
	
	// Create Table Query 
	private final String SNSMYGROUPINFO_CREATE = "create table " + TABLE_SNSMYGROUPINFO + " (" +
												KEY_IDX 								+ " integer primary key autoincrement, " +
												KEY_SNSMYGROUPINFO_GROUPID				+ " integer not null unique, " +
												KEY_SNSMYGROUPINFO_ISFAVORITE			+ " integer not null);";
	
	
	// Drop Table Query 
	private final String SNSALARM_DROP = "DROP TABLE IF EXISTS " + TABLE_SNSALARM;
	private final String SNSMYGROUPINFO_DROP = "DROP TABLE IF EXISTS " + TABLE_SNSMYGROUPINFO;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private FavoriteGroupDBHelper m_dbHelper = null;
	
	public SNSGroupDBAdapter(Context context)
	{
		m_context = context;
		m_dbHelper = new FavoriteGroupDBHelper(m_context, DATABASE_NAME, null, DatabaseDefine.DATABASE_VERSION);
	}
	
	// Database Open Read & Write Permission
	public SNSGroupDBAdapter open() throws SQLException
	{
		m_db = m_dbHelper.getWritableDatabase();
		return this;
	}
	
	// Database Open Read Permission
	public SNSGroupDBAdapter openReadOnly() throws SQLException
	{
		m_db = m_dbHelper.getReadableDatabase();
		return this;
	}
	
	// Database Close
	public void close()
	{
		m_db.close();
	}
	
	public int insertSNSAlarm(SNSAlarmData a_data)
	{
		long lnRowId = 0;
		
		if(a_data == null)
			return -1;
		
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_GROUPID, a_data.m_nGroupId);
			value.put(KEY_SNSALARM_BOARDNO, a_data.m_nBoardNo);
			value.put(KEY_SNSALARM_REPLYNO, a_data.m_nReplyNo);
			value.put(KEY_SNSALARM_USERNO, a_data.m_nUserNo);
			value.put(KEY_SNSALARM_BOARDUSERIMAGEURL, a_data.m_strUserImagerUrl);
			value.put(KEY_SNSALARM_TYPE, a_data.m_strType);
			value.put(KEY_SNSALARM_CREATEDDATE, a_data.m_strCreateDate);
			value.put(KEY_SNSALARM_UPDATEDDATE, a_data.m_strUpdateDate);
			value.put(KEY_SNSALARM_ISDELETED, a_data.m_isDeleted ? 1 : 0);
			value.put(KEY_SNSALARM_ISALARMREAD, a_data.m_isAlarmRead ? 1 : 0);
			value.put(KEY_SNSALARM_ISBOARDREAD, a_data.m_isBoardRead ? 1 : 0);
			value.put(KEY_SNSALARM_GROUPNAME, a_data.m_strGroupName);
			value.put(KEY_SNSALARM_COMMENT, a_data.m_strComment);
			value.put(KEY_SNSALARM_MSG, a_data.m_strMsg);
			value.put(KEY_SNSALARM_CREATEMS, a_data.m_lnCreateMillisecond);
			
			lnRowId = m_db.insert(TABLE_SNSALARM, null, value);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			lnRowId = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return (int)lnRowId;
	}
	
	public int insertSNSAlarm(ArrayList<SNSAlarmData> a_arrData)
	{
		int nCount = 0;
		
		if(a_arrData == null || a_arrData.size() == 0)
			return -1;
		
		try
		{
			m_db.beginTransaction();
			for(SNSAlarmData data : a_arrData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_SNSALARM_GROUPID, data.m_nGroupId);
				value.put(KEY_SNSALARM_BOARDNO, data.m_nBoardNo);
				value.put(KEY_SNSALARM_REPLYNO, data.m_nReplyNo);
				value.put(KEY_SNSALARM_USERNO, data.m_nUserNo);
				value.put(KEY_SNSALARM_BOARDUSERIMAGEURL, data.m_strUserImagerUrl);
				value.put(KEY_SNSALARM_TYPE, data.m_strType);
				value.put(KEY_SNSALARM_CREATEDDATE, data.m_strCreateDate);
				value.put(KEY_SNSALARM_UPDATEDDATE, data.m_strUpdateDate);
				value.put(KEY_SNSALARM_ISDELETED, data.m_isDeleted ? 1 : 0);
				value.put(KEY_SNSALARM_ISALARMREAD, data.m_isAlarmRead ? 1 : 0);
				value.put(KEY_SNSALARM_ISBOARDREAD, data.m_isBoardRead ? 1 : 0);
				value.put(KEY_SNSALARM_GROUPNAME, data.m_strGroupName);
				value.put(KEY_SNSALARM_COMMENT, data.m_strComment);
				value.put(KEY_SNSALARM_MSG, data.m_strMsg);
				value.put(KEY_SNSALARM_CREATEMS, data.m_lnCreateMillisecond);
				
				m_db.insert(TABLE_SNSALARM, null, value);
				nCount++;
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int insertSNSMyGroupInfo(int a_nGroupId)
	{
		long lnRowId = 0;
		
		if(a_nGroupId < 0)
			return -1;
		
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_SNSMYGROUPINFO_GROUPID, a_nGroupId);
			value.put(KEY_SNSMYGROUPINFO_ISFAVORITE, 0);
			
			lnRowId = m_db.insert(TABLE_SNSMYGROUPINFO, null, value);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			lnRowId = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return (int)lnRowId;
	}
	
	public int insertSNSMyGroupInfo(ArrayList<SNSGroupData> a_arrData)
	{
		int nCount = 0;
		
		if(a_arrData == null || a_arrData.size() == 0)
			return -1;
		
		try
		{
			m_db.beginTransaction();
			for(SNSGroupData data : a_arrData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_SNSMYGROUPINFO_GROUPID, data.m_nGroupId);
				value.put(KEY_SNSMYGROUPINFO_ISFAVORITE, data.m_isFavorite);
				m_db.insert(TABLE_SNSMYGROUPINFO, null, value);
				nCount++;
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateAlarmSNSGroupName(ArrayList<SNSGroupData> a_arrSNSGroupData)
	{
		if(a_arrSNSGroupData == null || a_arrSNSGroupData.size() == 0)
			return -1;
		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			for(SNSGroupData data : a_arrSNSGroupData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_SNSALARM_GROUPNAME, data.m_strGroupName);
				m_db.update(TABLE_SNSALARM, value, KEY_SNSALARM_GROUPID + "=" + data.m_nGroupId, null);
				nCount++;
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateSNSAlarmIsDelete(int a_nIdx, boolean a_isDelete)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISDELETED, a_isDelete ? 1 : 0);
			nCount = m_db.update(TABLE_SNSALARM, value, KEY_IDX + "=" + a_nIdx, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsAlarmRead(int a_nIdx, boolean a_isRead)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISALARMREAD, a_isRead ? 1 : 0);
			nCount = m_db.update(TABLE_SNSALARM, value, KEY_IDX + "=" + a_nIdx, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateIsAlarmRead(boolean a_isRead)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISALARMREAD, a_isRead ? 1 : 0);
			m_db.update(TABLE_SNSALARM, value, null, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsAlarmRead(SparseArray<Boolean> a_arrIsRead)
	{
		if(a_arrIsRead == null || a_arrIsRead.size() == 0)
			return -1;
		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			int nSize = a_arrIsRead.size();
			
			for(int i = 0; i < nSize; i++)
			{
				int nKey = a_arrIsRead.keyAt(i);
				Boolean isRead = a_arrIsRead.get(nKey);
				
				ContentValues value = new ContentValues();
				value.put(KEY_SNSALARM_ISALARMREAD, isRead ? 1 : 0);
				m_db.update(TABLE_SNSALARM, value, KEY_IDX + "=" + nKey, null);
				nCount++;
			}
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsBoardRead(int a_nIdx, boolean a_isRead)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISBOARDREAD, a_isRead ? 1 : 0);
			nCount = m_db.update(TABLE_SNSALARM, value, KEY_IDX + "=" + a_nIdx, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsBoardRead(int a_nGroupId, SparseBooleanArray a_arrIsRead)
	{
		if(a_arrIsRead == null || a_arrIsRead.size() == 0)
			return -1;
		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			int nSize = a_arrIsRead.size();
			
			for(int i = 0; i < nSize; i++)
			{
				int nBoardId = a_arrIsRead.keyAt(i);
				Boolean isRead = a_arrIsRead.get(nBoardId);
				
				ContentValues value = new ContentValues();
				value.put(KEY_SNSALARM_ISBOARDREAD, isRead ? 1 : 0);
				
				String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_BOARDNO + "=" + nBoardId;
				
				m_db.update(TABLE_SNSALARM, value, strWhere, null);
				nCount++;
			}
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsBoardRead(int a_nGroupId, int a_nBoardId, boolean a_isRead)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISBOARDREAD, a_isRead ? 1 : 0);
			String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_BOARDNO + "=" + a_nBoardId;
			nCount = m_db.update(TABLE_SNSALARM, value, strWhere, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateIsReplyRead(int a_nGroupId, int a_nBoardId, boolean a_isRead)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISBOARDREAD, a_isRead ? 1 : 0);
			String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_BOARDNO + "=" + a_nBoardId + " AND " + KEY_SNSALARM_REPLYNO + " != -1";
			nCount = m_db.update(TABLE_SNSALARM, value, strWhere, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsDeleted(int a_nIdx, boolean a_isDeleted)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSALARM_ISDELETED, a_isDeleted ? 1 : 0);
			nCount = m_db.update(TABLE_SNSALARM, value, KEY_IDX + "=" + a_nIdx, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateReadBoardAndReply(ArrayList<Integer> a_arrReadBoardAndReplyNos)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			int nSize = a_arrReadBoardAndReplyNos.size();
			for(int i = 0; i < nSize; i++)
			{
				int nNo = a_arrReadBoardAndReplyNos.get(i);
				ContentValues value = new ContentValues();
				value.put(KEY_SNSALARM_ISBOARDREAD, 1);
				nCount = m_db.update(TABLE_SNSALARM, value, KEY_SNSALARM_BOARDNO + "=" + nNo + " OR " + KEY_SNSALARM_REPLYNO + "=" + nNo, null);
			}
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	// Key : KEY_IDX, Value : isRead
	public int updateIsFavorite(int a_nGroupId, boolean a_isFavorite)
	{		
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_SNSMYGROUPINFO_ISFAVORITE, a_isFavorite ? 1 : 0);
			nCount = m_db.update(TABLE_SNSMYGROUPINFO, value, KEY_SNSMYGROUPINFO_GROUPID + "=" + a_nGroupId, null);
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int deleteSNSAlarm()
	{
		return m_db.delete(TABLE_SNSALARM, null, null);
	}
	
	public int deleteSNSAlarm(int a_nIdx)
	{
		return m_db.delete(TABLE_SNSALARM, KEY_IDX + "=" + a_nIdx, null);
	}
	
	public int deleteSNSAlarmWhereBoardId(int a_nBoardId)
	{
		return m_db.delete(TABLE_SNSALARM, KEY_SNSALARM_BOARDNO + "=" + a_nBoardId, null);
	}
	
	public int deleteSNSAlarmWhereGroupId(int a_nGroupId)
	{
		return m_db.delete(TABLE_SNSALARM, KEY_SNSALARM_GROUPID + "=" + a_nGroupId, null);
	}
	
	public int deleteSNSAlarmBefore2Week()
	{
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) - 14);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		long lnEditTime = calendar.getTimeInMillis();
		
		String strWhere = KEY_SNSALARM_CREATEMS + "<" + lnEditTime;
		
		return m_db.delete(TABLE_SNSALARM, strWhere, null);
	}
	
	public int deleteSNSAlarmPushType()
	{
		String strWhere = KEY_SNSALARM_TYPE + "=\"" + SNSAlarmData.ALARMTYPE_PUSH + "\"";
		return m_db.delete(TABLE_SNSALARM, strWhere, null);
	}
	
	public int deleteSNSMyGroupInfo()
	{
		return m_db.delete(TABLE_SNSMYGROUPINFO, null, null);
	}
	
	public int deleteSNSMyGroupInfo(int a_nGroupId)
	{
		return m_db.delete(TABLE_SNSMYGROUPINFO, KEY_SNSMYGROUPINFO_GROUPID + "=" + a_nGroupId, null);
	}
	
	public Cursor getSNSAlarm()
	{
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		return m_db.query(TABLE_SNSALARM, null, null, null, null, null, strOrderBy);
	}
	
	public Cursor getSNSAlarmWhereNoDelete()
	{
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		String strWhere = KEY_SNSALARM_ISDELETED + "=" + "0";
		return m_db.query(TABLE_SNSALARM, null, strWhere, null, null, null, strOrderBy);
	}
	
	public Cursor getLastAlarm(int a_nGroupId)
	{
		String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_TYPE + "!=\"" + SNSAlarmData.ALARMTYPE_PUSH + "\"";
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		return m_db.query(TABLE_SNSALARM, null, strWhere, null, null, null, strOrderBy, "1");
	}
	
	public Cursor getSNSAlarmWhereNoBoardRead(int a_nGroupId)
	{
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_ISBOARDREAD + "=" + "0" + " AND " + KEY_SNSALARM_REPLYNO + " = -1";
		return m_db.query(TABLE_SNSALARM, null, strWhere, null, null, null, strOrderBy);
	}
	
	public Cursor getSNSAlarmWhereNoBoardReadReply(int a_nGroupId)
	{
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_ISBOARDREAD + "=" + "0" + " AND " + KEY_SNSALARM_REPLYNO + " != -1";
		return m_db.query(TABLE_SNSALARM, null, strWhere, null, null, null, strOrderBy);
	}
	
	public Cursor getSNSAlarmWhereNoReplyRead(int a_nGroupId, int a_nBoardId)
	{
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		String strWhere = KEY_SNSALARM_GROUPID + "=" + a_nGroupId + " AND " + KEY_SNSALARM_BOARDNO + "=" + a_nBoardId + " AND " + KEY_SNSALARM_ISBOARDREAD + "=" + "0";
		return m_db.query(TABLE_SNSALARM, null, strWhere, null, null, null, strOrderBy);
	}
	
	public int getNoAlarmReadCount()
	{
		int nCount = 0;
		String strQuery = "select count(*) from " + TABLE_SNSALARM + " where " + KEY_SNSALARM_ISALARMREAD + "=0";
		Cursor cursor = m_db.rawQuery(strQuery, null);
		if(cursor.moveToFirst())
		{
			nCount = cursor.getInt(0);
		}
		cursor.close();
		return nCount;
	}
	
	public int getNoBoardReadCount()
	{
		int nCount = 0;
		String strQuery = "select count(*) from " + TABLE_SNSALARM + " where " + KEY_SNSALARM_ISBOARDREAD + "=0";
		Cursor cursor = m_db.rawQuery(strQuery, null);
		if(cursor.moveToFirst())
		{
			nCount = cursor.getInt(0);
		}
		cursor.close();
		return nCount;
	}
	
	public int getNoBoardReadCountWhereGroupId(int a_nGroupId)
	{
		int nCount = 0;
		String strQuery = "select count(*) from " + TABLE_SNSALARM + " where " + KEY_SNSALARM_ISBOARDREAD + "=0 AND " + KEY_SNSALARM_GROUPID + "=" + a_nGroupId;
		Cursor cursor = m_db.rawQuery(strQuery, null);
		if(cursor.moveToFirst())
		{
			nCount = cursor.getInt(0);
		}
		cursor.close();
		return nCount;
	}
	
	public Cursor getUnReadBoardAndReplyNos()
	{
		String strOrderBy = KEY_SNSALARM_UPDATEDDATE + " COLLATE LOCALIZED DESC";
		String strWhere = KEY_SNSALARM_ISBOARDREAD + "=" + "0";
		return m_db.query(TABLE_SNSALARM, null, strWhere, null, null, null, strOrderBy);
	}
	
	public Cursor getSNSMyGroupInfo()
	{
		return m_db.query(TABLE_SNSMYGROUPINFO, null, null, null, null, null, null);
	}
	
	public Cursor getSNSMyGroupInfoFavorite()
	{
		String strWhere = KEY_SNSMYGROUPINFO_ISFAVORITE + "=1";
		return m_db.query(TABLE_SNSMYGROUPINFO, null, strWhere, null, null, null, null);
	}
	
	// SQLite Open Helper Class
	private class FavoriteGroupDBHelper extends SQLiteOpenHelper
	{

		public FavoriteGroupDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(SNSALARM_CREATE);
			db.execSQL(SNSMYGROUPINFO_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			db.execSQL(SNSALARM_DROP);
			db.execSQL(SNSMYGROUPINFO_DROP);
			onCreate(db);
		}
	}
}
