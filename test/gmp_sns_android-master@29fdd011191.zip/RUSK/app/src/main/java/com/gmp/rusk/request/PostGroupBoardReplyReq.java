package com.gmp.rusk.request;

import org.json.JSONObject;


import com.gmp.rusk.utils.CommonLog;

/**
 *	@author kch
 *			모임 댓글 등록
 *			method : post
 */

public class PostGroupBoardReplyReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";

	private final String JSON_BODY = "body";

	private String m_strBody = "";
	
	public PostGroupBoardReplyReq(int a_nGroupId, int a_nThreadNo, String a_strBody)
	{
		APINAME = APINAME + "/" + a_nGroupId + "/thread/" + a_nThreadNo + "/comment";
		m_strBody = a_strBody;
	}
	
	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_BODY, m_strBody);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PostGroupBoardReplyReq.class.getSimpleName(), "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
