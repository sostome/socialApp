package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ApprovalTabAct;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomAllViewAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * ChatRoomOtherMSGLayout 채팅방 다른사람 메세지 List Item Layout
 */
public class ChatRoomOtherMSGLayout extends CustomLinearLayout implements OnLongClickListener, OnClickListener, OnTouchListener {
	// int m_nNumber;
	// String m_strName;
	// String m_strOtherMSG;
	// long m_lSentTime;
	// ArrayList<Integer> m_arrRead;
	// ArrayList<Integer> m_arrTotalUser;
	// String m_strMessageID;
	RelativeLayout m_OtherMessage;
	TextView m_tvOtherMSG, m_tvOtherMessageTime, m_tvOtherName, m_tvOtherMessageNoSee;
	ImageView m_ivOtherImage, m_ivNotFellowImage,m_ivOtherProfileFrame,m_ivPartnerIcon;
	View m_vLineMessageAll;
	LinearLayout m_ibAllView;
	ImageButton m_ibCheckRegular, m_ibReApproval;
	// boolean m_isAvailable;
	CommonPopup m_Popup;
	private int nListPopupCase;
	private final int LONG_CLICK = 1;

	private ChatRoomData m_ChatRoomData = null;
	private CommonListPopup m_ListPopup = null;
	private boolean isAbleClick = true;

	//파트너의 경우 자신을 승인한 정직원의 ID
	private int m_nApprovalUserNo = 0;

	//서버메시지를 처리 하기 위한 Comma 방일 경우에 타입 구분을 위함
	private String m_strCommaType = "";

	//대화 검색시 레이아웃이 흔들리게 하기 위해 필요
	private String m_strBounceID = "";
	private boolean m_isBounce = false;

	public ChatRoomOtherMSGLayout(Context context) {
		super(context);
		// m_strOtherMSG = a_strOhterMSG;
		// m_strName = a_strName;
		// m_nNumber = a_nNumber;
		// m_lSentTime = a_lSentTime;
		// m_arrRead = a_arrRead;
		// m_arrTotalUser = a_arrTotalRead;
		// m_strMessageID = a_strMessageID;
		// m_isAvailable = a_isImageAvailable;
		init();

	}
	private void init() {
		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
		li.inflate(R.layout.layout_chat_room_othermsg, this, true);


		m_tvOtherMSG = (TextView) findViewById(R.id.tv_chat_othermsg);

		SharedPref pref = SharedPref.getInstance(getContext());
		int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			m_tvOtherMSG.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.33f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			m_tvOtherMSG.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19.92f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			m_tvOtherMSG.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 24.53f);
		}
		m_tvOtherMSG.setLinkTextColor(Color.BLUE);
		m_tvOtherMessageTime = (TextView) findViewById(R.id.tv_chat_othermsg_time);
		m_tvOtherMessageNoSee = (TextView) findViewById(R.id.tv_chat_othermsg_nosee);
		m_tvOtherName = (TextView) findViewById(R.id.tv_chat_othername);
		m_OtherMessage = (RelativeLayout) findViewById(R.id.layout_chat_othermsg);
		m_ivOtherImage = (ImageView) findViewById(R.id.iv_chat_otherimage);
		m_vLineMessageAll = (View)findViewById(R.id.line_msgall);
		m_ibAllView = (LinearLayout) findViewById(R.id.ib_chat_othermsg_all);
		m_ibCheckRegular = (ImageButton) findViewById(R.id.ib_chat_othermsg_check_regular);
		m_ibReApproval = (ImageButton) findViewById(R.id.ib_chat_othermsg_reapproval);
		m_ivNotFellowImage = (ImageView) findViewById(R.id.iv_profile_notfellow_pic);
		m_ivPartnerIcon = (ImageView) findViewById(R.id.iv_chatroom_icon_partner);
		m_ivOtherProfileFrame = (ImageView) findViewById(R.id.iv_profile_other_frame) ;

		m_tvOtherMSG.setOnTouchListener(this);
		m_tvOtherMessageNoSee.setOnClickListener(this);
		m_tvOtherMessageTime.setOnClickListener(this);	
		m_OtherMessage.setOnLongClickListener(this);
		m_tvOtherMSG.setOnLongClickListener(this);
		m_ivOtherImage.setOnClickListener(this);

		// TTalkImageLoader.getImage(App.getImageDownLoaderUrl(m_nNumber, false), m_ivOtherImage);
	}

/*	public void setPosition(int nPosition){
		m_nPosition = nPosition;
	}*/

	public void setChatRoomData(ChatRoomData a_Data) {
		m_ChatRoomData = a_Data;
		if(a_Data.m_strRoomID.split("_").length == 3) {
			m_OtherMessage.setBackgroundResource(R.drawable.img_balloon_friend);
			m_ivOtherProfileFrame.setBackgroundResource(R.drawable.img_profile_talk);
			m_tvOtherMessageNoSee.setTextColor(Color.parseColor("#e04f07"));
		} else {
			m_OtherMessage.setBackgroundResource(R.drawable.img_balloon_friend);
			m_ivOtherProfileFrame.setBackgroundResource(R.drawable.img_profile_talk);
			m_tvOtherMessageNoSee.setTextColor(Color.parseColor("#e04f07"));
		}


		m_tvOtherName.setText(m_ChatRoomData.m_strName);
		EmoticonUtils utils = new EmoticonUtils();
		String strText = m_ChatRoomData.m_strOtherMSG;
		String strLastChar = " ";
		String strFirstChar = " ";

		if (m_ChatRoomData.m_strRoomID.length() < 8) {
			m_strBounceID = ((ChatRoomAct) getContext()).getBounceID();
		} else {
			m_strBounceID = ((ChatRoomGroupAct) getContext()).getBounceID();
		}

		if (strText != null && strText.length() != 0) {
			while (strLastChar.equals(" ") || strLastChar.equals("\n")) {
				strLastChar = (String) strText.subSequence(strText.length() - 1, strText.length());
				if (strLastChar.equals(" ") || strLastChar.equals("\n")) {
					strText = (String) strText.subSequence(0, strText.length() - 1);
				}
			}
			while (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
				strFirstChar = (String) strText.subSequence(0, 1);
				if (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
					strText = (String) strText.subSequence(1, strText.length());
				}
			}
		}
		if(m_ChatRoomData.m_strRoomID.equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))){
			if(strText.split("\\*").length > 1 && strText.split("\\*")[1].equals(StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORPARTNER)){
				m_nApprovalUserNo = Integer.parseInt(strText.split("\\*")[2]);
				m_strCommaType = strText.split("\\*")[1];
				strText = strText.split("\\*")[0];
			} else if(strText.split("\\*").length > 1 && strText.split("\\*")[1].equals(StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORREGULAR)){
				m_strCommaType = strText.split("\\*")[1];
				strText = strText.split("\\*")[0];
			}
		}

		String strViewText = "";
		if(strText.length() > 1000){
			strViewText = strText.substring(0, 997);
			char[] cText = strViewText.toCharArray();
			for(int i = 994; i < 997; i++){
				if(cText[i] == '('){
					strViewText = strText.substring(0, i);
					break;
				}
			}
			strViewText = strViewText + "...";
		} else {
			strViewText = strText;
		}
		ArrayList<Integer> index = new ArrayList<>();

		String strSearchText = m_ChatRoomData.m_strSearchText;
		SpannableString ssViewText = new SpannableString(strViewText);
		if (strViewText.contains(strSearchText) && !strSearchText.equals("")) {
			for(int i = strViewText.indexOf(strSearchText); i >= 0; i = strViewText.indexOf(strSearchText, i + 1)){
				index.add(i);
			}
			//index = strViewText.indexOf(strSearchText);
			for(int j = 0; j < index.size(); j++) {
				ssViewText.setSpan(new BackgroundColorSpan(Color.parseColor("#6d55d9")), index.get(j), index.get(j) + strSearchText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				ssViewText.setSpan(new ForegroundColorSpan(Color.parseColor("#ffffff")), index.get(j), index.get(j) + strSearchText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			}
		}
		m_tvOtherMSG.setText(utils.parsingEmoticonText(getContext(), ssViewText, strViewText, (int) m_tvOtherMSG.getTextSize()));

		CustomLinkify.addLinks(m_tvOtherMSG, CustomLinkify.ALL);
		if(m_strBounceID.equals(m_ChatRoomData.m_strMessageID) && !m_isBounce){
			LinearLayout layout = (LinearLayout)findViewById(R.id.layout_chat_room_othermsg);
			YoYo.with(Techniques.Bounce).duration(500).repeat(1).playOn(layout);
			if (m_ChatRoomData.m_strRoomID.length() < 8) {
				((ChatRoomAct) getContext()).setBounceIDEmpty();
			} else {
				((ChatRoomGroupAct) getContext()).setBounceIDEmpty();
			}
		}

//		UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(getContext(), m_ChatRoomData.m_nNO);
		if(m_ChatRoomData.m_nNO == App.m_MyUserInfo.m_nUserNo){
			m_ivOtherImage.setBackgroundResource(R.drawable.img_profile_cork);
			m_ivNotFellowImage.setVisibility(View.GONE);
		} else {
			if (m_ChatRoomData.m_isImageAvailable) {
				App.imageloader.cancelDownload(m_ivOtherImage);
				App.imageloader.getProfileImage(m_ivOtherImage, App.getImageDownLoaderUrl(m_ChatRoomData.m_nNO, true), R.drawable.profile_pic_default, false);
			
			} else
			{
				App.imageloader.cancelDownload(m_ivOtherImage);
				m_ivOtherImage.setImageResource(R.drawable.profile_pic_default);
			}

			if(m_ChatRoomData.m_strSenderType.equals("R")){
				m_ivPartnerIcon.setVisibility(GONE);
			} else {
				m_ivPartnerIcon.setVisibility(VISIBLE);
			}
		}
		// 날짜
		String pattern = "a h:mm";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String date = (String) format.format(new Timestamp(m_ChatRoomData.m_lDate));

		m_tvOtherMessageTime.setText(date);

		int nNoReadCount = 0;
		//nNoReadCount = m_ChatRoomData.m_arrTotalRead.size() - m_ChatRoomData.m_arrRead.size();
		nNoReadCount = m_ChatRoomData.m_nNoReadCount;
		if (nNoReadCount == 0) {
			m_tvOtherMessageNoSee.setText("");
			m_tvOtherMessageNoSee.setVisibility(View.GONE);
		} else if (nNoReadCount < 0) {
			m_tvOtherMessageNoSee.setText("");
			m_tvOtherMessageNoSee.setVisibility(View.GONE);
		} else {
			m_tvOtherMessageNoSee.setText("" + nNoReadCount);
			m_tvOtherMessageNoSee.setVisibility(View.VISIBLE);
		}

		if (m_ChatRoomData.m_strOtherMSG.length() > 1000) {
			m_vLineMessageAll.setVisibility(VISIBLE);
			m_ibAllView.setVisibility(View.VISIBLE);
			m_ibAllView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(getContext(), ChatRoomAllViewAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_ChatRoomData.m_strRoomID);
					intent.putExtra(IntentKeyString.INTENT_KEY_TEXT, m_ChatRoomData.m_strOtherMSG);
					getContext().startActivity(intent);

				}
			});
		} else {
			m_vLineMessageAll.setVisibility(GONE);
			m_ibAllView.setVisibility(View.GONE);
		}
		if(m_ChatRoomData.m_nNO == App.m_MyUserInfo.m_nUserNo){
			m_OtherMessage.setOnLongClickListener(null);
			m_tvOtherMSG.setOnLongClickListener(null);
		}

		//자신이 파트너 이고, 계정만료 안내 메시지를 받았을때 보여줌
		if(!m_strCommaType.equals("")){
			if(m_strCommaType.equals(StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORPARTNER)) {
				m_ibCheckRegular.setVisibility(View.VISIBLE);
				m_ibCheckRegular.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intent = new Intent(getContext(), ProfileViewPopupAct.class);
						//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_nApprovalUserNo);
						intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_ChatRoomData.m_strRoomID);
						getContext().startActivity(intent);
					}
				});
			} else if(m_strCommaType.equals(StaticString.COMMA_ROOM_SERVER_MESSAGE_TYPE_PREEXPFORREGULAR)){
				m_ibReApproval.setVisibility(View.VISIBLE);
				m_ibReApproval.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						Intent intentApprovalTabAct = new Intent(getContext(), ApprovalTabAct.class);
						intentApprovalTabAct.putExtra(IntentKeyString.INTENT_KEY_REAPPROVAL, true);
						getContext().startActivity(intentApprovalTabAct);
					}
				});
			}
		}
	}

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.layout_chat_othermsg:
		case R.id.tv_chat_othermsg:
			nListPopupCase = LONG_CLICK;
			m_ListPopup = new CommonListPopup(getContext(), ChatRoomOtherMSGLayout.this);
			m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_longclick_type));
			m_ListPopup.setCancelable(true);
			m_ListPopup.show();

			break;

		default:
			break;
		}
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				isAbleClick = true;
			}

		};

		if (isAbleClick) {
			Timer mTimer = new Timer();
			mTimer.schedule(task, 500);

			isAbleClick = false;
			switch (v.getId()) {
			case R.id.tv_chat_othermsg_nosee:
			case R.id.tv_chat_othermsg_time:

				break;
			case R.id.ib_pop_ok:
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SEND_NOTICE) {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).sendMessage(m_ChatRoomData.m_strOtherMSG, true);
					} else {
						((ChatRoomGroupAct) getContext()).sendMessage(m_ChatRoomData.m_strOtherMSG, true);
					}
				} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					} else {
						((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					}
				}

				popup_ok.cancel();
				break;
			case R.id.ib_pop_cancel:
				CommonPopup popup_cancel = (CommonPopup)v.getTag();
				popup_cancel.cancel();
				break;
			case R.id.iv_chat_otherimage:
				if(m_ChatRoomData.m_nNO != App.m_MyUserInfo.m_nUserNo){
					Intent intent = new Intent(getContext(), ProfileViewPopupAct.class);
					//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_ChatRoomData.m_nNO);
					intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_ChatRoomData.m_strRoomID);
					getContext().startActivity(intent);
				}
				break;
			case R.id.ib_pop_cancel_long:
				m_ListPopup.cancel();
				break;
			case R.id.tv_pop_first_row:
				m_ListPopup.cancel();
				if (m_ChatRoomData.m_strRoomID.length() < 8) {
					((ChatRoomAct) getContext()).sendMessageOther(m_ChatRoomData.m_strOtherMSG);
				} else {
					((ChatRoomGroupAct) getContext()).sendMessageOther(m_ChatRoomData.m_strOtherMSG);
				}
				break;
			case R.id.tv_pop_second_row:
				m_ListPopup.cancel();
				m_Popup = new CommonPopup(getContext(), ChatRoomOtherMSGLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title), getContext().getString(R.string.popup_delete_text_text));
				m_Popup.setCancelable(false);
				m_Popup.show();
				break;
			case R.id.tv_pop_third_row:
				m_ListPopup.cancel();
				m_Popup = new CommonPopup(getContext(), ChatRoomOtherMSGLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_SEND_NOTICE);
				m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_urgent_title), getContext().getString(R.string.popup_urgent_text));
				m_Popup.setCancelable(false);
				m_Popup.show();
				break;
			default:
				break;
			}
		}

	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			if (nListPopupCase == LONG_CLICK) {
				nListPopupCase = 0;
			}
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			if (nListPopupCase == LONG_CLICK) {
				return true;
			}
		}
		return false;
	}
}
