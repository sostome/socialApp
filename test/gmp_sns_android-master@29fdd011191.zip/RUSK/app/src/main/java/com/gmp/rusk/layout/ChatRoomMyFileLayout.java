package com.gmp.rusk.layout;

import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.Contacts.Data;
import android.provider.ContactsContract.Intents.Insert;
import android.support.v4.content.FileProvider;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomImageView;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.filedownload.FileDownload;
import com.gmp.rusk.gmp.AuthUtil;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.takemedia.FileUtil;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.parameter.EmailType;
import ezvcard.parameter.TelephoneType;
import ezvcard.property.Telephone;

/**
 * ChatRoomMyFileLayout 채팅방 내 파일 List Item Layout
 */
public class ChatRoomMyFileLayout extends CustomLinearLayout implements OnClickListener, OnLongClickListener {

	TextView m_tvChatMyfile, m_tvChatMyfileNosee, m_tvChatMyfileTime, m_tvChatMyfileDate;
	TextView m_tvChatMyVideoData;
	TextView m_tvChatMyContactName;

	LinearLayout m_MyFile, m_MyVideo, m_MyContacts, m_MyTimeAndNosee;
	ImageView m_ivIcon, m_ivMimeIcon ,m_ivIconRefresh;
	CustomImageView m_ivMyVideoThumb;
	private ProgressBar aProgress;
	private RotateAnimation m_animProgress = null;;
	CommonPopup m_Popup;
	private CommonListPopup m_ListPopup = null;
	private int nListPopupCase;
	private final int LONG_CLICK = 1;
	private final int SELECT_ICON = 2;
	private final int LONG_CLICK_FAIL = 3;
	private boolean isAbleClick = true;
	private boolean isDownloading = false;
	private ChatRoomData m_ChatRoomData = null;
	private long m_lCreateTime = 0;

	private String m_strBounceID = "";
	private boolean m_isBounce = false;

	private Context m_Context;
	public ChatRoomMyFileLayout(Context context) {
		super(context);
		m_Context = context;
		init();

	}

	private void init() {

		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
		li.inflate(R.layout.layout_chat_room_myfile, this, true);

		m_animProgress = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		m_animProgress.setInterpolator(new LinearInterpolator());
		m_animProgress.setRepeatCount(Animation.INFINITE);
		m_animProgress.setDuration(1000);

		m_tvChatMyfile = (TextView) findViewById(R.id.tv_chat_myfile);
		m_tvChatMyfileNosee = (TextView) findViewById(R.id.tv_chat_myfile_nosee);
		m_tvChatMyfileTime = (TextView) findViewById(R.id.tv_chat_myfile_time);
		m_tvChatMyfileDate = (TextView) findViewById(R.id.tv_chat_myfile_date);
		m_tvChatMyVideoData = (TextView) findViewById(R.id.tv_chat_myvideo_date);
		m_tvChatMyContactName = (TextView) findViewById(R.id.tv_chat_mycontact_name);
		m_MyFile = (LinearLayout) findViewById(R.id.layout_chat_myfile);
		m_MyVideo = (LinearLayout) findViewById(R.id.layout_chat_myvideo);
		m_ivMyVideoThumb = (CustomImageView) findViewById(R.id.iv_chat_myvideo);
		m_MyContacts = (LinearLayout) findViewById(R.id.layout_chat_mycontacts);
		m_ivIcon = (ImageView) findViewById(R.id.iv_chat_myfile_icon);
		m_ivIconRefresh = (ImageView) findViewById(R.id.iv_chat_myfile_icon_refresh);
		m_ivMimeIcon = (ImageView) findViewById(R.id.iv_chat_myfile_mime_icon);
		m_MyTimeAndNosee = (LinearLayout) findViewById(R.id.layout_chat_my_time_and_nosee);

		m_tvChatMyfileNosee.setOnClickListener(this);

		aProgress = (ProgressBar) findViewById(R.id.tv_chat_myfile_progress);

	}

	public void setChatRoomData(ChatRoomData a_Data) {
		m_ChatRoomData = a_Data;
		if(a_Data.m_strRoomID.split("_").length==3){
			m_MyFile.setBackgroundResource(R.drawable.img_balloon_me);
		/*	m_MyVideo.setBackgroundResource(R.drawable.img_balloon_me);*/
			m_MyContacts.setBackgroundResource(R.drawable.img_balloon_me);
			m_tvChatMyfileNosee.setTextColor(Color.parseColor("#e04f07"));
		} else {
			m_MyFile.setBackgroundResource(R.drawable.img_balloon_me);
		/*	m_MyVideo.setBackgroundResource(R.drawable.img_balloon_me);*/
			m_MyContacts.setBackgroundResource(R.drawable.img_balloon_me);
			m_tvChatMyfileNosee.setTextColor(Color.parseColor("#e04f07"));
		}


		if (m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_NORMAL)) {
			m_MyVideo.setVisibility(View.GONE);
			m_MyFile.setVisibility(View.VISIBLE);
			m_MyContacts.setVisibility(View.GONE);
			String extension = m_ChatRoomData.m_strMyMSG.substring(m_ChatRoomData.m_strMyMSG.lastIndexOf(".") + 1, m_ChatRoomData.m_strMyMSG.length());
			extension = extension.toLowerCase();
			if (extension.equalsIgnoreCase("txt")) {
				m_ivMimeIcon.setImageResource(R.drawable.icon_text_s);
			} else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
				m_ivMimeIcon.setImageResource(R.drawable.icon_word_s);
			} else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
				m_ivMimeIcon.setImageResource(R.drawable.icon_excel);
			} else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
				m_ivMimeIcon.setImageResource(R.drawable.icon_ppt);
			} else if (extension.equalsIgnoreCase("pdf")) {
				m_ivMimeIcon.setImageResource(R.drawable.icon_pdf);
			} else if (extension.equalsIgnoreCase("hwp")) {
				m_ivMimeIcon.setImageResource(R.drawable.icon_han_s);
			} else {
				m_ivMimeIcon.setImageResource(R.drawable.icon_filezip_copy);
			}
			String strSearchText = m_ChatRoomData.m_strSearchText;
			SpannableString ssViewText = new SpannableString(m_ChatRoomData.m_strMyMSG);

			ArrayList<Integer> index = new ArrayList<>();

			if (m_ChatRoomData.m_strMyMSG.contains(strSearchText) && !strSearchText.equals("")) {
				for(int i = m_ChatRoomData.m_strMyMSG.indexOf(strSearchText); i >= 0; i = m_ChatRoomData.m_strMyMSG.indexOf(strSearchText, i + 1)){
					index.add(i);
				}
				//index = strViewText.indexOf(strSearchText);
				for(int j = 0; j < index.size(); j++) {
					ssViewText.setSpan(new BackgroundColorSpan(Color.parseColor("#6d55d9")), index.get(j), index.get(j) + strSearchText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
					ssViewText.setSpan(new ForegroundColorSpan(Color.parseColor("#ffffff")), index.get(j), index.get(j) + strSearchText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				}
			}
			m_tvChatMyfile.setText(ssViewText);

			SharedPref pref = SharedPref.getInstance(getContext());
			int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
			if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
				m_tvChatMyfile.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.33f);
			} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
				m_tvChatMyfile.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19.92f);
			} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
				m_tvChatMyfile.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 24.53f);
			}
			if (m_ChatRoomData.m_strRoomID.length() < 8) {
				m_strBounceID = ((ChatRoomAct) getContext()).getBounceID();
			} else {
				m_strBounceID = ((ChatRoomGroupAct) getContext()).getBounceID();
			}

			if(m_strBounceID.equals(m_ChatRoomData.m_strMessageID) && !m_isBounce){
				LinearLayout layout = (LinearLayout)findViewById(R.id.layout_chat_room_myfile);
				YoYo.with(Techniques.Bounce.Bounce).duration(500).repeat(1).playOn(layout);
				if (m_ChatRoomData.m_strRoomID.length() < 8) {
					((ChatRoomAct) getContext()).setBounceIDEmpty();
				} else {
					((ChatRoomGroupAct) getContext()).setBounceIDEmpty();
				}
			}

			m_ivMimeIcon.setBackgroundResource(R.drawable.chat_icon_file_me);
		} else if(m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_CONTACT)){
			m_MyVideo.setVisibility(View.GONE);
			m_MyFile.setVisibility(View.GONE);
			m_MyContacts.setVisibility(View.VISIBLE);
			m_tvChatMyContactName.setText(m_ChatRoomData.m_strMyMSG);
			SharedPref pref = SharedPref.getInstance(getContext());
			int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
			if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
				m_tvChatMyContactName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f);
			} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
				m_tvChatMyContactName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18.2f);
			} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
				m_tvChatMyContactName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 22.4f);
			}
		}
		else 
		{
			m_MyContacts.setVisibility(View.GONE);
			m_MyFile.setVisibility(View.GONE);
			m_MyVideo.setVisibility(View.VISIBLE);
		}
		// 올린 시간
		String pattern = "a h:mm";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String date = (String) format.format(new Timestamp(m_ChatRoomData.m_lDate));
		// 파일 다운 가능 시간
		String pattern2 = "yyyy.MM.dd";
		SimpleDateFormat format2 = new SimpleDateFormat(pattern2);
		if(m_ChatRoomData.m_lCreateTime != 0){
			m_lCreateTime = m_ChatRoomData.m_lCreateTime;
		} else {
			m_lCreateTime = m_ChatRoomData.m_lDate;
		}
		String date2 = (String) format2.format(new Timestamp(m_lCreateTime + 1814400000));
		if(m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_VIDEO)){
			ImageLoaderManager imageloader = ImageLoaderManager.getInstance(getContext());
			Bitmap thumbBitmap = imageloader.getLocalRoundImage(m_ChatRoomData.m_strMyImageThumbUrl);
			if(thumbBitmap == null)
				imageloader.getImageRoundMine(m_ivMyVideoThumb, m_ChatRoomData.m_strMyImageThumbUrl, 0, m_ImageLoaderListener);
			else
				m_ivMyVideoThumb.setImageBitmap(thumbBitmap);
		} else {
			m_ivMyVideoThumb.setImageBitmap(null);
		}
		int nNoReadCount = 0;
		//nNoReadCount = m_ChatRoomData.m_arrTotalRead.size() - m_ChatRoomData.m_arrRead.size();
		nNoReadCount = m_ChatRoomData.m_nNoReadCount;
		m_tvChatMyfileTime.setOnClickListener(this);
		if (m_ChatRoomData.m_nSendStatus == 0) {
			m_ivIcon.setVisibility(View.VISIBLE);
			m_ivIcon.setBackgroundResource(R.drawable.img_loading);
			m_ivIcon.startAnimation(m_animProgress);
			m_ivIconRefresh.setVisibility(GONE);
			m_tvChatMyfileTime.setVisibility(VISIBLE);
			m_tvChatMyfileTime.setOnClickListener(null);
			m_MyFile.setOnLongClickListener(this);
			m_MyVideo.setOnLongClickListener(this);
			m_MyContacts.setOnLongClickListener(this);
		} else if (m_ChatRoomData.m_nSendStatus == 1) {
			m_ivIcon.setVisibility(View.GONE);
			m_ivIconRefresh.setVisibility(VISIBLE);
			m_ivIconRefresh.setBackgroundResource(R.drawable.btn_refresh);
			m_ivIconRefresh.setOnClickListener(this);
			m_tvChatMyfileTime.setVisibility(GONE);
			m_tvChatMyfileTime.setOnClickListener(null);
			m_MyFile.setOnLongClickListener(this);
			m_MyVideo.setOnLongClickListener(this);
			m_MyContacts.setOnLongClickListener(this);
		} else if (m_ChatRoomData.m_nSendStatus == 2) {
			m_ivIcon.setVisibility(View.GONE);
			m_ivIconRefresh.setVisibility(GONE);
			m_tvChatMyfileTime.setVisibility(VISIBLE);
			m_tvChatMyfileTime.setOnClickListener(this);
			m_MyFile.setOnClickListener(this);
			m_MyVideo.setOnClickListener(this);
			m_MyContacts.setOnClickListener(this);
			m_MyFile.setOnLongClickListener(this);
			m_MyVideo.setOnLongClickListener(this);
			m_MyContacts.setOnLongClickListener(this);
		}

		if (nNoReadCount == 0) {
			m_tvChatMyfileNosee.setText("");
			m_tvChatMyfileNosee.setVisibility(View.GONE);
		} else if (nNoReadCount < 0) {
			m_tvChatMyfileNosee.setText("");
			m_tvChatMyfileNosee.setVisibility(View.GONE);
		} else {
			m_tvChatMyfileNosee.setText("" + nNoReadCount);
			m_tvChatMyfileNosee.setVisibility(View.VISIBLE);
		}
		m_tvChatMyfileTime.setText(date);
		if (m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_NORMAL)) {
			m_tvChatMyfileDate.setText(getContext().getString(R.string.layout_chatroom_file_period)+ date2 + getContext().getString(R.string.layout_chatroom_file_download));
		} else {
			m_tvChatMyVideoData.setText(getContext().getString(R.string.layout_chatroom_file_period) + date2 + getContext().getString(R.string.layout_chatroom_file_download));
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				isAbleClick = true;
			}

		};

		if (isAbleClick) {
			Timer mTimer = new Timer();
			mTimer.schedule(task, 500);
			isAbleClick = false;
			switch (v.getId()) {

			case R.id.layout_chat_myfile:
			case R.id.layout_chat_myvideo:

				if(m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_NORMAL) && m_ChatRoomData.m_strVdi.equals("true")){
					m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title), getContext().getString(R.string.popup_fail_open_vdi_file));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_VIDEO) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
						(App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled))){
					m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title), getContext().getString(R.string.cork_pop_fail_open_file));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(!m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_VIDEO) && (App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileDownloadEnabled) ||
						(App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileDownloadEnabled)){
					m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title), getContext().getString(R.string.cork_pop_fail_open_file));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else {
					if (System.currentTimeMillis() < m_lCreateTime + 1814400000) {

							if (m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_NORMAL) && AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)) {
								Utils.startFileViewPlus(getContext(), m_ChatRoomData.m_strMyMSG, m_ChatRoomData.m_strMyFile);
							} else {
								if (FileUtil.getAvailableExternalMemorySize() < 104857600) {
									m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
									m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_fail_download_title), getContext().getString(R.string.popup_fail_download_text));
									m_Popup.setCancelable(false);
									m_Popup.show();
								} else {
									SharedPref pref = SharedPref.getInstance(getContext());
									if(pref.getBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, false)) {
										if (!isDownloading) {
											startDownload();
										}
									} else {
										if (!isDownloading) {
											final String strPopupMsg = m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_VIDEO) ? getContext().getString(R.string.cork_pop_video_down) : getContext().getString(R.string.cork_pop_file_down);
											m_Popup = new CommonPopup(getContext(), new OnClickListener() {
												@Override
												public void onClick(View v) {
													if (v.getId() == R.id.ib_pop_ok) {
														CommonPopup popup_cancel = (CommonPopup) v.getTag();
														popup_cancel.cancel();
														SharedPref pref = SharedPref.getInstance(getContext());
														pref.setBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, true);
														startDownload();
													} else {
														CommonPopup popup_cancel = (CommonPopup) v.getTag();
														popup_cancel.cancel();
													}
												}
											}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
											m_Popup.setBodyAndTitleText(getContext().getString(R.string.pop_confirm), strPopupMsg);
											m_Popup.setCancelable(false);
											m_Popup.show();

										}
									}
								}
							}

					}
					else {
						m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_fail_download_title), getContext().getString(R.string.cork_pop_end_download_period));
						m_Popup.setCancelable(false);
						m_Popup.show();
					}
				}
				break;
			case R.id.layout_chat_mycontacts:
				if (!isDownloading) {
					isDownloading = true;
					FileDownload fileDownload = new FileDownload(getContext(), m_ChatRoomData.m_strRoomID, m_ChatRoomData.m_strMessageID, m_ChatRoomData.m_strMyFile, true);


					fileDownload.startDownload(new FileDownload.OnDownloadComplete() {

						@Override
						public void onDownloadFail() {
							// TODO Auto-generated method stub
							// 다운로드 실패 처리
							isDownloading = false;
						}

						@Override
						public void onComplete(String a_strFilePath) {
							// TODO Auto-generated method stub
							isDownloading = false;					
							aProgress.setVisibility(View.GONE);
							m_MyTimeAndNosee.setVisibility(View.VISIBLE);
							startSaveContact(m_ChatRoomData.m_strMyMSG, a_strFilePath);
						}

						@Override
						public void onProgess(int a_nCount, int a_nTotal) {
							// TODO Auto-generated method stub
							// (int)((total*100)/lengoffile))
							CommonLog.e(getContext(), "Progress a_nCount: " + a_nCount + " a_nTotal: " + a_nTotal);
							aProgress.setMax(a_nTotal);
							aProgress.setProgress(a_nCount);
						}

						@Override
						public void onStart() {
							m_MyTimeAndNosee.setVisibility(View.GONE);
							aProgress.setMax(100);
							aProgress.setProgress(0);
							aProgress.setVisibility(View.VISIBLE);
						}
					});
				}
				
				break;
			case R.id.iv_chat_myfile_icon_refresh:

				nListPopupCase = SELECT_ICON;
				m_ListPopup = new CommonListPopup(getContext(), ChatRoomMyFileLayout.this);
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_file_resend_type));
				m_ListPopup.setCancelable(true);
				m_ListPopup.show();

				break;
			case R.id.tv_chat_myfile_nosee:
			case R.id.tv_chat_myfile_time:

				break;
			case R.id.ib_pop_ok_long:
				CommonPopup popup_ok_long = (CommonPopup)v.getTag();
				popup_ok_long.cancel();
				break;
			case R.id.ib_pop_ok:
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				if (m_ChatRoomData.m_strRoomID.length() < 8) {
					((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
				} else {
					((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
				}
				popup_ok.cancel();
				break;
			case R.id.ib_pop_cancel:
				CommonPopup popup_cancel = (CommonPopup)v.getTag();
				popup_cancel.cancel();
				break;
			case R.id.ib_pop_cancel_long:
				m_ListPopup.cancel();
				break;
			case R.id.tv_pop_first_row:
				m_ListPopup.cancel();
				if (nListPopupCase == LONG_CLICK_FAIL) {
					m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title),
							getContext().getString(R.string.popup_delete_text_text));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (nListPopupCase == LONG_CLICK) {
					if (System.currentTimeMillis() >= m_lCreateTime + 1814400000){
						m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title),
								getContext().getString(R.string.popup_send_other_fail));
						m_Popup.setCancelable(false);
						m_Popup.show();
					} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).sendFileOther(m_ChatRoomData.m_JsonObject.toString());
					} else {
						((ChatRoomGroupAct) getContext()).sendFileOther(m_ChatRoomData.m_JsonObject.toString());
					}
					}
				} else {
					ChattingDBManager chattingDBMngd = new ChattingDBManager(getContext());
					chattingDBMngd.openWritable(m_ChatRoomData.m_strRoomID);
					chattingDBMngd.deleteChattingMessage(m_ChatRoomData.m_strMessageID);
					chattingDBMngd.close();

					sendFile();
				}
				break;
			case R.id.tv_pop_second_row:
				m_ListPopup.cancel();
				if (nListPopupCase == LONG_CLICK) {
					m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title),
							getContext().getString(R.string.popup_delete_text_text));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					} else {
						((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					}
				}
				break;
			default:
				break;
			}
		}
	}

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.layout_chat_myfile:
		case R.id.layout_chat_myvideo:
		case R.id.layout_chat_mycontacts:

			nListPopupCase = LONG_CLICK;
			m_ListPopup = new CommonListPopup(getContext(), ChatRoomMyFileLayout.this);
			if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_SUCCESS) {
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_file_longclick_type));
			}
			else {
				nListPopupCase = LONG_CLICK_FAIL;
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(),
						getResources().getStringArray(R.array.arr_chat_file_longclick_fail_type));
			}
			m_ListPopup.setCancelable(true);
			m_ListPopup.show();

		default:
			break;
		}
		return true;
	}


	private void sendFile() {
		String strUserName = null;
		if (m_ChatRoomData.m_strRoomID.length() > 8) {

				Uri uri = Uri.parse(m_ChatRoomData.m_strMyFile);
				((ChatRoomGroupAct) getContext()).reSendDelete(m_ChatRoomData);

				if(m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_CONTACT)){
					strUserName = m_ChatRoomData.m_strMyMSG;
					try {
						JSONObject jsonObject = new JSONObject(m_ChatRoomData.m_JsonObject.toString());
						((ChatRoomGroupAct) getContext()).sendFile(jsonObject.getString(StaticString.XMPP_TEXT_CONTACTFILENAME), uri, strUserName);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				} else {
					((ChatRoomGroupAct) getContext()).sendFile(m_ChatRoomData.m_strMyMSG, uri, strUserName);
				}

		} else {
				Uri uri = Uri.parse(m_ChatRoomData.m_strMyFile);
				CommonLog.e(getClass(), "uri getScheme : " + uri.getScheme());
				CommonLog.e(getClass(), "uri getPath : " + uri.getPath());
				((ChatRoomAct) getContext()).reSendDelete(m_ChatRoomData);
				if(m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_CONTACT)){
					strUserName = m_ChatRoomData.m_strMyMSG;
					try {
						JSONObject jsonObject = new JSONObject(m_ChatRoomData.m_JsonObject.toString());
						((ChatRoomAct) getContext()).sendFile(jsonObject.getString(StaticString.XMPP_TEXT_CONTACTFILENAME), uri, strUserName);
					} catch (JSONException e) {
						e.printStackTrace();
					}
				} else {
					((ChatRoomAct) getContext()).sendFile(m_ChatRoomData.m_strMyMSG, uri, strUserName);
				}

		}
	}
	
	private void startSaveContact(String a_strName, String a_strFilePath)
	{
		try {
			File file = new File(a_strFilePath);
			FileInputStream fis = new FileInputStream(a_strFilePath);
			byte[] b = new byte[(int) file.length()];
			fis.read(b);
			String vCard = new String(b);
			fis.close();
			VCard vcard = Ezvcard.parse(vCard).first();
			ArrayList<ContentValues> data = new ArrayList<ContentValues>();
			
			List<Telephone> arrTele = vcard.getTelephoneNumbers();
			for(Telephone tele : arrTele)
			{
				int nType = Phone.TYPE_OTHER;
				Iterator<TelephoneType> iter = tele.getTypes().iterator();
			    while (iter.hasNext()) {
			    	TelephoneType type = iter.next();
			    	
			    	if(type == TelephoneType.CELL)
			    	{
			    		nType = Phone.TYPE_MOBILE;
			    		break;
			    	}
			    	else if(type == TelephoneType.HOME)
			    	{
			    		nType = Phone.TYPE_HOME;
			    		break;
			    	}
			    	else if(type == TelephoneType.WORK)
			    	{
			    		nType = Phone.TYPE_WORK;
			    		break;
			    	}
			    	else
			    	{
			    		nType = Phone.TYPE_OTHER;
			    		break;
			    	}
			    }
			    
			    ContentValues row = new ContentValues();
				row.put(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE);
				row.put(Phone.NUMBER, tele.getText());
				row.put(Phone.TYPE, nType);
				data.add(row);
			}
			
			List<ezvcard.property.Email> arrEmail = vcard.getEmails();
			for(ezvcard.property.Email email : arrEmail)
			{
				int nType = Email.TYPE_OTHER;
				Iterator<EmailType> iter = email.getTypes().iterator();
				while (iter.hasNext()) {
					EmailType type = iter.next();
					if(type == EmailType.INTERNET)
						continue;
					
					if(type == EmailType.HOME)
					{
						nType = Email.TYPE_HOME;
			    		break;
					}
			    	else if(type == EmailType.WORK)
			    	{
			    		nType = Email.TYPE_WORK;
			    		break;
			    	}
			    	else
			    	{
			    		nType = Email.TYPE_OTHER;
			    		break;
			    	}
				}
				
				ContentValues row = new ContentValues();
				row.put(Data.MIMETYPE, Email.CONTENT_ITEM_TYPE);
				row.put(Email.TYPE, nType);
				row.put(Email.ADDRESS, email.getValue());
				data.add(row);
			}
			
			Intent intent = new Intent(Intent.ACTION_INSERT, Contacts.CONTENT_URI);
			intent.putExtra(ContactsContract.Intents.Insert.NAME, a_strName);
			intent.putParcelableArrayListExtra(Insert.DATA, data);
			getContext().startActivity(intent);
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	ImageLoaderManager.ImageLoaderListener m_ImageLoaderListener = new ImageLoaderManager.ImageLoaderListener() {

		@Override
		public void onSuccess() {
			// TODO Auto-generated method stub
			if (m_ChatRoomData.m_strRoomID.length() > 8) {
				//((ChatRoomGroupAct) getContext()).setDataChanged();

			} else {
				//((ChatRoomAct) getContext()).setDataChanged();
			}

		}

		@Override
		public void onFail(String a_strErrorMsg) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onNotModified() {
			// TODO Auto-generated method stub

		}
	};

	private void startDownload(){
		isDownloading = true;
		FileDownload fileDownload = new FileDownload(getContext(), m_ChatRoomData.m_strRoomID, m_ChatRoomData.m_strMessageID, m_ChatRoomData.m_strMyFile);


		fileDownload.startDownload(new FileDownload.OnDownloadComplete() {

			@Override
			public void onDownloadFail() {
				// TODO Auto-generated method stub
				// 다운로드 실패 처리
				isDownloading = false;
			}

			@Override
			public void onComplete(String a_strFilePath) {
				// TODO Auto-generated method stub
				isDownloading = false;
				CommonLog.e(getContext(), "Result Path : " + a_strFilePath);
				aProgress.setVisibility(View.GONE);
				m_MyTimeAndNosee.setVisibility(View.VISIBLE);
				Intent fileLinkIntent = new Intent(Intent.ACTION_VIEW);

				String extension = a_strFilePath.substring(a_strFilePath.lastIndexOf(".") + 1, a_strFilePath.length());
				extension = extension.toLowerCase();
				File file = new File(a_strFilePath);
				boolean isAction = true;
				if (m_ChatRoomData.m_strMimetype.equals(StaticString.FILE_TYPE_NORMAL)) {
					if (extension.equalsIgnoreCase("txt")) {
						fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "text/*");
					} else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
						fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "application/msword");
					} else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
						fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "application/vnd.ms-excel");
					} else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
						fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "application/vnd.ms-powerpoint");
					} else if (extension.equalsIgnoreCase("pdf")) {
						fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "application/pdf");
					} else if (extension.equalsIgnoreCase("hwp")) {
						fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "application/haansofthwp");
					} else {
						isAction = false;
						String[] arrVideoList = getResources().getStringArray(R.array.arr_chat_video_list);
						String[] arrImageList = getResources().getStringArray(R.array.arr_chat_image_list);
						for (int i = 0; i < arrVideoList.length; i++) {
							if (extension.equalsIgnoreCase(arrVideoList[i])) {
								fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "video/*");
								isAction = true;
								break;
							}
						}
						for (int i = 0; i < arrImageList.length; i++) {
							if (extension.equalsIgnoreCase(arrImageList[i])) {
								fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "image/*");
								isAction = true;
								break;
							}
						}
						if (!isAction) {

							m_Popup = new CommonPopup(getContext(), ChatRoomMyFileLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title), getContext().getString(R.string.popup_fail_file_action));
							m_Popup.setCancelable(false);
							m_Popup.show();
						}

					}
				} else {
					fileLinkIntent.setDataAndType(FileProvider.getUriForFile(getContext(), StaticString.FILE_PROVIDER, file), "video/*");
				}
				if (isAction) {
					fileLinkIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
					PackageManager packageManager = getContext().getPackageManager();
					List activities = packageManager.queryIntentActivities(fileLinkIntent,
							PackageManager.MATCH_DEFAULT_ONLY);
					boolean isIntentSafe = activities.size() > 0;
					if (isIntentSafe) {
						getContext().startActivity(fileLinkIntent);
					} else {
						Toast.makeText(getContext(), getContext().getString(R.string.cork_toast_not_fount_app), Toast.LENGTH_LONG).show();
					}
				}
			}

			@Override
			public void onProgess(int a_nCount, int a_nTotal) {
				// TODO Auto-generated method stub
				// (int)((total*100)/lengoffile))
				CommonLog.e(getContext(), "Progress a_nCount: " + a_nCount + " a_nTotal: " + a_nTotal);
				aProgress.setMax(a_nTotal);
				aProgress.setProgress(a_nCount);
			}

			@Override
			public void onStart() {
				m_MyTimeAndNosee.setVisibility(View.GONE);
				aProgress.setMax(100);
				aProgress.setProgress(0);
				aProgress.setVisibility(View.VISIBLE);
			}
		});
	}
}
