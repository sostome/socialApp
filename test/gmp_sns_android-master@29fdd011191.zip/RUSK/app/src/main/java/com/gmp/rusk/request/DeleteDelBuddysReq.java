package com.gmp.rusk.request;

import java.util.ArrayList;



/**
 *	@author kch
 *			동료 삭제
 *			method : delete
 */

public class DeleteDelBuddysReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "DELETE";
	

	public DeleteDelBuddysReq(int nBuddyNo){
		APINAME = APINAME + "/" + App.m_EntryData.m_nUserNo + "/buddy/" + nBuddyNo;
	}
	public DeleteDelBuddysReq(ArrayList<Integer> a_nArrBuddyNos)
	{
		String strBuddyNos = "";
		for(int i=0;i<a_nArrBuddyNos.size();i++)
		{
			strBuddyNos = strBuddyNos + a_nArrBuddyNos.get(i);
			
			if(i < a_nArrBuddyNos.size()-1)
				strBuddyNos = strBuddyNos + ",";
		}
		APINAME = APINAME + "/" + App.m_EntryData.m_nUserNo + "/buddy/" + strBuddyNos; 
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
