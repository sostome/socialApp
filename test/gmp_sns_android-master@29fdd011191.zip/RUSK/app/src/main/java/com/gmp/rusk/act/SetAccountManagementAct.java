package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetGroupListReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetGroupListRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.SharedPref;

import java.util.ArrayList;

/**
 * SetAccountManagementAct
 * 
 * @author subi78 계정 관리 Activity
 */
public class SetAccountManagementAct extends CustomActivity {
	private CommonPopup m_Popup = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_set_account_management);

		setResult(Activity.RESULT_CANCELED);
		setAccountManagementUI();
	}

	private void setAccountManagementUI() {

		ImageView ivClose = (ImageView)findViewById(R.id.btn_cancel);
		ivClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		LinearLayout layout_account_management_passwordchange = (LinearLayout) findViewById(R.id.layout_account_management_passwordchange);
		layout_account_management_passwordchange.setOnClickListener(this);

		LinearLayout layout_account_management_out = (LinearLayout) findViewById(R.id.layout_account_management_out);
		layout_account_management_out.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		Intent intent = null;
		if (v.getId() == R.id.layout_account_management_passwordchange) {
			intent = new Intent(SetAccountManagementAct.this, SetPasswordChangeAct.class);
			startActivity(intent);
		} else if (v.getId() == R.id.layout_account_management_out) {
			getGroupListOwner();
		} else if (v.getId() == R.id.ib_pop_cancel) {
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		} else if (v.getId() == R.id.ib_pop_ok) {
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			popup_ok.cancel();
			intent = new Intent(SetAccountManagementAct.this, SetOutAct.class);
			startActivity(intent);
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		}
	}

	private void getGroupListOwner(){
		GetGroupListReq req = new GetGroupListReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
			@Override
			public void onPreRequest() {
				showProgress();
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				closeProgress();
				showErrorPopup(nErrorCode, strMessage);
			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
				boolean isHasOwner = false;
				GetGroupListRes res = new GetGroupListRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_LIST);

				ArrayList<ChannelData> arrMemberChannelData = res.getMemberChannelListData();

				if(arrMemberChannelData != null && arrMemberChannelData.size() > 0){
					for(int i = 0; i < arrMemberChannelData.size(); i++){
						if(arrMemberChannelData.get(i).m_isOwner){
							isHasOwner = true;
							break;
						}
					}
				}
				getRoomInfo(isHasOwner);
			}
		});
	}

	private void getRoomInfo(boolean hasOwner){
		boolean isChannelOwner = hasOwner;
		if(isChannelOwner){
			m_Popup = new CommonPopup(SetAccountManagementAct.this, SetAccountManagementAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.error_preview_out).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		} else {
			boolean isChatroomOwner = false;
			ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(this);
			for (int i = 0; i < arrRoomData.size(); i++) {
				if (arrRoomData.get(i).m_strRoomId.length() >= 8 && arrRoomData.get(i).m_nRoomOwnerId == App.m_MyUserInfo.m_nUserNo) {
					isChatroomOwner = true;
					break;
				}
			}
			if (isChatroomOwner) {
				m_Popup = new CommonPopup(SetAccountManagementAct.this, SetAccountManagementAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.error_preview_out_chatroom).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_Popup = new CommonPopup(SetAccountManagementAct.this, SetAccountManagementAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.set_preview_out).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
}
