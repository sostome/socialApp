package com.gmp.rusk.datamodel;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-14.
 */

public class ChannelNoticeData {


    public int m_nThreadNo = -1;
    public String m_strTitle = "";
    public String m_strBody = "";
    public String m_strCreatedDate = "";
    public String m_strUpdatedTime = "";

    public ArrayList<ChannelFileData> m_arrChannelFileData = new ArrayList<ChannelFileData>();

}
