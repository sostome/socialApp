package com.gmp.rusk.act;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.imageloader.FileCacheDBAdapter;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetRegularReq;
import com.gmp.rusk.request.PostChangeImageReq;
import com.gmp.rusk.request.PostRegularReq;
import com.gmp.rusk.response.GetRegularRes;
import com.gmp.rusk.response.PostRegularRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;

/**
 * RegularSignUpAct
 * 
 * @author subi78 정회원 회원가입 Activity
 */
public class RegularSignUpAct extends Activity implements OnClickListener {

	private boolean isTwo = false;

	public MyApp App = MyApp.getInstance();
	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;

	private boolean m_isImageAvailable = false;
	
	private String m_strPreviewImageUrlTemplate = "";

	private int m_nUserNo = 0;

	private TakeMediaIntent m_TakeMedia = null;

	private Bitmap m_Bitmap;
	private byte[] m_BitmapByte;

	private boolean m_isUploadImage = false;

	private ImageView iv_signup_pic;

	private boolean m_isCrop = false;

	private CommonListPopup m_ListPopup = null;
	public boolean m_isRunning = false;

	public boolean m_isSetImage = false; //이미지가 set된 경우에만 Cork가입이 완료되었습니다. 메시지 보고 분기 처리(ok_long)

	//이미지가 없는 상태에서, 이미지를 등록 한 후 '편집' 을 누를때 사용
	private Uri m_cropUri = null;

	//카메라로 찍고 '편집'을 누를때 사용
	private boolean m_isCamera = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_regular_signup);

		requestGetRegularReq();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;

		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}

	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	
	private void setSignUpUI(String a_strImageUrl, String a_strName, String a_strTeam) {

		TextView tv_profile_name = (TextView) findViewById(R.id.tv_profile_name);
		TextView tv_profile_team = (TextView) findViewById(R.id.tv_profile_team);
		TextView tv_profile_regularid = (TextView) findViewById(R.id.tv_profile_regularid);

		tv_profile_name.setText(a_strName);
		tv_profile_team.setText(a_strTeam);
		tv_profile_regularid.setText(App.m_GMPData.m_strRegularID);

		iv_signup_pic = (ImageView) findViewById(R.id.iv_signup_pic);

		if (m_isImageAvailable)
			App.imageloader.getProfileImage(iv_signup_pic, a_strImageUrl, R.drawable.sign_up_pic_default_frame, false);
		else
			iv_signup_pic.setImageResource(R.drawable.sign_up_pic_default_frame);

		ImageView ib_sign_up = (ImageView) findViewById(R.id.ib_sign_up);
		ib_sign_up.setOnClickListener(this);

		ImageButton ib_signup_edit = (ImageButton) findViewById(R.id.ib_signup_edit);
		ib_signup_edit.setOnClickListener(this);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == StaticString.REQUESTCODE_PARTNER_SIGNUP_SUCCESS) {
				setResult(Activity.RESULT_OK);
				finish();
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM) {
				// Album에서 Image 선택후 Crop 실행
				m_isCamera = false;
				/*m_cropUri = data.getData();
				m_TakeMedia.doCropImageFromAlbumWithAspect(data.getData());*/
				Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
				ArrayList<GalleryListData> arrSelectedImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);
				if(arrSelectedImage != null && arrSelectedImage.size() > 0)
				{
					GalleryListData galleryListData = arrSelectedImage.get(0);
					CommonLog.e(getClass(), "getDirName : " + galleryListData.getDirName());
					CommonLog.e(getClass(), "getDirPath : " + galleryListData.getDirPath());
					CommonLog.e(getClass(), "getSdcardPath : " + galleryListData.getSdcardPath());
					m_cropUri = Uri.fromFile(new File(galleryListData.getSdcardPath()));
					m_TakeMedia.doCropImageFromAlbumWithAspect(Uri.fromFile(new File(galleryListData.getSdcardPath())));
				}
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CAMERA) {
				// 카메라 촬영후 Crop 실행
				m_isCamera = true;
				m_cropUri = null;
				m_TakeMedia.doCropImageFromCameraWithAspect();
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				m_isCrop = true;
				// Crop이 완료된 이미지를 가져옴
				m_isUploadImage = true;
				m_BitmapByte = m_TakeMedia.getCropImageByte();
				m_Bitmap = m_TakeMedia.getCropImageBitmap();

				iv_signup_pic.setImageBitmap(m_Bitmap);

				// setMyImage(StaticString.CHAT_ROOM_MY_IMAGE, 0, m_Bitmap, m_BitmapByte);
				//
				// m_ivSampleImage.setImageBitmap(m_Bitmap);
			}
		} else {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM || requestCode == TakeMediaIntent.REQUESTCODE_CAMERA || requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				// 취소등에 의한 후처리 필요
				m_TakeMedia.deleteDirectory();
				m_TakeMedia = null;
			}
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		//이미지 설정이 된 사람의 경우 회원가입완료 메시지 보여주고 종료
		if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_COMPLETE){
				popup_ok_long.cancel();
				if(m_isSetImage)
					App.m_MyUserInfo.m_isImageAvailable = true;
				setResult(Activity.RESULT_OK);
				finish();
			} else {
				popup_ok_long.cancel();
			}
		} else if (v.getId() == R.id.ib_sign_up) {
			requestPostRegularReq();
		} else if (v.getId() == R.id.ib_signup_edit) {
			m_ListPopup = new CommonListPopup(RegularSignUpAct.this, RegularSignUpAct.this);
			if (m_isImageAvailable || m_isCrop)
				m_ListPopup.setBodyAndTitleText(getString(R.string.pic_edit_title).toString(), getResources().getStringArray(R.array.arr_pic_edit));
			else
				m_ListPopup.setBodyAndTitleText(getString(R.string.pic_edit_title).toString(), getResources().getStringArray(R.array.arr_pic_edit_noimage));
			m_ListPopup.setCancelable(false);
			m_ListPopup.show();
			
			
//			AlertDialog.Builder listBuilder = new AlertDialog.Builder(this);
//			if (m_isImageAvailable && !m_isCrop) {
//				listBuilder.setTitle(getString(R.string.pic_edit_title).toString());
//
//				listBuilder.setItems(R.array.arr_pic_edit, new DialogInterface.OnClickListener() {
//
//					public void onClick(DialogInterface dialog, int item) {
//						if (item == 0) {
//							m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
//							m_TakeMedia.doGetImageFromAlbum();
//						} else if (item == 1) {
//							m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
//							m_TakeMedia.doTakeImageFromCamera();
//						} else if (item == 2) {
//							CommonLog.e("", "image edit 1");
//							Uri a_Uri = null;
//							m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
//							if (m_isCrop) {
//								CommonLog.e("", "image edit isCrop");
//								a_Uri = Uri.fromFile(new File(m_TakeMedia.getCropImageFilePath()));
//							} else {
//								CommonLog.e("", "image edit not isCrop");
//								FileCacheDBAdapter db = new FileCacheDBAdapter(RegularSignUpAct.this);
//								db.openReadOnly();
//								String strFileName = db.getFileCache(App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo, true));
//								db.close();
//								File file = new File(RegularSignUpAct.this.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), strFileName);
//								a_Uri = Uri.fromFile(new File(file.getPath()));
//
//							}
//							if (a_Uri != null) {
//								CommonLog.e("", "image edit go doCropImage");
//								m_TakeMedia.doCropImage(a_Uri);
//							}
//						}
//					}
//				});
//			} else {
//				listBuilder.setTitle(getString(R.string.pic_edit_title).toString());
//
//				listBuilder.setItems(R.array.arr_pic_edit_noimage, new DialogInterface.OnClickListener() {
//
//					public void onClick(DialogInterface dialog, int item) {
//						if (item == 0) {
//							m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
//							m_TakeMedia.doGetImageFromAlbum();
//						} else if (item == 1) {
//							m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
//							m_TakeMedia.doTakeImageFromCamera();
//						}
//					}
//				});
//			}
//			AlertDialog alertList = listBuilder.create();
//
//			alertList.show();
		}
		else if(v.getId() == R.id.ib_pop_cancel_long)
		{
			m_ListPopup.cancel();
		}
		else if(v.getId() == R.id.tv_pop_first_row)
		{
			m_ListPopup.cancel();
			m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
			m_TakeMedia.doGetImageFromAlbum();
		}
		else if(v.getId() == R.id.tv_pop_second_row)
		{
			m_ListPopup.cancel();
			m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
			m_TakeMedia.doTakeImageFromCamera();
		}
		else if(v.getId() == R.id.tv_pop_third_row)
		{
			m_ListPopup.cancel();
			Uri a_Uri = null;
			m_TakeMedia = new TakeMediaIntent(RegularSignUpAct.this);
			if (m_isCrop) {
				CommonLog.e("", "image edit isCrop");
				if(m_cropUri == null && !m_isCamera) {
					a_Uri = Uri.fromFile(new File(m_TakeMedia.getCropImageFilePath()));
				} else if(m_cropUri == null && m_isCamera){
					m_TakeMedia.doCropImageFromCameraWithAspect();
					return;
				}
				else if(m_cropUri != null && !m_isCamera){
					a_Uri = m_cropUri;
				}
			} else {
				CommonLog.e("", "image edit not isCrop");
				/*FileCacheDBAdapter db = new FileCacheDBAdapter(RegularSignUpAct.this);
				db.openReadOnly();
				
				String strFileName = db.getFileCache(m_strPreviewImageUrlTemplate.replace(
						"{userNo}", "" + m_nUserNo).replace("{userNoModuloBy1000}", ""+m_nUserNo%1000));
				db.close();
				File file = new File(RegularSignUpAct.this.getFilesDir(), strFileName);
				a_Uri = Uri.fromFile(new File(file.getPath()));*/
				Bitmap bmp = ((BitmapDrawable)iv_signup_pic.getDrawable()).getBitmap();
				ByteArrayOutputStream bytes = new ByteArrayOutputStream();
				bmp.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
				String path = MediaStore.Images.Media.insertImage(getContentResolver(), bmp, "Title", null);
				a_Uri = Uri.parse(path);

			}
			if (a_Uri != null) {
				CommonLog.e("", "image edit go doCropImage");
				m_TakeMedia.doCropImage(a_Uri, true);
			}
		} else if(v.getId() == R.id.ib_pop_ok){
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_COMPLETE);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.cork_pop_msg_join).toString());
			m_Popup.setCancelable(false);
			m_Popup.show();
		} else if(v.getId() == R.id.ib_pop_cancel){
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		}
	}

	// 이미지 전송
	public void requestPostChangeImage(final Bitmap a_Bitmap, byte[] a_BitmapByte) {
		showProgress();
		PostChangeImageReq req = new PostChangeImageReq(m_nUserNo);
		req.setFileData(a_BitmapByte);

		WebAPI webApi = new WebAPI(this);
		webApi.requestUpload(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String strData) {
				// TODO Auto-generated method stub
				closeProgress();
				m_isSetImage = true;
				m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_COMPLETE);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.cork_pop_msg_join).toString());
				m_Popup.setCancelable(false);
				m_Popup.show();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						a_strMessage);
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		});
	}

	private void requestGetRegularReq() {
		showProgress();
		GetRegularReq req = new GetRegularReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetRegularRes res = new GetRegularRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				m_nUserNo = res.getEntryUserData(getApplicationContext()).m_nUserNo;
				m_isImageAvailable = res.getEntryUserData(getApplicationContext()).m_isImageAvailable;
				m_strPreviewImageUrlTemplate = App.m_EntryData.m_strPreviewImageUrlTemplate;
				setSignUpUI(m_strPreviewImageUrlTemplate.replace(
						"{userNo}", "" + m_nUserNo).replace("{userNoModuloBy1000}", ""+m_nUserNo%1000), res.getEntryUserData(getApplicationContext()).m_strName, res.getEntryUserData(getApplicationContext()).m_strDepartment);
//				setSignUpUI(res.m_strPreviewImageUrlTemplate.replace("{userNo}", "" + 1297), res.m_strName, res.m_strDepartment);
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
//				if (a_nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_FOUND) {
//
//					m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.partner_signup_popup_useid_fail).toString());
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				}
				m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						a_strMessage);
				m_Popup.setCancelable(false);
				isCheckShowPopup();

			}
		});
	}

	private void requestPostRegularReq() {
		showProgress();
		PostRegularReq req = new PostRegularReq(m_nUserNo);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				PostRegularRes res = new PostRegularRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				
				
					
				//App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate, res.m_strPreviewImageUrlTemplate,res.m_strEmoticonTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);
				App.m_MyUserInfo = res.getEntryUserData(getApplicationContext());
				
				if (m_isUploadImage) {
					//이미지 지정이 되있는 경우 requestPostChangeImage 이후 회원가입 완료 메시지를 띄우고 종료
					requestPostChangeImage(m_Bitmap, m_BitmapByte);
				} else {
					m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_confirm).toString(), getString(R.string.cork_pop_msg_join_noprofile).toString());
					m_Popup.setCancelable(false);
					m_Popup.show();
				}

			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
//				if (a_nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_FOUND) {
//
//					m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.partner_signup_popup_useid_fail).toString());
//					m_Popup.setCancelable(false);
//					isCheckShowPopup();
//				}
				m_Popup = new CommonPopup(RegularSignUpAct.this, RegularSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						a_strMessage);
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		});
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if (!isTwo) {
			Toast.makeText(this, getString(R.string.press_back_key), Toast.LENGTH_SHORT).show();
			myTimer timer = new myTimer(2000, 1); // 2초동안 수행
			timer.start(); // 타이머를 이용해줍시다
		} else // super.onBackPressed();
		{
			// android.os.Process.killProcess(android.os.Process.myPid()); //프로세스 끝내기
			super.onBackPressed();
		}
	}

	public class myTimer extends CountDownTimer {

		public myTimer(long millisInFuture, long countDownInterval) {
			super(millisInFuture, countDownInterval);
			// TODO Auto-generated constructor stub
			isTwo = true;
		}

		@Override
		public void onFinish() {
			isTwo = false;
		}

		@Override
		public void onTick(long millisUntilFinished) {
			// TODO Auto-generated method stub

		}
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}
}
