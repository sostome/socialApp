package com.gmp.rusk.extension;

import java.util.ArrayList;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

public class IQUsersEx extends IQ {
	public final static String NAMESPACE = "jabber:iq:users";
//	private final String NAMESPACE_Q = "<query xmlns=\"jabber:iq:users\">";

	private ArrayList<String> users;
	private String owner;
	private String namespace = null;

	public IQUsersEx() {
	}

	public IQUsersEx(String namespace, ArrayList<String> nodes, String owner) {
		this.namespace = namespace;
		this.users = nodes;
		this.owner = owner;
	}

	
	@Override
	public String getChildElementXML() {
		StringBuilder buf = new StringBuilder();
//		buf.append(NAMESPACE_Q);
//		if (namespace != null) {
//			buf.append("<user>").append(namespace).append("</user>");
//		}
//		buf.append("</query>");
		return buf.toString();
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getNamespace() {
		return namespace;
	}
	
	public ArrayList<String> getUsers(){
		return this.users;
	}
	
	public String getOwnerUser(){
		return this.owner;
	}

	public static class Provider implements IQProvider {

		@Override
		public IQ parseIQ(XmlPullParser parser) throws Exception {
			// TODO Auto-generated method stub
			ArrayList<String> users = new ArrayList<String>();
			String owner = null;
			String namespace = null;
			boolean done = false;
			while (!done) {
				int eventType = parser.next();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getAttributeCount() == 1) {
						owner = parser.nextText();
					} else {
						
						users.add(parser.nextText());
					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals("query")) {
						namespace = parser.getNamespace();
						done = true;

					}
				}
			}
			return new IQUsersEx(namespace, users, owner);
		}

	}

}