package com.gmp.rusk.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.FindIdPwTabAct;
import com.gmp.rusk.act.FindPwSendEmailSuccessAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostFindPasswordAuthPartnerReq;
import com.gmp.rusk.request.PostFindPasswordPartnerReq;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.Utils;

/**
 * ApprovalAcceptListFlag
 * @author subi78
 * ApprovalAcceptListFlag - 승인 완료 리스트 Fragment
 */
public class FindPwFlag extends Fragment implements OnClickListener{

	public MyApp App = MyApp.getInstance();
	private View m_vFindPw = null;	
	
	EditText et_findpw_id;
	EditText et_findpw_name;
	EditText et_findpw_email;
	EditText et_findpw_authnum;
	
	private FragmentActivity m_Activity = null;
	
	private ProgressDlg m_Progress = null;
	
	private CommonPopup m_Popup = null;
	public boolean m_isRunning = false;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        m_Activity = getActivity();

    }
    
    /**
     * The Fragment's UI is just a simple text view showing its
     * instance number.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    	
    	m_vFindPw = inflater.inflate(R.layout.fragact_findpw, container, false);
    	
    	((FindIdPwTabAct)m_Activity).setTitle(getString(R.string.findidpwtab_title));
    	
    	initSetUI();
    	
        return m_vFindPw;
    }
    
    @Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
    

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_ok)
		{	
			if(et_findpw_id.getText().length() < 6)
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_userid_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(et_findpw_name.getText().length() == 0)
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_name_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(!Utils.isEmailAddress(et_findpw_email.getText().toString()))
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_email_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(et_findpw_authnum.getText().length() == 0)
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_authnum_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			requestPostFindPasswordPartner(et_findpw_id.getText().toString(), et_findpw_name.getText().toString(), et_findpw_email.getText().toString(), et_findpw_authnum.getText().toString());
		}
		else if(v.getId() == R.id.ib_number)
		{
			if(et_findpw_id.getText().length() < 6)
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_userid_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(et_findpw_name.getText().length() == 0)
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_name_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(!Utils.isEmailAddress(et_findpw_email.getText().toString()))
			{
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_email_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			requestPostFindPasswordAuthPartner(et_findpw_id.getText().toString(), et_findpw_name.getText().toString(), et_findpw_email.getText().toString());
		}
		else if(v.getId() == R.id.ib_pop_ok)
		{
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			popup_ok.cancel();
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
		}
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	popup_ok_long.cancel();
				App.expirePartnerLogin(m_Activity);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Activity);
			}
			else
			{
				popup_ok_long.cancel();
			}
		}
	}
    
    private void initSetUI()
    {
    	et_findpw_id = (EditText)m_vFindPw.findViewById(R.id.et_findpw_id);
    	et_findpw_name = (EditText)m_vFindPw.findViewById(R.id.et_findpw_name);
    	et_findpw_email = (EditText)m_vFindPw.findViewById(R.id.et_findpw_email);
    	et_findpw_authnum = (EditText)m_vFindPw.findViewById(R.id.et_findpw_authnum);
    	
    	Button ib_number = (Button)m_vFindPw.findViewById(R.id.ib_number);
    	ib_number.setOnClickListener(this);
    	
    	Button ib_ok = (Button)m_vFindPw.findViewById(R.id.ib_ok);
    	ib_ok.setOnClickListener(this);
    }
    
	private void requestPostFindPasswordAuthPartner(String a_strUserId, String a_strName, String a_strEmail)
	{
		showProgress();
		PostFindPasswordAuthPartnerReq req = new PostFindPasswordAuthPartnerReq(a_strUserId, a_strName, a_strEmail);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_findidpw_request_authnum));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, FindPwFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(getActivity(), FindPwFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
	private void requestPostFindPasswordPartner(String a_strUserId, String a_strName, String a_strEmail, String a_strAuthnum)
	{
		showProgress();
		PostFindPasswordPartnerReq req = new PostFindPasswordPartnerReq(a_strUserId, a_strAuthnum);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				Intent intent = new Intent(m_Activity, FindPwSendEmailSuccessAct.class);
				startActivity(intent);
				m_Activity.finish();
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, FindPwFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(getActivity(), FindPwFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, FindPwFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
    
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}

}