package com.gmp.rusk.utils;

import android.os.Environment;

import com.gmp.rusk.act.FileMultiSelectorAct;
import com.gmp.rusk.datamodel.FileInfo;

import java.io.File;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Stack;

/**
 * Created by K on 2016-08-08.
 */
public class FileExplorer {

    private Stack<String> m_stackFolderName;

    final public static int TYPE_ROOT = 0;
    final public static int TYPE_NEXT = 1;
    final public static int TYPE_PREVIOUS = 2;

    public String getNowFolder(){
        return m_stackFolderName.peek();
    }

    public ArrayList<FileInfo> setFolder(String strFolder, int nType){

        if(nType == TYPE_ROOT) {
            m_stackFolderName = new Stack<String>();

            Stack<String> stackParentFolder = new Stack<String>();
            String strParent = "";
            File parent = Environment.getExternalStorageDirectory().getParentFile();
            while (!parent.getPath().equals("/")) {
                if (parent.getPath().equals("/")) {
                    strParent = parent.getPath();
                    stackParentFolder.push(strParent);
                } else {
                    strParent = parent.getPath();
                    stackParentFolder.push(strParent);
                    parent = parent.getParentFile();
                }
            }
            strParent = parent.getPath();
            stackParentFolder.push(strParent);

            if (!stackParentFolder.isEmpty()) {

                while (!stackParentFolder.isEmpty()) {
                    m_stackFolderName.push(stackParentFolder.pop());
                }

            }
            m_stackFolderName.push(strFolder);
        } else if(nType == TYPE_NEXT){
            if(!strFolder.equals(m_stackFolderName.peek())){
                if(m_stackFolderName.size() == 1){
                    m_stackFolderName.push("/" + strFolder);
                } else {
                    m_stackFolderName.push(m_stackFolderName.peek() + "/" + strFolder);
                }
            }
        } else if(nType == TYPE_PREVIOUS){
            if(m_stackFolderName.size() >= 1){
                m_stackFolderName.pop();
            }
        }


        ArrayList<FileInfo> arrFileInfo = new ArrayList<>();
        ArrayList<String> arrNowFolderFileNameInfo = new ArrayList<>();
        File file = new File(m_stackFolderName.peek());

        if(file != null && file.exists() && file.canRead()){
            String[] fileList = file.list();
            for(String strFile : fileList) {
                arrNowFolderFileNameInfo.add(strFile);
            }

        }
        Collections.sort(arrNowFolderFileNameInfo, comparator);

        int index = 0;
        for(String info : arrNowFolderFileNameInfo){
            File fileInfo = new File(m_stackFolderName.peek() + "/" + info);
            if(fileInfo.isDirectory()){
                arrFileInfo.add(index++, new FileInfo(fileInfo, FileMultiSelectorAct.VIEW_TYPE_ROW_1));
            } else {
                arrFileInfo.add(new FileInfo(fileInfo, FileMultiSelectorAct.VIEW_TYPE_ROW_2));
            }
        }

        return arrFileInfo;
    }

    Comparator<String> comparator = new Comparator<String>() {
        private final Collator collator = Collator.getInstance();
        @Override
        public int compare(String lhs, String rhs) {
            return collator.compare(lhs.substring(lhs.lastIndexOf(".") + 1, lhs.length()).toLowerCase(), rhs.substring(rhs.lastIndexOf(".") + 1, rhs.length()).toLowerCase());
        }
    };
}
