package com.gmp.rusk.customview;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.gmp.rusk.imageloader.FileCacheDBAdapter;
import com.gmp.rusk.imageloader.ImageDownloadCompleteListener;
import com.gmp.rusk.imageloader.ImageDownloader;
import com.gmp.rusk.utils.CommonLog;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.widget.ImageView;

public class CustomImageView extends ImageView implements ImageDownloadCompleteListener {

	Context m_Context;

	private static CustomImageView m_Instance = null;
	private ImageDownloader m_ImageDownloader = new ImageDownloader(this);

	public CustomImageView(Context context) {
		super(context);
		m_Context = context;
		// TODO Auto-generated constructor stub
	}

	public CustomImageView(Context context, AttributeSet attr) {
		super(context, attr);
		m_Context = context;
		// TODO Auto-generated constructor stub
	}

	private void setContext(Context a_Context) {
		m_Context = a_Context;
	}

	public static CustomImageView getInstance(Context a_Context) {
		if (m_Instance == null)
			m_Instance = new CustomImageView(a_Context);
		else
			m_Instance.setContext(a_Context);

		return m_Instance;
	}

	public void getImage(ImageView a_ivImage, String a_strUrl, int a_nResId, int a_nWidth, int a_nHeight) {
		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
		db.openReadOnly();
		String strFileName = db.getFileCache(a_strUrl);
		db.close();

		CommonLog.e("", "String strFileName = " + strFileName);

		String strIfModifiedSince = "";

		if (TextUtils.isEmpty(strFileName)) {
			// Default Image Set
			setDafaultImage(a_ivImage, a_nResId);
		} else {
			// File Load And Set Image
			File file = new File(m_Context.getFilesDir(), strFileName);
			if (file == null || !file.exists()) {
				// Default Image Set
				setDafaultImage(a_ivImage, a_nResId);
			} 
//			else {
//				Bitmap bmp = readImageFile(file);
//				int height = a_nHeight;
//				int width = a_nWidth;
//
//				CommonLog.e(m_Context, "Width : " + width);
//				CommonLog.e(m_Context, "Height : " + height);
//				Bitmap resizedBmp = null;
//
//				if (width >= height) {
//					height = (height * 500) / width;
//					width = 500;
//				} else if(width < height){
//					width = (width * 400) / height;
//					height = 400;
//				}
//				resizedBmp = Bitmap.createScaledBitmap(bmp, width, height, true);
//				CommonLog.e(m_Context, "Width : " + width);
//				CommonLog.e(m_Context, "Height : " + height);
//				if (resizedBmp != null) {
//					strIfModifiedSince = "" + file.lastModified();
//					a_ivImage.setImageBitmap(resizedBmp);
//				} else
//					setDafaultImage(a_ivImage, a_nResId);
//			}
			else
			{
				Bitmap bmp = readImageFile(file);
				if(bmp != null)
				{
					strIfModifiedSince = "" + file.lastModified();
					a_ivImage.setImageBitmap(bmp);
				}
				else
					setDafaultImage(a_ivImage, a_nResId);
			}
		}

		// Download 수행
		//m_ImageDownloader.download(a_strUrl, a_ivImage, strIfModifiedSince);
	}

	private void setDafaultImage(ImageView a_ivImage, int a_nResId) {
		if (a_nResId > 0)
			a_ivImage.setImageResource(a_nResId);
	}

	private Bitmap readImageFile(File a_fileImage) {
		return BitmapFactory.decodeFile(a_fileImage.getPath());
	}

	@Override
	public void onComplete(String a_strUrl, Bitmap a_bmpImage) {
		// TODO Auto-generated method stub
		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
		db.open();

		String strFileName = db.getFileCache(a_strUrl);
		if (TextUtils.isEmpty(strFileName)) {
			String[] arrUrl = a_strUrl.split("/");
			strFileName = arrUrl[arrUrl.length - 1];
			db.insertFileCache(a_strUrl, strFileName);
		}

		File fileImage = new File(m_Context.getFilesDir(), strFileName);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileImage);
			a_bmpImage.compress(CompressFormat.JPEG, 60, fos);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		db.close();
	}
	
	@Override
	public void onFail(String a_strUrl, int a_nErrorCode, String a_strErrorMsg) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void onNotModified(String a_strUrl, Bitmap a_bmp) {
		// TODO Auto-generated method stub
		
	}
}
