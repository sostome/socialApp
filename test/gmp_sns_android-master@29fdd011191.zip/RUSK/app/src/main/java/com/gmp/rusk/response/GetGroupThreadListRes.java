package com.gmp.rusk.response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GetGroupThreadListRes extends ChannelRes{

	public int m_nSize = 0;
	public long m_lnTotalElement = 0L;
	public int m_nTotalPages = 0;
	public int m_nNumber = 0;

	public GetGroupThreadListRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);

			if (!jsonRoot.isNull(JSON_SIZE)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_SIZE);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);

						m_nSize = jsonItem.getInt(JSON_SIZE);
						m_lnTotalElement = jsonItem.getInt(JSON_TOTALELEMENTS);
						m_nTotalPages = jsonItem.getInt(JSON_TOTALPAGES);
						m_nNumber = jsonItem.getInt(JSON_NUMBER);

					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
