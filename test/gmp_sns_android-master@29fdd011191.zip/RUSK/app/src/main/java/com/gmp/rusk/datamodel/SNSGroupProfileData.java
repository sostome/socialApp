package com.gmp.rusk.datamodel;

public class SNSGroupProfileData {
	
	public static final String GROUP_MEMBERED_NOTYET 	= "N";	// 미수락
	public static final String GROUP_MEMBERED_RETRY 	= "R";	// 재초대
	public static final String GROUP_MEMBERED_YES 		= "Y";	// 수락
	
	public int m_nGroupId = 0;
	public String m_strGroupName = "";
	public int m_nImageIndex = -1;
	public String m_strGroupImageUrl = "";
	public String m_strGroupPreviewImageUrl = "";
	public String m_strMembered = GROUP_MEMBERED_NOTYET;
	public int m_nGuestCount = 0;	// 모임 초대 인원수
	public int m_nUserCount = 0;	// 참여 인원 수
	public String m_strOwnerName = "";
	public String m_strCompany = "";
	public String m_strDepartment = "";
}
