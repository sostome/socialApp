package com.gmp.rusk.datamodel;

public class AddedByFellowListData {
	public int m_nUserNo = 0;					//동료 사용자 번호
	
	public AddedByFellowListData(int a_nUserNo) {
		m_nUserNo = a_nUserNo;
	}
}
