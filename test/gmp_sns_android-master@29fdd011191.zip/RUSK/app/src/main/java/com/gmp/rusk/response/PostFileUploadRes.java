package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

public class PostFileUploadRes extends Res{
	private final String JSON_URL 						= "url";
	private final String JSON_PREVIEWURL	 			= "previewUrl";
	
	public String m_strUrl = "";
	public String m_strPreviewUrl = "";
	
	public PostFileUploadRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if(!jsonRoot.isNull(JSON_URL)) {
				m_strUrl = jsonRoot.optString(JSON_URL);
			}
			
			if(!jsonRoot.isNull(JSON_PREVIEWURL)) {
				m_strPreviewUrl = jsonRoot.optString(JSON_PREVIEWURL);
			}
			

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

}
