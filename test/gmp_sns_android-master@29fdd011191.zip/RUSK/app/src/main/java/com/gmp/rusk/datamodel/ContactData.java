package com.gmp.rusk.datamodel;

/**
 * Created by kang on 2017-05-31.
 */

public class ContactData {
    private long phoneId;
    private String phoneNumber;
    private String name;
    private String chosung;
    private int viewType = 1;
    private boolean isChecked = false;

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public ContactData() {

    }
    public ContactData(String a_phoneNumber,int a_viewType) {
        phoneNumber = a_phoneNumber;
        viewType = a_viewType;
    }

    public String getChosung() {
        return chosung;
    }

    public void setChosung(String chosung) {
        this.chosung = chosung;
    }

    public int getViewType() {
        return viewType;
    }

    public void setViewType(int viewType) {
        this.viewType = viewType;
    }

    public long getPhoneId() {
        return phoneId;
    }

    public void setPhoneId(long phoneId) {
        this.phoneId = phoneId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
