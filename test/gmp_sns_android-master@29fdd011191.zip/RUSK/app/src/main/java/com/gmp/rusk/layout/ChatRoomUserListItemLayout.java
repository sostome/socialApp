package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomExitOtherAct;
import com.gmp.rusk.act.ChatRoomMemberAct;
import com.gmp.rusk.act.ChatRoomOwnerAct;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostAddBuddysReq;

import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.HashMap;

/**
 * ChatRoomUserListItemLayout 채팅방 인물 List Item Layout
 */
public class ChatRoomUserListItemLayout extends CustomLinearLayout implements OnClickListener, OnCheckedChangeListener {

	ImageButton ib_add_fellow;
	View m_lineBottom;

	Context m_Context;

	public final static int CHATROOM_ITEM_TYPE_MEMBER = 1;
	public final static int CHATROOM_ITEM_TYPE_EXIT = 2;
	public final static int CHATROOM_ITEM_TYPE_OWNER = 3;
	public final static int CHATROOM_ITEM_TYPE_CHECK = 4;

	int m_nType;
	private UserListData m_UserListData = null;
	int m_nOwnerNo = 0;
	int m_nPostion = 0;
	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;
	boolean m_isRead = false;

	HashMap<String, String> m_mapPersonalData;
	public ChatRoomUserListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public ChatRoomUserListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public ChatRoomUserListItemLayout(Context context, int nType) {
		super(context);
		// TODO Auto-generated constructor stub
		m_nType = nType;
		init(context);
	}

	private void init(Context a_context) {
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		View m_View = layoutInflater.inflate(R.layout.layout_listitem_chatroom_menu_user, this);
		RelativeLayout layout_checkbox = (RelativeLayout) m_View.findViewById(R.id.layout_checkbox);
		layout_checkbox.setVisibility(VISIBLE);

	}

	public void setOwner(int a_nOwnerNo) {
		m_nOwnerNo = a_nOwnerNo;
	}

	public void setUserListData(UserListData a_Data) {
		m_UserListData = a_Data;
		if(m_UserListData != null)
			setUiData();
	}

	// 강제 탈퇴 시 사용
	public void setPosition(int a_nPosition) {
		m_nPostion = a_nPosition;
	}
	
	public void setRead(boolean a_isRead){
		m_isRead = a_isRead;
	}

	// UI 세팅
	private void setUiData() {
		m_lineBottom = findViewById(R.id.line_bottom);
		ImageView iv_profile_pic = (ImageView) findViewById(R.id.iv_profile_pic);
		iv_profile_pic.setOnClickListener(this);
		ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);
		if (m_UserListData.m_isImageAvailable) {
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_UserListData.m_nUserNo, true), R.drawable.profile_pic_default, false);
		}
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}

		ImageView ivIconPartner = (ImageView) findViewById(R.id.iv_chatlist_icon_partner);
		if(m_UserListData.m_strUserType.equals("R")){
			ivIconPartner.setVisibility(GONE);
		} else {
			ivIconPartner.setVisibility(VISIBLE);
		}

		TextView tv_name = (TextView) findViewById(R.id.tv_name);
		LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
		TextView tv_position = (TextView) findViewById(R.id.tv_position);
		LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
		TextView tv_charge = (TextView) findViewById(R.id.tv_charge);
		TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
		TextView tv_departments = (TextView) findViewById(R.id.tv_departments);

		if (m_UserListData.m_nUserNo == m_nOwnerNo) {
			ImageView ivOwner = (ImageView) findViewById(R.id.iv_owner);
			ivOwner.setVisibility(VISIBLE);
		} else {
			ImageView ivOwner = (ImageView) findViewById(R.id.iv_owner);
			ivOwner.setVisibility(GONE);
		}
		if (m_UserListData.m_strUserType.equals("R")) {


			m_mapPersonalData = m_UserListData.m_PersonalData.mapPersonalData;
			tv_name.setText(m_mapPersonalData.get(PersonalData.NAME));

			if(m_UserListData.m_isActive)
			{
				tv_uninstall.setVisibility(GONE);
			}
			else
			{
				tv_uninstall.setVisibility(VISIBLE);
			}

			String strDepartments = "";
			if(m_mapPersonalData.get(PersonalData.PARENT_DEPARTMENT).length() > 0 && m_mapPersonalData.get(PersonalData.DEPARTMENT).length() > 0)
				strDepartments = m_mapPersonalData.get(PersonalData.PARENT_DEPARTMENT) + " > " + m_mapPersonalData.get(PersonalData.DEPARTMENT);
			else if(m_mapPersonalData.get(PersonalData.PARENT_DEPARTMENT).length() == 0)
				strDepartments = m_mapPersonalData.get(PersonalData.DEPARTMENT);
			else if(m_mapPersonalData.get(PersonalData.DEPARTMENT).length() == 0)
				strDepartments = m_mapPersonalData.get(PersonalData.PARENT_DEPARTMENT);

			String strCharge = "";
			if(m_mapPersonalData.get(PersonalData.CHARGE) == null || m_mapPersonalData.get(PersonalData.CHARGE).equals("") || m_mapPersonalData.get(PersonalData.CHARGE).equals("null"))
			{
				strCharge = "";
			}
			else
			{
				strCharge = " " + m_mapPersonalData.get(PersonalData.CHARGE);
			}

			strDepartments = strDepartments + strCharge;

			SpannableStringBuilder builder = new SpannableStringBuilder(strDepartments);
			builder.setSpan(new ForegroundColorSpan(Color.parseColor("#ff7900")), strDepartments.length()-strCharge.length(), strDepartments.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			tv_departments.setText(builder);
		}

		m_mapPersonalData = m_UserListData.m_PersonalData.mapPersonalData;
		tv_name.setText(m_mapPersonalData.get(PersonalData.NAME));
		if(m_UserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_mapPersonalData.get(PersonalData.POSITION) != null && ! m_mapPersonalData.get(PersonalData.POSITION).equals("")){
			layout_position.setVisibility(VISIBLE);
			tv_position.setText(m_mapPersonalData.get(PersonalData.POSITION));
		} else {
			layout_position.setVisibility(GONE);
		}

		if(m_UserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_mapPersonalData.get(PersonalData.CHARGE)!=null && !m_mapPersonalData.get(PersonalData.CHARGE).equals("")){
			layout_charge.setVisibility(VISIBLE);
			tv_charge.setText(m_mapPersonalData.get(PersonalData.POSITION));
		} else {
			layout_charge.setVisibility(GONE);
		}

		if (m_UserListData.m_isActive) {
			tv_uninstall.setVisibility(GONE);
		} else {
			tv_uninstall.setVisibility(VISIBLE);
		}


		if (m_UserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR)) {
			tv_departments.setText(m_mapPersonalData.get(PersonalData.DEPARTMENT)+" | "+m_mapPersonalData.get(PersonalData.COMPANY_NAME));
		} else {
			tv_departments.setText(m_mapPersonalData.get(PersonalData.AFFILIATION));
		}

		// 친구가 아니라면 친구추가 아이콘 표시
		ib_add_fellow = (ImageButton) findViewById(R.id.ib_add_fellow);
		ib_add_fellow.setOnClickListener(this);
		if (!m_UserListData.m_isFellow && m_UserListData.m_nUserNo != App.m_MyUserInfo.m_nUserNo) {
			ib_add_fellow.setVisibility(View.VISIBLE);
		} else {
			ib_add_fellow.setVisibility(View.GONE);
		}

		iv_notfellow_pic.setVisibility(View.GONE);
		if (m_nType == CHATROOM_ITEM_TYPE_EXIT) {
			ib_add_fellow.setVisibility(View.GONE);
			CheckBox cb_exituser = (CheckBox) findViewById(R.id.cb_exituser);

			cb_exituser.setVisibility(View.VISIBLE);
			if (((ChatRoomExitOtherAct) m_Context).getCheckBoxPosition(m_nPostion)) {
				if (!cb_exituser.isChecked())
					cb_exituser.setChecked(true);
			} else {
				if (cb_exituser.isChecked())
					cb_exituser.setChecked(false);
			}
			cb_exituser.setOnCheckedChangeListener(this);
			if(m_UserListData.m_nUserNo == App.m_MyUserInfo.m_nUserNo) {
				cb_exituser.setVisibility(View.GONE);
			} else {
				cb_exituser.setVisibility(View.VISIBLE);
			}

		} else if (m_nType == CHATROOM_ITEM_TYPE_OWNER) {
			ib_add_fellow.setVisibility(View.GONE);
			ImageButton ib_owner = (ImageButton) findViewById(R.id.ib_chat_owner);

			if(m_UserListData.m_nUserNo == App.m_MyUserInfo.m_nUserNo) {
				ib_owner.setVisibility(INVISIBLE);
			} else {
				ib_owner.setVisibility(View.VISIBLE);
			}
			ib_owner.setOnClickListener(this);
			if (m_UserListData.m_nUserNo == ((ChatRoomOwnerAct) m_Context).getOwner()) {
				ib_owner.setBackgroundResource(R.drawable.btn_radio_selected);
			} else {
				ib_owner.setBackgroundResource(R.drawable.btn_radio);
			}

		} else if (m_nType == CHATROOM_ITEM_TYPE_MEMBER) {
			ImageView ivOwner = (ImageView) findViewById(R.id.iv_owner);
			if (m_nOwnerNo == m_UserListData.m_nUserNo) {
				
				ivOwner.setVisibility(View.VISIBLE);
			} else {
				ivOwner.setVisibility(View.GONE);
			}
		} else if(m_nType == CHATROOM_ITEM_TYPE_CHECK){
			ib_add_fellow.setVisibility(View.GONE);
			TextView tvReadCheck = (TextView) findViewById(R.id.tv_readcheck);
			tvReadCheck.setVisibility(View.VISIBLE);
			if(m_isRead){
				tvReadCheck.setText(R.string.layout_chatroom_readcheck_yes);
				tvReadCheck.setTextColor(Color.rgb(99, 99, 99));
			} else {
				tvReadCheck.setText(R.string.layout_chatroom_readcheck_no);
				tvReadCheck.setTextColor(Color.rgb(183, 183, 183));
			}
		}

		RelativeLayout layout_listitem = (RelativeLayout) findViewById(R.id.layout_listitem);
		layout_listitem.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.ib_add_fellow) {
			ib_add_fellow.setClickable(false);
			requestAddBuddys();
		} else if (v.getId() == R.id.layout_listitem) {
			//doShowProfile();
			if (m_nType == CHATROOM_ITEM_TYPE_EXIT) {
				CheckBox cb_exituser = (CheckBox) findViewById(R.id.cb_exituser);
				if (cb_exituser.getVisibility() == View.VISIBLE && cb_exituser.isChecked())
					cb_exituser.setChecked(false);
				else if (cb_exituser.getVisibility() == View.VISIBLE && !cb_exituser.isChecked())
					cb_exituser.setChecked(true);
			}
		} else if(v.getId() == R.id.iv_profile_pic) {
			doShowProfile();
		} else if (v.getId() == R.id.ib_chat_owner) {
			((ChatRoomOwnerAct) m_Context).setOwner(m_UserListData.m_nUserNo);
			((ChatRoomOwnerAct) m_Context).setOwnerName(m_UserListData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
			((ChatRoomOwnerAct) m_Context).reDrawUI();
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	
				popup_ok_long.cancel();
				App.expirePartnerLogin(m_Context);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Context);
			}
			else
			{
				popup_ok_long.cancel();
			}
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		if (buttonView.getId() == R.id.cb_exituser) {
			if (isChecked) {
				//((ChatRoomExitOtherAct) m_Context).addExitUser(m_UserListData);
				((ChatRoomExitOtherAct) m_Context).setCheckBoxPosition(m_nPostion, true);
			} else {
				//((ChatRoomExitOtherAct) m_Context).removeExitUser(m_UserListData);
				((ChatRoomExitOtherAct) m_Context).setCheckBoxPosition(m_nPostion, false);
			}

		}
	}

	private void doShowProfile() {
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_UserListData.m_nUserNo);
		m_Context.startActivity(intent);
	}

	private void requestAddBuddys() {
		showProgress();
		int[] nSelects = new int[1];
		nSelects[0] = m_UserListData.m_nUserNo;
		PostAddBuddysReq req = new PostAddBuddysReq(nSelects);
		WebAPI webApi = new WebAPI(m_Context);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				// FellowListData fellowListData = new FellowListData(m_PartnerSearchListData.m_nUserNo, "P", m_PartnerSearchListData.m_strName, m_PartnerSearchListData.m_strCompany,
				// null, null, m_PartnerSearchListData.m_isImageAvailable, m_PartnerSearchListData.m_isAvailable);
				ib_add_fellow.setClickable(true);
				UserListData getItem = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_UserListData.m_nUserNo);

				if (getItem != null) {
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();

					TTalkDBManager.ContactsDBManager.updateContacts(m_Context, getItem);
					ib_add_fellow.setVisibility(View.INVISIBLE);

					HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
					if (getItem.m_strUserType.equals("R")) {
						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),personalData.get(PersonalData.AFFILIATION),
								personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
						App.buddyAdd(fellowListData);
					} else {
						FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
								getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
						App.buddyAdd(fellowListData);
					}
					closeProgress();
					if (m_nType == CHATROOM_ITEM_TYPE_MEMBER) {
						ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);
						iv_notfellow_pic.setVisibility(View.GONE);
						((ChatRoomMemberAct)m_Context).mService.addBuddy(Integer.toString(getItem.m_nUserNo));
					}
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_fellowadd_title), m_Context.getString(R.string.pop_fellowadd_success));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					// 사용자 추가..... 구현
					requestAddedByUserList();

				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				ib_add_fellow.setClickable(true);
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							m_Context.getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	private void requestAddedByUserList() {
		int[] nSelects = new int[1];
		nSelects[0] = m_UserListData.m_nUserNo;
		GetUserInfoReq req = new GetUserInfoReq(nSelects);
		WebAPI webApi = new WebAPI(m_Context);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				UserListData getItem = res.getUserListData().get(0);
				closeProgress();
				if (getItem != null) {
					getItem.m_isFellow = true;
					getItem.m_strFellowAddTime = Utils.getCurrentTime();
					if (ContactsDBManager.insertContacts(m_Context, getItem) > 0) {
						ib_add_fellow.setVisibility(View.INVISIBLE);

						HashMap<String, String> personalData = getItem.m_PersonalData.mapPersonalData;;
						if (getItem.m_strUserType.equals("R")) {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),personalData.get(PersonalData.AFFILIATION),
									personalData.get(PersonalData.CHARGE), getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						} else {
							FellowListData fellowListData = new FellowListData(getItem.m_nUserNo, getItem.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
									getItem.m_isImageAvailable, getItem.m_isActive, getItem.m_strFellowAddTime, getItem.m_strGreeting);
							App.buddyAdd(fellowListData);
						}
						if (m_nType == CHATROOM_ITEM_TYPE_MEMBER) {
							ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);
							iv_notfellow_pic.setVisibility(View.GONE);
							((ChatRoomMemberAct)m_Context).mService.addBuddy(Integer.toString(getItem.m_nUserNo));
						}
						m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_fellowadd_title), m_Context.getString(R.string.pop_fellowadd_success));
						m_Popup.setCancelable(false);
						m_Popup.show();
					}
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(m_Context.getString(R.string.pop_error_title), m_Context.getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else
				{
					m_Popup = new CommonPopup(m_Context, ChatRoomUserListItemLayout.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							m_Context.getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		});
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

}
