package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.db.RoomDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * Created by kang on 2017-09-13.
 */

public class ChatRoomAlarmSetAct extends CustomActivity implements CompoundButton.OnCheckedChangeListener, View.OnClickListener,View.OnTouchListener {

    CheckBox cb_chatroom;

    String m_strRoomID = "";
    boolean m_isAlarm = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_alarm_setting);
        ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_OK);
                finish();
            }
        });
        getIntents();
        setAlramUI();
    }

    public void getIntents() {
        m_strRoomID = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_ROOM_ID);
        m_isAlarm = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_ISALARM_ON, true);
    }


    public void setAlramUI() {
        LinearLayout layoutNewWriteAlarm = (LinearLayout) findViewById(R.id.layout_set_alarm_newwrite_alram);
        layoutNewWriteAlarm.setVisibility(View.GONE);
        LinearLayout layoutNewAddAlarm = (LinearLayout) findViewById(R.id.layout_set_alarm_newadd_alram);
        layoutNewAddAlarm.setVisibility(View.GONE);
        LinearLayout layoutChatroomAlarm = (LinearLayout) findViewById(R.id.layout_set_alarm_chatroom_alram);
        layoutChatroomAlarm.setVisibility(View.VISIBLE);
        layoutChatroomAlarm.setOnClickListener(this);
        cb_chatroom = (CheckBox) findViewById(R.id.cb_chatroom_alram);
        if(m_isAlarm){
            cb_chatroom.setChecked(true);
        } else {
            cb_chatroom.setChecked(false);
        }
        cb_chatroom.setOnTouchListener(this);
        cb_chatroom.setOnCheckedChangeListener(this);

    }

    @Override
    public void onClick(View v) {
        super.onClick(v);
        if (v.getId() == R.id.layout_set_alarm_chatroom_alram) {
            if (cb_chatroom.isChecked()) {
                cb_chatroom.setChecked(false);
            } else {
                cb_chatroom.setChecked(true);
            }
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (v.getId() == R.id.cb_chatroom_alram) {
                if (cb_chatroom.isChecked()) {
                    cb_chatroom.setChecked(false);
                } else {
                    cb_chatroom.setChecked(true);
                }
            }
        }
        return true;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

        if (buttonView.getId() == R.id.cb_chatroom_alram) {
            if(isChecked){
                m_isAlarm = true;
            } else {
                m_isAlarm = false;
            }
            updateAlarm(m_isAlarm);
        }
    }
    public void updateAlarm(boolean a_isAlarm){
        TTalkDBManager.RoomDBManager.updateRoom(this,m_strRoomID, a_isAlarm);
        if(a_isAlarm){
            mService.requestOnOff("on", m_strRoomID);
        } else {
            mService.requestOnOff("off", m_strRoomID);
        }
    }
}