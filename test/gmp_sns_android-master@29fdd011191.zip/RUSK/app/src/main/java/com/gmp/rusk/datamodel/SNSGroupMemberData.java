package com.gmp.rusk.datamodel;

public class SNSGroupMemberData {
	
/*
	
	public int m_nUserNo = -1;
	public String m_strUserName = "";
	public String m_strCompanyOrDepartment = "";
	public String m_strUserImageUrl = "";
	public String m_strMembered = MEMBERED_TYPE_NONE;
	public boolean m_isOwnered = false;
	public String m_strType = "";*/

	public int m_nUserNo = -1;
	public boolean m_isOwner = false;
}
