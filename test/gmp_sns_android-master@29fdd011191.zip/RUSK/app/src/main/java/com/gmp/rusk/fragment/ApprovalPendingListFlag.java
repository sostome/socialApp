package com.gmp.rusk.fragment;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ApprovalTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.datamodel.ApprovalPendingListData;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.GMPData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.datamodel.UserUpdateListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.gmp.AuthUtil;
import com.gmp.rusk.gmp.SimpleCrypto;
import com.gmp.rusk.layout.ApprovalPendingListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteCompanionPartnerApprovalReq;
import com.gmp.rusk.request.GetEntryReq;
import com.gmp.rusk.request.GetPartnerApprovalListReq;
import com.gmp.rusk.request.GetUserListReq;
import com.gmp.rusk.request.PutApprovedPartnerReq;
import com.gmp.rusk.response.GetEntryRes;
import com.gmp.rusk.response.GetPartnerApprovalListRes;
import com.gmp.rusk.response.GetUserListRes;
import com.gmp.rusk.response.Res;

import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * ApprovalPendingListFlag
 * @author subi78
 * ApprovalTabAct - 승인요청 리스트 Fragment
 */
public class ApprovalPendingListFlag extends Fragment implements OnClickListener{
	public MyApp App = MyApp.getInstance();
	public static final String ID_MDN        = "MDN";
	public static final String ID_APP_ID     = "APPID";
	public static final String ID_AUTH_KEY   = "authKey";
	public static final String ID_COMPANY_CD = "companyCd";
	public static final String ID_ENC_PWD    = "encPwd";
	
	private String m_strTimeStamp = "";
	private ArrayList<UserListData> m_arrAddedFellowListData = null;
	
	
	private View m_vApprovalPendingList = null;	
	private TextView m_tvDesc;
	private RelativeLayout m_layoutDesc;
	
	private FragmentActivity m_Activity = null;
	
	private ListView m_lvApprovalPendingList = null;
	private ApprovalPendingListApdapter m_ApprovalPendingAdapter = null;
	
	ArrayList<ApprovalPendingListData> m_arrPendingListDatas = null;
	ArrayList<ApprovalPendingListData> m_arrPendingSearchListDatas = null;
	
	Button ib_complete_all;
	
	RelativeLayout layout_nolisttext,layout_no_searchList;
	
	private ProgressDlg m_Progress = null;
	
	private CommonPopup m_Popup = null;
	
	int[] nUserNos;
	
	SharedPref pref;
	
	public boolean m_isRunning = false;
	
	EditText et_search_keyword;
	ImageButton ib_cancel;
	private InputMethodManager imm; 
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        m_Activity = getActivity();
        pref = SharedPref.getInstance(m_Activity);

        imm = (InputMethodManager)m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE); 
    }
    
    /**
     * The Fragment's UI is just a simple text view showing its
     * instance number.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    	
    	m_vApprovalPendingList = inflater.inflate(R.layout.fragact_approvalpending_list, container, false);
    	
    	((ApprovalTabAct)m_Activity).setTitle(getString(R.string.approvaltab_title));
    	
    	if (App.m_EntryData == null) {
    		initProcess();
		} 
    	else
		{
        	initSetUI();
        	requestGetPartnerApprovalList();
		}	

        return m_vApprovalPendingList;
    }
    
    @Override
    public void onResume() {
    	// TODO Auto-generated method stub
    	super.onResume();
    	if(m_ApprovalPendingAdapter !=null)
    		m_ApprovalPendingAdapter.notifyDataSetInvalidated();
    	m_isRunning = true;
    }
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}
	
	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	
    public void initProcess()
    {
    	if(AppSetting.FEATURE_VARIANT.equals("R"))
			doGMPLogin();
		else
			new ReqVersionInfoTask().execute(null,null,null);
//			new ReqGMPInfoTask().execute(null,null,null);
    }
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_complete_all)
		{
			if(m_arrPendingSearchListDatas != null)
			{
				nUserNos = new int[m_arrPendingSearchListDatas.size()];
				for(int i=0;i<m_arrPendingSearchListDatas.size();i++)
				{
					nUserNos[i] = m_arrPendingSearchListDatas.get(i).m_nUserNo;
				}
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_COMPLETE_ALL);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_approvalpending_prev_complete).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
		else if(v.getId() == R.id.ib_pop_ok)
		{
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_COMPLETE)
			{
				popup_ok.cancel();
				requestPostApprovedPartner(nUserNos);
			}
			else if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_COMPLETE_ALL)
			{
				popup_ok.cancel();
				requestPostApprovedPartner(nUserNos);
			}
			else if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_DENIAL)
			{
				popup_ok.cancel();
				requestDeleteCompanionPartnerApproval(nUserNos[0]);
			}	
			else if(popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION)
			{
				if(AppSetting.FEATURE_VARIANT.equals("R"))
				{
					//버전 업데이트 처리
					try{

	                    Intent intent = new Intent("com.sk.pe.group.store.detail"); //GMP 스마트폰 스토어의 상세화면
			             // Intent intent = new Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿 스토어의 상세화면

	                    intent.putExtra("APP_ID", App.m_AppID); //대상 어플 아이디
	                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); //Activity 남기지 않음
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
	                catch(ActivityNotFoundException e){
	                    Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
				}
				else
				{	
					Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
	                startActivity(intent);
	                App.allActivityDestroy();
				}
			}
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			if(popup_cancel.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION)
			{
				if(AppSetting.FEATURE_VARIANT.equals("R"))
					new ReqGMPInfoTask().execute(null,null,null);
				else
				{
					m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

					CommonLog.e(getClass(), "UserList DB update");
					requestUpdateUserList(m_strTimeStamp);
				}
			}
			popup_cancel.cancel();
		}
		else if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	
				popup_ok_long.cancel();
				App.expirePartnerLogin(m_Activity);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_COMPLETE_ALL_SUCCESS)
			{
				for(int i=0; i<m_arrPendingSearchListDatas.size();i++)
				{
					m_arrPendingListDatas.remove(m_arrPendingSearchListDatas.get(i));
					m_arrPendingSearchListDatas.remove(i);
					m_ApprovalPendingAdapter.notifyDataSetInvalidated();
				}
				ib_complete_all.setVisibility(View.GONE);	
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Activity);
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_NEW_VERSION)
			{
				popup_ok_long.cancel();
				CommonLog.e("","update..... gogo");
				if(AppSetting.FEATURE_VARIANT.equals("R"))
				{
					//버전 업데이트 처리
					try{

	                    Intent intent = new Intent("com.sk.pe.group.store.detail"); //GMP 스마트폰 스토어의 상세화면
			             // Intent intent = new Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿 스토어의 상세화면

	                    intent.putExtra("APP_ID", App.m_AppID); //대상 어플 아이디
	                    intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); //Activity 남기지 않음
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
	                catch(ActivityNotFoundException e){
	                    Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
	                    startActivity(intent);
	                    App.allActivityDestroy();
	                }
				}
				else
				{	
					Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://cork.toktok.sk.com:7443/multi")).addCategory(Intent.CATEGORY_BROWSABLE);
	                startActivity(intent);
	                App.allActivityDestroy();
				}
			}
			else if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_FINISH)
			{
				popup_ok_long.cancel();
				//finish();
			} 
			else if(popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_NO_SEARCH)
			{
				popup_ok_long.cancel();
				et_search_keyword.setText("");
				m_arrPendingSearchListDatas = m_arrPendingListDatas;
				m_ApprovalPendingAdapter.notifyDataSetChanged();
				if(!m_arrPendingSearchListDatas.isEmpty()){
		    		layout_nolisttext.setVisibility(View.GONE);
					layout_no_searchList.setVisibility(View.GONE);
					m_layoutDesc.setVisibility(View.VISIBLE);
					m_tvDesc.setText(getString(R.string.approvalaccept_description));
		    	}
				else {
					layout_nolisttext.setVisibility(View.GONE);
					layout_no_searchList.setVisibility(View.VISIBLE);
					m_layoutDesc.setVisibility(View.GONE);
				}

			}
			else
			{
				for(int i=0; i<m_arrPendingListDatas.size();i++)
				{
					for(int j=0;j<nUserNos.length;j++)
					{
						if(m_arrPendingListDatas.get(i).m_nUserNo == nUserNos[j])
						{
							m_arrPendingListDatas.remove(i);
							m_ApprovalPendingAdapter.notifyDataSetInvalidated();
						}
					}
				}	
				
				for(int i=0; i<m_arrPendingSearchListDatas.size();i++)
				{
					for(int j=0;j<nUserNos.length;j++)
					{
						if(m_arrPendingSearchListDatas.get(i).m_nUserNo == nUserNos[j])
						{
							m_arrPendingSearchListDatas.remove(i);
							m_ApprovalPendingAdapter.notifyDataSetInvalidated();
						}
					}
				}	
				
				if(m_arrPendingSearchListDatas.size() == 0)
					ib_complete_all.setVisibility(View.GONE);
			}
			
			popup_ok_long.cancel();
		}
	}
    
    private void initSetUI()
    {
    	m_lvApprovalPendingList = (ListView)m_vApprovalPendingList.findViewById(R.id.lv_approvalpending_list);
    	
    	layout_nolisttext = (RelativeLayout)m_vApprovalPendingList.findViewById(R.id.layout_hinttext);
    	//layout_nolisttext.setVisibility(View.VISIBLE);
    	layout_no_searchList = (RelativeLayout)m_vApprovalPendingList.findViewById(R.id.layout_no_searchlist);

    	ib_complete_all = (Button)m_vApprovalPendingList.findViewById(R.id.ib_complete_all);
    	ib_complete_all.setOnClickListener(this);
    	ib_complete_all.setVisibility(View.GONE);

    	m_tvDesc = (TextView)m_vApprovalPendingList.findViewById(R.id.tv_approvalpending_text);
		m_layoutDesc = (RelativeLayout)m_vApprovalPendingList.findViewById(R.id.layout_approvalpending_text);
		m_layoutDesc.setVisibility(View.GONE);
    	//m_tvDesc.setText(getString(R.string.approvalpending_description));
    	et_search_keyword = (EditText)m_vApprovalPendingList.findViewById(R.id.et_search_keyword);
    	if(imm != null && et_search_keyword != null)
    		imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
//    	et_search_keyword.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
    	ib_cancel = (ImageButton)m_vApprovalPendingList.findViewById(R.id.ib_cancel);

    	ib_cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				et_search_keyword.setText("");
				m_arrPendingSearchListDatas = m_arrPendingListDatas;
				m_ApprovalPendingAdapter.notifyDataSetChanged();
				if(!m_arrPendingSearchListDatas.isEmpty()){
		    		layout_nolisttext.setVisibility(View.GONE);
					layout_no_searchList.setVisibility(View.GONE);
					m_layoutDesc.setVisibility(View.VISIBLE);
					m_tvDesc.setText(getString(R.string.approvalpending_description));
		    	} else {
					layout_nolisttext.setVisibility(View.VISIBLE);
					layout_no_searchList.setVisibility(View.GONE);
					m_layoutDesc.setVisibility(View.GONE);
				}

			}
		});
    	    	
    	et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				CommonLog.e("EditAction", "actionId1 : "+actionId);
							
				switch(actionId) {
				case EditorInfo.IME_ACTION_SEARCH:
					if(v.getText().toString().trim().length() > 1)
					{
						if(!Utils.UseChar(v.getText().toString()))
						{
							m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
									CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(
									getString(R.string.pop_error_title).toString(),
									getString(R.string.regular_expression_search).toString());
							m_Popup.setCancelable(false);
							isCheckShowPopup();
							return false;
						}
						initSearch(v.getText().toString());
						//requestAddedByPartner(v.getText().toString());
					}
					else
					{
						m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(
								getString(R.string.pop_error_title).toString(),
								getString(R.string.popup_search_length).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
					
					break;
				}
				return false;
			}
		});
    	
    	et_search_keyword.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if(s.toString().length()>0)
				{
					ib_cancel.setVisibility(View.VISIBLE);
				}
				else
				{	
					ib_cancel.setVisibility(View.INVISIBLE);

					m_arrPendingSearchListDatas = m_arrPendingListDatas;
					m_ApprovalPendingAdapter.notifyDataSetChanged();
					if(!m_arrPendingSearchListDatas.isEmpty()){
			    		layout_nolisttext.setVisibility(View.GONE);
						layout_no_searchList.setVisibility(View.GONE);
						m_layoutDesc.setVisibility(View.VISIBLE);
						m_tvDesc.setText(getString(R.string.approvalpending_description));
			    	} else {
						layout_nolisttext.setVisibility(View.VISIBLE);
						layout_no_searchList.setVisibility(View.GONE);
						m_layoutDesc.setVisibility(View.GONE);
					}
//					layout_nolisttext.setVisibility(View.VISIBLE);
					//layout_addedbylist_list.setVisibility(View.GONE);
					//m_arrPartnerSearchListDatas = null;
//					initSearchPartner();
					
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});
    }
    
    private void initSearch(String a_strKeyword){
    	m_arrPendingSearchListDatas = new ArrayList<ApprovalPendingListData>();
    	if(m_arrPendingListDatas != null){
    		for(int i = 0; i < m_arrPendingListDatas.size(); i++){
    			if(m_arrPendingListDatas.get(i).m_strName.contains(a_strKeyword) || m_arrPendingListDatas.get(i).m_strCompany.contains(a_strKeyword)){
    				m_arrPendingSearchListDatas.add(m_arrPendingListDatas.get(i));
    			}
    		}
    		if(!m_arrPendingSearchListDatas.isEmpty()){
    			layout_nolisttext.setVisibility(View.GONE);
				layout_no_searchList.setVisibility(View.GONE);
    			m_ApprovalPendingAdapter.notifyDataSetChanged();
				m_layoutDesc.setVisibility(View.VISIBLE);
    			m_tvDesc.setText(getString(R.string.layout_sectionstring_search_result) + " (" + m_arrPendingSearchListDatas.size() + ")");
    		} 
    		else {
				m_lvApprovalPendingList.setVisibility(View.INVISIBLE);
				layout_nolisttext.setVisibility(View.GONE);
				layout_no_searchList.setVisibility(View.VISIBLE);
				m_layoutDesc.setVisibility(View.VISIBLE);
				m_tvDesc.setText(getString(R.string.layout_sectionstring_search_result) + " (0)");
    		/*	m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_NO_SEARCH);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.layout_sectionstring_search_noresult));
				m_Popup.setCancelable(false);
				isCheckShowPopup();*/

    		}
    		
    	}
    	
    }
    
    private void setApprovalPendingApdapter()
    {	
    	m_ApprovalPendingAdapter = new ApprovalPendingListApdapter();
        if(m_arrPendingSearchListDatas != null && !m_arrPendingSearchListDatas.isEmpty())
        {
        	CommonLog.e("", "m_arrPendingListDatas != null");
        	m_lvApprovalPendingList.setVisibility(View.VISIBLE);
        	layout_nolisttext.setVisibility(View.GONE);
			layout_no_searchList.setVisibility(View.GONE);
			m_layoutDesc.setVisibility(View.VISIBLE);
			m_tvDesc.setText(getString(R.string.approvalpending_description));
        	
    	
        	m_lvApprovalPendingList.setAdapter(m_ApprovalPendingAdapter);
    	
        	m_lvApprovalPendingList.setOnScrollListener(new OnScrollListener() {
			
				@Override
				public void onScrollStateChanged(AbsListView view, int scrollState) {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onScroll(AbsListView view, int firstVisibleItem,
						int visibleItemCount, int totalItemCount) {
					// TODO Auto-generated method stub
	
				}
			});
        }
        else
        {
        	CommonLog.e("", "m_arrPendingListDatas == null");
        	m_lvApprovalPendingList.setVisibility(View.INVISIBLE);
        	layout_nolisttext.setVisibility(View.VISIBLE);
			layout_no_searchList.setVisibility(View.GONE);
			m_layoutDesc.setVisibility(View.GONE);
        	initSetUI();
        }

    }
    
	// AddedByPartnerList Adapter
	private class ApprovalPendingListApdapter extends BaseAdapter
	{	
		
		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub
			
			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if(m_arrPendingSearchListDatas != null)
				return m_arrPendingSearchListDatas.size();
			
			return 0;
		}

		@Override
		public Object getItem(int position) {
//			if(position == 0) return header;
			
			if(m_arrPendingSearchListDatas != null)
				return m_arrPendingSearchListDatas.get(position);
			
			return null;
		}
		
		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) 
		{
			final int nPosition = position;
			ApprovalPendingListData data = (ApprovalPendingListData)m_arrPendingSearchListDatas.get(nPosition);
			
			CommonLog.e(getClass(), "getView");
			
			
			// convertView null 시 새로 생성하자
			if(convertView == null)
				convertView = new ApprovalPendingListItemLayout(m_Activity);
			
			((ApprovalPendingListItemLayout)convertView).setApprovalPendingListData(data);	
						
			((ApprovalPendingListItemLayout)convertView).setApprovalPendingListener(m_ApprovalPendingListner);
			return convertView;
		}	
	}    
    
    private void requestGetPartnerApprovalList()
    {
    	showProgress(getString(R.string.progress_search));
    	GetPartnerApprovalListReq req = new GetPartnerApprovalListReq();
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e("", "requestGetPartnerApprovalList... post..");
				closeProgress();
				GetPartnerApprovalListRes res = new GetPartnerApprovalListRes(a_strData);
				m_arrPendingListDatas = new ArrayList<ApprovalPendingListData>();
				if(res.getApprovalPendingList() != null)
				{
					m_arrPendingListDatas = res.getApprovalPendingList();
					m_arrPendingSearchListDatas = m_arrPendingListDatas;
					if(m_arrPendingListDatas.size() > 0)
						ib_complete_all.setVisibility(View.VISIBLE);
					pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, res.getApprovalPendingList().size());
					IconBadge.updateIconBadge(m_Activity);
				} else {
					pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, 0);
					IconBadge.updateIconBadge(m_Activity);
				}
				setApprovalPendingApdapter();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
    }
    
    private void requestPostApprovedPartner(final int[] a_nUserNo)
    {
    	showProgress(getString(R.string.progress_search));
    	PutApprovedPartnerReq req = new PutApprovedPartnerReq(a_nUserNo);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nUserNo.length > 1)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_COMPLETE_ALL_SUCCESS);
					pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, 0);
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_COMPLETE_SUCCESS);
					pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT)-1);
				}
				IconBadge.updateIconBadge(m_Activity);
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_approvalpending_complete).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
    }
    
    private void requestDeleteCompanionPartnerApproval(int a_nUserNo)
    {
    	showProgress(getString(R.string.progress_search));
    	DeleteCompanionPartnerApprovalReq req = new DeleteCompanionPartnerApprovalReq(a_nUserNo);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT)-1);
				IconBadge.updateIconBadge(m_Activity);
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_DENIAL_SUCCESS);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_approvalpending_denial).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
    }
    
	ApprovalPendingListItemLayout.OnApprovalPendingListener m_ApprovalPendingListner = new ApprovalPendingListItemLayout.OnApprovalPendingListener() {
//		Intent intent = new Intent(PartnerApprovalReqAct.this, PartnerSignUpAct.class);
//		intent.putExtra(IntentKeyString.INTENT_KEY_USERID_TYPE, m_isPartner);
//		if(!m_isPartner)
//		{
//			intent.putExtra(IntentKeyString.INTENT_KEY_USERID_ID, m_strUserId);
//		}
//		
//		intent.putExtra(IntentKeyString.INTENT_KEY_USERID_APPROVAL_USERNO, a_nApprovalUserNo);
//		intent.putExtra(IntentKeyString.INTENT_KEY_USERID_APPROVAL_USERNAME, a_strApprovalUserName);
//		startActivityForResult(intent, StaticString.REQUESTCODE_PARTNER_SIGNUP);
		
		@Override
		public void onApprovalComplete(int a_nApprovalPendingUserNo) {
			// TODO Auto-generated method stub
			nUserNos = new int[1];
			nUserNos[0] = a_nApprovalPendingUserNo;
			
			m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
					CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_COMPLETE);
			m_Popup.setBodyAndTitleText(
					getString(R.string.pop_error_title).toString(),
					getString(R.string.pop_approvalpending_prev_complete).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}

		@Override
		public void onApprovalDenial(int a_nApprovalPendingUserNo) {
			// TODO Auto-generated method stub
			nUserNos = new int[1];
			nUserNos[0] = a_nApprovalPendingUserNo;
			
			m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
					CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_DENIAL);
			m_Popup.setBodyAndTitleText(
					getString(R.string.pop_error_title).toString(),
					getString(R.string.pop_approvalpending_prev_denial).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	};
    
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	/*
	 * 사용자 목록 조회 및 Update
	 */
	
	private void doUserListSync()
	{
		SharedPref pref = SharedPref.getInstance(m_Activity);
		if(!AppSetting.FEATURE_VARIANT.equals("R"))
		{	
			int nUpdateType = Utils.CheckVersion(m_Activity,App.m_EntryData.m_strLatestVersion);
			if(nUpdateType == 1)
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			else if(nUpdateType == 2)
			{
				if(!pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(App.m_EntryData.m_strLatestVersion))
				{
					pref.setStringPref(SharedPref.PREF_GMP_VERSION, App.m_EntryData.m_strLatestVersion);
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.update_version).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}
		}
		m_strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);
		
		CommonLog.e(getClass(), "UserList DB update");
		requestUpdateUserList(m_strTimeStamp);
	}
	/*
	 * GMPLogin
	 */
	private void doGMPLogin()
	{
		
		//GMP 인증
		if(!AuthUtil.isLogin(m_Activity, App.m_Mdn, App.m_AppID)){
			AuthUtil.runGMPLogin(m_Activity);			
		}else{
			requestEntry();
		}
	}
	
	private class ReqGMPInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			try {
				Map<String,String> map = new HashMap<String,String>();
				
				CommonLog.e(getClass(), "getGMPAuthPwd start");	
					map = AuthUtil.getAuthInfo(m_Activity,App.m_Mdn,App.m_AppID);
					
					CommonLog.e(getClass(), "getGMPAuthPwd end");
//				String secretkeydecrypt = null;
				strResultCode = map.get("result_code");
				if(strResultCode.equals("1000")){ // 정상 처리일 경우정상 처리 코드 넣어주시기 바랍니다.
					String strRegularID = "";
					String secretkey = AuthUtil.getSecretKey(m_Activity); //비밀키 얻어오기
					try{
						strRegularID = SimpleCrypto.decrypt(secretkey, map.get("result_user_num")); // 복호화
					}catch (Exception e){
						strRegularID = "-2"; //복호화 실패시 아이디 값에 넣어줌
					}
					
					App.m_GMPData = new GMPData(map.get(ID_COMPANY_CD), strRegularID, map.get(ID_AUTH_KEY), map.get(ID_ENC_PWD));
					
				}               
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("1000")) 
				requestEntry();
			else if(result.equals("7009"))
			{
				try {
					AuthUtil.logout(m_Activity);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					doGMPLogin();
				}
			}
			else if(result.equals("3205"))
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			else
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}
	
	private class ReqVersionInfoTask extends AsyncTask<String, Void, String> {
		String strResultCode = "";
		String strAppVersion = "";
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			try {
				Map<String,String> map = new HashMap<String,String>();
				
				CommonLog.e(getClass(), "getVersionInfo start");	
					map = AuthUtil.getVersionInfo(m_Activity,App.m_Mdn,App.m_AppID);
					
					CommonLog.e(getClass(), "getVersionInfo end");
//				String secretkeydecrypt = null;
				strResultCode = map.get("result");
				if(strResultCode.equals("1000")){ // 정상 처리일 경우정상 처리 코드 넣어주시기 바랍니다.
					CommonLog.e(getClass(), "result : 1000");	
					strAppVersion = map.get("appVer");
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} // auth, company_cd, enc_pwd 얻어오며 파싱 시작
			return strResultCode;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result.equals("1000")) 
			{
				if(strAppVersion.equals(""))
				{
					new ReqGMPInfoTask().execute(null,null,null);
				}
				else
				{
					SharedPref pref = SharedPref.getInstance(m_Activity);
					int nUpdateType = Utils.CheckVersion(m_Activity, strAppVersion);
					if(nUpdateType == 2 && !pref.getStringPref(SharedPref.PREF_GMP_VERSION, "").equals(strAppVersion))
					{
						pref.setStringPref(SharedPref.PREF_GMP_VERSION, strAppVersion);
						m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
								CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
						m_Popup.setBodyAndTitleText(
								getString(R.string.pop_error_title).toString(),
								getString(R.string.update_version).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
					else
					{
						new ReqGMPInfoTask().execute(null,null,null);
					}
				}
			}
			else if(result.equals("7009"))
			{
				try {
					AuthUtil.logout(m_Activity);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally
				{
					doGMPLogin();
				}
			}
			else if(result.equals("3205"))
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_NEW_VERSION);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.force_update_version).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			else
			{
				m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.gmp_auth_bad).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}
	
	public void requestEntry()
	{
//		showProgress(getString(R.string.progress_entry).toString());
		GetEntryReq req = new GetEntryReq();
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetEntryRes res = new GetEntryRes(a_strData, Res.RES_TYPE_USER_ENTRY);
				//App.m_EntryData = new EntryData(res.m_strUserNo, res.m_strIsTNaUser, res.m_strDepartmentCode, res.m_strImageUrlTemplate, res.m_strPreviewImageUrlTemplate,res.m_strEmoticonTemplate, res.m_strLatestVersion, res.m_strLol, res.m_strMobile);
				App.m_MyUserInfo = res.getEntryUserData(m_Activity);
//				closeProgress();
				doUserListSync();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
//				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_APP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}				
			}
		});
	}
	
	public void requestUpdateUserList(String a_strTimeStamp)
	{
//		showProgress(getString(R.string.progress_getfellowlist));
		GetUserListReq req = new GetUserListReq(a_strTimeStamp);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);
				
				if(res.getUserListData() != null)
				{
					for(UserListData data : res.getUserListData())
					{
						UserListData getitem = ContactsDBManager.getContacts(m_Activity, data.m_nUserNo);
						if(getitem == null)
						{
							UserListData item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive, data.m_strGreeting, "A", false, "");
							ContactsDBManager.insertContacts(m_Activity, item);
						}
						else
						{							
							UserListData item = null;
							if(data.m_strUserStatus.equals("A"))
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive, data.m_strGreeting, data.m_strUserStatus,
										getitem.m_isFellow, getitem.m_strFellowAddTime);
							else
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive, data.m_strGreeting, data.m_strUserStatus,
										getitem.m_isFellow, "");
							
							ContactsDBManager.updateContacts(m_Activity, item);
						}
					}
				}
				
				pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);
				
				
				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
				finally
				{
			    	initSetUI();
			    	requestGetPartnerApprovalList();
				}
				
				
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
//				closeProgress();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED)
				{
					m_Popup = new CommonPopup(m_Activity, ApprovalPendingListFlag.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_FINISH);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.network_bad).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
			    	initSetUI();
			    	requestGetPartnerApprovalList();
				}
			}
		});
	}
    private ArrayList<FellowListData> setFellowList() throws Exception
    {    
    	m_arrAddedFellowListData = TTalkDBManager.ContactsDBManager.getContactsByFellows(m_Activity); 
    	App.m_arrFellowListData = new ArrayList<FellowListData>();
    	//CommonLog.e("", "setFellowList() lol : " + App.m_EntryData.m_strLol);
		for (UserListData data : m_arrAddedFellowListData) {
			HashMap<String, String> personalData = data.m_PersonalData.mapPersonalData;
			if (data.m_strUserType.equals("R")) {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_CODE),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
						personalData.get(PersonalData.CHARGE), data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			} else {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME), "", "","","","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
						data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			}
		}
    	
    	return App.m_arrFellowListData;
    }

    private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}
}