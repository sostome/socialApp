package com.gmp.rusk.customview;

import com.gmp.rusk.utils.Utils;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class SNSGroupDetailSwifeRefreshLayout extends android.support.v4.widget.SwipeRefreshLayout{
	
	public SNSGroupDetailSwifeRefreshLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public SNSGroupDetailSwifeRefreshLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
	
	public void initFlag()
	{
		m_fDownY = 0.0F;
		m_fDownX = 0.0F;
		m_isRefresh = false;
	}

	private float m_fDownY = 0.0F;
	private float m_fDownX = 0.0F;
	private boolean m_isRefresh = false;
	@Override
	public boolean onInterceptTouchEvent(MotionEvent arg0) {
		// TODO Auto-generated method stub
		float fYPixel = Utils.convertDpToPixel(getContext(), 30);
		float fXPixel = Utils.convertDpToPixel(getContext(), 30);
		switch (arg0.getActionMasked()) {
			case MotionEvent.ACTION_DOWN: 
			{
				m_fDownY = arg0.getY();
				m_fDownX = arg0.getX();
				return false;
			}
			case MotionEvent.ACTION_MOVE: 
			{
				float fY = arg0.getY();
				float fX = arg0.getX();
				if(!m_isRefresh && (fY - m_fDownY > fYPixel))
				{
					m_isRefresh = true;
					MotionEvent me = arg0;
					me.setAction(MotionEvent.ACTION_DOWN);
					return super.onInterceptTouchEvent(me);
				}
				else if(!m_isRefresh && ((fX - m_fDownX > fXPixel) || (m_fDownX - fX > fXPixel))){
					m_isRefresh = true;
					return false;
				}
				else 
				{
					if(m_isRefresh)
						return super.onInterceptTouchEvent(arg0);
					else
						return false;
				}
			}
			case MotionEvent.ACTION_UP:
				initFlag();
				break;
			case MotionEvent.ACTION_CANCEL:
				initFlag();
				break;
		}
		
		return super.onInterceptTouchEvent(arg0);
	}
}
