package com.gmp.rusk.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import com.gmp.rusk.MyApp;

/**
 * Created by K on 2016-06-28.
 */
public class CustomLinearLayout extends LinearLayout {
    public MyApp App = MyApp.getInstance();
    public CustomLinearLayout(Context context) {
        super(context);

    }

    public CustomLinearLayout(Context context, AttributeSet attrs) {
        super(context);
    }
}
