package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;

/**
 * Created by 강철 on 2016-01-18.
 */
public class SetLicenseInfo extends CustomActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_set_licenseinfo);
        ImageView ivClose = (ImageView)findViewById(R.id.btn_cancel);
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
