package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelUnreadsData;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.utils.CommonLog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetGroupUnreadsRes extends ChannelRes{

	private final String JSON_UNREADS				= "unreads";
	private final String JSON_CHANNELNO				= "channelNo";
	private final String JSON_THREADNO				= "threadNo";
	private final String JSON_COMMENTNO			= "commentNo";
	private final String JSON_INVITEDCHANNELCOUNT = "invitedChannelCount";

	public ArrayList<ChannelUnreadsData> m_arrChannelUnreadsData = new ArrayList<ChannelUnreadsData>();
	public int m_nInvitedChannelCount = 0;

	public GetGroupUnreadsRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);

			JSONArray jsonUnreads = jsonRoot.getJSONArray(JSON_UNREADS);
			int nUnreadsSize = jsonUnreads.length();
			for(int i = 0; i < nUnreadsSize; i++)
			{
				JSONObject jsonUnread = jsonUnreads.getJSONObject(i);
				ChannelUnreadsData unreadData = new ChannelUnreadsData();
				unreadData.m_nChannelNo = jsonUnread.getInt(JSON_CHANNELNO);
				JSONArray jsonUnreadsIn = jsonUnread.getJSONArray(JSON_UNREADS);
				for(int j= 0; j < jsonUnreadsIn.length(); j++){
					JSONObject jsonThreadAndCommentNo = jsonUnreadsIn.getJSONObject(j);
					String strNo = "";
					strNo += jsonThreadAndCommentNo.getString(JSON_THREADNO);
					/*if(!jsonThreadAndCommentNo.isNull(JSON_COMMENTNO))
						strNo += "|" + jsonThreadAndCommentNo.getString(JSON_COMMENTNO);*/
					unreadData.m_arrThreadAndCommentNo.add(strNo);
				}
				m_arrChannelUnreadsData.add(unreadData);

			}

			m_nInvitedChannelCount = jsonRoot.getInt(JSON_INVITEDCHANNELCOUNT);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<ChannelUnreadsData> getChannelUnreadsData() {
		return  m_arrChannelUnreadsData;
	}

	public int getInvitedChannelCount(){
		return  m_nInvitedChannelCount;
	}
}