package com.gmp.rusk.act;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.SharedPref;

import android.app.Activity;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class TutorialAct extends Activity implements OnClickListener {

	private ViewPager m_Pager;

	private ImageView m_ivPage1 = null;
	private ImageView m_ivPage2 = null;
	private ImageView m_ivPage3 = null;
	private ImageView m_ivPage4 = null;
	private ImageView m_ivPage5 = null;
	private ImageView m_ivPage6 = null;
	private ImageView m_ivPage7 = null;
	private ImageView m_ivPage8 = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_tutorial);

		m_ivPage1 = (ImageView) findViewById(R.id.iv_tutorial_page1);
		m_ivPage2 = (ImageView) findViewById(R.id.iv_tutorial_page2);
		m_ivPage3 = (ImageView) findViewById(R.id.iv_tutorial_page3);
		m_ivPage4 = (ImageView) findViewById(R.id.iv_tutorial_page4);
		m_ivPage5 = (ImageView) findViewById(R.id.iv_tutorial_page5);
		m_ivPage6 = (ImageView) findViewById(R.id.iv_tutorial_page6);
		m_ivPage7 = (ImageView) findViewById(R.id.iv_tutorial_page7);
		m_ivPage8 = (ImageView) findViewById(R.id.iv_tutorial_page8);

		TextView tvNever = (TextView) findViewById(R.id.tv_tutorial_never);
		TextView tvClose = (TextView) findViewById(R.id.tv_tutorial_close);

		m_ivPage1.setOnClickListener(this);
		m_ivPage2.setOnClickListener(this);
		m_ivPage3.setOnClickListener(this);
		m_ivPage4.setOnClickListener(this);
		m_ivPage5.setOnClickListener(this);
		m_ivPage6.setOnClickListener(this);
		m_ivPage7.setOnClickListener(this);
		m_ivPage8.setOnClickListener(this);

		tvNever.setOnClickListener(this);
		tvClose.setOnClickListener(this);

		m_Pager = (ViewPager) findViewById(R.id.vp_tutorial_pager);
		m_Pager.setAdapter(new PagerAdapterClass());
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.iv_tutorial_page1) {
			m_Pager.setCurrentItem(0);
		} else if (v.getId() == R.id.iv_tutorial_page2) {
			m_Pager.setCurrentItem(1);
		} else if (v.getId() == R.id.iv_tutorial_page3) {
			m_Pager.setCurrentItem(2);
		} else if (v.getId() == R.id.iv_tutorial_page4) {
			m_Pager.setCurrentItem(3);
		} else if (v.getId() == R.id.iv_tutorial_page5) {
			m_Pager.setCurrentItem(4);
		} else if (v.getId() == R.id.iv_tutorial_page6) {
			m_Pager.setCurrentItem(5);
		} else if (v.getId() == R.id.iv_tutorial_page7) {
			m_Pager.setCurrentItem(6);
		} else if (v.getId() == R.id.iv_tutorial_page8) {
			m_Pager.setCurrentItem(7);
		} else if (v.getId() == R.id.tv_tutorial_never) {
			SharedPref pref = SharedPref.getInstance(this);
			pref.setBooleanPref(SharedPref.PREF_TUTORIAL_NEVERSHOW, true);
			finish();
		} else if (v.getId() == R.id.tv_tutorial_close) {
			finish();
		}
	}

	private class PagerAdapterClass extends PagerAdapter {

		private LayoutInflater mInflater;

		public PagerAdapterClass() {
			super();
			mInflater = getLayoutInflater();
		}

		@Override
		public int getCount() {
			return 8;
		}

		@Override
		public Object instantiateItem(View pager, int position) {
			View v = null;
			if (position == 0)
				v = mInflater.inflate(R.layout.layout_tutorial_1, null);
			else if (position == 1)
				v = mInflater.inflate(R.layout.layout_tutorial_2, null);
			else if (position == 2)
				v = mInflater.inflate(R.layout.layout_tutorial_3, null);
			else if (position == 3)
				v = mInflater.inflate(R.layout.layout_tutorial_4, null);
			else if (position == 4)
				v = mInflater.inflate(R.layout.layout_tutorial_5, null);
			else if (position == 5)
				v = mInflater.inflate(R.layout.layout_tutorial_6, null);
			else if (position == 6)
				v = mInflater.inflate(R.layout.layout_tutorial_7, null);
			else if (position == 7)
				v = mInflater.inflate(R.layout.layout_tutorial_8, null);

			((ViewPager) pager).addView(v, 0);

			return v;
		}

		@Override
		public void destroyItem(View pager, int position, Object view) {
			((ViewPager) pager).removeView((View) view);
		}

		@Override
		public boolean isViewFromObject(View pager, Object obj) {
			return pager == obj;
		}

		@Override
		public void restoreState(Parcelable arg0, ClassLoader arg1) {

		}

		@Override
		public Parcelable saveState() {
			return null;
		}

		@Override
		public void startUpdate(View arg0) {

		}

		@Override
		public void finishUpdate(View arg0) {
			int nCurrentItem = m_Pager.getCurrentItem();
			if (nCurrentItem == 0) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_on);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 1) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_on);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 2) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_on);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 3) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_on);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 4) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_on);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 5) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_on);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 6) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_on);
				m_ivPage8.setBackgroundResource(R.drawable.dot_off);
			} else if (nCurrentItem == 7) {
				m_ivPage1.setBackgroundResource(R.drawable.dot_off);
				m_ivPage2.setBackgroundResource(R.drawable.dot_off);
				m_ivPage3.setBackgroundResource(R.drawable.dot_off);
				m_ivPage4.setBackgroundResource(R.drawable.dot_off);
				m_ivPage5.setBackgroundResource(R.drawable.dot_off);
				m_ivPage6.setBackgroundResource(R.drawable.dot_off);
				m_ivPage7.setBackgroundResource(R.drawable.dot_off);
				m_ivPage8.setBackgroundResource(R.drawable.dot_on);
			}
		}

	}
}
