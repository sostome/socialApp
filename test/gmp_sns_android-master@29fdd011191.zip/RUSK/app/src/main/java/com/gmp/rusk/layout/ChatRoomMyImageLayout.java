package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.ChatRoomImageAct;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomImageView;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;

/**
 * ChatRoomMyImageLayout 채팅방 내 이미지 List Item Layout
 */
public class ChatRoomMyImageLayout extends CustomLinearLayout implements OnClickListener, OnLongClickListener {
	// Context m_Context;
	// int m_nNumber;
	// String m_strMyImageUrl, m_strMyImageThumbUrl;
	CustomImageView m_ivMyImageWidth;
	ImageView m_ivIcon,m_ivIconRefresh;
	RelativeLayout m_MyImageHeight, m_MyImageWidth;
	// ArrayList<Integer> m_arrRead;
	// ArrayList<Integer> m_arrTotalRead;
	TextView m_tvChatMyImageNosee, m_tvChatMyImageTime;
	// long m_lTime;
	// int m_nSendStatus;
	// String m_strMessageID, m_strRoomID;
	// int m_nWidth, m_nHeight;
	CommonPopup m_Popup;

	private RotateAnimation m_animProgress = null;

	private ChatRoomData m_ChatRoomData = null;
	private CommonListPopup m_ListPopup = null;
	private int nListPopupCase;
	private final int LONG_CLICK = 1;
	private final int SELECT_ICON = 2;
	private final int LONG_CLICK_FAIL = 3;
	private boolean isAbleClick = true;

	public ChatRoomMyImageLayout(Context context) {
		super(context);
		// m_nSendStatus = a_nSendStatus;
		// m_strRoomID = a_strRoomID;
		// // 전송 완료 전에는 로컬의 경로이며, 전송 완료 후에는 서버의 경로
		// m_strMyImageUrl = a_strMyImageUrl;
		// m_nWidth = a_nWidth;
		// m_nHeight = a_nHeight;
		// m_strMyImageThumbUrl = a_strMyImageThumbUrl;
		// m_nNumber = a_nNumber;
		// m_arrRead = a_arrRead;
		// m_arrTotalRead = a_arrTotalRead;
		// m_lTime = a_lDate;
		// m_strMessageID = a_strMessageID;
		init();

	}

	private void init() {

		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
		li.inflate(R.layout.layout_chat_room_myimage, this, true);

		m_tvChatMyImageNosee = (TextView) findViewById(R.id.tv_chat_myimage_nosee);
		m_tvChatMyImageTime = (TextView) findViewById(R.id.tv_chat_myimage_time);

		// m_MyImageWidth = (RelativeLayout) findViewById(R.id.layout_chat_myimage_width);
		m_ivMyImageWidth = (CustomImageView) findViewById(R.id.iv_chat_myimage_width);
		m_ivIcon = (ImageView) findViewById(R.id.iv_chat_myimage_icon);
		m_ivIconRefresh = (ImageView) findViewById(R.id.iv_chat_myimg_icon_refresh);
		m_animProgress = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		m_animProgress.setInterpolator(new LinearInterpolator());
		m_animProgress.setRepeatCount(Animation.INFINITE);
		m_animProgress.setDuration(1000);

		m_tvChatMyImageNosee.setOnClickListener(this);

	}

	public void setChatRoomData(ChatRoomData a_Data) {
		m_ChatRoomData = a_Data;
		if(a_Data.m_strRoomID.split("_").length == 3) {
		/*	m_ivMyImageWidth.setBackgroundResource(R.drawable.btn_group_balloon_me);*/
			m_tvChatMyImageNosee.setTextColor(Color.parseColor("#e04f07"));
		} else {
		/*	m_ivMyImageWidth.setBackgroundResource(R.drawable.btn_chat_balloon_me);*/
			m_tvChatMyImageNosee.setTextColor(Color.parseColor("#e04f07"));
		}

		// 올린 시간
		String pattern = "a h:mm";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String date = (String) format.format(new Timestamp(m_ChatRoomData.m_lDate));

		int nNoReadCount = 0;
		//nNoReadCount = m_ChatRoomData.m_arrTotalRead.size() - m_ChatRoomData.m_arrRead.size();
		nNoReadCount = m_ChatRoomData.m_nNoReadCount;
		if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {
			m_ivIcon.setVisibility(View.VISIBLE);
			m_ivIconRefresh.setVisibility(GONE);
			m_ivIcon.setBackgroundResource(R.drawable.img_loading);
			m_ivIcon.startAnimation(m_animProgress);
			m_tvChatMyImageTime.setVisibility(VISIBLE);
			m_tvChatMyImageNosee.setVisibility(View.GONE);
			m_ivIcon.setOnClickListener(null);
			m_ivMyImageWidth.setOnClickListener(null);
			m_ivMyImageWidth.setOnLongClickListener(this);
		} else if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_FAIL) {
			m_ivIconRefresh.setVisibility(VISIBLE);
			m_ivIconRefresh.setBackgroundResource(R.drawable.btn_refresh);
			m_ivIconRefresh.setOnClickListener(this);
			m_tvChatMyImageNosee.setVisibility(View.GONE);
			m_ivIcon.setVisibility(View.GONE);
			m_tvChatMyImageTime.setVisibility(GONE);
			m_ivMyImageWidth.setOnClickListener(null);
			m_ivMyImageWidth.setOnLongClickListener(this);
		} else if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_SUCCESS) {
			m_ivIcon.setOnClickListener(null);
			m_ivIcon.setVisibility(View.GONE);
			m_ivIconRefresh.setVisibility(GONE);
			m_tvChatMyImageTime.setVisibility(VISIBLE);
			m_tvChatMyImageNosee.setVisibility(View.VISIBLE);
			m_ivMyImageWidth.setOnClickListener(this);
			m_ivMyImageWidth.setOnLongClickListener(this);
		}

		if (nNoReadCount == 0) {
			m_tvChatMyImageNosee.setText("");
			m_tvChatMyImageNosee.setVisibility(View.GONE);
		} else if (nNoReadCount < 0) {
			m_tvChatMyImageNosee.setText("");
			m_tvChatMyImageNosee.setVisibility(View.GONE);
		} else {
			m_tvChatMyImageNosee.setText("" + nNoReadCount);
			m_tvChatMyImageNosee.setVisibility(View.VISIBLE);
		}

		m_tvChatMyImageTime.setText(date);
		// if(m_MyImage.getWidth() > m_MyImage.getHeight()){
		// m_MyImageWidth.setVisibility(View.VISIBLE);
		// TTalkImageLoader.getImage(m_strMyImageThumbUrl, m_ivMyImageHeight);
		
		int height = m_ChatRoomData.m_nHeight;
		int width = m_ChatRoomData.m_nWidht;
		
		
		if (width >= height && width > 290) {
			height = (height * 290) / width;
			width = 290;
		} else if (width < height && height > 290) {
			width = (width * 290) / height;
			height = 290;
		}
		m_ivMyImageWidth.setMinimumHeight(height+70);
		m_ivMyImageWidth.setMinimumWidth(width+70);
		
		if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_SUCCESS) {
			
			ImageLoaderManager imageloader = ImageLoaderManager.getInstance(getContext());
			Bitmap thumbBitmap = imageloader.getLocalRoundImage(m_ChatRoomData.m_strMyImageThumbUrl);
			if(thumbBitmap == null)
				imageloader.getImageRoundMine(m_ivMyImageWidth, m_ChatRoomData.m_strMyImageThumbUrl, 0, m_ImageLoaderListener);
			else
				m_ivMyImageWidth.setImageBitmap(thumbBitmap);
			// CustomImageView customImageView = CustomImageView.getInstance(getContext());
			// customImageView.getImage(m_ivMyImageWidth, m_ChatRoomData.m_strMyImageThumbUrl, 0, m_ChatRoomData.m_nWidht, m_ChatRoomData.m_nHeight);
			
			m_tvChatMyImageTime.setOnClickListener(this);
		} else {

			ImageLoaderManager imageloader = ImageLoaderManager.getInstance(getContext());
			imageloader.getImageRoundBeforeSend(m_ivMyImageWidth, m_ChatRoomData.m_strMyImageUrl, m_ChatRoomData.m_nHeight, m_ChatRoomData.m_nWidht);
			m_tvChatMyImageTime.setOnClickListener(null);


		}
	}

	ImageLoaderManager.ImageLoaderListener m_ImageLoaderListener = new ImageLoaderManager.ImageLoaderListener() {

		@Override
		public void onSuccess() {
			// TODO Auto-generated method stub
			if (m_ChatRoomData.m_strRoomID.length() > 8) {
				//((ChatRoomGroupAct) getContext()).setDataChanged();
				
			} else {
				//((ChatRoomAct) getContext()).setDataChanged();
			}

		}

		@Override
		public void onFail(String a_strErrorMsg) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onNotModified() {
			// TODO Auto-generated method stub

		}
	};

	// public class setImageLoadTask extends AsyncTask<Void, Void, Bitmap> {
	//
	// @Override
	// protected Bitmap doInBackground(Void... params) {
	// // TODO Auto-generated method stub
	// CommonLog.e(getContext(), "Path : " + m_ChatRoomData.m_strMyImageUrl);
	//
	// Bitmap bmp = BitmapFactory.decodeFile(Uri.fromFile(new File(m_ChatRoomData.m_strMyImageUrl)).getPath());
	// int height = m_ChatRoomData.m_nHeight;
	// int width = m_ChatRoomData.m_nWidht;
	//
	// Bitmap resizedBmp = null;
	//
	// if (width >= height) {
	// height = (height * 500) / width;
	// width = 500;
	// } else if (width < height) {
	// width = (width * 400) / height;
	// height = 400;
	// }
	//
	// resizedBmp = Bitmap.createScaledBitmap(bmp, width, height, true);
	//
	// return resizedBmp;
	// }
	//
	// protected void onPostExecute(Bitmap resizedBmp) {
	//
	// m_ivMyImageWidth.setImageBitmap(resizedBmp);
	//
	// }
	//
	// }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				isAbleClick = true;
			}

		};


		if (isAbleClick) {
			Timer mTimer = new Timer();
			mTimer.schedule(task, 500);
			isAbleClick = false;
			switch (v.getId()) {
			case R.id.iv_chat_myimg_icon_refresh:

				if (m_ChatRoomData.m_strRoomID.length() > 8) {
					((ChatRoomGroupAct) getContext()).clearRoom();
				} else {
					((ChatRoomAct) getContext()).clearRoom();
				}

				nListPopupCase = SELECT_ICON;
				m_ListPopup = new CommonListPopup(getContext(), ChatRoomMyImageLayout.this);
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_file_resend_type));
				m_ListPopup.setCancelable(true);
				m_ListPopup.show();

				break;
			case R.id.iv_chat_myimage_width:
				if((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
						App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled){
					m_Popup = new CommonPopup(getContext(), ChatRoomMyImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title), getContext().getString(R.string.cork_pop_fail_open_file));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					Intent intent = new Intent(getContext(), ChatRoomImageAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_IMAGE_PATH, m_ChatRoomData.m_strMyImageUrl);
					intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_ROOM_ID, m_ChatRoomData.m_strRoomID);
					intent.putExtra(IntentKeyString.INTENT_KEY_DOWNLOAD_MESSAGE_ID, m_ChatRoomData.m_strMessageID);

					getContext().startActivity(intent);
				}
				break;
			case R.id.tv_chat_myimage_nosee:
			case R.id.tv_chat_myimage_time:

				break;
			case R.id.ib_pop_ok:
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				if (m_ChatRoomData.m_strRoomID.length() < 8) {
					((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
				} else {
					((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
				}
				popup_ok.cancel();
				break;
			case R.id.ib_pop_cancel:
				CommonPopup popup_cancel = (CommonPopup)v.getTag();
				popup_cancel.cancel();
				break;
			case R.id.ib_pop_ok_long:
				CommonPopup popup_ok_long = (CommonPopup)v.getTag();
				popup_ok_long.cancel();
				break;
			case R.id.ib_pop_cancel_long:
				m_ListPopup.cancel();
				break;
			case R.id.tv_pop_first_row:
				m_ListPopup.cancel();
				if (nListPopupCase == LONG_CLICK_FAIL) {
					m_Popup = new CommonPopup(getContext(), ChatRoomMyImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title),
							getContext().getString(R.string.popup_delete_text_text));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else if (nListPopupCase == LONG_CLICK) {
					if (System.currentTimeMillis() >= m_ChatRoomData.m_lDate + 1814400000){
						m_Popup = new CommonPopup(getContext(), ChatRoomMyImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_title),
								getContext().getString(R.string.popup_send_other_fail));
						m_Popup.setCancelable(false);
						m_Popup.show();
					} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).sendFileOther(m_ChatRoomData.m_JsonObject.toString());
					} else {
						((ChatRoomGroupAct) getContext()).sendFileOther(m_ChatRoomData.m_JsonObject.toString());
					}
					}
				} else {
					ChattingDBManager chattingDBMngd = new ChattingDBManager(getContext());
					chattingDBMngd.openWritable(m_ChatRoomData.m_strRoomID);
					chattingDBMngd.deleteChattingMessage(m_ChatRoomData.m_strMessageID);
					chattingDBMngd.close();

					final Bitmap bmp = BitmapFactory.decodeFile(Uri.fromFile(new File(m_ChatRoomData.m_strMyImageUrl)).getPath());
					// int height = m_ChatRoomData.m_nHeight;
					// int width = m_ChatRoomData.m_nWidht;
					//
					// Bitmap resizedBmp = null;
					//
					// if (width >= height) {
					// height = (height * 500) / width;
					// width = 500;
					// } else if (width < height) {
					// width = (width * 400) / height;
					// height = 400;
					// }
					//
					// resizedBmp = Bitmap.createScaledBitmap(bmp, width,
					// height, true);
					//
					byte[] imgData = null;
					File file = new File(m_ChatRoomData.m_strMyImageUrl);

					try {
						FileInputStream isFile = new FileInputStream(file);
						int nCount = isFile.available();
						if (nCount > 0) {
							imgData = new byte[nCount];
							isFile.read(imgData);
						}
						if (isFile != null) {
							isFile.close();
						}
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					final byte[] imgDataf = imgData;

					final long lTime = System.currentTimeMillis();
					
					if (m_ChatRoomData.m_strRoomID.length() > 8) {
						((ChatRoomGroupAct) getContext()).reSendDelete(m_ChatRoomData);					
						((ChatRoomGroupAct) getContext()).sendImage(lTime, bmp, imgDataf, m_ChatRoomData.m_strMyImageUrl);
					} else {
						((ChatRoomAct) getContext()).reSendDelete(m_ChatRoomData);
						((ChatRoomAct) getContext()).sendImage(lTime, bmp, imgDataf, m_ChatRoomData.m_strMyImageUrl);
					}
				}
				break;
			case R.id.tv_pop_second_row:
				m_ListPopup.cancel();
				if (nListPopupCase == LONG_CLICK) {
					m_Popup = new CommonPopup(getContext(), ChatRoomMyImageLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title),
							getContext().getString(R.string.popup_delete_text_text));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					} else {
						((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					}
				}
				break;
			default:
				break;
			}
		}

	}

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.iv_chat_myimage_width:
			nListPopupCase = LONG_CLICK;
			m_ListPopup = new CommonListPopup(getContext(), ChatRoomMyImageLayout.this);
			if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_SUCCESS) {
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(),
						getResources().getStringArray(R.array.arr_chat_file_longclick_type));
			} 
			else {
				nListPopupCase = LONG_CLICK_FAIL;
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(),
						getResources().getStringArray(R.array.arr_chat_file_longclick_fail_type));
			}
			m_ListPopup.setCancelable(true);
			m_ListPopup.show();

			break;

		default:
			break;
		}
		return true;
	}

}
