package com.gmp.rusk.act;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.GalleryCategoryData;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.layout.adapter.GalleryListAdapter;
import com.gmp.rusk.utils.IntentKeyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class GalleryMultiselectorListAct extends CustomActivity implements OnClickListener, OnItemClickListener{
	
	private final int STATE_CATEGORY 	= 1;
	private final int STATE_FILES 		= 2;
	
	public static final int FROMACTIVITY_CHATTING 	= 0;
	public static final int FROMACTIVITY_SNS 		= 1;
	public static final int FROMACTIVITY_SNS_CREATE = 2;
	public static final int FROMACTIVITY_SNS_REPLY = 3;
	public static final int FROMACTIVITY_PROFILE = 4;

//	GridView v_GridGallery;			//file list를 보여주는 뷰
	Handler handler;				
	
	int MAX_SELECT_COUNT = 0;				//파일 선택 갯수 제한
	long MAX_SELECT_SIZE = 0L;				//파일 크기 제한
	boolean isSingleSelect = false;			//단일 선택 앨범 유무
	private int m_nFromActivity = FROMACTIVITY_CHATTING;
	
	// image or video
	public static int IMAGE_TYPE = 0;
	public static int VIDEO_TYPE = 1;
	// dir or file
	public static int FILE_TYPE = 0;
	public static int DIRECTORY_TYPE = 1;
	//file selection limit Error
	public static int ERROR_MAX_SIZE_OVER = -1;
	public static int ERROR_MAX_COUNT_OVER = -2;
	
	
//	TextView titlebar;				//상단 제목
//
//	ImageView imgNoMedia;			//이미지가 로딩 중일 때 보여주는 이미지 뷰 (현재는 이미지 없음)
//	ImageView imgSinglePick;        //단일 이미지를 선택했을 경우 보여주는 뷰
//	
//	Button btnGalleryOk;			//선택 완료 버튼
//	Button btnGalleryBack;			//뒤로 가기 버튼 (gone 처리 되어있음 - 뒤로가기 버튼이 없음)

	String action;					//동영상 혹은 이미지 앨범을 구별하기 위해 사용됨
	String album_file_path ;			//선택된 디렉토리 경로를 저장하기 위한 변수 
	
	private CommonPopup m_Popup = null;
	
	private int m_nState = STATE_CATEGORY;
	
	// Key : Path, Value : GalleryCategoryData
	private HashMap<String, GalleryCategoryData> m_mapCategory = new LinkedHashMap<String, GalleryCategoryData>();
	private ArrayList<GalleryListData> m_arrGalleryList = new ArrayList<GalleryListData>();
	
	private CategoryAdapter m_adapterCategory = null;
	private GalleryListAdapter v_adapter = null;			//select file list Adapter
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.act_galleryview_list);
		Intent intent = getIntent();
		action = intent.getAction();
		Bundle bundle = intent.getExtras();
		MAX_SELECT_COUNT = bundle.getInt(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_COUNT_LIMIT);	//넘겨 받은 인텐트에 최대 선택 및 최대 사이즈 정보를 받음
		MAX_SELECT_SIZE  = bundle.getLong(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_SIZE_LIMIT);
		m_nFromActivity = bundle.getInt(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FROM);
		if(MAX_SELECT_COUNT == 1)
			isSingleSelect = true;
		
		initImageLoader();				//Image loader와 캐시 디렉토리를 설정함
		getMedia();
		initUI();
		setUI();
//		fileListInit();
	}
	
	//image loader 초기화
	private void initImageLoader() {
//		try {
//			imageLoader = new ImageGalleryLoaderManager(GalleryMultiselectorListAct.this);
//
//		} catch (Exception e) {
//
//		}
	}
	
	private void initUI()
	{
		ImageView ibBack = (ImageView) findViewById(R.id.ib_gallery_view_back);
		ImageView btnOk = (ImageView) findViewById(R.id.ib_gallery_view_save);
		ibBack.setOnClickListener(this);
		btnOk.setOnClickListener(this);
		
		GridView gvGallery = (GridView) findViewById(R.id.gv_gallery_item_view);
		gvGallery.setFastScrollEnabled(true);
		gvGallery.setOnItemClickListener(mItemMulClickListener);
		gvGallery.setOnScrollListener(new OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				switch (scrollState) {
					case OnScrollListener.SCROLL_STATE_IDLE: // 스크롤이 정지되어 있는 상태.
						break;
					case OnScrollListener.SCROLL_STATE_TOUCH_SCROLL: // 스크롤이 터치되어 있을 때 상태,
						break;
					case OnScrollListener.SCROLL_STATE_FLING: // 이건 스크롤이 움직이고 있을때 상태.
						break;
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub

			}
		});
	}
	
	private void setUI()
	{
		GridView gvGalleryView = (GridView)findViewById(R.id.gv_gallery_item_view);
		ListView lvCategoryView = (ListView)findViewById(R.id.lv_gallery_category_view);
		ImageView ivNoMedia = (ImageView) findViewById(R.id.iv_no_media);
		
		lvCategoryView.setOnItemClickListener(this);
		
		if(m_mapCategory.isEmpty())
		{
			TextView tvTitlebar = (TextView)findViewById(R.id.tv_gallery_view_title);
			if(action.equalsIgnoreCase(GalleryAction.ACTION_IMAGE_LIST))
			{
				tvTitlebar.setText(R.string.act_galleryview_album_title);
			}
			else if(action.equalsIgnoreCase(GalleryAction.ACTION_VIDEO_LIST))
			{
				tvTitlebar.setText(R.string.act_galleryview_vod_title);
			}
			ImageView btnOk = (ImageView) findViewById(R.id.ib_gallery_view_save);
			btnOk.setVisibility(View.GONE);
			gvGalleryView.setVisibility(View.GONE);
			lvCategoryView.setVisibility(View.GONE);
			ivNoMedia.setVisibility(View.VISIBLE);
		}
		else
		{			
			ivNoMedia.setVisibility(View.GONE);

			ImageView ibBack = (ImageView) findViewById(R.id.ib_gallery_view_back);
			ImageView btnOk = (ImageView) findViewById(R.id.ib_gallery_view_save);
			
			if(m_nState == STATE_CATEGORY)
			{
				gvGalleryView.setVisibility(View.GONE);
				lvCategoryView.setVisibility(View.VISIBLE);
				if(m_adapterCategory == null)
				{
					m_adapterCategory = new CategoryAdapter();
					lvCategoryView.setAdapter(m_adapterCategory);
				}
				//ibBack.setVisibility(View.INVISIBLE);
				btnOk.setVisibility(View.INVISIBLE);
				
				TextView tvTitlebar = (TextView)findViewById(R.id.tv_gallery_view_title);
				
				if(action.equalsIgnoreCase(GalleryAction.ACTION_IMAGE_LIST))
				{
					tvTitlebar.setText(R.string.act_galleryview_album_title);
				}
				else if(action.equalsIgnoreCase(GalleryAction.ACTION_VIDEO_LIST))
				{
					tvTitlebar.setText(R.string.act_galleryview_vod_title);
				}
			}
			else if(m_nState == STATE_FILES)
			{
				ibBack.setVisibility(View.VISIBLE);
				btnOk.setVisibility(View.VISIBLE);
				gvGalleryView.setVisibility(View.VISIBLE);
				lvCategoryView.setVisibility(View.GONE);
			}
		}
	}
	
	private void getMedia()
	{
		if(action.equalsIgnoreCase(GalleryAction.ACTION_IMAGE_LIST))
		{
			getPhoto();
		}
		else if(action.equalsIgnoreCase(GalleryAction.ACTION_VIDEO_LIST))
		{
			getVOD();
		}
	}
	
	private void getPhoto()
	{
		m_arrGalleryList = new ArrayList<GalleryListData>();


			String[] columns = {MediaStore.Images.Media._ID,
				       MediaStore.Images.Media.DATA,
				       MediaStore.Images.Media.DISPLAY_NAME,
				       MediaStore.Images.Media.SIZE
				       };

			final String orderBy = MediaStore.Images.Media._ID;
			Cursor imagecursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, null, null, orderBy);
			if (imagecursor != null && imagecursor.getCount() > 0) {

				while (imagecursor.moveToNext()) {
					try {
					GalleryListData item = new GalleryListData();
					int index = imagecursor.getColumnIndex(MediaStore.Images.Media._ID);
					int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Images.Media.DATA);
					int imageSizeIndex = imagecursor.getColumnIndex(MediaStore.Images.Media.SIZE);  
					String fullpath = imagecursor.getString(dataColumnIndex);
					item.setSdcardPath(fullpath);
					item.m_nMediaIndex = imagecursor.getLong(index);
					item.m_nItemId = imagecursor.getString(index);
					item.m_lnSize = Integer.parseInt(imagecursor.getString(imageSizeIndex));
					item.m_nFileType = FILE_TYPE;
					item.m_strType = IMAGE_TYPE;

					String strPath = item.getDirPath();
					int nLastIndexOf = strPath.lastIndexOf("/");
					String strFolderName = strPath.substring(nLastIndexOf + 1, strPath.length());
					GalleryCategoryData galleryCategoryData = m_mapCategory.get(strPath);
					if(galleryCategoryData == null)
					{
						galleryCategoryData = new GalleryCategoryData();
						galleryCategoryData.m_strFolderName = strFolderName;
						galleryCategoryData.m_strPath = strPath;
						m_mapCategory.put(strPath, galleryCategoryData);
					}
					galleryCategoryData.m_nMediaCount++;
					galleryCategoryData.m_currentGalleryListData = item;
						m_arrGalleryList.add(item);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			imagecursor.close();


		// show newest photo at beginning of the list
		Collections.reverse(m_arrGalleryList);
	}
	
	private void getVOD()
	{
		m_arrGalleryList = new ArrayList<GalleryListData>();
		

			String[] columns = {MediaStore.Video.Media._ID,  
				       MediaStore.Video.Media.DATA,  
				       MediaStore.Video.Media.DISPLAY_NAME,  
				       MediaStore.Video.Media.SIZE
				       }; 
			final String orderBy = MediaStore.Video.Media._ID;
			Cursor imagecursor = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, columns, null, null, orderBy);
			if (imagecursor != null && imagecursor.getCount() > 0) {

				while (imagecursor.moveToNext()) {
					try {
					int index = imagecursor.getColumnIndex(MediaStore.Video.Media._ID);
					int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Video.Media.DATA);
					int imageSizeIndex = imagecursor.getColumnIndex(MediaStore.Video.Media.SIZE);  
					GalleryListData item = new GalleryListData();
					item.setSdcardPath(imagecursor.getString(dataColumnIndex));
					item.m_nMediaIndex = imagecursor.getLong(index);
					item.m_nItemId = imagecursor.getString(index);
					item.m_lnSize = Integer.parseInt(imagecursor.getString(imageSizeIndex));
					item.m_nFileType = FILE_TYPE;
					item.m_strType = VIDEO_TYPE;
					
					String strPath = item.getDirPath();
					int nLastIndexOf = strPath.lastIndexOf("/");
					String strFolderName = strPath.substring(nLastIndexOf + 1, strPath.length());
					GalleryCategoryData galleryCategoryData = m_mapCategory.get(strPath);
					if(galleryCategoryData == null)
					{
						galleryCategoryData = new GalleryCategoryData();
						galleryCategoryData.m_strFolderName = strFolderName;
						galleryCategoryData.m_strPath = strPath;
						m_mapCategory.put(strPath, galleryCategoryData);
					}
					galleryCategoryData.m_nMediaCount++;
					galleryCategoryData.m_currentGalleryListData = item;
						m_arrGalleryList.add(item);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			imagecursor.close();


		// show newest photo at beginning of the list
		Collections.reverse(m_arrGalleryList);
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		if(m_nState == STATE_CATEGORY)
			super.onBackPressed();
		else
		{
			m_nState = STATE_CATEGORY;
			setUI();
			max_size = 0;
			max_count = 0;
		}
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		int nId = v.getId();
		if(nId == R.id.ib_gallery_view_back)
		{
			if(m_nState == STATE_CATEGORY)
				finish();
			else
			{
				m_nState = STATE_CATEGORY;
				setUI();
				max_size = 0;
				max_count = 0;
			}
		}
		else if(nId == R.id.ib_gallery_view_save)
		{
			Intent data = new Intent();
			ArrayList<GalleryListData> selectGalleryList = v_adapter.getSelected();

			if(v_adapter.getSelected().size() > 0)
			{
				Bundle extra = new Bundle();
				extra.putSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY, selectGalleryList);
				data.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST, extra);  		//다중 선택

				setResult(RESULT_OK, data);
			}
			finish();
		}
	}
	
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		m_nState = STATE_FILES;
		setUI();
		
		GalleryCategoryData categoryData = (GalleryCategoryData)m_adapterCategory.getItem(position);
		if(categoryData == null)
		{
			// 전체
			for(GalleryListData data : m_arrGalleryList)
			{
				data.isSeleted = false;
			}
			fileListInit(getString(R.string.act_galleryview_allitem), m_arrGalleryList);
		}
		else
		{
			ArrayList<GalleryListData> arrGalleryListData = new ArrayList<GalleryListData>();
			
			for(GalleryListData data : m_arrGalleryList)
			{
				if(categoryData.m_strPath.equals(data.getDirPath()))
				{
					data.isSeleted = false;
					arrGalleryListData.add(data);
				}
			}
			
			fileListInit(categoryData.m_strFolderName, arrGalleryListData);
		}
	}

	//선택된 디렉토리를 로드할 때 화면 구성 및 데이터 로드
    int max_count = 0;
    int max_size = 0;
	private void fileListInit(String a_strFolderName, ArrayList<GalleryListData> a_arrGalleryLiatData) {
		handler = new Handler();
		
		GridView gvGalleryView = (GridView)findViewById(R.id.gv_gallery_item_view);
		v_adapter = new GalleryListAdapter(getApplicationContext());
		v_adapter.setMultiplePick(true);
		gvGalleryView.setAdapter(v_adapter);
		
		v_adapter.addAll(a_arrGalleryLiatData);

		TextView tvTitlebar = (TextView)findViewById(R.id.tv_gallery_view_title);
		tvTitlebar.setText(a_strFolderName + "(" + v_adapter.getCount() + ")");
		ImageView btnOk = (ImageView) findViewById(R.id.ib_gallery_view_save);
		/*btnOk.setText(R.string.act_galleryview_complete);*/
	}

	//선택된 디렉토리의 파일 리스트를 가져옴.  
	private ArrayList<GalleryListData> getGalleryPhotos() {
		ArrayList<GalleryListData> galleryList = new ArrayList<GalleryListData>();
		

			String[] columns = {MediaStore.Images.Media._ID,  
				       MediaStore.Images.Media.DATA,  
				       MediaStore.Images.Media.DISPLAY_NAME,
				       MediaStore.Images.Media.SIZE
				       }; 
			
			final String orderBy = MediaStore.Images.Media._ID;
			Cursor imagecursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, null, null, orderBy);
			if (imagecursor != null && imagecursor.getCount() > 0) {

				while (imagecursor.moveToNext()) {
					try {
					GalleryListData item = new GalleryListData();
					int index = imagecursor.getColumnIndex(MediaStore.Images.Media._ID);
					int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Images.Media.DATA);
					int imageSizeIndex = imagecursor.getColumnIndex(MediaStore.Images.Media.SIZE);  
					String fullpath = imagecursor.getString(dataColumnIndex);
					item.setSdcardPath(fullpath);
					item.m_nMediaIndex = imagecursor.getLong(index);
					item.m_nItemId = imagecursor.getString(index);
					item.m_lnSize = Integer.parseInt(imagecursor.getString(imageSizeIndex));
					item.m_nFileType = FILE_TYPE;
					item.m_strType = IMAGE_TYPE;
					galleryList.add(item);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			imagecursor.close();


		// show newest photo at beginning of the list
		Collections.reverse(galleryList);
		return galleryList;
	}
	
	//선택된 디렉토리의 동영상 파일 리스트를 가져옴
	private ArrayList<GalleryListData> getGalleryVideos() {
		ArrayList<GalleryListData> VideoList = new ArrayList<GalleryListData>();
		

			String[] columns = {MediaStore.Video.Media._ID,  
				       MediaStore.Video.Media.DATA,  
				       MediaStore.Video.Media.DISPLAY_NAME,  
				       MediaStore.Video.Media.SIZE
				       }; 
			final String orderBy = MediaStore.Video.Media._ID;
			Cursor imagecursor = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, columns, null, null, orderBy);
			if (imagecursor != null && imagecursor.getCount() > 0) {

				while (imagecursor.moveToNext()) {
					try {
					int index = imagecursor.getColumnIndex(MediaStore.Video.Media._ID);
					int dataColumnIndex = imagecursor.getColumnIndex(MediaStore.Video.Media.DATA);
					int imageSizeIndex = imagecursor.getColumnIndex(MediaStore.Video.Media.SIZE);  
					GalleryListData item = new GalleryListData();
					item.setSdcardPath(imagecursor.getString(dataColumnIndex));
					item.m_nMediaIndex = imagecursor.getLong(index);
					item.m_nItemId = imagecursor.getString(index);
					item.m_lnSize = Integer.parseInt(imagecursor.getString(imageSizeIndex));
					item.m_nFileType = FILE_TYPE;
					item.m_strType = VIDEO_TYPE;
					VideoList.add(item);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			imagecursor.close();


		// show newest photo at beginning of the list
		Collections.reverse(VideoList);
		return VideoList;
	}
	
	private void showExceedSizeLimitPopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_attach_maxsize));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void showExceedSizeZeroPopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_attach_minsize));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void showExceedMaxCountPopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
		String strMsg = "";
		if(m_nFromActivity == FROMACTIVITY_CHATTING)
			strMsg = getString(R.string.popup_chatting_image_attach_maxcount);
		else if(m_nFromActivity == FROMACTIVITY_SNS_CREATE || m_nFromActivity == FROMACTIVITY_SNS_REPLY || m_nFromActivity == FROMACTIVITY_PROFILE)
			strMsg = getString(R.string.popup_sns_attach_maxcount_snscreate);
		else
			strMsg = getString(R.string.popup_sns_attach_maxcount);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), strMsg);
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
	
	//video 와 image album 구별을 위한 Action
	public class GalleryAction {
		
		//VIDEO ACTION
		public static final String ACTION_VIDEO_LIST = "com.gmp.rusk.ACTION_VIDEO_LIST";
		
		//PHOTO ACTION
		public static final String ACTION_IMAGE_LIST = "com.gmp.rusk.ACTION_IMAGE_LIST";
		
	}
	
	
	//아이템 선택 시 최대 선택 갯수, 최대 선택 용량을 판별
	//아이템 선택 이미지 변경
	AdapterView.OnItemClickListener mItemMulClickListener = new AdapterView.OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> l, View v, int position, long id) {
			int nMaxCount = v_adapter.changeSelection(v, position, max_count, MAX_SELECT_COUNT, MAX_SELECT_SIZE);
			
			if(max_count == MAX_SELECT_COUNT && nMaxCount == MAX_SELECT_COUNT)
			{
				showExceedMaxCountPopup();
				return;
			}
			
			if(nMaxCount == -1)
				showExceedSizeLimitPopup();
			else if(nMaxCount == -2)
				showExceedSizeZeroPopup();
			else
			{
				max_count = nMaxCount;
				ImageView btnOk = (ImageView) findViewById(R.id.ib_gallery_view_save);
				/*if(max_count == 0)
					btnOk.setText(getString(R.string.act_galleryview_complete));
				else
					btnOk.setText(getString(R.string.act_galleryview_complete) + max_count + " ");*/
			}
		}
	};
	
	private class CategoryAdapter extends BaseAdapter
	{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return m_mapCategory.size() + 1;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if(position == 0)
				return null;
			
			Iterator<String> iter = m_mapCategory.keySet().iterator();
			int nCount = 1;
			while(iter.hasNext())
			{
				String strKey = iter.next();
				if(position == nCount)
				{
					return m_mapCategory.get(strKey);
				}
				nCount++;
			}
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if(convertView == null)
			{
				LayoutInflater li = getLayoutInflater();
				convertView = li.inflate(R.layout.layout_gallery_category_item, parent, false);
			}
			
			GalleryCategoryData categoryData = (GalleryCategoryData)getItem(position);
			ImageView ivThumbNail = (ImageView)convertView.findViewById(R.id.iv_gallery_category_currentthumbnail);
			TextView tvThumbNail = (TextView)convertView.findViewById(R.id.tv_gallery_category_name);
			
			if(categoryData == null)
			{
				String strName = getString(R.string.act_galleryview_allitem) + "(" + m_arrGalleryList.size() + ")";
				tvThumbNail.setText(strName);
				
//				GalleryListData galleryData = categoryData.m_currentGalleryListData;
				GalleryListData galleryData = m_arrGalleryList.get(0);

				Bitmap bmpThumb = null;
				if (galleryData.m_strType == IMAGE_TYPE) {
					bmpThumb = Images.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, Images.Thumbnails.MINI_KIND, null);
					if (bmpThumb == null)
						bmpThumb = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, MediaStore.Images.Thumbnails.MICRO_KIND, null);
				}
				else
				{
					bmpThumb = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, MediaStore.Video.Thumbnails.MINI_KIND, null);
					if (bmpThumb == null)
						bmpThumb = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, MediaStore.Video.Thumbnails.MICRO_KIND, null);
				}
				
				if(bmpThumb != null) {
					try {
						ExifInterface exif = new ExifInterface(galleryData.getSdcardPath());
						int orientaion = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1);
						if(orientaion != 0) {
							int degree = exifOrientationToDegrees(orientaion);

							Matrix matrix = new Matrix();
							matrix.setRotate(degree);

							bmpThumb = Bitmap.createBitmap(bmpThumb, 0, 0, bmpThumb.getWidth(), bmpThumb.getHeight(), matrix, true);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
					ivThumbNail.setImageBitmap(bmpThumb);
				}

				
			}
			else
			{
				String strName = categoryData.m_strFolderName + "(" + categoryData.m_nMediaCount + ")";
				tvThumbNail.setText(strName);
				
				GalleryListData galleryData = categoryData.m_currentGalleryListData;
				Bitmap bmpThumb = null;
				if (galleryData.m_strType == IMAGE_TYPE) {
					bmpThumb = Images.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, Images.Thumbnails.MINI_KIND, null);
					if (bmpThumb == null)
						bmpThumb = MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, MediaStore.Images.Thumbnails.MICRO_KIND, null);
				}
				else
				{
					bmpThumb = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, MediaStore.Video.Thumbnails.MINI_KIND, null);
					if (bmpThumb == null)
						bmpThumb = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), galleryData.m_nMediaIndex, MediaStore.Video.Thumbnails.MICRO_KIND, null);
				}
				
				if(bmpThumb != null){
					try {
						ExifInterface exif = new ExifInterface(galleryData.getSdcardPath());
						int orientaion = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, -1);
						if(orientaion != 0) {
							int degree = exifOrientationToDegrees(orientaion);

							Matrix matrix = new Matrix();
							matrix.setRotate(degree);

							bmpThumb = Bitmap.createBitmap(bmpThumb, 0, 0, bmpThumb.getWidth(), bmpThumb.getHeight(), matrix, true);
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
					ivThumbNail.setImageBitmap(bmpThumb);
				}

			}
			
			return convertView;
		}
		
	}

	public int exifOrientationToDegrees(int exifOrientation){
	  	if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_90) {
		    return 90;
	  	} else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_180) {
		    return 180;
		} else if (exifOrientation == ExifInterface.ORIENTATION_ROTATE_270) {
		    return 270;
	  	} return 0;
	}
}
