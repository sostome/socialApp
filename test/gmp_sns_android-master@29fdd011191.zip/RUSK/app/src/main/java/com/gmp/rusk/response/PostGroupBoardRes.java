package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class PostGroupBoardRes extends ChannelRes{
	
	private final String JSON_THREADNO				= "threadNo";
	
	private int m_nThreadNo = 0;
	
	public PostGroupBoardRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		if(m_strResData == null || m_strResData.equals(""))
			return;
		
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);

			m_nThreadNo = jsonRoot.getInt(JSON_THREADNO);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int getThreadNo()
	{
		return m_nThreadNo;
	}
}
