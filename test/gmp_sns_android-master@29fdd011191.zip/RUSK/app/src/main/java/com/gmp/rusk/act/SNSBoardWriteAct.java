package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.customview.KeyBoardShowHideEventLayout;
import com.gmp.rusk.customview.KeyBoardShowHideEventLayout.OnKeyBoardEvent;
import com.gmp.rusk.datamodel.FileInfo;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostGroupBoardFileUploadReq;
import com.gmp.rusk.request.PostGroupBoardReq;
import com.gmp.rusk.response.PostGroupBoardRes;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.ScaleImage;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SNSBoardWriteAct extends CustomActivity implements OnClickListener{
	
	private final int REQUESTCODE_SNSCLOUDFILESEARCH = 20000;
	
	private final int ATTACH_FILE_MAX_COUNT = 10;
	private final long ATTACH_FILE_MAX_SIZE = 104857600L;
	
	private int m_nGroupId = -1;
	
	private long m_lnAttachFileTotalSize = 0L;
	
	private TakeMediaIntent m_TakeMedia = null;
	
	private ArrayList<SNSBoardFileData> m_arrAttachMedia = new ArrayList<SNSBoardFileData>();
	private ArrayList<SNSBoardFileData> m_arrAttachFile = new ArrayList<SNSBoardFileData>();
	private AttachFileListAdapter m_adapterAttachFileList = null;
	
	private CommonPopup m_Popup = null;
	private ProgressDlg m_Progress = null;
	private  String m_strBoardText;
	private HashMap<String, Bitmap> m_mapThumbnail = new HashMap<String, Bitmap>();

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_snsboardwrite);
		
		getIntentData();
		
		initUI();
		setAttachFileUI();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}
	}

	private void getIntentData()
	{
		m_nGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSBOARDWRITE_GROUPID, -1);
		m_strBoardText = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDTEXT);
	}
	
	private void initUI()
	{
		ImageView btnTopClose = (ImageView)findViewById(R.id.btn_top_close);
		btnTopClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				m_Popup = new CommonPopup(SNSBoardWriteAct.this, new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						int nId = v.getId();
						if(nId == R.id.ib_pop_ok)
						{
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							finish();
						}
						CommonPopup popup = (CommonPopup)v.getTag();
						popup.cancel();
						popup.dismiss();
					}
				}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_confirm), getString(R.string.cork_pop_cancel_write));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		});
		KeyBoardShowHideEventLayout layoutRoot = (KeyBoardShowHideEventLayout)findViewById(R.id.layout_snsboardwrite_root);
		layoutRoot.setOnKeyBoardEvent(new OnKeyBoardEvent() {
			
			@Override
			public void onKeyBoardEvent(boolean a_isKeyBoardShown) {
				// TODO Auto-generated method stub
				if(a_isKeyBoardShown)
					hideAttachFileList();
				else
					showAttachFileList();
			}
		});
		
		TextView tvTitle = (TextView)findViewById(R.id.tv_snsboardwrite_title);
		tvTitle.setText(R.string.snsboardwrite_write_title);
		
		ImageView btnSave = (ImageView) findViewById(R.id.btn_snsboardwrite_save);
		btnSave.setOnClickListener(this);
		
		LinearLayout layoutRegulerAttachMenu = (LinearLayout)findViewById(R.id.layout_snsboardwrite_regular_attachmenu);
		LinearLayout layoutPartnerAttachMenu = (LinearLayout)findViewById(R.id.layout_snsboardwrite_partner_attachmenu);
		if(AppSetting.FEATURE_VARIANT.equals("R"))
		{
			layoutRegulerAttachMenu.setVisibility(View.VISIBLE);
			layoutPartnerAttachMenu.setVisibility(View.GONE);
			
			ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_file);
			ImageButton btnCloud = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_cloud);
			ImageButton btnCamera = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_camera);
			ImageButton btnAlbum = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_album);
			ImageButton btnVod = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_vod);
			btnFile.setOnClickListener(this);
			btnCloud.setOnClickListener(this);
			btnCamera.setOnClickListener(this);
			btnAlbum.setOnClickListener(this);
			btnVod.setOnClickListener(this);

			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageSharingEnabled) {
				btnAlbum.setOnClickListener(null);
				btnAlbum.setImageResource(R.drawable.btn_write_photo_disabled);
				btnVod.setOnClickListener(null);
				btnVod.setImageResource(R.drawable.btn_write_movie_disabled);
				btnCamera.setOnClickListener(null);
				btnCamera.setImageResource(R.drawable.btn_write_camera_disabled);
			}
			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileSharingEnabled) {
				btnFile.setOnClickListener(null);
				btnFile.setImageResource(R.drawable.btn_write_file_disabled);
			}
		}
		else
		{
			layoutRegulerAttachMenu.setVisibility(View.GONE);
			layoutPartnerAttachMenu.setVisibility(View.VISIBLE);
			
			ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_file);
			ImageButton btnCamera = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_camera);
			ImageButton btnAlbum = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_album);
			ImageButton btnVod = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_vod);
			btnFile.setOnClickListener(this);
			btnCamera.setOnClickListener(this);
			btnAlbum.setOnClickListener(this);
			btnVod.setOnClickListener(this);

			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageSharingEnabled) {
				btnAlbum.setOnClickListener(null);
				btnAlbum.setImageResource(R.drawable.btn_write_photo_disabled);
				btnVod.setOnClickListener(null);
				btnVod.setImageResource(R.drawable.btn_write_movie_disabled);
				btnCamera.setOnClickListener(null);
				btnCamera.setImageResource(R.drawable.btn_write_camera_disabled);
			}
			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileSharingEnabled) {
				btnFile.setOnClickListener(null);
				btnFile.setImageResource(R.drawable.btn_write_file_disabled);
			}
		}

		final EditText etComment = (EditText)findViewById(R.id.et_snsboardwrite_comment);
		SharedPref pref = SharedPref.getInstance(this);
		int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			etComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			etComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20.8f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			etComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25.6f);
		}
		etComment.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if(s.length() > 0)
				{
					String strRemoveEnter = s.toString().replace("\n", "");
					String strRemoveSpace = strRemoveEnter.replace(" ", "");
					if(!strRemoveSpace.equals("")){
						setSaveButtonEnable(true);
					} else {
						setSaveButtonEnable(false);
					}
					if(s.length() > 2999){
						m_Popup = new CommonPopup(SNSBoardWriteAct.this, new View.OnClickListener() {

							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								CommonPopup popup = (CommonPopup)v.getTag();
								popup.cancel();
							}
						}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.snsboardwrite_limit));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}

				}
				else
				{
					if(m_arrAttachMedia.size() > 0 || m_arrAttachFile.size() > 0)
						setSaveButtonEnable(true);
					else
						setSaveButtonEnable(false);
				}
		}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub

			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				ArrayList<int[]> spans = new ArrayList<int[]>();

				char prefix = '#';
				Pattern pattern = Pattern.compile(prefix + "[^\\r\\n\\t\\f #]{1,3000}");
				Matcher matcher = pattern.matcher(s);

				// Check all occurrences
				while (matcher.find()) {
					int[] currentSpan = new int[2];
					currentSpan[0] = matcher.start();
					currentSpan[1] = matcher.end();
					spans.add(currentSpan);
				}
				for (int i = 0; i < spans.size(); i++) {
					int[] span = spans.get(i);
					int hashTagStart = span[0];
					int hashTagEnd = span[1];
						s.setSpan(new ForegroundColorSpan(Color.parseColor("#48abb7")),
								hashTagStart,
								hashTagEnd, 0);


				}
			}
		});
		etComment.setText(m_strBoardText);
	}

	@Override
	public void onBackPressed() {
		m_Popup = new CommonPopup(SNSBoardWriteAct.this, new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					CommonPopup popup = (CommonPopup)v.getTag();
					popup.cancel();
					popup.dismiss();
					finish();
				}
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.pop_confirm), getString(R.string.cork_pop_cancel_write));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}

	private void setSaveButtonEnable(boolean a_isEnable)
	{
		ImageView btnSave = (ImageView) findViewById(R.id.btn_snsboardwrite_save);
		btnSave.setEnabled(a_isEnable);
		if(a_isEnable)
			btnSave.setImageResource(R.drawable.btn_btn_top_ok);
		else
			btnSave.setImageResource(R.drawable.btn_top_ok_disabled);
	}
	
	private void setAttachFileUI()
	{
		LinearLayout layoutAttach = (LinearLayout)findViewById(R.id.layout_snsboardwrite_attach);

		if(getAttachCount() > 0)
		{
			int nImageCount = 0;
			int nVideoCount = 0;
			setSaveButtonEnable(true);
			layoutAttach.setVisibility(View.VISIBLE);
			m_lnAttachFileTotalSize = 0;
			for(SNSBoardFileData data : m_arrAttachFile)
			{
				m_lnAttachFileTotalSize += data.m_lnFileSize;
				ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_file);
				btnFile.setImageResource(R.drawable.btn_write_file_selected);
				ImageButton btnFile2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_file);
				btnFile2.setImageResource(R.drawable.btn_write_file_selected);
			}
			for(SNSBoardFileData data : m_arrAttachMedia)
			{
				m_lnAttachFileTotalSize += data.m_lnFileSize;
				if(data.m_strFileType.equals(StaticString.FILE_TYPE_IMAGE)){
					ImageButton btnAlbum = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_album);
					btnAlbum.setImageResource(R.drawable.btn_write_photo_selected);
					ImageButton btnAlbum2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_album);
					btnAlbum2.setImageResource(R.drawable.btn_write_photo_selected);
					nImageCount++;
				} else if(data.m_strFileType.equals(StaticString.FILE_TYPE_VIDEO)) {
					ImageButton btnVod = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_vod);
					btnVod.setImageResource(R.drawable.btn_write_movie_selected);
					ImageButton btnVod2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_vod);
					btnVod2.setImageResource(R.drawable.btn_write_movie_selected);
					nVideoCount++;
				}
			}

			if(m_arrAttachFile.size() == 0){
				ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_file);
				btnFile.setImageResource(R.drawable.btn_btn_write_file);
				ImageButton btnFile2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_file);
				btnFile2.setImageResource(R.drawable.btn_btn_write_file);
			}
			//if(m_arrAttachMedia.size() == 0){
			if(nImageCount == 0) {
				ImageButton btnAlbum = (ImageButton) findViewById(R.id.btn_snsboardwrite_regular_attachmenu_album);
				btnAlbum.setImageResource(R.drawable.btn_btn_write_photo);
				ImageButton btnAlbum2 = (ImageButton) findViewById(R.id.btn_snsboardwrite_partner_attachmenu_album);
				btnAlbum2.setImageResource(R.drawable.btn_btn_write_photo);
			}
			if(nVideoCount == 0) {
				ImageButton btnVod = (ImageButton) findViewById(R.id.btn_snsboardwrite_regular_attachmenu_vod);
				btnVod.setImageResource(R.drawable.btn_btn_write_movie);
				ImageButton btnVod2 = (ImageButton) findViewById(R.id.btn_snsboardwrite_partner_attachmenu_vod);
				btnVod2.setImageResource(R.drawable.btn_btn_write_movie);
			}
			//}

			float fTotalFileSize = Utils.bytesToMegabyteFloat(m_lnAttachFileTotalSize);
			if(fTotalFileSize == 0.0)
				fTotalFileSize = 0.1F;
			
			String strFileTotalSize = String.format(getString(R.string.snsboardwrite_attachsize), fTotalFileSize);
			String strFileTotalCount = String.format(getString(R.string.snsboardwrite_attachtotal),getAttachCount());
			TextView tvTotalSize = (TextView)findViewById(R.id.tv_snsboardwrite_attachtotalsize);
			TextView tvTotalCount = (TextView)findViewById(R.id.tv_snsboardwrite_attachtotalcount);
			tvTotalCount.setText(strFileTotalCount);
			tvTotalSize.setText(strFileTotalSize);
			
			ListView lvAttachFileList = (ListView)findViewById(R.id.lv_snsboardwrite_attachlist);
			if(m_adapterAttachFileList == null)
			{
				m_adapterAttachFileList = new AttachFileListAdapter();
				lvAttachFileList.setAdapter(m_adapterAttachFileList);
			}
			else
				m_adapterAttachFileList.notifyDataSetChanged();
		}
		else
		{
			if(m_arrAttachFile.size() == 0){
				ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_file);
				btnFile.setImageResource(R.drawable.btn_btn_write_file);
				ImageButton btnFile2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_file);
				btnFile2.setImageResource(R.drawable.btn_btn_write_file);
			}
			if(m_arrAttachMedia.size() == 0){
				ImageButton btnAlbum = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_album);
				btnAlbum.setImageResource(R.drawable.btn_btn_write_photo);
				ImageButton btnAlbum2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_album);
				btnAlbum2.setImageResource(R.drawable.btn_btn_write_photo);
				ImageButton btnVod = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_vod);
				btnVod.setImageResource(R.drawable.btn_btn_write_movie);
				ImageButton btnVod2 = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_vod);
				btnVod2.setImageResource(R.drawable.btn_btn_write_movie);
			}

			EditText etComment = (EditText)findViewById(R.id.et_snsboardwrite_comment);
			if(etComment.getText().toString().length() > 0)
				setSaveButtonEnable(true);
			else
				setSaveButtonEnable(false);
			
			m_adapterAttachFileList = null;
			layoutAttach.setVisibility(View.GONE);
		}

		//기존 코드를 활용하다 보니 들어가게 됨
		//이미지, 파일등이 첨부 되어 있냐 아니냐에 따라 아이콘이 변경 되는데,
		//Multitenancy에 따라 비활성화를 시켜 줘야 하므로 여기서 마지막으로 다시 처리
		if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
		{

			ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_file);
			ImageButton btnCamera = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_camera);
			ImageButton btnAlbum = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_album);
			ImageButton btnVod = (ImageButton)findViewById(R.id.btn_snsboardwrite_regular_attachmenu_vod);

			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageSharingEnabled) {
				btnAlbum.setImageResource(R.drawable.btn_write_photo_disabled);
				btnVod.setImageResource(R.drawable.btn_write_movie_disabled);
				btnCamera.setImageResource(R.drawable.btn_write_camera_disabled);
			}
			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileSharingEnabled) {
				btnFile.setImageResource(R.drawable.btn_write_file_disabled);
			}
		}
		else
		{
			ImageButton btnFile = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_file);
			ImageButton btnCamera = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_camera);
			ImageButton btnAlbum = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_album);
			ImageButton btnVod = (ImageButton)findViewById(R.id.btn_snsboardwrite_partner_attachmenu_vod);

			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageSharingEnabled) {
				btnAlbum.setImageResource(R.drawable.btn_write_photo_disabled);
				btnVod.setImageResource(R.drawable.btn_write_movie_disabled);
				btnCamera.setImageResource(R.drawable.btn_write_camera_disabled);
			}
			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileSharingEnabled) {
				btnFile.setImageResource(R.drawable.btn_write_file_disabled);
			}
		}
	}
	
	private int getAttachCount()
	{
		int nAttachFileCount = m_arrAttachFile == null ? 0 : m_arrAttachFile.size();
		int nAttachMediaCount = m_arrAttachMedia == null ? 0 : m_arrAttachMedia.size();
		
		return nAttachFileCount + nAttachMediaCount;
	}
	
	private int getAbleAttachFileCount()
	{
		return ATTACH_FILE_MAX_COUNT - getAttachCount();
	}
	
	private long getAbleAttachFileMaxSize()
	{
		return ATTACH_FILE_MAX_SIZE - m_lnAttachFileTotalSize;
	}
	
	private void showAttachFileList()
	{
		LinearLayout layoutAttach = (LinearLayout)findViewById(R.id.layout_snsboardwrite_attach);
		if(getAttachCount() > 0)
			layoutAttach.setVisibility(View.VISIBLE);
		else
			layoutAttach.setVisibility(View.GONE);
			
	}
	
	private void hideAttachFileList()
	{
		LinearLayout layoutAttach = (LinearLayout)findViewById(R.id.layout_snsboardwrite_attach);
		layoutAttach.setVisibility(View.GONE);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.btn_snsboardwrite_save)
		{
			saveBoard();
		}
		else if(nId == R.id.btn_snsboardwrite_regular_attachmenu_file || nId == R.id.btn_snsboardwrite_partner_attachmenu_file)
		{
			// Attach File
			if(getAttachCount() == ATTACH_FILE_MAX_COUNT)
			{
				showAlertAttachMaxCountPopup();
			}
			else
			{
				Intent multiSelector = new Intent(this,FileMultiSelectorAct.class);
				multiSelector.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILECOUNT, getAbleAttachFileCount());
				multiSelector.putExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_ABLEFILEMAXSIZE, getAbleAttachFileMaxSize());
				startActivityForResult(multiSelector,TakeMediaIntent.REQUESTCODE_FILE);
			}
		}
		else if(nId == R.id.btn_snsboardwrite_regular_attachmenu_album || nId == R.id.btn_snsboardwrite_partner_attachmenu_album)
		{
			// Attach Album Image
			if(getAttachCount() == ATTACH_FILE_MAX_COUNT)
			{
				showAlertAttachMaxCountPopup();
			}
			else
			{
				m_TakeMedia = new TakeMediaIntent(this);
				m_TakeMedia.doGetMultiSelectImageFromGallery(GalleryMultiselectorListAct.FROMACTIVITY_SNS, getAbleAttachFileCount(), getAbleAttachFileMaxSize());
			}
		}
		else if(nId == R.id.btn_snsboardwrite_regular_attachmenu_camera || nId == R.id.btn_snsboardwrite_partner_attachmenu_camera)
		{
			// Attach Camera Image
			if(getAttachCount() == ATTACH_FILE_MAX_COUNT)
			{
				showAlertAttachMaxCountPopup();
			}
			else
			{
				m_TakeMedia = new TakeMediaIntent(this);
				m_TakeMedia.doTakeImageFromCamera();
			}
		}
		else if(nId == R.id.btn_snsboardwrite_regular_attachmenu_vod || nId == R.id.btn_snsboardwrite_partner_attachmenu_vod)
		{
			// Attach Vod
			if(getAttachCount() == ATTACH_FILE_MAX_COUNT)
			{
				showAlertAttachMaxCountPopup();
			}
			else
			{
				m_TakeMedia = new TakeMediaIntent(this);
				m_TakeMedia.doGetMultiSelectVideoFromGallery(getAbleAttachFileCount(), getAbleAttachFileMaxSize());
			}
		}
		super.onClick(v);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM) {
				// Album에서 Image 선택후 Crop 실행
				SelectImageProcessTask task = new SelectImageProcessTask();
				task.execute(data);
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CAMERA) {
				// 카메라 촬영후 Crop 실행
//				m_TakeMedia.doCropImageFromCameraWithAspect();
				m_TakeMedia.scaleCameraImage();
				SNSBoardFileData snsFileData = new SNSBoardFileData();
				snsFileData.m_strFileType = StaticString.FILE_TYPE_IMAGE;
				snsFileData.m_strFileURL = m_TakeMedia.getCropImageFilePath();
				File file = new File(snsFileData.m_strFileURL);
				snsFileData.m_lnFileSize = file.length(); 
				
				m_arrAttachMedia.add(snsFileData);
				setAttachFileUI();
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				// Crop이 완료된 이미지를 가져옴
//				m_TakeMedia.scaleCropImage();
//				SNSBoardFileData snsFileData = new SNSBoardFileData();
//				snsFileData.m_strFileType = StaticString.FILE_TYPE_IMAGE;
//				snsFileData.m_strFileURL = m_TakeMedia.getCropImageFilePath();
//				File file = new File(snsFileData.m_strFileURL);
//				snsFileData.m_lnFileSize = file.length(); 
//				
//				m_arrAttachMedia.add(snsFileData);
//				setAttachFileUI();
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_VIDEO) {
				// Video 가져옴
				Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
				ArrayList<GalleryListData> arrAttachVod = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);

				if(arrAttachVod != null && arrAttachVod.size() > 0)
				{
					for(GalleryListData galleryListData : arrAttachVod)
					{
						SNSBoardFileData snsFileData = new SNSBoardFileData();
						snsFileData.m_strFileType = StaticString.FILE_TYPE_VIDEO;
						snsFileData.m_strFileURL = galleryListData.getSdcardPath();
						snsFileData.m_lnFileSize = galleryListData.m_lnSize;

						m_arrAttachMedia.add(snsFileData);
					}
					setAttachFileUI();
				}
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_FILE){
				if(data.hasExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST))
				{
					ArrayList<Parcelable> parcelList = data.getParcelableArrayListExtra(IntentKeyString.INTENT_KEY_FILEMULTISELECTOR_FILELIST);
					if(parcelList != null)
					{
						ArrayList<FileInfo> arrAttachFile = (ArrayList<FileInfo>)parcelList.clone();
						for(FileInfo fileData : arrAttachFile)
						{
							SNSBoardFileData snsFileData = new SNSBoardFileData();
							snsFileData.m_strFileName = fileData.m_strName;
							snsFileData.m_strFileURL = fileData.m_strPath;
							snsFileData.m_lnFileSize = fileData.m_lnSize;
							snsFileData.m_strFileType = SNSBoardFileData.FILETYPE_ETC;
							
							m_arrAttachFile.add(snsFileData);
						}
						setAttachFileUI();
					}
				}
			}

		} else {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM || requestCode == TakeMediaIntent.REQUESTCODE_CAMERA
					|| requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				// 취소등에 의한 후처리 필요
				m_TakeMedia.deleteDirectory();
				m_TakeMedia = null;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
	private void saveBoard()
	{
		EditText etComment = (EditText)findViewById(R.id.et_snsboardwrite_comment);
		String strComment = etComment.getText().toString();

		if(strComment.trim().equals("")){
			strComment = "";
		}
		
		boolean isFile = (getAttachCount()) > 0;
		String strThreadType = "";
		if(isFile){
			strThreadType = PostGroupBoardReq.CHANNEL_THREAD_TYPE_FILE;
		} else {
			strThreadType = PostGroupBoardReq.CHANNEL_THREAD_TYPE_NORMAL;
		}
		PostGroupBoardReq req = new PostGroupBoardReq(m_nGroupId, strComment, strThreadType);

		/*if(AppSetting.FEATURE_VARIANT.equals("R") && arrCloudFileData.size() > 0)
		{
			req.setCloudFile(arrCloudFileData);
		}*/

		
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress("");
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				int nBoardId;
				
				PostGroupBoardRes res = new PostGroupBoardRes(a_strData);
				nBoardId = res.getThreadNo();
				
				if((getAttachCount()) > 0)
				{
					uploadAttachFile(nBoardId);
				}
				else
				{
					closeProgress();
					setResult(RESULT_OK);
					finish();
				}
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardWriteAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);

			}
		});
		
	}
	
	private void uploadAttachFile(int a_nBoardId)
	{
		PostGroupBoardFileUploadReq req = new PostGroupBoardFileUploadReq(m_nGroupId, a_nBoardId);
		
		if(m_arrAttachFile != null)
		{
			for(SNSBoardFileData data : m_arrAttachFile)
			{
				req.addFileInfo(this, data.m_strFileName, data.m_strFileURL);
			}
		}
		
		if(m_arrAttachMedia != null)
		{
			for(SNSBoardFileData data : m_arrAttachMedia)
			{
				if(data.m_strFileType.equals(StaticString.FILE_TYPE_IMAGE))
				{
					req.addImageFileInfo(this, data.m_strFileURL);
				}
				else if(data.m_strFileType.equals(StaticString.FILE_TYPE_VIDEO))
				{
					req.addVodFileInfo(this, data.m_strFileURL);
				}
			}
		}
		
		WebAPI api = new WebAPI(this);
		api.requestUpload(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e(getClass(), "uploadAttachFile Success");
				closeProgress();
				setResult(RESULT_OK);
				finish();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				CommonLog.e(getClass(), "uploadAttachFile Fail... " + strMessage);

				closeProgress();
				setResult(RESULT_OK);
				finish();

			}
		});
	}
	
	private void showAlertAttachMaxCountPopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_sns_attach_maxcount));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
	
	private class AttachFileListAdapter extends BaseAdapter
	{
		private final int VIEWTYPE_FILE = 0;
		private final int VIEWTYPE_MEDIA = 1;
		private final int VIEWTYPE_MAX = 2;
		
		@Override
		public int getViewTypeCount() {
			// TODO Auto-generated method stub
			return VIEWTYPE_MAX;
		}
		
		@Override
		public int getItemViewType(int position) {
			// TODO Auto-generated method stub
			int nCount = getCount();
			
			if(m_arrAttachMedia != null && m_arrAttachMedia.size() > 0)
			{
				if(nCount == (position + 1)){
					return VIEWTYPE_MEDIA;
				}
				else {
					return VIEWTYPE_FILE;
				}
			}
			else
				return VIEWTYPE_FILE;
			
		}
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nCount = m_arrAttachFile == null ? 0 : m_arrAttachFile.size();
			if(m_arrAttachMedia != null && m_arrAttachMedia.size() > 0)
				nCount++;
			return nCount;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;
			int nViewType = getItemViewType(nPosition);
			if(convertView == null)
			{
				LayoutInflater li = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
				if(nViewType == VIEWTYPE_FILE)
					convertView = li.inflate(R.layout.layout_snsboardwrite_listitem_attach_file, parent, false);
				else
					convertView = li.inflate(R.layout.layout_snsboardwrite_listitem_attach_media, parent, false);
			}
			
			if(nViewType == VIEWTYPE_FILE)
			{
				TextView tvFileName = (TextView)convertView.findViewById(R.id.tv_snsboardwrite_listitem_attach_file_filename);
				SharedPref pref = SharedPref.getInstance(SNSBoardWriteAct.this);
				int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
				if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
					tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f);
				} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
					tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16.9f);
				} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
					tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20.8f);
				}
				tvFileName.setText(m_arrAttachFile.get(nPosition).m_strFileName);
				
				Button btnDelete = (Button)convertView.findViewById(R.id.btn_snsboardwrite_listitem_attach_file_delete);
				btnDelete.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						showAttachDeletePopup(ATTACH_DELETE_TYPE_FILE, nPosition);
					}
				});
			}
			else
			{
				LayoutInflater li = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
				final LinearLayout layoutMediaList = (LinearLayout)convertView.findViewById(R.id.layout_snsboardwrite_listitem_attach_media);
//				int nChildViewCount = layoutMediaList.getChildCount();
				int nChildViewCount = getLastMediaCount();
				//if(nChildViewCount != m_arrAttachMedia.size())
				//{
					layoutMediaList.removeAllViews();
					int nMediaListSize = m_arrAttachMedia.size();
					for(int i = 0; i < nMediaListSize; i++)
					{
						final int nIndex = i;
						final SNSBoardFileData data = m_arrAttachMedia.get(i);
						View vItem = li.inflate(R.layout.layout_snsboardwrite_listitem_attach_media_item, layoutMediaList, false);
						ImageView ivImg = (ImageView)vItem.findViewById(R.id.iv_snsboardwrite_listitem_attach_media_img);
						ImageView ivFrame = (ImageView)vItem.findViewById(R.id.iv_snsboardwrite_listitem_attach_media_frame);

						int a_nDeleteType = -1;

						if(data.m_strFileType.equals(StaticString.FILE_TYPE_IMAGE))
						{
							a_nDeleteType = ATTACH_DELETE_TYPE_IMAGE;
							Bitmap thumb = m_mapThumbnail.get(data.m_strFileURL);
							
							if(thumb == null)
							{
								Bitmap bm = BitmapFactory.decodeFile(data.m_strFileURL);
								thumb = Utils.makeThumbnail(bm, 250, 250);
								m_mapThumbnail.put(data.m_strFileURL, thumb);
							}
							ivImg.setImageBitmap(thumb);
							ivFrame.setBackgroundResource(R.drawable.file_pic_frame);
						}
						else
						{
							a_nDeleteType = ATTACH_DELETE_TYPE_MEDIA;
							Bitmap thumb = m_mapThumbnail.get(data.m_strFileURL);
							if(thumb == null)
							{
								thumb = Utils.getMiniThumbnailFromVideo(SNSBoardWriteAct.this, data.m_strFileURL);
								m_mapThumbnail.put(data.m_strFileURL, thumb);
							}

							ivImg.setImageBitmap(thumb);
							ivFrame.setBackgroundResource(R.drawable.icon_movie_s);
						}

						final int a_nFinalDeleteType = a_nDeleteType;
						vItem.setOnClickListener(new OnClickListener() {
							
							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								showAttachDeletePopup(a_nFinalDeleteType, nIndex);
							}
						});
						layoutMediaList.addView(vItem);
					}
					setLastMediaCount(nMediaListSize);
				//}
			}
			return convertView;
		}
		
		private int m_nLastMediaCount = 0;
		private int getLastMediaCount()
		{
			return m_nLastMediaCount;
		}
		
		private void setLastMediaCount(int a_nCount)
		{
			m_nLastMediaCount = a_nCount;
		}
		
		private final int ATTACH_DELETE_TYPE_FILE = 0;
		private final int ATTACH_DELETE_TYPE_MEDIA = 1;
		private final int ATTACH_DELETE_TYPE_IMAGE = 2;
		private void showAttachDeletePopup(final int a_nType, final int a_nPosition)
		{
			//파일일 때
			if(a_nType == ATTACH_DELETE_TYPE_FILE){
				m_Popup = new CommonPopup(SNSBoardWriteAct.this, new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						int nId = v.getId();
						if(nId == R.id.ib_pop_ok)
						{
							m_arrAttachFile.remove(a_nPosition);
							setAttachFileUI();
						}
						CommonPopup popup = (CommonPopup)v.getTag();
						popup.cancel();
						popup.dismiss();
					}
				}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_attach_delete_title), getString(R.string.cork_pop_clear_file));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else if(a_nType == ATTACH_DELETE_TYPE_MEDIA){
				m_Popup = new CommonPopup(SNSBoardWriteAct.this, new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						int nId = v.getId();
						if(nId == R.id.ib_pop_ok)
						{
							SNSBoardFileData data = m_arrAttachMedia.remove(a_nPosition);
							m_mapThumbnail.remove(data.m_strFileURL);
							if(m_arrAttachMedia.size() == 0){
								setLastMediaCount(m_arrAttachMedia.size());
							}
							setAttachFileUI();
						}
						CommonPopup popup = (CommonPopup)v.getTag();
						popup.cancel();
						popup.dismiss();
					}
				}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_attach_delete_title), getString(R.string.cork_pop_clear_vod));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_Popup = new CommonPopup(SNSBoardWriteAct.this, new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						int nId = v.getId();
						if(nId == R.id.ib_pop_ok)
						{
							SNSBoardFileData data = m_arrAttachMedia.remove(a_nPosition);
							m_mapThumbnail.remove(data.m_strFileURL);
							if(m_arrAttachMedia.size() == 0){
								setLastMediaCount(m_arrAttachMedia.size());
							}
							setAttachFileUI();
						}
						CommonPopup popup = (CommonPopup)v.getTag();
						popup.cancel();
						popup.dismiss();
					}
				}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_attach_delete_title), getString(R.string.cork_pop_clear_img));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
		}
	}
	
	private class SelectImageProcessTask extends AsyncTask<Intent, Void, Boolean>
	{
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			showProgress();
			super.onPreExecute();
		}
		
		@Override
		protected Boolean doInBackground(Intent... params) {
			// TODO Auto-generated method stub
			Intent data = params[0];
			Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
			ArrayList<GalleryListData> arrAttachImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);
			
			if(arrAttachImage != null && arrAttachImage.size() > 0)
			{
				String strScaleSaveDirectory = getFilesDir().getAbsolutePath();
				for(GalleryListData galleryListData : arrAttachImage)
				{
					
					String strImagePath = galleryListData.getSdcardPath();
					ScaleImage scaleImage = new ScaleImage();
					scaleImage.scaleImage(strImagePath, strScaleSaveDirectory);
					
					SNSBoardFileData snsFileData = new SNSBoardFileData();
					snsFileData.m_strFileType = StaticString.FILE_TYPE_IMAGE;
					snsFileData.m_strFileURL = scaleImage.getSavedScaleImagePath();
					snsFileData.m_lnFileSize = scaleImage.getSavedScaleImageSize();
					m_arrAttachMedia.add(snsFileData);
				}
				return true;
			}
			else
				return false;
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			setAttachFileUI();
			closeProgress();
			super.onPostExecute(result);
		}
	}
}
