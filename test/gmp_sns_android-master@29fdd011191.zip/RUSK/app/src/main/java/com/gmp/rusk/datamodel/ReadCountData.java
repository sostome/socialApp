package com.gmp.rusk.datamodel;

public class ReadCountData {
	
	public String m_strMessageId = "";
	public int m_nCount = 0;
}
