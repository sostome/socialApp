package com.gmp.rusk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatInviteTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.DepartmentsData;
import com.gmp.rusk.datamodel.NavigationInfoData;
import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserSearchListData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.ChatroomAllUserListItemLayout;
import com.gmp.rusk.layout.SNSInviteRegularListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetDepartmentReq;
import com.gmp.rusk.request.PostSearchUserReq;
import com.gmp.rusk.response.GetDepartmentRes;
import com.gmp.rusk.response.PostSearchUserRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;

/**
 * Created by kang on 2017-05-10.
 */

public class ChatRoomSearchListFlag extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener, CompoundButton.OnCheckedChangeListener, View.OnTouchListener {

    public MyApp App = MyApp.getInstance();
    private FragmentActivity m_Activity = null;

    ArrayList<NavigationInfoData> m_arrNavigationInfoDatas = null;
    ArrayList<DepartmentsData> m_arrDepartmentsDatas = null;
    ArrayList<DepartmentUserListData> m_arrDepartmentUserListDatas = null;

    private AddedByUserListAdapter m_AddedByUserAdapter = null;
    View m_vOrganChart;
    ArrayAdapter<String> adspin;
    String m_strCurrentSelTeamCode = "";
    ArrayList<String> m_arrSKTTeamList = null;
    ArrayList<String> m_arrSKTTeamCodeList = null;
    private RelativeLayout layout_organchart = null;
    private RelativeLayout layout_organregular = null;

    private LinearLayout layout_organchartlist_list = null;
    private ListView m_lvorganRegularList = null;
    // private SectionListAdapter m_SectionListAdapter = null;
    // private ArrayList<SectionListItem> m_SectionListItems = null; //
    // SectionListView
    // 에 넣는 Item
    // 생성

    private static int SEARCH_NAME = 0;
    private static int SEARCH_TEAM = 1;

    private int m_nSearchType = 0;
    private int m_nPage = 1;

    EditText et_search_keyword;
    TextView tv_nolist;
    ImageButton ib_cancel;

    TextView m_tvSectionText;
    TextView m_tvSectionTextOrgan;
    CheckBox m_cbAllcheck;
    CheckBox m_cbAllcheckOrgan;

    Spinner spn_search_type;
    TextView tv_hint;
    HorizontalScrollView m_hsvOrgMenu;
    RelativeLayout m_layoutSection;
    RelativeLayout layout_hinttext, layout_nolist;
    RelativeLayout m_LayoutDepartmentsList;
    private ProgressDlg m_Progress = null;
    private CommonPopup m_Popup = null;
    TextView tv_spinner_text;
    private InputMethodManager imm;
    public boolean m_isRunning = false;
    ArrayList<UserSearchListData> m_arrUserSearchListDatas;

    // 사용자가 눌러서 터치를 한것인지, 앱에서 판단해서 체크하는지
    boolean m_isTouchCheckBox = false;

    ArrayList<Integer> m_arrUserNumbers;
    boolean m_isFirstView = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        m_Activity = getActivity();
        imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        App.m_arrSearchListCheckData = new ArrayList<SearchListCheckData>();
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        m_isRunning = false;
    }

    @Override
    public void onStop() {
        // TODO Auto-generated method stub
        super.onStop();
        m_isRunning = false;
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        if(m_AddedByUserAdapter != null)
            m_AddedByUserAdapter.notifyDataSetChanged();

        super.onResume();
        m_isRunning = true;
    }

    @Override
    public void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        if (imm != null && et_search_keyword != null)
            imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        ((ChatInviteTabAct) m_Activity).setNotifyListener(m_NotifyListner);
       /* m_arrUserNumbers = ((SNSGroupMemeberInviteAct) m_Activity).getUserNumbers();*/
        m_vOrganChart = inflater.inflate(R.layout.fragact_sns_organization_chart, container, false);

        layout_organchart = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organchart);
        layout_organregular = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organregular);

        m_LayoutDepartmentsList = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_departments_list);

      /*if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
         requestDepartment(App.m_EntryData.m_strDepartmentCode);
      } else {*/
        initSearchOrganChart();
   /* }*/
        initSearchBar();
        return m_vOrganChart;
    }

    private void initSearchBar() {
        tv_hint = (TextView) m_vOrganChart.findViewById(R.id.tv_hinttext);
        tv_hint.setText(getString(R.string.addbyregularlist_hinttext));
        m_arrSKTTeamList = new ArrayList<>();
        m_arrSKTTeamCodeList = new ArrayList<>();
        if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)) {
            for (int i = 0; i < App.m_EntryData.m_arrCompanyData.size(); i++) {
                if (App.m_EntryData.m_strCompanyCode.equals(App.m_EntryData.m_arrCompanyData.get(i).strCode)) {
                    m_arrSKTTeamList.add(0, getString(R.string.search_my_company) + " " + App.m_EntryData.m_arrCompanyData.get(i).strName);
                    m_arrSKTTeamCodeList.add(0, App.m_EntryData.m_arrCompanyData.get(i).strCode);
                } else {
                    m_arrSKTTeamList.add(App.m_EntryData.m_arrCompanyData.get(i).strName);
                    m_arrSKTTeamCodeList.add(App.m_EntryData.m_arrCompanyData.get(i).strCode);
                }
            }
            m_arrSKTTeamList.add(1, getString(R.string.search_all));
            m_arrSKTTeamCodeList.add(1, PostSearchUserReq.SEARCH_ALL);
        } else {
            m_arrSKTTeamList.add(0, getString(R.string.search_all));
            m_arrSKTTeamCodeList.add(0, PostSearchUserReq.SEARCH_ALL);
            if(App.m_EntryData.m_MultiTenancy.isPartnerRegularSearchEnabled){
                m_arrSKTTeamList.add(1, App.m_EntryData.m_strCompanyName);
                m_arrSKTTeamCodeList.add(1, App.m_EntryData.m_strCompanyCode);
            }
        }
        adspin = new ArrayAdapter<String>(m_Activity,R.layout.layout_spinner_textview,m_arrSKTTeamList);
        tv_spinner_text = (TextView) m_vOrganChart.findViewById(R.id.tv_spinner_text);
        spn_search_type = (Spinner) m_vOrganChart.findViewById(R.id.spn_search_type);
        adspin.setDropDownViewResource(R.layout.spinner_custom_list_item);
        spn_search_type.setAdapter(adspin);
        spn_search_type.setOnItemSelectedListener(this);

        et_search_keyword = (EditText) m_vOrganChart.findViewById(R.id.et_search_keyword);
        m_tvSectionTextOrgan = (TextView) m_vOrganChart.findViewById(R.id.tv_sectiontext_organ);

        ib_cancel = (ImageButton) m_vOrganChart.findViewById(R.id.ib_cancel);
        ib_cancel.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                et_search_keyword.setText("");
            /*if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
               m_LayoutOrgMenu01.setVisibility(View.GONE);
               m_LayoutOrgMenu02.setVisibility(View.GONE);
               m_LayoutOrgMenu03.setVisibility(View.GONE);
               m_LayoutOrgMenu04.setVisibility(View.GONE);
               m_LayoutOrgMenu05.setVisibility(View.GONE);
               m_LayoutOrgMenu06.setVisibility(View.GONE);
               m_LayoutOrgMenu07.setVisibility(View.GONE);
               m_LayoutOrgMenu08.setVisibility(View.GONE);
               m_LayoutOrgMenu09.setVisibility(View.GONE);
               m_LayoutOrgMenu10.setVisibility(View.GONE);
            }
            if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
               requestDepartment(App.m_EntryData.m_strDepartmentCode);
            } else {*/
                initSearchOrganChart();
            /*}*/
            }
        });

        et_search_keyword.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // TODO Auto-generated method stub
                CommonLog.e("EditAction", "actionId1 : " + actionId);

                switch (actionId) {
                    case EditorInfo.IME_ACTION_SEARCH:
                        if (v.getText().toString().trim().length() > 1) {
                            if (!Utils.UseChar(v.getText().toString())) {
                                m_Popup = new CommonPopup(m_Activity, ChatRoomSearchListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                                m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.regular_expression_search)
                                        .toString());
                                m_Popup.setCancelable(false);
                                isCheckShowPopup();
                                return false;
                            }
                                requestAddedByName(v.getText().toString());

                        } else {
                            m_Popup = new CommonPopup(m_Activity, ChatRoomSearchListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                            m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.popup_search_length).toString());
                            m_Popup.setCancelable(false);
                            isCheckShowPopup();
                        }
                        break;
                }
                return false;
            }
        });

        et_search_keyword.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // TODO Auto-generated method stub
                if (s.toString().length() > 0) {
                    ib_cancel.setVisibility(View.VISIBLE);
                } else {
                    ib_cancel.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }
        });

    }

    private void initSearchOrganChart() {
        m_cbAllcheck = (CheckBox) m_vOrganChart.findViewById(R.id.cb_sns_allmember);

        layout_organchart.setVisibility(View.GONE);
        layout_organregular.setVisibility(View.VISIBLE);
        m_LayoutDepartmentsList.setVisibility(View.GONE);

        layout_organchartlist_list = (LinearLayout) m_vOrganChart.findViewById(R.id.layout_organ_regular_list);
        m_lvorganRegularList = (ListView) m_vOrganChart.findViewById(R.id.lv_organ_regular_list);
        layout_organchartlist_list.setVisibility(View.GONE);
        m_layoutSection = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_section);
        m_tvSectionText = (TextView) m_vOrganChart.findViewById(R.id.tv_sectiontext);
        layout_hinttext = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_hinttext);
        layout_hinttext.setVisibility(View.VISIBLE);
        layout_nolist = (RelativeLayout)m_vOrganChart.findViewById(R.id.layout_no_list);
        layout_nolist.setVisibility(View.GONE);
        m_cbAllcheck.setOnCheckedChangeListener(this);
        m_cbAllcheck.setOnTouchListener(this);
        m_cbAllcheck.setChecked(false);

    }

    private void setUserSearchApdapter() {
        initSearchOrganChart();
        m_lvorganRegularList.setVisibility(View.VISIBLE);
        layout_organchartlist_list.setVisibility(View.VISIBLE);

        if (m_arrUserSearchListDatas != null) {
            layout_hinttext.setVisibility(View.GONE);
            layout_nolist.setVisibility(View.GONE);
            m_layoutSection.setVisibility(View.VISIBLE);
            m_tvSectionText.setText(getString(R.string.layout_sectionstring_search_result) +" " + m_arrUserSearchListDatas.size());
        } else {
            m_layoutSection.setVisibility(View.GONE);
            layout_hinttext.setVisibility(View.GONE);
            layout_nolist.setVisibility(View.VISIBLE);
            if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_PARTNER)){
                RelativeLayout textLayout = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organization_nolisttext_regular);
                textLayout.setVisibility(View.GONE);
            }
        }
        m_AddedByUserAdapter = new AddedByUserListAdapter();
        m_AddedByUserAdapter.areAllItemsEnabled();
        m_lvorganRegularList.setAdapter(m_AddedByUserAdapter);
    }

    private class AddedByUserListAdapter extends BaseAdapter {
        @Override
        public void notifyDataSetChanged() {
            // TODO Auto-generated method stub

            super.notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            if (m_arrUserSearchListDatas != null)
                return m_arrUserSearchListDatas.size();

            return 0;
        }

        @Override
        public Object getItem(int position) {

            if (m_arrUserSearchListDatas != null)
                return m_arrUserSearchListDatas.get(position);

            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int nPosition = position;
            UserSearchListData data = m_arrUserSearchListDatas.get(nPosition);

            // convertView null 시 새로 생성하자
            if (convertView == null)
                convertView = new ChatroomAllUserListItemLayout(m_Activity);

            ((ChatroomAllUserListItemLayout) convertView).setUserSearchListData(data);
            ((ChatroomAllUserListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);
            CheckBox cb_redaction = (CheckBox) ((ChatroomAllUserListItemLayout) convertView).findViewById(R.id.cb_invite);
            ImageView ivSelected = (ImageView) ((ChatroomAllUserListItemLayout) convertView).findViewById(R.id.iv_invite_selected);

            int nUserNumber;
            boolean isActive;
            if (data.m_isRegular) {
                RegularSearchListData regularSearchListData = (RegularSearchListData) data.m_UserData;
                nUserNumber = regularSearchListData.m_nUserNo;
                isActive = regularSearchListData.m_isAvailable;
            } else {
                PartnerSearchListData partnerSearchListData = (PartnerSearchListData) data.m_UserData;
                nUserNumber = partnerSearchListData.m_nUserNo;
                isActive = partnerSearchListData.m_isAvailable;
            }

            if (App.m_arrRoomUserList!=null&& App.m_arrRoomUserList.contains(nUserNumber) || nUserNumber == App.m_MyUserInfo.m_nUserNo) {

                cb_redaction.setVisibility(View.INVISIBLE);
                ivSelected.setVisibility(View.VISIBLE);
            } else {
                cb_redaction.setVisibility(View.VISIBLE);
                ivSelected.setVisibility(View.INVISIBLE);
            }
            if(!isActive){
                cb_redaction.setVisibility(View.INVISIBLE);
                ivSelected.setVisibility(View.INVISIBLE);
            }

            if (cb_redaction.getVisibility() != View.INVISIBLE) {
                boolean is_redaction = false;
                ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;

                for (int i = 0; i < arrSearchListCheckData.size(); i++) {
                    if (nUserNumber == arrSearchListCheckData.get(i).m_nUserNo) {
                        is_redaction = true;
                        cb_redaction.setChecked(true);
                        break;
                    }
                }
                if (!is_redaction) {
                    cb_redaction.setChecked(false);
                }
            }
            return convertView;
        }

    }

    ChatInviteTabAct.OnNotifyListener m_NotifyListner = new ChatInviteTabAct.OnNotifyListener() {

        @Override
        public void onNotify() {
            // TODO Auto-generated method stub

            if(m_AddedByUserAdapter != null){
                m_AddedByUserAdapter.notifyDataSetChanged();
                m_cbAllcheck.setChecked(false);
            }
        }
    };

    ChatroomAllUserListItemLayout.OnCheckedChangedListener m_CheckedChangedListner = new ChatroomAllUserListItemLayout.OnCheckedChangedListener() {

        @Override
        public void onChecked(boolean a_isChecked, int a_nUserId) {
            // TODO Auto-generated method stub
            if (a_isChecked) {
                boolean isSame = false;
                if (App.m_arrSearchListCheckData != null) {
                    for (int i = 0; i < m_arrUserSearchListDatas.size(); i++) {
                        for (SearchListCheckData data : App.m_arrSearchListCheckData) {
                            int nUserNumber;
                            boolean isActive;
                            if (m_arrUserSearchListDatas.get(i).m_isRegular) {
                                RegularSearchListData regularSearchListData = (RegularSearchListData) m_arrUserSearchListDatas.get(i).m_UserData;
                                nUserNumber = regularSearchListData.m_nUserNo;
                                isActive = regularSearchListData.m_isAvailable;
                            } else {
                                PartnerSearchListData partnerSearchListData = (PartnerSearchListData) m_arrUserSearchListDatas.get(i).m_UserData;
                                nUserNumber = partnerSearchListData.m_nUserNo;
                                isActive = partnerSearchListData.m_isAvailable;
                            }
                            if (data.m_nUserNo == nUserNumber) {
                                isSame = true;
                                break;
                            } else if (App.m_arrRoomUserList!=null&&App.m_arrRoomUserList.contains(nUserNumber)) {
                                isSame = true;
                                break;
                            } else if(!isActive){
                                isSame = true;
                                break;
                            }
                            else {
                                isSame = false;
                            }

                        }
                        if (!isSame) {
                            break;
                        }
                    }
                }
                if (isSame) {
                    m_cbAllcheck.setChecked(true);
                } else {
                    m_cbAllcheck.setChecked(false);
                }
            } else {

                m_cbAllcheck.setChecked(false);
            }
        }

        @Override
        public void onDataSetChagnged() {
            // TODO Auto-generated method stub
            // if (m_SearchFellowListAdapter != null)
            // m_SearchFellowListAdapter.notifyDataSetChanged();
            // if (m_FellowListAdapter != null)
            // m_FellowListAdapter.notifyDataSetChanged();
        }
    };

    SNSInviteRegularListItemLayout.OnCheckedChangedListener m_CheckedChangedRegularListner = new SNSInviteRegularListItemLayout.OnCheckedChangedListener() {

        @Override
        public void onChecked(boolean a_isChecked, int a_nUserId) {
            // TODO Auto-generated method stub
            if (a_isChecked) {
                boolean isSame = false;
                if (App.m_arrSearchListCheckData != null) {
                    for (int i = 0; i < App.m_arrRegularSearchListDatas.size(); i++) {
                        for (SearchListCheckData data : App.m_arrSearchListCheckData) {

                            if (data.m_nUserNo == App.m_arrRegularSearchListDatas.get(i).m_nUserNo) {
                                isSame = true;
                                break;
                            } /*else if (m_arrUserNumbers.contains(App.m_arrRegularSearchListDatas.get(i).m_nUserNo)) {
                                isSame = true;
                                break;
                            }*/ else if (!App.m_arrRegularSearchListDatas.get(i).m_isAvailable) {
                                isSame = true;
                                break;
                            }
                            else {
                                isSame = false;
                            }

                        }
                        if (!isSame) {
                            break;
                        }
                    }
                }
                if (isSame) {
                    m_cbAllcheck.setChecked(true);
                } else {
                    m_cbAllcheck.setChecked(false);
                }
            } else {

                m_cbAllcheck.setChecked(false);
            }
        }

        @Override
        public void onDataSetChagnged() {
            // TODO Auto-generated method stub
            // if (m_SearchFellowListAdapter != null)
            // m_SearchFellowListAdapter.notifyDataSetChanged();
            // if (m_FellowListAdapter != null)
            // m_FellowListAdapter.notifyDataSetChanged();
        }
    };

    ChatroomAllUserListItemLayout.OnCheckedChangedListener m_CheckedChangedOrganListner = new ChatroomAllUserListItemLayout.OnCheckedChangedListener() {

        @Override
        public void onChecked(boolean a_isChecked, int a_nUserId) {
            // TODO Auto-generated method stub
            if (a_isChecked) {
                boolean isSame = false;
                if (App.m_arrSearchListCheckData != null) {
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {
                        for (SearchListCheckData data : App.m_arrSearchListCheckData) {

                            if (data.m_nUserNo == m_arrDepartmentUserListDatas.get(i).getUserNo()) {
                                isSame = true;
                                break;
                            } /*else if (m_arrUserNumbers.contains(m_arrDepartmentUserListDatas.get(i).getUserNo())) {
                                isSame = true;
                                break;
                            }*/ else if (!m_arrDepartmentUserListDatas.get(i).getAvailable()){
                                isSame = true;
                                break;
                            }
                            else {
                                isSame = false;
                            }

                        }
                        if (!isSame) {
                            break;
                        }
                    }
                }
                if (isSame) {
                    m_cbAllcheckOrgan.setChecked(true);
                } else {
                    m_cbAllcheckOrgan.setChecked(false);
                }
            } else {

                m_cbAllcheckOrgan.setChecked(false);
            }
        }

        @Override
        public void onDataSetChagnged() {
            // TODO Auto-generated method stub
            // if (m_SearchFellowListAdapter != null)
            // m_SearchFellowListAdapter.notifyDataSetChanged();
            // if (m_FellowListAdapter != null)
            // m_FellowListAdapter.notifyDataSetChanged();
        }
    };

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        // TODO Auto-generated method stub
        if (buttonView.getId() == R.id.cb_sns_allmember) {
      /* if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
            if (m_isTouchCheckBox) {
               if (isChecked) {
                  for (int i = 0; i < App.m_arrRegularSearchListDatas.size(); i++) {

                     if (!m_arrUserNumbers.contains(App.m_arrRegularSearchListDatas.get(i).m_nUserNo)) {
                        SearchListCheckData addData = new SearchListCheckData(App.m_arrRegularSearchListDatas.get(i).m_nUserNo,
                              App.m_arrRegularSearchListDatas.get(i).m_strName);
                        if(App.m_arrRegularSearchListDatas.get(i).m_isAvailable) {
                           ((SNSGroupMemeberInviteAct) m_Activity).addSearchList(addData);
                        }
                     }

                  }
               } else {
                  for (int i = 0; i < App.m_arrRegularSearchListDatas.size(); i++) {

                     ((SNSGroupMemeberInviteAct) m_Activity).removeListData(App.m_arrRegularSearchListDatas.get(i).m_nUserNo);

                  }
               }
               m_isTouchCheckBox = false;
               if (m_AddedByRegularAdapter != null)
                  m_AddedByRegularAdapter.notifyDataSetChanged();

            }
         } else {*/
            if (m_isTouchCheckBox) {
                if (isChecked) {
                    int nCheckList = 0;
                    for (int i = 0; i < m_arrUserSearchListDatas.size(); i++) {

                        int nUserNumber;
                        String strUserName;
                        boolean isActive;
                        if (m_arrUserSearchListDatas.get(i).m_isRegular) {
                            RegularSearchListData regularSearchListData = (RegularSearchListData) m_arrUserSearchListDatas.get(i).m_UserData;
                            nUserNumber = regularSearchListData.m_nUserNo;
                            strUserName = regularSearchListData.m_strName;
                            isActive = regularSearchListData.m_isAvailable;
                        } else {
                            PartnerSearchListData partnerSearchListData = (PartnerSearchListData) m_arrUserSearchListDatas.get(i).m_UserData;
                            nUserNumber = partnerSearchListData.m_nUserNo;
                            strUserName = partnerSearchListData.m_strName;
                            isActive = partnerSearchListData.m_isAvailable;
                        }
                        if (App.m_arrRoomUserList!=null&&!App.m_arrRoomUserList.contains(nUserNumber)) {
                            SearchListCheckData addData = new SearchListCheckData(nUserNumber, strUserName);
                            if(isActive) {
                                ((ChatInviteTabAct) m_Activity).addSearchList(addData);
                                nCheckList++;
                            }
                        }

                    }
                    if(nCheckList == 0){
                        m_isTouchCheckBox = false;
                        m_cbAllcheck.setChecked(false);
                    }
                } else {
                    for (int i = 0; i < m_arrUserSearchListDatas.size(); i++) {
                        int nUserNumber;
                        if (m_arrUserSearchListDatas.get(i).m_isRegular) {
                            RegularSearchListData regularSearchListData = (RegularSearchListData) m_arrUserSearchListDatas.get(i).m_UserData;
                            nUserNumber = regularSearchListData.m_nUserNo;
                        } else {
                            PartnerSearchListData partnerSearchListData = (PartnerSearchListData) m_arrUserSearchListDatas.get(i).m_UserData;
                            nUserNumber = partnerSearchListData.m_nUserNo;
                        }
                        ((ChatInviteTabAct) m_Activity).removeListData(nUserNumber);

                    }
                }
                m_isTouchCheckBox = false;
                if (m_AddedByUserAdapter != null)
                    m_AddedByUserAdapter.notifyDataSetChanged();

            }
         /*}*/
        } else if (buttonView.getId() == R.id.cb_sns_allmember_organ) {

            if (m_isTouchCheckBox) {
                if (isChecked) {
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {

                      /*  if (!m_arrUserNumbers.contains(m_arrDepartmentUserListDatas.get(i).getUserNo())) {
                            SearchListCheckData addData = new SearchListCheckData(m_arrDepartmentUserListDatas.get(i).getUserNo(),
                                    m_arrDepartmentUserListDatas.get(i).getName());
                            if(m_arrDepartmentUserListDatas.get(i).getAvailable()) {
                                ((SNSGroupMemeberInviteAct) m_Activity).addSearchList(addData);
                            }
                        }*/

                    }
                } else {
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {

                        ((ChatInviteTabAct) m_Activity).removeListData(m_arrDepartmentUserListDatas.get(i).getUserNo());

                    }
                }
                m_isTouchCheckBox = false;
            }
        }

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.cb_sns_allmember) {
            m_isTouchCheckBox = true;
        } else if (v.getId() == R.id.cb_sns_allmember_organ) {
            m_isTouchCheckBox = true;
        }
        return false;
    }

    private void requestAddedByName(String a_strKeyword) {
        showProgress(getString(R.string.progress_search));
        PostSearchUserReq req = new PostSearchUserReq(a_strKeyword,m_strCurrentSelTeamCode); // 이름검색

        WebAPI webApi = new WebAPI(m_Activity);
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub
            }

            @Override
            public void onPostRequest(String strData) {
                // TODO Auto-generated method stub
                PostSearchUserRes res = new PostSearchUserRes(strData);
                res.parseData();

                m_arrUserSearchListDatas = null;
                if (res.getUserSearchListData() != null) {
                    m_arrUserSearchListDatas = res.getUserSearchListData();
                } else {
                }

                closeProgress();
                setUserSearchApdapter();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((ChatInviteTabAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
            }
        });

    }

   /* private void requestAddedByGroup(String a_strKeyword) {
        showProgress(getString(R.string.progress_search));
        PostSearchUserReq req = new PostSearchUserReq(a_strKeyword, 1, PostSearchUserReq.TYPE_GROUP); // 이름검색

        WebAPI webApi = new WebAPI(m_Activity);
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub
            }

            @Override
            public void onPostRequest(String strData) {
                // TODO Auto-generated method stub
                PostSearchUserRes res = new PostSearchUserRes(strData);
                res.parseData();

                m_arrUserSearchListDatas = null;
                if (res.getUserSearchListData() != null) {
                    m_arrUserSearchListDatas = res.getUserSearchListData();
                } else {
                    Toast.makeText(m_Activity, getString(R.string.layout_sectionstring_search_noresult), Toast.LENGTH_SHORT).show();
                }

                closeProgress();
                setUserSearchApdapter();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((ChatInviteTabAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
//          if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//                   PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          } else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE || a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//                   PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          } else {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          }
            }
        });

    }*/

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        tv_spinner_text.setText(m_arrSKTTeamList.get(position));
        m_strCurrentSelTeamCode = m_arrSKTTeamCodeList.get(position);

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub

    }

    public void showProgress() {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Activity);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void showProgress(String a_strMsg) {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Activity, a_strMsg);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void closeProgress() {
        if (m_Progress != null && m_Progress.isShowing())
            m_Progress.cancel();
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.ib_pop_ok_long) {
            CommonPopup popup_ok_long = (CommonPopup)v.getTag();
            if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
                popup_ok_long.cancel();
                App.expirePartnerLogin(m_Activity);
            } else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
                popup_ok_long.cancel();
                App.initPartnerLogin(m_Activity);
            } else {
                popup_ok_long.cancel();
            }
        }
    }

    private void isCheckShowPopup() {
        if (m_isRunning) {
            m_Popup.show();
        }
    }
}
