package com.gmp.rusk.extension;

import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.datamodel.ChatRoomListData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.utils.CommonLog;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

import java.util.ArrayList;

/**
 * Created by kang on 2017-06-16.
 */

public class GroupChatsEx extends IQ {
    public final static String NAMESPACE = "jabber:iq:groupchats";
//	private final String NAMESPACE_Q = "<query xmlns=\"jabber:iq:rooms\">";

    private ArrayList<ChattingRoomInfoData> nodes;
    private String namespace = null;

    public GroupChatsEx() {
    }

    public GroupChatsEx(String namespace, ArrayList<ChattingRoomInfoData> nodes) {
        this.namespace = namespace;
        this.nodes = nodes;
    }


    @Override
    public String getChildElementXML() {
        StringBuilder buf = new StringBuilder();
//		buf.append(NAMESPACE_Q);
//		if (namespace != null) {
//			buf.append("<user>").append(namespace).append("</user>");
//		}
//		buf.append("</query>");
        return buf.toString();
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getNamespace() {
        return namespace;
    }

    public ArrayList<ChattingRoomInfoData> getNodes(){
        return this.nodes;
    }

    public static class Provider implements IQProvider {

        @Override
        public IQ parseIQ(XmlPullParser parser) throws Exception {
            // TODO Auto-generated method stub
            String namespace = null;
            ArrayList<ChattingRoomInfoData> nodes = new ArrayList<>();
            boolean done = false;
            while (!done) {
                int eventType = parser.next();
                if (eventType == XmlPullParser.START_TAG) {
                    if (parser.getName().equals("node")) {
                        ChattingRoomInfoData data = new ChattingRoomInfoData();
                        int count = parser.getAttributeCount();
                        for(int i = 0 ; i<count ; i++){
                            if(parser.getAttributeName(i).equals("name")){
                                data.m_strRoomTitle = parser.getAttributeValue(i);
                            } else if(parser.getAttributeName(i).equals("image")){
                                data.m_strCoverImagUrl = parser.getAttributeValue(i);
                            }
                        }
                        data.m_strRoomId = parser.nextText();
                        nodes.add(data);

                    }
                } else if (eventType == XmlPullParser.END_TAG) {
                    if (parser.getName().equals("query")) {
                        namespace = parser.getNamespace();
                        done = true;

                    }
                }
            }
            return new GroupChatsEx(namespace, nodes);
        }

    }

}