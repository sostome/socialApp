package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.ReadCountData;
import com.gmp.rusk.utils.CommonLog;

public class PostReadCountRes extends Res{
	
	private final String JSON_READCOUNTLIST			= "messages";
	private final String JSON_MESSAGEID				= "messageId";
	private final String JSON_COUNT					= "count";
	
	private ArrayList<ReadCountData> m_arrReadCountData = new ArrayList<ReadCountData>();
	
	public PostReadCountRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			JSONArray jsonReadCountList = jsonRoot.getJSONArray(JSON_READCOUNTLIST);
			int nReadCountSize = jsonReadCountList.length();
			for(int i = 0; i < nReadCountSize; i++)
			{
				ReadCountData data = new ReadCountData();
				JSONObject jsonReadCount = jsonReadCountList.getJSONObject(i);
				data.m_strMessageId = jsonReadCount.getString(JSON_MESSAGEID);
				data.m_nCount = jsonReadCount.getInt(JSON_COUNT);
				
				m_arrReadCountData.add(data);
			}
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	public ArrayList<ReadCountData> getReadCountList()
	{
		return m_arrReadCountData;
	}
}
