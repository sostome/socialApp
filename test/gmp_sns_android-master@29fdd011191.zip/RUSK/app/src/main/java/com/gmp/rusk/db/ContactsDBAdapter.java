package com.gmp.rusk.db;

import java.util.ArrayList;

import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.google.gson.Gson;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class ContactsDBAdapter {
	
	// Database File Name
	private static final String DATABASE_NAME 		= "ttalk_contacts.db";
	
	// Contacts Table Name
	private static final String TABLE_CONTACTS 		= "Contacts";
	
	// Contacts Table Field Name
	public static final String KEY_CONTACTS_USERID				= "userId";				// User Id
	public static final String KEY_CONTACTS_PERSONAL			= "personal";
	public static final String KEY_CONTACTS_USERTYPE			= "userType";			// 사용자 유형 R:정직원 P:파트너
	public static final String KEY_CONTACTS_HASTHUMB			= "hasThumb";			// Thumbnail 유/무
	public static final String KEY_CONTACTS_ISAPPINSTALLED		= "isAppInstalled";		// Application 설치 유/무
	public static final String KEY_CONTACTS_USERSTATUS			= "userStatus";			// 사용자 상태(A:정상, W:탈퇴, C:승인취소파트너)
	public static final String KEY_CONTACTS_ISFELLOW			= "isFellow";			// 동료 추가 여부
	public static final String KEY_CONTACTS_FELLOWADDTIME		= "fellowAddTime";		// 동료 추가 시간
	public static final String KEY_CONTACTS_GREETING			= "greeting";			// 동료 추가 시간
	
	
	// Create Table Query
	private final String CONTACTS_CREATE = "create table " + TABLE_CONTACTS + " (" + 
												KEY_CONTACTS_USERID 			+ " integer primary key, " +
												KEY_CONTACTS_PERSONAL			+ " text not null, " +
												KEY_CONTACTS_USERTYPE			+ " text not null, " +
												KEY_CONTACTS_HASTHUMB			+ " integer not null, " +
												KEY_CONTACTS_ISAPPINSTALLED 	+ " integer not null, " +
												KEY_CONTACTS_USERSTATUS			+ " text not null, "	+
												KEY_CONTACTS_ISFELLOW		 	+ " integer not null, " +
												KEY_CONTACTS_GREETING 			+ " text, " +
												KEY_CONTACTS_FELLOWADDTIME		+ " text);";
	
	// Drop Table Query 
	private final String CONTACTS_DROP = "DROP TABLE IF EXISTS " + TABLE_CONTACTS;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private ContactsDBHelper m_dbHelper = null;
	
	public ContactsDBAdapter(Context context)
	{
		m_context = context;
		m_dbHelper = new ContactsDBHelper(m_context, DATABASE_NAME, null, DatabaseDefine.DATABASE_VERSION);
	}
	
	// Database Open Read & Write Permission
	public ContactsDBAdapter open() throws SQLException
	{
		m_db = m_dbHelper.getWritableDatabase();
		return this;
	}
	
	// Database Open Read Permission
	public ContactsDBAdapter openReadOnly() throws SQLException
	{
		m_db = m_dbHelper.getReadableDatabase();
		return this;
	}
	
	// Database Close
	public void close()
	{
		m_db.close();
	}
	
	/**
	 * insertContacts
	 * 주소록 Array 추가 Query
	 * @param a_arrUserListData	UserListData ArrayList : 추가할 주소록 ArrayList
	 * @return int insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertContacts(ArrayList<UserListData> a_arrUserListData)
	{
		int nCount = 0;
		
		if(a_arrUserListData == null || a_arrUserListData.size() == 0)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			for(UserListData data : a_arrUserListData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_CONTACTS_USERID, data.m_nUserNo);
				Gson gson = new Gson();
				String strPersonalData = gson.toJson(data.m_PersonalData.mapPersonalData);
				LocalAesCrypto crypto = new LocalAesCrypto();
				value.put(KEY_CONTACTS_PERSONAL, crypto.encrypt(strPersonalData));
				value.put(KEY_CONTACTS_USERTYPE, data.m_strUserType);
				if(data.m_isImageAvailable)
					value.put(KEY_CONTACTS_HASTHUMB, 1);
				else
					value.put(KEY_CONTACTS_HASTHUMB, 0);
				if(data.m_isActive)
					value.put(KEY_CONTACTS_ISAPPINSTALLED, 1);
				else
					value.put(KEY_CONTACTS_ISAPPINSTALLED, 0);

				value.put(KEY_CONTACTS_USERSTATUS, data.m_strUserStatus);

				if(data.m_isFellow)
					value.put(KEY_CONTACTS_ISFELLOW, 1);
				else
					value.put(KEY_CONTACTS_ISFELLOW, 0);

				value.put(KEY_CONTACTS_FELLOWADDTIME, data.m_strFellowAddTime);
				value.put(KEY_CONTACTS_GREETING, data.m_strGreeting);
				m_db.insert(TABLE_CONTACTS, null, value);
				nCount++;
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * insertContacts 
	 * 주소록 단일 추가 Insert Query
	 * @param a_userListData UserListData : 추가할 UserListData 
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertContacts(UserListData a_userListData)
	{
		int nCount = 0;
		
		if(a_userListData == null)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_CONTACTS_USERID, a_userListData.m_nUserNo);
			Gson gson = new Gson();
			String strPersonalData = gson.toJson(a_userListData.m_PersonalData.mapPersonalData);
			LocalAesCrypto crypto = new LocalAesCrypto();
			value.put(KEY_CONTACTS_PERSONAL, crypto.encrypt(strPersonalData));
			value.put(KEY_CONTACTS_USERTYPE, a_userListData.m_strUserType);
			if(a_userListData.m_isImageAvailable)
				value.put(KEY_CONTACTS_HASTHUMB, 1);
			else
				value.put(KEY_CONTACTS_HASTHUMB, 0);
			if(a_userListData.m_isActive)
				value.put(KEY_CONTACTS_ISAPPINSTALLED, 1);
			else
				value.put(KEY_CONTACTS_ISAPPINSTALLED, 0);
				
			value.put(KEY_CONTACTS_USERSTATUS, a_userListData.m_strUserStatus);
			
			if(a_userListData.m_isFellow)
				value.put(KEY_CONTACTS_ISFELLOW, 1);
			else
				value.put(KEY_CONTACTS_ISFELLOW, 0);
			
			value.put(KEY_CONTACTS_FELLOWADDTIME, a_userListData.m_strFellowAddTime);
			value.put(KEY_CONTACTS_GREETING, a_userListData.m_strGreeting);
			m_db.insert(TABLE_CONTACTS, null, value);
			
			nCount++;
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateContacts
	 * 주소록 Array Update Query 
	 * UserListData.m_nUserNo로 비교하여 Update를 수행
	 * @param a_userListData UserListData ArrayList : Update 할 UserListData의 ArrayList
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateContacts(ArrayList<UserListData> a_arrUserListData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			for(UserListData data : a_arrUserListData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_CONTACTS_USERTYPE, data.m_strUserType);
				if(data.m_isImageAvailable)
					value.put(KEY_CONTACTS_HASTHUMB, 1);		//
				else
					value.put(KEY_CONTACTS_HASTHUMB, 0);
				if(data.m_isActive)
					value.put(KEY_CONTACTS_ISAPPINSTALLED, 1);
				else
					value.put(KEY_CONTACTS_ISAPPINSTALLED, 0);
					
				value.put(KEY_CONTACTS_USERSTATUS, data.m_strUserStatus);
				
				if(data.m_isFellow)
					value.put(KEY_CONTACTS_ISFELLOW, 1);
				else
					value.put(KEY_CONTACTS_ISFELLOW, 0);
				
				value.put(KEY_CONTACTS_FELLOWADDTIME, data.m_strFellowAddTime);
				value.put(KEY_CONTACTS_GREETING, data.m_strGreeting);
				
				nCount = m_db.update(TABLE_CONTACTS, value, KEY_CONTACTS_USERID + "=" + data.m_nUserNo, null);
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateContacts
	 * 주소록 단일 Update Query 
	 * UserListData.m_nUserNo로 비교하여 Update를 수행
	 * @param a_userListData UserListData : Update 할 UserListData
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateContacts(UserListData a_userListData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_CONTACTS_USERTYPE, a_userListData.m_strUserType);
			if(a_userListData.m_isImageAvailable)
				value.put(KEY_CONTACTS_HASTHUMB, 1);		//
			else
				value.put(KEY_CONTACTS_HASTHUMB, 0);
			if(a_userListData.m_isActive)
				value.put(KEY_CONTACTS_ISAPPINSTALLED, 1);
			else
				value.put(KEY_CONTACTS_ISAPPINSTALLED, 0);
				
			value.put(KEY_CONTACTS_USERSTATUS, a_userListData.m_strUserStatus);
			
			if(a_userListData.m_isFellow)
				value.put(KEY_CONTACTS_ISFELLOW, 1);
			else
				value.put(KEY_CONTACTS_ISFELLOW, 0);
			
			value.put(KEY_CONTACTS_FELLOWADDTIME, a_userListData.m_strFellowAddTime);
			value.put(KEY_CONTACTS_GREETING, a_userListData.m_strGreeting);
			
			nCount += m_db.update(TABLE_CONTACTS, value, KEY_CONTACTS_USERID + "=" + a_userListData.m_nUserNo, null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateContacts
	 * 주소록 단일 Update Query isFellow 만 Update 
	 * a_nUserNo로 비교하여 Update를 수행
	 * @param a_nUserNo Update 할 UserNo
	 * @param a_isFellow Update 할 Fellow Field 값
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateContacts(int a_nUserNo, boolean a_isFellow)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			if(a_isFellow)
				value.put(KEY_CONTACTS_ISFELLOW, 1);
			else
				value.put(KEY_CONTACTS_ISFELLOW, 0);
						
			nCount += m_db.update(TABLE_CONTACTS, value, KEY_CONTACTS_USERID + "=" + a_nUserNo, null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	} 
	
	/**
	 * deleteContacts
	 * 주소록 전체 삭제
	 * @return int 삭제한 개수
	 */
	public int deleteContacts()
	{
		return m_db.delete(TABLE_CONTACTS, null, null);
	}
	
	/**
	 * deleteContacts
	 * 주소록 단일 삭제
	 * @param a_nUserId 삭제할 UserId
	 * @return int 삭제한 개수
	 */
	public int deleteContacts(int a_nUserId)
	{
		return m_db.delete(TABLE_CONTACTS, KEY_CONTACTS_USERID + "=" + a_nUserId, null);
	}
	
	/**
	 * getContactsList
	 * 주소록 가져오기
	 * @return DB Cursor
	 */
	public Cursor getContactsList()
	{
		return m_db.query(TABLE_CONTACTS, null, null, null, null, null, null);
	}
	
	public Cursor getContacts(int a_nUserId)
	{
		return m_db.query(TABLE_CONTACTS, null, KEY_CONTACTS_USERID + "=" + a_nUserId, null, null, null, null);
	}
	
	public Cursor getContactsByFellowList()
	{
		return m_db.query(TABLE_CONTACTS, null, KEY_CONTACTS_ISFELLOW + "=" + 1, null, null, null, null);
	}
		
	// SQLite Open Helper Class
	private class ContactsDBHelper extends SQLiteOpenHelper
	{

		public ContactsDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(CONTACTS_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			db.execSQL(CONTACTS_DROP);
			onCreate(db);
		}
	}
}
