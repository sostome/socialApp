package com.gmp.rusk.act;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.layout.SNSUserListItemLayout;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteGroupUserKickReq;
import com.gmp.rusk.request.GetGroupUserReq;
import com.gmp.rusk.request.PutGroupUserReq;
import com.gmp.rusk.response.GetGroupUserRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * ChatRoomExitOtherAct
 * 
 * @author kch 강퇴 Activity
 */
public class SNSExitOtherAct extends CustomActivity{

	ArrayList<UserListData> m_arrUserListDatas = null;
	ArrayList<Boolean> m_arrIsCheck;
	UserListAdapter m_UserListAdapter;
	ArrayList<Integer> m_arrUserNo;
	ImageView m_btnComplete;
	private ListView m_lvUserList = null;
	
	ArrayList<Integer> m_arrExitUser;
	CommonPopup m_Popup;

	int m_nGroupId;
	ArrayList<SNSGroupMemberData> m_arrInvitedMember = new ArrayList<SNSGroupMemberData>();
	TextView m_tvTitle;
	TextView m_TvSection;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatroom_menu_exit_other);

		m_arrIsCheck = new ArrayList<Boolean>();
		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_nGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID);
		}

		init();
		getGroupMemberList();
		

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {

			Intent intent = new Intent();

			setResult(RESULT_CANCELED, intent);
			finish();
		}
		return super.onKeyDown(keyCode, event);

	}

	private void init(){
		ImageView btnTopClose = (ImageView)findViewById(R.id.btn_top_close);
		btnTopClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		m_tvTitle = (TextView) findViewById(R.id.tv_exitother_title);
		m_TvSection = (TextView) findViewById(R.id.tv_section_name);
		m_btnComplete = (ImageView) findViewById(R.id.btn_complete);
		m_lvUserList = (ListView) findViewById(R.id.lv_chat_member_list);
		m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
		m_btnComplete.setOnClickListener(null);
		
		RelativeLayout layout_nolisttext;
		layout_nolisttext = (RelativeLayout) findViewById(R.id.layout_hinttext);
		layout_nolisttext.setVisibility(View.GONE);
	}
	
	private void initOrganChartUI() {

		m_TvSection.setText(String.format(getString(R.string.snsgroupexitother_section_name)+" "+m_arrUserListDatas.size()));
		
		if (m_arrUserListDatas != null) {
			
			m_UserListAdapter = new UserListAdapter();
			m_lvUserList.setAdapter(m_UserListAdapter);
		}	
		
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		if(m_UserListAdapter != null)
			m_UserListAdapter.notifyDataSetChanged();
		super.onResume();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		switch (v.getId()) {
		case R.id.btn_complete:
//			boolean isNoExit = true;
//			for (int i = 0; i < m_arrIsCheck.size(); i++) {
//				if (m_arrIsCheck.get(i)) {
//					isNoExit = false;
//				}
//			}
//			if (isNoExit) {
//				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//				m_Popup.setBodyAndTitleText(getString(R.string.popup_exit_other_title), getString(R.string.popup_exit_other_no_select));
//				m_Popup.setCancelable(false);
//				isCheckShowPopup();
//			} else {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getString(R.string.snsgroupexit_popup_title), getString(R.string.snsgroupexit_popup_text));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
//			}
			break;
		case R.id.ib_pop_ok:
			
			for (int i = 0; i < m_arrIsCheck.size(); i++) {
				if (m_arrIsCheck.get(i)) {
					m_arrExitUser.add(m_arrUserNo.get(i));
					CommonLog.e(this, "KickUser : " + m_arrUserNo.get(i));
				}
			}


			DeleteGroupUserKickReq req = new DeleteGroupUserKickReq(m_nGroupId, m_arrExitUser);
			WebAPI api = new WebAPI(this);
			api.request(req, new WebListener() {
				
				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub
					
				}
				
				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub
					/*ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(SNSExitOtherAct.this);
					for(int i = 0; i < arrRoomData.size(); i++){
						if(arrRoomData.get(i).m_strRoomId.split("\\_").length == 3){
							if(arrRoomData.get(i).m_strRoomId.split("\\_")[2].equals(Integer.toString(m_nGroupId))){
								mService.exitOther(m_arrExitUser, arrRoomData.get(i).m_strRoomId);
								break;
							}
						}
					}*/
					Intent intent = new Intent();

					setResult(RESULT_OK, intent);
					finish();
				}
				
				@Override
				public void onNetworkError(int nErrorCode, String strMessage) {
					// TODO Auto-generated method stub
					//Toast.makeText(SNSExitOtherAct.this, "Exit Other Fail : " + strMessage, Toast.LENGTH_SHORT).show();
					showErrorPopup(nErrorCode, strMessage);
				}
			});
			
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			popup_ok.cancel();
			break;
		case R.id.ib_pop_cancel:
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			break;
		case R.id.ib_pop_ok_long:
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			break;
		default:
			break;
		}
	}

	public void setCheckBoxPosition(int nPosition, boolean isCheck) {
		m_arrIsCheck.set(nPosition, isCheck);
		boolean isNoCheck = true;
		int nCheckCount = 0;
		for(int i = 0; i < m_arrIsCheck.size(); i++){
			if(m_arrIsCheck.get(i)){
				isNoCheck = false;
				nCheckCount++;
			} 
		}
		if(isNoCheck){
			m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
			m_btnComplete.setOnClickListener(null);
			m_tvTitle.setText(getString(R.string.snsgroupexitother_title_nocheck));
		} else {
			m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);
			m_btnComplete.setOnClickListener(this);
			m_tvTitle.setText(String.format(getString(R.string.snsgroupexitother_title), nCheckCount));
		}
	}

	public boolean getCheckBoxPosition(int nPosition) {
		return m_arrIsCheck.get(nPosition);
	}

	private class UserListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nUserListDataSize = 0;

			if (m_arrUserListDatas != null)
				nUserListDataSize = m_arrUserListDatas.size();

			return nUserListDataSize;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_arrUserListDatas != null && position < m_arrUserListDatas.size())
				return m_arrUserListDatas.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			UserListData userData;

			if (nPosition < m_arrUserListDatas.size()) {
				userData = (UserListData) m_arrUserListDatas.get(nPosition);
				// convertView null 시 새로 생성하자
				if (convertView == null)
					convertView = new SNSUserListItemLayout(SNSExitOtherAct.this, SNSUserListItemLayout.CHATROOM_ITEM_TYPE_EXIT);
				((SNSUserListItemLayout) convertView).setPosition(nPosition);
				((SNSUserListItemLayout) convertView).setUserListData(userData);
			}

			return convertView;
		}
	}

	private void getGroupMemberList()
	{
		GetGroupUserReq req = new GetGroupUserReq(m_nGroupId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetGroupUserRes res = new GetGroupUserRes(a_strData);
				m_arrInvitedMember = res.getGroupMemberList();
				m_arrUserListDatas = new ArrayList<UserListData>();
				m_arrUserNo = new ArrayList<Integer>();
				for(int j = 0; j < m_arrInvitedMember.size(); j++){
					m_arrUserNo.add(m_arrInvitedMember.get(j).m_nUserNo);
				}
				for (int nUserNo : m_arrUserNo) {
						UserListData userListData = ContactsDBManager.getContacts(SNSExitOtherAct.this, nUserNo);
						if(userListData != null)
						{
							if(nUserNo == App.m_MyUserInfo.m_nUserNo){
								m_arrUserListDatas.add(0,userListData);
							}else {
								m_arrUserListDatas.add(userListData);
							}
							m_arrIsCheck.add(false);
						}
				}

				m_arrExitUser = new ArrayList<Integer>();

				initOrganChartUI();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				//Toast.makeText(SNSExitOtherAct.this, "Group Member List Fail : " + strMessage, Toast.LENGTH_SHORT).show();
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}
	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
