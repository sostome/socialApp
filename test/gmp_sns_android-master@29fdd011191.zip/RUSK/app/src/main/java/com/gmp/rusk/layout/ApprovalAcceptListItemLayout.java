package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;


import com.gmp.rusk.R;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.datamodel.ApprovalAcceptListData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * ApprovalAcceptListItemLayout
 * 승인 완료 List Item Layout
 */
public class ApprovalAcceptListItemLayout extends CustomLinearLayout implements OnClickListener{
	
	Button ib_reApproval;
	Button ib_out;
	Context m_Context;
	
	
	private OnApprovalAcceptListener m_ApprovalAcceptListener = null;
	private ApprovalAcceptListData m_ApprovalAcceptListData = null;
	
	public ApprovalAcceptListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public ApprovalAcceptListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context a_context)
	{
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listitem_approval_accept, this);
		
	}
	
	public void setApprovalAcceptListData(ApprovalAcceptListData a_Data)
	{	
		m_ApprovalAcceptListData = a_Data;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		ImageView iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
		ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);
		
		UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_ApprovalAcceptListData.m_nUserNo);
		
		if(userData != null && userData.m_isImageAvailable)
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_ApprovalAcceptListData.m_nUserNo, true), R.drawable.profile_pic_default, false);
		}
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}

		iv_notfellow_pic.setVisibility(View.GONE);

		TextView tv_name = (TextView)findViewById(R.id.tv_name);
		//if(m_ApprovalAcceptListData.m_strName.length() > 4 && m_ApprovalAcceptListData.m_isExpiresoon){
		//	tv_name.setText(m_ApprovalAcceptListData.m_strName.substring(0,4) + "...");
		//} else
			tv_name.setText(m_ApprovalAcceptListData.m_strName);

		TextView tv_mobile = (TextView)findViewById(R.id.tv_mobile);
		LinearLayout layout_mobile = (LinearLayout)findViewById(R.id.layout_mobile);
		tv_mobile.setText(m_ApprovalAcceptListData.m_strMobile);

		ib_reApproval = (Button) findViewById(R.id.ib_reapproval);
		ib_reApproval.setOnClickListener(this);
		ib_out = (Button)findViewById(R.id.ib_out);
		ib_out.setOnClickListener(this);
		if(m_ApprovalAcceptListData.m_isExpiresoon) {
			ib_reApproval.setVisibility(View.VISIBLE);
			layout_mobile.setVisibility(View.GONE);
		} else {
			ib_reApproval.setVisibility(View.GONE);
			layout_mobile.setVisibility(View.VISIBLE);
		}
		
		TextView tv_company = (TextView)findViewById(R.id.tv_company);
		tv_company.setText(m_ApprovalAcceptListData.m_strAffiliation);


		
		RelativeLayout layout_listitem_approval_accept = (RelativeLayout)findViewById(R.id.layout_listitem_approval_accept);
    	layout_listitem_approval_accept.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()== R.id.layout_listitem_approval_accept)
		{
			doShowProfile();
		}
		else if(v.getId()== R.id.ib_out)
		{	
			m_ApprovalAcceptListener.onApprovalOut(m_ApprovalAcceptListData.m_nUserNo);
		} else if(v.getId()==R.id.ib_reapproval)
		{
			m_ApprovalAcceptListener.onReApproval(m_ApprovalAcceptListData.m_nUserNo);
		}
	}
	
	private void doShowProfile()
	{
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_ApprovalAcceptListData.m_nUserNo);
		m_Context.startActivity(intent);
	}
	
	public void setApprovalAcceptListener(OnApprovalAcceptListener a_Listener)
	{
		m_ApprovalAcceptListener = a_Listener;
	}

	public interface OnApprovalAcceptListener {
        public void onApprovalOut(int a_nApprovalPendingUserNo);
		public void onReApproval(int a_nReApprovalUserNo);
    }
}
