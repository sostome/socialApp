package com.gmp.rusk.datamodel;

public class UserPhoneNumberData {
	
	public int m_nUserNo = 0;
	public String m_strPhoneNum = "";
}
