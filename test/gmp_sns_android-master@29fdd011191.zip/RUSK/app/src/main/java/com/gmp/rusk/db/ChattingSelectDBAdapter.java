package com.gmp.rusk.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.datamodel.TiniSelectListData;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.concurrent.locks.Lock;

/**
 * Created by kang on 2017-03-02.
 */

public class ChattingSelectDBAdapter {

    public MyApp App = MyApp.getInstance();

    private static final String DATABASE_NAME               = "ttalk_chattingselect.db";

    private static final String TABLE_CHATTINGSELECT        = "ChattingSelect";

    public static final String KEY_CHATTINGSELECT_MSGID     = "msgId";
    public static final String KEY_SELECT_LIST              = "selectList";

    private final String CHATTING_SELECT_CREATE = "create table "+TABLE_CHATTINGSELECT      + " (" +
                                                    KEY_CHATTINGSELECT_MSGID                + " text not null, "+
                                                    KEY_SELECT_LIST                         + " text not null);";

    private final String CHATTINGSELECT_DROP = "DROP TABLE IF EXISTS "+ TABLE_CHATTINGSELECT;

    private SQLiteDatabase m_db = null;
    private Context m_context;
    private ChattingSelectDBHelper m_dbHelper = null;
    private Lock w_recv;

    public ChattingSelectDBAdapter(Context context){
        m_context = context;
        String strDatabaseName = DATABASE_NAME;
        m_dbHelper = new ChattingSelectDBHelper(m_context,strDatabaseName,null,DatabaseDefine.DATABASE_CHATTINGDB_VERSION);

        w_recv = App.rwl.writeLock();
    }

    public ChattingSelectDBAdapter open() throws SQLiteException{

        w_recv.lock();
        m_db = m_dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        m_db.close();
        w_recv.unlock();
    }
    public void beginTransaction(){m_db.beginTransaction();}

    public void setTransactionSuccessful(){m_db.setTransactionSuccessful();}

    public void endTransaction() {m_db.endTransaction();}

    public int insertChattingSelectMessage(String msgId, JSONArray chattingSelectList){
        int nCount = 0;

        try {

            m_db.beginTransaction();
            ContentValues values = new ContentValues();
            values.put(KEY_CHATTINGSELECT_MSGID, msgId);
            values.put(KEY_SELECT_LIST, chattingSelectList.toString());
            m_db.insert(TABLE_CHATTINGSELECT, null, values);
            nCount++;
            m_db.setTransactionSuccessful();
        }catch (Exception e){
            e.printStackTrace();
            nCount = -1;
        }finally {
            m_db.endTransaction();
        }

        return nCount;
    }

    public int deleteChattingSelect(){return m_db.delete(TABLE_CHATTINGSELECT,null,null);}

    public int deleteChattingSelect(String a_strMsgId){
        return m_db.delete(TABLE_CHATTINGSELECT,KEY_CHATTINGSELECT_MSGID +"=\"" +a_strMsgId + "\"",null);
    }

    public Cursor getChattingSelect(){
        return  m_db.query(TABLE_CHATTINGSELECT,null,null,null,null,null,null);
    }
    public Cursor getChattingSelect(String msgId){
        String strWhere = KEY_CHATTINGSELECT_MSGID + "=\"" +msgId+"\"";
        return m_db.query(TABLE_CHATTINGSELECT,null,strWhere,null,null,null,null);
    }

    private class ChattingSelectDBHelper extends SQLiteOpenHelper{

        ChattingSelectDBHelper(Context context, String name, CursorFactory factory, int version){
            super(context,name,factory,version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CHATTING_SELECT_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            if(oldVersion == 1 && newVersion == 2){
                ArrayList<TiniSelectListData> arrOldTiniSelectListData = getTiniSelectListFromDBVersion1(db);
                db.execSQL(CHATTINGSELECT_DROP);
                onCreate(db);
                insertChattingSelectMessageToChattingSelectDBVersion2(db,arrOldTiniSelectListData);

            }
        }
        private Cursor getTiniSelectList(SQLiteDatabase db){
            return db.query(TABLE_CHATTINGSELECT,null,null,null,null,null,null);
        }
        private ArrayList<TiniSelectListData> getTiniSelectListFromDBVersion1(SQLiteDatabase db){

            ArrayList<TiniSelectListData> arrTiniSelectListData = new ArrayList<>();

            Cursor cursor = getTiniSelectList(db);
            if(cursor.moveToFirst()){
                do{
                    String strMsgId = cursor.getString(cursor.getColumnIndex(ChattingSelectDBAdapter.KEY_CHATTINGSELECT_MSGID));
                    if (strMsgId == null || strMsgId.equals(""))
                        continue;

                    String strSelectList = cursor.getString(cursor.getColumnIndex(ChattingSelectDBAdapter.KEY_SELECT_LIST));
                    if (strSelectList == null || strSelectList.equals(""))
                        continue;

                    TiniSelectListData data = new TiniSelectListData();
                    data.m_strMsgId = strMsgId;
                    data.m_strSelectList = strSelectList;

                    arrTiniSelectListData.add(data);
                }while (cursor.moveToNext());
            }
            cursor.close();

            return arrTiniSelectListData;
        }

        private int insertChattingSelectMessageToChattingSelectDBVersion2(SQLiteDatabase db, ArrayList<TiniSelectListData> a_arrData){
            int nCount = 0;

            if(a_arrData == null || a_arrData.size() == 0)
                return 0;

            try {
                db.beginTransaction();

                for (TiniSelectListData data : a_arrData){
                    ContentValues value = new ContentValues();
                    value.put(KEY_CHATTINGSELECT_MSGID, data.m_strMsgId);
                    value.put(KEY_SELECT_LIST,data.m_strSelectList);

                    db.insert(TABLE_CHATTINGSELECT,null,value);
                    nCount++;
                }
                db.setTransactionSuccessful();
            }catch (Exception e){
                e.printStackTrace();
                nCount = -1;
            }finally {
                db.endTransaction();
            }
            return nCount;
        }

    }


}
