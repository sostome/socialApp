package com.gmp.rusk;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.util.SparseArray;

import com.gmp.rusk.utils.CommonLog;
import com.kris520.apngdrawable.ApngLoader;
import com.gmp.rusk.act.IntroAct;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.EntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.GMPData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.listview.SectionListItem;

import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.ErrorReporter;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;

import android.database.sqlite.SQLiteDatabase;

import org.acra.ACRA;
import org.acra.ReportingInteractionMode;
import org.acra.annotation.ReportsCrashes;
import org.jivesoftware.smack.XMPPConnection;

import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@ReportsCrashes(
		formKey = "",	
		mode = ReportingInteractionMode.DIALOG,
		resDialogTitle = R.string.crash_dialog_title,
		resDialogText = R.string.crash_dialog_text,
		mailTo = "kch@uangel.com"
		
		)
public class MyApp extends MultiDexApplication {

	public int m_nChatbot = 99;
	public int m_nRoomLimit = 150;
	public int m_nGroupLimit = 300;
	public String m_AppID = "Z000S01077";
	public String m_TnaAppID = "Z000ST0028";
	public String m_Mdn = "";

	public ArrayList<Activity> m_arrActivitys = null;

	public ErrorReporter errorRepoter = null;

	public String m_PartnerID = "";
	public String m_PartnerPW = "";

	public EntryData m_EntryData = null; // 로그인 정보

	public GMPData m_GMPData = null; // GMP 인증 정보

	public String m_Key = "1a2b3c4d5e6f7890";

	public ArrayList<FellowListData> m_arrFellowListData = null;
	// 조직도에서 채팅방 만들때 사용
	public ArrayList<DepartmentUserListData> m_arrDepartmentUserListData = null;
	//public ArrayList<PartnerSearchListData> m_arrPartnerSearchListData = null;

	public ArrayList<SearchListCheckData> m_arrSearchListCheckData = null;
	public FellowListData m_MyUserInfo = null;


	public XMPPConnection connection;
	// 현재 입장해 있는 방의 유저 리스트, 초대시 방에 있는 유저는 초대하지 않기 위해 사용
	public ArrayList<Integer> m_arrRoomUserList = new ArrayList<Integer>();

	public ArrayList<RegularSearchListData> m_arrRegularSearchListDatas = null;

	public ImageLoaderManager imageloader = null;

	public int m_nNewApproval = 0;
	
	public boolean m_isRoomDelete = false;

	public boolean m_isChangeFellow = false;
	
	//인트로에서 offline message로 처리된 강퇴 정보를 MainTab까지 이어가기 여의치 않아 사용
	public ArrayList<ArrayList<String>> m_arrKickRoomInfo = null;
	
	private static MyApp m_Instance = null;

	public static MyApp getInstance()
	{
		return m_Instance;
	}

	public AppStatus mAppStatus = AppStatus.FOREGROUND;

	public boolean m_isInChannelList = false;

	public boolean m_isTouchSearchTab = false;

	public ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();

	public SparseArray<UserListData> m_arrUserListData = null;

	public ArrayList<SectionListItem> m_SectionListItems = null;

	public String m_strLocale = "kr";

	//다른 앱 에서 Cork를 호출 할때 사용. intent가 너무 혼잡해서 이렇게 처리 함
	public boolean m_isOtherApp = false;

	//프로필 상세화면에서 이미지 크게 보기
	public boolean m_isProfileImageView = false;
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		m_Instance = this;
		if(AppSetting.CRASHLOG_MAIL){
			ACRA.init(this);
		}
		m_arrActivitys = new ArrayList<Activity>();

		//APNG 이미지 로더 init
		ApngLoader.init(this);


		//errorRepoter = new ErrorReporter();
		//errorRepoter.Init(getApplicationContext());
		//Thread.setDefaultUncaughtExceptionHandler(errorRepoter);


		if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
			TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);

			m_Mdn = tm.getLine1Number();
		}

		Locale systemLocale = getApplicationContext().getResources().getConfiguration().locale;
		m_strLocale = systemLocale.getLanguage();
		SharedPref pref = SharedPref.getInstance(this);

		// if(!pref.getStringPref(SharedPref.PREF_PARTNER_ID, "").equals(""))
		// {
		// CommonLog.e("","prev decript App : "+pref.getStringPref(SharedPref.PREF_PARTNER_ID,
		// ""));
		// CommonLog.e("","prev decript App : "+pref.getStringPref(SharedPref.PREF_PARTNER_PW,
		// ""));
		//
		// try {
		// CommonLog.e("","decript App : "+LocalAesCrypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_ID,
		// "")));
		// CommonLog.e("","decript App : "+LocalAesCrypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_PW,
		// "")));
		//
		// App.m_PartnerID =
		// LocalAesCrypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_ID,
		// ""));
		// App.m_PartnerPW =
		// LocalAesCrypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_PW,
		// ""));
		// } catch (Exception e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		// }
		try {
			LocalAesCrypto crypto = new LocalAesCrypto();
			m_PartnerID = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_ID, ""));
			m_PartnerPW = crypto.decrypt(pref.getStringPref(SharedPref.PREF_PARTNER_PW, ""));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		registerActivityLifecycleCallbacks(new MyActivityLifecycleCallbacks());
		initImageLoader();

	}

	/*@Override
	protected void attachBaseContext(Context base) {
		super.attachBaseContext(base);
		MultiDex.install(this);
	}
*/
	private void initImageLoader() {
		imageloader = ImageLoaderManager.getInstance(this);
	}

	public String getImageDownLoaderUrl(int a_nUserNo, boolean a_isPrev) {
		if (a_isPrev) {
			return m_EntryData.m_strPreviewImageUrlTemplate.replace(
					"{userNo}", "" + a_nUserNo).replace("{userNoModuloBy1000}", ""+a_nUserNo%1000);
		} else {
			return m_EntryData.m_strImageUrlTemplate.replace("{userNo}", ""
					+ a_nUserNo).replace("{userNoModuloBy1000}", ""+a_nUserNo%1000);
		}
	}
/*	public String getEmoticonImageDownLoaderUrl(String emoticonName){
		return
	}*/

	public void allActivityDestroy() {
		if (m_arrActivitys != null) {
			for (Activity data : m_arrActivitys)
				data.finish();
		}
	}

	public void initPartnerLogin(Context a_Context) {
		if (!AppSetting.FEATURE_VARIANT.equals("R")) {
			m_PartnerID = "";
			m_PartnerPW = "";
			m_EntryData = null; // 로그인 정보
			m_arrFellowListData = null;
			m_arrDepartmentUserListData = null;
			m_MyUserInfo = null;
			m_arrRoomUserList = null;
			m_arrRegularSearchListDatas = null;

			SharedPref pref = SharedPref.getInstance(a_Context);
			pref.deletePreferences();

			TTalkDBManager.initTTalkDB(a_Context);
			Intent intent = new Intent(a_Context, IntroAct.class);
			a_Context.startActivity(intent);
			allActivityDestroy();
		} else {
			SharedPref pref = SharedPref.getInstance(a_Context);
			pref.deletePreferences();
			TTalkDBManager.initTTalkDB(a_Context);
			allActivityDestroy();
		}

	}

	public void expirePartnerLogin(Context a_Context) {
		if (!AppSetting.FEATURE_VARIANT.equals("R")) {
			m_PartnerPW = "";

			m_EntryData = null;
			m_MyUserInfo = null;
			SharedPref pref = SharedPref.getInstance(a_Context);
			pref.setStringPref(SharedPref.PREF_PARTNER_PW, "");

			pref.setStringPref(SharedPref.PREF_COOKIE, "");
			pref.setStringPref(SharedPref.PREF_LOGIN_TIME, "0");

		}
		Intent intent = new Intent(a_Context, IntroAct.class);
		a_Context.startActivity(intent);
		allActivityDestroy();
	}
	
	public void restartApplication(Context a_Context)
	{
		m_PartnerID = "";
		m_PartnerPW = "";
		m_EntryData = null; // 로그인 정보
		m_arrFellowListData = null;
		m_arrDepartmentUserListData = null;
		//App.m_arrPartnerSearchListData = null;
		m_MyUserInfo = null;
		m_arrRoomUserList = null;
		m_arrRegularSearchListDatas = null;

		Intent intent = new Intent(a_Context, IntroAct.class);
		a_Context.startActivity(intent);
		allActivityDestroy();
	}

	public synchronized void buddyAdd(FellowListData fellowListData){
		boolean isAlreadBuddy = false;
		for(FellowListData testData : m_arrFellowListData){
			if(testData.m_nUserNo == fellowListData.m_nUserNo){
				isAlreadBuddy = true;
				break;
			}
		}
		if(!isAlreadBuddy){
			m_arrFellowListData.add(fellowListData);
		} 
	}

	// public boolean isRegularLogin(Context a_Context)
	// {
	// return AuthUtil.isLogin(a_Context, m_Mdn, m_AppID);
	// }

	public AppStatus getAppStatus(){
		return mAppStatus;
	}

	public boolean isReturnedForgroud(){
		return mAppStatus.ordinal() == AppStatus.RETURNED_TO_FOREGROUND.ordinal();
	}

	public enum AppStatus {
		BACKGROUND,
		RETURNED_TO_FOREGROUND,
		FOREGROUND;

	}
	public class MyActivityLifecycleCallbacks implements  ActivityLifecycleCallbacks {
		private int running = 0;


		@Override
		public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

		}

		@Override
		public void onActivityStarted(Activity activity) {
			if (++running == 1) {
				// running activity is 1,
				// app must be returned from background just now (or first launch)
				mAppStatus = AppStatus.RETURNED_TO_FOREGROUND;
			} else if (running > 1) {
				// 2 or more running activities,
				// should be foreground already.
				mAppStatus = AppStatus.FOREGROUND;
			}
		}

		@Override
		public void onActivityResumed(Activity activity) {

		}

		@Override
		public void onActivityPaused(Activity activity) {

		}

		@Override
		public void onActivityStopped(Activity activity) {
			if (--running == 0) {
				// no active activity
				// app goes to background
				mAppStatus = AppStatus.BACKGROUND;
			}
		}

		@Override
		public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

		}

		@Override
		public void onActivityDestroyed(Activity activity) {

		}
	}
}
