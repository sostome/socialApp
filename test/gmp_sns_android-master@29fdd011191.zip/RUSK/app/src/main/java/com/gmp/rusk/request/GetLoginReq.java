package com.gmp.rusk.request;

/**
 *	@author subi78
 *			application에 진입하기 위한 API.
 *			method : get
 */

public class GetLoginReq extends Req{
	
	private final String APINAME = "login";
	
	private String AUTHENTIFICATION = "true";
	
	private final String METHOD = "GET";
	
	
	public GetLoginReq()
	{
		
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
