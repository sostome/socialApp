package com.gmp.rusk.service;

import android.content.Context;
import android.os.Handler;
import android.os.PowerManager;


import com.gmp.rusk.R;
import com.gmp.rusk.act.PushPopupScreenOffAct;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.extension.ClearEx;
import com.gmp.rusk.extension.DelayInformationTTalk;
import com.gmp.rusk.extension.EmoticonEx;
import com.gmp.rusk.extension.FileEx;
import com.gmp.rusk.extension.PCSingleMessageEx;
import com.gmp.rusk.extension.PCSyncEx;
import com.gmp.rusk.extension.ReadEx;
import com.gmp.rusk.extension.ReceivedEx;
import com.gmp.rusk.extension.RequestEx;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.CountDownLatch;

public class XmppFilterOnlineSingle extends XmppFilterMessage{

	
	Handler mHandler;
	XMPPConnection connection;
	Context mContext;
	Long lnEditTime;
	XmppListener mXmppListener;
	
	
	public XmppFilterOnlineSingle(Long lTime, XmppListener listener, Handler handler, XMPPConnection superConnection, Context context) {
		lnEditTime = lTime;
		mXmppListener = listener;
		mHandler = handler;
		connection = superConnection;
		mContext = context;
		setContext(context);
	}
	
	public void setFilter1(final Packet message) {
		PacketExtension packetExtensionReceq = message.getExtension(RequestEx.NAMESPACE);
		PacketExtension packetExtensionRead = message.getExtension(ReadEx.NAMESPACE);
		EmoticonEx emoticonEx =(EmoticonEx)message.getExtension(EmoticonEx.NAMESPACE);
		ClearEx clearEx = (ClearEx) message.getExtension(ClearEx.NAMESPACE);
		FileEx fileEx = (FileEx) message.getExtension(FileEx.NAMESPACE);
		PCSyncEx pcsyncEx = (PCSyncEx) message.getExtension(PCSyncEx.NAMESPACE);
		PCSingleMessageEx pcSingleMessageEx = null;
		if(message.getExtension(PCSingleMessageEx.NAMESPACE) != null && message.getExtension(PCSingleMessageEx.NAMESPACE).getElementName().equals(PCSingleMessageEx.ELEMENT_NAME))
			pcSingleMessageEx = (PCSingleMessageEx) message.getExtension(PCSingleMessageEx.NAMESPACE);
		if (message.getError() != null) {
			if (message.getError().getCode() == 404) {				
				if (mXmppListener.getPacketListener() != null) {
					mXmppListener.getPacketListener().viewErrorMessage("해당 사용자가 없습니다.");
				} else if (mXmppListener.getGroupPacketListener() != null) {
					mXmppListener.getGroupPacketListener().viewErrorMessage("해당 사용자가 없습니다.");
				}
			}
			else if (message.getError().getCode() == 413){
				if (mXmppListener.getPacketListener() != null) {
					mXmppListener.getPacketListener().viewErrorMessage(message.getError().getMessage());
				} else if (mXmppListener.getGroupPacketListener() != null) {
					mXmppListener.getGroupPacketListener().viewErrorMessage(message.getError().getMessage());
				}
			}
		} else if(!message.getFrom().equals("cork.com") && pcSingleMessageEx != null && pcSingleMessageEx.getElementName().equals(PCSingleMessageEx.ELEMENT_NAME)){
			if(!pcSingleMessageEx.getReadIds().isEmpty()){
				// ArrayList<ReadCountData> arrReadCountData = new
				// ArrayList<ReadCountData>();
				ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
				chattingDBMngd.openWritable(pcSingleMessageEx.getTo().split("@")[0]);

				HashMap<String, Boolean> mapNoReadMessageID = new HashMap<String, Boolean>();

				for (String readId : pcSingleMessageEx.getReadIds()) {
					mapNoReadMessageID.put(readId, true);
					// ReadCountData readCountData = new
					// ReadCountData();
					//
					// ChattingMessageData chattingMsg =
					// chattingDBMngd.getChattingMessage(readId);
					// readCountData.m_strRoomId =
					// message.getFrom().split("@")[0];
					// readCountData.m_strMessageId = readId;
					// readCountData.m_strCreateDate = "" +
					// chattingMsg.m_lnMsgSendTime;
					// readCountData.m_nCount =
					// chattingMsg.m_nNoReadUserCount - 1;
					// arrReadCountData.add(readCountData);
				}
				// chattingDBMngd.updateNoReadUserCount(arrReadCountData);
				chattingDBMngd.updateReadMessage(mapNoReadMessageID);
				chattingDBMngd.close();
				SharedPref pref = SharedPref.getInstance(mContext);
				int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
				int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
				if(nUpdateBadgeCount < 0){
					nUpdateBadgeCount = 0;
				}
				pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
				IconBadge.updateIconBadge(mContext);
				
				if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
					mXmppListener.getNotifyListner().onReadNotify(pcSingleMessageEx.getTo().split("@")[0], pcSingleMessageEx.getReadIds());
				}
			} else {
			boolean isNoRoom = true;

			ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(mContext, pcSingleMessageEx.getTo().split("@")[0]);

			if (roomData != null) {
				isNoRoom = false;
			}

			if (isNoRoom) {

				UserListData m_UserData = ContactsDBManager.getContacts(mContext, Integer.parseInt(pcSingleMessageEx.getTo().split("@")[0]));
				if (m_UserData == null) {
					CountDownLatch latch = new CountDownLatch(1);
					requestAddedByUserList(Integer.parseInt(pcSingleMessageEx.getTo().split("@")[0]), latch);
					try {
						latch.await();
					} catch (InterruptedException e) {
						// TODO Auto-generated
						// catch block
						e.printStackTrace();
					}
				} else {
					String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
					ChattingRoomInfoData data;
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
						data = new ChattingRoomInfoData(pcSingleMessageEx.getTo().split("@")[0], crypto.encrypt(strFriendUserName), true,
								App.m_MyUserInfo.m_nUserNo, false);
						RoomDBManager.insertRoom(mContext, data);
					} catch (Exception e) {
						// TODO Auto-generated
						// catch block
						e.printStackTrace();
					}

				}
			}

			//DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

			SimpleDateFormat formatZ = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault());
			formatZ.setTimeZone(TimeZone.getTimeZone("UTC"));
			Date dateZ = null;
			try {
				dateZ = formatZ.parse(pcSingleMessageEx.getStamp());
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			long lTime = dateZ.getTime();
			int nDBResult = -1;
			
			ChattingMessageData a_chattingMsgData;
			a_chattingMsgData = new ChattingMessageData();
			if(pcSingleMessageEx.getType().equals("clear")){
				ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
				chattingDBMng.openWritable((pcSingleMessageEx.getTo().split("@")[0]));
				chattingDBMng.deleteChattingMessage();


				String pattern = "a h:mm";
				SimpleDateFormat format = new SimpleDateFormat(pattern);
				String date = (String) format.format(new Timestamp(lTime));

				// 방장 이름
				UserListData userClear = null;

				userClear = (ContactsDBManager.getContacts(mContext, Integer.parseInt(pcSingleMessageEx.getFrom().split("@")[0])));
	
				String strClearName;
				if(userClear == null){
					strClearName = mContext.getString(R.string.not_in_db_user);
				} else {
					strClearName = userClear.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
				}

				a_chattingMsgData.m_strMsgText = String.format(mContext.getString(R.string.chatroom_clear), strClearName) + date;
				a_chattingMsgData.m_nMsgType = 1;
				a_chattingMsgData.m_isRead = true;
				a_chattingMsgData.m_strMsgId = pcSingleMessageEx.getId();
				a_chattingMsgData.m_lnMsgSendTime = lTime;


				if(lTime > lnEditTime)
					nDBResult = chattingDBMng.insertMessage(a_chattingMsgData);
				chattingDBMng.close();
			}
			else if(pcSingleMessageEx.getType().equals("file")){
				
				ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
				chattingDBMngd.openWritable(pcSingleMessageEx.getTo().split("@")[0]);

				ArrayList<Integer> arrMyId = new ArrayList<Integer>();
				arrMyId.add(App.m_MyUserInfo.m_nUserNo);
				// 처음 글을 올리는 순간은 무조건 나만 본것
				if (pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
					String strCreateTime = "";
					if (pcSingleMessageEx.getCreateTime() != null && !pcSingleMessageEx.getCreateTime().equals("0")) {
						strCreateTime = pcSingleMessageEx.getCreateTime();
					} else {
						strCreateTime = Long.toString(lTime);
					}
					XmppUtils utils = new XmppUtils();
					utils.strFileName = pcSingleMessageEx.getFileName();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strCreateTime = strCreateTime;
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}
				// 이미지 라면 추가로 width, height, 썸네일
				// url도 추가한다
				else if (pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;
					XmppUtils utils = new XmppUtils();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strWidth = pcSingleMessageEx.getWidth();
					utils.strHeight = pcSingleMessageEx.getHeight();
					utils.strThumb = pcSingleMessageEx.getThumb();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}
				// 동영상일 경우 fileName에 "" 을 넣도록
				// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
				else if (pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
					String strCreateTime = "";
					if (pcSingleMessageEx.getCreateTime() != null && !pcSingleMessageEx.getCreateTime().equals("0")) {
						strCreateTime = pcSingleMessageEx.getCreateTime();
					} else {
						strCreateTime = Long.toString(lTime);
					}
					XmppUtils utils = new XmppUtils();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strCreateTime = strCreateTime;
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strThumb = pcSingleMessageEx.getThumb();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}
				else if (pcSingleMessageEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
					XmppUtils utils = new XmppUtils();
					utils.strFileName = pcSingleMessageEx.getFileName();
					utils.strMimeType = pcSingleMessageEx.getMimetype();
					utils.strUrl = pcSingleMessageEx.getUrl();
					utils.strVdi = pcSingleMessageEx.getVdi();
					a_chattingMsgData.m_strMsgText = utils.getFileExText();
				}
				a_chattingMsgData.m_nSendUserId = 0;
				a_chattingMsgData.m_strMsgId = pcSingleMessageEx.getId();
				a_chattingMsgData.m_lnMsgSendTime = lTime;
				a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
				a_chattingMsgData.m_nNoReadUserCount = 1;
				a_chattingMsgData.m_isRead = true;

				if(lTime > lnEditTime)
					nDBResult = chattingDBMngd.insertMessage(a_chattingMsgData);
				chattingDBMngd.close();
			} else if(pcSingleMessageEx.getType().equals("urgent") || pcSingleMessageEx.getType().equals("")){

			ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
			chattingDBMngd.openWritable(pcSingleMessageEx.getTo().split("@")[0]);
			
			ArrayList<Integer> arrMyId = new ArrayList<Integer>();
			// 임시
			arrMyId.add(App.m_MyUserInfo.m_nUserNo);
			// 처음 글을 올리는 순간은 무조건 나만 본것

			if(pcSingleMessageEx.getType().equals("urgent")){
				a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
			}
			
			a_chattingMsgData.m_nSendUserId = 0;
			a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
			if(pcSingleMessageEx.getBody() != null)
			a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(pcSingleMessageEx.getBody());
				if (pcSingleMessageEx.getName() !=null){
					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
					a_chattingMsgData.m_strEmoticon = pcSingleMessageEx.getName();
				}
			a_chattingMsgData.m_strMsgId = pcSingleMessageEx.getId();
			a_chattingMsgData.m_lnMsgSendTime = lTime;
			a_chattingMsgData.m_nNoReadUserCount = 1;
			a_chattingMsgData.m_isRead = true;

			if(lTime > lnEditTime)
				nDBResult = chattingDBMngd.insertMessage(a_chattingMsgData);
			chattingDBMngd.close();
			}
			if (nDBResult != -1) {
				final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

				Message sendMSG2 = new Message();
				sendMSG2.setPacketID(strPacketID);
				sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
				sendMSG2.addExtension(new PacketExtension() {

					@Override
					public String toXML() {
						// TODO Auto-generated
						// method stub
						return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
					}

					@Override
					public String getElementName() {
						// TODO Auto-generated
						// method stub
						return "received";
					}

					@Override
					public String getNamespace() {
						// TODO Auto-generated
						// method stub
						return "urn:xmpp:receipts";
					}

				});
				connection.sendPacket(sendMSG2);
				CommonLog.e(TAG, "MyPCMessage Receive Online: " + sendMSG2);
			
			
				if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
					mXmppListener.getNotifyListner().onNotify(pcSingleMessageEx.getTo().split("@")[0], pcSingleMessageEx.getId(), false);
				}
				else if (mXmppListener.getPacketListener() != null) {
					if(pcSingleMessageEx.getType().equals("clear")){
						mXmppListener.getPacketListener().onClearRoom(a_chattingMsgData.m_strMsgText, Integer.parseInt(pcSingleMessageEx.getTo().split("@")[0]));
					} else 
					mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(pcSingleMessageEx.getTo().split("@")[0]));
				}
			}
			}
		}
		else if (!message.getFrom().equals("cork.com") && (pcsyncEx == null || !pcsyncEx.getElementName().equals(PCSyncEx.ELEMENT_NAME)) && (message.getFrom().split("@")[1].equals("cork.com/TMS") || message.getFrom().split("@")[1].equals("cork.com")
				|| message.getFrom().split("@")[1].equals("cork.com/TMS_PC") || message.getFrom().split("@")[1].equals("cork.com/TMS_ALL"))) {

			if (clearEx != null) {
				if (clearEx.getElementName().equals(ClearEx.ELEMENT_NAME)) {
					ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
					// 자기가 초기화 했다면
					if (message.getFrom().equals(connection.getUser())) {
						chattingDBMng.openWritable((message.getTo().split("@")[0]));
					}
					// 친구가 했다면
					else {
						chattingDBMng.openWritable((message.getFrom().split("@")[0]));
					}
					chattingDBMng.deleteChattingMessage();

					DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

					long lTime = delay.getStamp().getTime();

					String pattern = "a h:mm";
					SimpleDateFormat format = new SimpleDateFormat(pattern);
					String date = (String) format.format(new Timestamp(lTime));

					// 방장 이름
					UserListData userClear = null;

					// 자기가 초기화 했다면
					if (message.getFrom().equals(connection.getUser())) {
						userClear = (ContactsDBManager.getContacts(mContext, Integer.parseInt(message.getFrom().split("@")[0])));
					}
					// 친구가 했다면
					else {
						userClear = (ContactsDBManager.getContacts(mContext, Integer.parseInt(message.getFrom().split("@")[0])));
					}
					String strClearName;
					if(userClear == null){
						strClearName = mContext.getString(R.string.not_in_db_user);
					} else {
						strClearName = userClear.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
					}
					ChattingMessageData data = new ChattingMessageData();

					data.m_strMsgText = String.format(mContext.getString(R.string.chatroom_clear), strClearName) + date;
					data.m_nMsgType = 1;
					data.m_isRead = true;
					data.m_strMsgId = message.getPacketID();
					data.m_lnMsgSendTime = lTime;

					int nDBResult = 0;
					if(delay.getStamp().getTime() > lnEditTime)
					nDBResult = chattingDBMng.insertMessage(data);
					chattingDBMng.close();
					if (nDBResult != -1) {

						Packet receivePacket = new Packet() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
								StringBuilder buf = new StringBuilder();
								buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
								buf.append("\" id=\"").append(strPacketID);
								buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@" + SERVICE_NAME).append("\">");
								buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
								buf.append("</message>");

								return buf.toString();
							}
						};
						CommonLog.e(TAG, "Recieve Message : " + receivePacket);
						connection.sendPacket(receivePacket);

						if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
							mXmppListener.getNotifyListner().onNotify(message.getFrom().split("@")[0], message.getPacketID(), true);
						}
						// 자기가 초기화 했다면
						if (message.getFrom().equals(connection.getUser())) {
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().onClearRoom(data.m_strMsgText, Integer.parseInt(message.getTo().split("@")[0]));
							}
						}
						// 친구가 했다면
						else {
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().onClearRoom(data.m_strMsgText, Integer.parseInt(message.getFrom().split("@")[0]));
							}
						}
					}
				}
			} else if (message.getFrom().equals(connection.getUser())) {
				// 내가 보낸 파일에 대한 응답
				if (fileEx != null) {
					if (fileEx.getElementName().equals(FileEx.ELEMENT_NAME)) {

						// 전송 완료전의 임시 DB를 삭제 하기 위함
						ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
						chattingDBMngd.openWritable(message.getTo().split("@")[0]);

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						// 처음 글을 올리는 순간은 무조건 나만 본것
						if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 이미지 라면 추가로 width, height, 썸네일
						// url도 추가한다
						else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strWidth = fileEx.getWidth();
							utils.strHeight = fileEx.getHeight();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 동영상일 경우 fileName에 "" 을 넣도록
						// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
						else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						} else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}

						a_chattingMsgData.m_nSendUserId = 0;
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nNoReadUserCount = 1;
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						a_chattingMsgData.m_isRead = true;
						int nDBResult = 0;
						if(delay.getStamp().getTime() > lnEditTime)
						nDBResult = chattingDBMngd.updateChattingMessage(a_chattingMsgData);
						chattingDBMngd.close();
						if (nDBResult != -1) {
							if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
								mXmppListener.getNotifyListner().onNotify(message.getFrom().split("@")[0], message.getPacketID(), false);
							}

							if (fileEx.getMimetype() == null && fileEx.getDocId() != null) {
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getTo().split("@")[0]));
								}
							} else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO) || fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL) || fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getTo().split("@")[0]));
								}
							} else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getTo().split("@")[0]));
								}
							}
						}
					}
				}
				// 내 리드 메세지
				else if (packetExtensionRead != null) {
					if (packetExtensionRead.getElementName().equals(ReadEx.ELEMENT_NAME)) {
//						ReadEx readEx = (ReadEx) message.getExtension(ReadEx.NAMESPACE);
//
////						ArrayList<ReadCountData> arrReadCountData = new ArrayList<ReadCountData>();
//						ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
//						chattingDBMngd.openWritable(message.getTo().split("@")[0]);
//						HashMap<String, Boolean> mapNoReadMessageID = new HashMap<String, Boolean>();
//						for (String readId : readEx.getIds()) {
//							mapNoReadMessageID.put(readId, true);
////							ReadCountData readCountData = new ReadCountData();
//
////							ChattingMessageData chattingMsg = chattingDBMngd.getChattingMessage(readId);
////							readCountData.m_strRoomId = message.getFrom().split("@")[0];
////							readCountData.m_strMessageId = readId;
////							readCountData.m_strCreateDate = "" + chattingMsg.m_lnMsgSendTime;
////							readCountData.m_nCount = chattingMsg.m_nNoReadUserCount - 1;
////							arrReadCountData.add(readCountData);
//						}
////						chattingDBMngd.updateNoReadUserCount(arrReadCountData);
//						chattingDBMngd.updateReadMessage(mapNoReadMessageID);
//						chattingDBMngd.close();
//						SharedPref pref = SharedPref.getInstance(mContext);
//						int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
//						int nUpdateBadgeCount = nBadgeCount - mapNoReadMessageID.size();
//						if(nUpdateBadgeCount < 0){
//							nUpdateBadgeCount = 0;
//						}
//						pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
//						IconBadge.updateIconBadge(mContext);
//
//						// if (mXmppListener.getPacketListener() != null) {
//						//
//						// mXmppListener.getPacketListener().setReadMessage(readEx.getIds(),
//						// Integer.parseInt(message.getFrom().split("@")[0]));
//						// }
					}
				} else if (packetExtensionReceq != null) {
					if (packetExtensionReceq.getElementName().equals(RequestEx.ELEMENT_NAME)) {
						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						// 전송 완료전의 임시 DB를 삭제 하기 위함
						ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
						chattingDBMngd.openWritable(message.getTo().split("@")[0]);

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						if (message.getExtension("info", "urn:xmpp:urgent") != null) {

							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
							CommonLog.e(TAG, "Urgent Success");
						}
						ArrayList<Integer> arrMyId = new ArrayList<Integer>();
						// 임시
						arrMyId.add(App.m_MyUserInfo.m_nUserNo);
						// 처음 글을 올리는 순간은 무조건 나만 본것

						a_chattingMsgData.m_nSendUserId = 0;
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						if(((Message) message).getBody()!=null)
							a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
						else
							a_chattingMsgData.m_strMsgText = "";
						if (emoticonEx !=null){
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
							a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
						}
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nNoReadUserCount = 1;
						a_chattingMsgData.m_isRead = true;
						int nDBResult = 0;
						if(delay.getStamp().getTime() > lnEditTime)
						nDBResult = chattingDBMngd.updateChattingMessage(a_chattingMsgData);
						chattingDBMngd.close();

						if (nDBResult != -1) {
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getTo().split("@")[0]));
							}
						}

					}
				}
				// request, receive등 아무것도 포함되지 않았을때
				else {
					ChattingMessageData a_chattingMsgData;
					a_chattingMsgData = new ChattingMessageData();

					// 전송 완료전의 임시 DB를 삭제 하기 위함
					ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
					chattingDBMngd.openWritable(message.getTo().split("@")[0]);

					DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

					if (message.getExtension("info", "urn:xmpp:urgent") != null) {


						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
						CommonLog.e(TAG, "Urgent Success!!");
					}

					ArrayList<Integer> arrMyId = new ArrayList<Integer>();
					// 임시
					arrMyId.add(App.m_MyUserInfo.m_nUserNo);
					// 처음 글을 올리는 순간은 무조건 나만 본것

					a_chattingMsgData.m_nSendUserId = 0;
					a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
					if(((Message) message).getBody()!=null)
						a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
					else
						a_chattingMsgData.m_strMsgText = "";
					if (emoticonEx !=null){
						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
						a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
					}
					a_chattingMsgData.m_strMsgId = message.getPacketID();
					a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
					a_chattingMsgData.m_nNoReadUserCount = 1;
					a_chattingMsgData.m_isRead = true;
					int nDBResult = 0;
					if(delay.getStamp().getTime() > lnEditTime)
					nDBResult = chattingDBMngd.updateChattingMessage(a_chattingMsgData);
					if(nDBResult == 0){
						chattingDBMngd.insertMessage(a_chattingMsgData);
					}
					chattingDBMngd.close();

					if (nDBResult != -1) {
						if (mXmppListener.getPacketListener() != null) {
							mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getTo().split("@")[0]));
						}
					}
				}

			} else {
				// 받은 메시지 화면에 표시하고 DB에 삽입
				// Request
				if (packetExtensionRead != null) {
					if (packetExtensionRead.getElementName().equals(ReadEx.ELEMENT_NAME)) {
//						ReadEx readEx = (ReadEx) message.getExtension(ReadEx.NAMESPACE);
//
////						ArrayList<ReadCountData> arrReadCountData = new ArrayList<ReadCountData>();
//						ChattingDBManager chattingDBMngd = new ChattingDBManager(mContext);
//						chattingDBMngd.openWritable(message.getFrom().split("@")[0]);
//						HashMap<String, Boolean> mapNoReadMessageID = new HashMap<String, Boolean>();
//						for (String readId : readEx.getIds()) {
//							mapNoReadMessageID.put(readId, true);
////							ReadCountData readCountData = new ReadCountData();
//
////							ChattingMessageData chattingMsg = chattingDBMngd.getChattingMessage(readId);
////							readCountData.m_strRoomId = message.getFrom().split("@")[0];
////							readCountData.m_strMessageId = readId;
////							readCountData.m_strCreateDate = "" + chattingMsg.m_lnMsgSendTime;
////							readCountData.m_nCount = chattingMsg.m_nNoReadUserCount - 1;
////							arrReadCountData.add(readCountData);
//						}
////						chattingDBMngd.updateNoReadUserCount(arrReadCountData);
//						chattingDBMngd.updateReadMessage(mapNoReadMessageID);
//						chattingDBMngd.close();

						// if (mXmppListener.getPacketListener() != null) {
						//
						// mXmppListener.getPacketListener().setReadMessage(readEx.getIds(),
						// Integer.parseInt(message.getFrom().split("@")[0]));
						// }

//						if (mXmppListener.getPacketListener() != null) {
//
//							mXmppListener.getPacketListener().setReadMessage(readEx.getIds(), Integer.parseInt(message.getFrom().split("@")[0]));
//						}
					}
					// }
				}

				// 상대방이 보낸 파일을 받았을때
				else if (fileEx != null) {
					if (fileEx.getElementName().equals(FileEx.ELEMENT_NAME)) {

						ChattingRoomInfoData singleRoomData = RoomDBManager.getChattingRoom(mContext, message.getFrom().split("@")[0]);

						if (singleRoomData == null) {

							UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(mContext,
									Integer.parseInt(message.getFrom().split("@")[0]));
							if (m_UserData == null) {
								CountDownLatch latch = new CountDownLatch(1);
								requestAddedByUserList(Integer.parseInt(message.getFrom().split("@")[0]), latch);
								try {
									latch.await();
								} catch (InterruptedException e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}
							} else {
								String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								ChattingRoomInfoData data;
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									data = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(strFriendUserName), true,
											App.m_MyUserInfo.m_nUserNo, false);
									RoomDBManager.insertRoom(mContext, data);
								} catch (Exception e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}

							}
						}

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						ArrayList<Integer> arrFriendId = new ArrayList<Integer>();
						// 처음 파일을 받았을때는 읽음 표시 하지 않음
						arrFriendId.add(Integer.parseInt(message.getFrom().split("@")[0]));

						if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 이미지 라면 추가로 width, height, 썸네일
						// url도 추가한다
						else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_IMAGE;
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strWidth = fileEx.getWidth();
							utils.strHeight = fileEx.getHeight();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 동영상일 경우 fileName에 "" 을 넣도록
						// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
						else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();

						}
						else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}

						a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("@")[0]);
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						a_chattingMsgData.m_nNoReadUserCount = 0;

						ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
						chattingDBMng.openWritable(message.getFrom().split("@")[0]);
						int nDBResult = 0;
						if(delay.getStamp().getTime() > lnEditTime)
						nDBResult = chattingDBMng.insertMessage(a_chattingMsgData);
						chattingDBMng.close();
						if (nDBResult != -1) {
							// 상대가 보낸 파일의 정보를 받았을때
							final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

							Message sendMSG2 = new Message();
							sendMSG2.setPacketID(strPacketID);
							sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
							sendMSG2.addExtension(new PacketExtension() {

								@Override
								public String toXML() {
									// TODO Auto-generated
									// method stub
									return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
								}

								@Override
								public String getElementName() {
									// TODO Auto-generated
									// method stub
									return "received";
								}

								@Override
								public String getNamespace() {
									// TODO Auto-generated
									// method stub
									return "urn:xmpp:receipts";
								}

							});
							connection.sendPacket(sendMSG2);
							CommonLog.e(TAG, "File Received : " + sendMSG2);

							SharedPref pref = SharedPref.getInstance(mContext);
							int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
							int nUpdateBadgeCount = nBadgeCount + 1;
							if (nUpdateBadgeCount < 0) {
								nUpdateBadgeCount = 0;
							}
							pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
							IconBadge.updateIconBadge(mContext);

							if (mXmppListener.getPacketListener() != null && mXmppListener.getPacketListener().getRoomID().equals(message.getFrom().split("@")[0])) {

							} else {
								UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(mContext,
										Integer.parseInt(message.getFrom().split("@")[0]));
								String[] aesData;
								String strFriendName;
								if(m_UserData == null){
									strFriendName = mContext.getString(R.string.not_in_db_user);
								} else {
									strFriendName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								}							
								String strText = "";
								if (fileEx.getMimetype() == null && fileEx.getDocId() != null) {
									//strText = "보안파일";
									strText = mContext.getString(R.string.chatlist_file);
								} else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO))
									strText = mContext.getString(R.string.chatlist_movie);
								else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL))
									strText = mContext.getString(R.string.chatlist_file);
								else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE))
									strText = mContext.getString(R.string.chatlist_image);
								else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT))
									strText = mContext.getString(R.string.chatlist_contact);
								if (delay.getType() != null && delay.getIdx() != null) {
									if (!delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) && !delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)
											&& Integer.parseInt(message.getFrom().split("@")[0]) != App.m_MyUserInfo.m_nUserNo) {
										PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
										boolean isScreenOn = pm.isScreenOn();

										if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
											mHandler.post(new ToastRunnable(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, strText, App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true),
													message.getFrom().split("@")[0]));
											PushController.buildMessageNotification(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, strText, App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true),
													null);
										}
									}
								} else {
									if (Integer.parseInt(message.getFrom().split("@")[0]) != App.m_MyUserInfo.m_nUserNo) {
										PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
										boolean isScreenOn = pm.isScreenOn();

										if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
											mHandler.post(new ToastRunnable(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, strText, App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true),
													message.getFrom().split("@")[0]));
											PushController.buildMessageNotification(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, strText, App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true),
													null);
										}
									}
								}
							}

							if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {

								mXmppListener.getNotifyListner().onNotify(message.getFrom().split("@")[0], message.getPacketID(), false);
							}

							if (fileEx.getMimetype() == null && fileEx.getDocId() != null) {
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getFrom().split("@")[0]));
								}
							} else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO) || fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL) || fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getFrom().split("@")[0]));
								}
							} else if (fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getFrom().split("@")[0]));
								}
							}
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().onReadCheck(Integer.parseInt(message.getFrom().split("@")[0]), message);
							}
						}
					}
				} else if (packetExtensionReceq != null) {
					boolean isSystemMessage = false;
					if (packetExtensionReceq.getElementName().equals(RequestEx.ELEMENT_NAME)) {
						boolean isNoRoom = true;
						ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(mContext, message.getFrom().split("@")[0]);
						if (roomData != null) {
							isNoRoom = false;
						}

						if (isNoRoom) {
							CommonLog.e(mContext, "생성 진입");
							UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(mContext,
									Integer.parseInt(message.getFrom().split("@")[0]));
							if (m_UserData == null) {
								CountDownLatch latch = new CountDownLatch(1);
								requestAddedByUserList(Integer.parseInt(message.getFrom().split("@")[0]), latch);
								try {
									latch.await();
								} catch (InterruptedException e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}
							} else {
								String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								ChattingRoomInfoData data;
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									data = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(strFriendUserName), true,
											App.m_MyUserInfo.m_nUserNo, false);
									RoomDBManager.insertRoom(mContext, data);
								} catch (Exception e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}

								CommonLog.e(mContext, "생성 중");
							}
						}

						final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						int nDBResult = 0;
						ChattingDBManager chattingDBMng = null;

						chattingDBMng = new ChattingDBManager(mContext);
						chattingDBMng.openWritable(message.getFrom().split("@")[0]);

						if (message.getExtension("info", "urn:xmpp:urgent") != null) {

							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
							CommonLog.e(TAG, "Urgent Success");
						}
						if (nDBResult != -1) {
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

							if (message.getExtension("info", "urn:xmpp:event") != null) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
								String pattern = "a h:mm";

								SimpleDateFormat format = new SimpleDateFormat(pattern);
								String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
								if (((Message) message).getBody() != null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;
								a_chattingMsgData.m_isRead = true;
								isSystemMessage = true;
							} else {
								if(((Message) message).getBody()!=null)
									a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
								else
									a_chattingMsgData.m_strMsgText = "";
								if (emoticonEx !=null){
									a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
									a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
								}
							}
							a_chattingMsgData.m_strMsgId = message.getPacketID();
							a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
							a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("@")[0]);
							a_chattingMsgData.m_nNoReadUserCount = 0;

							int nInsertCount = 0;
							if(delay.getStamp().getTime() > lnEditTime)
							nInsertCount = chattingDBMng.insertMessage(a_chattingMsgData);
							if (nInsertCount != -1) {

								UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(mContext,
										Integer.parseInt(message.getFrom().split("@")[0]));

								Message sendMSG2 = new Message();
								sendMSG2.setPacketID(strPacketID);
								sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
								sendMSG2.addExtension(new PacketExtension() {

									@Override
									public String toXML() {
										// TODO
										// Auto-generated
										// method stub
										return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
									}

									@Override
									public String getElementName() {
										// TODO
										// Auto-generated
										// method stub
										return "received";
									}

									@Override
									public String getNamespace() {
										// TODO
										// Auto-generated
										// method stub
										return "urn:xmpp:receipts";
									}

								});
								connection.sendPacket(sendMSG2);

								if (!isSystemMessage) {
									SharedPref pref = SharedPref.getInstance(mContext);
									int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
									int nUpdateBadgeCount = nBadgeCount + 1;
									if (nUpdateBadgeCount < 0) {
										nUpdateBadgeCount = 0;
									}
									pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
									IconBadge.updateIconBadge(mContext);

								}
								if (mXmppListener.getPacketListener() != null && mXmppListener.getPacketListener().getRoomID().equals(message.getFrom().split("@")[0])) {

								} else {
									if (delay.getType() != null && delay.getIdx() != null) {
										if (!delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE)
												&& !delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)
												&& Integer.parseInt(message.getFrom().split("@")[0]) != App.m_MyUserInfo.m_nUserNo) {
											PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
											boolean isScreenOn = pm.isScreenOn();

											if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
												String[] aesData;
												String strFriendName;
												if(m_UserData == null){
													strFriendName = mContext.getString(R.string.not_in_db_user);
												} else {
													strFriendName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
												}
												
												mHandler.post(new ToastRunnable(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
														strFriendName, a_chattingMsgData.m_strMsgText, App.getImageDownLoaderUrl(
																Integer.parseInt(message.getFrom().split("@")[0]), true), message.getFrom().split("@")[0]));
												PushController.buildMessageNotification(mContext,
														Integer.parseInt(message.getFrom().split("@")[0]), strFriendName, a_chattingMsgData.m_strMsgText,
														App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true), null);
											}
										}
									} else {
										if (Integer.parseInt(message.getFrom().split("@")[0]) != App.m_MyUserInfo.m_nUserNo) {
											PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
											boolean isScreenOn = pm.isScreenOn();

											if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
												String[] aesData;
												String strFriendName;
												if(m_UserData == null){
													strFriendName = mContext.getString(R.string.not_in_db_user);
												} else {
													strFriendName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
												}
												mHandler.post(new ToastRunnable(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
														strFriendName, a_chattingMsgData.m_strMsgText, App.getImageDownLoaderUrl(
																Integer.parseInt(message.getFrom().split("@")[0]), true), message.getFrom().split("@")[0]));
												PushController.buildMessageNotification(mContext,
														Integer.parseInt(message.getFrom().split("@")[0]), strFriendName, a_chattingMsgData.m_strMsgText,
														App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true), null);
											}
										}
									}
								}

								if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
									mXmppListener.getNotifyListner().onNotify(message.getFrom().split("@")[0], message.getPacketID(), isSystemMessage);
								}
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getFrom().split("@")[0]));
								}
								if (mXmppListener.getPacketListener() != null) {
									mXmppListener.getPacketListener().onReadCheck(Integer.parseInt(message.getFrom().split("@")[0]), message);
								}

							}
						}

						chattingDBMng.close();

						// }
					}
					// Received
					else if (packetExtensionReceq.getElementName().equals(ReceivedEx.ELEMENT_NAME)) {
						//CommonLog.e(TAG, "Received : " + message.toXML());

					}

				}
				// receive, request등 아무것도 포함되지 않은경우
				else {
					boolean isSystemMessage = false;
					ChattingRoomInfoData singleRoomData = RoomDBManager.getChattingRoom(mContext, message.getFrom().split("@")[0]);

					if (singleRoomData == null) {
						CommonLog.e(mContext, "생성 진입");
						UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(mContext,
								Integer.parseInt(message.getFrom().split("@")[0]));
						if (m_UserData == null) {
							CountDownLatch latch = new CountDownLatch(1);
							requestAddedByUserList(Integer.parseInt(message.getFrom().split("@")[0]), latch);
							try {
								latch.await();
							} catch (InterruptedException e) {
								// TODO Auto-generated catch
								// block
								e.printStackTrace();
							}
						} else {
							String strFriendUserName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
							ChattingRoomInfoData data;
							try {
								LocalAesCrypto crypto = new LocalAesCrypto();
								data = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(strFriendUserName), true,
										App.m_MyUserInfo.m_nUserNo, false);
								RoomDBManager.insertRoom(mContext, data);
							} catch (Exception e) {
								// TODO Auto-generated catch
								// block
								e.printStackTrace();
							}

							CommonLog.e(mContext, "생성 중");
						}
					}

					final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + App.m_MyUserInfo.m_nUserNo;

					ChattingMessageData a_chattingMsgData;
					a_chattingMsgData = new ChattingMessageData();

					int nDBResult = 0;
					ChattingDBManager chattingDBMng = new ChattingDBManager(mContext);
					chattingDBMng.openWritable(message.getFrom().split("@")[0]);
					if (message.getExtension("info", "urn:xmpp:urgent") != null) {

						a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
						CommonLog.e(TAG, "Urgent Success");
					}
					if (nDBResult != -1) {
						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						if (message.getExtension("info", "urn:xmpp:event") != null) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
							String pattern = "a h:mm";
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
							if (((Message) message).getBody() != null)
							a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;
							a_chattingMsgData.m_isRead = true;
							isSystemMessage = true;
						} else {
							if(((Message) message).getBody()!=null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
							else
								a_chattingMsgData.m_strMsgText = "";
							if (emoticonEx !=null){
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
								a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
							}
						}

						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("@")[0]);
						a_chattingMsgData.m_nNoReadUserCount = 0;

						int nInsertCount = 0;
						if(delay.getStamp().getTime() > lnEditTime)
						nInsertCount = chattingDBMng.insertMessage(a_chattingMsgData);

						if (nInsertCount != -1) {
							UserListData m_UserData = TTalkDBManager.ContactsDBManager.getContacts(mContext,
									Integer.parseInt(message.getFrom().split("@")[0]));

							String[] aesData;
							String strFriendName;
							if(m_UserData == null){
								strFriendName = mContext.getString(R.string.not_in_db_user);
							} else {
								strFriendName = m_UserData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
							}
							
							Message sendMSG2 = new Message();
							sendMSG2.setPacketID(strPacketID);
							sendMSG2.setTo(Integer.parseInt(message.getFrom().split("@")[0]) + "@" + SERVICE_NAME);
							sendMSG2.addExtension(new PacketExtension() {

								@Override
								public String toXML() {
									// TODO Auto-generated
									// method stub
									return "<received xmlns='urn:xmpp:receipts' id='" + message.getPacketID() + "'/>";
								}

								@Override
								public String getElementName() {
									// TODO Auto-generated
									// method stub
									return "received";
								}

								@Override
								public String getNamespace() {
									// TODO Auto-generated
									// method stub
									return "urn:xmpp:receipts";
								}

							});

							connection.sendPacket(sendMSG2);

							if (!isSystemMessage) {
								SharedPref pref = SharedPref.getInstance(mContext);
								int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
								int nUpdateBadgeCount = nBadgeCount + 1;
								if (nUpdateBadgeCount < 0) {
									nUpdateBadgeCount = 0;
								}
								pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, nUpdateBadgeCount);
								IconBadge.updateIconBadge(mContext);

							}

							if (mXmppListener.getPacketListener() != null && mXmppListener.getPacketListener().getRoomID().equals(message.getFrom().split("@")[0])) {

							} else {
								String remakeMsgText = "";
								if(a_chattingMsgData.m_strEmoticon.equals("")){
									remakeMsgText = a_chattingMsgData.m_strMsgText;
								} else {
									remakeMsgText = mContext.getString(R.string.emoticon)+a_chattingMsgData.m_strMsgText;
								}
								if (delay.getType() != null && delay.getIdx() != null) {
									if (!delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) && !delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)
											&& Integer.parseInt(message.getFrom().split("@")[0]) != App.m_MyUserInfo.m_nUserNo) {
										PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
										boolean isScreenOn = pm.isScreenOn();

										if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
											mHandler.post(new ToastRunnable(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, remakeMsgText, App.getImageDownLoaderUrl(
															Integer.parseInt(message.getFrom().split("@")[0]), true), message.getFrom().split("@")[0]));
											PushController.buildMessageNotification(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, remakeMsgText,
													App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true), null);
										}
									}
								} else {
									if (Integer.parseInt(message.getFrom().split("@")[0]) != App.m_MyUserInfo.m_nUserNo) {
										PowerManager pm = (PowerManager) mContext.getSystemService(Context.POWER_SERVICE);
										boolean isScreenOn = pm.isScreenOn();

										if (isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning) {
											mHandler.post(new ToastRunnable(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, remakeMsgText, App.getImageDownLoaderUrl(
															Integer.parseInt(message.getFrom().split("@")[0]), true), message.getFrom().split("@")[0]));
											PushController.buildMessageNotification(mContext, Integer.parseInt(message.getFrom().split("@")[0]),
													strFriendName, remakeMsgText,
													App.getImageDownLoaderUrl(Integer.parseInt(message.getFrom().split("@")[0]), true), null);
										}
									}
								}
							}
						
							if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
								mXmppListener.getNotifyListner().onNotify(message.getFrom().split("@")[0], message.getPacketID(), isSystemMessage);
							}
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().printAddMessage(a_chattingMsgData, Integer.parseInt(message.getFrom().split("@")[0]));
							}
							if (mXmppListener.getPacketListener() != null) {
								mXmppListener.getPacketListener().onReadCheck(Integer.parseInt(message.getFrom().split("@")[0]), message);
							}
						}
					}
					chattingDBMng.close();
				}
			}
		}
	}	
}
