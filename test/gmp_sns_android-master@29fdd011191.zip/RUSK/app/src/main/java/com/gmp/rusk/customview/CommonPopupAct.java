package com.gmp.rusk.customview;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

public class CommonPopupAct extends CustomActivity{

	private int m_nBtnType = 0;
	private String m_strTitle = "";
	private String m_strBody = "";
	private String m_strRoomID = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		setContentView(R.layout.act_popup_common);
		// select UserNo 가져 오는 부분 구현
		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_nBtnType = bundle.getInt(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BTNTYPE);
			m_strTitle = bundle.getString(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_TITLE, getString(R.string.pop_error_title));
			m_strBody = bundle.getString(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BODY, "");
			m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID_KICK, "");
		}

		TextView tv_pop_title = (TextView) findViewById(R.id.tv_pop_title);
		tv_pop_title.setText(m_strTitle);

		TextView tv_pop_body = (TextView) findViewById(R.id.tv_pop_body);
		tv_pop_body.setText(m_strBody);

		if (m_nBtnType == CommonPopupBtnTypeInt.POP_BTNTYPE_YES) {
			LinearLayout layout_one_btn = (LinearLayout) findViewById(R.id.layout_one_btn);
			layout_one_btn.setVisibility(View.VISIBLE);

			ImageButton ib_pop_ok_long = (ImageButton) findViewById(R.id.ib_pop_ok_long);
			ib_pop_ok_long.setOnClickListener(this);
		} else if (m_nBtnType == CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO) {
			LinearLayout layout_two_btn = (LinearLayout) findViewById(R.id.layout_two_btn);
			layout_two_btn.setVisibility(View.VISIBLE);

			ImageButton ib_pop_ok = (ImageButton) findViewById(R.id.ib_pop_ok);
			ib_pop_ok.setOnClickListener(this);

			ImageButton ib_pop_cancel = (ImageButton) findViewById(R.id.ib_pop_cancel);
			ib_pop_cancel.setOnClickListener(this);
		}
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		// super.onBackPressed();
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		// TODO Auto-generated method stub
		if (v.getId() == R.id.ib_pop_ok_long) {
			Intent intent = new Intent();
			intent.setAction(StaticString.BROADCAST_KICK_RECEIVER);
			intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID_KICK, m_strRoomID);
			sendBroadcast(intent, StaticString.BROADCAST_PERMISSION_KICK);
			finish();
		} else if (v.getId() == R.id.ib_pop_ok) {
			finish();
		} else if (v.getId() == R.id.ib_pop_cancel) {
			finish();
		}
	}

	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub

		Rect dialogBounds = new Rect();
		getWindow().getDecorView().getHitRect(dialogBounds);
		if (!dialogBounds.contains((int) ev.getX(), (int) ev.getY())) {
			return false;
		}
		return super.dispatchTouchEvent(ev);
	}
}
