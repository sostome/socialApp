package com.gmp.rusk.extension;

import com.gmp.rusk.utils.CommonLog;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.w3c.dom.Node;
import org.xmlpull.v1.XmlPullParser;

import java.io.StringWriter;
import java.util.ArrayList;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class PCSingleMessageEx implements PacketExtension{
		public static final String NAMESPACE = "urn:utalk:carbons";
		public static final String ELEMENT_NAME = "forwarded";
		//뭐야 이건?
		public static final String ELEMENT_NAME2 = "copy";
		
		private String message;

		//이렇게 까지 해야 하나
		private String id;
		private String from;
		private String to;
		private String body;
		
		private String type;
		private String stamp;
		
		private String fileName;
		private String mimetype;
		private String url;
		private String width;
		private String height;
		private String thumb;
		private String docId;
		private String createTime;

		private String name;

		private String vdi;
		
		private ArrayList<String> readIds = new ArrayList<String>();
		
		public PCSingleMessageEx(String strId, String strFrom, String strTo, String strBody, String strFileName, String strMimetype, String strUrl, 
				String strWidth, String strHeight, String strThumb, String strDocId, String strCreateTime, String strType, String strStamp, ArrayList<String> arrReadIds, String strVdi, String strName)
		{
			id = strId;
			from = strFrom;
			to = strTo;
			body = strBody;
			fileName = strFileName;
			mimetype = strMimetype;
			url = strUrl;
			width = strWidth;
			height = strHeight;
			thumb = strThumb;
			docId = strDocId;
			createTime = strCreateTime;
			
			type = strType;
			stamp = strStamp;
			readIds = arrReadIds;
			vdi = strVdi;

			name = strName;
			
		}

		public String getId(){
			return id;
		}
		
		public String getFrom(){
			return from;
		}
		
		public String getTo(){
			return to;
		}
		
		public String getBody(){
			return body;
		}

		public String getFileName() {
			return fileName;
		}

		public String getMimetype() {
			return mimetype;
		}

		public String getUrl() {
			return url;
		}
		
		public String getWidth() {
			return width;
		}
		
		public String getHeight() {
			return height;
		}
		
		public String getThumb() {
			return thumb;
		}
		
		public String getDocId() {
			return docId;
		}
		
		public String getCreateTime(){
			return createTime;
		}
		
		public String getType() {
			return type;
		}
		
		public String getMessage(){
			return message;
		}
		
		public String getStamp(){
			return stamp;
		}
		
		public ArrayList<String> getReadIds(){
			return readIds;
		}

		public String getVdi() { return vdi; }

		public String getName() {return name;}
		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}
		
		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();

			return buf.toString();
		}
		
		private static String nodeToString(Node node) {
		    StringWriter sw = new StringWriter();
		    try {
		      Transformer t = TransformerFactory.newInstance().newTransformer();
		      t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		      t.setOutputProperty(OutputKeys.INDENT, "yes");
		      t.transform(new DOMSource(node), new StreamResult(sw));
		    } catch (TransformerException te) {
		      System.out.println("nodeToString Transformer Exception");
		    }
		    return sw.toString();
		  }
		
		public static class Provider implements PacketExtensionProvider {

			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
	            
//				
//				DOM2XmlPullBuilder dom2parser = new DOM2XmlPullBuilder();
//				Element element = dom2parser.parseSubTree(parser);
//				
//				String strFullMessage = nodeToString(element);
//				
//				int nEndDelete = strFullMessage.indexOf(">");
//				String strMessage = strFullMessage.substring(nEndDelete + 1, strFullMessage.length() - 13);
//				String strFinalMessage = strMessage.substring(0, 9) + strMessage.substring(18, strMessage.length());
//				strFinalMessage = strFinalMessage.replace("\n", "");
//				CommonLog.e("Test", "Forwarded Log : " + strMessage);
				boolean done = false;
				String strId = null;
				String strFrom = null;
				String strTo = null;
				String strBody = null;
				String strName = null;
				
				//파일
				String fileName = "";
				String mimetype = "";
				String url = "";
				String width = "0";
				String height = "0";
				String thumb = "";
				String docId = "";
				String createTime = "0";
				String strVdi = "false";
				
				ArrayList<String> readIds = new ArrayList<String>();
				
				//구분
				String type = "";
				String stamp = "";
				while (!done) {
					int eventType = parser.getEventType();
					if (eventType == XmlPullParser.START_TAG) {
						if (parser.getName().equals("message")) {	
							
							for(int i = 0; i < 3; i++){
								if(parser.getAttributeName(i).equals("id")){
									strId = parser.getAttributeValue(i);
								} else if(parser.getAttributeName(i).equals("to")){
									strTo = parser.getAttributeValue(i);
								} else if(parser.getAttributeName(i).equals("from")){
									strFrom = parser.getAttributeValue(i);
								}
							}
						}
						else if(parser.getName().equals("body")) {
							strBody = parser.nextText();
						}
						else if(parser.getName().equals("delay")) {
							stamp = parser.getAttributeValue(0);
						}
						else if(parser.getName().equals("info")){
							if(parser.getNamespace().equals("urn:xmpp:file")){
								type = "file";
								int cnt = parser.getAttributeCount();
								for(int i = 0; i < cnt; i++){
									if(parser.getAttributeName(i).equals("isVdi")){
										strVdi = parser.getAttributeValue(i);
									}
								}
							} else if(parser.getNamespace().equals("urn:xmpp:clear")){
								type = "clear";
							} else if(parser.getNamespace().equals("urn:xmpp:urgent")){
								type = "urgent";
							}
						} 
						else if (parser.getName().equals("ack")) {
							readIds.add(parser.getAttributeValue("", "id"));
			            }
						else if (parser.getName().equals("fileName")) {
							fileName = parser.nextText();
						} else if (parser.getName().equals("mimetype")) {						
							mimetype = parser.nextText();
						} else if (parser.getName().equals("url")) {
							url = parser.nextText();
						} else if (parser.getName().equals("width")) {
							width = parser.nextText();
						} else if (parser.getName().equals("height")) {
							height = parser.nextText();
						} else if (parser.getName().equals("thumb")) {
							thumb = parser.nextText();
						} else if (parser.getName().equals("docId")){
							docId = parser.nextText();
						} else if( parser.getName().equals("createTime")){
							createTime = parser.nextText();
						} else if (parser.getName().equals("name")){
							strName = parser.nextText();
						}
					} else if (eventType == XmlPullParser.END_TAG) {
						if (parser.getName().equals(ELEMENT_NAME)) {
							done = true;
						}
					}
					if (!done)
						parser.next();
				}

				return new PCSingleMessageEx(strId, strFrom, strTo, strBody, fileName, mimetype, url, width, height, thumb, docId, createTime, type, stamp, readIds, strVdi, strName);
			}
		}
	}