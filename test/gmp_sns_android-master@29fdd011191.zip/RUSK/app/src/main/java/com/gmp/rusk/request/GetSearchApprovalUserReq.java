package com.gmp.rusk.request;

import android.net.Uri;

import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 *	@author kch
 *			승인자 조회 
 *			method : get
 */

public class GetSearchApprovalUserReq extends Req{

	private String APINAME = "partner";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "GET";


	public GetSearchApprovalUserReq(String a_strCompanyCode, String a_strKeyword)
	{
		try {
			a_strKeyword = URLEncoder.encode(a_strKeyword, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		APINAME = APINAME +"/search/approval-user" + "?companyCode=" + a_strCompanyCode + "&keyword=" + a_strKeyword +"&size=10000";
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		/*try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_KEYWORD, m_strKeyword);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e("PostSearchApprovalUserReq", "" + e.toString());
			return "";
		}*/
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
