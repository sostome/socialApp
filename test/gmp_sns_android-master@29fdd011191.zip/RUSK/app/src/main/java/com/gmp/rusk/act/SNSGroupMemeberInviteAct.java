package com.gmp.rusk.act;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.customview.CustomFragmentActivity;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.fragment.SNSInviteChatRoomListFlag;
import com.gmp.rusk.fragment.SNSInviteFellowListFlag;
import com.gmp.rusk.fragment.SNSInviteOrganChartFlag;
import com.gmp.rusk.fragment.SNSInviteSearchUserFlag;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostGroupUserReq;
import com.gmp.rusk.request.PostRecommendReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;

import java.util.ArrayList;
import java.util.HashMap;

public class SNSGroupMemeberInviteAct extends CustomFragmentActivity implements OnClickListener {

	// Tab Tag
	private final String TAB_FELLOW = "Fellow"; // 동료
	private final String TAB_CHATROOM = "Chatroom"; // 채팅방
	private final String TAB_SEARCH = "Search"; // 검색
	private final String TAB_ORGAN = "Organ"; // 조직도

	private int TAB_INDEX_FELLOW = 3;
	private final int TAB_INDEX_CHATROOM = 0;
	private final int TAB_INDEX_ORGAN = 2;
	private final int TAB_INDEX_SEARCH = 1;
	private int TAB_INDEX_MAX;

	TabHost mTabHost;
	TabManager mTabManager;
	HorizontalScrollView m_BadgeScroll;

	LinearLayout m_LayoutBadge;
	LinearLayout m_RealTabContent;
	LayoutInflater inflater;

	OnNotifyListener m_NotifyListener;

	ArrayList<SearchListCheckData> m_arrSearchListCheckData;
	ArrayList<Integer> m_arrSaveUserNo;
	ImageView m_btnComplete;
	ArrayList<Integer> m_arrUserNumbers;
	int m_nGroupId;
	String m_strChannelName;
	boolean m_isCreate;

	boolean m_isInChatRoomMemberList = false;
	Intent extras;

	private CommonPopup m_Popup = null;
//	int m_nPopupType;

	RelativeLayout m_layoutReturnList;

	ArrayList<Integer> m_arrActiveUsers;
	ArrayList<Integer> m_arrUnActiveUsers;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

		setContentView(R.layout.act_snsgroupinvitetab);

		extras = getIntent();
		m_arrUserNumbers = extras.getIntegerArrayListExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_USERIDS);
		if (m_arrUserNumbers == null) {
			m_arrUserNumbers = new ArrayList<Integer>();
			m_arrUserNumbers.add(App.m_MyUserInfo.m_nUserNo);
		}
		m_nGroupId = extras.getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPID, 0);
		m_strChannelName = extras.getStringExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPNAME);
		m_isCreate = extras.getBooleanExtra(IntentKeyString.INTENT_KEY_SNSGROUPDETAIL_GROUPCREATE, false);
		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();
		m_BadgeScroll = (HorizontalScrollView) findViewById(R.id.sv_badge);

		mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);
		inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		m_RealTabContent = (LinearLayout) findViewById(R.id.layout_realtabcontent);
		m_LayoutBadge = (LinearLayout) findViewById(R.id.layout_badge);
		m_arrSearchListCheckData = new ArrayList<SearchListCheckData>();
		m_arrSaveUserNo = new ArrayList<Integer>();
		ImageView btnCancel = (ImageView)findViewById(R.id.btn_cancel);
		btnCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		if(!m_isCreate){
			btnCancel.setImageResource(R.drawable.btn_btn_top_close);
		}
		m_btnComplete = (ImageView) findViewById(R.id.btn_complete);
		m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
		m_btnComplete.setOnClickListener(this);

		//App.m_arrSearchListCheckData = new ArrayList<SearchListCheckData>();

		setTitle(getString(R.string.snsgroupinvite_member_title));

		View[] viewTabs;
		View viewTabchat = null;
		if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
			TAB_INDEX_MAX = 4;
		} else {
			TAB_INDEX_MAX = 3;
		}
		viewTabs = new View[TAB_INDEX_MAX];
		for (int i = 0; i < TAB_INDEX_MAX; i++) {
			LayoutInflater inflater = getLayoutInflater();
			viewTabs[i] = inflater.inflate(R.layout.layout_tabitem_text, null);
		}
		TextView tvChatTab = null;
		TextView tvSearchTab = null;
		TextView tvOrganTab = null;
		TextView tvFellowListTab = null;

		if(AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
			tvChatTab = (TextView) viewTabs[TAB_INDEX_CHATROOM].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
			tvSearchTab = (TextView) viewTabs[TAB_INDEX_SEARCH].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
			tvOrganTab = (TextView) viewTabs[TAB_INDEX_ORGAN].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
			tvFellowListTab = (TextView) viewTabs[TAB_INDEX_FELLOW].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
		} else {
			tvChatTab = (TextView) viewTabs[TAB_INDEX_CHATROOM].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
			tvSearchTab = (TextView) viewTabs[TAB_INDEX_SEARCH].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
			TAB_INDEX_FELLOW = 2;
			tvFellowListTab = (TextView) viewTabs[TAB_INDEX_FELLOW].findViewById(R.id.tv_tabitem_snsgroupmemberlist);
		}
		// Tab Image 설정
		tvChatTab.setText(R.string.tabitem_text_chatlist);
		tvChatTab.setBackgroundResource(R.drawable.tabitem_background);
		tvSearchTab.setText(R.string.tabitem_text_search_user);
		tvSearchTab.setBackgroundResource(R.drawable.tabitem_background);
		if(tvOrganTab!=null) {
			tvOrganTab.setText(R.string.tabitem_text_organ);
			tvOrganTab.setBackgroundResource(R.drawable.tabitem_background);
		}
		tvFellowListTab.setText(R.string.tabitem_text_fellowlist);
		tvFellowListTab.setBackgroundResource(R.drawable.tabitem_background);

		if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
			mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

			mTabManager.addTab(mTabHost.newTabSpec(TAB_CHATROOM).setIndicator(viewTabs[TAB_INDEX_CHATROOM]), SNSInviteChatRoomListFlag.class, null);
			mTabManager.addTab(mTabHost.newTabSpec(TAB_SEARCH).setIndicator(viewTabs[TAB_INDEX_SEARCH]), SNSInviteSearchUserFlag.class, null);
			mTabManager.addTab(mTabHost.newTabSpec(TAB_ORGAN).setIndicator(viewTabs[TAB_INDEX_ORGAN]), SNSInviteOrganChartFlag.class, null);
			mTabManager.addTab(mTabHost.newTabSpec(TAB_FELLOW).setIndicator(viewTabs[TAB_INDEX_FELLOW]), SNSInviteFellowListFlag.class, null);

		} else {
			mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

			mTabManager.addTab(mTabHost.newTabSpec(TAB_CHATROOM).setIndicator(viewTabs[TAB_INDEX_CHATROOM]), SNSInviteChatRoomListFlag.class, null);
			mTabManager.addTab(mTabHost.newTabSpec(TAB_SEARCH).setIndicator(viewTabs[TAB_INDEX_SEARCH]), SNSInviteSearchUserFlag.class, null);
			mTabManager.addTab(mTabHost.newTabSpec(TAB_FELLOW).setIndicator(viewTabs[TAB_INDEX_FELLOW]), SNSInviteFellowListFlag.class, null);

		}

		// mTabManager.addTab(mTabHost.newTabSpec(TAB_SEARCH).setIndicator(viewTabs[TAB_INDEX_PARTNER]),
		// ChatRoomPartnerListFlag.class, null);

	}

	public void setTitle(String a_strTitle) {
		TextView tvTitle = (TextView) findViewById(R.id.tv_tabact_main_title);
		tvTitle.setText(a_strTitle);
	}

	public void setNotifyListener(OnNotifyListener a_Listener) {
		m_NotifyListener = a_Listener;
	}

	public interface OnNotifyListener {
		public void onNotify();
	}

	public ArrayList<Integer> getUserNumbers() {
		return m_arrUserNumbers;
	}

	public class TabManager implements TabHost.OnTabChangeListener {
		private final FragmentActivity mActivity;
		private final TabHost mTabHost;
		private final int mContainerId;
		private final HashMap<String, TabInfo> mTabs = new HashMap<String, TabInfo>();
		TabInfo mLastTab;

		final class TabInfo {
			private final String tag;
			private final Class<?> clss;
			private final Bundle args;
			private Fragment fragment;

			TabInfo(String _tag, Class<?> _class, Bundle _args) {
				tag = _tag;
				clss = _class;
				args = _args;
			}
		}

		class DummyTabFactory implements TabHost.TabContentFactory {
			private final Context mContext;

			public DummyTabFactory(Context context) {
				mContext = context;
			}

			@Override
			public View createTabContent(String tag) {
				View v = new View(mContext);
				v.setMinimumWidth(0);
				v.setMinimumHeight(0);
				return v;
			}
		}

		public TabManager(FragmentActivity activity, TabHost tabHost, int containerId) {
			mActivity = activity;
			mTabHost = tabHost;
			mContainerId = containerId;
			mTabHost.setOnTabChangedListener(this);
		}

		public void addTab(TabHost.TabSpec tabSpec, Class<?> clss, Bundle args) {
			tabSpec.setContent(new DummyTabFactory(mActivity));
			String tag = tabSpec.getTag();

			TabInfo info = new TabInfo(tag, clss, args);

			// Check to see if we already have a fragment for this tab, probably
			// from a previously saved state. If so, deactivate it, because our
			// initial state is that a tab isn't shown.
			info.fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
			if (info.fragment != null && !info.fragment.isDetached()) {
				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				ft.detach(info.fragment);
				ft.commit();
			}
			// m_testFragment = info.fragment;
			mTabs.put(tag, info);
			mTabHost.addTab(tabSpec);
		}

		@Override
		public void onTabChanged(String tabId) {
			TabInfo newTab = mTabs.get(tabId);

			if (mLastTab != newTab) {

				FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
				if (mLastTab != null) {
					if (mLastTab.fragment != null) {
						ft.detach(mLastTab.fragment);
					}
				}
				if (newTab != null) {
					if (newTab.fragment == null) {
						newTab.fragment = Fragment.instantiate(mActivity, newTab.clss.getName(), newTab.args);
						ft.add(mContainerId, newTab.fragment, newTab.tag);
					} else {
						ft.attach(newTab.fragment);
					}
				}

				mLastTab = newTab;
				ft.commit();
				mActivity.getSupportFragmentManager().executePendingTransactions();
			}
		}

	}

	public void removeListData(int nUserNo) {

		for (SearchListCheckData partnerData : m_arrSearchListCheckData) {
			if (partnerData.m_nUserNo == nUserNo) {
				m_arrSearchListCheckData.remove(partnerData);
				for (SearchListCheckData appPartnerData : App.m_arrSearchListCheckData) {
					if (nUserNo == appPartnerData.m_nUserNo) {
						// appPartnerData.m_isChecked = false;
						App.m_arrSearchListCheckData.remove(appPartnerData);
						break;
					}
				}
				break;
			}
		}
		for (int i = 0; i < m_arrSaveUserNo.size(); i++) {
			if (nUserNo == m_arrSaveUserNo.get(i)) {

				for (int j = 0; j < App.m_arrSearchListCheckData.size(); j++) {
					if (m_arrSaveUserNo.get(i) == App.m_arrSearchListCheckData.get(j).m_nUserNo) {
						App.m_arrSearchListCheckData.remove(j);
						break;
					}
				}

				m_LayoutBadge.removeViewAt(i);
				m_arrSaveUserNo.remove(i);
			/*	m_btnComplete.setText(String.format(getString(R.string.snsgroupinvite_invite), m_arrSaveUserNo.size()));*/

				break;
			}
		}

		if (m_arrSearchListCheckData.isEmpty()) {
			m_BadgeScroll.setVisibility(View.GONE);
			m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
			LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();

			lParams.weight = 1521;
			m_RealTabContent.setLayoutParams(lParams);
		}
		m_NotifyListener.onNotify();
		if(m_arrSearchListCheckData.size() > 0)
			setTitle(getString(R.string.snsgroupinvite_member_title) + " " + m_arrSearchListCheckData.size());
		else
			setTitle(getString(R.string.snsgroupinvite_member_title));
	}

	public void addSearchList(SearchListCheckData a_SearchListData) {
		if (m_arrSearchListCheckData.isEmpty()) {
			m_BadgeScroll.setVisibility(View.VISIBLE);
			m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);

			LinearLayout.LayoutParams lParams = (LinearLayout.LayoutParams) m_RealTabContent.getLayoutParams();
			lParams.weight = 1371;

			m_RealTabContent.setLayoutParams(lParams);
		}
		boolean isSame = false;

		for (SearchListCheckData listData : m_arrSearchListCheckData) {

			if (listData.m_nUserNo == a_SearchListData.m_nUserNo) {
				isSame = true;
			}
		}
		if (!isSame) {
			SearchListCheckData addData = new SearchListCheckData(a_SearchListData.m_nUserNo, a_SearchListData.m_strName);
			// addData.m_isChecked = true;
			App.m_arrSearchListCheckData.add(0, addData);
			m_arrSearchListCheckData.add(0, a_SearchListData);
			final LinearLayout inviteScrollItem = (LinearLayout) inflater.inflate(R.layout.layout_invite_scroll_item, null);
			m_LayoutBadge.addView(inviteScrollItem, 0);
			final TextView tvInviteScrollItem = (TextView) inviteScrollItem.findViewById(R.id.tv_invite_scroll_item);
			final LinearLayout layoutScrollItem = (LinearLayout) inviteScrollItem.findViewById(R.id.layout_invite_scroll_item);
			tvInviteScrollItem.setText(a_SearchListData.m_strName);
			m_arrSaveUserNo.add(0, a_SearchListData.m_nUserNo);
			/*m_btnComplete.setText(String.format(getString(R.string.snsgroupinvite_invite), m_arrSaveUserNo.size()));*/
			layoutScrollItem.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					int nUserNo = m_arrSaveUserNo.get(m_LayoutBadge.indexOfChild(inviteScrollItem));
					for (SearchListCheckData partnerData : m_arrSearchListCheckData) {
						if (partnerData.m_nUserNo == nUserNo) {
							removeListData(partnerData.m_nUserNo);
							break;
						}

					}

				}
			});
		}
		if(m_arrSearchListCheckData.size() > 0)
			setTitle(getString(R.string.snsgroupinvite_member_title) + " " + m_arrSearchListCheckData.size());
		else
			setTitle(getString(R.string.snsgroupinvite_member_title));

	}

	public void inChatRoomMemberList(boolean isState) {
		m_isInChatRoomMemberList = isState;
		/*if (isState) {
			m_layoutReturnList.setVisibility(View.VISIBLE);
		} else {
			m_layoutReturnList.setVisibility(View.GONE);
		}*/

	}

	public void showErrorPopup(int a_nErrorCode, String a_strMessage) {
		super.showErrorPopup(a_nErrorCode, a_strMessage);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub

		if (m_isInChatRoomMemberList) {
			m_OnKeyBackPressedListener.onBack();
		} else {
			super.onBackPressed();
		}
	}

	public interface onKeyBackPressedListener {
		public void onBack();
	}

	private onKeyBackPressedListener m_OnKeyBackPressedListener;

	public void setOnKeyBackPressedListener(onKeyBackPressedListener listener) {
		m_OnKeyBackPressedListener = listener;
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		switch (v.getId()) {
		case R.id.btn_complete:
			if (m_arrUserNumbers.size() + m_arrSaveUserNo.size() > App.m_nGroupLimit) {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
				m_Popup.setBodyAndTitleText(getString(R.string.snsgroupinvite_limit_in_title), getString(R.string.snsgroupinvite_limit_in_text));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else {
				m_arrActiveUsers = new ArrayList<Integer>();
				m_arrUnActiveUsers = new ArrayList<Integer>();

				m_arrActiveUsers = m_arrSaveUserNo;
				reqPostGroupUser(m_arrActiveUsers, m_arrUnActiveUsers);
				//미설치자는 아예 선택 불가 하게 되었으므로 불필요
				/*for (int i = 0; i < m_arrSaveUserNo.size(); i++) {
					UserListData data = ContactsDBManager.getContacts(this, m_arrSaveUserNo.get(i));
					if (data != null && data.m_isActive) {
						m_arrActiveUsers.add(m_arrSaveUserNo.get(i));
					} else {
						m_arrUnActiveUsers.add(m_arrSaveUserNo.get(i));
					}
				}

				if (m_arrUnActiveUsers.size() == 0) {
					reqPostGroupUser(m_arrActiveUsers, m_arrUnActiveUsers);

				} else {
					m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, CommonPopupTypeInt.COMMONPOPUP_SNS_INVITE_UNACTIVE);
					m_Popup.setBodyAndTitleText(getString(R.string.snsgroupinvite_unactive_title), getString(R.string.snsgroupinvite_unactive_text));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}*/

			}
			break;
		case R.id.ib_pop_ok_long:
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			
			if (popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SNS_INVITESUCCESS || popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_CONFIRM_SNS_INVITE) {
				Intent intent = new Intent();

				setResult(RESULT_OK, intent);
				finish();
			}

			popup_ok_long.cancel();
			break;
		case R.id.ib_pop_ok:
			CommonPopup popup_ok = (CommonPopup)v.getTag();
			if (popup_ok.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SNS_INVITE_UNACTIVE) {

			}
			popup_ok.cancel();
			break;
		case R.id.ib_pop_cancel:
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			break;
		case R.id.layout_tabitem_chatinviteitem_return:
			m_OnKeyBackPressedListener.onBack();
			break;
		default:
			break;
		}
	}

	private void reqPostGroupUser(final ArrayList<Integer> arrActiveUsers, ArrayList<Integer> arrUnActiveUsers) {
		if (arrActiveUsers.size() != 0) {
			PostGroupUserReq req = new PostGroupUserReq(m_nGroupId, arrActiveUsers);
			WebAPI webApi = new WebAPI(this);
			webApi.request(req, new WebListener() {

				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub
					showProgress();
				}

				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub
					closeProgress();
					if(m_isCreate) {
						m_Popup = new CommonPopup(SNSGroupMemeberInviteAct.this, SNSGroupMemeberInviteAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_CONFIRM_SNS_INVITE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), String.format(getString(R.string.cork_pop_make_channel_confirm), m_arrActiveUsers.size(), m_strChannelName));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					} else {
						m_Popup = new CommonPopup(SNSGroupMemeberInviteAct.this, SNSGroupMemeberInviteAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_SNS_INVITESUCCESS);
						m_Popup.setBodyAndTitleText(getString(R.string.snsgroupinvite_complete_title),
								String.format(getString(R.string.cork_pop_sns_invite), (m_arrSaveUserNo.size() - m_arrUnActiveUsers.size()), m_strChannelName));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}

				}

				@Override
				public void onNetworkError(int nErrorCode, String strMessage) {
					// TODO Auto-generated method stub
					closeProgress();
					showErrorPopup(nErrorCode, strMessage);
				}
			});
		}
		if (arrUnActiveUsers.size() != 0) {
			int[] arrUsers = new int[arrUnActiveUsers.size()];
			for (int j = 0; j < arrUnActiveUsers.size(); j++) {
				arrUsers[j] = arrUnActiveUsers.get(j);
			}
			PostRecommendReq req2 = new PostRecommendReq(arrUsers);
			WebAPI webApi2 = new WebAPI(this);
			webApi2.request(req2, new WebListener() {

				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub
						if(arrActiveUsers.size() == 0){
							finish();
						}
				}

				@Override
				public void onNetworkError(int a_nErrorCode, String a_strMessage) {
					// TODO Auto-generated method stub

				}
			});
		}
	}

	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}
}
