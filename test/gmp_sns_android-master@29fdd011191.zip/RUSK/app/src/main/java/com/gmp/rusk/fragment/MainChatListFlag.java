package com.gmp.rusk.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTitleNameAct;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.datamodel.ChatRoomListData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.listview.SectionListAdapter;
import com.gmp.rusk.listview.SectionListItem;
import com.gmp.rusk.listview.SectionListView;
import com.gmp.rusk.network.PriorityAsyncUITask;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.StringMatcher;
import com.gmp.rusk.utils.Utils;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import me.thanel.swipeactionview.SwipeActionView;
import me.thanel.swipeactionview.SwipeGestureListener;

/**
 * MainChatListFlag
 *
 * @author kch MainTabAct - 채팅리스트 Fragment
 */
public class MainChatListFlag extends Fragment implements OnClickListener {
	public MyApp App = MyApp.getInstance();
	private final int REQUEST_CODE_PASSOWNER_CHATLIST = 20;
	private final int REQUEST_CODE_TITLE_CHANGE = 21;
	private final int REQUEST_CODE_SEARCH_CHATROOM = 24;
	private final int REQUEST_CODE_SEND_ALLMESSAGE = 25;

	private FragmentActivity m_Activity = null;
	private SectionListView m_ListView;
	ChatListAdapter m_ChatAdapter;

	SectionListAdapter m_SectionListAdapter = null;
	CommonPopup m_Popup;
	int m_nBackgroundColor;

	//	int m_nPopupType;
	public boolean m_isRunning = false;
	public boolean m_isFirstView = true;

	//현재 검색 중인 단어 저장
	String m_currentSearchWord = "";

	ArrayList<ChatRoomListData> m_arrChatRoomListData = null;
	HashMap<String, ChatRoomListData> mapChatRoomListData = null;

	private SectionListItem item = null;
	private ArrayList<SectionListItem> m_SectionListItems = null;

	ArrayList<ChatRoomListData> sortListData;
	View m_vList;
	private FrameLayout m_ChatFrameLayout;
	private LinearLayout m_noListLayout;
	int m_nVisibleNumber = 0;

	int m_nFavoriteCount = 0;
	int m_nNormalCount = 0;

	//boolean m_isNowOnInit = false;
	ArrayList<Boolean> m_arrNowOnInit;
	ProgressDlg m_Progress;

	// 리스트 스크롤 도중 방이 추가될시
	ArrayList<SectionListItem> m_arrItemTrueList = null;
	boolean m_isNowOnScroll = false;

	//방으로 들어가면서 핸들러가 해제되고 핸들러의 정보가  초기화 되기에 보존용
	ArrayList<String> m_arrEnteringRoom = new ArrayList<String>();

	//xmpp이상 여부를 체크할 수단이 없어 프로그레스 바가 10초이상 유지될 경우 네트워크 에러 팝업을 띄우게 하였으나,
	//정상적으로 처리 된 후에 다시 프로그레스바가 뜰때에도 이전 handler내의 if문이 적용 되기에 구분을 위해 넣음.
	private int m_nProgressCount = 0;
	private int m_nDoneProgressCount = 0;

	long m_lStartTime = 0;
	long m_lEndTime = 0;

	RelativeLayout layout_chatroom_search;
	EditText et_search_keyword;
	ImageButton ib_cancel;

	private InputMethodManager imm;

	ArrayList<ChatRoomListData> m_arrSearchRoomListData = null;
	int m_nSearchFavoriteNum = 0;
	int m_nSearchNormalNum = 0;
    /*ArrayList<ChatRoomListData> m_arrAllRoomListData = null;*/

	//찾기를 하던 중인지 체크
	boolean m_isBeforeSearchStatus = false;
	boolean m_isbeforeChangeData = false;

	//채팅 리스트에서 방장 위임을 했을 경우를 체크
	boolean m_isPassOwner = false;

	HashMap<String,ArrayList<Integer>> m_mapUserInfoInChatRoom = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		m_arrChatRoomListData = new ArrayList<ChatRoomListData>();
		mapChatRoomListData = new HashMap<String, ChatRoomListData>();
		App.m_arrDepartmentUserListData = null;
		m_Activity = getActivity();
		m_arrNowOnInit = new ArrayList<Boolean>();
		imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == REQUEST_CODE_PASSOWNER_CHATLIST) {
				App.m_isRoomDelete = true;
				showProgress();
				Bundle bundle = data.getExtras();
				m_isPassOwner = true;
				if (bundle != null)
					((MainTabAct) m_Activity).passOwner(bundle.getInt(IntentKeyString.INTENT_KEY_PASS_OWNER),
							bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID));

				ChatRoomListData roomdata = mapChatRoomListData.get(bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID));
				m_arrChatRoomListData.remove(roomdata);

			} else if (requestCode == REQUEST_CODE_TITLE_CHANGE) {
				Bundle bundle = data.getExtras();
				if (bundle != null) {
					String strRoomId = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID);
					if (bundle.getString(IntentKeyString.INTENT_KEY_ROOM_CHANGE_TITLE).equals("")) {
						String strTitle = "";
						if(strRoomId.length() > 8) {
							ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
							chattingDBMng.openReadable(strRoomId);
							ArrayList<Integer> arrRoomUser = chattingDBMng.getChattingUser();
							chattingDBMng.close();

							ArrayList<String> arrTitleName = new ArrayList<String>();
							StringBuffer title = new StringBuffer();
							for (int i = 0; i < arrRoomUser.size(); i++) {
								if(arrRoomUser.get(i) == null){
									arrTitleName.add(getString(R.string.not_in_db_user));
								} else {
									UserListData userData = ContactsDBManager.getContacts(m_Activity, arrRoomUser.get(i));
									arrTitleName.add(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}
							}

							Collections.sort(arrTitleName, Utils.nameComparator);

							for (int i = 0; i < arrTitleName.size(); i++) {

								title.append(arrTitleName.get(i));

								if (i != arrTitleName.size() - 1) {
									title.append(", ");
								}
							}
							strTitle = title.toString();
						} else if(Integer.parseInt(strRoomId) == App.m_MyUserInfo.m_nUserNo) {
							strTitle = getString(R.string.app_name);
						}
						else {
							UserListData userData = ContactsDBManager.getContacts(m_Activity, Integer.parseInt(strRoomId));
							strTitle = userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
						}
						try {
							LocalAesCrypto crypto = new LocalAesCrypto();
							RoomDBManager.updateRoom(m_Activity, bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID), crypto.encrypt(strTitle), false);
							((MainTabAct)m_Activity).mService.changeRoomTitle(strRoomId, strTitle);
							((MainTabAct)m_Activity).mService.changeRoomNamePCsync(strRoomId, strTitle);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						try {
							LocalAesCrypto crypto = new LocalAesCrypto();
							RoomDBManager.updateRoom(m_Activity, bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID),
									crypto.encrypt(bundle.getString(IntentKeyString.INTENT_KEY_ROOM_CHANGE_TITLE)), true);
							//XMPP로 변경해보자.
							((MainTabAct)m_Activity).mService.changeRoomTitle(strRoomId,bundle.getString(IntentKeyString.INTENT_KEY_ROOM_CHANGE_TITLE));
							((MainTabAct)m_Activity).mService.changeRoomNamePCsync(strRoomId, bundle.getString(IntentKeyString.INTENT_KEY_ROOM_CHANGE_TITLE));
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		} else {
			if(requestCode == REQUEST_CODE_SEARCH_CHATROOM){
				initializeSearchState();
			}
		}
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}

	@Override
	public void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
		((MainTabAct) m_Activity).removeChatRoomReadReceiver();
		//홈버튼등을 이용해 화면을 내린 경우와 탭을 옮기는 경우를 구분하여 처리할 때 사용
        /*if(((MainTabAct)getActivity()).getIsUSerLeave()){
            initializeSearchState();
        }else {

        }*/
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_arrEnteringRoom = new ArrayList<String>();
		m_isRunning = true;
		//홈버튼 등을 이용해 화면을 내릴때와 탭을 옮겼을 때를 구분하기 위한 뒤처리용으로 사용
        /*((MainTabAct) m_Activity).setIsUserLeave(false);*/
		((MainTabAct) m_Activity).setChatRoomReadReceiver();
		if (!m_isFirstView) {


			if (App.m_isRoomDelete) {
				getActivity().runOnUiThread(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub

						showProgress();
					}
				});
			}

			if(!m_isPassOwner) {
				init();
			}
		}
	}

	/**
	 * @brief       화면의 제목,버튼,view등을 설정
	 * @details     화면의 제목을 설정하고 왼쪽 오른쪽 버튼을 설정,처음 이 화면에 들어오면(m_isFirstView)<br>
	 *                 sortListData = firstDataSort(null)<br>
	 *                 firstFavoriteInit(sortListData)<br>
	 *                 firstInit(sortListData)<br>
	 *                 를 호출 하여 m_arrChatRoomListData를 정렬하여 채운다.<br>
	 *                 m_isFirstView가 false인 경우 이미 가지고있는 m_arrChatRoomListData를 사용하므로 어댑터 적용만 다시 해준다.<br>
	 *                 마지막엔 m_isFirstView값에 관계 없이 initSearch메소드를 호출한다.
	 * @param       inflater
	 * @param         container
	 * @param         savedInstanceState
	 * @return      반환값
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// TODO Auto-generated method stub

		m_vList = inflater.inflate(R.layout.fragact_chat_list, container, false);
		m_vList.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				return false;
			}
		});
		((MainTabAct) m_Activity).setTitle(getString(R.string.maintab_chatlist));
		((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_CHATLIST);
		/*((MainTabAct) m_Activity).setRightTopButton(false, ((MainTabAct) m_Activity).TAB_RIGHTBTN_CHATLIST);
		((MainTabAct) m_Activity).setRightFloatButton(true, ((MainTabAct) m_Activity).TAB_RIGHTBTN_CHATLIST);
		((MainTabAct) m_Activity).setLeftTopButton(false, ((MainTabAct) m_Activity).TAB_LEFTBTN_CHATLIST);*/

		((MainTabAct) m_Activity).setNotifyListener(m_NotifyListner);
		layout_chatroom_search = (RelativeLayout)m_vList.findViewById(R.id.layout_chat_room_search);
		// onCreateView에서 그려야지만 리스트뷰의 위치가 유지된다. 어째서 일까.
		if (m_isFirstView) {

			/*sortListData = firstDataSort();*/
			sortListData = firstDataSort(null);

			firstFavoriteInit(sortListData);
			firstInit(sortListData);


		} else {
			m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);

			m_ChatFrameLayout = (FrameLayout) m_vList.findViewById(R.id.layout_chat_list);
			m_noListLayout = (LinearLayout)m_vList.findViewById(R.id.layout_no_list);
			m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);

			m_ListView.setAdapter(m_SectionListAdapter);

			m_ListView.setOnScrollListener(new OnScrollListener() {

				@Override
				public void onScrollStateChanged(AbsListView view, int scrollState) {
					// TODO Auto-generated method stub
					if (scrollState == SCROLL_STATE_IDLE) {
						m_isNowOnScroll = false;
						if (m_arrItemTrueList != null) {
							m_SectionListItems = new ArrayList<SectionListItem>(m_arrItemTrueList);
							if(m_arrNowOnInit.isEmpty() && m_ChatAdapter != null){
								m_ChatAdapter.notifyDataSetChanged();
							}
							m_arrItemTrueList = null;
						}
					} else {
						m_isNowOnScroll = true;
					}
				}

				@Override
				public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
					// TODO Auto-generated method stub
					m_nVisibleNumber = firstVisibleItem;
					if (m_SectionListAdapter != null)
						m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
				}
			});

			// init();

		}
		initSearch();
		return m_vList;
	}

	/**
	 * @brief       검색화면을 초기화하여 평상시 화면이 나오도록 하는 메소드
	 * @details		1) 검색화면을 비운다.<br>
	 *     			2) 취소버튼을 invisible한다.<br>
	 * 				3) m_arrChatRoomListData를 뒤집어 놓은 listData를 매개변수로 firstFavoriteInit과 firstInit을 호출한다<br>
	 * 				4) m_isBeforeSearchStatus를 false로 한다.<br>
	 * 				 (기존의 init을 이용하여 구현할 경우 async에서 하기 때문에 약간의 딜레이가 발생해 따로 만든 메소드)
	 * @param
	 * @return      void
	 */
	private void initializeSearchState(){
		et_search_keyword.setText("");
		ib_cancel.setVisibility(View.INVISIBLE);
		ArrayList<ChatRoomListData> listDatas = new ArrayList<ChatRoomListData>();
		listDatas.addAll(m_arrChatRoomListData);
		Collections.reverse(listDatas);
		firstFavoriteInit(listDatas);
		firstInit(listDatas);
		m_isBeforeSearchStatus = false;
	}

	/**
	 * @brief       검색과 관련된 작업을 init한다.
	 * @details		editText을 비우고 취소 버튼을 설정한다. 취소버튼의 경우 클릭 시 initializeSearchState()를 호출하고 키보드를 내린다.<br>
	 *     			editText에 TextChangeListener를 걸어 문자에 변화가 있을 경우 현재 입력한 글자의 길이가 0보다 큰가 0인가에 따라 처리한다.<br>
	 *     			1)입력한 문자 길이가 0 보다 큰 경우<br>
	 *     			 - m_currentSearchWord에 현재 입력된 문자를 저장<br>
	 *     			 - 취소 버튼 visible<br>
	 *     			 - SearchListViewUi(입력한 문자) 호출<br>
	 *     			 - m_isBeforeSearchStatus 를 true<br>
	 *     			2)입력한 문자 길이가 0<br>
	 *     			 - initializeSearchState() 호출<br>
	 * @param
	 * @return      void
	 */
	private void initSearch(){
		layout_chatroom_search = (RelativeLayout)m_vList.findViewById(R.id.layout_chat_room_search);
		et_search_keyword = (EditText) m_vList.findViewById(R.id.et_search_keyword);
		et_search_keyword.setText("");
		ib_cancel = (ImageButton) m_vList.findViewById(R.id.ib_cancel);
		ib_cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_ChatFrameLayout.setVisibility(View.VISIBLE);
				m_noListLayout.setVisibility(View.GONE);
				initializeSearchState();
				imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(),0);
			}
		});
		et_search_keyword.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				switch (actionId){
					case EditorInfo.IME_ACTION_SEARCH:

						/*if(!Utils.UseChar(v.getText().toString())){
							m_Popup = new CommonPopup(m_Activity,MainChatListFlag.this,CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
							m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.regular_expression_search).toString());
							m_Popup.setCancelable(false);
							m_Popup.show();
							return false;
						}*/
						//imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(),0);

						break;
				}
				return true;
			}
		});
		et_search_keyword.addTextChangedListener(new TextWatcher() {
			int beforeLen = 0;
			int currentLen = 0;
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				beforeLen = count;
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				currentLen = count;
				if(s.toString().length() > 0){
					m_currentSearchWord = s.toString();
					ib_cancel.setVisibility(View.VISIBLE);
					m_isBeforeSearchStatus = true;
					if(m_isbeforeChangeData) {
						m_isbeforeChangeData = false;
						init();
					}
					else
						SearchListViewUi(s.toString());
				}else {
					if(beforeLen == 1 &&currentLen == 0){
						m_ChatFrameLayout.setVisibility(View.VISIBLE);
						m_noListLayout.setVisibility(View.GONE);
						initializeSearchState();
					}
				}
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

	}

	/**
	 * @brief       검색할 때 화면을 구성하는 메소드
	 * @details		SearchRoomList(검색할 문자) 메소드를 호출하여 m_arrSearchRoomListData를 채우고<br>
	 *     			그 안의 값을 통해 m_SectionListItems를 채운다. 이후 ChatAdapter를 생성하여 SectionListAdapter에 넣고<br>
	 *     			listView에 새로운 SectionListAdapter를 적용하여준다.
	 * @param
	 * @return      void
	 */

	/**
	 * @brief       검색어를 통해 검색되어 보여질 목록을 만드는 메소드
	 * @details		m_arrChatroomListData로부터 data를 가져와 우선 방 이름으로 검색해 보고 검색이 되지 않은 경우 맴버들의 이름 검색을 한다.
	 * @param
	 * @return      void
	 */
	private ArrayList<ChatRoomListData> SearchRoomList(String a_keyword){
		a_keyword = a_keyword.trim().replace(" ","");
		m_arrSearchRoomListData = null;
		m_arrSearchRoomListData = new ArrayList<ChatRoomListData>();
		m_nSearchNormalNum = 0;
		m_nSearchFavoriteNum = 0;
		String strLowerKeyword = a_keyword.toLowerCase();
		//SectionListItem을 이용하면 검색을 한 상태에서 뒤로 돌아갈 때 현재 색션을 기준으로 하므로 전체검색이 아니게 된다.
		//즉 SectionListItem의 순서를 이용하면서 전체검색을 하고 싶으면 전체정보를 따로 저장해야 한다.
		if(a_keyword.length() != 0){
			for(ChatRoomListData data : m_arrChatRoomListData){
				//일반 방의 경우
				if(StringMatcher.match(data.getName().toLowerCase(),strLowerKeyword)){
					m_arrSearchRoomListData.add(data);
					if(data.getFavorite()){
						m_nSearchFavoriteNum++;
					} else {
						m_nSearchNormalNum++;
					}
					continue;
				}
				if(data.getMemberList()!= null){
					for (int j = 0; j < data.getMemberList().size() ; j++){
						if(data.getMemberList().get(j)!=null && StringMatcher.match(data.getMemberList().get(j).toLowerCase(),strLowerKeyword)){
							m_arrSearchRoomListData.add(data);
							if(data.getFavorite()){
								m_nSearchFavoriteNum++;
							} else {
								m_nSearchNormalNum++;
							}
							break;
						}
					}
				}else {

				}
			}
		}
		return m_arrSearchRoomListData;
	}

	private void SearchListViewUi(String a_Keyword){
		m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);

		SearchRoomList(a_Keyword.trim());

		if (m_SectionListItems == null)
			m_SectionListItems = new ArrayList<SectionListItem>();
		else
			m_SectionListItems.clear();

		SectionListItem item;
		if(m_arrSearchRoomListData != null){
			for(ChatRoomListData data : m_arrSearchRoomListData){
				if(data.getFavorite()) {
					item = new SectionListItem(data, getString(R.string.chat_favorite) + " " + m_nSearchFavoriteNum);
					m_SectionListItems.add(item);
				}
			}
		}

		if(m_arrSearchRoomListData != null){
			for(ChatRoomListData data : m_arrSearchRoomListData){
				if(!data.getFavorite()) {
					item = new SectionListItem(data, getString(R.string.chat_roomlist) + " " + m_nSearchNormalNum);
					m_SectionListItems.add(item);
				}
			}
		}

		if(m_SectionListItems.size() == 0){
			m_ChatFrameLayout.setVisibility(View.GONE);
			m_noListLayout.setVisibility(View.VISIBLE);
		}else {
			m_ChatFrameLayout.setVisibility(View.VISIBLE);
			m_noListLayout.setVisibility(View.GONE);
		/*m_SearchRoomListAdapter = new SearchRoomListAdapter(getContext());
		m_SearchRoomListAdapter.areAllItemsEnabled();*/
			m_ChatAdapter = new ChatListAdapter(getContext());
			m_ChatAdapter.areAllItemsEnabled();
			m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);
			m_ListView.setAdapter(m_SectionListAdapter);
			m_ListView.setOnScrollListener(new OnScrollListener() {
				@Override
				public void onScrollStateChanged(AbsListView view, int scrollState) {

				}

				@Override
				public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
					if (m_SectionListAdapter != null)
						m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
				}
			});
		}
	}

	/**
	 * @brief       방 번호를 전달받아 해당 방 번호 안의 유저정보를 이름의 리스트로 반환하는 메소드
	 * @param       a_roomId 방 번호(String)
	 * @return      ArrayList<String>
	 */
	public ArrayList<String> getChatRoomListMember(String a_roomId){
		ArrayList<String> list = null;
		//방 Id를 매개로 mapUserInfo에서 유저 리스트를 가져오고 유저 아이디를 매개로 mapUserListData에서 유저리스트에서 가져온 key값으로 AesData를 가져와 복호화 한 후 ArrayList에 담아 돌려준다.
		ArrayList<Integer> arrn_userList = m_mapUserInfoInChatRoom.get(a_roomId);
		if(arrn_userList!= null) {
			list = new ArrayList<>();
			HashMap<String, String> personalData = null;
			for(int i = 0 ; i < arrn_userList.size() ; i++){
				int userNo = arrn_userList.get(i);
				/*	String strAesData = m_mapUserListData.get(userNo);*/
				if(TTalkDBManager.ContactsDBManager.getContacts(m_Activity, userNo) == null){

				} else {
					personalData = TTalkDBManager.ContactsDBManager.getContacts(m_Activity, userNo).m_PersonalData.mapPersonalData;
				}
				if(personalData != null) {
					if (personalData.get(PersonalData.NAME) != null && !personalData.get(PersonalData.NAME).equals("")) {
						list.add(personalData.get(PersonalData.NAME));// 이름을 복호화 한 값을 list에 넣는다.
					}
				} else {
				}
			}
		}

		return list;    //해당 방의 유저의 이름 리스트가 들어가있다.
	}

	public ArrayList<ChatRoomListData> firstDataSort(ChatRoomListData a_data) {

		m_mapUserInfoInChatRoom = new HashMap<String,ArrayList<Integer>>();
		m_nFavoriteCount = 0;
		m_nNormalCount = 0;
		if (m_SectionListItems == null)
			m_SectionListItems = new ArrayList<SectionListItem>();

		ArrayList<ChatRoomListData> data = new ArrayList<ChatRoomListData>();

		ArrayList<ChattingRoomInfoData> roomInfoData = RoomDBManager.getChattingRoom(m_Activity);

		//현재 내 채팅방의 전체 정보를 DB로부터 가져와 해당 방 번호를 매개로 각 방 유저 정보를 DB로 부터 가져와 해당 리스트를 방ID를 key값 유저리스트를 value로 저장한다.
		for(int i = 0 ; i < roomInfoData.size() ; i++){
			if(roomInfoData.get(i).m_strRoomId.length() > 8) {
				ChattingDBManager dbMng = new ChattingDBManager(m_Activity);
				dbMng.openWritable(roomInfoData.get(i).m_strRoomId);
				ArrayList<Integer> memberList = dbMng.getChattingUser();
				dbMng.close();

				if (memberList != null)
					m_mapUserInfoInChatRoom.put(roomInfoData.get(i).m_strRoomId, memberList);
				else {
					memberList = new ArrayList<>();
					m_mapUserInfoInChatRoom.put(roomInfoData.get(i).m_strRoomId, memberList);
				}

			} else {
				ArrayList<Integer> memberList = new ArrayList<>();
				memberList.add(App.m_MyUserInfo.m_nUserNo);
				memberList.add(Integer.parseInt(roomInfoData.get(i).m_strRoomId));
				m_mapUserInfoInChatRoom.put(roomInfoData.get(i).m_strRoomId, memberList);
			}
		}

		for (int i = 0; i < roomInfoData.size(); i++) {

			ChatRoomListData chattingRoomInfoData = getLastMessage(roomInfoData.get(i));


			if (chattingRoomInfoData == null) {
				CommonLog.e(MainChatListFlag.class.getSimpleName(), "chattingRoomInfoData is null!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
				for (int j = 0; j < 5; j++) {
					chattingRoomInfoData = getLastMessage(roomInfoData.get(i));
					if (chattingRoomInfoData != null)
						break;
				}
			}
			if(chattingRoomInfoData != null){
				if (chattingRoomInfoData.getFavorite()) {
					m_nFavoriteCount += 1;
				} else {
					m_nNormalCount += 1;
				}
				chattingRoomInfoData.setMemberList(getChatRoomListMember(roomInfoData.get(i).m_strRoomId));
				if(a_data!=null && roomInfoData.get(i).m_strRoomId.equals(a_data.getRoomID()) && a_data.getBackgroundColor()!=0)
					chattingRoomInfoData.setBackgroundColor(a_data.getBackgroundColor());
				data.add(chattingRoomInfoData);
			}

		}

		// m_ChatAdapter.clear();

		return sortFellowListData(data);
	}

	public void firstFavoriteInit(ArrayList<ChatRoomListData> data) {
		m_ChatFrameLayout = (FrameLayout) m_vList.findViewById(R.id.layout_chat_list);
		m_noListLayout = (LinearLayout) m_vList.findViewById(R.id.layout_no_list);
		m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);
		m_SectionListItems.clear();
		m_arrChatRoomListData.clear();
		mapChatRoomListData.clear();

		for (int j = data.size() - 1; j >= 0; j--) {
			ChatRoomListData roomListData = data.get(j);
			if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
				RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
			} else {

				if (roomListData.getFavorite()) {
					if(roomListData.getRoomID().equals(((MainTabAct)m_Activity).getLastChatRoomId())){
						roomListData.setNosee(((MainTabAct)m_Activity).getLastChatRoomBadge());
					}
					item = new SectionListItem(roomListData, getString(R.string.chat_favorite) + " " + m_nFavoriteCount);
					m_SectionListItems.add(item);

					// m_ChatAdapter.add(roomListData);
					m_arrChatRoomListData.add(roomListData);
					mapChatRoomListData.put(roomListData.getRoomID(), roomListData);
				}
			}

		}

	}

	public void firstInit(ArrayList<ChatRoomListData> data) {

		for (int j = data.size() - 1; j >= 0; j--) {
			ChatRoomListData roomListData = data.get(j);
			if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
				RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
			} else {
				if (!roomListData.getFavorite()) {
					if(roomListData.getRoomID().equals(((MainTabAct)m_Activity).getLastChatRoomId())){
						roomListData.setNosee(((MainTabAct)m_Activity).getLastChatRoomBadge());
					}
					item = new SectionListItem(roomListData, getString(R.string.chat_roomlist) + " " + m_nNormalCount);
					m_SectionListItems.add(item);


					// m_ChatAdapter.add(roomListData);
					m_arrChatRoomListData.add(roomListData);
					mapChatRoomListData.put(roomListData.getRoomID(), roomListData);
				}
			}

		}



		m_ChatAdapter = new ChatListAdapter(m_Activity);
		m_ChatAdapter.areAllItemsEnabled();
		m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);

		m_ListView.setAdapter(m_SectionListAdapter);

		m_ListView.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub
				if (scrollState == SCROLL_STATE_IDLE) {
					m_isNowOnScroll = false;
					if (m_arrItemTrueList != null) {
						m_SectionListItems = new ArrayList<SectionListItem>(m_arrItemTrueList);
						if (m_arrNowOnInit.isEmpty() && m_ChatAdapter != null) {
							m_ChatAdapter.notifyDataSetChanged();
						}
						m_arrItemTrueList = null;
					}
				} else {
					m_isNowOnScroll = true;
				}
			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				m_nVisibleNumber = firstVisibleItem;
				if (m_SectionListAdapter != null)
					m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
			}
		});

		m_isFirstView = false;
	}

	public void init() {
		m_arrNowOnInit.add(true);
		PriorityAsyncUITask<Void, Void, ArrayList<ChatRoomListData>> task = new PriorityAsyncUITask<Void, Void, ArrayList<ChatRoomListData>>() {

			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				super.onPreExecute();

			}

			@Override
			protected ArrayList<ChatRoomListData> doInBackground(Void... params) {
				// TODO Auto-generated method stub
				// m_ChatAdapter = new ChatListAdapter(m_Activity);
				// m_ListView = (SectionListView)
				// m_vList.findViewById(R.id.lv_chat_list);
				//
				// m_SectionListAdapter = new
				// SectionListAdapter(m_Activity.getLayoutInflater(),
				// m_ChatAdapter);
				//
				// m_ListView.setAdapter(m_SectionListAdapter);


				return firstDataSort(null);
			}

			@Override
			protected void onPostExecute(ArrayList<ChatRoomListData> data) {
				// TODO Auto-generated method stub
				super.onPostExecute(data);

				boolean isSearch = false;

				if (m_isRunning) {
					// m_SectionListItems.clear();
					// m_arrChatRoomListData.clear();
					// mapChatRoomListData.clear();

					// 현재 검색 상태인 경우 검색화면을 재구성하도록 한다.(대화방 삭제,대화방 이름 변경시 적용됨.)
					if(m_isBeforeSearchStatus) {
						isSearch = true;
						m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);
						m_SectionListItems.clear();
						m_arrChatRoomListData.clear();
						mapChatRoomListData.clear();
						//즐겨찾기 부분 설정
						for (int j = data.size() - 1; j >= 0; j--) {
							ChatRoomListData roomListData = data.get(j);
							if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
								RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
							} else {

								if (roomListData.getFavorite()) {

									if(roomListData.getRoomID().equals(((MainTabAct)m_Activity).getLastChatRoomId())){
										roomListData.setNosee(((MainTabAct)m_Activity).getLastChatRoomBadge());
									}
									m_arrChatRoomListData.add(roomListData);
									mapChatRoomListData.put(roomListData.getRoomID(), roomListData);
								}
							}

						}

						//일반 대화방 부분 설정
						for (int j = data.size() - 1; j >= 0; j--) {
							ChatRoomListData roomListData = data.get(j);
							if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
								RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
							} else {
								if (!roomListData.getFavorite()) {
									if(roomListData.getRoomID().equals(((MainTabAct)m_Activity).getLastChatRoomId())){
										roomListData.setNosee(((MainTabAct)m_Activity).getLastChatRoomBadge());
									}
									m_arrChatRoomListData.add(roomListData);
									mapChatRoomListData.put(roomListData.getRoomID(), roomListData);
								}
							}

						}
						//검색어에 맞는 부분 추출
						SearchRoomList(m_currentSearchWord);
						//검색섹션 설정
						SectionListItem item;
						if(m_arrSearchRoomListData != null){
							for(ChatRoomListData listData : m_arrSearchRoomListData){
								if(listData.getFavorite()) {
									item = new SectionListItem(listData, getString(R.string.chat_favorite) + " " + m_nSearchFavoriteNum);
									m_SectionListItems.add(item);
								}
							}
						}

						if(m_arrSearchRoomListData != null){
							for(ChatRoomListData listData : m_arrSearchRoomListData){
								if(!listData.getFavorite()) {
									item = new SectionListItem(listData, getString(R.string.chat_roomlist) + " " + m_nSearchNormalNum);
									m_SectionListItems.add(item);
								}
							}
						}
					}
					else {
						m_ListView = (SectionListView) m_vList.findViewById(R.id.lv_chat_list);
						m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);
						m_ListView.setAdapter(m_SectionListAdapter);
						ArrayList<SectionListItem> tempList = new ArrayList<SectionListItem>();
						ArrayList<ChatRoomListData> tempChatRoomListData = new ArrayList<ChatRoomListData>();
						HashMap<String, ChatRoomListData> tempMapChatRoomListData = new HashMap<String, ChatRoomListData>();
						for (int j = data.size() - 1; j >= 0; j--) {
							ChatRoomListData roomListData = data.get(j);
							if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
								RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
							} else {

								if (roomListData.getFavorite()) {
									if (roomListData.getRoomID().equals(((MainTabAct) m_Activity).getLastChatRoomId())) {
										roomListData.setNosee(((MainTabAct) m_Activity).getLastChatRoomBadge());
									}
									item = new SectionListItem(roomListData, getString(R.string.chat_favorite) + " " + m_nFavoriteCount);
									// m_SectionListItems.add(item);
									// m_arrChatRoomListData.add(roomListData);
									// mapChatRoomListData.put(roomListData.getRoomID(),
									// roomListData);
									tempList.add(item);
									tempChatRoomListData.add(roomListData);
									tempMapChatRoomListData.put(roomListData.getRoomID(), roomListData);
								}
							}

						}
						for (int j = data.size() - 1; j >= 0; j--) {
							ChatRoomListData roomListData = data.get(j);
							if (roomListData.getRoomID().length() < 8 && roomListData.getText().equals("") && roomListData.getLastMessageTime() == 0) {
								RoomDBManager.deleteRoom(m_Activity, roomListData.getRoomID());
							} else {
								if (!roomListData.getFavorite()) {
									if (roomListData.getRoomID().equals(((MainTabAct) m_Activity).getLastChatRoomId())) {
										roomListData.setNosee(((MainTabAct) m_Activity).getLastChatRoomBadge());
									}
									item = new SectionListItem(roomListData, getString(R.string.chat_roomlist) + " " + m_nNormalCount);
									// m_SectionListItems.add(item);
									// m_arrChatRoomListData.add(roomListData);
									// mapChatRoomListData.put(roomListData.getRoomID(),
									// roomListData);
									tempList.add(item);
									tempChatRoomListData.add(roomListData);
									tempMapChatRoomListData.put(roomListData.getRoomID(), roomListData);
								}
							}

						}
						// boolean isCountChange = false;
						// if(m_SectionListItems.size() != tempList.size())
						// isCountChange = true;
						m_arrChatRoomListData = new ArrayList<ChatRoomListData>(tempChatRoomListData);
						mapChatRoomListData = new HashMap<String, ChatRoomListData>(tempMapChatRoomListData);

						if (m_SectionListItems.size() < tempList.size() && m_isNowOnScroll) {
							m_arrItemTrueList = new ArrayList<SectionListItem>(tempList);
							tempList.remove(tempList.size() - 1);
							m_SectionListItems = new ArrayList<SectionListItem>(tempList);
						} else {
							m_SectionListItems = new ArrayList<SectionListItem>(tempList);
						}
						if (m_arrEnteringRoom.size() != 0) {
							ChatRoomListData zeroData = null;
							String strZeroSection = "";
							int nPosition = 0;
							for (int xy = 0; xy < m_SectionListItems.size(); xy++) {
								zeroData = (ChatRoomListData) m_SectionListItems.get(xy).item;
								boolean isSame = false;
								for (int nRoomPosition = 0; nRoomPosition < m_arrEnteringRoom.size(); nRoomPosition++) {
									if (zeroData.getRoomID().equals(m_arrEnteringRoom.get(nRoomPosition))) {
										strZeroSection = m_SectionListItems.get(xy).section;
										nPosition = xy;
										isSame = true;
										m_arrEnteringRoom.remove(nRoomPosition);
										break;
									}
								}
								if (isSame) {
									break;
								}
							}
							if (zeroData != null) {
								//해당 방에 새 메시지가 온다고 해도, 현재 진입중이므로 표시 하지 않아도 된다.
								zeroData.setNosee(0);
								SectionListItem zeroItem = new SectionListItem(zeroData, strZeroSection);
								m_SectionListItems.set(nPosition, zeroItem);
							}

						} else {
							((MainTabAct) m_Activity).setChatListNoReadCountBadge(((MainTabAct) m_Activity).getLastChatRoomId());
						}
					}
					m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);
					m_ListView.setAdapter(m_SectionListAdapter);
					if(m_SectionListItems.size() == 0) {
						m_ChatFrameLayout.setVisibility(View.GONE);
						if(isSearch) {
							m_noListLayout.setVisibility(View.VISIBLE);
						}
					} else {
						m_ChatFrameLayout.setVisibility(View.VISIBLE);
						m_noListLayout.setVisibility(View.GONE);
					}
				}
				closeProgress();
				if (App.m_isRoomDelete)
					App.m_isRoomDelete = false;
				m_arrNowOnInit.remove(0);


				if(m_arrNowOnInit.isEmpty() && m_ChatAdapter != null){
					m_ChatAdapter.notifyDataSetChanged();
				}

			}
		};
		if(m_arrNowOnInit.size() < 2){
			task.execute();
		} else {
			m_arrNowOnInit.remove(0);
		}
	}

	public void changeData(String strRoomID, String strPacketID) {
		m_isbeforeChangeData = true;
		ChattingMessageData chattingMsg = null;
		String strRoomTitle = "";
		ChattingRoomInfoData roomInfoData = RoomDBManager.getChattingRoom(m_Activity, strRoomID);
		if(roomInfoData != null) {
			ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
			chattingDBMng.openReadable(strRoomID);
			// ArrayList<ChattingMessageData> arrChattingMessageData =
			// chattingDBMng.getChattingMessage();
			// chattingMsg =
			// arrChattingMessageData.get(arrChattingMessageData.size() - 1);
			chattingMsg = chattingDBMng.getChattingMessage(strPacketID);
			String text = null;
			if (chattingMsg.m_nMsgType == StaticString.CHAT_ROOM_MY_FILE || chattingMsg.m_nMsgType == StaticString.CHAT_ROOM_OTHER_FILE) {
				// 파일 이름과 클라우드 파일 이름이 상관없이 무조건 '파일', '클라우드'로 변경하기 위함
				try {
					JSONObject jsonObject = new JSONObject(chattingMsg.m_strMsgText);

					if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO))
						text = getString(R.string.chatlist_movie);
					else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL))
						text = getString(R.string.chatlist_file);
					else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT))
						text = getString(R.string.chatlist_contact);
				} catch (JSONException e) {
					e.printStackTrace();
				}

			} else if (chattingMsg.m_nMsgType == StaticString.CHAT_ROOM_MY_IMAGE || chattingMsg.m_nMsgType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
				text = getString(R.string.chatlist_image);
			} else {
				text = chattingMsg.m_strMsgText;
			}
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				strRoomTitle = crypto.decrypt(roomInfoData.m_strRoomTitle);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			int nNoReadMessageCount = 0;
			if (!chattingMsg.m_isRead) {
				if (chattingMsg.m_nMsgType != StaticString.CHAT_ROOM_SYSTEM_MSG && ((MainTabAct) m_Activity).getLastChatRoomId().equals(strRoomID)) {
					int nNowLastChatRoomBadge = ((MainTabAct) m_Activity).getLastChatRoomBadge();
					((MainTabAct) m_Activity).setLastChatRoomBadge(nNowLastChatRoomBadge + 1);
					nNoReadMessageCount = ((MainTabAct) m_Activity).getLastChatRoomBadge();
				} else {
					nNoReadMessageCount = chattingDBMng.getNoReadMessageCount();
				}
			} else {
				nNoReadMessageCount = chattingDBMng.getNoReadMessageCount();
			}

			ChatRoomListData protoRoomListData = new ChatRoomListData();

			protoRoomListData = new ChatRoomListData(roomInfoData.m_strRoomId, strRoomTitle, chattingMsg.m_nMsgType, text,
						chattingMsg.m_lnMsgSendTime, nNoReadMessageCount, roomInfoData.m_nRoomOwnerId, roomInfoData.m_isAlarmOn,
						chattingMsg.m_nSendStatus, roomInfoData.m_isFavorite,roomInfoData.m_backgroundColor, roomInfoData.m_isTitleEdited);

			final ChatRoomListData roomListData = protoRoomListData;

			chattingDBMng.close();
			// 이전 방 정보 삭제
			ChatRoomListData removeData = mapChatRoomListData.get(strRoomID);
			// 이전 방 정보가 없는데 changeData라면 새로 생성된 방이다
			if (removeData == null)
				m_nNormalCount += 1;
			m_arrChatRoomListData.remove(removeData);
			mapChatRoomListData.remove(strRoomID);
			m_arrChatRoomListData.add(0, roomListData);
			mapChatRoomListData.put(strRoomID, roomListData);

			getActivity().runOnUiThread(new Runnable() {
				public void run() {
					// m_ChatAdapter.clear();
					ArrayList<SectionListItem> tempList = new ArrayList<SectionListItem>();
					// m_SectionListItems.clear();

					for (int j = 0; j < m_arrChatRoomListData.size(); j++) {
						// m_ChatAdapter.add(m_arrChatRoomListData.get(j));
						if (m_arrChatRoomListData.get(j).getFavorite()) {
							item = new SectionListItem(m_arrChatRoomListData.get(j), getString(R.string.chat_favorite) + " " + m_nFavoriteCount);

							tempList.add(item);
						}
					}

					for (int j = 0; j < m_arrChatRoomListData.size(); j++) {
						// m_ChatAdapter.add(m_arrChatRoomListData.get(j));
						if (!m_arrChatRoomListData.get(j).getFavorite()) {
							item = new SectionListItem(m_arrChatRoomListData.get(j), getString(R.string.chat_roomlist) + " " + m_nNormalCount);

							tempList.add(item);
						}
					}
					if (m_SectionListItems.size() < tempList.size() && m_isNowOnScroll) {
						m_arrItemTrueList = new ArrayList<SectionListItem>(tempList);
						tempList.remove(tempList.size() - 1);
						m_SectionListItems = new ArrayList<SectionListItem>(tempList);
					} else {
						m_SectionListItems = new ArrayList<SectionListItem>(tempList);
					}
					if (m_arrNowOnInit.isEmpty() && m_ChatAdapter != null) {
						if(m_SectionListItems.size() == 0){
							m_ChatFrameLayout.setVisibility(View.GONE);
							m_noListLayout.setVisibility(View.VISIBLE);
						}else {
							m_ChatFrameLayout.setVisibility(View.VISIBLE);
							m_noListLayout.setVisibility(View.GONE);
							if(m_SectionListItems.size() == 1) {
								//아무런 방도 없을 경우 처리를 위함
								m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);
								m_ListView.setAdapter(m_SectionListAdapter);
							} else {
							}
						}
						m_ChatAdapter.notifyDataSetChanged();
					}


				}
			});
		}
		// m_ChatAdapter = new ChatListAdapter(m_Activity);
		// m_ChatAdapter.areAllItemsEnabled();
		// m_SectionListAdapter = new
		// SectionListAdapter(m_Activity.getLayoutInflater(), m_ChatAdapter);
		// m_ListView.setAdapter(m_SectionListAdapter);

	}

	public void setReadData(String strRoomID, ArrayList<String> arrPacketID){
		ChatRoomListData roomData = mapChatRoomListData.get(strRoomID);
		for(int i = 0; i < m_arrChatRoomListData.size(); i++){
			if(m_arrChatRoomListData.get(i).getRoomID().equals(strRoomID)){
				int nNoSee = roomData.getNosee();
				nNoSee = nNoSee - arrPacketID.size();
				roomData.setNosee(nNoSee);
				mapChatRoomListData.remove(strRoomID);
				mapChatRoomListData.put(strRoomID, roomData);
				m_arrChatRoomListData.set(i, roomData);
				if(m_arrNowOnInit.isEmpty() && m_ChatAdapter != null){
					getActivity().runOnUiThread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							m_ChatAdapter.notifyDataSetChanged();
						}
					});
				}
				break;
			}
		}
	}
	public void deleteData(String strRoomID) {
		// ChatRoomListData removeData = mapChatRoomListData.get(strRoomID);
		// m_arrChatRoomListData.remove(removeData);
		// mapChatRoomListData.remove(strRoomID);
		// getActivity().runOnUiThread(new Runnable() {
		// public void run() {
		// m_ChatAdapter.clear();
		// for (int j = 0; j < m_arrChatRoomListData.size(); j++) {
		// m_ChatAdapter.add(m_arrChatRoomListData.get(j));
		// }
		// m_ChatAdapter.notifyDataSetChanged();
		// }
		// });
		if(m_isPassOwner)
			m_isPassOwner = false;

		init();

		// final ArrayList<ChatRoomListData> data = firstDataSort();
		// getActivity().runOnUiThread(new Runnable() {
		//
		// @Override
		// public void run() {
		// // TODO Auto-generated method stub
		// firstFavoriteInit(data);
		// firstInit(data);
		// }
		// });

	}

	private ArrayList<ChatRoomListData> sortFellowListData(ArrayList<ChatRoomListData> a_Data) {

		Collections.sort(a_Data, myComparator);

		ArrayList<ChatRoomListData> roomData = new ArrayList<ChatRoomListData>();

		for (ChatRoomListData data : a_Data)
			roomData.add(data);

		return roomData;
	}

	private ChatRoomListData getLastMessage(final ChattingRoomInfoData data) {

		// GetLastMessageThread thread = new GetLastMessageThread(data);
		// thread.start();
		// try {
		// thread.join();
		// } catch (InterruptedException e) {
		// // TODO Auto-generated catch block
		// CommonLog.e(MainChatListFlag.class.getSimpleName(),
		// "GetLastMessageThread InterruptedException!!!!!!!!!!");
		// e.printStackTrace();
		// }
		//
		// return thread.getResultData();

		ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
		chattingDBMng.openReadable(data.m_strRoomId);
		// ArrayList<ChattingMessageData> arrChattingMessageData =
		// chattingDBMng.getChattingMessage();

		ChattingMessageData lastMessage = chattingDBMng.getCurrentMessage();
		ChatRoomListData roomData = null;
		if (lastMessage == null) {
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				roomData = new ChatRoomListData(data.m_strRoomId, crypto.decrypt(data.m_strRoomTitle), 0, "", 0, chattingDBMng.getNoReadMessageCount(),
						data.m_nRoomOwnerId, data.m_isAlarmOn, 2, data.m_isFavorite,data.m_backgroundColor, data.m_isTitleEdited);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			chattingDBMng.close();
			return roomData;
		} else {
			// ChattingMessageData lastMessage =
			// arrChattingMessageData.get(arrChattingMessageData.size() - 1);
			String text = null;
			if (lastMessage.m_nMsgType == StaticString.CHAT_ROOM_MY_FILE || lastMessage.m_nMsgType == StaticString.CHAT_ROOM_OTHER_FILE) {
				// 파일 이름과 클라우드 파일 이름이 상관없이 무조건 '파일', '클라우드'로 변경하기 위함
				try {
					JSONObject jsonObject = new JSONObject(lastMessage.m_strMsgText);

					if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO))
						text = getString(R.string.chatlist_movie);
					else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL))
						text = getString(R.string.chatlist_file);
					else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT))
						text = getString(R.string.chatlist_contact);
				} catch (JSONException e) {
					e.printStackTrace();
				}

			} else if (lastMessage.m_nMsgType == StaticString.CHAT_ROOM_MY_IMAGE || lastMessage.m_nMsgType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
				text = getString(R.string.chatlist_image);
			}  else {
				text = lastMessage.m_strMsgText;
			}
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				String strRoomTitle = crypto.decrypt(data.m_strRoomTitle);
				roomData = new ChatRoomListData(data.m_strRoomId, strRoomTitle, lastMessage.m_nMsgType, text,
						lastMessage.m_lnMsgSendTime, chattingDBMng.getNoReadMessageCount(), data.m_nRoomOwnerId, data.m_isAlarmOn, lastMessage.m_nSendStatus,
						data.m_isFavorite,data.m_backgroundColor, data.m_isTitleEdited);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			chattingDBMng.close();
			return roomData;
		}

	}

	public class ViewHolder {
		public TextView m_tvListName, m_tvListMessage, m_tvListNosee, m_tvListMessageTime, m_tvListUserCount;
		public ImageView m_ivprofile_pic, m_ivIcon, m_ivAlarm, m_ivStatus, m_iv_profile_pic_frame,m_iv_partner_icon,m_iv_side_favorite,m_iv_side_alarm;
		public ImageButton m_btnExit;
		public LinearLayout layout;
		public LinearLayout m_layoutExitRoom, m_layoutFavorite, m_layoutAlarm, m_layoutChangeName;
		public SwipeActionView m_layoutSwipe;
	}

	public class ChatListAdapter extends BaseAdapter {

		Context m_Context;
		LayoutInflater m_Inflater;
		ChatRoomListData m_Data;
		int m_nPosition;
		// TextView m_tvListName, m_tvListMessage, m_tvListNosee,
		// m_tvListMessageTime, m_tvListUserCount;
		// ImageView m_ivprofile_pic, m_ivIcon, m_ivAlarm, m_ivStatus;
		// ImageButton m_btnExit;

		ViewHolder viewHolder;

		public ChatListAdapter(Context context) {

			m_Context = context;
			// m_Inflater = LayoutInflater.from(context);
			m_Inflater = (LayoutInflater) m_Activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			// TODO Auto-generated constructor stub
		}



		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			m_Data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
			// m_Data = getItem(position);
			//int viewType = getItemViewType(position) ;

			if (convertView == null) {
				viewHolder = new ViewHolder();
				convertView = m_Inflater.inflate(R.layout.layout_chat_listitem, parent, false);

				viewHolder.layout = (LinearLayout) convertView.findViewById(R.id.layout_chat_listitem);
				viewHolder.m_layoutSwipe = (SwipeActionView) convertView.findViewById(R.id.layout_chat_swipe);
				viewHolder.m_layoutSwipe.setSwipeGestureListener(new SwipeGestureListener() {
					@Override
					public boolean onSwipedLeft(@NotNull final SwipeActionView swipeActionView) {
						((MainTabAct)m_Activity).setSwipeView(swipeActionView);
						return false;
					}

					@Override
					public boolean onSwipedRight(@NotNull SwipeActionView swipeActionView) {
						((MainTabAct)m_Activity).setSwipeView(swipeActionView);
						return false;
					}
				});
				viewHolder.m_tvListName = (TextView) convertView.findViewById(R.id.tv_chatlist_name);
				viewHolder.m_tvListMessage = (TextView) convertView.findViewById(R.id.tv_chatlist_chat);
				viewHolder.m_tvListNosee = (TextView) convertView.findViewById(R.id.tv_chatlist_nosee);
				viewHolder.m_ivprofile_pic = (ImageView) convertView.findViewById(R.id.iv_profile_pic);
				viewHolder.m_iv_profile_pic_frame = (ImageView) convertView.findViewById(R.id.iv_profile_pic_frame);
				viewHolder.m_iv_partner_icon = (ImageView) convertView.findViewById(R.id.iv_chatlist_icon_partner);
				viewHolder.m_tvListMessageTime = (TextView) convertView.findViewById(R.id.tv_chatlist_time);
				viewHolder.m_tvListUserCount = (TextView) convertView.findViewById(R.id.tv_profile_num);
				viewHolder.m_ivIcon = (ImageView) convertView.findViewById(R.id.iv_chatlist_icon);
				viewHolder.m_btnExit = (ImageButton) convertView.findViewById(R.id.btn_chatlist_exit);
				viewHolder.m_ivAlarm = (ImageView) convertView.findViewById(R.id.iv_chatlist_alarm);
				viewHolder.m_ivStatus = (ImageView) convertView.findViewById(R.id.iv_chatlist_alert);
				viewHolder.m_layoutExitRoom = (LinearLayout) convertView.findViewById(R.id.layout_sidemenu_exitroom);
				viewHolder.m_layoutFavorite = (LinearLayout) convertView.findViewById(R.id.layout_sidemenu_favorite);
				viewHolder.m_iv_side_favorite = (ImageView) convertView.findViewById(R.id.iv_side_favorite);
				viewHolder.m_layoutAlarm = (LinearLayout) convertView.findViewById(R.id.layout_sidemenu_alarm);
				viewHolder.m_iv_side_alarm = (ImageView) convertView.findViewById(R.id.iv_side_alarm);
				viewHolder.m_layoutChangeName = (LinearLayout) convertView.findViewById(R.id.layout_sidemenu_changename);

				convertView.setTag(viewHolder);
			} else {
				viewHolder = (ViewHolder) convertView.getTag();
			}
			if (m_Data != null) {
				if (m_Data.getRoomID().length() > 8) {
					ChattingDBManager chattingDBMng = new ChattingDBManager(m_Context);
					chattingDBMng.openReadable(m_Data.getRoomID());
					ArrayList<Integer> arrUserNo = chattingDBMng.getChattingUser();
					chattingDBMng.close();
					viewHolder.m_tvListUserCount.setText("" + arrUserNo.size());
					UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_Data.getOwnerID());
					if (userData != null && userData.m_isImageAvailable) {
						App.imageloader.cancelDownload(viewHolder.m_ivprofile_pic);

						App.imageloader.getProfileImage(viewHolder.m_ivprofile_pic, App.getImageDownLoaderUrl(m_Data.getOwnerID(), true),
								R.drawable.profile_pic_default, false);

					} else {
						App.imageloader.cancelDownload(viewHolder.m_ivprofile_pic);
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.profile_pic_default);
					}

					if(userData != null && userData.m_strUserType.equals("R")){
						viewHolder.m_iv_partner_icon.setVisibility(View.GONE);
					} else {
						viewHolder.m_iv_partner_icon.setVisibility(View.VISIBLE);
					}

					if (arrUserNo.size() == 1) {
						viewHolder.m_tvListUserCount.setVisibility(View.GONE);
						viewHolder.m_iv_partner_icon.setVisibility(View.GONE);
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.profile_pic_default);
						if(m_Data.getTitleEdited()){
							viewHolder.m_tvListName.setText(m_Data.getName());
						} else {
							viewHolder.m_tvListName.setText(R.string.layout_chatroom_nobody);
						}
					}
					else {
						viewHolder.m_tvListUserCount.setVisibility(View.VISIBLE);
						viewHolder.m_tvListName.setText(m_Data.getName());
					}
					viewHolder.m_layoutAlarm.setVisibility(View.VISIBLE);
				} else {
					UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, Integer.parseInt(m_Data.getRoomID()));
					if (userData != null && userData.m_nUserNo == App.m_MyUserInfo.m_nUserNo) {
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.img_profile_cork);
					} else if (userData != null && userData.m_isImageAvailable) {
						App.imageloader.cancelDownload(viewHolder.m_ivprofile_pic);
						App.imageloader.getProfileImage(viewHolder.m_ivprofile_pic, App.getImageDownLoaderUrl(Integer.parseInt(m_Data.getRoomID()), true),
									R.drawable.profile_pic_default, false);

					} else {
						App.imageloader.cancelDownload(viewHolder.m_ivprofile_pic);
						viewHolder.m_ivprofile_pic.setImageResource(R.drawable.profile_pic_default);
					}
					if(userData.m_strUserType.equals("R")){
						viewHolder.m_iv_partner_icon.setVisibility(View.GONE);
					} else {
						viewHolder.m_iv_partner_icon.setVisibility(View.VISIBLE);
					}
					viewHolder.m_tvListName.setText(m_Data.getName());
					viewHolder.m_tvListUserCount.setVisibility(View.GONE);
					viewHolder.m_layoutAlarm.setVisibility(View.GONE);
				}

				if(m_Data.getFavorite())
					viewHolder.m_iv_side_favorite.setBackgroundResource(R.drawable.btn_btn_talk_star_on);
				else
					viewHolder.m_iv_side_favorite.setBackgroundResource(R.drawable.btn_btn_talk_star);

				if(m_Data.getAlarm())
					viewHolder.m_iv_side_alarm.setBackgroundResource(R.drawable.btn_btn_talk_alarm);
				else
					viewHolder.m_iv_side_alarm.setBackgroundResource(R.drawable.btn_btn_talk_alarm_off);

				EmoticonUtils utils = new EmoticonUtils();
				viewHolder.m_ivIcon.setVisibility(View.GONE);
				if (m_Data.getType() == StaticString.CHAT_ROOM_MY_FILE || m_Data.getType() == StaticString.CHAT_ROOM_OTHER_FILE) {
					if (m_Data.getText().equals(getString(R.string.chatlist_movie))) {
						viewHolder.m_ivIcon.setVisibility(View.VISIBLE);
						viewHolder.m_ivIcon.setImageResource(R.drawable.icon_talk_movie);
					} else {
						viewHolder.m_ivIcon.setVisibility(View.VISIBLE);
						if (m_Data.getText().equals(getString(R.string.chatlist_file)))
							viewHolder.m_ivIcon.setImageResource(R.drawable.icon_talk_file);
						else if (m_Data.getText().equals("클라우드"))
							viewHolder.m_ivIcon.setImageResource(R.drawable.icon_cloud);
						else if (m_Data.getText().equals(getString(R.string.chatlist_contact)))
							viewHolder.m_ivIcon.setImageResource(R.drawable.icon_talk_tel);
					}
				} else if (m_Data.getType() == StaticString.CHAT_ROOM_MY_IMAGE || m_Data.getType() == StaticString.CHAT_ROOM_OTHER_IMAGE) {
					viewHolder.m_ivIcon.setVisibility(View.VISIBLE);
					viewHolder.m_ivIcon.setImageResource(R.drawable.icon_talk_photo);
				}
				// 파일, 클라우드시 파일 이름 보여주지 않고 그냥 '파일', '클라우드'로 적용
				// if (m_Data.getText().equals(getString(R.string.chatlist_movie)) ||
				// m_Data.getText().equals(getString(R.string.chatlist_image)))
				// m_tvListMessage.setText(utils.parsingEmoticonText(m_Context,
				// m_Data.getText(), (int) m_tvListMessage.getTextSize()));
				// else{
				// String strText = m_Data.getText().split("\\*")[0];
				String strText = m_Data.getText();
				String strLastChar = " ";
				String strFirstChar = " ";

				if (strText != null && strText.trim().length() != 0) {
					while (strLastChar.equals(" ") || strLastChar.equals("\n")) {
						strLastChar = (String) strText.subSequence(strText.length() - 1, strText.length());
						if (strLastChar.equals(" ") || strLastChar.equals("\n")) {
							strText = (String) strText.subSequence(0, strText.length() - 1);
						}
					}
					while (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
						strFirstChar = (String) strText.subSequence(0, 1);
						if (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
							strText = (String) strText.subSequence(1, strText.length());
						}
					}
				}
				viewHolder.m_tvListMessage.setText(utils.parsingEmoticonText(m_Context, strText, (int) viewHolder.m_tvListMessage.getTextSize()));

				// }
				if (m_Data.getAlarm()) {
					viewHolder.m_ivAlarm.setVisibility(View.GONE);
				} else {
					viewHolder.m_ivAlarm.setVisibility(View.VISIBLE);
				}

				if (m_Data.getStatus() != 2) {
					viewHolder.m_ivStatus.setVisibility(View.VISIBLE);
				} else {
					viewHolder.m_ivStatus.setVisibility(View.GONE);
				}
				// 마지막 메세지 시간
				String patternFull = "yyyyMMdd";
				SimpleDateFormat formatFull = new SimpleDateFormat(patternFull);
				String strLastMassageDate = (String) formatFull.format(new Timestamp(m_Data.getLastMessageTime()));

				// 지금 시간
				String strTodayDate = (String) formatFull.format(new Timestamp(System.currentTimeMillis()));
				// 어제 시간
				// String strYesterDay = (String) formatFull.format(new
				// Timestamp(System.currentTimeMillis() - 86400));
				String pattern = null;
				if (strLastMassageDate.equals(strTodayDate)) {
					pattern = "a h:mm";
				} else if (((Integer.parseInt(strTodayDate) / 10000) != Integer.parseInt(strLastMassageDate) / 10000)) {
					pattern = "yyyy.M.d";
				} else {
					pattern = "M.d.";
				}

				// UserListData userData;
				SimpleDateFormat format = new SimpleDateFormat(pattern);
				String date = (String) format.format(new Timestamp(m_Data.getLastMessageTime()));
				viewHolder.m_tvListMessageTime.setText("");
				if ((Integer.parseInt(strTodayDate) - Integer.parseInt(strLastMassageDate)) == 1) {
					viewHolder.m_tvListMessageTime.setText(getString(R.string.etc_yesterday));
				} else if (m_Data.getLastMessageTime() != 0) {
					viewHolder.m_tvListMessageTime.setText(date);
				}
				int nNoSeeCount = m_Data.getNosee();

				if (nNoSeeCount > 0) {
					// 안본 개수가 1개 이상일때 보여짐.
					if (nNoSeeCount > 999)
						viewHolder.m_tvListNosee.setText("999+");
					else
						viewHolder.m_tvListNosee.setText("" + nNoSeeCount);
					viewHolder.m_tvListNosee.setVisibility(View.VISIBLE);
				} else {
					// 0개일 경우에는 Gone
					viewHolder.m_tvListNosee.setVisibility(View.GONE);
				}
				//배경색 설정
				if(m_Data.getBackgroundColor() != 0)
					viewHolder.layout.setBackgroundColor(m_Data.getBackgroundColor());
				else
					viewHolder.layout.setBackgroundResource(R.drawable.chatroom_listitem_selecter);
			}
			//대화방리스트의 스와이프 기능이 터치 이벤트를 먼저 가져 가는 듯 함
			//리스트 내부의 뷰에 대한 클릭 이벤트가 부모로 전달이 되지 않는다.
			//duplicateparentsate 도 먹히지 않음
			//억지로 touchListener로 구현
			viewHolder.m_tvListName.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if(event.getAction() == MotionEvent.ACTION_UP) {
						ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
						clickLayout(data);
					}

					return false;
				}
			});
			viewHolder.m_tvListName.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

				}
			});
			viewHolder.m_tvListMessage.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if(event.getAction() == MotionEvent.ACTION_UP) {
						ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
						clickLayout(data);
					}

					return false;
				}
			});
			viewHolder.m_tvListMessage.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

				}
			});
			viewHolder.layout.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
					clickLayout(data);
				}
			});
			// 알림끄기 아이콘이 있을때는 방제목과 채팅 텍스트 오른쪽에 마진 20
			viewHolder.m_layoutFavorite.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					final ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
					setFavorite(data);
					/*if(data.getFavorite())
						setFavorite(data);
					else
						setFavoriteBackgroundColor(data);*/
				}
			});
			viewHolder.m_layoutAlarm.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					final ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;

					boolean isAlarm = data.getAlarm();
					TTalkDBManager.RoomDBManager.updateRoom(m_Context, data.getRoomID(), !isAlarm);

					if(isAlarm){
						((MainTabAct)m_Activity).mService.requestOnOff("off", data.getRoomID());
					} else {
						((MainTabAct)m_Activity).mService.requestOnOff("on", data.getRoomID());
					}

					init();
				}
			});
			viewHolder.m_layoutChangeName.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					final ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
					onTitleChange(data);
				}
			});
			viewHolder.m_layoutExitRoom.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					final ChatRoomListData data = (ChatRoomListData) m_SectionListItems.get(nPosition).item;
					onExitRoom(data);
				}
			});

			return convertView;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			if (m_SectionListItems != null)
				return m_SectionListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_SectionListItems != null)
				return m_SectionListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub
			super.notifyDataSetChanged();
		}

		public void clickLayout(ChatRoomListData data){
			if (data.getRoomID().length() < 8) {

				m_arrEnteringRoom.add(data.getRoomID());

				((MainTabAct) m_Activity).removeChatRoomReadReceiver();

				((MainTabAct) getActivity()).setLastChatRoomId(data.getRoomID());
				((MainTabAct) getActivity()).setLastChatRoomBadge(0);
				int nNoSeeCount = data.getNosee();
				int nBadgeCount = ((MainTabAct) getActivity()).getChatListNoReadCountBadge();
				((MainTabAct) getActivity()).setChatListNoReadCountBadge(nBadgeCount - nNoSeeCount);

				Intent intent = new Intent(m_Context, ChatRoomAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, Integer.parseInt(data.getRoomID()));
				startActivity(intent);
				// m_isFirstView = true;
				data.setLastMessageTime();
				data.setLastMessageStatus();
				m_ChatAdapter.notifyDataSetChanged();
			} else {

				m_arrEnteringRoom.add(data.getRoomID());

				((MainTabAct) m_Activity).removeChatRoomReadReceiver();

				((MainTabAct) getActivity()).setLastChatRoomId(data.getRoomID());
				((MainTabAct) getActivity()).setLastChatRoomBadge(0);
				int nNoSeeCount = data.getNosee();
				int nBadgeCount = ((MainTabAct) getActivity()).getChatListNoReadCountBadge();
				((MainTabAct) getActivity()).setChatListNoReadCountBadge(nBadgeCount - nNoSeeCount);

				Intent intent = new Intent(m_Context, ChatRoomGroupAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_MAKE_ROOMID, data.getRoomID());
				intent.putExtra(IntentKeyString.INTENT_KEY_NO_MAKE_ROOM, "yes");
				if (data.getRoomID().split("\\_").length == 3) {
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPCHAT_ID, Integer.parseInt(data.getRoomID().split("\\_")[2]));
					ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(m_Context, data.getRoomID());
					intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPCHAT_NAME, roomData.m_strRoomTitle);
				}
				startActivity(intent);
				// m_isFirstView = true;
				data.setLastMessageTime();
				data.setLastMessageStatus();
				m_ChatAdapter.notifyDataSetChanged();
			}
		}
	}

	private final static Comparator<ChatRoomListData> myComparator = new Comparator<ChatRoomListData>() {
		private final Collator collator = Collator.getInstance();

		@Override
		public int compare(ChatRoomListData lhs, ChatRoomListData rhs) {
			// TODO Auto-generated method stub
			return collator.compare(Long.toString(lhs.getLastMessageTime()), Long.toString(rhs.getLastMessageTime()));
		}

	};


	public void setFavorite(ChatRoomListData data){
		if (data.getFavorite()) {
			m_nBackgroundColor = 0;
			TTalkDBManager.RoomDBManager.updateRoomBackgroundColor(getContext(), data.getRoomID(), m_nBackgroundColor);
			TTalkDBManager.RoomDBManager.updateRoomFavorite(m_Activity, data.getRoomID(), false);
			((MainTabAct) getActivity()).mService.delChatFavorite(data.getRoomID());
		} else {
			TTalkDBManager.RoomDBManager.updateRoomFavorite(m_Activity, data.getRoomID(), true);
			((MainTabAct) getActivity()).mService.addChatFavorite(data.getRoomID());
		}
		final ArrayList<ChatRoomListData> favoriteData = firstDataSort(data);
		getActivity().runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method
				// stub
				firstFavoriteInit(favoriteData);
				firstInit(favoriteData);
				if(et_search_keyword.length() > 0){
					SearchListViewUi(et_search_keyword.getText().toString());
				}
			}
		});
	}

	MainTabAct.OnNotifyChatListListener m_NotifyListner = new MainTabAct.OnNotifyChatListListener() {

		@Override
		public void onNotify(String strRoomID, String strPacketID) {
			// TODO Auto-generated method stub

			// init();
			// PacketID가 null 이면 삭제
			if (strPacketID != null) {
				//if (!m_isNowOnInit) {
				changeData(strRoomID, strPacketID);
				// init();
				//}
			} else {
				// if (!m_isNowOnInit) {
				deleteData(strRoomID);
				// }
			}

		}

		@Override
		public void onResumeScreen() {
			// TODO Auto-generated method stub
			init();
		}

		@Override
		public void onReadNotify(String strRoomID, ArrayList<String> arrPacketID) {
			// TODO Auto-generated method stub
			setReadData(strRoomID, arrPacketID);
		}

	};

	public class setNotifyDataTask extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			return null;
		}

		protected void onPostExecute(Void Void) {

			// firstInit();

		}

	}

	public void onTitleChange(final ChatRoomListData chatRoomListData) {
		Intent intent;

		intent = new Intent(m_Activity, CommonPopupTitleNameAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BTNTYPE, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
		intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_TITLE, m_Activity.getString(R.string.pop_set_title_name));
		intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BODY, m_Activity.getString(R.string.pop_set_title_name_text));
		intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, chatRoomListData.getRoomID());
		startActivityForResult(intent, REQUEST_CODE_TITLE_CHANGE);
		// m_isFirstView = true;
	}

	public void onExitRoom(final ChatRoomListData chatRoomListData) {

		ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
		chattingDBMng.openReadable(chatRoomListData.getRoomID());
		ArrayList<Integer> arrUserNo = chattingDBMng.getChattingUser();
		chattingDBMng.close();
		if (chatRoomListData.getRoomID().length() > 8 && chatRoomListData.getOwnerID() == App.m_MyUserInfo.m_nUserNo && arrUserNo.size() != 1) {

			m_Popup = new CommonPopup(m_Activity, new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					switch (v.getId()) {
						case R.id.ib_pop_ok_long:
							CommonPopup popup_cancel = (CommonPopup) v.getTag();
							popup_cancel.cancel();
							break;

						default:
							break;
					}
				}
			}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_exit_room_title), getString(R.string.popup_exit_room_text_owner));
		} else {

			m_Popup = new CommonPopup(m_Activity, new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					switch (v.getId()) {
						case R.id.ib_pop_ok:
							CommonPopup popup_ok = (CommonPopup) v.getTag();
							if (chatRoomListData.getRoomID().length() < 8) {
								showProgress();
							/*PostOneRoomSyncReq req = new PostOneRoomSyncReq(chatRoomListData.getRoomID());
							WebAPI webApi = new WebAPI(m_Activity);
							webApi.request(req, new WebListener() {

								@Override
								public void onPreRequest() {
									// TODO Auto-generated method stub

								}

								@Override
								public void onNetworkError(int nErrorCode, String strMessage) {
									// TODO Auto-generated method stub
									closeProgress();
									m_Popup = new CommonPopup(m_Activity, MainChatListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
									m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
									m_Popup.setCancelable(false);
									isCheckShowPopup();
								}

								@Override
								public void onPostRequest(String a_strData) {
									// TODO Auto-generated method stub
									RoomDBManager.deleteRoom(m_Activity, chatRoomListData.getRoomID());
									App.m_isRoomDelete = true;
									ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
									chattingDBMng.openWritable(chatRoomListData.getRoomID());
									chattingDBMng.deleteChattingUser();
									chattingDBMng.deleteChattingMessage();
									chattingDBMng.close();
									// setNotifyDataTask task = new setNotifyDataTask();
									// task.execute();
									deleteData(chatRoomListData.getRoomID());
									((MainTabAct) m_Activity).setChatListNoReadCountBadge(((MainTabAct)m_Activity).getLastChatRoomId());
									PushController.cancelNotification(m_Activity, chatRoomListData.getRoomID());
								}

							});*/
								RoomDBManager.deleteRoom(m_Activity, chatRoomListData.getRoomID());
								App.m_isRoomDelete = true;
								ChattingDBManager chattingDBMng = new ChattingDBManager(m_Activity);
								chattingDBMng.openWritable(chatRoomListData.getRoomID());
								chattingDBMng.deleteChattingUser();
								chattingDBMng.deleteChattingMessage();
								chattingDBMng.close();
								// setNotifyDataTask task = new setNotifyDataTask();
								// task.execute();
								deleteData(chatRoomListData.getRoomID());
								((MainTabAct) m_Activity).setChatListNoReadCountBadge(((MainTabAct) m_Activity).getLastChatRoomId());
								PushController.cancelNotification(m_Activity, chatRoomListData.getRoomID());
							} else {

								App.m_isRoomDelete = true;
								showProgress();
								((MainTabAct) m_Activity).exitRoom(chatRoomListData.getRoomID());

							}
							popup_ok.cancel();
							break;
						case R.id.ib_pop_cancel:
							CommonPopup popup_cancel = (CommonPopup) v.getTag();
							popup_cancel.cancel();
							break;
						default:
							break;
					}
				}
			}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_exit_room_title), getString(R.string.popup_exit_room_text));
		}
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
			m_nProgressCount++;
			Handler mHandler = new Handler();
			mHandler.postDelayed(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					m_nDoneProgressCount++;
					if (m_Progress != null && m_Progress.isShowing() && m_nDoneProgressCount == m_nProgressCount) {
						m_Progress.cancel();
						m_Popup = new CommonPopup(m_Activity, MainChatListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
				}

			}, 10000);
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
			m_nProgressCount++;
			Handler mHandler = new Handler();
			mHandler.postDelayed(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					m_nDoneProgressCount++;
					if (m_Progress != null && m_Progress.isShowing() && m_nDoneProgressCount == m_nProgressCount) {
						m_Progress.cancel();
						m_Popup = new CommonPopup(m_Activity, MainChatListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}
				}

			}, 10000);
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
			case R.id.ib_pop_ok_long:
				CommonPopup popup_ok_long = (CommonPopup)v.getTag();
				popup_ok_long.cancel();

				break;
			case R.id.ib_pop_ok:
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				popup_ok.cancel();

				break;
			case R.id.ib_pop_cancel:
				CommonPopup popup_cancel = (CommonPopup)v.getTag();
				popup_cancel.cancel();

				break;
		}
	}

	private void isCheckShowPopup() {
		if (m_isRunning) {
			m_Popup.show();
		}
	}
}