package com.gmp.rusk.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Base64;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.act.IntroAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManagerForDelayMessage;
import com.gmp.rusk.extension.ChannelEx;
import com.gmp.rusk.extension.ChannelInviteEx;
import com.gmp.rusk.extension.ClearEx;
import com.gmp.rusk.extension.DelayEx;
import com.gmp.rusk.extension.DelayInformationProviderTTalk;
import com.gmp.rusk.extension.DelayInformationTTalk;
import com.gmp.rusk.extension.EmoticonEx;
import com.gmp.rusk.extension.FileEx;
import com.gmp.rusk.extension.FileReceivedEx;
import com.gmp.rusk.extension.GroupChatsEx;
import com.gmp.rusk.extension.GroupNoticeEx;
import com.gmp.rusk.extension.IQAlarmEx;
import com.gmp.rusk.extension.IQKickErrorEx;
import com.gmp.rusk.extension.IQMaxUserErrorEx;
import com.gmp.rusk.extension.IQQuitErrorEx;
import com.gmp.rusk.extension.IQRoomTitleEx;
import com.gmp.rusk.extension.IQUsersEx;
import com.gmp.rusk.extension.InviteMyEx;
import com.gmp.rusk.extension.KickEx;
import com.gmp.rusk.extension.KickMyEx;
import com.gmp.rusk.extension.OwnerEx;
import com.gmp.rusk.extension.PCSingleMessageEx;
import com.gmp.rusk.extension.PCSyncEx;
import com.gmp.rusk.extension.PCSystemEx;
import com.gmp.rusk.extension.QuitEx;
import com.gmp.rusk.extension.QuitMyEx;
import com.gmp.rusk.extension.ReadEx;
import com.gmp.rusk.extension.ReceivedEx;
import com.gmp.rusk.extension.RoomTitleChangeEx;
import com.gmp.rusk.extension.RoomsEx;
import com.gmp.rusk.extension.UserEx;
import com.gmp.rusk.network.PriorityAsyncTask;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.AppSetting.APISERVER_LIST;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionConfiguration.SecurityMode;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.PacketCollector;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.Roster.SubscriptionMode;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.AndFilter;
import org.jivesoftware.smack.filter.IQTypeFilter;
import org.jivesoftware.smack.filter.PacketExtensionFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketIDFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.Presence.Type;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smackx.OfflineMessageManager;
import org.jivesoftware.smackx.packet.OfflineMessageInfo;
import org.jivesoftware.smackx.packet.OfflineMessageRequest;
import org.jivesoftware.smackx.provider.DataFormProvider;
import org.jivesoftware.smackx.provider.DiscoverInfoProvider;
import org.jivesoftware.smackx.provider.DiscoverItemsProvider;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class XmppConnectionService extends Service {

	public MyApp App = MyApp.getInstance();
	// private final String DEV_SERVER_URL = "ttalktest.uangel.com";
	//기존 개발 서버
//	private final String DEV_SERVER_URL = "192.168.1.146";
	//GMP 개발 서버
	private final String DEV_SERVER_URL = "devcorkx.toktok.sk.com";
//	private final String DEV_SERVER_URL = "jupiter.uangel.com"; //내부 메신저 용
	//2016년 고도화 개발 서버
//	private final String DEV_SERVER_URL = "211.188.179.15";

	private final String COMMON_SERVER_URL = "corkx.toktok.sk.com";
	//private final String COMMON_SERVER_URL = "61.250.22.115";
	//상용 서버
	private final int SERVER_PORT = 5222;
	//개발 서버
//	private final int SERVER_PORT = 7012;
	//GMP 서버 포트
//	private final int SERVER_PORT = 5222;
	//2016 고도화 개발 서버 포트
//	private final int SERVER_PORT = 35222;
	static final String SERVICE_NAME = "cork.com";
	static final String TAG = XmppConnectionService.class.getSimpleName();
	private boolean m_isSuccessGetOfflineMessage = true;

	private final IBinder mBinder = new LocalBinder(); // 컴포넌트에 반환되는 IBinder

	XMPPConnection connection;
	LoginTask task = null;
	public static Queue<Packet> m_queuePacket;

	OfflineMessageManager m_OfflineManager = null;

	boolean m_isLogin = false;

	public Handler mHandler;
	long lnEditTime;


	// 그룹채팅방에 DB에 없는 사용자가 있을시 처리를 위함
	ArrayList<UserListData> m_arrDBSetUser = new ArrayList<UserListData>();

	private boolean m_isServiceAlive = false;

	static {
		m_queuePacket = new LinkedList<Packet>();
	}

	private ChattingDBManagerForDelayMessage m_DelayMessageDB;

	XmppSendPacket m_XmppSendPacket;
	XmppListener m_XmppListener;

	// 컴포넌트에 반환해줄 IBinder를 위한 클래스
	public class LocalBinder extends Binder {
		public XmppConnectionService getService() {
			return XmppConnectionService.this;
		}
	}

	
	@Override
	public void onCreate() {
		super.onCreate();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		CommonLog.e(TAG, "onBind");
		m_isServiceAlive = true;
		CommonLog.e(TAG, "On bind Packet IsEmpty : " + m_queuePacket.isEmpty());
		ConnectionConfiguration connConfig;
		if (AppSetting.USING_SERVER == APISERVER_LIST.DEV_SERVER)
			connConfig = new ConnectionConfiguration(DEV_SERVER_URL, SERVER_PORT, SERVICE_NAME);
		else {
			connConfig = new ConnectionConfiguration(COMMON_SERVER_URL, SERVER_PORT, SERVICE_NAME);
		}
		connConfig.setSASLAuthenticationEnabled(false);
		connConfig.setReconnectionAllowed(true);
		connConfig.setSecurityMode(SecurityMode.enabled);
		connConfig.setSendPresence(false);
		connection = new XMPPConnection(connConfig);
		m_XmppSendPacket = new XmppSendPacket(connection, getApplicationContext());
		m_XmppListener = new XmppListener();
		
		Roster roster = connection.getRoster();
		roster.setSubscriptionMode(SubscriptionMode.accept_all);
		if (!connection.isConnected()) {
			if (!m_isLogin) {
				if (task == null) {
					task = new LoginTask();
				}

				if (!task.isRunning())
					task.execute();
			}
		}
		mHandler = new Handler();

		// m_hConnectionCheck.sendEmptyMessage(0);
		return mBinder;
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		CommonLog.e(TAG, "onUnBind");
		// m_hConnectionCheck.removeMessages(0);
		if (connection.isConnected()) {

			new DisconnectAsync().execute();
			CommonLog.e(TAG, "Disconnecte Success");
		}

		if (task != null) {
			m_isLogin = false;
			task = null;
			CommonLog.e(TAG, "Task null Success");
		}

		m_isServiceAlive = false;
		return super.onUnbind(intent);
	}

	class DisconnectAsync extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... params) {
			connection.disconnect();
			return null;
		}
	}
	// 일반 채팅
	public void addIntroPacketListener(IntroAct.PacketListener aPacketListener) {
		m_XmppListener.addIntroPacketListener(aPacketListener);
	}

	public void removeIntroPacketListener() {
		m_XmppListener.removeIntroPacketListener();
	}
	// 메인 탭
	public void addNotifyListner(MainTabAct.OnNotifyListener aNotifyListener) {
		m_XmppListener.addNotifyListner(aNotifyListener);
	}

	public void removeNotifyListener() {
		m_XmppListener.removeNotifyListener();
	}

	// 일반 채팅
	public void addPacketListener(ChatRoomAct.PacketListener aPacketListener) {
		m_XmppListener.addPacketListener(aPacketListener);
	}

	public void removePacketListener() {
		m_XmppListener.removePacketListener();
	}

	// 그룹 채팅

	public void addGroupPacketListener(ChatRoomGroupAct.PacketListener aPacketListener) {
		m_XmppListener.addGroupPacketListener(aPacketListener);
	}

	public void removeGroupPacketListener() {
		m_XmppListener.removeGroupPacketListener();
	}

	ConnectionListener mConnectionListener = new ConnectionListener() {

		@Override
		public void reconnectionSuccessful() {
			// TODO Auto-generated method stub
			CommonLog.e(TAG, "CC-reconnectionSuccessful");
		}

		@Override
		public void reconnectionFailed(Exception arg0) {
			// TODO Auto-generated method stub
			CommonLog.e(TAG, "CC-reconnectionFailed");
			if (m_XmppListener.getIntroPacketListner() != null) {
				m_XmppListener.getIntroPacketListner().showPopup();
			}
		}

		@Override
		public void reconnectingIn(int arg0) {
			// TODO Auto-generated method stub
			CommonLog.e(TAG, "CC-reconnectingIn");
		}

		@Override
		public void connectionClosedOnError(Exception arg0) {
			// TODO Auto-generated method stub
			CommonLog.e(TAG, "CC-connectionClosedOnError : " + arg0.getMessage());
			if (m_XmppListener.getIntroPacketListner() != null) {
				m_XmppListener.getIntroPacketListner().showPopup();
			} else if(m_XmppListener.getNotifyListner() != null) {
				m_XmppListener.getNotifyListner().onBindService();
			} else if(m_XmppListener.getPacketListener() != null) {
				m_XmppListener.getPacketListener().onBindService();
			} else if(m_XmppListener.getGroupPacketListener() != null) {
				m_XmppListener.getGroupPacketListener().onBindService();
			}
			else {
					//setTaskNull();
					//setConnect();
			}
			/*else if (m_XmppListener.getNotifyListner() != null) {

			} else if (m_XmppListener.getPacketListener() != null) {

			} else if (m_XmppListener.getGroupPacketListener() != null) {

			}*/
		}

		@Override
		public void connectionClosed() {
			// TODO Auto-generated method stub
			CommonLog.e(TAG, "CC-connectionClosed");
		}
	};

	public void sendMessage(String strEditText, String strSendMessage, int nFriendUserNumber, String strPacketID){
		m_XmppSendPacket.sendMessage(strEditText, strSendMessage, nFriendUserNumber, strPacketID);
	}

	public void sendEmoticon(String strEditText,String strEmoticon ,int nFriendUserNumber,String strPacketID){
		m_XmppSendPacket.sendEmoticon(strEditText,strEmoticon,nFriendUserNumber,strPacketID);
	}

	public void sendEmoticonGroup(String strEditText,String strEmoticon ,String strRoomID,String strPacketID){
		m_XmppSendPacket.sendEmoticonGroup(strEditText,strEmoticon,strRoomID,strPacketID);
	}

	public void sendMessageGroup(final String strEditText, final String strSendMessage, final String strRoomID, final String strPacketID){
		m_XmppSendPacket.sendMessageGroup(strEditText, strSendMessage, strRoomID, strPacketID);
	}
	
	public void sendUrgentMessage(final String strEditText, final int nFriendUserNumber, final String strPacketID){
		m_XmppSendPacket.sendUrgentMessage(strEditText, nFriendUserNumber, strPacketID);
	}
	
	public void sendUrgentMessageGroup(final String strEditText, final String strRoomID, final String strPacketID){
		m_XmppSendPacket.sendUrgentMessageGroup(strEditText, strRoomID, strPacketID);
	}
	
	public void sendReadMessage(final Packet message) {
		m_XmppSendPacket.sendReadMessage(message);
	}
	
	public void sendReadMessageGroup(final Packet message) {
		m_XmppSendPacket.sendReadMessageGroup(message);
	}
	
	public void sendCloud(final long lTime, final String strFileName, final String strDocId, final String strUrl, final int nFriendUserNumber, final String strCreatTime) {
		m_XmppSendPacket.sendCloud(lTime, strFileName, strDocId, strUrl, nFriendUserNumber, strCreatTime);
	}
	
	public void sendFile(final long lTime, final String strFileName, final String strUrl, final String strPreviewUrl, final int nFriendUserNumber, final String strCreatTime, final boolean isContacts, final String strVdi) {
		m_XmppSendPacket.sendFile(lTime, strFileName, strUrl, strPreviewUrl, nFriendUserNumber, strCreatTime, isContacts, strVdi);
	}
	
	public void sendCloudGroup(final long lTime, final String strFileName, final String strDocId, final String strUrl, final String strRoodID, final String strCreatTime) {
		m_XmppSendPacket.sendCloudGroup(lTime, strFileName, strDocId, strUrl, strRoodID, strCreatTime);
	}
	
	public void sendFileGroup(final long lTime, final String strFileName, final String strUrl, final String strPreviewUrl, final String strRoodID, final String strCreatTime, final boolean isContacts, final String strVdi) {
		m_XmppSendPacket.sendFileGroup(lTime, strFileName, strUrl, strPreviewUrl, strRoodID, strCreatTime, isContacts, strVdi);
	}
	
	public void sendImage(final long lTime, final Bitmap bitamp, final String strUrl, final String strPreviewUrl, final int nFriendUserNumber) {
		m_XmppSendPacket.sendImage(lTime, bitamp, strUrl, strPreviewUrl, nFriendUserNumber);
	}
	
	public void sendImageOther(final long lTime, final int nWidth, final int nHeight, final String strUrl, final String strPreviewUrl,
			final int nFriendUserNumber) {
		m_XmppSendPacket.sendImageOther(lTime, nWidth, nHeight, strUrl, strPreviewUrl, nFriendUserNumber);
	}
	
	public void sendImageGroup(final long lTime, final Bitmap bitamp, final String strUrl, final String strPreviewUrl, final String strRoomID) {
		m_XmppSendPacket.sendImageGroup(lTime, bitamp, strUrl, strPreviewUrl, strRoomID);
	}
	
	public void sendImageGroupOther(final long lTime, final int nWidth, final int nHeight, final String strUrl, final String strPreviewUrl,
			final String strRoomID) {
		m_XmppSendPacket.sendImageGroupOther(lTime, nWidth, nHeight, strUrl, strPreviewUrl, strRoomID);
	}
	
	public void setReadRoomMessage(final ArrayList<String> arrNoReadMessageID, final String strRoomId){
		m_XmppSendPacket.setReadRoomMessage(arrNoReadMessageID, strRoomId);
	}
	
	public void setReadRoomMessageGroup(final ArrayList<String> arrNoReadMessageID, final String strRoomId) {
		m_XmppSendPacket.setReadRoomMessageGroup(arrNoReadMessageID, strRoomId);
	}
	
	public void clearRoom(final int nFriendUserNumber) {
		m_XmppSendPacket.clearRoom(nFriendUserNumber);
	}
	
	public void clearRoom(final String strRoomID){
		m_XmppSendPacket.clearRoom(strRoomID);
	}
	
	public void makeRoom(final ArrayList<Integer> arrRoomUser) {
		m_XmppSendPacket.makeRoom(arrRoomUser);
	}

	public void makeSNSRoom(final ArrayList<Integer> arrRoomUser, final int nGroupId, final String strGrounpName,final String strImageURL, final int nImageIndex){
		m_XmppSendPacket.makeSNSRoom(arrRoomUser, nGroupId, strGrounpName,strImageURL,nImageIndex);
	}

	public void inviteSelf(final String strGroupID) {
		m_XmppSendPacket.inviteSelf(strGroupID);
	}
	
	public void passOwner(final int nUserID, final String strRoomID) {
		m_XmppSendPacket.passOwner(nUserID, strRoomID);
	}
	
	public void exitOther(final ArrayList<Integer> arrKickUser, final String strRoomID) {
		m_XmppSendPacket.exitOther(arrKickUser, strRoomID);
	}
	
	public void inviteOther(ArrayList<Integer> arrUserData, final String strRoomID) {
		m_XmppSendPacket.inviteOther(arrUserData, strRoomID);
	}
	
	public void exitRoom(final String strRoomID) {
		m_XmppSendPacket.exitRoom(strRoomID);
	}

	public void requestRoomList() {
		m_XmppSendPacket.requestRoomList();
	}

	public void requestGroupChats(){
		m_XmppSendPacket.requestGroupChats();
	}

	public void requestUserList(final String strRoomID) {
		m_XmppSendPacket.requestUserList(strRoomID);
	}
	
	public void requestOnOff(final String onoff, final String strRoomID) {
		m_XmppSendPacket.requestOnOff(onoff, strRoomID);
	}
	
	public void addBuddy(final String strUser){
		m_XmppSendPacket.addBuddy(strUser);
	}
	
	public void delBuddy(final ArrayList<String> arrUser){
		m_XmppSendPacket.delBuddy(arrUser);
	}

	public void changeRoomTitle(final String strRoomId, final String strRoomName){
		m_XmppSendPacket.changeRoomTitle(strRoomId,strRoomName);
	}

	public void changeRoomNamePCsync(final String strRoomId, final String strRoomName){
		m_XmppSendPacket.changeRoomNamePCsync(strRoomId, strRoomName);
	}
	
	public void addGroupFavorite(final String strGroupId){
		m_XmppSendPacket.addGroupFavorite(strGroupId);
	}
	
	public void delGroupFavorite(final String strGroupId){
		m_XmppSendPacket.delGroupFavorite(strGroupId);
	}
	
	public void addChatFavorite(final String strRoomId){
		m_XmppSendPacket.addChatFavorite(strRoomId);
	}
	
	public void delChatFavorite(final String strRoomId){
		m_XmppSendPacket.delChatFavorite(strRoomId);
	}

	public class PopupRunnable implements Runnable {
		Context aContext;
		String strAlert;
		String strRoomID;

		public PopupRunnable(Context a_Context, String a_strAlert, String a_strRoomID) {
			aContext = a_Context;
			strAlert = a_strAlert;
			strRoomID = a_strRoomID;
		}

		@Override
		public void run() {
			PushController.showKickPopup(aContext, strAlert, strRoomID);
		}
	}
	
	public class LoginTask extends PriorityAsyncTask<Void, Void, Void> {
		// private ProgressDialog dialog;
		private boolean isRunning = false;

		public boolean isRunning() {
			
			return isRunning;
		}

		@Override
		protected void onPreExecute() {
			isRunning = true;
			
			SharedPref pref = SharedPref.getInstance(XmppConnectionService.this);
			int nSaveChatMsgTerm = pref.getIntegerPref(SharedPref.PREF_SAVECHATMESSAGETERM, StaticString.CHATMESSAGETERM_3WEEKBEFORE);
			int nBeforeDay = 21;
			
			if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3WEEKBEFORE)
				nBeforeDay = 21;
			else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_2WEEKBEFORE)
				nBeforeDay = 14;
			else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_1WEEKBEFORE)
				nBeforeDay = 7;
			else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3DAYBEFORE)
				nBeforeDay = 3;
			
			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) - nBeforeDay);
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			
			lnEditTime = calendar.getTimeInMillis();
		}

		@Override
		protected Void doInBackground(Void... unused) {
			try {
				String strPassword = null;
				if (AppSetting.FEATURE_VARIANT.equals("R")) {
					//if (AppSetting.USING_SERVER == APISERVER_LIST.DEV_SERVER) {
						TelephonyManager telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
						String mu_phone_deviceid = telephony.getDeviceId();
						strPassword = Base64.encodeToString((App.m_GMPData.m_strAuthKey + "|" + App.m_Mdn + "|" + mu_phone_deviceid).getBytes(), Base64.NO_WRAP);
					//} else {
					//	strPassword = Base64.encodeToString((App.m_GMPData.m_strAuthKey + "|" + App.m_Mdn).getBytes(), Base64.NO_WRAP);
					//}
				} else {
					TelephonyManager telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
					String mu_phone_deviceid = telephony.getDeviceId(); // device
																		// id
					CommonLog.e(TAG, "device id : " + mu_phone_deviceid);
					String strEncodePassword = Base64.encodeToString(App.m_PartnerPW.getBytes(), Base64.NO_WRAP);
					strPassword = Base64.encodeToString((strEncodePassword + "|" + mu_phone_deviceid).getBytes(), Base64.NO_WRAP);
					//strPassword = Base64.encodeToString((App.m_PartnerPW + "|" + mu_phone_deviceid).getBytes(), Base64.NO_WRAP);
				}

				// connection.connect();
				// connection.addConnectionListener(mConnectionListener);

				if (!m_isLogin && !connection.isConnected()) {
					connection.connect();
					connection.addConnectionListener(mConnectionListener);
					if (connection.getUser() == null) {
						CommonLog.e(getClass().getSimpleName(), "Login Status : Full Login!!!");
						connection.login(Integer.toString(App.m_MyUserInfo.m_nUserNo), strPassword, "TMS");
					} else {
						CommonLog.e(getClass().getSimpleName(), "Login Status : Already Login!!!");
					}
					m_isLogin = true;
				} else if (!m_isLogin) {
					if (connection.getUser() == null) {
						CommonLog.e(getClass().getSimpleName(), "Login Status : Login!!!");
						connection.login(Integer.toString(App.m_MyUserInfo.m_nUserNo), strPassword, "TMS");
					} else {
						CommonLog.e(getClass().getSimpleName(), "Login Status : Already Login!!!");
					}
					m_isLogin = true;
				} else if (!connection.isConnected()) {
					CommonLog.e(getClass().getSimpleName(), "Login Status : Connection!!!");
					connection.connect();
					connection.addConnectionListener(mConnectionListener);
				}

				// ProviderManager.getInstance().addExtensionProvider("delay",
				// "urn:xmpp:delay", new DelayInformationTTalkProvider());
				/*채팅방 그룹핑 IQ추가*/


				ProviderManager.getInstance().addExtensionProvider(DelayEx.ELEMENT_NAME, DelayEx.NAMESPACE, new DelayInformationProviderTTalk());
				ProviderManager.getInstance().addExtensionProvider(ReceivedEx.ELEMENT_NAME, ReceivedEx.NAMESPACE, new ReceivedEx.Provider());

				ProviderManager.getInstance().addExtensionProvider(ReadEx.ELEMENT_NAME, ReadEx.NAMESPACE, new ReadEx.Provider());

				ProviderManager.getInstance().addExtensionProvider(UserEx.ELEMENT_NAME, UserEx.NAMESPACE, new UserEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(EmoticonEx.ELEMENT_NAME,EmoticonEx.NAMESPACE,new EmoticonEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(QuitEx.ELEMENT_NAME, QuitEx.NAMESPACE, new QuitEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(KickEx.ELEMENT_NAME, KickEx.NAMESPACE, new KickEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(OwnerEx.ELEMENT_NAME, OwnerEx.NAMESPACE, new OwnerEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(ClearEx.ELEMENT_NAME, ClearEx.NAMESPACE, new ClearEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(FileEx.ELEMENT_NAME, FileEx.NAMESPACE, new FileEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(GroupNoticeEx.ELEMENT_NAME,GroupNoticeEx.NAMESPACE, new GroupNoticeEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(PCSystemEx.ELEMENT_NAME, PCSystemEx.NAMESPACE, new PCSystemEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(PCSyncEx.ELEMENT_NAME, PCSyncEx.NAMESPACE, new PCSyncEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(PCSingleMessageEx.ELEMENT_NAME, PCSingleMessageEx.NAMESPACE, new PCSingleMessageEx.Provider());
				ProviderManager.getInstance().addExtensionProvider("file-received", "", new FileReceivedEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(RoomTitleChangeEx.ELEMENT_NAME,RoomTitleChangeEx.NAMESPACE,new RoomTitleChangeEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(ChannelEx.ELEMENT_NAME, ChannelEx.NAMESPACE, new ChannelEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(ChannelInviteEx.ELEMENT_NAME, ChannelInviteEx.NAMESPACE, new ChannelInviteEx.Provider());
				ProviderManager.getInstance().addExtensionProvider(ChannelInviteEx.ELEMENT_NAME, ChannelInviteEx.NAMESPACE, new ChannelInviteEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", IQRoomTitleEx.NAMESPACE, new IQRoomTitleEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", QuitMyEx.NAMESPACE, new QuitMyEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", KickMyEx.NAMESPACE, new KickMyEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", InviteMyEx.NAMESPACE, new InviteMyEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", IQAlarmEx.NAMESPACE, new IQAlarmEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", RoomsEx.NAMESPACE, new RoomsEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", GroupChatsEx.NAMESPACE,new GroupChatsEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", IQUsersEx.NAMESPACE, new IQUsersEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", IQQuitErrorEx.NAMESPACE, new IQQuitErrorEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", IQMaxUserErrorEx.NAMESPACE, new IQMaxUserErrorEx.Provider());
				ProviderManager.getInstance().addIQProvider("query", IQKickErrorEx.NAMESPACE, new IQKickErrorEx.Provider());

				// OfflineMessage를 사용하기 위해 필요
				ProviderManager.getInstance().addIQProvider("query", "http://jabber.org/protocol/disco#info", new DiscoverInfoProvider());
				ProviderManager.getInstance().addIQProvider("query", "http://jabber.org/protocol/disco#items", new DiscoverItemsProvider());
				ProviderManager.getInstance().addExtensionProvider("x", "jabber:x:data", new DataFormProvider());
				// Offline Message Requests
				ProviderManager.getInstance().addIQProvider("offline", "http://jabber.org/protocol/offline", new OfflineMessageRequest.Provider());
				// Offline Message Indicator
				ProviderManager.getInstance().addExtensionProvider("offline", "http://jabber.org/protocol/offline", new OfflineMessageInfo.Provider());

				m_OfflineManager = new OfflineMessageManager(connection);
				if (m_XmppListener.getIntroPacketListner() != null) {
					SharedPref pref = SharedPref.getInstance(XmppConnectionService.this);
					
					if(!pref.getStringPref(SharedPref.PREF_NOW_VERSION, "0").equals("0")){
						pref.setBooleanPref(SharedPref.PREF_ALREADY_GETOFFLINE_MESSAGE, true);
						pref.setBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_FIRST_LOGIN, false);
						CommonLog.e(TAG, "Get Offline Message : On Intro");
					} else {
						pref.setBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_FIRST_LOGIN, true);
						CommonLog.e(TAG, "Get Offline Message : On Intro + Pass");
					}
					getOfflineMessageAll();
					
				} else if (m_XmppListener.getIntroPacketListner() == null) {
					SharedPref pref = SharedPref.getInstance(XmppConnectionService.this);
					if (pref.getBooleanPref(SharedPref.PREF_ALREADY_GETOFFLINE_MESSAGE, false)) {
						pref.setBooleanPref(SharedPref.PREF_ALREADY_GETOFFLINE_MESSAGE, false);
						CommonLog.e(TAG, "Get Offline Message : Pass");
					} else {
						getOfflineMessageAll();
						CommonLog.e(TAG, "Get Offline Message : On Main");
					}
					ArrayList<ArrayList<String>> arrKickRoomInfo = new ArrayList<ArrayList<String>>();
					arrKickRoomInfo = App.m_arrKickRoomInfo;
					if(arrKickRoomInfo != null && !arrKickRoomInfo.isEmpty()){
						for(int i = 0; i < arrKickRoomInfo.size(); i++){
							mHandler.post(new PopupRunnable(getApplicationContext(),String.format(getString(R.string.chatroom_kickuser_popup), arrKickRoomInfo.get(i).get(0)),
									arrKickRoomInfo.get(i).get(1)));
						}
						
					}
					App.m_arrKickRoomInfo = new ArrayList<ArrayList<String>>();
				}
				if(m_isSuccessGetOfflineMessage){
					if(m_XmppListener.getIntroPacketListner() == null) {
						Presence presence = new Presence(Presence.Type.available);
						if (connection.isConnected())
							connection.sendPacket(presence);
					}

				final XmppFilterOnlineSingle filterOnlineSingle = new XmppFilterOnlineSingle(lnEditTime, m_XmppListener, mHandler, connection, getApplicationContext());
				final XmppFilterOnlineGroup filterOnlineGroup = new XmppFilterOnlineGroup(lnEditTime, m_XmppListener, mHandler, connection, getApplicationContext());
				final XmppFilterPCSystem filterPCSystem = new XmppFilterPCSystem(lnEditTime, m_XmppListener, mHandler, connection, getApplicationContext());
				final XmppFilterChannel filterChannel = new XmppFilterChannel(m_XmppListener, mHandler, connection, getApplicationContext());
				if (m_XmppListener.getIntroPacketListner() == null) {
					PacketFilter filter = new AndFilter(new PacketTypeFilter(Message.class));
					connection.addPacketListener(new PacketListener() {

						@Override
						public void processPacket(final Packet message) {
							// TODO Auto-generated method stub
							CommonLog.e(TAG, "Message ToXml :" + message.toXML());
							filterPCSystem.setFilter(message);
							filterOnlineSingle.setFilter1(message);
							filterOnlineGroup.setFilter1(message);
							filterChannel.setFilter(message);
							//setFilter1(message);
						}
					}, filter);
				}
				
				final XmppFilterIQ filterIQ = new XmppFilterIQ(m_XmppListener, m_XmppSendPacket, getApplicationContext());
				PacketFilter filter2 = new IQTypeFilter(IQ.Type.RESULT);

				connection.addPacketListener(new PacketListener() {

					@Override
					public void processPacket(Packet iq) {
						// TODO Auto-generated method stub
						filterIQ.setFilterIQ(iq);
					}
				}, filter2);

				PacketFilter filter3 = new IQTypeFilter(IQ.Type.ERROR);

				connection.addPacketListener(new PacketListener() {

					@Override
					public void processPacket(Packet iq) {
						// TODO Auto-generated method stub
						filterIQ.setFilterErrorIQ(iq);
					}

				}, filter3);
				}
			} catch (XMPPException e) {
				e.printStackTrace();
				if (m_XmppListener.getIntroPacketListner() != null) {
					if (!AppSetting.FEATURE_VARIANT.equals("R") && e.getXMPPError().getCode() == 401) {
						App.m_PartnerPW = "";
						SharedPref pref = SharedPref.getInstance(XmppConnectionService.this);
						pref.setStringPref(SharedPref.PREF_PARTNER_PW, "");

						pref.setStringPref(SharedPref.PREF_COOKIE, "");
						pref.setStringPref(SharedPref.PREF_LOGIN_TIME, "0");
						m_XmppListener.getIntroPacketListner().showPasswordPopup();
					} else {
						m_XmppListener.getIntroPacketListner().showPopup();
					}
					
				} else {
					setTaskNull();
				}
				/*else if (m_XmppListener.getNotifyListner() != null) {
					if(e.getXMPPError().getCode() == 401)
						m_XmppListener.getNotifyListner().onOtherLogin();
				} else if (m_XmppListener.getPacketListener() != null) {
					if(e.getXMPPError().getCode() == 401)
						m_XmppListener.getPacketListener().onOtherLogin();
				} else if (m_XmppListener.getGroupPacketListener() != null) {
					if(e.getXMPPError().getCode() == 401)
						m_XmppListener.getGroupPacketListener().onOtherLogin();
				}*/
			}
			return null;
		}

		@Override
		protected void onProgressUpdate(Void... unused) {
		}

		@Override
		protected void onPostExecute(Void unused) {

			if (m_XMPPConnectionComplete != null)
				m_XMPPConnectionComplete.onConnectionComplete();
			isRunning = false;

			CommonLog.e(TAG, "Send Queue1");
			if (!m_queuePacket.isEmpty()) {
				CommonLog.e(TAG, "Send Queue2");
				while (!m_queuePacket.isEmpty()) {
					Packet message = m_queuePacket.poll();
					CommonLog.e(TAG, "Send Queue");
					CommonLog.e(TAG, "" + message);
					if (connection.isConnected())
						connection.sendPacket(message);

				}
			}

			super.onPostExecute(unused);
		}
	}

	public void setConnect() {
		if (!connection.isConnected()) {
			ConnectionConfiguration connConfig;
			if (AppSetting.USING_SERVER == APISERVER_LIST.DEV_SERVER)
				connConfig = new ConnectionConfiguration(DEV_SERVER_URL, SERVER_PORT, SERVICE_NAME);
			else {
				connConfig = new ConnectionConfiguration(COMMON_SERVER_URL, SERVER_PORT, SERVICE_NAME);
			}

			connConfig.setSASLAuthenticationEnabled(false);
			connConfig.setReconnectionAllowed(true);
			connConfig.setSecurityMode(SecurityMode.enabled);
			connConfig.setSendPresence(false);
			connection = new XMPPConnection(connConfig);
			m_XmppSendPacket = new XmppSendPacket(connection, getApplicationContext());
			//m_XmppListener = new XmppListener();
			Roster roster = connection.getRoster();
			roster.setSubscriptionMode(SubscriptionMode.accept_all);
			if (task == null) {
				task = new LoginTask();
			} else {
			}

			if (!task.isRunning() && !m_isLogin) {
				task.execute();
			} else {
			}
		}
	}

	public void setTaskNull() {
		if (connection.isConnected()) {
			new DisconnectTypeAsync().execute();

		}

		if (task != null) {
			CommonLog.e(TAG, "Task Null");
			m_isLogin = false;
			task = null;

		}
	}

	class DisconnectTypeAsync extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... params) {
			Presence type = new Presence(Type.unavailable);
			connection.disconnect(type);
			return null;
		}
	}

	public boolean isLogin() {
		return m_isLogin;
	}

	public boolean isConnected() {
		if (connection != null)
			return connection.isConnected();
		else
			return false;
	}

	private XMPPConnectionComplete m_XMPPConnectionComplete = null;

	public void startConnection(XMPPConnectionComplete a_XMPPConnectionComplete) {
		m_XMPPConnectionComplete = a_XMPPConnectionComplete;
		if (!connection.isConnected()) {
			if (!m_isLogin) {
				if (task == null) {
					task = new LoginTask();
				}
				if (!task.isRunning())
					task.execute();
			}
		} else
			m_XMPPConnectionComplete.onConnectionComplete();
	}

	public boolean isServiceAlive() {
		return m_isServiceAlive;
	}

	private void getOfflineMessageAll() throws XMPPException{
		SmackConfiguration.setPacketCollectorSize(500000);
		//SmackConfiguration.setPacketReplyTimeout(60000);
		//SmackConfiguration.setDefaultPacketReplyTimeout(10000);
		//CommonLog.e(TAG, "OFLOG-Offline Size : " + SmackConfiguration.getPacketCollectorSize());
		
		SharedPref pref = SharedPref.getInstance(XmppConnectionService.this);
		m_DelayMessageDB = new ChattingDBManagerForDelayMessage(this);
		String strUser = connection.getUser();

		List<Message> messages = new ArrayList<Message>();
		List<String> arrNode = new ArrayList<String>();
		OfflineMessageRequest request = new OfflineMessageRequest();
		request.setFetch(true);
		PacketFilter packetFilter = new AndFilter(new PacketExtensionFilter("offline", "http://jabber.org/protocol/offline"));
		// Filter packets looking for an answer from the server.
		PacketFilter responseFilter = new PacketIDFilter(request.getPacketID());
		PacketCollector response = connection.createPacketCollector(responseFilter);
		// Filter offline messages that were requested by this request
		PacketCollector messageCollector = connection.createPacketCollector(packetFilter);
		// Send the retrieval request to the server.
		connection.sendPacket(request);
		// Wait up to a certain number of seconds for a reply.
		
		IQ answer = (IQ) response.nextResult(60000);
		CommonLog.e(TAG, "Answer : " + answer);
		
		// Stop queuing results
		response.cancel();

		if (answer != null && answer.getError() == null) {

			// Collect the received offline messages
			Message message = (Message) messageCollector.nextResult(1);

			while (message != null) {
				messages.add(message);
				message = (Message) messageCollector.nextResult(1);
			}
			// Stop queuing offline messages
			messageCollector.cancel();

			com.gmp.rusk.db.RoomDBManager a_DelayRoomDB = new com.gmp.rusk.db.RoomDBManager(this);
			com.gmp.rusk.db.ContactsDBManager a_ContactsDBManager = new com.gmp.rusk.db.ContactsDBManager(this);
			a_DelayRoomDB.open();
			a_ContactsDBManager.open();
			XmppFilterOffline filter = new XmppFilterOffline(XmppConnectionService.this, strUser, m_DelayMessageDB, a_DelayRoomDB, a_ContactsDBManager);
			if(pref.getBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_IGNORE_MESSAGE, false)){
				Collections.sort(messages, myComparator);
			}
			for (Message messageaaa : messages) {

				if(!pref.getBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_FIRST_LOGIN, false)){
					//CommonLog.e(TAG, "OFLOG-Offline : " + messageaaa.getBody());
					//CommonLog.e(TAG, "OFLOG-Offline : " + messageaaa);
					filter.setFilter(messageaaa);
					pref.setBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_IGNORE_MESSAGE, false);
				} else {
					pref.setBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_IGNORE_MESSAGE, true);
				}
				OfflineMessageInfo info = (OfflineMessageInfo) messageaaa.getExtension("offline", "http://jabber.org/protocol/offline");
				//NodeEx nodeEx = (NodeEx)messageaaa.getExtension("offline", "http://jabber.org/protocol/offline");
				//CommonLog.e(TAG, "Node : " + info.getNode());
				arrNode.add(info.getNode());

			}
			CommonLog.e(TAG, "OFLOG-Offline : 진행불가?");
			a_ContactsDBManager.close();
			a_DelayRoomDB.close();
			// while (message.hasNext()) {
			// Message object = (Message) message.next();
			// // CommonLog.e(getClass().getSimpleName(),
			// // "OfflineMessage!!!!!!!!!!! : " + object.toXML());
			// // setFilter1(object, false);
			// filter.setFilter1(object, strUser, m_DelayMessageDB);
			// }
			m_DelayMessageDB.end();

			if (m_XmppListener.getNotifyListner() != null && m_XmppListener.getPacketListener() == null && m_XmppListener.getGroupPacketListener() == null) {
				m_XmppListener.getNotifyListner().onResumeScreen();
			}
			if (m_XmppListener.getPacketListener() != null) {
				m_XmppListener.getPacketListener().onResumeScreen();
			}
			if (m_XmppListener.getGroupPacketListener() != null) {
				m_XmppListener.getGroupPacketListener().onResumeScreen();
			}

			m_queuePacket.addAll(filter.getQueue());
			filter.clearQueue();
			
			CommonLog.e(TAG, "Node Size : " + arrNode.size());
			if(!pref.getBooleanPref(SharedPref.PREF_BACKUP_REINSTALL_FIRST_LOGIN, false)){
				if(arrNode.size() > 250){
					List<String> arrNodeSep = new ArrayList<String>();
					CommonLog.e(TAG, "Delete Start");
					for(int i = 0; i < arrNode.size(); i++){
						arrNodeSep.add(arrNode.get(i));
						if(arrNodeSep.size() > 200){
							m_OfflineManager.deleteMessages(arrNodeSep);
							CommonLog.e(TAG, "Delete Count : " + arrNodeSep.size());
							arrNodeSep.clear();
						} else if(i == (arrNode.size() - 1)){
							m_OfflineManager.deleteMessages(arrNodeSep);
							CommonLog.e(TAG, "Delete Count : " + arrNodeSep.size());
							CommonLog.e(TAG, "Delete finish");
							arrNodeSep.clear();
						}
					}
				} else {
					m_OfflineManager.deleteMessages(arrNode);
				}
			}
		} else if (answer != null && answer.getError() != null) {
			CommonLog.e(TAG, "Error response from server.");
		} else {
			CommonLog.e(TAG, "No response from server!!!!!");
//			m_isSuccessGetOfflineMessage = false;
//			if (m_XmppListener.getIntroPacketListner() != null) {
//				m_XmppListener.getIntroPacketListner().showPopup();
//			}
		}
	}

	private final static Comparator<Message> myComparator = new Comparator<Message>() {
		private final Collator collator = Collator.getInstance();

		@Override
		public int compare(Message lhs, Message rhs) {
			// TODO Auto-generated method stub
			DelayInformationTTalk delayL = (DelayInformationTTalk) lhs.getExtension("delay", "urn:xmpp:delay");
			long lTimeL = delayL.getStamp().getTime();

			DelayInformationTTalk delayR = (DelayInformationTTalk) rhs.getExtension("delay", "urn:xmpp:delay");
			long lTimeR = delayR.getStamp().getTime();

			return collator.compare(Long.toString(lTimeL), Long.toString(lTimeR));
		}

	};
//	private void getOfflineMessage() throws XMPPException {
//
//		long startTime4 = System.currentTimeMillis();
//		String strUser = connection.getUser();
//
//		XmppFilter1 filter = new XmppFilter1(XmppConnectionService.this);
//
//		m_DelayMessageDB = new ChattingDBManagerForDelayMessage(this);
//
//		List<String> arrNode = new ArrayList<String>();
//
//		Iterator<OfflineMessageHeader> offlineHeader = m_OfflineManager.getHeaders();
//		while (offlineHeader.hasNext()) {
//			OfflineMessageHeader header = offlineHeader.next();
//
//			// CommonLog.e(getClass().getSimpleName(),
//			// "OfflineMessage!!!!!!!!!!!");
//			arrNode.add(header.getStamp());
//		}
//		// for (String stamp : arrNode) {
//		// CommonLog.e(getClass().getSimpleName(), "Stamp : " + stamp);
//		// }
//
//		// Iterator<Message> message = m_OfflineManager.getMessages(arrNode);
//		long endTime4 = System.currentTimeMillis();
//		long time4 = endTime4 - startTime4;
//		CommonLog.e(getClass().getSimpleName(), "CDM-checkTime : " + time4);
//		long startTime1 = System.currentTimeMillis();
//		// getPacketReplyTimeout 문제로 임시로 라이브러리 내부의 코드를 가져옴
//		PacketFilter packetFilter = new AndFilter(new PacketExtensionFilter("offline", "http://jabber.org/protocol/offline"));
//		List<Message> messages = new ArrayList<Message>();
//		OfflineMessageRequest request = new OfflineMessageRequest();
//		final List<String> finalNode = arrNode;
//
//		for (String node : finalNode) {
//			OfflineMessageRequest.Item item = new OfflineMessageRequest.Item(node);
//			item.setAction("view");
//			request.addItem(item);
//		}
//
//		// Filter packets looking for an answer from the server.
//		PacketFilter responseFilter = new PacketIDFilter(request.getPacketID());
//		PacketCollector response = connection.createPacketCollector(responseFilter);
//		// Filter offline messages that were requested by this request
//		PacketFilter messageFilter = new AndFilter(packetFilter, new PacketFilter() {
//			public boolean accept(Packet packet) {
//				OfflineMessageInfo info = (OfflineMessageInfo) packet.getExtension("offline", "http://jabber.org/protocol/offline");
//				return finalNode.contains(info.getNode());
//			}
//		});
//
//		PacketCollector messageCollector = connection.createPacketCollector(messageFilter);
//		// Send the retrieval request to the server.
//		connection.sendPacket(request);
//
//		// Wait up to a certain number of seconds for a reply.
//		IQ answer = (IQ) response.nextResult(SmackConfiguration.getPacketReplyTimeout());
//		// Stop queuing results
//		response.cancel();
//		if (answer != null) {
//			// throw new XMPPException("No response from server.");
//			// } else if (answer.getError() != null) {
//			// throw new XMPPException(answer.getError());
//			// }
//
//			// Collect the received offline messages
//
//			Message message = (Message) messageCollector.nextResult(1);
//			while (message != null) {
//				messages.add(message);
//				message = (Message) messageCollector.nextResult(1);
//			}
//			// Stop queuing offline messages
//			messageCollector.cancel();
//
//			long endTime1 = System.currentTimeMillis();
//			long time1 = endTime1 - startTime1;
//			CommonLog.e(getClass().getSimpleName(), "CDM-waitTime : " + time1);
//			long startTime = System.currentTimeMillis();
//
//			com.gmp.rusk.db.RoomDBManager a_DelayRoomDB = new com.gmp.rusk.db.RoomDBManager(this);
//			com.gmp.rusk.db.ContactsDBManager a_ContactsDBManager = new com.gmp.rusk.db.ContactsDBManager(this);
//			a_DelayRoomDB.open();
//			a_ContactsDBManager.open();
//			for (Message messageaaa : messages) {
//				filter.setFilter1(messageaaa, strUser, m_DelayMessageDB, a_DelayRoomDB, a_ContactsDBManager);
//				CommonLog.e(TAG, "OFLOG-Offline : " + messageaaa.getBody());
//				CommonLog.e(TAG, "OFLOG-Offline : " + messageaaa);
//			}
//			a_ContactsDBManager.close();
//			a_DelayRoomDB.close();
//			// while (message.hasNext()) {
//			// Message object = (Message) message.next();
//			// // CommonLog.e(getClass().getSimpleName(),
//			// // "OfflineMessage!!!!!!!!!!! : " + object.toXML());
//			// // setFilter1(object, false);
//			// filter.setFilter1(object, strUser, m_DelayMessageDB);
//			// }
//			m_DelayMessageDB.end();
//			long endTime = System.currentTimeMillis();
//			long time = endTime - startTime;
//			CommonLog.e(getClass().getSimpleName(), "CDM-endTime : " + time);
//
//			if (m_NotifyListner != null && m_PacketListener == null && m_GroupPacketListener == null) {
//				m_NotifyListner.onResumeScreen();
//			}
//			if (m_PacketListener != null) {
//				m_PacketListener.onResumeScreen();
//			}
//			if (m_GroupPacketListener != null) {
//				m_GroupPacketListener.onResumeScreen();
//			}
//			if (!arrNode.isEmpty()) {
//
//				m_queuePacket.addAll(filter.getQueue());
//				filter.clearQueue();
//				m_OfflineManager.deleteMessages(arrNode);
//
//			}
//		} else {
//			CommonLog.e(TAG, "No response from server.");
//		}
//
//	}


}
