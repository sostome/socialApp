package com.gmp.rusk.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.DepartmentsData;

/**
 * OrganChartListItemLayout
 * 조직도 부서 List Item Layout
 */
public class OrganChartListItemLayout extends CustomLinearLayout implements OnClickListener{
	
	ImageButton ib_add_fellow;
	Context m_Context;
	OnClickListener m_OnclickListener;
	
	private DepartmentsData m_DepartmentsData = null;
	
	public OrganChartListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public OrganChartListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context a_context)
	{
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listview_organchart_team, this);
		
	}
	
	public void setDepartmentsData(DepartmentsData a_Data)
	{
		m_DepartmentsData = a_Data;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		RelativeLayout layoutOrganTeam = (RelativeLayout)findViewById(R.id.layout_organchart_team);
		TextView tv_name = (TextView)findViewById(R.id.tv_organ_teamname);
		tv_name.setText(m_DepartmentsData.getDepartmentName());
		layoutOrganTeam.setOnClickListener(this);

	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()== R.id.layout_organchart_team)
		{	

			m_OnclickListener.onClick(m_DepartmentsData.getDepartmentCode());
		}
		
	}
	
	public void setClickListener(OnClickListener a_Listener) {
		m_OnclickListener = a_Listener;
	}
	
	public interface OnClickListener {
		public void onClick(String a_strDepartmentCode);
	}
}
