package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.FileProvider;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonProgressPopup;
import com.gmp.rusk.customview.CommonProgressPopup.OnCommonProgressPopupCanceled;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChannelCommentData;
import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChannelThreadData;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.filedownload.FileDownload;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.request.DeleteBoardLikeReq;
import com.gmp.rusk.request.DeleteGroupBoardNoticeReq;
import com.gmp.rusk.request.DeleteGroupBoardReq;
import com.gmp.rusk.request.DeleteGroupReplyReq;
import com.gmp.rusk.request.GetGroupBoardReq;
import com.gmp.rusk.request.GetGroupCommentListReq;
import com.gmp.rusk.request.GetGroupDetailReq;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostBoardLikeReq;
import com.gmp.rusk.request.PostGroupBoardReplyFileUploadReq;
import com.gmp.rusk.request.PostGroupBoardReplyReq;
import com.gmp.rusk.request.PutGroupBoardNoticeReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetGroupBoardRes;
import com.gmp.rusk.response.GetGroupCommentListRes;
import com.gmp.rusk.response.GetGroupDetailRes;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.PostGroupBoardReplyRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.takemedia.FileUtil;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.ScaleImage;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SNSBoardDetailAct extends CustomActivity implements OnClickListener{
	
	private final int REQUESTCODE_REPLYEDIT = 10000;
	private final int REQUESTCODE_BOARDEDIT = 10001;
	private final int REQUEST_CODE_MAKEROOM = 2;
	
	private boolean m_isRead = true;
	private boolean m_isPush = false;
	private int m_nGroupId = -1;
	private String m_strGroupName = "";
	private int m_nBoardId = -1;
	private boolean m_isOwner = false;
	private int m_nUserCount = 0;
	private boolean m_isShowReply = false;
	private boolean m_isWriteReply = false;
	private boolean m_isShowChatBtn = false;
	private boolean m_isLastScroll = false;
	
	private SNSBoardDetailListAdapter m_adapterSNSBoardDetailList = null;
	
	private ChannelThreadData m_SNSBoardData = null;
	private ArrayList<ChannelCommentData> m_ChannelCommentData = null;
	private CommonListPopup m_ListPopup = null;
	private CommonListPopup m_ListPeriodPopup = null;
	private CommonPopup m_Popup = null;
	private CommonProgressPopup m_FileDownloadPopup = null;
	private ProgressDlg m_Progress = null;
	private ImageButton m_btnSendReply;
	
//	private ImageButton btnGroupChat;
	private ImageView btnBack;
	private ArrayList<Integer> m_arrUserNumbers;
//	int m_nPopupType;
	private Intent m_intentResult = null;

	private TakeMediaIntent m_TakeMedia = null;

	SNSBoardFileData m_snsFileData;
	//공지글 기한 설정을 위해 추가
	private int m_nNoticePeriod = -1;

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		/*getWindow().setFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);*/
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_snsboarddetail);

		//이미 게시글 창이 떠있다면 제거
		boolean isAlreadyActivity = false;
		Activity alreadyActivity = null;
		for(Activity activity : App.m_arrActivitys){
			if(activity.getClass().getSimpleName().equals("SNSBoardDetailAct")){
				if(!isAlreadyActivity){
					isAlreadyActivity = true;
					alreadyActivity = activity;
				} else {
					alreadyActivity.finish();
					break;
				}
			}

		}
		getIntentData();
		initUI();
		
		sendDeleteSNSBadge();
		
		m_intentResult = new Intent();
		m_intentResult.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, m_nBoardId);
		setResult(RESULT_OK, m_intentResult);
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		closeProgress();

		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}

	}

	private void initUI()
	{
		if(m_strGroupName != null && !m_strGroupName.equals(""))
		{
			TextView tvTitle = (TextView)findViewById(R.id.tv_snsboarddetail_title);
			tvTitle.setText(m_strGroupName);
		}

		ImageButton btnMenu = (ImageButton)findViewById(R.id.btn_snsboarddetail_menu);
		m_btnSendReply = (ImageButton)findViewById(R.id.btn_snsboarddetail_sendreply);
		/*ImageButton btnAddImage = (ImageButton)findViewById(R.id.btn_snsboarddetail_add_reply_picture);*/
//		btnGroupChat = (ImageButton)findViewById(R.id.btn_snsboarddetail_chatgroup);
		btnBack = (ImageView)findViewById(R.id.ib_back);
		btnMenu.setOnClickListener(this);
		m_btnSendReply.setOnClickListener(this);
		btnBack.setOnClickListener(this);
	/*	btnAddImage.setOnClickListener(this);*/
//		btnGroupChat.setOnClickListener(this);
//		
//		if(!m_isShowChatBtn){
//			btnGroupChat.setVisibility(View.INVISIBLE);
//		}
		
		ListView lvList = (ListView)findViewById(R.id.lv_snsboarddetail_list);
		lvList.setTranscriptMode(ListView.TRANSCRIPT_MODE_NORMAL);
		//lvList.setOnItemLongClickListener(this);
		
		final EditText etReply = (EditText)findViewById(R.id.et_snsboarddetail_replycomment);
		SharedPref pref = SharedPref.getInstance(this);
		int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			etReply.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			etReply.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20.8f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			etReply.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 25.6f);
		}
		if(m_isWriteReply)
		{
			
			etReply.requestFocus();
			Handler mHandler = new Handler();
			mHandler.postDelayed(new Runnable() {
				@Override
				public void run() {
					showSoftkeyboard(etReply);
				}
			}, 500);
		}
		etReply.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				String strMessage = etReply.getText().toString();
				if (m_snsFileData == null && (strMessage.trim().isEmpty() || strMessage.trim().equals(""))) {
					m_btnSendReply.setImageResource(R.drawable.btn_send_reply);
				} else {
					m_btnSendReply.setImageResource(R.drawable.btn_send_reply_on);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	private void setUI(boolean a_isWriteReply)
	{
		TextView tvTitle = (TextView)findViewById(R.id.tv_snsboarddetail_title);
		tvTitle.setText(m_strGroupName);

		
		ListView lvList = (ListView)findViewById(R.id.lv_snsboarddetail_list);
		if(m_adapterSNSBoardDetailList == null)
		{
			m_adapterSNSBoardDetailList = new SNSBoardDetailListAdapter();
			lvList.setAdapter(m_adapterSNSBoardDetailList);
			if(m_isShowReply)
				lvList.setSelection(1);
			
			if(m_isLastScroll)
			{
				int nReplySize = m_ChannelCommentData == null ? 0 : m_ChannelCommentData.size();
				lvList.setSelection(nReplySize + 2);
				m_isLastScroll = false;
			}
		}
		else
		{
			m_adapterSNSBoardDetailList.notifyDataSetChanged();
			if(a_isWriteReply)
			{
				int nReplySize = m_ChannelCommentData == null ? 0 : m_ChannelCommentData.size();
				lvList.setSelection(nReplySize + 2);
			}
		}
		PushController.cancelNotification(this, "" + m_nBoardId);
	}
	
	private void getIntentData()
	{
		m_isRead = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISREAD, true);
		m_isPush = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISPUSH, false);
		m_nGroupId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPID, -1);
		m_strGroupName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_GROUPNAME);
		m_nBoardId = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, -1);
		m_isShowReply = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_REPLY, false);
		m_isWriteReply = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_WRITEREPLY, false);
		m_isShowChatBtn = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_SHOWCHATBTN, false);
		m_isLastScroll = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISLASTSCROLL, false);
		m_isOwner = getIntent().getBooleanExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISOWNER, false);
	}
	
	private void sendDeleteSNSBadge()
	{

			if(m_isPush)
			{
				getGroupDetailData();
			}
			else
			{
				getBoardDetailData(false);
			}

	}

	
	private void getGroupDetailData()
	{
		GetGroupDetailReq req = new GetGroupDetailReq(m_nGroupId);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetGroupDetailRes res = new GetGroupDetailRes(a_strData, ChannelRes.RES_TYPE_CHANNEL);
				ChannelData snsGroupDetailData = res.getChannelData();
				m_isOwner = snsGroupDetailData.m_isOwner;
				m_nUserCount = snsGroupDetailData.m_nMemberCount;
				
				getBoardDetailData(false);
			}
		});
	}
	
	private void getBoardDetailData(final boolean a_isWriteReply)
		{
		GetGroupBoardReq req = new GetGroupBoardReq(m_nGroupId, m_nBoardId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetGroupBoardRes res = new GetGroupBoardRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_THREAD);
				m_SNSBoardData = res.getChannelThreadData();
				//m_SNSBoardData.m_nThreadNo = m_nBoardId;
				getCommentData(a_isWriteReply);
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_FOUND || nErrorCode == ApiResult.HTTP_SERVER_REQUEST_FAIL) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							m_intentResult.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISDELETE, true);
							setResult(RESULT_OK, m_intentResult);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					showErrorPopup(nErrorCode, strMessage);
				}
			}
		});
	}

	private void getCommentData(final boolean a_isWriteReply){
		GetGroupCommentListReq req = new GetGroupCommentListReq(m_nGroupId, m_nBoardId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				closeProgress();
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_FOUND) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							m_intentResult.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISDELETE, true);
							setResult(RESULT_OK, m_intentResult);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					showErrorPopup(nErrorCode, strMessage);
				}
			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
				GetGroupCommentListRes res = new GetGroupCommentListRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_COMMENT);
				m_ChannelCommentData = res.getChannelCommentData();

				ArrayList<Integer> arrUserID = new ArrayList<Integer>();
				UserListData data;
				data = TTalkDBManager.ContactsDBManager.getContacts(SNSBoardDetailAct.this, m_SNSBoardData.m_nUserNo);
				if(data == null){
					arrUserID.add(m_SNSBoardData.m_nUserNo);
				}
				for(int i = 0; i < m_ChannelCommentData.size(); i++){
					data = TTalkDBManager.ContactsDBManager.getContacts(SNSBoardDetailAct.this, m_ChannelCommentData.get(i).m_nUserNo);
					if(data == null){
						if(!arrUserID.contains(m_ChannelCommentData.get(i).m_nUserNo)){
							arrUserID.add(m_ChannelCommentData.get(i).m_nUserNo);
						}
					}
				}
				int[] nNotInDBUsers = new int[arrUserID.size()];
				for(int j = 0; j < arrUserID.size(); j++){
					nNotInDBUsers[j] = arrUserID.get(j);
				}
				if(nNotInDBUsers.length > 0){
					requestAddedByUserList(a_isWriteReply, nNotInDBUsers);
				} else {
					setUI(a_isWriteReply);
				}
			}
		});
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(resultCode == RESULTCODE_NOTINVITED_SNSGROUP)
		{
			setResult(RESULTCODE_NOTINVITED_SNSGROUP);
			finish();
		} else if(requestCode == TakeMediaIntent.REQUESTCODE_ALBUM){
			if(resultCode == Activity.RESULT_OK){
				SelectImageProcessTask task = new SelectImageProcessTask();
				task.execute(data);
			} else {
				m_TakeMedia.deleteDirectory();
				m_TakeMedia = null;
			}
		}
		else
		{
			if(requestCode == REQUESTCODE_REPLYEDIT && resultCode == RESULT_OK)
			{
				//댓글에 이미지가 포함되면서, 서버에서 이미지 정보를 받아 와야 하므로 갱신
				m_adapterSNSBoardDetailList = null;
				getBoardDetailData(false);
				/*int nReplyId = data.getIntExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, -1);
				String strEditText = data.getStringExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT);
				
				for(SNSReplyData replyData : m_SNSBoardData.m_arrReplyData)
				{
					if(replyData.m_nReplyNo == nReplyId)
					{
						replyData.m_strReplyComment = strEditText;
						break;
					}
				}
				
				m_adapterSNSBoardDetailList.notifyDataSetChanged();*/
			}
			else if(requestCode == REQUESTCODE_BOARDEDIT && resultCode == RESULT_OK)
			{
				m_adapterSNSBoardDetailList = null;
				getBoardDetailData(false);
			} else if (requestCode == REQUEST_CODE_MAKEROOM && resultCode == RESULT_OK) {
				ArrayList<Integer> arrUserData = data.getIntegerArrayListExtra(IntentKeyString.INTENT_KEY_ARR_USERNO);
				Intent intent = new Intent(SNSBoardDetailAct.this, ChatRoomGroupAct.class);
				intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, arrUserData);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPCHAT_ID, m_nGroupId);
				intent.putExtra(IntentKeyString.INTENT_KEY_SNSGROUPCHAT_NAME, m_strGroupName);
				startActivity(intent);
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		
//		if(nId == R.id.btn_snsboarddetail_chatgroup)
//		{
//			if(m_SNSBoardData != null)
//			{
//				boolean isRoom = false;
//				String strRoomId = "";
//				ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(this);
//				for(int i = 0; i < arrRoomData.size(); i++){
//					if(arrRoomData.get(i).m_strRoomId.split("\\_").length == 3){				
//						if(arrRoomData.get(i).m_strRoomId.split("\\_")[2].equals(Integer.toString(m_nGroupId))){
//							isRoom = true;
//							strRoomId = arrRoomData.get(i).m_strRoomId;
//							break;
//						}
//					}
//				}
//				if(isRoom){
//					startGroupChat(strRoomId);
//				} else {
//					startMakeGroupChat();
//				}
//			}
//		}
//		else if(nId == R.id.btn_snsboarddetail_menu)
		if(nId == R.id.btn_snsboarddetail_menu)
		{
			if(m_SNSBoardData != null)
				showMenuPopup();
		}
		else if(nId == R.id.iv_snsboarddetail_menu){
			if(m_SNSBoardData != null)
				showMenuPopup();
		}
		else if(nId == R.id.ib_back){
			finish();
		}
		else if(nId == R.id.btn_snsboarddetail_sendreply)
		{
			if(m_SNSBoardData != null)
				writeReply();
		} /*else if(nId == R.id.btn_snsboarddetail_add_reply_picture)
		{
			if(m_SNSBoardData != null) {
				m_TakeMedia = new TakeMediaIntent(this);
				m_TakeMedia.doGetMultiSelectImageFromGallery(GalleryMultiselectorListAct.FROMACTIVITY_SNS_REPLY, 1, 104857600L);
			}
		}*/
		else if(nId == R.id.ib_pop_ok_long){
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		}
		
		super.onClick(v);
	}
	
	private void startGroupChat(String strRoomId){
		Intent intent = new Intent(this, ChatRoomGroupAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_MAKE_ROOMID, strRoomId);
		intent.putExtra(IntentKeyString.INTENT_KEY_NO_MAKE_ROOM, "yes");
		startActivity(intent);
	}

	private void showMenuPopup()
	{
		m_ListPopup = new CommonListPopup(this, new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch (v.getId()) {
					case R.id.tv_pop_first_row: {
						// 공지 설정 / 해제
						if(m_SNSBoardData.m_isNotice)
						{
							deleteNotice();
							m_ListPopup.cancel();
							m_ListPopup.dismiss();
						}
						else
						{
							showNoticePeriod();
							m_ListPopup.cancel();
							m_ListPopup.dismiss();
						}
					}
					break;
					case R.id.tv_pop_second_row: {
						// 글 수정
						editBoard();
						m_ListPopup.cancel();
						m_ListPopup.dismiss();
					}
					break;
					case R.id.tv_pop_third_row: {
						// 글 삭제
						showDeleteBoardPopup();
						m_ListPopup.cancel();
						m_ListPopup.dismiss();
					}
					break;
					case R.id.ib_pop_cancel_long: {
						m_ListPopup.cancel();
						m_ListPopup.dismiss();
						break;
					}
				}

			}
		});
		
		String[] strsMenuString;
		String strNoticeMenu;
		if(m_SNSBoardData.m_isNotice)
		{
			strNoticeMenu = getString(R.string.snsboarddetail_popup_menu_noticecancel);
		}
		else
		{
			strNoticeMenu = getString(R.string.snsboarddetail_popup_menu_noticeset);
		}
		
		if(m_SNSBoardData.m_nUserNo == App.m_EntryData.m_nUserNo)
		{
			strsMenuString = new String[3];
			strsMenuString[0] = strNoticeMenu;
			strsMenuString[1] = getString(R.string.snsboarddetail_popup_menu_boardedit);
			strsMenuString[2] = getString(R.string.snsboarddetail_popup_menu_boarddelete);
		}
		else
		{
			strsMenuString = new String[1];
			strsMenuString[0] = strNoticeMenu;
		}
		
		m_ListPopup.setBodyAndTitleText(getString(R.string.snsboarddetail_popup_title), strsMenuString);
		
		m_ListPopup.setCancelable(true);
		m_ListPopup.show();
	}
	private void showNoticePeriod()
	{
		CommonLog.e("showNotice","period");
		m_ListPeriodPopup = new CommonListPopup(this, new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch (v.getId()) {
					case R.id.tv_pop_first_row: {
						//무기한
						m_nNoticePeriod = 0;
						setNotice();
						m_ListPeriodPopup.cancel();
						m_ListPeriodPopup.dismiss();
					}
					break;
					case R.id.tv_pop_second_row: {
						//1주였는데 10일로 바뀜
						m_nNoticePeriod = 10;
						setNotice();
						m_ListPeriodPopup.cancel();
						m_ListPeriodPopup.dismiss();
					}
					break;
					case R.id.tv_pop_third_row: {
						//2주였는데 15일로 바뀜
						m_nNoticePeriod = 15;
						setNotice();
						m_ListPeriodPopup.cancel();
						m_ListPeriodPopup.dismiss();
					}
					break;
					case R.id.tv_pop_fourth_row: {
						//4주였는데 30일로 바뀜
						m_nNoticePeriod = 30;
						setNotice();
						m_ListPeriodPopup.cancel();
						m_ListPeriodPopup.dismiss();
					}
					break;
					case R.id.ib_pop_cancel_long: {
						//취소
						m_ListPeriodPopup.cancel();
						m_ListPeriodPopup.dismiss();
						break;
					}
				}

			}
		});
		String[] strsMenuString;

			strsMenuString = new String[4];
			strsMenuString[0] = getString(R.string.snsboarddetail_popup_menu_noticeInfi);
			strsMenuString[1] = getString(R.string.snsboarddetail_popup_menu_notice1week);
			strsMenuString[2] = getString(R.string.snsboarddetail_popup_menu_notice2weeks);
			strsMenuString[3] = getString(R.string.snsboarddetail_popup_menu_notice4weeks);

		m_ListPeriodPopup.setBodyAndTitleText(getString(R.string.snsboarddetail_popup_NoticePeriod), strsMenuString);

		m_ListPeriodPopup.setCancelable(true);
		m_ListPeriodPopup.show();
	}
	private void showEditReplyPopup(final ChannelCommentData data)
	{
		final int a_nReplyId = data.m_nCommentNo;
		m_ListPopup = new CommonListPopup(this, new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch (v.getId()) {
				case R.id.tv_pop_first_row:
				{
					// 댓글 삭제
					showDeleteReplyPopup(a_nReplyId);
					m_ListPopup.cancel();
					m_ListPopup.dismiss();
				}
					break;
				case R.id.tv_pop_second_row:
				{
					// 댓글 수정
					startEditReplyAct(a_nReplyId, data);
					m_ListPopup.cancel();
					m_ListPopup.dismiss();
				}
					break;
				case R.id.ib_pop_cancel_long:
					m_ListPopup.cancel();
					m_ListPopup.dismiss();
					break;
				}

			}
		});
		
		m_ListPopup.setBodyAndTitleText(getString(R.string.snsboarddetail_popup_editreply_title), getResources().getStringArray(R.array.arr_snsboarddetail_editreply_menu));
		
		m_ListPopup.setCancelable(true);
		m_ListPopup.show();
	}
	
	private void showDeleteBoardPopup()
	{
		m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					deleteBoard();
				}
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.snsboarddetail_popup_delete_title), getString(R.string.snsboarddetail_popup_delete_msg));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void showSetNoticePopup()
	{
		String strNotciePeriod = "";
		if(m_nNoticePeriod == 0){
			strNotciePeriod = getString(R.string.snsboarddetail_popup_menu_noticeInfi);
		} else {
			strNotciePeriod = m_nNoticePeriod+getString(R.string.snsboarddetail_popup_noticeset_msg_day);
		}
		m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
		String strMessage = m_SNSBoardData.m_isNotice ?
				String.format(getString(R.string.snsboarddetail_popup_noticeset_msg),strNotciePeriod) : getString(R.string.snsboarddetail_popup_noticecancel_msg);
		String strTitle = m_SNSBoardData.m_isNotice ?
				getString(R.string.snsboarddetail_popup_notice_title) : getString(R.string.snsboarddetail_popup_notice_cancel);
		m_Popup.setBodyAndTitleText(strTitle, strMessage);
		m_Popup.setCancelable(false);
		isCheckShowPopup();
		if(!m_SNSBoardData.m_isNotice) {
			m_intentResult = new Intent();
			m_intentResult.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_BOARDID, m_nBoardId);
			m_intentResult.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_CANCELNOTICE, true);
			setResult(RESULT_OK, m_intentResult);
		}
	}
	
	private void showDeleteReplyPopup(final int a_nReplyId)
	{
		m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					deleteReply(a_nReplyId);
				}
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.snsboarddetail_popup_deletereply_title), getString(R.string.snsboarddetail_popup_deletereply_msg));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void showDownloadFailWhySizePopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_download_title), getString(R.string.popup_fail_download_text));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void showDownloadCompletePopup(final String a_strFilePath)
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					startFileOpen(a_strFilePath);
				}
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_downloadcomplete_title), getString(R.string.popup_downloadcomplete_text));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void showFileOpenFailPopup()
	{
		m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
		m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_fail_file_action));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void startFileOpen(String a_strFilePath)
	{
		Intent fileLinkIntent = new Intent(Intent.ACTION_VIEW);

		String extension = a_strFilePath.substring(a_strFilePath.lastIndexOf(".") + 1, a_strFilePath.length());
		extension = extension.toLowerCase();
		File file = new File(a_strFilePath);
		boolean isAction = true;
		if (extension.equalsIgnoreCase("txt")) {
			fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "text/*");
		} else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
			fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/msword");
		} else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
			fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/vnd.ms-excel");
		} else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
			fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/vnd.ms-powerpoint");
		} else if (extension.equalsIgnoreCase("pdf")) {
			fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/pdf");
		} else if (extension.equalsIgnoreCase("hwp")) {
			fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/haansofthwp");
		} else {
			isAction = false;
			String[] arrVideoList = getResources().getStringArray(R.array.arr_chat_video_list);
			String[] arrImageList = getResources().getStringArray(R.array.arr_chat_image_list);
			for (int i = 0; i < arrVideoList.length; i++) {
				if (extension.equalsIgnoreCase(arrVideoList[i])) {
					fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "video/*");
					isAction = true;
					break;
				}
			}
			for (int i = 0; i < arrImageList.length; i++) {
				if (extension.equalsIgnoreCase(arrImageList[i])) {
					fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "image/*");
					isAction = true;
					break;
				}
			}
			if (!isAction) {
				showFileOpenFailPopup();
			}
		}

		if (isAction) {
			fileLinkIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
			PackageManager packageManager = getPackageManager();
			List activities = packageManager.queryIntentActivities(fileLinkIntent,
					PackageManager.MATCH_DEFAULT_ONLY);
			boolean isIntentSafe = activities.size() > 0;
			if(isIntentSafe) {
				startActivity(fileLinkIntent);
			} else {
				Toast.makeText(this, getString(R.string.cork_toast_not_fount_app), Toast.LENGTH_LONG).show();
			}
		}
	}
	
	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}

	private void deleteNotice()
	{
		DeleteGroupBoardNoticeReq req = new DeleteGroupBoardNoticeReq(m_nGroupId, m_nBoardId);

		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {

						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);
			}

			@Override
			public void onPostRequest(String a_strData) {
				m_SNSBoardData.m_isNotice = !m_SNSBoardData.m_isNotice;
				showSetNoticePopup();
			}
		});
	}
	private void setNotice()
	{
		PutGroupBoardNoticeReq req = new PutGroupBoardNoticeReq(m_nGroupId, m_nBoardId, m_nNoticePeriod);
		
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				m_SNSBoardData.m_isNotice = !m_SNSBoardData.m_isNotice;
				showSetNoticePopup();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

	private void editBoard()
	{
		Intent intent = new Intent(this, SNSBoardEditAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDEDIT_GROUPID, m_nGroupId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDEDIT_BOARDID, m_nBoardId);
		startActivityForResult(intent, REQUESTCODE_BOARDEDIT);
	}
	
	private void deleteBoard()
	{
		DeleteGroupBoardReq req = new DeleteGroupBoardReq(m_nGroupId, m_nBoardId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				m_intentResult.putExtra(IntentKeyString.INTENT_KEY_SNSBOARDDETAIL_ISDELETE, true);
				setResult(RESULT_OK, m_intentResult);
				finish();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);
			}
		});
	}
	
	private void writeReply()
	{
		final EditText etReply = (EditText)findViewById(R.id.et_snsboarddetail_replycomment);
		String strReplyComment = etReply.getText().toString();
		if(m_snsFileData == null && strReplyComment.trim().equals(""))
			return;
		
		PostGroupBoardReplyReq req = new PostGroupBoardReplyReq(m_nGroupId, m_nBoardId, strReplyComment);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				etReply.setText("");
				PostGroupBoardReplyRes res = new PostGroupBoardReplyRes(a_strData);
				int nCommentNo = res.getCommentNo();
				if(m_snsFileData == null){
					getBoardDetailData(true);
					closeProgress();
				} else {
					//uploadImage(nCommentNo);
				}


			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
					showErrorPopup(nErrorCode, strMessage);
			}
		});
	}
	
	private void deleteReply(final int a_nReplyId)
	{
		DeleteGroupReplyReq req = new DeleteGroupReplyReq(m_nGroupId, m_nBoardId, a_nReplyId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				getBoardDetailData(false);
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				if (nErrorCode == ApiResult.HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP) {
					m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {
						
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							CommonPopup popup = (CommonPopup)v.getTag();
							popup.cancel();
							popup.dismiss();
							setResult(RESULTCODE_NOTINVITED_SNSGROUP);
							finish();
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
					showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

	private void uploadImage(int a_nGroupId, int a_nBoardNo, int a_nReplyNo){
		PostGroupBoardReplyFileUploadReq req = new PostGroupBoardReplyFileUploadReq(a_nGroupId, a_nBoardNo, a_nReplyNo);
		req.addImageFileInfo(this, m_snsFileData.m_strFileURL);
		WebAPI api = new WebAPI(this);
		api.requestUpload(req, new WebListener() {

			@Override
			public void onPreRequest() {

			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				/*RelativeLayout layoutAddImage = (RelativeLayout)findViewById(R.id.layout_snsboarddetail_add_image);
				layoutAddImage.setVisibility(View.GONE);*/
				m_snsFileData = null;
				closeProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				closeProgress();
			/*	RelativeLayout layoutAddImage = (RelativeLayout)findViewById(R.id.layout_snsboarddetail_add_image);
				layoutAddImage.setVisibility(View.GONE);*/
				m_snsFileData = null;
				getBoardDetailData(true);
			}
		});
	}
	private void startEditReplyAct(int a_nReplyId,ChannelCommentData data)
	{
		Intent intent = new Intent(getBaseContext(),SNSReplyEditAct.class);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_BOARDID, m_nBoardId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_GROUPID, m_nGroupId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_REPLYID, a_nReplyId);
		intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_EDITTEXT, data.m_strBody);
		//intent.putExtra(IntentKeyString.INTENT_KEY_SNSEDITREPLY_IMAGEURL, data.m_strPreviewFileUrl);
		startActivityForResult(intent, REQUESTCODE_REPLYEDIT);
	}
	
	private void startImageViewer(int a_nPosition)
	{
		if((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
				App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled){
			m_Popup = new CommonPopup(this, SNSBoardDetailAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
			m_Popup.setCancelable(false);
			m_Popup.show();
		}else {
			int nPosition = 0;
			int nSelectedPos = 0;

			ArrayList<String> arrImageUrl = new ArrayList<String>();
			ArrayList<ChannelFileData> arrMediaFile = m_adapterSNSBoardDetailList.getPictureData();
			int nMediaListSize = arrMediaFile.size();
			for (int i = 0; i < nMediaListSize; i++) {
				ChannelFileData data = arrMediaFile.get(i);
				if (data.m_strType.equals(StaticString.FILE_TYPE_IMAGE)) {
					arrImageUrl.add(data.m_strUrl);
					if (a_nPosition == i)
						nSelectedPos = nPosition;
					else
						nPosition++;
				}
			}

			Intent intent = new Intent(this, SNSImageViewAct.class);
			intent.putExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_IMAGEURLLIST, arrImageUrl);
			intent.putExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_SELECTEDIMAGEPOS, nSelectedPos);
			startActivity(intent);
		}
	}
	
	/*private void startFileViewPlus(String a_strDocId, String a_strFileName) {
		try {
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setData(Uri.parse("toktok://com.external.viewer?docType=attach&docId=" + a_strDocId + "&fileName=" + a_strFileName));
			startActivity(intent);
		} catch (ActivityNotFoundException fileViewNotFoundException) {
			try {
				Intent intent = new Intent("com.sk.pe.group.store.detail"); // GMP 스마트폰 스토어의 상세화면
				// Intent intent = new Intent(“com.sk.tablet.group.store.DETAIL”); //GMP 태블릿 스토어의 상세화면

				intent.putExtra("APP_ID", App.FILEVIEWER_APPID); // 대상 어플 아이디
				intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY); // Activity 남기지 않음
				startActivity(intent);
			} catch (ActivityNotFoundException e) {
				Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
				startActivity(intent);
			}
		}
	}*/
	
	private void showSoftkeyboard(EditText a_etText) {
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.showSoftInput(a_etText, 0);
	}
	
	private void downloadFile(final ChannelFileData a_FileData, final boolean a_isSaveTTalkFolder)
	{
		if (FileUtil.getAvailableExternalMemorySize() < 104857600) {
			showDownloadFailWhySizePopup();
		} else if(a_FileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
				(App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled))){
			m_Popup = new CommonPopup(this, SNSBoardDetailAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
			m_Popup.setCancelable(false);
			m_Popup.show();
		}
		else if(!a_FileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileDownloadEnabled) ||
				(App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileDownloadEnabled))){
			m_Popup = new CommonPopup(this, SNSBoardDetailAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
			m_Popup.setCancelable(false);
			m_Popup.show();
		}
		else {
			if(a_FileData.m_strType.equals(StaticString.FILE_TYPE_NORMAL) && AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)){
				Utils.startFileViewPlus(SNSBoardDetailAct.this, a_FileData.m_strFileName, a_FileData.m_strUrl);
			} else {
				SharedPref pref = SharedPref.getInstance(this);
				if (pref.getBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, false)) {
					startDownloadFile(a_FileData, a_isSaveTTalkFolder);
				} else {
					final String strPopupMsg = a_FileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) ? getString(R.string.cork_pop_video_down) : getString(R.string.cork_pop_file_down);
					m_Popup = new CommonPopup(this, new OnClickListener() {
						@Override
						public void onClick(View v) {
							if (v.getId() == R.id.ib_pop_ok) {
								CommonPopup popup_cancel = (CommonPopup) v.getTag();
								popup_cancel.cancel();
								SharedPref pref = SharedPref.getInstance(SNSBoardDetailAct.this);
								pref.setBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, true);
								startDownloadFile(a_FileData, a_isSaveTTalkFolder);
							} else {
								CommonPopup popup_cancel = (CommonPopup) v.getTag();
								popup_cancel.cancel();
							}
						}
					}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(this.getString(R.string.pop_confirm), strPopupMsg);
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
			}
		}
	}

	private void startDownloadFile(final ChannelFileData a_FileData, boolean a_isSaveTTalkFolder){
		final FileDownload fileDownload = new FileDownload(this, m_nGroupId, a_FileData.m_nFileNo, a_FileData.m_strUrl, a_isSaveTTalkFolder);
		m_FileDownloadPopup = new CommonProgressPopup(this, new OnCommonProgressPopupCanceled() {

			@Override
			public void onCommonProgressPopupCanceled() {
				// TODO Auto-generated method stub
				fileDownload.stopDownload();
			}
		});

		fileDownload.startDownload(new FileDownload.OnDownloadComplete() {

			@Override
			public void onDownloadFail() {
				// TODO Auto-generated method stub
				// 다운로드 실패 처리
				CommonLog.e(getClass(), "File Download Fail");
				m_FileDownloadPopup.dismiss();
				m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						CommonPopup popup = (CommonPopup)v.getTag();
						popup.cancel();
						popup.dismiss();
					}
				}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_fail_download_err_network));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}

			@Override
			public void onComplete(String a_strFilePath) {
				// TODO Auto-generated method stub
				CommonLog.e(getClass(), "Result Path : " + a_strFilePath);
				m_FileDownloadPopup.dismiss();
				showDownloadCompletePopup(a_strFilePath);
			}

			@Override
			public void onProgess(int a_nCount, int a_nTotal) {
				// TODO Auto-generated method stub
				m_FileDownloadPopup.setMax(a_nTotal);
				m_FileDownloadPopup.setProgress(a_nCount);
			}

			@Override
			public void onStart() {
				m_FileDownloadPopup.setMax(100);
				m_FileDownloadPopup.setProgress(0);
				m_FileDownloadPopup.setCancelable(true);
				m_FileDownloadPopup.show();
			}
		});
	}
	/*@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view,
			int position, long id) {
		// TODO Auto-generated method stub
		if(position > 1)
		{
			SNSReplyData data = m_SNSBoardData.m_arrReplyData.get(position - 2);
			if(data.m_nUserNo == App.m_EntryData.m_nUserNo)
			{
				showEditReplyPopup(data);
			}
		}
		return true;
	}*/
	
	private class SNSBoardDetailListAdapter extends BaseAdapter
	{
		private final int VIEWTYPE_CONTENT 			= 0;
		private final int VIEWTYPE_REPLYSECTION 	= 1;
		private final int VIEWTYPE_REPLY 			= 2;
		private final int VIEWTYPE_MAX 				= 3;
		
		//private PicturePagerAdapter m_adapterPicturePager = null;
		private ArrayList<ChannelFileData> m_arrPictureData = null;
		private ArrayList<ChannelFileData> m_arrFileData = null;
		
		public ArrayList<ChannelFileData> getPictureData()
		{
			return m_arrPictureData;
		}
		
		@Override
		public int getItemViewType(int position) {
			// TODO Auto-generated method stub
			if(position == 0)
				return VIEWTYPE_CONTENT;
			else if(position == 1)
				return VIEWTYPE_REPLYSECTION;
			else
				return VIEWTYPE_REPLY;
		}
		
		@Override
		public int getViewTypeCount() {
			// TODO Auto-generated method stub
			return VIEWTYPE_MAX;
		}
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			
			if(m_SNSBoardData == null)
				return 0;
			if(m_ChannelCommentData == null)
				return 2;
			else return 2 + m_ChannelCommentData.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			int nViewType = getItemViewType(position);
			if(convertView == null)
			{
				LayoutInflater li = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
				if(nViewType == VIEWTYPE_CONTENT)
				{
					convertView = li.inflate(R.layout.layout_snsboarddetail_listitem_contents, parent, false);
					
					if(m_SNSBoardData.m_arrChannelFileData != null && m_SNSBoardData.m_arrChannelFileData.size() > 0)
					{
						m_arrPictureData = new ArrayList<ChannelFileData>();
						m_arrFileData = new ArrayList<ChannelFileData>();
						LinearLayout layoutAttachFileList = (LinearLayout)convertView.findViewById(R.id.layout_snsboarddetail_listitem_contents_attachfiles);
						for(final ChannelFileData data : m_SNSBoardData.m_arrChannelFileData)
						{
							if(data.m_strType.equals(StaticString.FILE_TYPE_IMAGE) || (data.m_strType.equals(StaticString.FILE_TYPE_VIDEO) && !data.m_strWidePreviewUrl.isEmpty()))
							{
								m_arrPictureData.add(data);
							}
							else
							{
								m_arrFileData.add(data);
								View vFile = li.inflate(R.layout.layout_snsboarddetail_listitem_file, layoutAttachFileList, false);
								ImageView ivFileIcon = (ImageView)vFile.findViewById(R.id.iv_file_icon);
								TextView tvFileName = (TextView)vFile.findViewById(R.id.tv_snsboarddetail_listitem_file_filename);
								TextView tvFileSize = (TextView)vFile.findViewById(R.id.tv_snsboarddetail_listitem_file_filesize);
								TextView tvFileLinker = (TextView)vFile.findViewById(R.id.tv_snsboarddetail_listitem_file_filelinkername);
								TextView tvFileSeperate = (TextView)vFile.findViewById(R.id.tv_snsboarddetail_listitem_file_seperate);

								SharedPref pref = SharedPref.getInstance(SNSBoardDetailAct.this);
								int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
								if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
									tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13f);
								} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
									tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16.9f);
								} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
									tvFileName.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 20.8f);
								}
								String extension = data.m_strFileName.substring(data.m_strFileName.lastIndexOf(".") + 1, data.m_strFileName.length());
								extension = extension.toLowerCase();
								if (extension.equalsIgnoreCase("txt")) {
									ivFileIcon.setImageResource(R.drawable.icon_text_s);
									tvFileLinker.setText(R.string.snsfile_text);
								} else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
									ivFileIcon.setImageResource(R.drawable.icon_word_s);
									tvFileLinker.setText(R.string.snsfile_word);
								} else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
									ivFileIcon.setImageResource(R.drawable.icon_excel);
									tvFileLinker.setText(R.string.snsfile_excel);
								} else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
									ivFileIcon.setImageResource(R.drawable.icon_ppt);
									tvFileLinker.setText(R.string.snsfile_ppt);
								} else if (extension.equalsIgnoreCase("pdf")) {
									ivFileIcon.setImageResource(R.drawable.icon_pdf);
									tvFileLinker.setText(R.string.snsfile_pdf);
								} else if (extension.equalsIgnoreCase("hwp")) {
									ivFileIcon.setImageResource(R.drawable.icon_han_s);
									tvFileLinker.setText(R.string.snsfile_han);
								} else if (extension.equalsIgnoreCase("png") || extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("jpeg") || extension.equalsIgnoreCase("bmp")){
									ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
									tvFileLinker.setText(R.string.snsfile_image);
								} else if (extension.equalsIgnoreCase("avi") || extension.equalsIgnoreCase("asf") || extension.equalsIgnoreCase("mov") || extension.equalsIgnoreCase("mp4") || extension.equalsIgnoreCase("wmv")){
									ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
									tvFileLinker.setText(R.string.snsfile_video);
								}  else if (extension.equalsIgnoreCase("vcf")) {
									ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
									tvFileLinker.setText(R.string.snsfile_vcf);
								} else if (extension.equalsIgnoreCase("zip")) {
									ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
									tvFileLinker.setText(R.string.snsfile_zip);
								}
								else {
									ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
								}

								tvFileName.setText(data.m_strFileName);
								float fFileSize = Utils.bytesToMegabyteFloat(data.m_lnFileSize);
								if(fFileSize == 0.0)
									fFileSize = 0.1F;
								
								tvFileSize.setText(String.format(getString(R.string.snsboarddetail_filesize), fFileSize));

								layoutAttachFileList.addView(vFile);
								vFile.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View v) {
										// TODO Auto-generated method stub
//										if(data.m_strDocId == null|| data.m_strDocId.equals(""))
//											downloadFile(data, true);
//										else
//										{
//											if(AppSetting.FEATURE_VARIANT.equals("R"))
//												startFileViewPlus(data.m_strDocId, data.m_strFileName);
//										}
										if(AppSetting.FEATURE_VARIANT.equals("R"))
										{
											//if(data.m_strDocId == null|| data.m_strDocId.equals(""))
												downloadFile(data, true);
											//else
											//	startFileViewPlus(data.m_strDocId, data.m_strFileName);
										}
										else
										{
											downloadFile(data, true);
										}
									}
								});
							}
						}
						if(m_arrFileData.size() > 0)
						{
							/*TextView tvAllFileCount = (TextView)layoutAttachFileList.findViewById(R.id.tv_snsboarddetail_allfilecount);
							tvAllFileCount.setText("" + m_arrFileData.size());*/
							layoutAttachFileList.setVisibility(View.VISIBLE);
						}
						else
							layoutAttachFileList.setVisibility(View.GONE);
					}
					
				}
				else if(nViewType == VIEWTYPE_REPLYSECTION)
				{
					convertView = li.inflate(R.layout.layout_snsboarddetail_listitem_replycount, parent, false);
				}
				else
				{
					convertView = li.inflate(R.layout.layout_snsboarddetail_listitem_reply, parent, false);
				}
			}
			
			if(nViewType == VIEWTYPE_CONTENT)
			{
				RelativeLayout layoutProfile = (RelativeLayout)convertView.findViewById(R.id.layout_snsboarddetail_board_listitem_userinfo);
				ImageView ivOwnerImg = (ImageView)convertView.findViewById(R.id.iv_snsboarddetail_listitem_contents_userimg);
				TextView tvOwnerName = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_contents_username);
				TextView tvOwnerCompanyOrDepartment = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_contents_companyordepartment);
				TextView tvDate = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_contents_date);
				TextView tvComment = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_contents_comment);
				LinearLayout layoutSNSImage = (LinearLayout)convertView.findViewById(R.id.layout_sns_image);
				ImageView ivPartnerMark = (ImageView)convertView.findViewById(R.id.iv_partner_mark);
				ImageView ivMenu = (ImageView)convertView.findViewById(R.id.iv_snsboarddetail_menu);

				SharedPref pref = SharedPref.getInstance(SNSBoardDetailAct.this);
				int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
				if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
					 tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14.67f);
				} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
					tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19.33f);
				} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
					tvComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 23.47f);
				}


				final UserListData ownerInfo = TTalkDBManager.ContactsDBManager.getContacts(SNSBoardDetailAct.this, m_SNSBoardData.m_nUserNo);
				ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSBoardDetailAct.this);
				imageLoaderMng.cancelDownload(ivOwnerImg);
				imageLoaderMng.getProfileImage(ivOwnerImg, App.getImageDownLoaderUrl(ownerInfo.m_nUserNo, true), R.drawable.profile_pic_default, false);

				layoutProfile.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						doShowProfile(ownerInfo.m_nUserNo);
					}
				});

				
				tvOwnerName.setText(ownerInfo.m_PersonalData.mapPersonalData.get(PersonalData.NAME));

				
				SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());
				String strDate = "";
				try {
					Date createDate = sdfOriginal.parse(m_SNSBoardData.m_strCreatedDate);
					
					SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
					strDate = sdfCreateDateUIPrint.format(createDate);
					
					if(!m_SNSBoardData.m_strCreatedDate.equals(m_SNSBoardData.m_strUpdatedTime) && !m_SNSBoardData.m_strCreateType.equals(StaticString.THREAD_CREATE_TYPE_NEW))
					{
						Date updateDate = sdfOriginal.parse(m_SNSBoardData.m_strUpdatedTime);
						
						Calendar createCal = Calendar.getInstance();
						createCal.setTime(createDate);
						
						Calendar updateCal = Calendar.getInstance();
						updateCal.setTime(updateDate);
						
						SimpleDateFormat sdfUpdateDateUIPrint;
						
						if( (createCal.get(Calendar.YEAR) == updateCal.get(Calendar.YEAR))
								&& (createCal.get(Calendar.MONTH) == updateCal.get(Calendar.MONTH)) 
								&& (createCal.get(Calendar.DAY_OF_MONTH) == updateCal.get(Calendar.DAY_OF_MONTH)))
						{
							sdfUpdateDateUIPrint = new SimpleDateFormat("a h:mm", Locale.getDefault());
						}
						else if(createCal.get(Calendar.YEAR) == updateCal.get(Calendar.YEAR))
						{
							sdfUpdateDateUIPrint = new SimpleDateFormat("MM.dd a h:mm", Locale.getDefault());
							
						}
						else
						{
							sdfUpdateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
						}
						String strUpdateDate = sdfUpdateDateUIPrint.format(updateDate);
						strDate += " | " + strUpdateDate + " " + getString(R.string.snsboarddetail_updatedate);
					}
					
					
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					strDate = m_SNSBoardData.m_strCreatedDate;
				}
				//파트너 마크표사
				final String a_userType = App.m_arrUserListData.get(m_SNSBoardData.m_nUserNo).m_strUserType;
				if(a_userType.equals("P")) {
					ivPartnerMark.setVisibility(View.VISIBLE);
					tvOwnerCompanyOrDepartment.setText(ownerInfo.m_PersonalData.mapPersonalData.get(PersonalData.AFFILIATION));
				}
				else {
					tvOwnerCompanyOrDepartment.setText(ownerInfo.m_PersonalData.mapPersonalData.get(PersonalData.DEPARTMENT)+" | "+ownerInfo.m_PersonalData.mapPersonalData.get(PersonalData.COMPANY_NAME));
					ivPartnerMark.setVisibility(View.GONE);
				}
				ivMenu.setOnClickListener(SNSBoardDetailAct.this);
				tvDate.setText(strDate);
				//tvComment.setText(Utils.getHashtagString(SNSBoardDetailAct.this, m_SNSBoardData.m_strBody, m_nGroupId, m_strGroupName, "", false));

				SpannableString spanText = Utils.getHashtagString(SNSBoardDetailAct.this, m_SNSBoardData.m_strBody, m_nGroupId, m_strGroupName, "", false);
				tvComment.setOnTouchListener(new Utils.MovementMethod(spanText));
				tvComment.setText(spanText);
				if(m_SNSBoardData.m_strBody.isEmpty()){
					tvComment.setVisibility(View.GONE);
				} else {
					tvComment.setVisibility(View.VISIBLE);
				}
				CustomLinkify.addLinks(tvComment, CustomLinkify.ALL);
				if(m_arrPictureData != null && m_arrPictureData.size() > 0)
				{
				/*	m_adapterPicturePager = new PicturePagerAdapter(m_arrPictureData);
					ViewPager vpPictures = (ViewPager)convertView.findViewById(R.id.vp_snsboarddetail_listitem_contents_pics);
					vpPictures.setPageMargin(getResources().getDisplayMetrics().widthPixels/-23);
					vpPictures.setOffscreenPageLimit(m_adapterPicturePager.getCount());
					vpPictures.setAdapter(m_adapterPicturePager);
					vpPictures.setVisibility(View.VISIBLE);*/

					layoutSNSImage.removeAllViews();
					for(int i = 0 ; i < m_arrPictureData.size(); i++){
						LayoutInflater li = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
						View view = li.inflate(R.layout.layout_sns_imageview, null);
						ImageView ivPicture = (ImageView)view.findViewById(R.id.iv_sns_detail_image);
						ImageView ivVodPlay = (ImageView)view.findViewById(R.id.iv_vod_play);
						if(m_arrPictureData.get(i).m_strType.equals(StaticString.FILE_TYPE_VIDEO))
						{
							Bitmap bmp = imageLoaderMng.getLocalImage(m_arrPictureData.get(i).m_strWidePreviewUrl);
							if(bmp == null)
								imageLoaderMng.getImage(ivPicture, m_arrPictureData.get(i).m_strWidePreviewUrl, R.drawable.file_img_frame_page_w);
							else
								ivPicture.setImageBitmap(bmp);
							ivVodPlay.setVisibility(View.VISIBLE);
						}
						else
						{
							Bitmap bmp = imageLoaderMng.getLocalImage(m_arrPictureData.get(i).m_strWidePreviewUrl);
							if(bmp == null)
								imageLoaderMng.getImage(ivPicture, m_arrPictureData.get(i).m_strWidePreviewUrl, R.drawable.file_img_frame_page_w);
							else
								ivPicture.setImageBitmap(bmp);
							ivVodPlay.setVisibility(View.GONE);
						}

						final int nPosition = i;
						view.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								//if(a_userType.equals("R")) {

									if (m_arrPictureData.get(nPosition).m_strType.equals(StaticString.FILE_TYPE_IMAGE)) {
										startImageViewer(nPosition);
									} else if (m_arrPictureData.get(nPosition).m_strType.equals(StaticString.FILE_TYPE_VIDEO)) {
										downloadFile(m_arrPictureData.get(nPosition), false);
									}
								/*} else {
									m_Popup = new CommonPopup(SNSBoardDetailAct.this, new OnClickListener() {

										@Override
										public void onClick(View v) {
											// TODO Auto-generated method stub
											CommonPopup popup = (CommonPopup)v.getTag();
											popup.cancel();
											popup.dismiss();
										}
									}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
									m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_fail_open_file));
									m_Popup.setCancelable(false);
									isCheckShowPopup();
								}*/
							}
						});
						layoutSNSImage.addView(view);
					}

					layoutSNSImage.setVisibility(View.VISIBLE);
				}
			}
			else if(nViewType == VIEWTYPE_REPLYSECTION)
			{
				RelativeLayout layoutLike = (RelativeLayout)convertView.findViewById(R.id.layout_snsboarddetail_like);
				final TextView tvLikeCount = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_like_count);
				final ImageView ivLike = (ImageView)convertView.findViewById(R.id.iv_snsboarddetail_listitem_like);
				TextView tvReplyCount = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_replycount_count);
				String strCount = m_ChannelCommentData == null ? "0" : "" + m_ChannelCommentData.size();
				if(m_SNSBoardData.m_isLiked){
					ivLike.setBackgroundResource(R.drawable.ic_btn_like_click);
				} else {
					ivLike.setBackgroundResource(R.drawable.ic_btn_like);
				}
				tvLikeCount.setText("" + m_SNSBoardData.m_nLikeCount);
				tvReplyCount.setText(strCount);

				layoutLike.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						if(m_SNSBoardData.m_isLiked){
							DeleteBoardLikeReq reqGroupBoardLike = new DeleteBoardLikeReq(m_nGroupId, m_nBoardId);
							WebAPI webApi = new WebAPI(SNSBoardDetailAct.this);
							webApi.request(reqGroupBoardLike, new WebListener() {

								@Override
								public void onPreRequest() {
									showProgress();
								}

								@Override
								public void onNetworkError(int nErrorCode, String strMessage) {
									closeProgress();
									showErrorPopup(nErrorCode, strMessage);
								}

								@Override
								public void onPostRequest(String a_strData) {
									closeProgress();
									m_SNSBoardData.m_nLikeCount--;
									m_SNSBoardData.m_isLiked = false;
									ivLike.setBackgroundResource(R.drawable.ic_btn_like);
									tvLikeCount.setText("" + (m_SNSBoardData.m_nLikeCount));

								}
							});
						} else {
							PostBoardLikeReq reqGroupBoardLike = new PostBoardLikeReq(m_nGroupId, m_nBoardId);
							WebAPI webApi = new WebAPI(SNSBoardDetailAct.this);
							webApi.request(reqGroupBoardLike, new WebListener() {

								@Override
								public void onPreRequest() {
									showProgress();
								}

								@Override
								public void onNetworkError(int nErrorCode, String strMessage) {
									closeProgress();
									showErrorPopup(nErrorCode, strMessage);
								}

								@Override
								public void onPostRequest(String a_strData) {
									closeProgress();
									ivLike.setBackgroundResource(R.drawable.ic_btn_like_click);
									m_SNSBoardData.m_nLikeCount++;
									m_SNSBoardData.m_isLiked = true;
									tvLikeCount.setText("" + (m_SNSBoardData.m_nLikeCount));

								}
							});
						}
					}
				});

			}
			else
			{
				LinearLayout layoutReply = (LinearLayout)convertView.findViewById(R.id.layout_snsboarddetail_reply);
				RelativeLayout layoutProfile = (RelativeLayout)convertView.findViewById(R.id.layout_snsboarddetail_listitem_reply_userinfo);
				ImageView ivReplyImg = (ImageView)convertView.findViewById(R.id.iv_snsboarddetail_listitem_reply_userimg);
				TextView tvReplyName = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_reply_username);
				TextView tvReplyCompanyOrDepartment = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_reply_companyordepartment);
				TextView tvReplyDate = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_reply_date);
				TextView tvReplyComment = (TextView)convertView.findViewById(R.id.tv_snsboarddetail_listitem_reply_comment);
				ImageView ivReplyAddImg = (ImageView)convertView.findViewById(R.id.iv_snsboarddetail_listitem_reply_addimage);
				ImageView ivPartnerMark = (ImageView)convertView.findViewById(R.id.iv_partner_mark);
				ImageView ivSNSReplyMenu = (ImageView)convertView.findViewById(R.id.iv_snsreply_menu);
				ImageView ivReplyFrameMe = (ImageView)convertView.findViewById(R.id.iv_snsboarddetail_listitem_reply_me_frame);


				SharedPref pref = SharedPref.getInstance(SNSBoardDetailAct.this);
				int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
				if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
					tvReplyComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14.67f);
				} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
					tvReplyComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19.33f);
				} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
					tvReplyComment.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 23.47f);
				}
				
				final ChannelCommentData data = m_ChannelCommentData.get(position - 2);

				UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(SNSBoardDetailAct.this, data.m_nUserNo);
				ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSBoardDetailAct.this);
				imageLoaderMng.getProfileImage(ivReplyImg, App.getImageDownLoaderUrl(userData.m_nUserNo, true), R.drawable.profile_pic_default, false);

				layoutProfile.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						doShowProfile(data.m_nUserNo);
					}
				});

				tvReplyName.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
//				tvReplyCompanyOrDepartment.setText(data.m_strCompanyOrDepartment);
				SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());
				String strDate = "";
				try {
					Date createDate = sdfOriginal.parse(data.m_strCreatedDate);
					
					SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd a h:mm", Locale.getDefault());
					strDate = sdfCreateDateUIPrint.format(createDate);
				}catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					strDate = data.m_strCreatedDate;
				}
				tvReplyDate.setText(strDate);
				//파트너 마크표사
				String a_userType = App.m_arrUserListData.get(data.m_nUserNo).m_strUserType;
				if(a_userType.equals("P"))
					ivPartnerMark.setVisibility(View.VISIBLE);
				else
					ivPartnerMark.setVisibility(View.GONE);

				if (data.m_nUserNo == App.m_EntryData.m_nUserNo) {
					ivReplyFrameMe.setVisibility(View.VISIBLE);
					ivSNSReplyMenu.setVisibility(View.VISIBLE);
					ivSNSReplyMenu.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
								showEditReplyPopup(data);
						}
					});
				} else {
					ivReplyFrameMe.setVisibility(View.GONE);
					ivSNSReplyMenu.setVisibility(View.GONE);
				}


				//tvReplyComment.setText(Utils.getHashtagString(SNSBoardDetailAct.this, data.m_strBody, m_nGroupId, m_strGroupName, "", false));
				SpannableString spanText = Utils.getHashtagString(SNSBoardDetailAct.this, data.m_strBody, m_nGroupId, m_strGroupName, "", false);
				tvReplyComment.setOnTouchListener(new Utils.MovementMethod(spanText));
				tvReplyComment.setText(spanText);
				CustomLinkify.addLinks(tvReplyComment, CustomLinkify.ALL);
				/*if(data.m_strFileUrl !=null && !data.m_strFileUrl.equals("")) {
					ivReplyAddImg.setVisibility(View.VISIBLE);
					ImageLoaderManager imageLoaderAddMng = ImageLoaderManager.getInstance(SNSBoardDetailAct.this);
					imageLoaderAddMng.cancelDownload(ivReplyAddImg);
					imageLoaderAddMng.getProfileImage(ivReplyAddImg, data.m_strPreviewFileUrl, 0, false);

					ivReplyAddImg.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							ArrayList<String> arrImageUrl = new ArrayList<String>();
							arrImageUrl.add(data.m_strFileUrl);
							Intent intent = new Intent(SNSBoardDetailAct.this, SNSImageViewAct.class);
							intent.putExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_IMAGEURLLIST, arrImageUrl);
							intent.putExtra(IntentKeyString.INTENT_KEY_SNSIMAGEVIEW_SELECTEDIMAGEPOS, 0);
							startActivity(intent);
						}
					});

					ivReplyAddImg.setOnLongClickListener(new View.OnLongClickListener() {
						@Override
						public boolean onLongClick(View v) {
							if (data.m_nUserNo == App.m_EntryData.m_nUserNo) {
								showEditReplyPopup(data);
							}
							return true;
						}
					});
				}else {*/
					ivReplyAddImg.setVisibility(View.GONE);
				//}

				//부모뷰 롱클릭으로 자식들의 이벤트 처리가 안되고 있다.
				//차후에 수정
				layoutReply.setOnLongClickListener(new View.OnLongClickListener() {
					@Override
					public boolean onLongClick(View v) {
						if(data.m_nUserNo == App.m_EntryData.m_nUserNo)
						{
							showEditReplyPopup(data);
						}
						return true;
					}
				});
				ivReplyAddImg.setOnLongClickListener(new View.OnLongClickListener() {
					@Override
					public boolean onLongClick(View v) {
						if(data.m_nUserNo == App.m_EntryData.m_nUserNo)
						{
							showEditReplyPopup(data);
						}
						return true;
					}
				});
				tvReplyComment.setOnLongClickListener(new View.OnLongClickListener() {
					@Override
					public boolean onLongClick(View v) {
						if(data.m_nUserNo == App.m_EntryData.m_nUserNo)
						{
							showEditReplyPopup(data);
						}
						return true;
					}
				});

			}
			
			return convertView;
		}
	}
	
	/*private class PicturePagerAdapter extends PagerAdapter
	{
		private ArrayList<ChannelFileData> m_arrBoardFileData = null;
		public PicturePagerAdapter(ArrayList<ChannelFileData> a_arrBoardFileData) {
			// TODO Auto-generated constructor stub
			super();
			m_arrBoardFileData = a_arrBoardFileData;
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return m_arrBoardFileData.size();
		}

		@Override
		public Object instantiateItem(View container, int position) {
			// TODO Auto-generated method stub
			// ViewPager에서 사용할 뷰객체 생성 및 들록
			final int nPosition = position;
			CommonLog.e(getClass(), "instantiateItem");
			View vContent = null;
			LayoutInflater li = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
			vContent = li.inflate(R.layout.layout_snsboarddetail_listitem_picture, null);
			
			final ChannelFileData data = m_arrBoardFileData.get(nPosition);
			
			ImageView ivPicture = (ImageView)vContent.findViewById(R.id.iv_snsboarddetail_listitem_picture);
			ImageView ivVodPlay = (ImageView)vContent.findViewById(R.id.iv_snsboarddetail_listitem_vodplay);
			if(data.m_strType.equals(StaticString.FILE_TYPE_VIDEO))
			{
				ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSBoardDetailAct.this);
				Bitmap bmp = imageLoaderMng.getLocalImage(data.m_strWidePreviewUrl);
				if(bmp == null)
					imageLoaderMng.getImage(ivPicture, data.m_strWidePreviewUrl, R.drawable.file_img_frame_page);
				else
					ivPicture.setImageBitmap(bmp);
				ivVodPlay.setVisibility(View.VISIBLE);
			}
			else
			{
				ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(SNSBoardDetailAct.this);
				Bitmap bmp = imageLoaderMng.getLocalImage(data.m_strWidePreviewUrl);
				if(bmp == null)
					imageLoaderMng.getImage(ivPicture, data.m_strWidePreviewUrl, R.drawable.file_img_frame_page);
				else
					ivPicture.setImageBitmap(bmp);
				ivVodPlay.setVisibility(View.GONE);
			}
			
			vContent.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if(data.m_strType.equals(StaticString.FILE_TYPE_IMAGE))
					{
						//if(data.m_strDocId != null && !data.m_strDocId.equals("") && AppSetting.FEATURE_VARIANT.equals("R"))
						//	startFileViewPlus(data.m_strDocId, data.m_strFileName);
						//else
							startImageViewer(nPosition);
					}
					else if(data.m_strType.equals(StaticString.FILE_TYPE_VIDEO))
					{
						if(data.m_nFileNo != -1 && AppSetting.FEATURE_VARIANT.equals("R"))
							startFileViewPlus("", data.m_strFileName);
						//else
						//	downloadFile(data, false);
					}
					
//					if(data.m_strDocId == null|| data.m_strDocId.equals(""))
//					{
//						if(data.m_strFileType.equals(StaticString.FILE_TYPE_VIDEO))
//							downloadFile(data, false);
//						else
//							startImageViewer(nPosition);
//					}
//					else
//					{
//						if(AppSetting.FEATURE_VARIANT.equals("R"))
//							startFileViewPlus(data.m_strDocId, data.m_strFileName);
//					}
				}
			});
			
			((ViewPager)container).addView(vContent, 0);
			
			return vContent;
		}
		
		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			// instantiateImage Method에서 생성한 객체를 이용할 것인지 여부를 반환 한다.
			return arg0 == arg1;
		}
		
		@Override
		public void destroyItem(View container, int position, Object object) {
			// TODO Auto-generated method stub
			// View 객체를 삭제 
			((ViewPager)container).removeView((View)object);
		}
		
		@Override 
		public void restoreState(Parcelable arg0, ClassLoader arg1) 
		{
			// saveState Method 상태에서 저장했던 Adapter와 Pager를 복구 한다.
		}
		
		@Override 
		public Parcelable saveState() 
		{
			// 현재 UI 상태를 저장하기 위해 Adapter와 Page 관련 인스턴스 상태를 저장.
			return null;
		}
		
		@Override
		public void startUpdate(View arg0)
		{
			// 페이지 변경이 시작될 때 호출
		}
		
		@Override
		public void finishUpdate(View arg0)
		{
			// 페이지 변경이 완료 됐을때 호출
		}
		
	}*/

	private void doShowProfile(int a_nUserNo)
	{
		Intent intent = new Intent(this, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, a_nUserNo);
		startActivityForResult(intent, StaticString.REQUESTCODE_PROFILEVIEW);
	}

	//댓글 이미지 첨부
	private class SelectImageProcessTask extends AsyncTask<Intent, Void, Boolean>
	{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			showProgress();
			super.onPreExecute();
		}

		@Override
		protected Boolean doInBackground(Intent... params) {
			// TODO Auto-generated method stub
			Intent data = params[0];
			Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
			ArrayList<GalleryListData> arrAttachImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);

			if(arrAttachImage != null && arrAttachImage.size() > 0)
			{
				String strScaleSaveDirectory = getFilesDir().getAbsolutePath();
				for(GalleryListData galleryListData : arrAttachImage)
				{
					//여러개 업로드 될 가능성을 위해 for문으로 처리 하고 있으나,
					//현재는 1개만 올라가는 시나리오 임
					String strImagePath = galleryListData.getSdcardPath();
					ScaleImage scaleImage = new ScaleImage();
					scaleImage.scaleImage(strImagePath, strScaleSaveDirectory);

					m_snsFileData = new SNSBoardFileData();
					m_snsFileData.m_strFileType = StaticString.FILE_TYPE_IMAGE;
					m_snsFileData.m_strFileURL = scaleImage.getSavedScaleImagePath();
					m_snsFileData.m_lnFileSize = scaleImage.getSavedScaleImageSize();
					//m_arrAttachMedia.add(snsFileData);
					break;
				}
				return true;
			}
			else
				return false;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			//setAttachFileUI();
		/*	final RelativeLayout layoutAddImage = (RelativeLayout)findViewById(R.id.layout_snsboarddetail_add_image);
			layoutAddImage.setVisibility(View.VISIBLE);

			ImageView ivAddImage = (ImageView)findViewById(R.id.iv_snsboarddetail_add_image);
			Bitmap bm = BitmapFactory.decodeFile(m_snsFileData.m_strFileURL);
			Bitmap thumb = Utils.makeThumbnail(bm, 250, 250);
			ivAddImage.setImageBitmap(thumb);
*/

			m_btnSendReply.setImageResource(R.drawable.btn_send_reply_on);

		/*	ImageView ivCloseImage = (ImageView)findViewById(R.id.iv_snsboarddetail_add_image_cancel);
			ivCloseImage.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					layoutAddImage.setVisibility(View.GONE);
					m_snsFileData = null;
					final EditText etReply = (EditText)findViewById(R.id.et_snsboarddetail_replycomment);
					String strMessage = etReply.getText().toString();
					if (m_snsFileData == null && (strMessage.isEmpty() || strMessage.equals(""))) {
						m_btnSendReply.setImageResource(R.drawable.btn_enroll_disabled);
					} else {
						m_btnSendReply.setImageResource(R.drawable.btn_enroll_pressed);
					}
				}
			});*/
			closeProgress();
			super.onPostExecute(result);
		}
	}

	synchronized public void requestAddedByUserList(final boolean isWriteReply, int[] nUserIDs){
		GetUserInfoReq req = new GetUserInfoReq(nUserIDs);
		WebAPI webApi = new WebAPI(SNSBoardDetailAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				for (int i = 0; i < res.getUserListData().size(); i++) {
					UserListData getItem = res.getUserListData().get(i);
					if (getItem != null) {
						TTalkDBManager.ContactsDBManager.insertContacts(SNSBoardDetailAct.this, getItem);
					}
				}
				setUI(isWriteReply);
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				showErrorPopup(a_nErrorCode, a_strMessage);
			}
		});
	}
}
