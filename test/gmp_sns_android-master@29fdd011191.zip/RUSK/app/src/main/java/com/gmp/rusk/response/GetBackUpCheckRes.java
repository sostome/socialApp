package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

public class GetBackUpCheckRes extends Res{
	
private final String JSON_RESULT 			= "url";

	private String m_strBackupURL = "";
	private String m_strBackUp = "false";
	
	public GetBackUpCheckRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			if(jsonRoot.getString(JSON_RESULT) != null){
				m_strBackUp = "true";
				m_strBackupURL = jsonRoot.getString(JSON_RESULT);
			} else {
				m_strBackUp = "false";
			}

			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getResult()
	{
		return m_strBackUp;
	}
	public String getBackupURL(){
		return m_strBackupURL;
	}
}
