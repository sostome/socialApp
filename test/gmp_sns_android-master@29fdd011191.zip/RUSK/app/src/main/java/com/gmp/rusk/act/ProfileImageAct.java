package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.customview.TouchImageView;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

public class ProfileImageAct extends CustomActivity {
	MyApp App = MyApp.getInstance();
	Bundle bundle;
	private int m_nUserNo;
	ImageView m_ivLoading;

	TouchImageView m_ivLargeImage;
//	GestureImageView m_ivLargeImage;
//	ImageView m_ivLargeImage;

	private RotateAnimation m_animProgress = null;
	CommonPopup m_Popup;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_profileimage);

		App.m_isProfileImageView = true;
		m_ivLargeImage = (TouchImageView) findViewById(R.id.iv_profileimage_largeimage);
		
		m_ivLoading = (ImageView) findViewById(R.id.iv_profileimage_loading);
		bundle = getIntent().getExtras();
		if (bundle != null) {
			m_nUserNo = bundle.getInt(IntentKeyString.INTENT_KEY_PROFILEIMAGE_USERNO);
		}
		
		m_animProgress = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		m_animProgress.setInterpolator(new LinearInterpolator());
		m_animProgress.setRepeatCount(Animation.INFINITE);
		m_animProgress.setDuration(1000);
		
		init();
	}

	
	private void init() {
		ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
		ivCancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		m_ivLoading.startAnimation(m_animProgress);
//		ImageLoaderManager imageloader = ImageLoaderManager.getInstance(ProfileImageAct.this);
		App.imageloader.getImage(m_ivLargeImage, App.getImageDownLoaderUrl(m_nUserNo, false), 0, m_ImageLoaderListener);

	}
	
	ImageLoaderManager.ImageLoaderListener m_ImageLoaderListener = new ImageLoaderManager.ImageLoaderListener() {
		
		@Override
		public void onSuccess() {
			// TODO Auto-generated method stub
			m_animProgress.setRepeatCount(0);
			m_ivLoading.setVisibility(View.GONE);
			setResult(RESULT_OK);
			ImageView ivThumb = (ImageView)findViewById(R.id.iv_profileimage_smallimage);
			App.imageloader.getProfileImage(ivThumb, App.getImageDownLoaderUrl(m_nUserNo, true), 0, true);
		}
		
		@Override
		public void onFail(String a_strErrorMsg) {
			// TODO Auto-generated method stub
			m_animProgress.setRepeatCount(0);
			m_ivLoading.setVisibility(View.GONE);
			
			m_Popup = new CommonPopup(ProfileImageAct.this, ProfileImageAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			String strError;
			if(a_strErrorMsg == null)
				strError = getString(R.string.popup_fail_imagedownload_text);
			else 
				strError = a_strErrorMsg;
			
			m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_download_title), strError);
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
		
		@Override
		public void onNotModified() {
			// TODO Auto-generated method stub
			m_animProgress.setRepeatCount(0);
			m_ivLoading.setVisibility(View.GONE);
		}
	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			finish();
		}
	}
	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
