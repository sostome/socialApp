package com.gmp.rusk.request;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;


import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.utils.CommonLog;

/**
 *	@author kch
 *			모임 게시글 수정
 *			method : put
 */

public class PutGroupBoardReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";

	private final String JSON_BODY		= "body";
	private final String JSON_TYPE = "threadType";

	public static final String CHANNEL_THREAD_TYPE_NORMAL = "N";
	public static final String CHANNEL_THREAD_TYPE_FILE = "F";

	private String m_strBody = "";
	private String m_strType = "";
	
	public PutGroupBoardReq(int a_nGroupId, int a_nThreadId, String a_strBody, String a_strType)
	{
		APINAME = APINAME +"/" + a_nGroupId + "/thread/" + a_nThreadId;

		m_strBody = a_strBody;
		m_strType = a_strType;
	}


	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_BODY, m_strBody);
			jsonObj.put(JSON_TYPE, m_strType);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PutGroupBoardReq.class.getSimpleName(), "" + e.getMessage());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
