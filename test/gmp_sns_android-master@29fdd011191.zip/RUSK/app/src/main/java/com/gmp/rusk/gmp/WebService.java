package com.gmp.rusk.gmp;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import com.gmp.rusk.utils.CommonLog;

public class WebService {
		DefaultHttpClient httpClient;
	    HttpContext localContext;
	 
	    HttpResponse response = null;
	    HttpPost httpPost = null;
	    HttpGet httpGet = null;
	    String webServiceUrl;
	    String TAG="WebService";
	 
	    public WebService(String serviceName){
	        HttpParams myParams = new BasicHttpParams();
	 
	        HttpConnectionParams.setConnectionTimeout(myParams, 5000);
	        HttpConnectionParams.setSoTimeout(myParams, 5000);
	        httpClient = new DefaultHttpClient(myParams);
	        localContext = new BasicHttpContext();
	        webServiceUrl = serviceName;
	 
	    }
	    public String[] webGet(String methodName, Map<String, String> params) {
	        String getUrl = webServiceUrl + methodName;
	        String returnValue[]= {"","",""};
	        int i = 0;
	        for (Map.Entry<String, String> param : params.entrySet())
	        {
	            if(i == 0){
	                getUrl += "?";
	            }
	            else{
	                getUrl += "&";
	            }
	 
	            try {
	                getUrl += param.getKey() + "=" + URLEncoder.encode(param.getValue(),"UTF-8");
	              
	            } catch (UnsupportedEncodingException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	 
	            i++;
	        }
	        
	        CommonLog.e("WebService","getUrl : " + getUrl);
	        
	        try {	  
	        	URL serverUrl = new URL(getUrl);
	        	
	        	XmlPullParserFactory parserCreator;
				
				parserCreator = XmlPullParserFactory.newInstance();
				
	        		        	
	        	XmlPullParser parser = parserCreator.newPullParser();
	        	parser.setInput( serverUrl.openStream(), null );
	        	
	        	int parserEvent = parser.getEventType();
	        	String tag;
	        	while (parserEvent != XmlPullParser.END_DOCUMENT ){
	        		switch(parserEvent){ 
	        		case XmlPullParser.START_TAG:
	        			tag = parser.getName();
	        			if(tag.compareTo("result") == 0) { // 결과 코드
	        				returnValue[0] = parser.nextText();
	                    }
	        			if(tag.compareTo("encEmpId") == 0) { // 사번
	        				returnValue[1] = parser.nextText();
	                    }
	                    if(tag.compareTo("resultMessage") == 0) { // 결과 메시지
							returnValue[2] = parser.nextText();
						}
	        		break;
	        		}
	        		parserEvent = parser.next();
	        	}	        	
	        }catch (IOException e) {
	        	CommonLog.e("getGMPAuthPwd", "WebService 1["+e.getMessage().toString()+"]");
	        } catch (XmlPullParserException e) {
				// TODO Auto-generated catch block
	        	CommonLog.e("getGMPAuthPwd", "WebService 2");
				e.printStackTrace();
			}
//	        catch (Exception e) {
//				// TODO: handle exception
//	        	CommonLog.e("getGMPAuthPwd", "WebService exception ["+e.getMessage()+"]");
//			}
	        
	        return returnValue;
	    }
	    
	    
	    public String[] webGetVersion(String methodName, Map<String, String> params) {
	        String getUrl = webServiceUrl + methodName;
	        String returnValue[]= {"","",""};
	        int i = 0;
	        for (Map.Entry<String, String> param : params.entrySet())
	        {
	            if(i == 0){
	                getUrl += "?";
	            }
	            else{
	                getUrl += "&";
	            }
	 
	            try {
	                getUrl += param.getKey() + "=" + URLEncoder.encode(param.getValue(),"UTF-8");

	            } catch (UnsupportedEncodingException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	 
	            i++;
	        }
	        
	        CommonLog.e("WebService","getUrl : " + getUrl);
	        
	        try {	  
	        	URL serverUrl = new URL(getUrl);
	        	
	        	XmlPullParserFactory parserCreator;
				
				parserCreator = XmlPullParserFactory.newInstance();
				
	        		        	
	        	XmlPullParser parser = parserCreator.newPullParser();
	        	parser.setInput( serverUrl.openStream(), null );
	        	
	        	int parserEvent = parser.getEventType();
	        	String tag;
	        	while (parserEvent != XmlPullParser.END_DOCUMENT ){
	        		switch(parserEvent){ 
	        		case XmlPullParser.START_TAG:
	        			tag = parser.getName();
	        			if(tag.compareTo("result") == 0) { // 결과 코드
	        				returnValue[0] = parser.nextText();
	                    }
	        			if(tag.compareTo("appVer") == 0) { // 사번
	        				returnValue[1] = parser.nextText();
	                    }
						if(tag.compareTo("resultMessage") == 0) { // 결과 메시지
							returnValue[2] = parser.nextText();
						}
	        		break;
	        		}
	        		parserEvent = parser.next();
	        	}	        	
	        }catch (IOException e) {
	        	CommonLog.e("getGMPAuthPwd", "WebService 1["+e.getMessage().toString()+"]");
	        } catch (XmlPullParserException e) {
				// TODO Auto-generated catch block
	        	CommonLog.e("getGMPAuthPwd", "WebService 2");
				e.printStackTrace();
			}
//	        catch (Exception e) {
//				// TODO: handle exception
//	        	CommonLog.e("getGMPAuthPwd", "WebService exception ["+e.getMessage()+"]");
//			}
	        
	        return returnValue;
	    }

	public String[] webGetDocId(String methodName, Map<String, String> params) {
		String getUrl = webServiceUrl + methodName;
		String returnValue[]= {"",""};
		int i = 0;

		for (Map.Entry<String, String> param : params.entrySet())
		{
			if(i == 0){
				getUrl += "?";
			}
			else{
				getUrl += "&";
			}

			try {
				getUrl += param.getKey() + "=" + URLEncoder.encode(param.getValue(),"UTF-8");

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			i++;
		}

		CommonLog.e("WebService","getUrl : " + getUrl);

		try {
			URL serverUrl = new URL(getUrl);
			XmlPullParserFactory parserCreator;
			parserCreator = XmlPullParserFactory.newInstance();

			XmlPullParser parser = parserCreator.newPullParser();
			parser.setInput( serverUrl.openStream(), null );
			int parserEvent = parser.getEventType();
			String tag;

			while (parserEvent != XmlPullParser.END_DOCUMENT ){
				switch(parserEvent){
					case XmlPullParser.START_TAG:
						tag = parser.getName();
						if(tag.compareTo("result") == 0) { // 결과 코드
							returnValue[0] = parser.nextText();
						}
						if(tag.compareTo("docId") == 0) { // Dod Id
							returnValue[1] = parser.nextText();
						}
						break;
				}
				parserEvent = parser.next();
			}
		}catch (IOException e) {
			CommonLog.e("getDocId", "IOException 1["+e.getMessage().toString()+"]");
		} catch (XmlPullParserException e) {
			// TODO Auto-generated catch block
			CommonLog.e("getDocid", "XmlPullParserException");
			e.printStackTrace();
		}

//	        catch (Exception e) {
//				// TODO: handle exception
//	        	CommonLog.e("getGMPAuthPwd", "WebService exception ["+e.getMessage()+"]");
//			}

		return returnValue;
	}
}