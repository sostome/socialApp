package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

public class IQAlarmEx extends IQ {
	public final static String NAMESPACE = "jabber:iq:alarm";
//	private final String NAMESPACE_Q = "<query xmlns=\"jabber:iq:users\">";

	private String onoff;
	private String namespace = null;

	public IQAlarmEx() {
	}

	public IQAlarmEx(String namespace, String onoff) {
		this.namespace = namespace;
		this.onoff = onoff;
	}

	
	@Override
	public String getChildElementXML() {
		StringBuilder buf = new StringBuilder();
//		buf.append(NAMESPACE_Q);
//		if (namespace != null) {
//			buf.append("<user>").append(namespace).append("</user>");
//		}
//		buf.append("</query>");
		return buf.toString();
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getNamespace() {
		return namespace;
	}
	
	public String getOnoff(){
		return this.onoff;
	}

	public static class Provider implements IQProvider {

		@Override
		public IQ parseIQ(XmlPullParser parser) throws Exception {
			// TODO Auto-generated method stub
			String onoff = null;
			String namespace = null;
			boolean done = false;
			while (!done) {
				int eventType = parser.next();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("on")) {
						onoff = parser.getName();
					} else if (parser.getName().equals("off")) {
						onoff = parser.getName();
						
					}
					else {
					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals("query")) {
						namespace = parser.getNamespace();
						done = true;

					}
				}
			}
			return new IQAlarmEx(namespace, onoff);
		}

	}

}