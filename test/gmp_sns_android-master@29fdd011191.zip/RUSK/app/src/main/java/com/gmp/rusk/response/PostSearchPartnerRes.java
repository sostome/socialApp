package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.utils.CommonLog;

public class PostSearchPartnerRes extends Res{
	
//	private final String JSON_RESULTCOUNT				= "resultCount";
	private final String JSON_RESULTS 					= "results";
	private final String JSON_USERNO 					= "userNo";
	private final String JSON_NAME	 					= "name";
	private final String JSON_COMPANY					= "company";
	private final String JSON_IMAGEAVAILABLE			= "imageAvailable";
	private final String JSON_AVAILABLE					= "available";
	private final String JSON_TYPE						= "type";
	
	ArrayList<PartnerSearchListData> m_arrPartnerSearchListDatas = null;
	
	public PostSearchPartnerRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_RESULTS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_RESULTS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrPartnerSearchListDatas = new ArrayList<PartnerSearchListData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						int nUserNo = jsonItem.optInt(JSON_USERNO);
						String strName = jsonItem.optString(JSON_NAME);
						String strCompany = jsonItem.optString(JSON_COMPANY);
						boolean isImageAvailable = jsonItem.optBoolean(JSON_IMAGEAVAILABLE);
						boolean isAvailable = jsonItem.optBoolean(JSON_AVAILABLE);
						String strType = jsonItem.optString(JSON_TYPE);
						
						PartnerSearchListData item = new PartnerSearchListData(nUserNo, strName,null,null,strCompany, isImageAvailable, isAvailable, strType);
						
						m_arrPartnerSearchListDatas.add(item);
					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}
	
	public ArrayList<PartnerSearchListData> getPartnerSearchListData()
	{
		return m_arrPartnerSearchListDatas;
	}

}
