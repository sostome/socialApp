package com.gmp.rusk.network;

public interface WebListener {
	public void onPreRequest();
	public void onNetworkError(int nErrorCode, String strMessage);
	public void onPostRequest(String a_strData);
	
}
