package com.gmp.rusk.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import java.util.ArrayList;

/**
 * Created by 강철 on 2015-12-15.
 */
public class PermissionCheck {

    public final static int PERMISSION_CODE_READ_CALENDAR = 1;
    public final static int PERMISSION_CODE_WRITE_CALENDAR = 2;
    public final static int PERMISSION_CODE_CAMERA = 3;
    public final static int PERMISSION_CODE_READ_CONTACTS = 4;
    public final static int PERMISSION_CODE_WRITE_CONTACTS = 5;
    public final static int PERMISSION_CODE_GET_ACCOUNTS = 6;
    public final static int PERMISSION_CODE_ACCESS_FINE_LOCATION = 7;
    public final static int PERMISSION_CODE_ACCESS_COARSE_LOCATION = 8;
    public final static int PERMISSION_CODE_RECORD_AUDIO = 9;
    public final static int PERMISSION_CODE_READ_PHONE_STATE = 10;
    public final static int PERMISSION_CODE_CALL_PHONE = 11;
    public final static int PERMISSION_CODE_READ_CALL_LOG = 12;
    public final static int PERMISSION_CODE_WRITE_CALL_LOG = 13;
    public final static int PERMISSION_CODE_ADD_VOICEMAIL = 14;
    public final static int PERMISSION_CODE_USE_SIP = 15;
    public final static int PERMISSION_CODE_PROCESS_OUTGOING_CALLS = 16;
    public final static int PERMISSION_CODE_BODY_SENSORS = 17;
    public final static int PERMISSION_CODE_SEND_SMS = 18;
    public final static int PERMISSION_CODE_RECEIVE_SMS = 19;
    public final static int PERMISSION_CODE_READ_SMS = 20;
    public final static int PERMISSION_CODE_RECEIVE_WAP_PUSH = 21;
    public final static int PERMISSION_CODE_RECEIVE_MMS = 22;
    public final static int PERMISSION_CODE_READ_EXTERNAL_STORAGE = 23;
    public final static int PERMISSION_CODE_WRITE_EXTERNAL_STORAGE = 24;


    public final static String ALL_PERMISSION_GRANT = "all_permission_grant";
    public final static String PERMISSION_GRANT = "permission_grant";
    public final static ArrayList<String> DANGEROUS_PERMISSIONS = new ArrayList<String>();
    static{
        DANGEROUS_PERMISSIONS.add(Manifest.permission.READ_CALENDAR);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.WRITE_CALENDAR);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.CAMERA);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.READ_CONTACTS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.WRITE_CONTACTS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.GET_ACCOUNTS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.ACCESS_FINE_LOCATION);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.RECORD_AUDIO);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.READ_PHONE_STATE);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.CALL_PHONE);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.READ_CALL_LOG);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.WRITE_CALL_LOG);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.ADD_VOICEMAIL);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.USE_SIP);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.PROCESS_OUTGOING_CALLS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.BODY_SENSORS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.SEND_SMS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.RECEIVE_SMS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.READ_SMS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.RECEIVE_WAP_PUSH);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.RECEIVE_MMS);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        DANGEROUS_PERMISSIONS.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }

    private static String getPermissionName(int code){
        if(code == PERMISSION_CODE_READ_CALENDAR){
            return Manifest.permission.READ_CALENDAR;
        } else if(code == PERMISSION_CODE_WRITE_CALENDAR){
            return Manifest.permission.WRITE_CALENDAR;
        } else if(code == PERMISSION_CODE_CAMERA){
            return Manifest.permission.CAMERA;
        } else if(code == PERMISSION_CODE_READ_CONTACTS){
            return Manifest.permission.READ_CONTACTS;
        } else if(code == PERMISSION_CODE_WRITE_CONTACTS){
            return Manifest.permission.WRITE_CONTACTS;
        } else if(code == PERMISSION_CODE_GET_ACCOUNTS){
            return Manifest.permission.GET_ACCOUNTS;
        } else if(code == PERMISSION_CODE_ACCESS_FINE_LOCATION){
            return Manifest.permission.ACCESS_FINE_LOCATION;
        } else if(code == PERMISSION_CODE_ACCESS_COARSE_LOCATION){
            return Manifest.permission.ACCESS_COARSE_LOCATION;
        } else if(code == PERMISSION_CODE_RECORD_AUDIO){
            return Manifest.permission.RECORD_AUDIO;
        } else if(code == PERMISSION_CODE_READ_PHONE_STATE){
            return Manifest.permission.READ_PHONE_STATE;
        } else if(code == PERMISSION_CODE_CALL_PHONE){
            return Manifest.permission.CALL_PHONE;
        } else if(code == PERMISSION_CODE_READ_CALL_LOG){
            return Manifest.permission.READ_CALL_LOG;
        } else if(code == PERMISSION_CODE_WRITE_CALL_LOG){
            return Manifest.permission.WRITE_CALL_LOG;
        } else if(code == PERMISSION_CODE_ADD_VOICEMAIL){
            return Manifest.permission.ADD_VOICEMAIL;
        } else if(code == PERMISSION_CODE_USE_SIP){
            return Manifest.permission.USE_SIP;
        } else if(code == PERMISSION_CODE_PROCESS_OUTGOING_CALLS){
            return Manifest.permission.PROCESS_OUTGOING_CALLS;
        } else if(code == PERMISSION_CODE_BODY_SENSORS){
            return Manifest.permission.BODY_SENSORS;
        } else if(code == PERMISSION_CODE_SEND_SMS){
            return Manifest.permission.SEND_SMS;
        } else if(code == PERMISSION_CODE_RECEIVE_SMS){
            return Manifest.permission.RECEIVE_SMS;
        } else if(code == PERMISSION_CODE_READ_SMS){
            return Manifest.permission.READ_SMS;
        } else if(code == PERMISSION_CODE_RECEIVE_WAP_PUSH){
            return Manifest.permission.RECEIVE_WAP_PUSH;
        } else if(code == PERMISSION_CODE_RECEIVE_MMS){
            return Manifest.permission.RECEIVE_MMS;
        } else if(code == PERMISSION_CODE_READ_EXTERNAL_STORAGE){
            return Manifest.permission.READ_EXTERNAL_STORAGE;
        } else if(code == PERMISSION_CODE_WRITE_EXTERNAL_STORAGE){
            return Manifest.permission.WRITE_EXTERNAL_STORAGE;
        } else {
            return "";
        }
    }

    public static void checkAllPermission(Context context, int requestCode){

        PackageInfo packageInfo = null;
        String[] requestedPermissions = null;
        ArrayList<String> arrNeedPermissions = new ArrayList<>();
        try {
            packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_PERMISSIONS);
            requestedPermissions = packageInfo.requestedPermissions;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        for(int i = 0; i < requestedPermissions.length; i++){

            if(DANGEROUS_PERMISSIONS.contains(requestedPermissions[i])) {
                if (ContextCompat.checkSelfPermission(context, requestedPermissions[i]) != PackageManager.PERMISSION_GRANTED) {
                    arrNeedPermissions.add(requestedPermissions[i]);
                }
            }
        }
        String[] arr = new String[arrNeedPermissions.size()];

        if(arrNeedPermissions.isEmpty()){
            arr = new String[]{ALL_PERMISSION_GRANT};
        } else {
            arr = (String[]) arrNeedPermissions.toArray(arr);
        }
        ActivityCompat.requestPermissions((Activity) context, arr, requestCode);

    }

    public static void checkPermission(Context context, int code){

        String strPermissionName = getPermissionName(code);
        if(ContextCompat.checkSelfPermission(context, strPermissionName) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) context, new String[]{strPermissionName}, code);
        } else {
            ActivityCompat.requestPermissions((Activity) context, new String[]{PERMISSION_GRANT}, code);
        }
    }

    public static void checkPermission(Context context, ArrayList<Integer> codes, int requestCode){
        String[] arrPermissionName = new String[codes.size()];
        for(int i = 0; i < arrPermissionName.length; i++){
            if(ContextCompat.checkSelfPermission(context, getPermissionName(codes.get(i))) != PackageManager.PERMISSION_GRANTED) {
                arrPermissionName[i] = getPermissionName(codes.get(i));
            } else {
                arrPermissionName[i] = PERMISSION_GRANT;
            }
        }
        ActivityCompat.requestPermissions((Activity) context, arrPermissionName, requestCode);
    }
}
