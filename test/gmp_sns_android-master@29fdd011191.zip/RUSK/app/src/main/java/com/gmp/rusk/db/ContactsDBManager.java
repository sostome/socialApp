package com.gmp.rusk.db;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.database.Cursor;
import android.util.SparseArray;

import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ContactsDBManager {
	
	private ContactsDBAdapter m_dbAdapter = null;
	
	public ContactsDBManager(Context a_Context)
	{
		m_dbAdapter = new ContactsDBAdapter(a_Context);
	}
	
	public void open()
	{
		m_dbAdapter.open();
	}
	
	public void openReadOnly()
	{
		m_dbAdapter.openReadOnly();
	}
	
	public void close()
	{
		m_dbAdapter.close();
	}
	
	public int insertContacts(ArrayList<UserListData> a_arrUserListData) {
		return m_dbAdapter.insertContacts(a_arrUserListData);
	}

	/**
	 * insertContacts 주소록 단일 추가
	 * 
	 * @param a_Context
	 * @param a_userListData
	 * @return 추가한 Item의 개수
	 */
	public int insertContacts(UserListData a_userListData) {
		return m_dbAdapter.insertContacts(a_userListData);
	}

	/**
	 * updateContacts 주소록 Array 수정 userno == userid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_arrUserListData
	 * @return 수정한 Item의 개수
	 */
	public int updateContacts(ArrayList<UserListData> a_arrUserListData) {
		return m_dbAdapter.updateContacts(a_arrUserListData);
	}

	/**
	 * updateContacts 주소록 단일 수정 userno == userid 인 Item으로 수정한다.
	 * 
	 * @param a_Context
	 * @param a_userListData
	 * @return 수정한 Item의 개수
	 */
	public int updateContacts(UserListData a_userListData) {
		return m_dbAdapter.updateContacts(a_userListData);
	}
	
	public int updateContactsIsFellow(int a_nUserNo, boolean a_isFellow) {
		return m_dbAdapter.updateContacts(a_nUserNo, a_isFellow);
	}

	/**
	 * deleteContacts 주소록 전체 삭제
	 * 
	 * @param a_Context
	 * @return 삭제한 Item의 개수
	 */
	public int deleteContacts() {
		return m_dbAdapter.deleteContacts();
	}

	/**
	 * deleteContacts 주소록 삭제
	 * 
	 * @param a_Context
	 * @param a_nUserNo
	 *            삭제할 UserNo
	 * @return 삭제한 Item의 개수
	 */
	public int deleteContacts(int a_nUserNo) {
		return m_dbAdapter.deleteContacts(a_nUserNo);
	}

	/**
	 * getContacts 주소록 가져오기
	 * 
	 * @param a_Context
	 * @return 주소록 ArrayList
	 */
	public ArrayList<UserListData> getContacts() {
		ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
		
		Cursor cursor = m_dbAdapter.getContactsList();

		if (cursor.moveToFirst()) {
			do {
				int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
				Gson gson = new Gson();
				Type type = new TypeToken<HashMap<String, String>>() {}.getType();
				String strMapData = "";
				PersonalData personalData = null;
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
					HashMap mapPersonalData = gson.fromJson(strMapData, type);
					personalData = new PersonalData(mapPersonalData);
				} catch (Exception e) {
					e.printStackTrace();
					personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
				}

				String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
				boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
				boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
				String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
				boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
				String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
				String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));

				UserListData data = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);

				arrUserListData.add(data);
			} while (cursor.moveToNext());
		}

		cursor.close();

		return arrUserListData;
	}
	
	public SparseArray<UserListData> getContactsReturnSparseArray() {
		SparseArray<UserListData> arrUserListData = new SparseArray<UserListData>();
		Cursor cursor = m_dbAdapter.getContactsList();

		if (cursor.moveToFirst()) {
			do {
				int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
				Gson gson = new Gson();
				Type type = new TypeToken<HashMap<String, String>>() {}.getType();
				String strMapData = "";
				PersonalData personalData = null;
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
					HashMap mapPersonalData = gson.fromJson(strMapData, type);
					personalData = new PersonalData(mapPersonalData);
				} catch (Exception e) {
					e.printStackTrace();
					personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
				}
				String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
				boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
				boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
				String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
				boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
				String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
				String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));

				UserListData data = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);

				arrUserListData.put(nUserNo, data);
			} while (cursor.moveToNext());
		}

		cursor.close();
		return arrUserListData;
	}

	/**
	 * getContacts 주소록 가져오기
	 * 
	 * @param a_Context
	 * @param a_nUserNo
	 * @return UserListData
	 */
	public UserListData getContacts(int a_nUserNo) {
		UserListData userListData = null;
		Cursor cursor = m_dbAdapter.getContacts(a_nUserNo);

		if (cursor.moveToFirst()) {
			int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
			Gson gson = new Gson();
			Type type = new TypeToken<HashMap<String, String>>() {}.getType();
			String strMapData = "";
			PersonalData personalData = null;
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
				HashMap mapPersonalData = gson.fromJson(strMapData, type);
				personalData = new PersonalData(mapPersonalData);
			} catch (Exception e) {
				e.printStackTrace();
				personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
			}
			String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
			boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
			boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
			String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
			boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
			String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
			String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));
			
			userListData = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);
		}

		cursor.close();
		return userListData;
	}

	/**
	 * getContactsByFellows 동료 리스트 가져오기
	 * 
	 * @param a_Context
	 * @return 주소록 ArrayList
	 */
	public ArrayList<UserListData> getContactsByFellows() {
		ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
		Cursor cursor = m_dbAdapter.getContactsByFellowList();

		if (cursor.moveToFirst()) {
			do {
				int nUserNo = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERID));
				Gson gson = new Gson();
				Type type = new TypeToken<HashMap<String, String>>() {}.getType();
				String strMapData = "";
				PersonalData personalData = null;
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					strMapData = crypto.decrypt(cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_PERSONAL)));
					HashMap mapPersonalData = gson.fromJson(strMapData, type);
					personalData = new PersonalData(mapPersonalData);
				} catch (Exception e) {
					e.printStackTrace();
					personalData = new PersonalData("", "" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" );
				}
				String strUserType = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERTYPE));
				boolean isImageAvailable = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_HASTHUMB)) == 1 ? true : false;
				boolean isActive = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISAPPINSTALLED)) == 1 ? true : false;
				String strUserStatus = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_USERSTATUS));
				boolean isFellow = cursor.getInt(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_ISFELLOW)) == 1 ? true : false;
				String strFellowAddTime = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_FELLOWADDTIME));
				String strGreeting = cursor.getString(cursor.getColumnIndex(ContactsDBAdapter.KEY_CONTACTS_GREETING));
				
				UserListData data = new UserListData(nUserNo, personalData, strUserType, isImageAvailable, isActive, strGreeting, strUserStatus, isFellow, strFellowAddTime);

				arrUserListData.add(data);
			} while (cursor.moveToNext());
		}

		cursor.close();
		
		return arrUserListData;
	}

}
