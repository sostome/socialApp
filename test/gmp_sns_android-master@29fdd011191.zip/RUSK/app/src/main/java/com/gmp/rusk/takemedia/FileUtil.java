package com.gmp.rusk.takemedia;

import java.io.File;

import android.os.Environment;
import android.os.StatFs;
/**
 * 파일관련 로직들 모아둔 클래스
 */
public class FileUtil {
	static final long ERROR = -1;
	
	public static boolean externalMemoryAvailable()
	{
		return android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
	}
	
	public static long getAvailableExternalMemorySize()
	{
		if(!externalMemoryAvailable())
			return ERROR;
		File path = Environment.getExternalStorageDirectory();
		StatFs stat = new StatFs(path.getPath());
		long blockSize = stat.getBlockSize();
		long availableBlocks = stat.getAvailableBlocks();
		return availableBlocks * blockSize;
	}
	
	public static String getExtRootPath(boolean bCreate){
		File path = Environment.getExternalStorageDirectory();
		String fullpath = path.getAbsolutePath();
		if(bCreate){
			File _dir = new File(fullpath);
			if(!_dir.exists()){
				_dir.mkdir();
			}
		}
		return fullpath;
	}
}
