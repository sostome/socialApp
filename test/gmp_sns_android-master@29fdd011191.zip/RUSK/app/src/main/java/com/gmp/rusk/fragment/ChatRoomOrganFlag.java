package com.gmp.rusk.fragment;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatInviteTabAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.DepartmentsData;
import com.gmp.rusk.datamodel.NavigationInfoData;
import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.datamodel.UserSearchListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.ChatroomOrganChartListItemlayout;
import com.gmp.rusk.layout.OrganChartListItemLayout;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetDepartmentReq;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.response.GetDepartmentRes;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.PopupIndex;

import java.util.ArrayList;

/**
 * Created by kang on 2017-07-13.
 */

public class ChatRoomOrganFlag  extends Fragment implements AdapterView.OnItemSelectedListener, View.OnClickListener, CompoundButton.OnCheckedChangeListener, View.OnTouchListener {

    public MyApp App = MyApp.getInstance();
    private FragmentActivity m_Activity = null;

    ArrayList<NavigationInfoData> m_arrNavigationInfoDatas = null;
    ArrayList<DepartmentsData> m_arrDepartmentsDatas = null;
    ArrayList<DepartmentUserListData> m_arrDepartmentUserListDatas = null;

    View m_vOrganChart;

    private LinearLayout layout_organchart = null;
    private RelativeLayout layout_organregular = null;

    private LinearLayout layout_organchartlist_list = null;
    private ListView m_lvorganRegularList = null;
    // private SectionListAdapter m_SectionListAdapter = null;
    // private ArrayList<SectionListItem> m_SectionListItems = null; //
    // SectionListView
    // 에 넣는 Item
    // 생성

    private static int SEARCH_NAME = 0;
    private static int SEARCH_TEAM = 1;

    private int m_nSearchType = 0;
    private int m_nPage = 1;

    EditText et_search_keyword;

    TextView tv_nolist;
    ImageButton ib_cancel;

    TextView m_tvSectionText;
    TextView m_tvSectionTextOrgan;
    CheckBox m_cbAllcheckOrgan;
    Spinner spn_search_type;
    TextView tv_spinner_text;
    HorizontalScrollView m_hsvOrgMenu;
    RelativeLayout layout_nolisttext , layout_hinttext;
    RelativeLayout m_LayoutDepartmentsList;
    ArrayAdapter<String> adspin;
    RelativeLayout m_LayoutOrgMenu01,m_LayoutOrgMenu02, m_LayoutOrgMenu03, m_LayoutOrgMenu04, m_LayoutOrgMenu05, m_LayoutOrgMenu06, m_LayoutOrgMenu07,
            m_LayoutOrgMenu08, m_LayoutOrgMenu09, m_LayoutOrgMenu10, m_LayoutOrgMenu11, m_LayoutOrgMenu12, m_LayoutOrgMenu13;
    ImageView m_ivDepth1,m_ivDepth2,m_ivDepth3,m_ivDepth4,m_ivDepth5,m_ivDepth6,m_ivDepth7,m_ivDepth8,m_ivDepth9,m_ivDepth10,m_ivDepth11,m_ivDepth12,m_ivDepth13,
            m_ivDepthArrow1,m_ivDepthArrow2,m_ivDepthArrow3,m_ivDepthArrow4,m_ivDepthArrow5,m_ivDepthArrow6,m_ivDepthArrow7,m_ivDepthArrow8,m_ivDepthArrow9,m_ivDepthArrow10,m_ivDepthArrow11,m_ivDepthArrow12,m_ivDepthArrow13;
    TextView m_tvOrgMenu01, m_tvOrgMenu02, m_tvOrgMenu03, m_tvOrgMenu04, m_tvOrgMenu05, m_tvOrgMenu06, m_tvOrgMenu07, m_tvOrgMenu08, m_tvOrgMenu09,
            m_tvOrgMenu10, m_tvOrgMenu11, m_tvOrgMenu12, m_tvOrgMenu13;
    OrganChartListAdapter m_OrganChartListAdapter;
    private ListView m_lvOrganChartList = null;
    private ProgressDlg m_Progress = null;
    private CommonPopup m_Popup = null;

    String m_strCurrentSelTeamCode = "";
    ArrayList<String> m_arrSKTTeamList = null;
    ArrayList<String> m_arrSKTTeamCodeList = null;

    private InputMethodManager imm;
    public boolean m_isRunning = false;

    ArrayList<UserSearchListData> m_arrUserSearchListDatas;

    // 사용자가 눌러서 터치를 한것인지, 앱에서 판단해서 체크하는지
    boolean m_isTouchCheckBox = false;

    ArrayList<Integer> m_arrUserNumbers;

    boolean m_isFirstView = true;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        m_Activity = getActivity();
        imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        m_isRunning = false;
    }

    @Override
    public void onStop() {
        // TODO Auto-generated method stub
        super.onStop();
        m_isRunning = false;
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub

        super.onResume();
        m_isRunning = true;
    }

    @Override
    public void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        if (imm != null && et_search_keyword != null)
            imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        m_isFirstView = true;
        ((ChatInviteTabAct) m_Activity).setNotifyListener(m_NotifyListner);
        m_arrUserNumbers = ((ChatInviteTabAct) m_Activity).getUserNumbers();
        m_vOrganChart = inflater.inflate(R.layout.fragact_chatorganization_chart, container, false);

        layout_organchart = (LinearLayout) m_vOrganChart.findViewById(R.id.layout_organchart);
        layout_organregular = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_organregular);

        m_LayoutDepartmentsList = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_departments_list);

        m_tvSectionTextOrgan = (TextView)m_vOrganChart.findViewById(R.id.tv_sectiontext);

      if (AppSetting.FEATURE_VARIANT.equals("R") || AppSetting.FEATURE_VARIANT.equals("S")) {
         //requestDepartment(App.m_EntryData.m_strCompanyCode, App.m_EntryData.m_strDepartmentCode);
      } else {
        initSearchOrganChart();
      }
        initSearchBar();
        return m_vOrganChart;
    }

    private void initSearchBar() {
        m_arrSKTTeamList = new ArrayList<>();
        m_arrSKTTeamCodeList = new ArrayList<>();
        for (int i = 0 ; i < App.m_EntryData.m_arrCompanyData.size() ; i++) {
            if(App.m_EntryData.m_strCompanyCode.equals(App.m_EntryData.m_arrCompanyData.get(i).strCode)){
                m_arrSKTTeamList.add(0,getString(R.string.search_my_company)+" "+App.m_EntryData.m_arrCompanyData.get(i).strName);
                m_arrSKTTeamCodeList.add(0,App.m_EntryData.m_arrCompanyData.get(i).strCode);
            } else {
                m_arrSKTTeamList.add(App.m_EntryData.m_arrCompanyData.get(i).strName);
                m_arrSKTTeamCodeList.add(App.m_EntryData.m_arrCompanyData.get(i).strCode);
            }
        }

        adspin = new ArrayAdapter<String>(m_Activity,R.layout.layout_spinner_textview,m_arrSKTTeamList);
        spn_search_type = (Spinner) m_vOrganChart.findViewById(R.id.spn_search_type);
        adspin.setDropDownViewResource(R.layout.spinner_custom_list_item);
        tv_spinner_text = (TextView) m_vOrganChart.findViewById(R.id.tv_spinner_text);
        spn_search_type.setAdapter(adspin);
        spn_search_type.setOnItemSelectedListener(this);

        layout_nolisttext = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_hinttext);
        layout_nolisttext.setVisibility(View.VISIBLE);

    }

    private void initSearchOrganChart() {
        layout_organchart.setVisibility(View.GONE);
        layout_organregular.setVisibility(View.VISIBLE);
        m_LayoutDepartmentsList.setVisibility(View.GONE);

        layout_organchartlist_list = (LinearLayout) m_vOrganChart.findViewById(R.id.layout_organ_regular_list);
        m_lvorganRegularList = (ListView) m_vOrganChart.findViewById(R.id.lv_organ_regular_list);
        layout_organchartlist_list.setVisibility(View.GONE);
        m_tvSectionText = (TextView) m_vOrganChart.findViewById(R.id.tv_sectiontext);


    }


    public void requestDepartment(String strCompanyCode, String strDepartmentCode) {
        showProgress(getString(R.string.progress_search));
        GetDepartmentReq req = new GetDepartmentReq(strCompanyCode, strDepartmentCode);
        WebAPI webApi = new WebAPI(m_Activity);
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((ChatInviteTabAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
//          if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//                   PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          } else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE || a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//                   PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          } else {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          }
            }

            @Override
            public void onPostRequest(String strData) {
                // TODO Auto-generated method stub
                GetDepartmentRes res = new GetDepartmentRes(strData, Res.RES_TYPE_USER_INFO);
                res.parseData();
                if (!res.getMessage().equals(null)) {
                    m_arrNavigationInfoDatas = res.getNavigationInfoData();
                    m_arrDepartmentsDatas = res.getDepartmentsData();
                    m_arrDepartmentUserListDatas = res.getDepartmentUserListData();
                }
                if(m_arrDepartmentUserListDatas != null) {
                    ArrayList<Integer> arrUserID = new ArrayList<Integer>();
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {
                        if(TTalkDBManager.ContactsDBManager.getContacts(getActivity(), m_arrDepartmentUserListDatas.get(i).getUserNo()) == null)
                             arrUserID.add(m_arrDepartmentUserListDatas.get(i).getUserNo());
                    }
                    int[] nNotInDBUsers = new int[arrUserID.size()];
                    for (int j = 0; j < arrUserID.size(); j++) {
                        nNotInDBUsers[j] = arrUserID.get(j);
                    }
                    if (nNotInDBUsers.length > 0) {
                        requestAddedByUserList(nNotInDBUsers);
                    } else {
                        closeProgress();
                        initOrganChartUI();
                    }
                } else {
                    closeProgress();
                    initOrganChartUI();
                }

                int nDataSize = 0;
                if(m_arrDepartmentUserListDatas != null){
                    nDataSize = m_arrDepartmentUserListDatas.size();
                }
                m_tvSectionTextOrgan.setText(getString(R.string.layout_sectionstring_organ) + " " + nDataSize);

            }

        });
    }

    private void initOrganChartUI() {
        m_isFirstView = false;
        layout_organchart.setVisibility(View.VISIBLE);
        layout_organregular.setVisibility(View.GONE);
        m_LayoutDepartmentsList.setVisibility(View.VISIBLE);

        m_cbAllcheckOrgan = (CheckBox) m_vOrganChart.findViewById(R.id.cb_chat_allmember);
        m_cbAllcheckOrgan.setOnCheckedChangeListener(this);
        m_cbAllcheckOrgan.setOnTouchListener(this);
        m_cbAllcheckOrgan.setChecked(false);

        if(m_arrDepartmentUserListDatas == null || m_arrDepartmentUserListDatas.size() == 0){
            m_cbAllcheckOrgan.setVisibility(View.GONE);
        } else {
            m_cbAllcheckOrgan.setVisibility(View.VISIBLE);
        }

        m_tvOrgMenu01 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_01);
        m_tvOrgMenu02 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_02);
        m_tvOrgMenu03 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_03);
        m_tvOrgMenu04 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_04);
        m_tvOrgMenu05 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_05);
        m_tvOrgMenu06 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_06);
        m_tvOrgMenu07 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_07);
        m_tvOrgMenu08 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_08);
        m_tvOrgMenu09 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_09);
        m_tvOrgMenu10 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_10);
        m_tvOrgMenu11 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_11);
        m_tvOrgMenu12 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_12);
        m_tvOrgMenu13 = (TextView) m_vOrganChart.findViewById(R.id.tv_org_menu_13);
        m_LayoutOrgMenu01 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_01);
        m_LayoutOrgMenu02 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_02);
        m_LayoutOrgMenu03 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_03);
        m_LayoutOrgMenu04 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_04);
        m_LayoutOrgMenu05 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_05);
        m_LayoutOrgMenu06 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_06);
        m_LayoutOrgMenu07 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_07);
        m_LayoutOrgMenu08 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_08);
        m_LayoutOrgMenu09 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_09);
        m_LayoutOrgMenu10 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_10);
        m_LayoutOrgMenu11 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_11);
        m_LayoutOrgMenu12 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_12);
        m_LayoutOrgMenu13 = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_org_menu_13);
        m_ivDepth1 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth1);
        m_ivDepth2 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth2);
        m_ivDepth3 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth3);
        m_ivDepth4 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth4);
        m_ivDepth5 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth5);
        m_ivDepth6 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth6);
        m_ivDepth7 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth7);
        m_ivDepth8 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth8);
        m_ivDepth9 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth9);
        m_ivDepth10 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth10);
        m_ivDepth11 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth11);
        m_ivDepth12 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth12);
        m_ivDepth13 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth13);

        m_ivDepthArrow1 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow1);
        m_ivDepthArrow2 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow2);
        m_ivDepthArrow3 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow3);
        m_ivDepthArrow4 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow4);
        m_ivDepthArrow5 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow5);
        m_ivDepthArrow6 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow6);
        m_ivDepthArrow7 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow7);
        m_ivDepthArrow8 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow8);
        m_ivDepthArrow9 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow9);
        m_ivDepthArrow10 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow10);
        m_ivDepthArrow11 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow11);
        m_ivDepthArrow12 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow12);
        m_ivDepthArrow13 = (ImageView) m_vOrganChart.findViewById(R.id.iv_depth_arrow13);

        m_hsvOrgMenu = (HorizontalScrollView) m_vOrganChart.findViewById(R.id.hsv_org_menu);

        m_LayoutOrgMenu01.setOnClickListener(this);
        m_LayoutOrgMenu02.setOnClickListener(this);
        m_LayoutOrgMenu03.setOnClickListener(this);
        m_LayoutOrgMenu04.setOnClickListener(this);
        m_LayoutOrgMenu05.setOnClickListener(this);
        m_LayoutOrgMenu06.setOnClickListener(this);
        m_LayoutOrgMenu07.setOnClickListener(this);
        m_LayoutOrgMenu08.setOnClickListener(this);
        m_LayoutOrgMenu09.setOnClickListener(this);
        m_LayoutOrgMenu10.setOnClickListener(this);
        m_LayoutOrgMenu11.setOnClickListener(this);
        m_LayoutOrgMenu12.setOnClickListener(this);
        m_LayoutOrgMenu13.setOnClickListener(this);

        m_LayoutOrgMenu01.setVisibility(View.GONE);
        m_LayoutOrgMenu02.setVisibility(View.GONE);
        m_LayoutOrgMenu03.setVisibility(View.GONE);
        m_LayoutOrgMenu04.setVisibility(View.GONE);
        m_LayoutOrgMenu05.setVisibility(View.GONE);
        m_LayoutOrgMenu06.setVisibility(View.GONE);
        m_LayoutOrgMenu07.setVisibility(View.GONE);
        m_LayoutOrgMenu08.setVisibility(View.GONE);
        m_LayoutOrgMenu09.setVisibility(View.GONE);
        m_LayoutOrgMenu10.setVisibility(View.GONE);
        m_LayoutOrgMenu11.setVisibility(View.GONE);
        m_LayoutOrgMenu12.setVisibility(View.GONE);
        m_LayoutOrgMenu13.setVisibility(View.GONE);

        if(m_arrNavigationInfoDatas != null) {
            if (m_arrNavigationInfoDatas.size() > 0) {
                m_LayoutOrgMenu01.setVisibility(View.VISIBLE);
                m_tvOrgMenu01.setText(m_arrNavigationInfoDatas.get(0).getDepartMentName());
                m_tvOrgMenu01.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth1.setImageResource(R.drawable.icon_depth_1_selected);
                m_ivDepthArrow1.setVisibility(View.GONE);
			/*m_LayoutOrgMenu01.setBackgroundResource(R.drawable.org_menu_01_selected);*/
            }
            if (m_arrNavigationInfoDatas.size() > 1) {
                m_LayoutOrgMenu02.setVisibility(View.VISIBLE);
                m_tvOrgMenu02.setText(m_arrNavigationInfoDatas.get(1).getDepartMentName());
                m_tvOrgMenu01.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth1.setImageResource(R.drawable.btn_org_menu_01);
                m_ivDepthArrow1.setVisibility(View.VISIBLE);
                m_tvOrgMenu02.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth2.setImageResource(R.drawable.icon_depth_2_selected);
                m_ivDepthArrow2.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 2) {
                m_LayoutOrgMenu03.setVisibility(View.VISIBLE);
                m_tvOrgMenu03.setText(m_arrNavigationInfoDatas.get(2).getDepartMentName());
                m_tvOrgMenu02.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth2.setImageResource(R.drawable.btn_org_menu_02);
                m_ivDepthArrow2.setVisibility(View.VISIBLE);
                m_tvOrgMenu03.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth3.setImageResource(R.drawable.icon_depth_3_selected);
                m_ivDepthArrow3.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 3) {
                m_LayoutOrgMenu04.setVisibility(View.VISIBLE);
                m_tvOrgMenu04.setText(m_arrNavigationInfoDatas.get(3).getDepartMentName());
                m_tvOrgMenu03.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth3.setImageResource(R.drawable.btn_org_menu_03);
                m_ivDepthArrow3.setVisibility(View.VISIBLE);
                m_tvOrgMenu04.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth4.setImageResource(R.drawable.icon_depth_4_selected);
                m_ivDepthArrow4.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 4) {
                m_LayoutOrgMenu05.setVisibility(View.VISIBLE);
                m_tvOrgMenu05.setText(m_arrNavigationInfoDatas.get(4).getDepartMentName());
                m_tvOrgMenu04.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth4.setImageResource(R.drawable.btn_org_menu_04);
                m_ivDepthArrow4.setVisibility(View.VISIBLE);
                m_tvOrgMenu05.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth5.setImageResource(R.drawable.icon_depth_5_selected);
                m_ivDepthArrow5.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 5) {
                m_LayoutOrgMenu06.setVisibility(View.VISIBLE);
                m_tvOrgMenu06.setText(m_arrNavigationInfoDatas.get(5).getDepartMentName());
                m_tvOrgMenu05.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth5.setImageResource(R.drawable.btn_org_menu_05);
                m_ivDepthArrow5.setVisibility(View.VISIBLE);
                m_tvOrgMenu06.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth6.setImageResource(R.drawable.icon_depth_6_selected);
                m_ivDepthArrow6.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 6) {
                m_LayoutOrgMenu07.setVisibility(View.VISIBLE);
                m_tvOrgMenu07.setText(m_arrNavigationInfoDatas.get(6).getDepartMentName());
                m_tvOrgMenu06.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth6.setImageResource(R.drawable.btn_org_menu_06);
                m_ivDepthArrow6.setVisibility(View.VISIBLE);
                m_tvOrgMenu07.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth7.setImageResource(R.drawable.icon_depth_7_selected);
                m_ivDepthArrow7.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 7) {
                m_LayoutOrgMenu08.setVisibility(View.VISIBLE);
                m_tvOrgMenu08.setText(m_arrNavigationInfoDatas.get(7).getDepartMentName());
                m_tvOrgMenu07.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth7.setImageResource(R.drawable.btn_org_menu_07);
                m_ivDepthArrow7.setVisibility(View.VISIBLE);
                m_tvOrgMenu08.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth8.setImageResource(R.drawable.icon_depth_8_selected);
                m_ivDepthArrow8.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 8) {
                m_LayoutOrgMenu09.setVisibility(View.VISIBLE);
                m_tvOrgMenu09.setText(m_arrNavigationInfoDatas.get(8).getDepartMentName());
                m_tvOrgMenu08.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth8.setImageResource(R.drawable.btn_org_menu_08);
                m_ivDepthArrow8.setVisibility(View.VISIBLE);
                m_tvOrgMenu09.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth9.setImageResource(R.drawable.icon_depth_9_selected);
                m_ivDepthArrow9.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 9) {
                m_LayoutOrgMenu10.setVisibility(View.VISIBLE);
                m_tvOrgMenu10.setText(m_arrNavigationInfoDatas.get(9).getDepartMentName());
                m_tvOrgMenu09.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth9.setImageResource(R.drawable.btn_org_menu_09);
                m_ivDepthArrow9.setVisibility(View.VISIBLE);
                m_tvOrgMenu10.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth10.setImageResource(R.drawable.icon_depth_10_selected);
                m_ivDepthArrow10.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 10) {
                m_LayoutOrgMenu11.setVisibility(View.VISIBLE);
                m_tvOrgMenu11.setText(m_arrNavigationInfoDatas.get(10).getDepartMentName());
                m_tvOrgMenu10.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth10.setImageResource(R.drawable.btn_org_menu_10);
                m_ivDepthArrow10.setVisibility(View.VISIBLE);
                m_tvOrgMenu11.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth11.setImageResource(R.drawable.icon_depth_11_selected);
                m_ivDepthArrow11.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 11) {
                m_LayoutOrgMenu12.setVisibility(View.VISIBLE);
                m_tvOrgMenu12.setText(m_arrNavigationInfoDatas.get(11).getDepartMentName());
                m_tvOrgMenu11.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth11.setImageResource(R.drawable.btn_org_menu_11);
                m_ivDepthArrow11.setVisibility(View.VISIBLE);
                m_tvOrgMenu12.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth12.setImageResource(R.drawable.icon_depth_12_selected);
                m_ivDepthArrow12.setVisibility(View.GONE);
            }
            if (m_arrNavigationInfoDatas.size() > 12) {
                m_LayoutOrgMenu13.setVisibility(View.VISIBLE);
                m_tvOrgMenu13.setText(m_arrNavigationInfoDatas.get(12).getDepartMentName());
                m_tvOrgMenu12.setTextColor(Color.parseColor("#2e2020"));
                m_ivDepth12.setImageResource(R.drawable.btn_org_menu_12);
                m_ivDepthArrow12.setVisibility(View.VISIBLE);
                m_tvOrgMenu13.setTextColor(Color.parseColor("#d63b33"));
                m_ivDepth13.setImageResource(R.drawable.icon_depth_13_selected);
                m_ivDepthArrow13.setVisibility(View.GONE);
            }
        } else {
            layout_organchart.setVisibility(View.GONE);
            layout_organregular.setVisibility(View.GONE);
            m_LayoutDepartmentsList.setVisibility(View.GONE);
        }

        m_hsvOrgMenu.post(new Runnable() {

            @Override
            public void run() {
                // TODO Auto-generated method stub
                m_hsvOrgMenu.fullScroll(ScrollView.FOCUS_RIGHT);
            }
        });

        m_lvOrganChartList = (ListView) m_vOrganChart.findViewById(R.id.lv_organchart_list);

        layout_nolisttext = (RelativeLayout) m_vOrganChart.findViewById(R.id.layout_hinttext);
        if (m_arrDepartmentsDatas != null || m_arrDepartmentUserListDatas != null) {
            layout_nolisttext.setVisibility(View.GONE);
            m_lvOrganChartList.setVisibility(View.VISIBLE);
            m_OrganChartListAdapter = new OrganChartListAdapter();
            m_lvOrganChartList.setAdapter(m_OrganChartListAdapter);
        } else {
            m_lvOrganChartList.setVisibility(View.GONE);
            layout_nolisttext.setVisibility(View.VISIBLE);
        }


    }

    private class OrganChartListAdapter extends BaseAdapter {

        @Override
        public void notifyDataSetChanged() {
            // TODO Auto-generated method stub

            super.notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            int nDepartmentsDataSize = 0;
            int nDepartmentUserListDataSize = 0;

            if (m_arrDepartmentsDatas != null)
                nDepartmentsDataSize = m_arrDepartmentsDatas.size();
            if (m_arrDepartmentUserListDatas != null)
                nDepartmentUserListDataSize = m_arrDepartmentUserListDatas.size();

            return nDepartmentsDataSize + nDepartmentUserListDataSize;
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            if (m_arrDepartmentUserListDatas != null && position < m_arrDepartmentUserListDatas.size())
                return m_arrDepartmentUserListDatas.get(position);
            if (m_arrDepartmentsDatas != null)
                return m_arrDepartmentsDatas.get(position - m_arrDepartmentUserListDatas.size());
            return null;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            final int nPosition = position;

            DepartmentUserListData userData;
            DepartmentsData data;

            if (m_arrDepartmentUserListDatas != null) {
                if (nPosition < m_arrDepartmentUserListDatas.size()) {
                    userData = (DepartmentUserListData) m_arrDepartmentUserListDatas.get(nPosition);
                    // 재사용을 어떤식으로 해야 할까
                    // convertView null 시 새로 생성하자
                    // if (convertView == null){
                    convertView = new ChatroomOrganChartListItemlayout(m_Activity);
                    // }
                    ((ChatroomOrganChartListItemlayout) convertView).setDepartmentUserListData(userData);
                    ((ChatroomOrganChartListItemlayout) convertView).setCheckedChangedListener(m_CheckedChangedOrganListner);
                    CheckBox cb_redaction = (CheckBox) ((ChatroomOrganChartListItemlayout) convertView).findViewById(R.id.cb_invite);
                    ImageView ivSelected = (ImageView) ((ChatroomOrganChartListItemlayout) convertView).findViewById(R.id.iv_invite_selected);

                    if (App.m_arrRoomUserList!=null&&App.m_arrRoomUserList.contains(userData.getUserNo()) ||App.m_MyUserInfo.m_nUserNo == userData.getUserNo()) {

                        cb_redaction.setVisibility(View.INVISIBLE);
                        ivSelected.setVisibility(View.VISIBLE);

                    } else {
                        cb_redaction.setVisibility(View.VISIBLE);
                        ivSelected.setVisibility(View.INVISIBLE);
                    }
                    if(!userData.getAvailable()){
                        cb_redaction.setVisibility(View.INVISIBLE);
                        ivSelected.setVisibility(View.INVISIBLE);
                    }


                    if (cb_redaction.getVisibility() != View.INVISIBLE) {
                        boolean is_redaction = false;
                        ArrayList<SearchListCheckData> arrSearchListCheckData = App.m_arrSearchListCheckData;

                        for (int i = 0; i < arrSearchListCheckData.size(); i++) {
                            if (userData.getUserNo() == arrSearchListCheckData.get(i).m_nUserNo) {
                                is_redaction = true;
                                cb_redaction.setChecked(true);
                                break;
                            }
                        }
                        if (!is_redaction) {
                            cb_redaction.setChecked(false);
                        }
                    }
                } else {
                    data = (DepartmentsData) m_arrDepartmentsDatas.get(nPosition - m_arrDepartmentUserListDatas.size());
                    // if (convertView == null){
                    convertView = new OrganChartListItemLayout(m_Activity);
                    // }
                    ((OrganChartListItemLayout) convertView).setDepartmentsData(data);
                    ((OrganChartListItemLayout) convertView).setClickListener(m_ClickListener);

                }
            } else if (m_arrDepartmentsDatas != null) {
                data = (DepartmentsData) m_arrDepartmentsDatas.get(nPosition);
                if (convertView == null)
                    convertView = new OrganChartListItemLayout(m_Activity);
                ((OrganChartListItemLayout) convertView).setDepartmentsData(data);
                ((OrganChartListItemLayout) convertView).setClickListener(m_ClickListener);
            }

            return convertView;
        }
    }

    OrganChartListItemLayout.OnClickListener m_ClickListener = new OrganChartListItemLayout.OnClickListener() {

        @Override
        public void onClick(String a_strDepartmentCode) {
            // TODO Auto-generated method stub
            requestDepartment(m_strCurrentSelTeamCode, a_strDepartmentCode);
        }
    };


    ChatInviteTabAct.OnNotifyListener m_NotifyListner = new ChatInviteTabAct.OnNotifyListener() {

        @Override
        public void onNotify() {
            // TODO Auto-generated method stub
            if(m_OrganChartListAdapter != null){
                m_OrganChartListAdapter.notifyDataSetChanged();
                m_cbAllcheckOrgan.setChecked(false);
            }
        }
    };

    ChatroomOrganChartListItemlayout.OnCheckedChangedListener m_CheckedChangedOrganListner = new ChatroomOrganChartListItemlayout.OnCheckedChangedListener() {

        @Override
        public void onChecked(boolean a_isChecked, int a_nUserId) {
            // TODO Auto-generated method stub
            if (a_isChecked) {
                boolean isSame = false;
                if (App.m_arrSearchListCheckData != null) {
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {
                        for (SearchListCheckData data : App.m_arrSearchListCheckData) {

                            if (data.m_nUserNo == m_arrDepartmentUserListDatas.get(i).getUserNo()) {
                                isSame = true;
                                break;
                            } else if (App.m_arrRoomUserList!=null&&App.m_arrRoomUserList.contains(m_arrDepartmentUserListDatas.get(i).getUserNo())|| (App.m_MyUserInfo.m_nUserNo == data.m_nUserNo)) {
                                isSame = true;
                                break;
                            } else if (!m_arrDepartmentUserListDatas.get(i).getAvailable()){
                                isSame = true;
                                break;
                            }
                            else {
                                isSame = false;
                            }

                        }
                        if (!isSame) {
                            break;
                        }
                    }
                }
                if (isSame) {
                    m_cbAllcheckOrgan.setChecked(true);
                } else {
                    m_cbAllcheckOrgan.setChecked(false);
                }
            } else {
                m_cbAllcheckOrgan.setChecked(false);
            }
        }

        @Override
        public void onDataSetChagnged() {
            // TODO Auto-generated method stub
            // if (m_SearchFellowListAdapter != null)
            // m_SearchFellowListAdapter.notifyDataSetChanged();
            // if (m_FellowListAdapter != null)
            // m_FellowListAdapter.notifyDataSetChanged();
        }
    };

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        // TODO Auto-generated method stub
        if (buttonView.getId() == R.id.cb_chat_allmember) {
            if (m_isTouchCheckBox) {
                if (isChecked) {
                    int nCheckList = 0;
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {
                        if (App.m_arrRoomUserList!=null&&!App.m_arrRoomUserList.contains(m_arrDepartmentUserListDatas.get(i).getUserNo()) && !(App.m_MyUserInfo.m_nUserNo == m_arrDepartmentUserListDatas.get(i).getUserNo())) {
                            SearchListCheckData addData = new SearchListCheckData(m_arrDepartmentUserListDatas.get(i).getUserNo(),
                                    m_arrDepartmentUserListDatas.get(i).getName());
                            if(m_arrDepartmentUserListDatas.get(i).getAvailable()) {
                                ((ChatInviteTabAct) m_Activity).addSearchList(addData);
                                nCheckList++;
                            }
                        }
                    }
                    if(nCheckList == 0){
                        m_isTouchCheckBox = false;
                        m_cbAllcheckOrgan.setChecked(false);
                    }
                } else {
                    for (int i = 0; i < m_arrDepartmentUserListDatas.size(); i++) {

                        ((ChatInviteTabAct) m_Activity).removeListData(m_arrDepartmentUserListDatas.get(i).getUserNo());

                    }
                }
                m_isTouchCheckBox = false;
                if(m_OrganChartListAdapter != null){
                    m_OrganChartListAdapter.notifyDataSetChanged();
                }


            }
        }

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.cb_sns_allmember) {
            m_isTouchCheckBox = true;
        } else if (v.getId() == R.id.cb_chat_allmember) {
            m_isTouchCheckBox = true;
        }
        return false;
    }

  /*  private void requestAddedByName(String a_strKeyword) {
        showProgress(getString(R.string.progress_search));
        PostSearchUserReq req = new PostSearchUserReq(a_strKeyword, 1, PostSearchUserReq.TYPE_NAME); // 이름검색

        WebAPI webApi = new WebAPI(m_Activity);
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub
            }

            @Override
            public void onPostRequest(String strData) {
                // TODO Auto-generated method stub
                PostSearchUserRes res = new PostSearchUserRes(strData);
                res.parseData();

                m_arrUserSearchListDatas = null;
                if (res.getUserSearchListData() != null) {
                    m_arrUserSearchListDatas = res.getUserSearchListData();
                } else {
                    Toast.makeText(m_Activity, getString(R.string.layout_sectionstring_search_noresult), Toast.LENGTH_SHORT).show();
                }

                closeProgress();
                setUserSearchApdapter();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((ChatInviteTabAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
            }
        });

    }*/

   /* private void requestAddedByGroup(String a_strKeyword) {
        showProgress(getString(R.string.progress_search));
        PostSearchUserReq req = new PostSearchUserReq(a_strKeyword, 1, PostSearchUserReq.TYPE_GROUP); // 이름검색

        WebAPI webApi = new WebAPI(m_Activity);
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub
            }

            @Override
            public void onPostRequest(String strData) {
                // TODO Auto-generated method stub
                PostSearchUserRes res = new PostSearchUserRes(strData);
                res.parseData();

                m_arrUserSearchListDatas = null;
                if (res.getUserSearchListData() != null) {
                    m_arrUserSearchListDatas = res.getUserSearchListData();
                } else {
                    Toast.makeText(m_Activity, getString(R.string.layout_sectionstring_search_noresult), Toast.LENGTH_SHORT).show();
                }

                closeProgress();
                setUserSearchApdapter();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                ((ChatInviteTabAct) m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
//          if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//                   PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          } else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE || a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
//                   PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          } else {
//             m_Popup = new CommonPopup(m_Activity, SNSInviteSearchUserFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
//             m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
//             m_Popup.setCancelable(false);
//             isCheckShowPopup();
//          }
            }
        });

    }*/

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        //Spinner를 그리면서 자동으로 선택 됨
        if(m_isFirstView) {
            spn_search_type.setSelection(0);
            tv_spinner_text.setText(m_arrSKTTeamList.get(0));
            m_strCurrentSelTeamCode = m_arrSKTTeamCodeList.get(0);
            requestDepartment(App.m_EntryData.m_strCompanyCode, App.m_EntryData.m_strDepartmentCode);
        }
        else if(!m_isFirstView) {
            tv_spinner_text.setText(m_arrSKTTeamList.get(position));
            m_strCurrentSelTeamCode = m_arrSKTTeamCodeList.get(position);
            requestDepartment(m_strCurrentSelTeamCode, m_strCurrentSelTeamCode + ".ROOT");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // TODO Auto-generated method stub

    }

    public void showProgress() {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Activity);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void showProgress(String a_strMsg) {
        if (m_Progress == null)
            m_Progress = new ProgressDlg(m_Activity, a_strMsg);

        if (!m_Progress.isShowing()) {
            m_Progress.show();
        }
    }

    public void closeProgress() {
        if (m_Progress != null && m_Progress.isShowing())
            m_Progress.cancel();
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        if (v.getId() == R.id.ib_pop_ok_long) {
            CommonPopup popup_ok_long = (CommonPopup)v.getTag();
            if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
                popup_ok_long.cancel();
                App.expirePartnerLogin(m_Activity);
            } else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
                popup_ok_long.cancel();
                App.initPartnerLogin(m_Activity);
            } else {
                popup_ok_long.cancel();
            }
        } else if (v.getId() == R.id.layout_org_menu_01) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(0).getDepartMentCode());
            m_LayoutOrgMenu02.setVisibility(View.GONE);
            m_LayoutOrgMenu03.setVisibility(View.GONE);
            m_LayoutOrgMenu04.setVisibility(View.GONE);
            m_LayoutOrgMenu05.setVisibility(View.GONE);
            m_LayoutOrgMenu06.setVisibility(View.GONE);
            m_LayoutOrgMenu07.setVisibility(View.GONE);
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_02) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(1).getDepartMentCode());
            m_LayoutOrgMenu03.setVisibility(View.GONE);
            m_LayoutOrgMenu04.setVisibility(View.GONE);
            m_LayoutOrgMenu05.setVisibility(View.GONE);
            m_LayoutOrgMenu06.setVisibility(View.GONE);
            m_LayoutOrgMenu07.setVisibility(View.GONE);
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_03) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(2).getDepartMentCode());
            m_LayoutOrgMenu04.setVisibility(View.GONE);
            m_LayoutOrgMenu05.setVisibility(View.GONE);
            m_LayoutOrgMenu06.setVisibility(View.GONE);
            m_LayoutOrgMenu07.setVisibility(View.GONE);
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_04) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(3).getDepartMentCode());
            m_LayoutOrgMenu05.setVisibility(View.GONE);
            m_LayoutOrgMenu06.setVisibility(View.GONE);
            m_LayoutOrgMenu07.setVisibility(View.GONE);
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_05) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(4).getDepartMentCode());
            m_LayoutOrgMenu06.setVisibility(View.GONE);
            m_LayoutOrgMenu07.setVisibility(View.GONE);
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_06) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(5).getDepartMentCode());
            m_LayoutOrgMenu07.setVisibility(View.GONE);
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_07) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(6).getDepartMentCode());
            m_LayoutOrgMenu08.setVisibility(View.GONE);
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_08) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(7).getDepartMentCode());
            m_LayoutOrgMenu09.setVisibility(View.GONE);
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_09) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(8).getDepartMentCode());
            m_LayoutOrgMenu10.setVisibility(View.GONE);
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_10) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(10).getDepartMentCode());
            m_LayoutOrgMenu11.setVisibility(View.GONE);
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_11) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(11).getDepartMentCode());
            m_LayoutOrgMenu12.setVisibility(View.GONE);
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_12) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(12).getDepartMentCode());
            m_LayoutOrgMenu13.setVisibility(View.GONE);
        } else if (v.getId() == R.id.layout_org_menu_13) {
            requestDepartment(m_strCurrentSelTeamCode, m_arrNavigationInfoDatas.get(13).getDepartMentCode());
        }
    }

    private void isCheckShowPopup() {
        if (m_isRunning) {
            m_Popup.show();
        }
    }

    synchronized public void requestAddedByUserList(int[] nUserIDs){
        GetUserInfoReq req = new GetUserInfoReq(nUserIDs);
        WebAPI webApi = new WebAPI(getActivity());
        webApi.request(req, new WebListener() {

            @Override
            public void onPreRequest() {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPostRequest(String a_strData) {
                // TODO Auto-generated method stub
                GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

                for (int i = 0; i < res.getUserListData().size(); i++) {
                    UserListData getItem = res.getUserListData().get(i);
                    if (getItem != null) {
                        TTalkDBManager.ContactsDBManager.insertContacts(getActivity(), getItem);
                    }
                }
                closeProgress();
                initOrganChartUI();
            }

            @Override
            public void onNetworkError(int a_nErrorCode, String a_strMessage) {
                // TODO Auto-generated method stub
                closeProgress();
                if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
                    m_Popup = new CommonPopup(getActivity(), ChatRoomOrganFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
                            PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                } else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
                    m_Popup = new CommonPopup(getActivity(), ChatRoomOrganFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
                            PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                } else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
                    m_Popup = new CommonPopup(getActivity(), ChatRoomOrganFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
                            PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                } else if (a_nErrorCode == ApiResult.HTTP_ERR_DISCONNECTED) {
                    m_Popup = new CommonPopup(getActivity(), ChatRoomOrganFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.network_bad).toString());
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                } else {
                    m_Popup = new CommonPopup(getActivity(), ChatRoomOrganFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_ERROR_MESSAGE);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }
            }
        });
    }
}
