package com.gmp.rusk.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;

/**
 * Created by kang on 2017-09-11.
 */

public class BackupDlg extends Dialog {

    private RotateAnimation m_animProgress = null;
    private String m_strProgressMsg = "";

    public BackupDlg(Context context, int theme) {
        super(context, theme);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        init();
        // TODO Auto-generated constructor stub
    }

    protected BackupDlg(Context context, boolean cancelable,
                          OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        init();
        // TODO Auto-generated constructor stub
    }

    public BackupDlg(Context context) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        m_strProgressMsg = "";
        init();
        // TODO Auto-generated constructor stub
    }

    public BackupDlg(Context context, String a_strMessage) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        m_strProgressMsg = a_strMessage;
        init();
        // TODO Auto-generated constructor stub
    }

    public void init()
    {
        this.setContentView(R.layout.layout_backupprogressdlg);
        setCancelable(false);

        m_animProgress = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
        m_animProgress.setInterpolator(new LinearInterpolator());
        m_animProgress.setRepeatCount(Animation.INFINITE);
        m_animProgress.setDuration(1000);

        TextView tvMessage = (TextView)findViewById(R.id.tv_progressdlg_msg);
        if(m_strProgressMsg.equals("") || TextUtils.isEmpty(m_strProgressMsg))
        {
            tvMessage.setText("");
            tvMessage.setVisibility(View.GONE);
        }
        else
        {
            tvMessage.setText(m_strProgressMsg);
        }
    }

    public void setText(String a_strText)
    {
        TextView tvMessage = (TextView)findViewById(R.id.tv_progressdlg_msg);
        tvMessage.setVisibility(View.VISIBLE);
        tvMessage.setText(a_strText);
    }

    @Override
    public void onBackPressed() {
        // TODO Auto-generated method stub
        super.onBackPressed();
    }

    @Override
    public void show() {
        // TODO Auto-generated method stub
        if(getContext().isRestricted())
            return;

        try
        {
            if(!isShowing())
            {
                ImageView ivLoading = (ImageView)findViewById(R.id.iv_progressdlg_loading);
                ivLoading.startAnimation(m_animProgress);
                super.show();
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void cancel() {
        // TODO Auto-generated method stub
        ImageView ivLoading = (ImageView)findViewById(R.id.iv_progressdlg_loading);
        try {
            ivLoading.startAnimation(null);
        } catch (Exception e) {
            // TODO: handle exception
        }
        super.cancel();
    }
}
