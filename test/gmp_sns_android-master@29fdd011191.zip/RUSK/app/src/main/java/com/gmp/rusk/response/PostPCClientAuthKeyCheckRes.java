package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

public class PostPCClientAuthKeyCheckRes extends Res{
	
	private final String JSON_SYNCFILEID				= "syncFileId";
	
	public String m_strSyncFileId = "";
	
	public PostPCClientAuthKeyCheckRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			m_strSyncFileId = jsonRoot.optString(JSON_SYNCFILEID);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}
	
	public String getSyncFileId()
	{
		return m_strSyncFileId;
	}
}
