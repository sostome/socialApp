package com.gmp.rusk.act;

import java.util.ArrayList;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.FellowRedactionListData;
import com.gmp.rusk.layout.OrganChartRegularSearchListItemLayout;
import com.gmp.rusk.listview.SectionListAdapter;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * OrganChartMakeChatAct
 * 
 * @author subi78 조직도 채팅방 생성 Activity
 */
public class OrganChartMakeChatAct extends CustomActivity implements OnCheckedChangeListener {

	private ListView m_lvRegularSearchcList = null;
	HorizontalScrollView m_BadgeScroll;
	LinearLayout m_LayoutBadge;
	TextView m_tvTitle, m_tvUserCount;

	private RegularSearchListAdapter m_RegularSearchListAdapter = null;
	private SectionListAdapter m_SectionListAdapter = null;

	public ArrayList<Integer> m_nSelectId = new ArrayList<Integer>();
	public ArrayList<DepartmentUserListData> m_arrSelectedList = new ArrayList<>();
	ImageView m_ivTopBack;
	ImageView btn_complate;
	CheckBox m_cbAllSelect;
	private ArrayList<DepartmentUserListData> m_DepartmentUserListData = null;

	int m_nDeletedUserCount = 0;

	boolean m_isAllCheckTouch = false;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_makechat);
		initListViewUi();
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		if(m_RegularSearchListAdapter != null)
			m_RegularSearchListAdapter.notifyDataSetChanged();
		
		super.onResume();
	}

	private void initListViewUi() {
		m_DepartmentUserListData = new ArrayList<DepartmentUserListData>();
		for (DepartmentUserListData data : App.m_arrDepartmentUserListData) {
			m_DepartmentUserListData.add(data);
			if(!data.m_isAvailable){
				m_nDeletedUserCount++;
			}
		}
		m_ivTopBack = (ImageView) findViewById(R.id.iv_chat_back);
		m_ivTopBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		btn_complate = (ImageView) findViewById(R.id.btn_complate);
		btn_complate.setImageResource(R.drawable.btn_top_ok_disabled);
		btn_complate.setEnabled(false);
		btn_complate.setOnClickListener(this);
		m_BadgeScroll = (HorizontalScrollView)findViewById(R.id.sv_badge);
		m_LayoutBadge = (LinearLayout) findViewById(R.id.layout_badge);
		m_cbAllSelect = (CheckBox) findViewById(R.id.cb_makeroom_all);
		m_cbAllSelect.setOnCheckedChangeListener(this);
		m_lvRegularSearchcList = (ListView) findViewById(R.id.lv_organchart_list);
		m_tvTitle = (TextView) findViewById(R.id.tv_chat_title);
		m_tvUserCount = (TextView) findViewById(R.id.tv_allmember_count);
		m_tvUserCount.setText(getString(R.string.text_all) + " " + m_DepartmentUserListData.size());

		m_RegularSearchListAdapter = new RegularSearchListAdapter();
		m_lvRegularSearchcList.setAdapter(m_RegularSearchListAdapter);
		m_lvRegularSearchcList.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				if (m_SectionListAdapter != null)
					m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
			}
		});

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		if (v.getId() == R.id.btn_complate) {
			// requestFellowDelete();
			ArrayList<Integer> m_arrUserNo = new ArrayList<Integer>();
			for(DepartmentUserListData data : m_DepartmentUserListData){
				if(data.m_isChecked){
					if(data.m_nUserNo != App.m_EntryData.m_nUserNo)
						m_arrUserNo.add(data.m_nUserNo);
				}
			}
			if (!m_arrUserNo.isEmpty()) {
				if (m_arrUserNo.size() > 1) {
					Intent intent = new Intent(OrganChartMakeChatAct.this, ChatRoomGroupAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_ARR_USERNO, m_arrUserNo);
					startActivity(intent);
					finish();
				} else {
					Intent intent = new Intent(OrganChartMakeChatAct.this, ChatRoomAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_USERNO, m_arrUserNo.get(0));
					startActivity(intent);
					finish();
				}
			}
			
			finish();
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if (isChecked) {
			final ArrayList<DepartmentUserListData> tempData = new ArrayList<DepartmentUserListData>(m_DepartmentUserListData);
			for (final DepartmentUserListData data : tempData) {
				m_isAllCheckTouch = true;
				if(data.m_isAvailable && !m_arrSelectedList.contains(data) && data.m_nUserNo != App.m_MyUserInfo.m_nUserNo) {
					data.m_isChecked = true;
					final LinearLayout inviteScrollItem = (LinearLayout) getLayoutInflater().inflate(R.layout.layout_invite_scroll_item, null);
					final TextView tvInviteScrollItem = (TextView) inviteScrollItem.findViewById(R.id.tv_invite_scroll_item);
					tvInviteScrollItem.setText(data.m_strName);
					m_BadgeScroll.setVisibility(View.VISIBLE);
					m_LayoutBadge.setVisibility(View.VISIBLE);
					m_LayoutBadge.addView(inviteScrollItem, 0);
					m_arrSelectedList.add(data);
					inviteScrollItem.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {

							DepartmentUserListData deleteData = data;
							m_arrSelectedList.remove(deleteData);
							m_LayoutBadge.removeView(inviteScrollItem);
							m_isAllCheckTouch = false;
							m_cbAllSelect.setChecked(false);

							for (DepartmentUserListData data2 : m_DepartmentUserListData) {
								if (data2.m_nUserNo == data.m_nUserNo) {
									data2.m_isChecked = false;
								}
							}

							if (m_arrSelectedList.size() == 0) {
								btn_complate.setImageResource(R.drawable.btn_top_ok_disabled);
								btn_complate.setEnabled(false);
								m_LayoutBadge.setVisibility(View.GONE);
								m_BadgeScroll.setVisibility(View.GONE);
							}
							m_RegularSearchListAdapter.notifyDataSetChanged();
							m_lvRegularSearchcList.invalidate();
						}
					});
				}

				//initListViewUi();
			}
			m_RegularSearchListAdapter.notifyDataSetChanged();
			m_lvRegularSearchcList.invalidate();
			if(m_arrSelectedList.size() != 0) {
				m_tvTitle.setText(getString(R.string.make_chat) + " " + m_arrSelectedList.size());
				btn_complate.setImageResource(R.drawable.btn_btn_top_ok);
				btn_complate.setEnabled(true);
			} else {
				m_tvTitle.setText(getString(R.string.make_chat));
			}
		} else {
			if(m_isAllCheckTouch) {

				for (DepartmentUserListData data : m_DepartmentUserListData) {

					data.m_isChecked = false;
					m_RegularSearchListAdapter.notifyDataSetChanged();
					m_lvRegularSearchcList.invalidate();
					m_BadgeScroll.setVisibility(View.GONE);
					//initListViewUi();
				}
				m_arrSelectedList = new ArrayList<DepartmentUserListData>();
				m_LayoutBadge.removeAllViews();
				if(m_arrSelectedList.size() != 0) {
					m_tvTitle.setText(getString(R.string.make_chat) + " " + m_arrSelectedList.size());
				} else {
					m_tvTitle.setText(getString(R.string.make_chat));
				}
			}

		}
	}

	// FellowList Adapter
	private class RegularSearchListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_DepartmentUserListData != null)
				return m_DepartmentUserListData.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (m_DepartmentUserListData != null)
				return m_DepartmentUserListData.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			DepartmentUserListData data = (DepartmentUserListData) m_DepartmentUserListData.get(nPosition);

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new OrganChartRegularSearchListItemLayout(OrganChartMakeChatAct.this);

			((OrganChartRegularSearchListItemLayout) convertView).setFellowRedactionListData(data);

			((OrganChartRegularSearchListItemLayout) convertView).setCheckedChangedListener(m_CheckedChangedListner);

			CheckBox cb_redaction = (CheckBox) ((OrganChartRegularSearchListItemLayout) convertView).findViewById(R.id.cb_user);

			if (data.m_isChecked)
				cb_redaction.setChecked(true);
			else
				cb_redaction.setChecked(false);

			return convertView;
		}
	}

	OrganChartRegularSearchListItemLayout.OnCheckedChangedListener m_CheckedChangedListner = new OrganChartRegularSearchListItemLayout.OnCheckedChangedListener() {

		@Override
		public void onChecked(boolean a_isChecked, final DepartmentUserListData a_fellowRedactionListData) {
			// TODO Auto-generated method stub
			if (a_isChecked) {
				//m_isAllCheckTouch = true;
				btn_complate.setImageResource(R.drawable.btn_btn_top_ok);
				btn_complate.setEnabled(true);
				m_BadgeScroll.setVisibility(View.VISIBLE);
				m_LayoutBadge.setVisibility(View.VISIBLE);
				//m_nSelectId.add(a_nUserId);
				for (DepartmentUserListData data : m_DepartmentUserListData) {
					if (data.m_nUserNo == a_fellowRedactionListData.m_nUserNo) {
						data.m_isChecked = true;
					}
				}

				if(!m_arrSelectedList.contains(a_fellowRedactionListData)) {
					final LinearLayout inviteScrollItem = (LinearLayout) getLayoutInflater().inflate(R.layout.layout_invite_scroll_item, null);
					final TextView tvInviteScrollItem = (TextView) inviteScrollItem.findViewById(R.id.tv_invite_scroll_item);
					tvInviteScrollItem.setText(a_fellowRedactionListData.m_strName);
					m_LayoutBadge.addView(inviteScrollItem, 0);
					m_arrSelectedList.add(a_fellowRedactionListData);
					inviteScrollItem.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {

							DepartmentUserListData deleteData = a_fellowRedactionListData;
							m_arrSelectedList.remove(deleteData);
							m_LayoutBadge.removeView(inviteScrollItem);
							m_isAllCheckTouch = false;
							m_cbAllSelect.setChecked(false);

							for (DepartmentUserListData data : m_DepartmentUserListData) {
								if (data.m_nUserNo == a_fellowRedactionListData.m_nUserNo) {
									data.m_isChecked = false;
								}
							}

							if (m_arrSelectedList.size() == 0) {
								btn_complate.setImageResource(R.drawable.btn_top_ok_disabled);
								btn_complate.setEnabled(false);
								m_LayoutBadge.setVisibility(View.GONE);
								m_BadgeScroll.setVisibility(View.GONE);
							}
							m_RegularSearchListAdapter.notifyDataSetChanged();
							m_lvRegularSearchcList.invalidate();
						}
					});
				}

				//사용자 본인은 체크리스트에 들어가지 않지만, 총 인원수에 적용 되어야 함
				if(m_arrSelectedList.size() + m_nDeletedUserCount + 1 >= m_DepartmentUserListData.size()){
					m_cbAllSelect.setChecked(true);
				}

				m_tvTitle.setText(getString(R.string.make_chat) + " " + m_arrSelectedList.size());
			} else {
				for (DepartmentUserListData data : m_DepartmentUserListData) {
					if (data.m_nUserNo == a_fellowRedactionListData.m_nUserNo) {
						data.m_isChecked = false;
					}
				}
				for (int i = 0; i < m_arrSelectedList.size(); i++) {
					if (m_arrSelectedList.get(i).m_nUserNo == a_fellowRedactionListData.m_nUserNo) {
						if(m_LayoutBadge.getChildCount() == m_arrSelectedList.size())
							m_LayoutBadge.removeViewAt(m_arrSelectedList.size() - i - 1);
						m_arrSelectedList.remove(i);
						break;
					}
				}
				if (m_arrSelectedList.size() == 0) {
					btn_complate.setImageResource(R.drawable.btn_top_ok_disabled);
					btn_complate.setEnabled(false);
					m_LayoutBadge.setVisibility(View.GONE);
					m_BadgeScroll.setVisibility(View.GONE);
				}
				//사용자 본인은 체크리스트에 들어가지 않지만, 총 인원수에 적용 되어야 함
				if(m_arrSelectedList.size() + m_nDeletedUserCount + 1 < m_DepartmentUserListData.size()){
					m_isAllCheckTouch = false;
					m_cbAllSelect.setChecked(false);
				}
				if(m_arrSelectedList.size() != 0) {
					m_tvTitle.setText(getString(R.string.make_chat) + " " + m_arrSelectedList.size());
				} else {
					m_tvTitle.setText(getString(R.string.make_chat));
				}
			}
		}
	};

}
