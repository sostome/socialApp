package com.gmp.rusk.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.gmp.rusk.datamodel.ChattingMessageData;

import android.content.Context;

public class ChattingDBManagerForDelayMessage {
	
	private Context m_Context = null;
	
	// Key : RoomId, Value : ChattingDBManager
	private HashMap<String, ChattingDBManager> m_mapChattingDBManager = new HashMap<String, ChattingDBManager>();
	
	public ChattingDBManagerForDelayMessage(Context a_Context)
	{
		m_Context = a_Context;
	}
	
	public int insertChattingMessage(String a_strRoomId, ChattingMessageData a_data)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		return dbManager.realInsertChattingMessage(a_data);
	}
	
	public void insertChattingUser(String a_strRoomId, int a_nUserNo)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.realInsertChattingUser(a_nUserNo);
	}
	
	public int insertChattingUser(String a_strRoomId, ArrayList<Integer> a_arrUserNo)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		return dbManager.realInsertChattingUser(a_arrUserNo);
	}
	
	public int updateChattingMessage(String a_strRoomId, ChattingMessageData a_data)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		return dbManager.realUpdateChattingMessage(a_data);
	}
	
	public void updateReadMessage(String a_strRoomId, HashMap<String, Boolean> a_mapReadMessage)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.realUpdateReadMessage(a_mapReadMessage);
	}
	
	public void updateReadMessage(String a_strRoomId, String a_strMsgId, boolean a_isRead)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.realUpdateReadMessage(a_strMsgId, a_isRead);
	}
	
	public void updateUpdateSendStatus(String a_strRoomId, String a_strMsgId, int a_nSendStatus)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.realUpdateSendStatus(a_strMsgId, a_nSendStatus);
	}
	
	public void deleteChattingMessage(String a_strRoomId)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.deleteChattingMessage();
	}
	
	public void deleteChattingMessage(String a_strRoomId, String a_strMsgId)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.deleteChattingMessage(a_strMsgId);
	}
	
	public void deleteChattingUser(String a_strRoomId)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.deleteChattingUser();
	}
	
	public void deleteChattingUser(String a_strRoomId, int a_nUserNo)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		dbManager.deleteChattingUser(a_nUserNo);
	}
	
	public ArrayList<ChattingMessageData> getChattingMessage(String a_strRoomId)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		return dbManager.getChattingMessage();
	}
	
	public ArrayList<Integer> getChattingUser(String a_strRoomId)
	{
		ChattingDBManager dbManager = getChattingDBManager(a_strRoomId);
		return dbManager.getChattingUser();
	}
	public void end()
	{
		Iterator<String> keys = m_mapChattingDBManager.keySet().iterator();
        while( keys.hasNext() ){
            String key = keys.next();
            ChattingDBManager dbManager = m_mapChattingDBManager.get(key);
            dbManager.setTransactionSuccessfulAtChattingDB();
            dbManager.endTransactionAtChattingDB();
            dbManager.close();
        }
	}
	
	private ChattingDBManager getChattingDBManager(String a_strRoomId)
	{
		ChattingDBManager dbManager = m_mapChattingDBManager.get(a_strRoomId);
		if(dbManager == null)
		{
			dbManager = new ChattingDBManager(m_Context);
			m_mapChattingDBManager.put(a_strRoomId, dbManager);
			
			dbManager.openWritable(a_strRoomId);
			dbManager.beginTransactionAtChattingDB();
		}
		
		return dbManager;
	}
}
