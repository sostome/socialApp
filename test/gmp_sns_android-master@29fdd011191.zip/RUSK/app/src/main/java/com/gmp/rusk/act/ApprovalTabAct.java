package com.gmp.rusk.act;

import java.util.HashMap;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.fragment.ApprovalAcceptListFlag;
import com.gmp.rusk.fragment.ApprovalPendingListFlag;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

/**
 * MainTabAct
 * @author subi78
 * MainTab Menu Activity
 */
public class ApprovalTabAct extends FragmentActivity {
	// Tab Tag
	private final String TAB_PENDING 		= "pending";			// 승인대기
	private final String TAB_ACCEPTED		= "accepted";			// 승인완료
	
	private final int TAB_INDEX_PENDING		= 0;
	private final int TAB_INDEX_ACCEPTED 	= 1;
	private final int TAB_INDEX_MAX 		= 2;
	
	TabHost mTabHost;
    TabManager mTabManager;
    
    OnNotifyListener m_NotifyListener;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_approvaltab);

        ImageView ivTopBack = (ImageView) findViewById(R.id.iv_top_back);
        ivTopBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    	mTabHost = (TabHost)findViewById(android.R.id.tabhost);
        mTabHost.setup();
        
        View[] viewTabs = new View[TAB_INDEX_MAX];
		for (int i = 0; i < TAB_INDEX_MAX; i++) {
			LayoutInflater inflater = getLayoutInflater();
			viewTabs[i] = inflater.inflate(R.layout.layout_tabitem, null);
		}
		
		//View ivPendingTab = (View) viewTabs[TAB_INDEX_PENDING].findViewById(R.id.iv_tabitem_mainitem);					// 승인 대기 Tab
		//View ivAcceptedTab = (View) viewTabs[TAB_INDEX_ACCEPTED].findViewById(R.id.iv_tabitem_mainitem);					// 승인 완료 Tab
		
		// Tab Image 설정
		//ivPendingTab.setImageResource(R.drawable.tabitem_approval_pending);
		//ivAcceptedTab.setImageResource(R.drawable.tabitem_approval_accepted);

        //View tabIndicator1 = inflater.inflate(R.layout.layout_tabitem,null);
        TextView textView1 = (TextView) viewTabs[TAB_INDEX_PENDING].findViewById(R.id.tv_tab_title);
        textView1.setText(R.string.approvaltab_pending);
        textView1.setBackgroundResource(R.drawable.tabitem_background);

        TextView textView2 = (TextView) viewTabs[TAB_INDEX_ACCEPTED].findViewById(R.id.tv_tab_title);
        textView2.setText(R.string.approvaltab_accept);
        textView2.setBackgroundResource(R.drawable.tabitem_background);
		
        mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

        mTabManager.addTab(mTabHost.newTabSpec(TAB_PENDING)
        		.setIndicator(viewTabs[TAB_INDEX_PENDING]),
        		ApprovalPendingListFlag.class,
                null);
        mTabManager.addTab(mTabHost.newTabSpec(TAB_ACCEPTED)
        		.setIndicator(viewTabs[TAB_INDEX_ACCEPTED]),
        		ApprovalAcceptListFlag.class, 
                null);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            boolean isReapproval = bundle.getBoolean(IntentKeyString.INTENT_KEY_REAPPROVAL);
            if(isReapproval){
                mTabHost.setCurrentTab(1);
            }

        }
	}
	
	@Override
    public void onResume() {
    	// TODO Auto-generated method stub
    	super.onResume();
    	
    }
	
	public void setNotify(){
		m_NotifyListener.onNotify();
	}
	public void setNotifyListener(OnNotifyListener a_Listener) {
		m_NotifyListener = a_Listener;
	}
	public interface OnNotifyListener {
		public void onNotify();
	}
	
    public void setTitle(String a_strTitle)
	{
		TextView tvTitle = (TextView)findViewById(R.id.tv_tabact_main_title);
		tvTitle.setText(a_strTitle);
	}
    
/*    public void setRightTopButton(boolean a_isVisible, final int a_nTabType)
    {
    	ImageView iv_tab_right_bg = (ImageView)findViewById(R.id.iv_tab_right_bg);
    	ImageButton ib_tab_right = (ImageButton)findViewById(R.id.ib_tab_right);
   		iv_tab_right_bg.setVisibility(View.INVISIBLE);
   		ib_tab_right.setVisibility(View.INVISIBLE);
    }
    
    public void setLeftTopButton(boolean a_isVisible, final int a_nTabType)
    {
    	Button btn_redaction = (Button)findViewById(R.id.btn_redaction);
   		btn_redaction.setVisibility(View.INVISIBLE);
    }*/
    
    public static class TabManager implements TabHost.OnTabChangeListener {
        private final FragmentActivity mActivity;
        private final TabHost mTabHost;
        private final int mContainerId;
        private final HashMap<String, TabInfo> mTabs = new HashMap<String, TabInfo>();
        TabInfo mLastTab;

        static final class TabInfo {
            private final String tag;
            private final Class<?> clss;
            private final Bundle args;
            private Fragment fragment;

            TabInfo(String _tag, Class<?> _class, Bundle _args) {
                tag = _tag;
                clss = _class;
                args = _args;
            }
        }

        static class DummyTabFactory implements TabHost.TabContentFactory {
            private final Context mContext;

            public DummyTabFactory(Context context) {
                mContext = context;
            }

            @Override
            public View createTabContent(String tag) {
                View v = new View(mContext);
                v.setMinimumWidth(0);
                v.setMinimumHeight(0);
                return v;
            }
        }

        public TabManager(FragmentActivity activity, TabHost tabHost, int containerId) {
            mActivity = activity;
            mTabHost = tabHost;
            mContainerId = containerId;
            mTabHost.setOnTabChangedListener(this);
        }

        public void addTab(TabHost.TabSpec tabSpec, Class<?> clss, Bundle args) {
            tabSpec.setContent(new DummyTabFactory(mActivity));
            String tag = tabSpec.getTag();

            TabInfo info = new TabInfo(tag, clss, args);

            // Check to see if we already have a fragment for this tab, probably
            // from a previously saved state.  If so, deactivate it, because our
            // initial state is that a tab isn't shown.
            info.fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
            if (info.fragment != null && !info.fragment.isDetached()) {
                FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
                ft.detach(info.fragment);
                ft.commit();
            }

            mTabs.put(tag, info);
            mTabHost.addTab(tabSpec);
        }

        @Override
        public void onTabChanged(String tabId) {
            TabInfo newTab = mTabs.get(tabId);
            if (mLastTab != newTab) {
                FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
                if (mLastTab != null) {
                    if (mLastTab.fragment != null) {
                        ft.detach(mLastTab.fragment);
                    }
                }
                if (newTab != null) {
                    if (newTab.fragment == null) {
                        newTab.fragment = Fragment.instantiate(mActivity,
                                newTab.clss.getName(), newTab.args);
                        ft.add(mContainerId, newTab.fragment, newTab.tag);
                    } else {
                        ft.attach(newTab.fragment);
                    }
                }

                mLastTab = newTab;
                ft.commit();
                mActivity.getSupportFragmentManager().executePendingTransactions();
            }
        }
    }
}
