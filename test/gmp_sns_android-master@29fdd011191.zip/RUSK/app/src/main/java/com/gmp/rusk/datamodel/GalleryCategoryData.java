package com.gmp.rusk.datamodel;

public class GalleryCategoryData {
	public String m_strPath = "";
	public String m_strFolderName = "";
	public int m_nMediaCount = 0;
	public GalleryListData m_currentGalleryListData = null;
}
