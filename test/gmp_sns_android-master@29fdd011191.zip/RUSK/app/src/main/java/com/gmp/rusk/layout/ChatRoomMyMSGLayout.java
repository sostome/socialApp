package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.act.ChatRoomAllViewAct;
import com.gmp.rusk.act.ChatRoomGroupAct;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.emoticon.EmoticonUtils;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.CustomLinkify;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * ChatRoomMyMSGLayout 채팅방 내 메세지 List Item Layout
 */
public class ChatRoomMyMSGLayout extends CustomLinearLayout implements OnLongClickListener, OnClickListener, OnTouchListener {
	// private final int REQUEST_CODE_INVITE = 2;
	// Context m_Context;
	// int m_nNumber;
	// String m_strMyMSG;
	TextView m_tvMyMesage, m_tvMyMessageNoSee, m_tvMyMessageTime;
	View m_vLineMessageAll;
	LinearLayout m_ibAllView;
	// boolean m_isAllView;
	// ArrayList<Integer> m_arrRead;
	// ArrayList<Integer> m_arrTotalUser;
	RelativeLayout m_MyMessage;
	// long m_lSendTime;
	// String m_strMessageID;
	ImageView m_ivIcon;
	ImageView m_ivIconRefresh;
	// int m_nSendStatus;
	// String m_strRoomID;
	private RotateAnimation m_animProgress = null;
	CommonPopup m_Popup;

	private ChatRoomData m_ChatRoomData = null;
	private CommonListPopup m_ListPopup = null;
	private int nListPopupCase;
	private final int LONG_CLICK = 1;
	private final int SELECT_ICON = 2;
	private boolean isAbleClick = true;

	//대화 검색시 레이아웃이 흔들리게 하기 위해 필요
	private String m_strBounceID = "";
	private boolean m_isBounce = false;

	ImageView m_ivEmoticonChat;
	public ChatRoomMyMSGLayout(Context context) {
		super(context);
		// m_strMyMSG = a_strMyMSG;
		// m_nNumber = a_nNumber;
		// m_arrRead = a_arrRead;
		// m_arrTotalUser = a_arrTotalRead;
		// m_lSendTime = a_lSendTime;
		// m_strMessageID = a_strMessageID;
		// m_nSendStatus = a_nSendStatus;
		// m_strRoomID = a_strRoomID;

		init();

	}

	private void init() {
		String m_strInfService = Context.LAYOUT_INFLATER_SERVICE;
		LayoutInflater li = (LayoutInflater) getContext().getSystemService(m_strInfService);
		li.inflate(R.layout.layout_chat_room_mymsg, this, true);
		m_tvMyMesage = (TextView) findViewById(R.id.tv_chat_mymsg);
		SharedPref pref = SharedPref.getInstance(getContext());
		int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
		if (nSaveTextSize == StaticString.SETTEXTSIZE_SMALL){
			m_tvMyMesage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15.33f);
		} else if (nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL){
			m_tvMyMesage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 19.92f);
		} else if(nSaveTextSize == StaticString.SETTEXTSIZE_BIG){
			m_tvMyMesage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 24.53f);
		}
		/*m_ivEmoticonChat = (ImageView) findViewById(R.id.iv_emoticon_chat);*/
		m_tvMyMesage.setOnLongClickListener(this);
		m_tvMyMesage.setLinkTextColor(Color.WHITE);
		m_tvMyMessageNoSee = (TextView) findViewById(R.id.tv_chat_mymsg_nosee);
		m_tvMyMessageTime = (TextView) findViewById(R.id.tv_chat_mymsg_time);
		m_vLineMessageAll = findViewById(R.id.line_msgall);
		m_ibAllView = (LinearLayout) findViewById(R.id.ib_chat_mymsg_all);
		m_MyMessage = (RelativeLayout) findViewById(R.id.layout_chat_mymsg);
		m_ivIcon = (ImageView) findViewById(R.id.iv_chat_mymsg_icon);
		m_ivIconRefresh = (ImageView) findViewById(R.id.iv_chat_mymsg_icon_refresh);
		m_animProgress = new RotateAnimation(0, 360, RotateAnimation.RELATIVE_TO_SELF, 0.5f, RotateAnimation.RELATIVE_TO_SELF, 0.5f);
		m_animProgress.setInterpolator(new LinearInterpolator());
		m_animProgress.setRepeatCount(Animation.INFINITE);
		m_animProgress.setDuration(1000);

		// m_MyMessage.setOnLongClickListener(this);

		m_tvMyMessageTime.setOnClickListener(this);

		m_tvMyMesage.setOnLongClickListener(this);
		m_tvMyMesage.setOnTouchListener(this);
		m_MyMessage.setOnLongClickListener(this);
		m_tvMyMessageNoSee.setOnClickListener(this);

	}
	/*public void setPosition(int nPosition){
		m_nPosition = nPosition;
	}*/

	public void setChatRoomData(ChatRoomData a_Data) {
		m_ChatRoomData = a_Data;

		if(a_Data.m_strRoomID.split("_").length == 3) {
			m_MyMessage.setBackgroundResource(R.drawable.img_balloon_me);
			m_tvMyMessageNoSee.setTextColor(Color.parseColor("#e04f07"));
		} else {
			m_MyMessage.setBackgroundResource(R.drawable.img_balloon_me);
			m_tvMyMessageNoSee.setTextColor(Color.parseColor("#e04f07"));
		}

		EmoticonUtils utils = new EmoticonUtils();
		String strText = m_ChatRoomData.m_strMyMSG;
		String strLastChar = " ";
		String strFirstChar = " ";

		if (m_ChatRoomData.m_strRoomID.length() < 8) {
			m_strBounceID = ((ChatRoomAct) getContext()).getBounceID();
		} else {
			m_strBounceID = ((ChatRoomGroupAct) getContext()).getBounceID();
		}
		if (strText != null && strText.length() != 0) {
			while (strLastChar.equals(" ") || strLastChar.equals("\n")) {
				strLastChar = (String) strText.subSequence(strText.length() - 1, strText.length());
				if (strLastChar.equals(" ") || strLastChar.equals("\n")) {
					strText = (String) strText.subSequence(0, strText.length() - 1);
				}
			}
			while (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
				strFirstChar = (String) strText.subSequence(0, 1);
				if (strFirstChar.equals(" ") || strFirstChar.equals("\n")) {
					strText = (String) strText.subSequence(1, strText.length());
				}
			}
		}

		String strViewText = "";
		if(strText.length() > 1000){
			strViewText = strText.substring(0, 997);
			char[] cText = strViewText.toCharArray();
			for(int i = 994; i < 997; i++){
				if(cText[i] == '('){
					strViewText = strText.substring(0, i);
					break;
				}
			}
			strViewText = strViewText + "...";
		} else {
			strViewText = strText;
		}

		ArrayList<Integer> index = new ArrayList<>();

		String strSearchText = m_ChatRoomData.m_strSearchText;
		SpannableString ssViewText = new SpannableString(strViewText);
		if (strViewText.contains(strSearchText) && !strSearchText.equals("")) {
			for(int i = strViewText.indexOf(strSearchText); i >= 0; i = strViewText.indexOf(strSearchText, i + 1)){
				index.add(i);
			}
			//index = strViewText.indexOf(strSearchText);
			for(int j = 0; j < index.size(); j++) {
				ssViewText.setSpan(new BackgroundColorSpan(Color.parseColor("#6d55d9")), index.get(j), index.get(j) + strSearchText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
				ssViewText.setSpan(new ForegroundColorSpan(Color.parseColor("#ffffff")), index.get(j), index.get(j) + strSearchText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
			}
		}
		m_tvMyMesage.setText(utils.parsingEmoticonText(getContext(), ssViewText, strViewText, (int) m_tvMyMesage.getTextSize()));
		CustomLinkify.addLinks(m_tvMyMesage, CustomLinkify.ALL);

		if(m_strBounceID.equals(m_ChatRoomData.m_strMessageID) && !m_isBounce){
			LinearLayout layout = (LinearLayout)findViewById(R.id.layout_chat_room_mymsg);
			YoYo.with(Techniques.Bounce.Bounce).duration(500).repeat(1).playOn(layout);
			if (m_ChatRoomData.m_strRoomID.length() < 8) {
				((ChatRoomAct) getContext()).setBounceIDEmpty();
			} else {
				((ChatRoomGroupAct) getContext()).setBounceIDEmpty();
			}
		}

		// 날짜
		String pattern = "a h:mm";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		String date = (String) format.format(new Timestamp(m_ChatRoomData.m_lDate));

		m_tvMyMessageTime.setText(date);

		int nNoReadCount = 0;

		//nNoReadCount = m_ChatRoomData.m_arrTotalRead.size() - m_ChatRoomData.m_arrRead.size();
		nNoReadCount = m_ChatRoomData.m_nNoReadCount;
		if (nNoReadCount == 0) {
			m_tvMyMessageNoSee.setText("");
			m_tvMyMessageNoSee.setVisibility(View.GONE);
		} else if (nNoReadCount < 0) {
			m_tvMyMessageNoSee.setText("");
			m_tvMyMessageNoSee.setVisibility(View.GONE);
		} else if (m_ChatRoomData.m_strRoomID.equals("99")||m_ChatRoomData.m_strRoomID.equals("100")) {
			m_tvMyMessageNoSee.setText("");
			m_tvMyMessageNoSee.setVisibility(View.GONE);
		} else {
			m_tvMyMessageNoSee.setText("" + nNoReadCount);
			m_tvMyMessageNoSee.setVisibility(View.VISIBLE);
		}

		if (m_ChatRoomData.m_strMyMSG.length() > 1000) {
			m_vLineMessageAll.setVisibility(VISIBLE);
			m_ibAllView.setVisibility(View.VISIBLE);
			m_ibAllView.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(getContext(), ChatRoomAllViewAct.class);
					intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_ChatRoomData.m_strRoomID);
					intent.putExtra(IntentKeyString.INTENT_KEY_TEXT, m_ChatRoomData.m_strMyMSG);
					getContext().startActivity(intent);

				}
			});
		} else {
			m_vLineMessageAll.setVisibility(GONE);
			m_ibAllView.setVisibility(View.GONE);
		}

		if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_LOADING) {
			m_ivIcon.setVisibility(View.VISIBLE);
			m_tvMyMessageTime.setVisibility(VISIBLE);
			m_ivIconRefresh.setVisibility(GONE);
			m_ivIcon.setBackgroundResource(R.drawable.img_loading);
			m_ivIcon.startAnimation(m_animProgress);
			m_tvMyMessageNoSee.setVisibility(View.GONE);
			m_tvMyMessageTime.setOnClickListener(null);

		} else if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_FAIL) {
			m_tvMyMessageNoSee.setVisibility(View.GONE);
			m_ivIcon.setVisibility(View.GONE);
			m_tvMyMessageTime.setVisibility(GONE);
			m_ivIconRefresh.setVisibility(VISIBLE);
			m_ivIconRefresh.setBackgroundResource(R.drawable.btn_refresh);
			m_ivIconRefresh.setOnClickListener(this);
			m_tvMyMessageTime.setOnClickListener(null);
		} else if (m_ChatRoomData.m_nSendStatus == StaticString.CHAT_SEND_STATUS_SUCCESS) {
			m_tvMyMessageNoSee.setVisibility(View.VISIBLE);
			m_tvMyMessageTime.setVisibility(VISIBLE);
			m_ivIcon.setVisibility(View.GONE);
			m_ivIconRefresh.setVisibility(GONE);
			m_tvMyMessageTime.setOnClickListener(this);
		}
	}

	@Override
	public boolean onLongClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.layout_chat_mymsg:
		case R.id.tv_chat_mymsg:
			nListPopupCase = LONG_CLICK;
			m_ListPopup = new CommonListPopup(getContext(), ChatRoomMyMSGLayout.this);
			m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_longclick_type));
			m_ListPopup.setCancelable(true);
			m_ListPopup.show();

			break;

		default:
			break;
		}
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				isAbleClick = true;
			}

		};


		if (isAbleClick) {
			Timer mTimer = new Timer();
			mTimer.schedule(task, 500);
			isAbleClick = false;
			switch (v.getId()) {
			case R.id.tv_chat_mymsg_nosee:
			case R.id.tv_chat_mymsg_time:

				break;
			case R.id.iv_chat_mymsg_icon_refresh:

				nListPopupCase = SELECT_ICON;
				m_ListPopup = new CommonListPopup(getContext(), ChatRoomMyMSGLayout.this);
				m_ListPopup.setBodyAndTitleText(getContext().getString(R.string.chat_popup_title).toString(), getResources().getStringArray(R.array.arr_chat_file_resend_type));
				m_ListPopup.setCancelable(true);
				m_ListPopup.show();

				break;
			case R.id.ib_pop_ok:
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				if (popup_ok.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SEND_NOTICE) {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).sendMessage(m_ChatRoomData.m_strMyMSG, true);
					} else {
						((ChatRoomGroupAct) getContext()).sendMessage(m_ChatRoomData.m_strMyMSG, true);
					}
				} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					} else {
						((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					}
				}
				popup_ok.cancel();
				break;
			case R.id.ib_pop_cancel:
				CommonPopup popup_cancel = (CommonPopup)v.getTag();
				popup_cancel.cancel();
				break;
			case R.id.ib_pop_cancel_long:
				m_ListPopup.cancel();
				break;
			case R.id.tv_pop_first_row:
				m_ListPopup.cancel();
				if (nListPopupCase == LONG_CLICK) {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).sendMessageOther(m_ChatRoomData.m_strMyMSG);
					} else {
						((ChatRoomGroupAct) getContext()).sendMessageOther(m_ChatRoomData.m_strMyMSG);
					}
				} else {
					 ChattingDBManager chattingDBMngd = new ChattingDBManager(getContext());
					 chattingDBMngd.openWritable(m_ChatRoomData.m_strRoomID);
					 chattingDBMngd.deleteChattingMessage(m_ChatRoomData.m_strMessageID);
					 chattingDBMngd.close();

					if (m_ChatRoomData.m_strRoomID.length() > 8) {
						((ChatRoomGroupAct) getContext()).reSendDelete(m_ChatRoomData);
						((ChatRoomGroupAct) getContext()).reSendMessage(m_ChatRoomData.m_strMyMSG, m_ChatRoomData.m_strMessageID);
					} else {
						((ChatRoomAct) getContext()).reSendDelete(m_ChatRoomData);
						((ChatRoomAct) getContext()).reSendMessage(m_ChatRoomData.m_strMyMSG, m_ChatRoomData.m_strMessageID);
						// ((ChatRoomAct) getContext()).sendFile(m_strMyFileName, m_strMyFilePath);
					}
				}
				break;
			case R.id.tv_pop_second_row:
				m_ListPopup.cancel();
				if (nListPopupCase == LONG_CLICK) {
					m_Popup = new CommonPopup(getContext(), ChatRoomMyMSGLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_delete_text_title), getContext().getString(R.string.popup_delete_text_text));
					m_Popup.setCancelable(false);
					m_Popup.show();
				} else {
					if (m_ChatRoomData.m_strRoomID.length() < 8) {
						((ChatRoomAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					} else {
						((ChatRoomGroupAct) getContext()).deleteMessage(m_ChatRoomData.m_strMessageID);
					}
				}
				break;
			case R.id.tv_pop_third_row:
				m_ListPopup.cancel();
				m_Popup = new CommonPopup(getContext(), ChatRoomMyMSGLayout.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, PopupIndex.INDEX_PREVPOP_SEND_NOTICE);
				m_Popup.setBodyAndTitleText(getContext().getString(R.string.popup_urgent_title), getContext().getString(R.string.popup_urgent_text));
				m_Popup.setCancelable(false);
				m_Popup.show();
				break;
			default:
				break;
			}
		}

	}

	// TextView의 autolink 가 onLongClick의 return을 true로 하는 것만으로는 제어가 되지 않아 따로 처리
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		// TODO Auto-generated method stub
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			if (nListPopupCase == LONG_CLICK) {
				nListPopupCase = 0;
			}
		}
		if (event.getAction() == MotionEvent.ACTION_UP) {
			if (nListPopupCase == LONG_CLICK) {
				return true;
			}
		}
		return false;
	}

}
