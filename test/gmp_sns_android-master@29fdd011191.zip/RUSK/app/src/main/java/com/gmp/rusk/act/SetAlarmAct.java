package com.gmp.rusk.act;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.gmp.rusk.R;
import com.gmp.rusk.aom.QuickstartPreferences;
import com.gmp.rusk.aom.RegistrationIntentService;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PutChangePushTokenReq;
import com.gmp.rusk.request.PutGroupSettingReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.SharedPref;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GooglePlayServicesUtil;


/**
 * SetAlramAct
 * @author kch
 * 알림 설정 Activity
 */
public class SetAlarmAct extends CustomActivity implements OnCheckedChangeListener, View.OnClickListener{

	SharedPref pref;
	CheckBox cb_push_receive_alram;
	CheckBox cb_push_receive_alram_popup;
	CheckBox cb_push_preview;
	CheckBox cb_sound;
	CheckBox cb_vibrate;
	CheckBox cb_alarm_snsgroupboard;
	CheckBox cb_alarm_snsgroupreply;

	boolean m_isOnlyUIChange = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_set_alarm);
		pref = SharedPref.getInstance(SetAlarmAct.this);
		ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
		ivCancel.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		setAlramUI();
		setPushUI();
		setVisibleUI();
	}

	@Override
	protected void onDestroy() {

		super.onDestroy();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();

	}

	private void setPushUI()
	{
		cb_push_receive_alram = (CheckBox)findViewById(R.id.cb_push_receive_alram);
		cb_push_receive_alram.setOnCheckedChangeListener(this);
		
		cb_push_receive_alram_popup = (CheckBox)findViewById(R.id.cb_push_receive_alram_popup);
		cb_push_receive_alram_popup.setOnCheckedChangeListener(this);
		
		cb_push_preview = (CheckBox)findViewById(R.id.cb_push_preview);
		cb_push_preview.setOnCheckedChangeListener(this);
		
		cb_alarm_snsgroupboard = (CheckBox)findViewById(R.id.cb_alarm_snsgroupboard);
		cb_alarm_snsgroupboard.setOnCheckedChangeListener(this);
		
		cb_alarm_snsgroupreply = (CheckBox)findViewById(R.id.cb_alarm_snsgroupreply);
		cb_alarm_snsgroupreply.setOnCheckedChangeListener(this);
		
		cb_push_receive_alram.setChecked(pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true));
		cb_push_receive_alram_popup.setChecked(pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true));
		cb_push_preview.setChecked(pref.getBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true));
		cb_alarm_snsgroupboard.setChecked(pref.getBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true));
		cb_alarm_snsgroupreply.setChecked(pref.getBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true));
	}
	
	private void setAlramUI()
	{
		cb_sound = (CheckBox)findViewById(R.id.cb_sound);
		cb_sound.setOnCheckedChangeListener(this);
		cb_vibrate = (CheckBox)findViewById(R.id.cb_vibrate);
		cb_vibrate.setOnCheckedChangeListener(this);
		
		cb_sound.setChecked(pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND, true));
		cb_vibrate.setChecked(pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true));
	}
	
	private void setVisibleUI()
	{
		LinearLayout layoutReceivePopup = (LinearLayout)findViewById(R.id.layout_set_alarm_push_receive_alram);
		LinearLayout layoutReceiveAlarmPopup = (LinearLayout)findViewById(R.id.layout_set_alarm_receive_alarm_popup);
		LinearLayout layoutPreview = (LinearLayout)findViewById(R.id.layout_set_alarm_preview);
		LinearLayout layoutSound = (LinearLayout)findViewById(R.id.layout_set_alram_sound);
		LinearLayout layoutVibrate = (LinearLayout)findViewById(R.id.layout_set_alram_vibrate);
		LinearLayout layoutGroupboard = (LinearLayout)findViewById(R.id.layout_set_alarm_snsgroupboard);
		LinearLayout layoutGroupreply = (LinearLayout)findViewById(R.id.layout_set_alarm_snsgroupreply);


		boolean isReceiveAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(isReceiveAlarm)
		{
			layoutReceiveAlarmPopup.setVisibility(View.VISIBLE);
			layoutPreview.setVisibility(View.VISIBLE);
			layoutSound.setVisibility(View.VISIBLE);
			layoutVibrate.setVisibility(View.VISIBLE);
			layoutGroupboard.setVisibility(View.VISIBLE);
			layoutGroupreply.setVisibility(View.VISIBLE);
		}
		else
		{
			layoutReceiveAlarmPopup.setVisibility(View.GONE);
			layoutPreview.setVisibility(View.GONE);
			layoutSound.setVisibility(View.GONE);
			layoutVibrate.setVisibility(View.GONE);
			layoutGroupboard.setVisibility(View.GONE);
			layoutGroupreply.setVisibility(View.GONE);
		}

		layoutReceivePopup.setOnClickListener(this);
		layoutReceiveAlarmPopup.setOnClickListener(this);
		layoutPreview.setOnClickListener(this);
		layoutSound.setOnClickListener(this);
		layoutVibrate.setOnClickListener(this);
		layoutGroupboard.setOnClickListener(this);
		layoutGroupreply.setOnClickListener(this);
	}

	public void getInstanceIdToken() {
		if (checkPlayServices()) {
			// Start IntentService to register this application with GCM.
			Intent intent = new Intent(this, RegistrationIntentService.class);
			startService(intent);
		} else {
			//startCheckDatabase();
		}
	}

	public boolean checkPlayServices() {
		GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
		int resultCode = googleAPI.isGooglePlayServicesAvailable(this);
		if (resultCode != ConnectionResult.SUCCESS) {
			if (googleAPI.isUserResolvableError(resultCode)) {
				GooglePlayServicesUtil.getErrorDialog(resultCode, this,
						9000).show();
			} else {
				finish();
			}
			return false;
		}
		return true;
	}

	public void setChannelAlarmOnOff(boolean isThreadAlarm, boolean isReplyAlarm){
		PutGroupSettingReq req = new PutGroupSettingReq(0, isThreadAlarm, isReplyAlarm, App.m_MyUserInfo.m_nUserNo);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

	public void setAllAlarmOnOff(final boolean isAllAlam){
		PutGroupSettingReq req = new PutGroupSettingReq(0, isAllAlam, isAllAlam, isAllAlam, App.m_MyUserInfo.m_nUserNo);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				if(isAllAlam) {
					m_isOnlyUIChange = true;
					cb_push_receive_alram_popup.setChecked(true);
					pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
					cb_push_preview.setChecked(true);
					pref.setBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
					cb_sound.setChecked(true);
					pref.setBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
					cb_vibrate.setChecked(true);
					pref.setBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
					cb_alarm_snsgroupboard.setChecked(true);
					pref.setBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true);
					cb_alarm_snsgroupreply.setChecked(true);
					pref.setBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true);
					m_isOnlyUIChange = false;
				} else {
					m_isOnlyUIChange = true;
					cb_push_receive_alram_popup.setChecked(false);
					pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, false);
					cb_push_preview.setChecked(false);
					pref.setBooleanPref(SharedPref.PREF_PUSH_PREVIEW, false);
					cb_sound.setChecked(false);
					pref.setBooleanPref(SharedPref.PREF_ALRAM_SOUND, false);
					cb_vibrate.setChecked(false);
					pref.setBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, false);
					cb_alarm_snsgroupboard.setChecked(false);
					pref.setBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, false);
					cb_alarm_snsgroupreply.setChecked(false);
					pref.setBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, false);
					m_isOnlyUIChange = false;
				}
			}

			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		if(v.getId() == R.id.layout_set_alarm_push_receive_alram){
			if(cb_push_receive_alram.isChecked()){
				cb_push_receive_alram.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, false);
			} else {
				cb_push_receive_alram.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
			}
		} else if(v.getId() == R.id.layout_set_alarm_receive_alarm_popup){
			if(cb_push_receive_alram_popup.isChecked()){
				cb_push_receive_alram_popup.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, false);
			} else {
				cb_push_receive_alram_popup.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
			}
		} else if(v.getId() == R.id.layout_set_alarm_preview){
			if(cb_push_preview.isChecked()){
				cb_push_preview.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_PUSH_PREVIEW, false);
			} else {
				cb_push_preview.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
			}
		} else if(v.getId() == R.id.layout_set_alram_sound){
			if(cb_sound.isChecked()){
				cb_sound.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_ALRAM_SOUND, false);
			} else {
				cb_sound.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
			}
		} else if(v.getId() == R.id.layout_set_alram_vibrate){
			if(cb_vibrate.isChecked()){
				cb_vibrate.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, false);
			} else {
				cb_vibrate.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
			}
		} else if(v.getId() == R.id.layout_set_alarm_snsgroupboard){
			if(cb_alarm_snsgroupboard.isChecked()){
				cb_alarm_snsgroupboard.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, false);
			} else {
				cb_alarm_snsgroupboard.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true);
			}
		} else if(v.getId() == R.id.layout_set_alarm_snsgroupreply){
			if(cb_alarm_snsgroupreply.isChecked()){
				cb_alarm_snsgroupreply.setChecked(false);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, false);
			} else {
				cb_alarm_snsgroupreply.setChecked(true);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true);
			}
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if(buttonView.getId() == R.id.cb_push_receive_alram)
		{
			//처음에 페이지에 진입 했을때는 동작 하지 않도록 하기 위함
			if(isChecked && pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true)){

			} else if (!isChecked && !pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true)) {

			}
			else {
				cb_push_receive_alram.setChecked(isChecked);
				pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, isChecked);
				if (isChecked) {
					setAllAlarmOnOff(true);
				} else {
					setAllAlarmOnOff(false);
				}

				setVisibleUI();
			}
		}
		else if(buttonView.getId() == R.id.cb_push_receive_alram_popup)
		{
			cb_push_receive_alram_popup.setChecked(isChecked);
			pref.setBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, isChecked);
		}
		else if(buttonView.getId() == R.id.cb_push_preview)
		{
			cb_push_preview.setChecked(isChecked);
			pref.setBooleanPref(SharedPref.PREF_PUSH_PREVIEW, isChecked);
		}
		else if(buttonView.getId() == R.id.cb_sound)
		{
			cb_sound.setChecked(isChecked);
			pref.setBooleanPref(SharedPref.PREF_ALRAM_SOUND, isChecked);
		}
		else if(buttonView.getId() == R.id.cb_vibrate)
		{
			cb_vibrate.setChecked(isChecked);
			pref.setBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, isChecked);
		}
		else if(buttonView.getId() == R.id.cb_alarm_snsgroupboard)
		{
			if(isChecked && pref.getBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true)){

			} else if (!isChecked && !pref.getBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true)) {

			} else {
				cb_alarm_snsgroupboard.setChecked(isChecked);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, isChecked);
				if(!m_isOnlyUIChange)
					setChannelAlarmOnOff(pref.getBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true), pref.getBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true));
			}
		}
		else if(buttonView.getId() == R.id.cb_alarm_snsgroupreply)
		{
			if(isChecked && pref.getBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true)){

			} else if (!isChecked && !pref.getBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true)) {

			} else {
				cb_alarm_snsgroupreply.setChecked(isChecked);
				pref.setBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, isChecked);
				if(!m_isOnlyUIChange)
					setChannelAlarmOnOff(pref.getBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true), pref.getBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true));
			}
		}
	}
}
