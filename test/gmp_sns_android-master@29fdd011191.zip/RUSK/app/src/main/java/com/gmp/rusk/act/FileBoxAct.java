package com.gmp.rusk.act;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.FileProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonProgressPopup;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.FileBoxData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.filedownload.FileDownload;
import com.gmp.rusk.fragment.ChatRoomChatRoomListFlag;
import com.gmp.rusk.fragment.ChatRoomFellowListFlag;
import com.gmp.rusk.fragment.ChatRoomSearchListFlag;
import com.gmp.rusk.fragment.FileBoxTabFileFrag;
import com.gmp.rusk.fragment.FileBoxTabImageFrag;
import com.gmp.rusk.fragment.FileBoxTabMovieFrag;
import com.gmp.rusk.layout.ChatRoomOtherFileLayout;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetGroupFileReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetGroupFileRes;
import com.gmp.rusk.takemedia.FileUtil;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import ezvcard.Ezvcard;
import ezvcard.VCard;
import ezvcard.parameter.EmailType;
import ezvcard.parameter.TelephoneType;
import ezvcard.property.Telephone;

/**
 * Created by kang on 2017-09-17.
 */

public class FileBoxAct extends CustomActivity {

    static Fragment m_testFragment;
    TabHost mTabHost;
    TabManager mTabManager;

    public CommonPopup m_Popup = null;
    private CommonProgressPopup m_FileDownloadPopup = null;

    final private int TAB_INDEX_MAX = 3;
    final private int TAB_INDEX_FILELIST = 0;
    final private int TAB_INDEX_IMAGELIST = 1;
    final private int TAB_INDEX_MOVIELIST = 2;

    final private String TAB_FILE = "File";
    final private String TAB_IMAGE = "Image";
    final private String TAB_MOVIE = "Movie";


    public int m_nChannelID = 0;
    public String m_strChatroomID = "";

    public ArrayList<ChannelFileData> m_arrNormalFileListDatas = new ArrayList<ChannelFileData>();
    public ArrayList<ChannelFileData> m_arrImageListDatas = new ArrayList<ChannelFileData>();
    public ArrayList<ChannelFileData> m_arrVideoListDatas = new ArrayList<ChannelFileData>();

    public ArrayList<ChattingMessageData> m_arrChattingNormalFileListDatas = new ArrayList<ChattingMessageData>();
    public ArrayList<ChattingMessageData> m_arrChattingImageListDatas = new ArrayList<ChattingMessageData>();
    public ArrayList<ChattingMessageData> m_arrChattingVideoDatas = new ArrayList<ChattingMessageData>();

    TextView m_tvFileTab = null;
    TextView m_tvImageTab = null;
    TextView m_tvMovieTab = null;

    public OnFileViewListener m_ViewListener;
    public OnImageViewListener m_ImageViewListener;
    public OnVideoViewListener m_VideoViewListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_filebox);
        mTabHost = (TabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup();
        getIntentData();
        init();
        if (m_nChannelID != 0) {
            requestChannelFileList();
        } else {
            getDB();
        }

    }

    private void init() {

        ImageView ivClose = (ImageView) findViewById(R.id.btn_cancel);
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        View[] viewTabs;
        viewTabs = new View[TAB_INDEX_MAX];
        for (int i = 0; i < TAB_INDEX_MAX; i++) {
            LayoutInflater inflater = getLayoutInflater();
            viewTabs[i] = inflater.inflate(R.layout.layout_tabitem_text, null);

        }


        m_tvFileTab = (TextView) viewTabs[TAB_INDEX_FILELIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 파일 Tab
        m_tvImageTab = (TextView) viewTabs[TAB_INDEX_IMAGELIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 이미지 Tab
        m_tvMovieTab = (TextView) viewTabs[TAB_INDEX_MOVIELIST].findViewById(R.id.tv_tabitem_snsgroupmemberlist); // 동영상 Tab

        m_tvFileTab.setBackgroundResource(R.drawable.tabitem_background);
        m_tvImageTab.setBackgroundResource(R.drawable.tabitem_background);
        m_tvMovieTab.setBackgroundResource(R.drawable.tabitem_background);


        mTabManager = new TabManager(this, mTabHost, R.id.realtabcontent);

        mTabManager.addTab(mTabHost.newTabSpec(TAB_FILE).setIndicator(viewTabs[TAB_INDEX_FILELIST]), FileBoxTabFileFrag.class, null);
        mTabManager.addTab(mTabHost.newTabSpec(TAB_IMAGE).setIndicator(viewTabs[TAB_INDEX_IMAGELIST]), FileBoxTabImageFrag.class, null);
        mTabManager.addTab(mTabHost.newTabSpec(TAB_MOVIE).setIndicator(viewTabs[TAB_INDEX_MOVIELIST]), FileBoxTabMovieFrag.class, null);

    }

    private void getIntentData() {
        m_nChannelID = getIntent().getIntExtra(IntentKeyString.INTENT_KEY_SNSGROUPFILEBOX_GROUPID, 0);
        m_strChatroomID = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_SNSGROUPFILEBOX_CHATROOMID);
    }

    public int getChannelID() {
        return m_nChannelID;
    }

    public class TabManager implements TabHost.OnTabChangeListener {
        private final FragmentActivity mActivity;
        private final TabHost mTabHost;
        private final int mContainerId;
        private final HashMap<String, TabManager.TabInfo> mTabs = new HashMap<String, TabManager.TabInfo>();
        TabManager.TabInfo mLastTab;

        final class TabInfo {
            private final String tag;
            private final Class<?> clss;
            private final Bundle args;
            private Fragment fragment;

            TabInfo(String _tag, Class<?> _class, Bundle _args) {
                tag = _tag;
                clss = _class;
                args = _args;
            }
        }

        class DummyTabFactory implements TabHost.TabContentFactory {
            private final Context mContext;

            public DummyTabFactory(Context context) {
                mContext = context;
            }

            @Override
            public View createTabContent(String tag) {
                View v = new View(mContext);
                v.setMinimumWidth(0);
                v.setMinimumHeight(0);
                return v;
            }
        }

        public TabManager(FragmentActivity activity, TabHost tabHost, int containerId) {
            mActivity = activity;
            mTabHost = tabHost;
            mContainerId = containerId;
            mTabHost.setOnTabChangedListener(this);
        }

        public void addTab(TabHost.TabSpec tabSpec, Class<?> clss, Bundle args) {
            tabSpec.setContent(new TabManager.DummyTabFactory(mActivity));
            String tag = tabSpec.getTag();

            TabManager.TabInfo info = new TabManager.TabInfo(tag, clss, args);

            info.fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
            if (info.fragment != null && !info.fragment.isDetached()) {
                FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
                ft.detach(info.fragment);
                ft.commit();
            }
            m_testFragment = info.fragment;
            mTabs.put(tag, info);
            mTabHost.addTab(tabSpec);
        }

        @Override
        public void onTabChanged(String tabId) {
            TabManager.TabInfo newTab = mTabs.get(tabId);

            if (mLastTab != newTab) {

                FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
                if (mLastTab != null) {
                    if (mLastTab.fragment != null) {
                        ft.detach(mLastTab.fragment);
                    }
                }
                if (newTab != null) {
                    if (newTab.fragment == null) {
                        newTab.fragment = Fragment.instantiate(mActivity, newTab.clss.getName(), newTab.args);
                        ft.add(mContainerId, newTab.fragment, newTab.tag);
                    } else {
                        ft.attach(newTab.fragment);
                    }
                }

                mLastTab = newTab;
                ft.commit();
                mActivity.getSupportFragmentManager().executePendingTransactions();
            }
        }
    }

    private void requestChannelFileList() {
        GetGroupFileReq req = new GetGroupFileReq(m_nChannelID, 0, StaticString.FILE_TYPE_NORMAL);
        WebAPI webApi = new WebAPI(this);
        webApi.request(req, new WebListener() {
            @Override
            public void onPreRequest() {
                showProgress();
            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                closeProgress();
                showErrorPopup(nErrorCode, strMessage);
            }

            @Override
            public void onPostRequest(String a_strData) {
                closeProgress();
                GetGroupFileRes res = new GetGroupFileRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_FILES);
                ArrayList<ChannelFileData> arrFileListDatas = res.getChannelFileListData();
                for (int i = 0; i < arrFileListDatas.size(); i++) {
                    String strType = arrFileListDatas.get(i).m_strType;
                    if(strType.equals(StaticString.FILE_TYPE_NORMAL)){
                        m_arrNormalFileListDatas.add(arrFileListDatas.get(i));
                    } else if(strType.equals(StaticString.FILE_TYPE_IMAGE)){
                        m_arrImageListDatas.add(arrFileListDatas.get(i));
                    } else if(strType.equals(StaticString.FILE_TYPE_VIDEO)){
                        m_arrVideoListDatas.add(arrFileListDatas.get(i));
                    }
                }

                m_tvFileTab.setText(String.format(getString(R.string.tab_filebox_file), res.getChannelNormalFileCount()));
                m_tvImageTab.setText(String.format(getString(R.string.tab_filebox_image), res.getChannelImageCount()));
                m_tvMovieTab.setText(String.format(getString(R.string.tab_filebox_movie), res.getChannelMovieFileCount()));

                m_ViewListener.startView();
            }
        });

    }

    public void requestChannelFileList(int nPage, final String strType) {
        GetGroupFileReq req = new GetGroupFileReq(m_nChannelID, nPage, strType);
        WebAPI webApi = new WebAPI(this);
        webApi.request(req, new WebListener() {
            @Override
            public void onPreRequest() {
                showProgress();
            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {
                closeProgress();
                showErrorPopup(nErrorCode, strMessage);
            }

            @Override
            public void onPostRequest(String a_strData) {
                closeProgress();
                GetGroupFileRes res = new GetGroupFileRes(a_strData, ChannelRes.RES_TYPE_CHANNEL_FILES);
                ArrayList<ChannelFileData> arrFileListDatas = res.getChannelFileListData();
                for (int i = 0; i < arrFileListDatas.size(); i++) {
                    String strType = arrFileListDatas.get(i).m_strType;
                    if(strType.equals(StaticString.FILE_TYPE_NORMAL)){
                        m_arrNormalFileListDatas.add(arrFileListDatas.get(i));
                    } else if(strType.equals(StaticString.FILE_TYPE_IMAGE)){
                        m_arrImageListDatas.add(arrFileListDatas.get(i));
                    } else if(strType.equals(StaticString.FILE_TYPE_VIDEO)){
                        m_arrVideoListDatas.add(arrFileListDatas.get(i));
                    }
                }
                boolean isLastPage = false;
                if(arrFileListDatas.size() == 0 || arrFileListDatas.size() < 30){
                    isLastPage = true;
                }


                if(strType.equals(StaticString.FILE_TYPE_NORMAL)) {
                    m_ViewListener.startViewAdd(isLastPage);
                } else if(strType.equals(StaticString.FILE_TYPE_IMAGE)){
                    m_ImageViewListener.startViewAdd(isLastPage);
                } else if(strType.equals(StaticString.FILE_TYPE_VIDEO)){
                    m_VideoViewListener.startViewAdd(isLastPage);
                }
            }
        });

    }

    private void getDB() {

        ChattingDBManager chattingDBMng = new ChattingDBManager(FileBoxAct.this);
        chattingDBMng.openWritable(m_strChatroomID);
        ArrayList<ChattingMessageData> arrChattingMessageDatas = chattingDBMng.getChattingMessage();

        for (int i = 0; i < arrChattingMessageDatas.size(); i++) {
            if (arrChattingMessageDatas.get(i).m_nMsgType == StaticString.CHAT_ROOM_MY_FILE || arrChattingMessageDatas.get(i).m_nMsgType == StaticString.CHAT_ROOM_OTHER_FILE) {
                try {
                    JSONObject jsonObject = new JSONObject(arrChattingMessageDatas.get(i).m_strMsgText);
                    if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL)){
                        //연락처는 처리 하지 않기로 함
                            //|| jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT)) {
                        m_arrChattingNormalFileListDatas.add(0, arrChattingMessageDatas.get(i));
                    } else if (jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
                        m_arrChattingVideoDatas.add(0, arrChattingMessageDatas.get(i));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else if (arrChattingMessageDatas.get(i).m_nMsgType == StaticString.CHAT_ROOM_MY_IMAGE || arrChattingMessageDatas.get(i).m_nMsgType == StaticString.CHAT_ROOM_OTHER_IMAGE) {
                m_arrChattingImageListDatas.add(0, arrChattingMessageDatas.get(i));
            }
        }
        chattingDBMng.close();

        m_tvFileTab.setText(String.format(getString(R.string.tab_filebox_file), m_arrChattingNormalFileListDatas.size()));
        m_tvImageTab.setText(String.format(getString(R.string.tab_filebox_image), m_arrChattingImageListDatas.size()));
        m_tvMovieTab.setText(String.format(getString(R.string.tab_filebox_movie), m_arrChattingVideoDatas.size()));
    }


    public void downloadFile(final FileBoxData a_FileData, final boolean a_isSaveTTalkFolder) {
        if (FileUtil.getAvailableExternalMemorySize() < 104857600) {
            showDownloadFailWhySizePopup();
        } else if(a_FileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
                (App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled))){

            m_Popup = new CommonPopup(this, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CommonPopup popup = (CommonPopup) v.getTag();
                    popup.cancel();
                    popup.dismiss();
                }
            }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
            m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
            m_Popup.setCancelable(false);
            m_Popup.show();
        }
        else if(!a_FileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileDownloadEnabled) ||
                (App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileDownloadEnabled))){
            m_Popup = new CommonPopup(this, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CommonPopup popup = (CommonPopup) v.getTag();
                    popup.cancel();
                    popup.dismiss();
                }
            }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
            m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
            m_Popup.setCancelable(false);
            m_Popup.show();
        }
        else {
            if(a_FileData.m_strType.equals(StaticString.FILE_TYPE_NORMAL) && AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)){
                Utils.startFileViewPlus(FileBoxAct.this, a_FileData.m_strFileName, a_FileData.m_strUrl);
            } else {
                SharedPref pref = SharedPref.getInstance(this);
                if (pref.getBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, false)) {
                    startDownloadFile(a_FileData, a_isSaveTTalkFolder);
                } else {
                    final String strPopupMsg = a_FileData.m_strType.equals(StaticString.FILE_TYPE_VIDEO) ? getString(R.string.cork_pop_video_down) : getString(R.string.cork_pop_file_down);
                    m_Popup = new CommonPopup(this, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (v.getId() == R.id.ib_pop_ok) {
                                CommonPopup popup_cancel = (CommonPopup) v.getTag();
                                popup_cancel.cancel();
                                SharedPref pref = SharedPref.getInstance(FileBoxAct.this);
                                pref.setBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, true);

                                startDownloadFile(a_FileData, a_isSaveTTalkFolder);
                            } else {
                                CommonPopup popup_cancel = (CommonPopup) v.getTag();
                                popup_cancel.cancel();
                            }
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
                    m_Popup.setBodyAndTitleText(this.getString(R.string.pop_confirm), strPopupMsg);
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
            }
        }
    }

    private void startDownloadFile(final FileBoxData a_FileData, boolean a_isSaveTTalkFolder){
        final FileDownload fileDownload = new FileDownload(this, m_nChannelID, a_FileData.m_nFileNo, a_FileData.m_strUrl, a_isSaveTTalkFolder);
        m_FileDownloadPopup = new CommonProgressPopup(this, new CommonProgressPopup.OnCommonProgressPopupCanceled() {

            @Override
            public void onCommonProgressPopupCanceled() {
                // TODO Auto-generated method stub
                fileDownload.stopDownload();
            }
        });

        fileDownload.startDownload(new FileDownload.OnDownloadComplete() {

            @Override
            public void onDownloadFail() {
                // TODO Auto-generated method stub
                // 다운로드 실패 처리
                CommonLog.e(getClass(), "File Download Fail");
                m_FileDownloadPopup.dismiss();
                m_Popup = new CommonPopup(FileBoxAct.this, new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        // TODO Auto-generated method stub
                        CommonPopup popup = (CommonPopup) v.getTag();
                        popup.cancel();
                        popup.dismiss();
                    }
                }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_fail_download_err_network));
                m_Popup.setCancelable(false);
                isCheckShowPopup();
            }

            @Override
            public void onComplete(String a_strFilePath) {
                // TODO Auto-generated method stub
                CommonLog.e(getClass(), "Result Path : " + a_strFilePath);
                m_FileDownloadPopup.dismiss();
                showDownloadCompletePopup(a_strFilePath);
            }

            @Override
            public void onProgess(int a_nCount, int a_nTotal) {
                // TODO Auto-generated method stub
                m_FileDownloadPopup.setMax(a_nTotal);
                m_FileDownloadPopup.setProgress(a_nCount);
            }

            @Override
            public void onStart() {
                m_FileDownloadPopup.setMax(100);
                m_FileDownloadPopup.setProgress(0);
                m_FileDownloadPopup.setCancelable(true);
                m_FileDownloadPopup.show();
            }
        });
    }
    public void downloadFile(final String a_strRoomID, final JSONObject jsonObject, final String a_strMsgId) {
        try {
            if ((System.currentTimeMillis() < (jsonObject.getLong(StaticString.XMPP_TEXT_CREATETIME) + 1814400000)) || jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT)) {
                if (FileUtil.getAvailableExternalMemorySize() < 104857600) {
                    showDownloadFailWhySizePopup();
                } else if(jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileImageDownloadEnabled) ||
                        (App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileImageDownloadEnabled))){
                    m_Popup = new CommonPopup(this, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            CommonPopup popup = (CommonPopup) v.getTag();
                            popup.cancel();
                            popup.dismiss();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                    m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
                else if(!jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO) && !jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT) && ((App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER) && !App.m_EntryData.m_MultiTenancy.isPartnerMobileNormalFileDownloadEnabled) ||
                        (App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_REGULAR) && !App.m_EntryData.m_MultiTenancy.isRegularMobileNormalFileDownloadEnabled))){
                    m_Popup = new CommonPopup(this, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            CommonPopup popup = (CommonPopup) v.getTag();
                            popup.cancel();
                            popup.dismiss();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
                    m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
                    m_Popup.setCancelable(false);
                    m_Popup.show();
                }
                else {
                    if(jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL) && AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR)){
                        Utils.startFileViewPlus(FileBoxAct.this, jsonObject.getString(StaticString.XMPP_TEXT_FILENAME), jsonObject.getString(StaticString.XMPP_TEXT_URL));
                    } else {
                        SharedPref pref = SharedPref.getInstance(this);
                        if (pref.getBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, false)) {

                            startDownloadFile(a_strRoomID, jsonObject, a_strMsgId);
                        } else {
                            final String strPopupMsg = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO) ? getString(R.string.cork_pop_video_down) : getString(R.string.cork_pop_file_down);
                            m_Popup = new CommonPopup(this, new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (v.getId() == R.id.ib_pop_ok) {
                                        CommonPopup popup_cancel = (CommonPopup) v.getTag();
                                        popup_cancel.cancel();
                                        SharedPref pref = SharedPref.getInstance(FileBoxAct.this);
                                        pref.setBooleanPref(SharedPref.PREF_FILEDOWNLOAD_POPUP_VIEW, true);

                                        startDownloadFile(a_strRoomID, jsonObject, a_strMsgId);
                                    } else {
                                        CommonPopup popup_cancel = (CommonPopup) v.getTag();
                                        popup_cancel.cancel();
                                    }
                                }
                            }, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
                            m_Popup.setBodyAndTitleText(this.getString(R.string.pop_confirm), strPopupMsg);
                            m_Popup.setCancelable(false);
                            m_Popup.show();
                        }
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void startDownloadFile(String a_strRoomID, final JSONObject jsonObject, final String a_strMsgId){
        try {
            boolean isVcard = false;
            if(jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT))
                isVcard = true;
            final FileDownload fileDownload = new FileDownload(this, a_strRoomID, a_strMsgId, jsonObject.getString(StaticString.XMPP_TEXT_URL), isVcard);
            m_FileDownloadPopup = new CommonProgressPopup(this, new CommonProgressPopup.OnCommonProgressPopupCanceled() {

                @Override
                public void onCommonProgressPopupCanceled() {
                    // TODO Auto-generated method stub
                    fileDownload.stopDownload();
                }
            });

            fileDownload.startDownload(new FileDownload.OnDownloadComplete() {

                @Override
                public void onDownloadFail() {
                    // TODO Auto-generated method stub
                    // 다운로드 실패 처리
                    CommonLog.e(getClass(), "File Download Fail");
                    m_FileDownloadPopup.dismiss();
                    m_Popup = new CommonPopup(FileBoxAct.this, new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            CommonPopup popup = (CommonPopup) v.getTag();
                            popup.cancel();
                            popup.dismiss();
                        }
                    }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
                    m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_fail_download_err_network));
                    m_Popup.setCancelable(false);
                    isCheckShowPopup();
                }

                @Override
                public void onComplete(String a_strFilePath) {
                    // TODO Auto-generated method stub
                    CommonLog.e(getClass(), "Result Path : " + a_strFilePath);
                    m_FileDownloadPopup.dismiss();
                    try {
                        if(jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT)){
                            startSaveContact(jsonObject.getString(StaticString.XMPP_TEXT_FILENAME), a_strFilePath);
                        } else {
                            showDownloadCompletePopup(a_strFilePath);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onProgess(int a_nCount, int a_nTotal) {
                    // TODO Auto-generated method stub
                    m_FileDownloadPopup.setMax(a_nTotal);
                    m_FileDownloadPopup.setProgress(a_nCount);
                }

                @Override
                public void onStart() {
                    m_FileDownloadPopup.setMax(100);
                    m_FileDownloadPopup.setProgress(0);
                    m_FileDownloadPopup.setCancelable(true);
                    m_FileDownloadPopup.show();
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void showDownloadFailWhySizePopup() {
        m_Popup = new CommonPopup(this, new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                CommonPopup popup = (CommonPopup) v.getTag();
                popup.cancel();
                popup.dismiss();
            }
        }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
        m_Popup.setBodyAndTitleText(getString(R.string.popup_fail_download_title), getString(R.string.popup_fail_download_text));
        m_Popup.setCancelable(false);
        isCheckShowPopup();
    }

    private void showDownloadCompletePopup(final String a_strFilePath) {
        m_Popup = new CommonPopup(this, new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                CommonPopup popup = (CommonPopup) v.getTag();
                popup.cancel();
                popup.dismiss();
                int nId = v.getId();
                if (nId == R.id.ib_pop_ok) {
                    startFileOpen(a_strFilePath);
                }
            }
        }, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
        m_Popup.setBodyAndTitleText(getString(R.string.popup_downloadcomplete_title), getString(R.string.popup_downloadcomplete_text));
        m_Popup.setCancelable(false);
        isCheckShowPopup();
    }

    private void showFileOpenFailPopup() {
        m_Popup = new CommonPopup(FileBoxAct.this, new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                CommonPopup popup = (CommonPopup) v.getTag();
                popup.cancel();
                popup.dismiss();
            }
        }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
        m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_fail_file_action));
        m_Popup.setCancelable(false);
        isCheckShowPopup();
    }

    public void showImageErrorPopup(){
        m_Popup = new CommonPopup(this, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CommonPopup popup = (CommonPopup) v.getTag();
                popup.cancel();
                popup.dismiss();
            }
        }, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
        m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.cork_pop_fail_open_file));
        m_Popup.setCancelable(false);
        m_Popup.show();
    }
    private void startFileOpen(String a_strFilePath)
    {
        Intent fileLinkIntent = new Intent(Intent.ACTION_VIEW);

        String extension = a_strFilePath.substring(a_strFilePath.lastIndexOf(".") + 1, a_strFilePath.length());
        extension = extension.toLowerCase();
        File file = new File(a_strFilePath);
        boolean isAction = true;
        if (extension.equalsIgnoreCase("txt")) {
            fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "text/*");
        } else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
            fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/msword");
        } else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
            fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/vnd.ms-excel");
        } else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
            fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/vnd.ms-powerpoint");
        } else if (extension.equalsIgnoreCase("pdf")) {
            fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/pdf");
        } else if (extension.equalsIgnoreCase("hwp")) {
            fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "application/haansofthwp");
        } else {
            isAction = false;
            String[] arrVideoList = getResources().getStringArray(R.array.arr_chat_video_list);
            String[] arrImageList = getResources().getStringArray(R.array.arr_chat_image_list);
            for (int i = 0; i < arrVideoList.length; i++) {
                if (extension.equalsIgnoreCase(arrVideoList[i])) {
                    fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "video/*");
                    isAction = true;
                    break;
                }
            }
            for (int i = 0; i < arrImageList.length; i++) {
                if (extension.equalsIgnoreCase(arrImageList[i])) {
                    fileLinkIntent.setDataAndType(FileProvider.getUriForFile(this, StaticString.FILE_PROVIDER, file), "image/*");
                    isAction = true;
                    break;
                }
            }
            if (!isAction) {
                showFileOpenFailPopup();
            }
        }

        if (isAction) {
            fileLinkIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            PackageManager packageManager = getPackageManager();
            List activities = packageManager.queryIntentActivities(fileLinkIntent,
                    PackageManager.MATCH_DEFAULT_ONLY);
            boolean isIntentSafe = activities.size() > 0;
            if(isIntentSafe) {
                startActivity(fileLinkIntent);
            } else {
                Toast.makeText(this, getString(R.string.cork_toast_not_fount_app), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startSaveContact(String a_strName, String a_strFilePath)
    {
        try {
            File file = new File(a_strFilePath);
            FileInputStream fis = new FileInputStream(a_strFilePath);
            byte[] b = new byte[(int) file.length()];
            fis.read(b);
            String vCard = new String(b);
            fis.close();
            VCard vcard = Ezvcard.parse(vCard).first();
            ArrayList<ContentValues> data = new ArrayList<ContentValues>();

            List<Telephone> arrTele = vcard.getTelephoneNumbers();
            for(Telephone tele : arrTele)
            {
                int nType = ContactsContract.CommonDataKinds.Phone.TYPE_OTHER;
                Iterator<TelephoneType> iter = tele.getTypes().iterator();
                while (iter.hasNext()) {
                    TelephoneType type = iter.next();

                    if(type == TelephoneType.CELL)
                    {
                        nType = ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE;
                        break;
                    }
                    else if(type == TelephoneType.HOME)
                    {
                        nType = ContactsContract.CommonDataKinds.Phone.TYPE_HOME;
                        break;
                    }
                    else if(type == TelephoneType.WORK)
                    {
                        nType = ContactsContract.CommonDataKinds.Phone.TYPE_WORK;
                        break;
                    }
                    else
                    {
                        nType = ContactsContract.CommonDataKinds.Phone.TYPE_OTHER;
                        break;
                    }
                }

                ContentValues row = new ContentValues();
                row.put(ContactsContract.Contacts.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                row.put(ContactsContract.CommonDataKinds.Phone.NUMBER, tele.getText());
                row.put(ContactsContract.CommonDataKinds.Phone.TYPE, nType);
                data.add(row);
            }

            List<ezvcard.property.Email> arrEmail = vcard.getEmails();
            for(ezvcard.property.Email email : arrEmail)
            {
                int nType = ContactsContract.CommonDataKinds.Email.TYPE_OTHER;
                Iterator<EmailType> iter = email.getTypes().iterator();
                while (iter.hasNext()) {
                    EmailType type = iter.next();
                    if(type == EmailType.INTERNET)
                        continue;

                    if(type == EmailType.HOME)
                    {
                        nType = ContactsContract.CommonDataKinds.Email.TYPE_HOME;
                        break;
                    }
                    else if(type == EmailType.WORK)
                    {
                        nType = ContactsContract.CommonDataKinds.Email.TYPE_WORK;
                        break;
                    }
                    else
                    {
                        nType = ContactsContract.CommonDataKinds.Email.TYPE_OTHER;
                        break;
                    }
                }

                ContentValues row = new ContentValues();
                row.put(ContactsContract.Contacts.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE);
                row.put(ContactsContract.CommonDataKinds.Email.TYPE, nType);
                row.put(ContactsContract.CommonDataKinds.Email.ADDRESS, email.getValue());
                data.add(row);
            }

            Intent intent = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
            intent.putExtra(ContactsContract.Intents.Insert.NAME, a_strName);
            intent.putParcelableArrayListExtra(ContactsContract.Intents.Insert.DATA, data);
            startActivity(intent);

        } catch (FileNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void isCheckShowPopup() {
        if (super.m_isRunning) {
            m_Popup.show();
        }
    }

    public interface OnFileViewListener{
        public void startView();
        public void startViewAdd(boolean isLastPage);
    }

    public interface OnImageViewListener{
        public void startViewAdd(boolean isLastPage);
    }

    public interface OnVideoViewListener{
        public void startViewAdd(boolean isLastPage);
    }

    public void setViewListener(OnFileViewListener listener){
        m_ViewListener = listener;
    }

    public void setViewListener(OnImageViewListener listener){
        m_ImageViewListener = listener;
    }

    public void setViewListener(OnVideoViewListener listener){
        m_VideoViewListener = listener;
    }
}
