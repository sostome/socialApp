package com.gmp.rusk.datamodel;

import android.graphics.Bitmap;

public class ChattingRoomImageData {

	public Bitmap bitmap = null;
	public byte[] byteBmp = null;
	public String strPath = "";

}
