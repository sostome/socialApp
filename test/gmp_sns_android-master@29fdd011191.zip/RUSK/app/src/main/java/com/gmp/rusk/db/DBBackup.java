package com.gmp.rusk.db;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.PCClientAuthAct;
import com.gmp.rusk.act.SetDeviceChangeAct;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.ResolveText;
import com.gmp.rusk.utils.StaticString;

import android.content.Context;
import android.util.SparseBooleanArray;

public class DBBackup {


	public static final String JSON_CHATTINGMSGS 			= "chattingMsgs";
	public static final String JSON_ROOMID					= "ri";
	public static final String JSON_MSGS					= "msgs";
	public static final String JSON_MESSAGEID				= "mi";
	public static final String JSON_SENDERID				= "si";
	public static final String JSON_MESSAGETIMESTAMP		= "mt";
	public static final String JSON_MESSAGE					= "m";
	public static final String JSON_ISREAD					= "ir";
	public static final String JSON_READCOUNT				= "rc";
	public static final String JSON_MESSAGETYPE				= "tm";
	public static final String JSON_FILETYPE				= "tf";
	public static final String JSON_FILENAME				= "fn";
	public static final String JSON_DOCID					= "di";
	public static final String JSON_FILETIMESTAMP			= "ft";
	public static final String JSON_FILEURL					= "uf";
	public static final String JSON_THUMBNAILURL			= "ut";
	public static final String JSON_IMAGESIZE				= "is";
	public static final String JSON_IMAGEWIDTH				= "w";
	public static final String JSON_IMAGEHEIGHT				= "h";
	
	public static final String JSON_CTROOMTITLE				= "rn";
	public static final String JSON_ROOMBOOKMARKED			= "rb";
	
	public static final String JSON_GROUPS					= "groups";
	public static final String JSON_GROUPFAVORITE			= "gf";
	public static final String JSON_EMOTICON				= "emo";

	public static final int MESSAGETYPE_SYSTEM				= 1;
	public static final int MESSAGETYPE_TEXT				= 2;
	public static final int MESSAGETYPE_FILE				= 3;
	public static final int MESSAGETYPE_URGENT				= 4;

	
	// return : Json String Byte
	public static String makeJsonByte(Context a_Context)
	{
		return getJsonBackupString(a_Context);
	}
	
	private static String getJsonBackupString(Context a_Context)
	{
		MyApp App = MyApp.getInstance();
		JSONObject jsonRoot = new JSONObject();
		
		try
		{
			ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(a_Context);
			SparseBooleanArray arrFavotiteGroupId = TTalkDBManager.SNSGroupDBManager.getFavoriteGroup(a_Context);
			int nFavoriteGroupIdsSize = arrFavotiteGroupId.size();
			if(arrRoomData != null && arrRoomData.size() > 0)
			{
				JSONArray jsonChattingRoom = new JSONArray(); 
				for(ChattingRoomInfoData roomData : arrRoomData)
				{
					JSONObject jsonRoom = new JSONObject();
					if(roomData.m_strRoomId.length() < 8){
						jsonRoom.put(JSON_ROOMID, roomData.m_strRoomId + "@cork.com.com");
					} else {
						jsonRoom.put(JSON_ROOMID, roomData.m_strRoomId + "@groupchat.cork.com");
					}
					
					if(roomData.m_isTitleEdited){
						
						LocalAesCrypto crypto = new LocalAesCrypto();
						jsonRoom.put(JSON_CTROOMTITLE, crypto.decrypt(roomData.m_strRoomTitle));
					}
					jsonRoom.put(JSON_ROOMBOOKMARKED, roomData.m_isFavorite);
					JSONArray jsonChattingMsgs = new JSONArray();
					ChattingDBManager chattingDBManager = new ChattingDBManager(a_Context);
					chattingDBManager.openReadable(roomData.m_strRoomId);
					ArrayList<ChattingMessageData> arrChattingMsgData = chattingDBManager.getChattingMessage();
					chattingDBManager.close();
					for(ChattingMessageData chattingData : arrChattingMsgData)
					{
						JSONObject jsonChattingMsg = new JSONObject();
						jsonChattingMsg.put(JSON_MESSAGEID, chattingData.m_strMsgId);
						if(chattingData.m_nSendUserId == 0){
							jsonChattingMsg.put(JSON_SENDERID, "" + App.m_MyUserInfo.m_nUserNo);
						} else {
							jsonChattingMsg.put(JSON_SENDERID, "" + chattingData.m_nSendUserId);
						}
						jsonChattingMsg.put(JSON_MESSAGETIMESTAMP, "" + chattingData.m_lnMsgSendTime);
						jsonChattingMsg.put(JSON_ISREAD, chattingData.m_isRead);
						jsonChattingMsg.put(JSON_READCOUNT, Integer.toString(chattingData.m_nNoReadUserCount));
						
						if(chattingData.m_nMsgType == StaticString.CHAT_ROOM_SYSTEM_MSG){
							jsonChattingMsg.put(JSON_MESSAGETYPE, MESSAGETYPE_SYSTEM);
							jsonChattingMsg.put(JSON_MESSAGE, chattingData.m_strMsgText);
						}
						else if(chattingData.m_nMsgType == 0 || chattingData.m_nMsgType == StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE || chattingData.m_nMsgType == StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE)
						{
							if(chattingData.m_strEmoticon.equals("")) {
								jsonChattingMsg.put(JSON_MESSAGETYPE, MESSAGETYPE_TEXT);
								jsonChattingMsg.put(JSON_MESSAGE, chattingData.m_strMsgText);
							} else {
								jsonChattingMsg.put(JSON_MESSAGETYPE,MESSAGETYPE_TEXT);
								jsonChattingMsg.put(JSON_MESSAGE,chattingData.m_strMsgText);
								jsonChattingMsg.put(JSON_EMOTICON,chattingData.m_strEmoticon);
							}
		
						}
						else if(chattingData.m_nMsgType  == StaticString.CHAT_ROOM_URGENT_MESSAGE)
						{
							jsonChattingMsg.put(JSON_MESSAGETYPE, MESSAGETYPE_URGENT);
							jsonChattingMsg.put(JSON_MESSAGE, chattingData.m_strMsgText);
							
						}
						else if(chattingData.m_nMsgType  == StaticString.CHAT_ROOM_MY_IMAGE || chattingData.m_nMsgType  == StaticString.CHAT_ROOM_OTHER_IMAGE)
						{
							jsonChattingMsg.put(JSON_MESSAGETYPE, MESSAGETYPE_FILE);
							jsonChattingMsg.put(JSON_FILETYPE, StaticString.FILE_TYPE_IMAGE);
							JSONObject jsonText = new JSONObject(chattingData.m_strMsgText);
							jsonChattingMsg.put(JSON_FILENAME, "");
							jsonChattingMsg.put(JSON_FILEURL, jsonText.getString(StaticString.XMPP_TEXT_URL));
							jsonChattingMsg.put(JSON_THUMBNAILURL, jsonText.getString(StaticString.XMPP_TEXT_THUMB));
							JSONObject jsonImage = new JSONObject();
							jsonImage.put(JSON_IMAGEWIDTH, jsonText.getString(StaticString.XMPP_TEXT_WIDTH));
							jsonImage.put(JSON_IMAGEHEIGHT, jsonText.getString(StaticString.XMPP_TEXT_HEIGHT));
							jsonChattingMsg.put(JSON_IMAGESIZE, jsonImage);
						}
						else if(chattingData.m_nMsgType  == StaticString.CHAT_ROOM_MY_FILE || chattingData.m_nMsgType  == StaticString.CHAT_ROOM_OTHER_FILE)
						{
							jsonChattingMsg.put(JSON_MESSAGETYPE, MESSAGETYPE_FILE);
							JSONObject jsonText = new JSONObject(chattingData.m_strMsgText);
							if(jsonText.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT)){
								jsonChattingMsg.put(JSON_FILETYPE, StaticString.FILE_TYPE_CONTACT);
								jsonChattingMsg.put(JSON_FILEURL, jsonText.getString(StaticString.XMPP_TEXT_URL));
								jsonChattingMsg.put(JSON_FILENAME, jsonText.getString(StaticString.XMPP_TEXT_FILENAME));
							}
							else if(jsonText.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_VIDEO)){
								jsonChattingMsg.put(JSON_FILETYPE, StaticString.FILE_TYPE_VIDEO);
								//동영상의 경우 파일 이름에 ""가 들어간다.
								jsonChattingMsg.put(JSON_FILEURL, jsonText.getString(StaticString.XMPP_TEXT_URL));
								jsonChattingMsg.put(JSON_FILENAME, jsonText.getString(StaticString.XMPP_TEXT_FILENAME));
								jsonChattingMsg.put(JSON_THUMBNAILURL, jsonText.getString(StaticString.XMPP_TEXT_THUMB));
								if (!jsonText.getString(StaticString.XMPP_TEXT_CREATETIME).equals("0")) {
									jsonChattingMsg.put(JSON_FILETIMESTAMP, jsonText.getString(StaticString.XMPP_TEXT_CREATETIME));
								}
							}
							else if(jsonText.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_NORMAL)){
								jsonChattingMsg.put(JSON_FILETYPE, StaticString.FILE_TYPE_NORMAL);
								jsonChattingMsg.put(JSON_FILEURL, jsonText.getString(StaticString.XMPP_TEXT_URL));
								jsonChattingMsg.put(JSON_FILENAME, jsonText.getString(StaticString.XMPP_TEXT_FILENAME));
								if (!jsonText.getString(StaticString.XMPP_TEXT_CREATETIME).equals("0")) {
									jsonChattingMsg.put(JSON_FILETIMESTAMP, jsonText.getString(StaticString.XMPP_TEXT_CREATETIME));
								}			
							}
						}
						jsonChattingMsgs.put(jsonChattingMsg);
					}
					jsonRoom.put(JSON_MSGS, jsonChattingMsgs);
					if(!roomData.m_strRoomId.equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))){
						jsonChattingRoom.put(jsonRoom);
						//CommonLog.e(PCClientAuthAct.class.getSimpleName(), "DB Json Chatting Room: " + jsonRoom);
					}

				}

				jsonRoot.put(JSON_CHATTINGMSGS, jsonChattingRoom);
				
			}
			if(arrFavotiteGroupId != null && nFavoriteGroupIdsSize > 0){
				JSONArray jsonFavoriteGroupArray = new JSONArray();
				JSONObject jsonFavoriteGroupsObject = new JSONObject();
				String strFavoriteGroups = "";
				for(int i = 0; i < nFavoriteGroupIdsSize; i++){
					strFavoriteGroups += arrFavotiteGroupId.keyAt(i);
					if(i != (nFavoriteGroupIdsSize - 1)){
						strFavoriteGroups += "|";
					}
				}
				jsonFavoriteGroupsObject.put(JSON_GROUPFAVORITE, strFavoriteGroups);
				jsonFavoriteGroupArray.put(jsonFavoriteGroupsObject);
				jsonRoot.put(JSON_GROUPS, jsonFavoriteGroupArray);
				//CommonLog.e(PCClientAuthAct.class.getSimpleName(), "DB Json Favorite: " + jsonFavoriteGroupArray);
				
			}
			if(jsonRoot.isNull(JSON_CHATTINGMSGS)){
				CommonLog.e(PCClientAuthAct.class.getSimpleName(), "DB Backup Json : isNull");
				jsonRoot.put(JSON_CHATTINGMSGS, JSONObject.NULL);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			try {
				jsonRoot.put(JSON_CHATTINGMSGS, JSONObject.NULL);
			} catch (JSONException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		return jsonRoot.toString();
	}
	
//	
//	private static String saveJsonFile(Context a_Context, String a_strJsonString)
//	{
//		String strFileName = "";
//		File file = null;
//		try {
//			File dir = new File(Environment.getExternalStorageDirectory().getPath() + File.separator + a_Context.getString(R.string.takepicture_save_directory));
//	        if (!dir.exists())
//	            dir.mkdirs();
//	        
//	        strFileName = System.currentTimeMillis() + ".json";
//	        file = new File(dir.getPath() + File.separator + strFileName);
//	        if(!file.exists())
//	        	file.createNewFile();
//	        
//	        byte[] bFile = a_strJsonString.getBytes();
//	        FileOutputStream fos;
//	        if(bFile != null)
//	        {
//	        	fos = new FileOutputStream(file);
//	        	fos.write(bFile);
//	        	fos.flush();
//		        fos.close();
//	        }
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			strFileName = "";
//			if(file != null && file.exists())
//			{
//				file.delete();
//			}
//		}
//		
//		return strFileName;
//	}
}
