package com.gmp.rusk.act;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.PostRequestApprovalReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.PopupIndex;

/**
 * PartnerSignUpSuccessAct
 * @author subi78
 * 파트너 회원가입 완료 Activity
 */
public class PartnerSignUpWattingAct extends Activity implements OnClickListener {

	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;
	public boolean m_isRunning = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_partner_signup_waitting);
		setResult(Activity.RESULT_OK);		
		setSignUpSuccessUI();
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	
	private void setSignUpSuccessUI()
	{
		ImageView btnCancel = (ImageView) findViewById(R.id.btn_cancel);
		btnCancel.setOnClickListener(this);
		Button ib_retry = (Button)findViewById(R.id.ib_retry);
		ib_retry.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_retry)
		{
			reqeustRequestApproval();
		}
		else if(v.getId() == R.id.btn_cancel)
		{
			finish();
		}

		else if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				finish();
			}
			else
				popup_ok_long.cancel();
		}
	}
	
	private void reqeustRequestApproval()
	{
		showProgress();
		PostRequestApprovalReq req = new PostRequestApprovalReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String strData) {
				// TODO Auto-generated method stub
				closeProgress();
				m_Popup = new CommonPopup(PartnerSignUpWattingAct.this, PartnerSignUpWattingAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.pop_requestApproval).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				Toast.makeText(PartnerSignUpWattingAct.this, "승인 재요청 실패", Toast.LENGTH_SHORT).show();
				if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(PartnerSignUpWattingAct.this, PartnerSignUpWattingAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(PartnerSignUpWattingAct.this, PartnerSignUpWattingAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}
}
