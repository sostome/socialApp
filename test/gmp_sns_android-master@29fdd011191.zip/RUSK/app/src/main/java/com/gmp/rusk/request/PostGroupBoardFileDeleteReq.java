package com.gmp.rusk.request;

import java.util.ArrayList;

/**
 *	@author kch
 *			모임 게시글 삭제
 *			method : delete
 */

public class PostGroupBoardFileDeleteReq extends Req{
	
	private String APINAME = "group";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	
	public PostGroupBoardFileDeleteReq(ArrayList<Integer> a_arrFileId)
	{
		String strFileIds = "";
		int nFileIdCount = a_arrFileId.size();
		for(int i = 0; i < nFileIdCount; i++)
		{
			strFileIds += "" + a_arrFileId.get(i);
			if(i != nFileIdCount - 1)
				strFileIds += ",";
		}
		APINAME = APINAME + "/board/file/" + strFileIds; 
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
