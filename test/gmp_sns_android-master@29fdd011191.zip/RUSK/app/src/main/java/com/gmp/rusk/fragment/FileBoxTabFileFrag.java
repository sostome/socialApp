package com.gmp.rusk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.act.FileBoxAct;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.FileBoxData;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.listview.LoadMoreListView;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetGroupFileReq;
import com.gmp.rusk.response.ChannelRes;
import com.gmp.rusk.response.GetGroupFileRes;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by kang on 2017-09-17.
 */

public class FileBoxTabFileFrag extends Fragment {

    View m_vFileBox;
    LoadMoreListView lvFileList;

    LayoutInflater m_Inflater;

    FileListAdapter fileListAdapter;

    ArrayList<FileBoxData> m_arrFileListDatas = new ArrayList<FileBoxData>();
    private ProgressDlg m_Progress = null;

    boolean m_isChannel = false;
    int m_nPage = 1;
    boolean m_isLastPage = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        m_vFileBox = inflater.inflate(R.layout.fragact_filebox_tab_file, container, false);
        m_Inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ((FileBoxAct)getContext()).setViewListener(m_ViewListener);
        initUI();
        return m_vFileBox;
    }

    private void initUI(){

        if(((FileBoxAct)getActivity()).m_nChannelID != 0) {
            m_isChannel = true;
            setChannelFileList();
        } else {
            m_isChannel = false;
            setChatRoomFileList();
        }

    }

    private class FileListAdapter extends BaseAdapter {

        ViewHolder viewHolder;

        @Override
        public void notifyDataSetChanged() {
            // TODO Auto-generated method stub

            super.notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            int nUserListDataSize = 0;

            if (m_arrFileListDatas != null)
                nUserListDataSize = m_arrFileListDatas.size();

            return nUserListDataSize;
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return m_arrFileListDatas.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            final FileBoxData m_Data = (FileBoxData) m_arrFileListDatas.get(position);


            // convertView null 시 새로 생성하자
            if(convertView == null)
            {
                convertView = m_Inflater.inflate(R.layout.layout_file_listitem, parent, false);
                viewHolder = new ViewHolder();
                viewHolder.layout = (LinearLayout)convertView.findViewById(R.id.layout_filebox_file);
                viewHolder.m_ivFileIcon = (ImageView)convertView.findViewById(R.id.iv_file_icon);
                viewHolder.m_tvFileName = (TextView) convertView.findViewById(R.id.tv_file_filename);
                viewHolder.m_tv_FileSize = (TextView) convertView.findViewById(R.id.tv_file_filesize);
                viewHolder.m_tv_fileDivider = (TextView) convertView.findViewById(R.id.tv_divider);
                viewHolder.m_tv_fileLinker = (TextView) convertView.findViewById(R.id.tv_file_filelinkername);
                viewHolder.m_tvFileDownDate = (TextView) convertView.findViewById(R.id.tv_file_filedate);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }

            if(m_Data != null){
                viewHolder.m_tvFileName.setText(m_Data.m_strFileName);
                String extension;
                if(m_Data.m_strType.equals(StaticString.FILE_TYPE_CONTACT)){
                    extension = m_Data.m_strUrl.substring(m_Data.m_strUrl.lastIndexOf(".") + 1, m_Data.m_strUrl.length());
                } else {
                    extension = m_Data.m_strFileName.substring(m_Data.m_strFileName.lastIndexOf(".") + 1, m_Data.m_strFileName.length());
                }
                extension = extension.toLowerCase();
                if (extension.equalsIgnoreCase("txt")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_text_s);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_text);
                } else if (extension.equalsIgnoreCase("doc") || extension.equalsIgnoreCase("docx")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_word_s);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_word);
                } else if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx") || extension.equalsIgnoreCase("csv")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_excel);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_excel);
                } else if (extension.equalsIgnoreCase("ppt") || extension.equalsIgnoreCase("pptx")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_ppt);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_ppt);
                } else if (extension.equalsIgnoreCase("pdf")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_pdf);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_pdf);
                } else if (extension.equalsIgnoreCase("hwp")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_han_s);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_han);
                } else if (extension.equalsIgnoreCase("png") || extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("jpeg") || extension.equalsIgnoreCase("bmp")){
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_image);
                } else if (extension.equalsIgnoreCase("avi") || extension.equalsIgnoreCase("asf") || extension.equalsIgnoreCase("mov") || extension.equalsIgnoreCase("mp4") || extension.equalsIgnoreCase("wmv")){
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_video);
                }  else if (extension.equalsIgnoreCase("vcf")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_vcf);
                } else if (extension.equalsIgnoreCase("zip")) {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                    viewHolder.m_tv_fileLinker.setText(R.string.snsfile_zip);
                }
                else {
                    viewHolder.m_ivFileIcon.setImageResource(R.drawable.icon_filezip_copy);
                }

                if(m_isChannel) {
                    float fFileSize = Utils.bytesToMegabyteFloat(m_Data.m_lnFileSize);
                    if (fFileSize == 0.0)
                        fFileSize = 0.1F;

                    viewHolder.m_tv_FileSize.setText(String.format(getString(R.string.snsboarddetail_filesize), fFileSize));
                    viewHolder.m_tvFileDownDate.setText(m_Data.m_strTime);
                    viewHolder.layout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ((FileBoxAct)getActivity()).downloadFile(m_Data, false);
                        }
                    });
                } else {
                    viewHolder.m_tv_FileSize.setVisibility(View.GONE);
                    viewHolder.m_tv_fileDivider.setVisibility(View.GONE);
                    viewHolder.m_tvFileDownDate.setText(m_Data.m_strTime);
                    viewHolder.layout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            ((FileBoxAct)getActivity()).downloadFile(((FileBoxAct)getActivity()).m_strChatroomID, m_Data.m_jsonObject, m_Data.m_strMsgId
                            );
                        }
                    });
                }
            }

            return convertView;
        }
    }

    public class ViewHolder {
        public TextView m_tvFileName,m_tv_FileSize,m_tv_fileDivider,m_tv_fileLinker,m_tvFileDownDate;
        public ImageView m_ivFileIcon;
        public LinearLayout layout;
    }


    private void setChannelFileList(){
        m_arrFileListDatas = new ArrayList<FileBoxData>();
        ArrayList<ChannelFileData> arrData = ((FileBoxAct)getActivity()).m_arrNormalFileListDatas;
        SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());

        for(int i = 0; i < arrData.size(); i++){
            FileBoxData data = new FileBoxData();
            data.m_strFileName = arrData.get(i).m_strFileName;
            data.m_strUrl = arrData.get(i).m_strUrl;
            data.m_lnFileSize = arrData.get(i).m_lnFileSize;
            data.m_strType = arrData.get(i).m_strType;
            data.m_nFileNo = arrData.get(i).m_nFileNo;
            try {
                Date createDate = sdfOriginal.parse(arrData.get(i).m_strTime);
                SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
                data.m_strTime = sdfCreateDateUIPrint.format(createDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            m_arrFileListDatas.add(data);
        }

        lvFileList = (LoadMoreListView) m_vFileBox.findViewById(R.id.lv_file_list);
        lvFileList.setOnLoadMoreListener(m_OnFileBoxLoadMoreListener);
        fileListAdapter = new FileListAdapter();
        lvFileList.setAdapter(fileListAdapter);

    }

    private void setChannelFileAddList(boolean isLastPage){
        m_isLastPage = isLastPage;
        m_arrFileListDatas = new ArrayList<FileBoxData>();
        ArrayList<ChannelFileData> arrData = ((FileBoxAct)getActivity()).m_arrNormalFileListDatas;
        SimpleDateFormat sdfOriginal = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZZZZZ", Locale.getDefault());

        for(int i = 0; i < arrData.size(); i++){
            FileBoxData data = new FileBoxData();
            data.m_strFileName = arrData.get(i).m_strFileName;
            data.m_strUrl = arrData.get(i).m_strUrl;
            data.m_lnFileSize = arrData.get(i).m_lnFileSize;
            data.m_strType = arrData.get(i).m_strType;
            data.m_nFileNo = arrData.get(i).m_nFileNo;
            try {
                Date createDate = sdfOriginal.parse(arrData.get(i).m_strTime);
                SimpleDateFormat sdfCreateDateUIPrint = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
                data.m_strTime = sdfCreateDateUIPrint.format(createDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            m_arrFileListDatas.add(data);
        }
        completeLoadMore();
        fileListAdapter.notifyDataSetChanged();

    }

    private void setChatRoomFileList(){

        m_arrFileListDatas = new ArrayList<FileBoxData>();
        ArrayList<ChattingMessageData> arrMessageData = ((FileBoxAct)getActivity()).m_arrChattingNormalFileListDatas;

        String pattern = "yyyy.MM.dd";
        SimpleDateFormat format = new SimpleDateFormat(pattern);

        for(int i = 0; i < arrMessageData.size(); i++){
            FileBoxData data = new FileBoxData();
            try {
                JSONObject jsonObject = new JSONObject(arrMessageData.get(i).m_strMsgText);
                data.m_strMsgId = arrMessageData.get(i).m_strMsgId;
                data.m_strFileName = jsonObject.getString(StaticString.XMPP_TEXT_FILENAME);
                data.m_strUrl = jsonObject.getString(StaticString.XMPP_TEXT_URL);
                data.m_strType = jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE);
                data.m_lnFileSize = 0;
                data.m_jsonObject = jsonObject;
                if(jsonObject.getString(StaticString.XMPP_TEXT_MIMEYPE).equals(StaticString.FILE_TYPE_CONTACT)){
                    data.m_strTime = (String) format.format(new Timestamp(arrMessageData.get(i).m_lnMsgSendTime));
                } else {
                    data.m_strTime = (String) format.format(new Timestamp(jsonObject.getLong(StaticString.XMPP_TEXT_CREATETIME)));
                }
                m_arrFileListDatas.add(data);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        lvFileList = (LoadMoreListView) m_vFileBox.findViewById(R.id.lv_file_list);
        FileListAdapter fileListAdapter = new FileListAdapter();
        lvFileList.setAdapter(fileListAdapter);

    }

    FileBoxAct.OnFileViewListener m_ViewListener = new FileBoxAct.OnFileViewListener() {
        @Override
        public void startView() {
            setChannelFileList();
        }

        @Override
        public void startViewAdd(boolean isLastPage) {
            setChannelFileAddList(isLastPage);
        }
    };

    private LoadMoreListView.OnLoadMoreListener m_OnFileBoxLoadMoreListener = new LoadMoreListView.OnLoadMoreListener() {
        @Override
        public void onLoadMore() {
            if(!m_isLastPage)
                ((FileBoxAct)getActivity()).requestChannelFileList(m_nPage++, StaticString.FILE_TYPE_NORMAL);
        }
    };

    private void completeLoadMore(){
        lvFileList.onLoadMoreComplete();
    }
}
