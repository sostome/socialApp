package com.gmp.rusk.response;

import android.content.Context;

import com.gmp.rusk.datamodel.FellowListData;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface UserEntryResObject {

    //중복 정의 되는 부분 뺌
    public final String JSON_USER                  = "user";
    public final String JSON_USERID                 = "userId";
    public final String JSON_USERNO 					= "userNo";
    public final String JSON_TYPE		 			= "type";
    //public final String JSON_NAME					= "name";
    public final String JSON_MOBILE				= "mobile";
    public final String JSON_COMPANYCODE 			= "companyCode";
    public final String JSON_COMPANYNAME               = "companyName";
    public final String JSON_DEPARTMENT			= "department";
    public final String JSON_DEPARTMENTCODE 			= "departmentCode";
    public final String JSON_PARENTDEPARTMENT		= "parentDepartment";
    public final String JSON_CHARGE				= "charge";
    public final String JSON_SECONDCHARGE			= "secondCharge";
    public final String JSON_AFFILIATION				= "affiliation";
    public final String JSON_IMAGEAVAILABLE		= "imageAvailable";
    public final String JSON_GREETING				= "greeting";
    public final String JSON_AVAILABLE				= "available";

    public void parseEntryUserData();
    public FellowListData getEntryUserData(Context context);
}
