package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ApprovalListData;
import com.gmp.rusk.utils.CommonLog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class GetSearchApprovalUserRes extends Res{


	public GetSearchApprovalUserRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}

}
