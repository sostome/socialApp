package com.gmp.rusk.customview;

import com.gmp.rusk.R;
import com.gmp.rusk.utils.AppSetting;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ProgressBar;

public class CommonProgressPopup extends Dialog {
	
	public interface OnCommonProgressPopupCanceled
	{
		public void onCommonProgressPopupCanceled();
	}
	
	private OnCommonProgressPopupCanceled m_onCanceled = null;

	public CommonProgressPopup(Context context, OnCommonProgressPopupCanceled a_onCanceled) {
		super(context);
		// TODO Auto-generated constructor stub
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		
		setContentView(R.layout.act_dlg_custom_progress_popup);

		m_onCanceled = a_onCanceled;
	}
	
	@Override
	public void cancel() {
		// TODO Auto-generated method stub
		if(m_onCanceled != null)
			m_onCanceled.onCommonProgressPopupCanceled();
		super.cancel();		
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
	}
	
	@Override
	public void onDetachedFromWindow() {
		// 
		super.onDetachedFromWindow();
	}
	
	public void setMax(int a_nProgress)
	{
		ProgressBar pbProgress = (ProgressBar)findViewById(R.id.pb_popup_progress);
		pbProgress.setMax(a_nProgress);
	}
	
	public void setProgress(int a_nProgress)
	{
		ProgressBar pbProgress = (ProgressBar)findViewById(R.id.pb_popup_progress);
		pbProgress.setProgress(a_nProgress);
	}
}
