package com.gmp.rusk.datamodel;

import org.json.JSONObject;

import java.util.ArrayList;

public class ChatRoomData {

	public String m_strRoomID;					//방 ID	
	public int m_nType;							//메시지 타입
	public int m_nNO;							//사용자 넘버
	public String m_strName;					//사용자 이름
	public String m_strSenderType;				//사용자 타입
	public String m_strSystemMSG;				//시스템 메시지
	public String m_strOtherMSG;				//다른 사용자 메시지
	public String m_strMyMSG;					//자기 메시지
	public String m_strMyImageUrl;				//자기가 올린 이미지
	public String m_strMyImageThumbUrl;			//자기가 올린 이미지 섬네일
	public String m_strOtherImageUrl; 			//다른 사람이 올린 이미지
	public String m_strOtherImageThumbUrl;		//다른 사람이 올린 이미지 섬네일
	public String m_strOtherFile;				//다른 사람이 올린 파일
	public String m_strMyFile;					//자기가 올린 파일
	public int m_nRead;							//글을 읽은 사람의 수
	public long m_lDate;						//전송 시간
	public String m_strMessageID;				//메시지 아이디
	public int m_nSendStatus;					//전송 상태
	//public ArrayList<Integer> m_arrRead; 		//글을 읽은 사람
	//public ArrayList<Integer> m_arrTotalRead; 	//글이 작성될 때 총 인원
	public int m_nNoReadCount;
	public int m_nWidht;						//이미지 가로
	public int m_nHeight;						//이미지 세로
	public boolean m_isImageAvailable;				//프로필 이미지 유무
	public String m_strMimetype;				//동영상 : V, 일반문서 : N, 클라우드 : C
	public boolean m_isSmileView = false;
	public long m_lCreateTime;					//파일을 전달 할 시, 기존의 생성시간
	public String m_strCloudUrl;				//클라우드 Url
	public String m_strVdi;					 //Vdi 여부
	//TINI이미지 용
	public boolean m_isHaveToDraw = true;
	//TINI이미지에 어떤 것을 사용할 것인가?
	public String m_EmoticonName;
	//대화 내용 검색
	public String m_strSearchText = "";
	//모임 공지 공유
	public String m_strGroupId;
	public String m_strBoardNo;
	public String m_strSNSNoticeText = "";
	public int m_nImageCount;
	public String m_strImage = "";
	public int m_nFileCount;
	public int m_nFileSize;
	public String m_strFileName = "";
	//선택지용
	public ArrayList<String> m_tiniSelectItem = new ArrayList<String>();

	//대화 전달용, 기왕 JSONObject를 만든김에 해당 데이터를 활용하여 Layout을 구성하면 좋으나,
	//기존 코드를 모두 수정하기 어려워 임시적인 조치
	public JSONObject m_JsonObject = new JSONObject();

}
