package com.gmp.rusk.db;

import java.util.ArrayList;

import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.utils.CommonLog;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class RoomDBAdapter {
	
	// Database File Name
	private static final String DATABASE_NAME 		= "ttalk_room.db";
	
	// Room Table Name
	private static final String TABLE_ROOM 			= "Room";
	
	// Room Table Field Name
	public static final String KEY_ROOM_ROOMID				= "roomId";				// Room Id
	public static final String KEY_ROOM_ROOMTITLE			= "roomTitle";			// Room Title
	public static final String KEY_ROOM_ISALARMON			= "isAlarmOn";			// 알람 On/Off
	public static final String KEY_ROOM_ROOMOWNERID			= "roomOwnerId";		// 방장 Id
	public static final String KEY_ROOM_ISTITLEDITED		= "isTitleEdited";		// Romm Title 사용자에 의해 변경되었는지 여부
	public static final String KEY_ROOM_ISFAVORITE			= "isFavorite";			// 즐겨찾기
	public static final String KEY_ROOM_BACKGROUND_COLOR	= "backgroundColor";	// 배경색
	public static final String KEY_ROOM_COVERIMAGE			= "coverImage";			//커버 이미지
	
	// Create Table Query
	private final String ROOM_CREATE = "create table " + TABLE_ROOM + " (" + 
												KEY_ROOM_ROOMID 			+ " text primary key , " +
												KEY_ROOM_ROOMTITLE 			+ " text not null, " +
												KEY_ROOM_ISALARMON 			+ " integer not null, " +
												KEY_ROOM_ROOMOWNERID		+ " integer, " + 
												KEY_ROOM_ISTITLEDITED		+ " integer not null, " + 
												KEY_ROOM_ISFAVORITE			+ " integer not null, "+
												KEY_ROOM_BACKGROUND_COLOR   + " integer default 0, " +
												KEY_ROOM_COVERIMAGE			+ " text" +");";

	
//	private final String ROOM_CREATE = "create table " + TABLE_ROOM + " (" + 
//			KEY_ROOM_ROOMID 			+ " text primary key , " +
//			KEY_ROOM_ROOMTITLE 			+ " text not null, " +
//			KEY_ROOM_ISALARMON 			+ " integer not null, " +
//			KEY_ROOM_ROOMOWNERID		+ " integer, " + 
//			KEY_ROOM_ISTITLEDITED		+ " integer not null);";
	
	// Drop Table Query 
	private final String ROOM_DROP = "DROP TABLE IF EXISTS " + TABLE_ROOM;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private RoomDBHelper m_dbHelper = null;
	
	public RoomDBAdapter(Context context)
	{
		m_context = context;
		m_dbHelper = new RoomDBHelper(m_context, DATABASE_NAME, null, DatabaseDefine.DATABASE_ROOMDB_VERSION);
//		m_dbHelper = new RoomDBHelper(m_context, DATABASE_NAME, null, 1);
	}
	
	// Database Open Read & Write Permission
	public RoomDBAdapter open() throws SQLException
	{
		m_db = m_dbHelper.getWritableDatabase();
		return this;
	}
	
	// Database Open Read Permission
	public RoomDBAdapter openReadOnly() throws SQLException
	{
		m_db = m_dbHelper.getReadableDatabase();
		return this;
	}
	
	// Database Close
	public void close()
	{
		m_db.close();
	}
	
	/**
	 * insertContacts
	 * 채팅방 Array 추가 Query
	 * @param a_arrRoomListData	ChattingRoomInfoData ArrayList : 추가할 방정보 ArrayList
	 * @return int insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertRoom(ArrayList<ChattingRoomInfoData> a_arrRoomListData)
	{
		int nCount = 0;
		
		if(a_arrRoomListData == null || a_arrRoomListData.size() == 0)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			for(ChattingRoomInfoData data : a_arrRoomListData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_ROOM_ROOMID, data.m_strRoomId);
				value.put(KEY_ROOM_ROOMTITLE, data.m_strRoomTitle);
				if(data.m_isAlarmOn)
					value.put(KEY_ROOM_ISALARMON, 1);		//
				else
					value.put(KEY_ROOM_ISALARMON, 0);
					
				value.put(KEY_ROOM_ROOMOWNERID, data.m_nRoomOwnerId);
				
				if(data.m_isTitleEdited)
					value.put(KEY_ROOM_ISTITLEDITED, 1);		//
				else
					value.put(KEY_ROOM_ISTITLEDITED, 0);
				
				if(data.m_isFavorite)
					value.put(KEY_ROOM_ISFAVORITE, 1);		//
				else
					value.put(KEY_ROOM_ISFAVORITE, 0);
					
				
				m_db.insert(TABLE_ROOM, null, value);
				nCount++;
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * insertRoom 
	 * 채팅방 단일 추가 Insert Query
	 * @param a_roomData ChattingRoomInfoData : 추가할 UserListData 
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertRoom(ChattingRoomInfoData a_roomData)
	{
		int nCount = 0;
		
		if(a_roomData == null)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_ROOM_ROOMID, a_roomData.m_strRoomId);
			value.put(KEY_ROOM_ROOMTITLE, a_roomData.m_strRoomTitle);
			if(a_roomData.m_isAlarmOn)
				value.put(KEY_ROOM_ISALARMON, 1);		//
			else
				value.put(KEY_ROOM_ISALARMON, 0);
				
			value.put(KEY_ROOM_ROOMOWNERID, a_roomData.m_nRoomOwnerId);
			
			if(a_roomData.m_isTitleEdited)
				value.put(KEY_ROOM_ISTITLEDITED, 1);		//
			else
				value.put(KEY_ROOM_ISTITLEDITED, 0);
			
			if(a_roomData.m_isFavorite)
				value.put(KEY_ROOM_ISFAVORITE, 1);		//
			else
				value.put(KEY_ROOM_ISFAVORITE, 0);
			if(!a_roomData.m_strCoverImagUrl.equals(""))
				value.put(KEY_ROOM_COVERIMAGE,a_roomData.m_strCoverImagUrl);
			else
				value.put(KEY_ROOM_COVERIMAGE,"");
			
			m_db.insert(TABLE_ROOM, null, value);
			nCount++;
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateRoom
	 * 채팅방 Array Update Query 
	 * ChattingRoomInfoData.m_strRoomId로 비교하여 Update를 수행
	 * @param a_arrChattingListData ChattingRoomInfoData ArrayList : Update 할 ChattingRoomInfoData의 ArrayList
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateRoom(ArrayList<ChattingRoomInfoData> a_arrChattingListData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			for(ChattingRoomInfoData data : a_arrChattingListData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_ROOM_ROOMTITLE, data.m_strRoomTitle);
				if(data.m_isAlarmOn)
					value.put(KEY_ROOM_ISALARMON, 1);		//
				else
					value.put(KEY_ROOM_ISALARMON, 0);
				value.put(KEY_ROOM_ROOMOWNERID, data.m_nRoomOwnerId);
				
				if(data.m_isTitleEdited)
					value.put(KEY_ROOM_ISTITLEDITED, 1);		//
				else
					value.put(KEY_ROOM_ISTITLEDITED, 0);
				
				if(data.m_isFavorite)
					value.put(KEY_ROOM_ISFAVORITE, 1);		//
				else
					value.put(KEY_ROOM_ISFAVORITE, 0);
				
				/*m_db.insert(TABLE_ROOM, null, value);*/
				
				nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + data.m_strRoomId + "\"", null);
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateRoom
	 * 채팅방 단일 Update Query 
	 * ChattingRoomInfoData.m_strRoomId로 비교하여 Update를 수행
	 * @param a_roomData ChattingRoomInfoData : Update 할 ChattingRoomInfoData
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateRoom(ChattingRoomInfoData a_roomData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_ROOM_ROOMTITLE, a_roomData.m_strRoomTitle);
			if(a_roomData.m_isAlarmOn)
				value.put(KEY_ROOM_ISALARMON, 1);		//
			else
				value.put(KEY_ROOM_ISALARMON, 0);
			value.put(KEY_ROOM_ROOMOWNERID, a_roomData.m_nRoomOwnerId);
			
			if(a_roomData.m_isTitleEdited)
				value.put(KEY_ROOM_ISTITLEDITED, 1);		//
			else
				value.put(KEY_ROOM_ISTITLEDITED, 0);
			
			if(a_roomData.m_isFavorite)
				value.put(KEY_ROOM_ISFAVORITE, 1);		//
			else
				value.put(KEY_ROOM_ISFAVORITE, 0);
			
			/*m_db.insert(TABLE_ROOM, null, value);*/
			
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_roomData.m_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateRoom
	 * 채팅방 단일 Update Query 
	 * a_strRoomId로 비교하여 Update를 수행
	 * @param a_strRoomId 수정할 RoomId
	 * @param a_nRoomOwnerId 
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateRoom(String a_strRoomId, int a_nRoomOwnerId)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_ROOM_ROOMOWNERID, a_nRoomOwnerId);			
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateRoom
	 * 채팅방 단일 Update Query 
	 * a_strRoomId로 비교하여 Update를 수행
	 * @param a_strRoomId 수정할 RoomId
	 * @param a_strTitle
	 * @param a_isTitleEdited 
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateRoom(String a_strRoomId, String a_strTitle, boolean a_isTitleEdited)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_ROOM_ROOMTITLE, a_strTitle);
			if(a_isTitleEdited)
				value.put(KEY_ROOM_ISTITLEDITED, 1);		//
			else
				value.put(KEY_ROOM_ISTITLEDITED, 0);			
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateRoom
	 * 채팅방 단일 Update Query 
	 * a_strRoomId로 비교하여 Update를 수행
	 * @param a_strRoomId 수정할 RoomId
	 * @param a_strTitle
	 * @param a_isAlarmOn 
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateRoom(String a_strRoomId, boolean a_isAlarmOn)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			if(a_isAlarmOn)
				value.put(KEY_ROOM_ISALARMON, 1);		//
			else
				value.put(KEY_ROOM_ISALARMON, 0);			
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	/**
	 * updateRoom
	 * 채팅방 단일 Update Query
	 * a_strRoomId로 비교하여 Update를 수행
	 * @param a_strRoomId 수정할 RoomId
	 * @param a_strImage
	 * @return int Update 한 개수, 0보다 작으면 에러
	 */
	public int updateRoom(String a_strRoomId, String a_strImage)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();//
			value.put(KEY_ROOM_COVERIMAGE, a_strImage);
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}

		return nCount;
	}
	/**
	 * updateRoom
	 * 채팅방 단일 Update Query 
	 * a_strRoomId로 비교하여 Update를 수행
	 * @param a_strRoomId 수정할 RoomId
	 * @param a_strTitle
	 * @param a_isFavorite
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateRoomFavorite(String a_strRoomId, boolean a_isFavorite)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			if(a_isFavorite)
				value.put(KEY_ROOM_ISFAVORITE, 1);		//
			else
				value.put(KEY_ROOM_ISFAVORITE, 0);			
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int updateRoomTitle(int a_nGroupId, String a_strRoomTitle)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_ROOM_ROOMTITLE, a_strRoomTitle);		//
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + " LIKE " + "\"%_" + a_nGroupId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}

	public int updateChatListBackgroundColor(String a_strRoomId, int nColor){
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			ContentValues value = new ContentValues();
			value.put(KEY_ROOM_BACKGROUND_COLOR, nColor);        //
			nCount = m_db.update(TABLE_ROOM, value, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}

		return nCount;

	}


	/**
	 * deleteRoom
	 * 채팅방 전체 삭제
	 * @return int 삭제한 개수
	 */
	public int deleteRoom()
	{
		return m_db.delete(TABLE_ROOM, null, null);
	}
	
	/**
	 * deleteRoom
	 * 채팅방 단일 삭제
	 * @param a_nUserId 삭제할 UserId
	 * @return int 삭제한 개수
	 */
	public int deleteRoom(String a_strRoomId)
	{
		return m_db.delete(TABLE_ROOM, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null);
	}
	
	/**
	 * getRoomList
	 * 채팅방 가져오기
	 * @return DB Cursor
	 */
	
	public Cursor getRoomList()
	{
		return m_db.query(TABLE_ROOM, null, null, null, null, null, null);
	}
	
	public Cursor getRoom(String a_strRoomId)
	{
		return m_db.query(TABLE_ROOM, null, KEY_ROOM_ROOMID + "=\"" + a_strRoomId + "\"", null, null, null, null);
	}
	
	// SQLite Open Helper Class
	private class RoomDBHelper extends SQLiteOpenHelper
	{

		public RoomDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(ROOM_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			if(oldVersion == 2 && newVersion == 3)
			{
				ArrayList<ChattingRoomInfoData> arrRoomInfo = new ArrayList<ChattingRoomInfoData>();
				Cursor cursor = getRoomList(db);
				if (cursor.moveToFirst()) {
					do {
						String strRoomId = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMID));
						String strRoomTitle = cursor.getString(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMTITLE));
						int nRoomOwnerId = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ROOMOWNERID));
						boolean isAlarmOn = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISALARMON)) == 1 ? true : false;
						boolean isTitleEdited = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_ISTITLEDITED)) == 1 ? true : false;
						int backgroundColor = cursor.getInt(cursor.getColumnIndex(RoomDBAdapter.KEY_ROOM_BACKGROUND_COLOR));

						ChattingRoomInfoData data = new ChattingRoomInfoData(strRoomId, strRoomTitle, isAlarmOn, nRoomOwnerId, isTitleEdited,false,backgroundColor);
						arrRoomInfo.add(data);

					} while (cursor.moveToNext());
				}

				cursor.close();
				
				db.execSQL(ROOM_DROP);
				onCreate(db);
				
				insertRoom(db, arrRoomInfo);
			}
			else
			{
				db.execSQL(ROOM_DROP);
				onCreate(db);
			}
		}
		
		private int insertRoom(SQLiteDatabase db, ArrayList<ChattingRoomInfoData> a_arrRoomListData)
		{
			int nCount = 0;
			
			if(a_arrRoomListData == null || a_arrRoomListData.size() == 0)
				return 0;
			
			try
			{
				db.beginTransaction();
				for(ChattingRoomInfoData data : a_arrRoomListData)
				{
					ContentValues value = new ContentValues();
					value.put(KEY_ROOM_ROOMID, data.m_strRoomId);
					value.put(KEY_ROOM_ROOMTITLE, data.m_strRoomTitle);
					if(data.m_isAlarmOn)
						value.put(KEY_ROOM_ISALARMON, 1);		//
					else
						value.put(KEY_ROOM_ISALARMON, 0);
						
					value.put(KEY_ROOM_ROOMOWNERID, data.m_nRoomOwnerId);
					
					if(data.m_isTitleEdited)
						value.put(KEY_ROOM_ISTITLEDITED, 1);		//
					else
						value.put(KEY_ROOM_ISTITLEDITED, 0);
					
					if(data.m_isFavorite)
						value.put(KEY_ROOM_ISFAVORITE, 1);		//
					else
						value.put(KEY_ROOM_ISFAVORITE, 0);
					
					db.insert(TABLE_ROOM, null, value);
					nCount++;
				}
				db.setTransactionSuccessful();
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				nCount = -1;
			}
			finally{
				db.endTransaction();
			}
			
			return nCount;
		}
		
		private Cursor getRoomList(SQLiteDatabase db)
		{
			return db.query(TABLE_ROOM, null, null, null, null, null, null);
		}
	}
}
