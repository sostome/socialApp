package com.gmp.rusk.network;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.net.ssl.SSLSocket;

import com.gmp.rusk.utils.CommonLog;

public class NoSSLv3SSLSocket extends DelegateSSLSocket {

	public NoSSLv3SSLSocket(SSLSocket delegate) {
		super(delegate);

		String canonicalName = delegate.getClass().getCanonicalName();
		if (!canonicalName.equals("org.apache.harmony.xnet.provider.jsse.OpenSSLSocketImpl")) {
			// try replicate the code from HttpConnection.setupSecureSocket()
			try {
				Method msetUseSessionTickets = delegate.getClass().getMethod("setUseSessionTickets", boolean.class);
				if (null != msetUseSessionTickets) {
					msetUseSessionTickets.invoke(delegate, true);
				}
			} catch (NoSuchMethodException ignored) {
			} catch (InvocationTargetException ignored) {
			} catch (IllegalAccessException ignored) {
			}
		}
	}

	@Override
	public void setEnabledProtocols(String[] protocols) {
		if (protocols != null && protocols.length == 1 && "SSLv3".equals(protocols[0])) {
			// no way jose
			// see issue https://code.google.com/p/android/issues/detail?id=78187
			List<String> enabledProtocols = new ArrayList<String>(Arrays.asList(delegate.getEnabledProtocols()));
			if (enabledProtocols.size() > 1) {
				enabledProtocols.remove("SSLv3");
			} else {
				CommonLog.w(NoSSLv3SSLSocket.class.getSimpleName(), "SSL stuck with protocol available for " + String.valueOf(enabledProtocols));
			}
			protocols = enabledProtocols.toArray(new String[enabledProtocols.size()]);
		}
		super.setEnabledProtocols(protocols);
	}
}
