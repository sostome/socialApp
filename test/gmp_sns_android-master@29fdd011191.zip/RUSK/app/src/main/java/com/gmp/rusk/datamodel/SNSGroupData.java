package com.gmp.rusk.datamodel;

public class SNSGroupData {
	
	public static final String MEMBERED_TYPE_NO = "N";		// 미수락
	public static final String MEMBERED_TYPE_RETRY = "R";	// 재초대
	
	// SNS Group 공통
	public int m_nGroupId = 0;
	public String m_strGroupName = "";
	public int m_nImageIndex = -1;
	public String m_strGroupImageUrl = "";
	public String m_strGroupPreviewImageUrl = "";
	public int m_nUserCount = 0;
	public boolean m_isFavorite = false;
	
	// 아직 수락 안한 Group
	public String m_strMembered = MEMBERED_TYPE_NO;

	// GNB 메뉴 용 타입
	public int m_nViewType = -1;
}
