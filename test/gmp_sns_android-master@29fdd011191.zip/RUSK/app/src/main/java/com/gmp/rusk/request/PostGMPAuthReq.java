package com.gmp.rusk.request;

import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

/**
 *	@author kch
 *			정직원 GMP 인증정보 등록
 *			method : post
 */

public class PostGMPAuthReq extends Req{

	private String APINAME = "regular";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";


	private final String JSON_AUTHKEY = "authKey";
	private final String JSON_ENCPWD 	= "encPwd";
	private final String JSON_MDN	 	= "mdn";


	public PostGMPAuthReq()
	{
		APINAME = APINAME + "/gmpAuth";
	}


	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_AUTHKEY, App.m_GMPData.m_strAuthKey);
			jsonObj.put(JSON_ENCPWD, App.m_GMPData.m_strEncPwd);
			jsonObj.put(JSON_MDN, App.m_Mdn);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PostGMPAuthReq.class.getSimpleName(), "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
