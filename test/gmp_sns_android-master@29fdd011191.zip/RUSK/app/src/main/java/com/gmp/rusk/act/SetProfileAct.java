package com.gmp.rusk.act;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonListPopup;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.GalleryListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.imageloader.FileCacheDBAdapter;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserInfoReq;
import com.gmp.rusk.request.PostChangeImageReq;
import com.gmp.rusk.request.PutChangeGreetingReq;
import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.takemedia.TakeMediaIntent;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.StringUtil;
import com.gmp.rusk.utils.Utils;
import com.yalantis.ucrop.UCrop;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * SetProfileAct
 * 
 * @author subi78 프로필 입력 및 수정 Activity
 */
public class SetProfileAct extends CustomActivity {

	ImageView iv_pic;
	EditText et_profile_greeting;
	EditText et_profile_company;

	private boolean m_isUploadImage = false;
	private TakeMediaIntent m_TakeMedia = null;

	private Bitmap m_Bitmap;
	private byte[] m_BitmapByte;

	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;

	private UserInfoData m_UserInfoData;

	private boolean m_isCrop = false;

	private CommonListPopup m_ListPopup = null;

	//이미지가 없는 상태에서, 이미지를 등록 한 후 '편집' 을 누를때 사용
	private Uri m_cropUri = null;

	//카메라로 찍고 '편집'을 누를때 사용
	private boolean m_isCamera = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
			setContentView(R.layout.act_set_profile);
		requestGetUserInfo();
		// setProfileUI();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if(m_TakeMedia != null){
			m_TakeMedia.deleteDirectory();
		}
	}

	private void setProfileUI() {
		SharedPref pref = SharedPref.getInstance(this);
		iv_pic = (ImageView) findViewById(R.id.iv_pic);
		iv_pic.setOnClickListener(this);
		TextView tv_profile_name = (TextView) findViewById(R.id.tv_profile_name);
		TextView tv_profile_team = (TextView) findViewById(R.id.tv_profile_team);
		et_profile_company = (EditText) findViewById(R.id.et_profile_company);
		et_profile_company.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				// TODO Auto-generated method stub
				if (keyCode == KeyEvent.KEYCODE_ENTER) {
					return true;
				}
				return false;
			}
		});
		TextView tv_profile_mobile = (TextView) findViewById(R.id.tv_profile_mobile);
		TextView tv_profile_email = (TextView) findViewById(R.id.tv_profile_email);
		et_profile_greeting = (EditText) findViewById(R.id.et_profile_greeting);

		et_profile_greeting.setOnKeyListener(new OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				// TODO Auto-generated method stub
				if (keyCode == KeyEvent.KEYCODE_ENTER) {
					return true;
				}
				return false;
			}
		});
		et_profile_company.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if (et_profile_company.getText().toString().length() > 30) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_limit_company));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(et_profile_company.getText().toString().contains("|")){
					String strReplaceText = et_profile_company.getText().toString();
					strReplaceText = strReplaceText.replace("|", "");
					et_profile_company.setText(strReplaceText);
					et_profile_company.setSelection(start);
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_pipe_contain));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if(et_profile_company.getText().toString().contains(" ")){
					String strReplaceText = et_profile_company.getText().toString();
					strReplaceText = strReplaceText.replace(" ", "");
					et_profile_company.setText(strReplaceText);
					et_profile_company.setSelection(start);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});
		et_profile_greeting.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if (et_profile_greeting.getText().toString().length() > 30) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_limit_greeting));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});

		ImageButton ib_sign_up_edit = (ImageButton) findViewById(R.id.ib_sign_up_edit);
		ib_sign_up_edit.setOnClickListener(this);

		ImageView btn_save = (ImageView) findViewById(R.id.btn_save);
		btn_save.setOnClickListener(this);
		ImageView btn_close = (ImageView) findViewById(R.id.btn_cancel);
		btn_close.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});


		tv_profile_name.setText(m_UserInfoData.m_strName);
		if (m_UserInfoData.m_strUserType.equals("R"))
			tv_profile_team.setText(m_UserInfoData.m_strDepartment+" | "+m_UserInfoData.m_strCompanyName);
		else {
			tv_profile_team.setVisibility(View.GONE);
			et_profile_company.setVisibility(View.VISIBLE);
			et_profile_company.setText(m_UserInfoData.m_strAffiliation);

		}
		if(m_UserInfoData.m_strMobile.equals("-")){
			tv_profile_mobile.setText("");
		} else {
			tv_profile_mobile.setText(Utils.getPhoneNumberWithHyphen(m_UserInfoData.m_strMobile)); // 폰번호
		}
		if(m_UserInfoData.m_strEmail.equals("-")){
			tv_profile_email.setText("");
		} else {
			tv_profile_email.setText(m_UserInfoData.m_strEmail);
		}
		if (App.m_MyUserInfo.m_isImageAvailable)
			App.imageloader.getProfileImage(iv_pic, App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo, true), R.drawable.setting_pic_default_frame, false);
		else
			iv_pic.setImageResource(R.drawable.setting_pic_default_frame);

		et_profile_greeting.setText(m_UserInfoData.m_strGreeting);
		et_profile_greeting.setSelection(et_profile_greeting.length());
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM) {
				// Album에서 Image 선택후 Crop 실행
				m_isCamera = false;
				/*m_cropUri = data.getData();
				m_TakeMedia.doCropImageFromAlbumWithAspect(data.getData());*/

				Bundle extra = data.getBundleExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILELIST);
				ArrayList<GalleryListData> arrSelectedImage = (ArrayList<GalleryListData>)extra.getSerializable(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FILEARRAY);
				if(arrSelectedImage != null && arrSelectedImage.size() > 0)
				{
					GalleryListData galleryListData = arrSelectedImage.get(0);
					CommonLog.e(getClass(), "getDirName : " + galleryListData.getDirName());
					CommonLog.e(getClass(), "getDirPath : " + galleryListData.getDirPath());
					CommonLog.e(getClass(), "getSdcardPath : " + galleryListData.getSdcardPath());
					m_cropUri = Uri.fromFile(new File(galleryListData.getSdcardPath()));
					m_TakeMedia.doCropImageFromAlbumWithAspect(Uri.fromFile(new File(galleryListData.getSdcardPath())));
				}
			} else if (requestCode == TakeMediaIntent.REQUESTCODE_CAMERA) {
				// 카메라 촬영후 Crop 실행
				m_isCamera = true;
				m_cropUri = null;
				m_TakeMedia.doCropImageFromCameraWithAspect();
			} else if (requestCode == UCrop.REQUEST_CROP) {
				// Crop이 완료된 이미지를 가져옴
				m_isCrop = true;
				m_isUploadImage = true;
				Uri resulturi = UCrop.getOutput(data);
				m_BitmapByte = m_TakeMedia.getCropImageByte();
				m_Bitmap = m_TakeMedia.getCropImageBitmap();
				iv_pic.setImageBitmap(m_Bitmap);
			}
		} else {
			if (requestCode == TakeMediaIntent.REQUESTCODE_ALBUM || requestCode == TakeMediaIntent.REQUESTCODE_CAMERA
					|| requestCode == TakeMediaIntent.REQUESTCODE_CROP) {
				// 취소등에 의한 후처리 필요
				m_TakeMedia.deleteDirectory();
				m_TakeMedia = null;
			}
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		if (v.getId() == R.id.btn_save) {
			if (!AppSetting.FEATURE_VARIANT.equals("R") && et_profile_company.getText().toString().length() == 0) {
				m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_empty_company));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else if (et_profile_company.getText().toString().length() > 30) {
				m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_limit_company));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else if (et_profile_greeting.getText().toString().length() > 30) {
				m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_limit_greeting));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			} else if (et_profile_company.getText().toString().length() == 1) {
				m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_limit_twolenth));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			else {
				if (m_isUploadImage) {
					requestPostChangeImage(m_Bitmap, m_BitmapByte);
				} else {
					boolean isInEmoticon = false;

					int[] codeCount = StringUtil.toCodePointArray(et_profile_company.getText().toString());
					for(int i = 0; i < codeCount.length; i++){
						if(Character.charCount(codeCount[i]) > 1){
							isInEmoticon = true;
							break;
						}
					}
					if(isInEmoticon){
						m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.set_profile_emoticon_company));
						m_Popup.setCancelable(false);
						isCheckShowPopup();
					}

					else {
						requestPutChangeGreeting();
					}
				}
			}
		} else if (v.getId() == R.id.ib_sign_up_edit || v.getId() == R.id.iv_pic) {
			m_ListPopup = new CommonListPopup(SetProfileAct.this, SetProfileAct.this);
			if (App.m_MyUserInfo.m_isImageAvailable || m_isCrop)
				m_ListPopup.setBodyAndTitleText(getString(R.string.pic_edit_title).toString(), getResources().getStringArray(R.array.arr_pic_edit));
			else
				m_ListPopup.setBodyAndTitleText(getString(R.string.pic_edit_title).toString(), getResources().getStringArray(R.array.arr_pic_edit_noimage));
			m_ListPopup.setCancelable(false);
			m_ListPopup.show();

			// AlertDialog.Builder listBuilder = new AlertDialog.Builder(this);
			// if (App.m_MyUserInfo.m_isImageAvailable && !m_isCrop) {
			// listBuilder.setTitle(getString(R.string.pic_edit_title).toString());
			//
			// listBuilder.setItems(R.array.arr_pic_edit, new
			// DialogInterface.OnClickListener() {
			//
			// public void onClick(DialogInterface dialog, int item) {
			// if (item == 0) {
			// m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			// m_TakeMedia.doGetImageFromAlbum();
			// } else if (item == 1) {
			// m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			// m_TakeMedia.doTakeImageFromCamera();
			// } else if (item == 2) {
			// CommonLog.e("", "image edit 1");
			// Uri a_Uri = null;
			// m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			// if (m_isCrop) {
			// CommonLog.e("", "image edit isCrop");
			// a_Uri = Uri.fromFile(new
			// File(m_TakeMedia.getCropImageFilePath()));
			// } else {
			// CommonLog.e("", "image edit not isCrop");
			// FileCacheDBAdapter db = new
			// FileCacheDBAdapter(SetProfileAct.this);
			// db.openReadOnly();
			// String strFileName =
			// db.getFileCache(App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo,
			// true));
			// db.close();
			// File file = new
			// File(SetProfileAct.this.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES),
			// strFileName);
			// a_Uri = Uri.fromFile(new File(file.getPath()));
			//
			// }
			// if (a_Uri != null) {
			// CommonLog.e("", "image edit go doCropImage");
			// m_TakeMedia.doCropImage(a_Uri);
			// }
			// }
			// }
			// });
			// } else {
			// listBuilder.setTitle(getString(R.string.pic_edit_title).toString());
			//
			// listBuilder.setItems(R.array.arr_pic_edit_noimage, new
			// DialogInterface.OnClickListener() {
			//
			// public void onClick(DialogInterface dialog, int item) {
			// if (item == 0) {
			// m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			// m_TakeMedia.doGetImageFromAlbum();
			// } else if (item == 1) {
			// m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			// m_TakeMedia.doTakeImageFromCamera();
			// }
			// }
			// });
			// }
			// AlertDialog alertList = listBuilder.create();
			//
			// alertList.show();
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
				popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_SAVEGREETING) {
				App.imageloader.getProfileImage(iv_pic, App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo, true), R.drawable.profile_pic_default, true);
				popup_ok_long.cancel();
				setResult(Activity.RESULT_OK);
				finish();
			} else
				popup_ok_long.cancel();
		} else if (v.getId() == R.id.ib_pop_cancel_long) {
			m_ListPopup.cancel();
		} else if (v.getId() == R.id.tv_pop_first_row) {
			m_ListPopup.cancel();
			/*FileCacheDBAdapter db = new FileCacheDBAdapter(SetProfileAct.this);
			db.open();
			String strFileNameT = db.getFileCache(App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo, true));
			String strFileNameF = db.getFileCache(App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo, false));
			db.deleteFileCache(strFileNameT);
			db.deleteFileCache(strFileNameF);
			//db.deleteFileCache();
			db.close();*/
			m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			m_TakeMedia.doGetImageFromAlbum();
		} else if (v.getId() == R.id.tv_pop_second_row) {
			m_ListPopup.cancel();
			m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			m_TakeMedia.doTakeImageFromCamera();
		} else if (v.getId() == R.id.tv_pop_third_row) {
			m_ListPopup.cancel();
			Uri a_Uri = null;
			m_TakeMedia = new TakeMediaIntent(SetProfileAct.this);
			if (m_isCrop) {
				CommonLog.e("", "image edit isCrop");
				if(m_cropUri == null && !m_isCamera) {
					a_Uri = Uri.fromFile(new File(m_TakeMedia.getCropImageFilePath()));
				} else if(m_cropUri == null && m_isCamera){
					m_TakeMedia.doCropImageFromCameraWithAspect();
					return;
				}
				else if(m_cropUri != null && !m_isCamera){
					a_Uri = m_cropUri;
				}
			} else {
				CommonLog.e("", "image edit not isCrop");
				/*FileCacheDBAdapter db = new FileCacheDBAdapter(SetProfileAct.this);
				db.openReadOnly();
				String strFileName = db.getFileCache(App.getImageDownLoaderUrl(App.m_MyUserInfo.m_nUserNo, true));
				db.close();
				File file = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES).getPath(), strFileName);

				a_Uri = Uri.fromFile(new File(file.getPath()));*/
				Bitmap bmp = ((BitmapDrawable)iv_pic.getDrawable()).getBitmap();
				ByteArrayOutputStream bytes = new ByteArrayOutputStream();
				bmp.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
				String path = MediaStore.Images.Media.insertImage(getContentResolver(), bmp, "Title", null);
				a_Uri = Uri.parse(path);
				m_cropUri = a_Uri;
			}
			if (a_Uri != null) {
				CommonLog.e("", "image edit go doCropImage");
				m_TakeMedia.doCropImage(a_Uri, true);
			}
		}
	}

	private void requestGetUserInfo() {
		showProgress();
		GetUserInfoReq req = new GetUserInfoReq(App.m_EntryData.m_nUserNo);
		WebAPI webApi = new WebAPI(SetProfileAct.this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_INFO);

				if (res.getUserInfoDatas() != null) {
					m_UserInfoData = res.getUserInfoDatas().get(0);

					setProfileUI();
				}
				closeProgress();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	// 이미지 전송
	public void requestPostChangeImage(final Bitmap a_Bitmap, byte[] a_BitmapByte) {
		showProgress();
		PostChangeImageReq req = new PostChangeImageReq(App.m_MyUserInfo.m_nUserNo);
		req.setFileData(a_BitmapByte);

		WebAPI webApi = new WebAPI(this);
		webApi.requestUpload(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String strData) {
				// TODO Auto-generated method stub
				closeProgress();
				App.m_MyUserInfo.m_isImageAvailable = true;
				requestPutChangeGreeting();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}  else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	// 인사말 변경
	public void requestPutChangeGreeting() {
		showProgress();

		PutChangeGreetingReq req = new PutChangeGreetingReq(et_profile_greeting.getText().toString(), et_profile_company.getText().toString());	
		
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String strData) {
				// TODO Auto-generated method stub
				closeProgress();
				UserListData data = TTalkDBManager.ContactsDBManager.getContacts(SetProfileAct.this, App.m_MyUserInfo.m_nUserNo);
				data.m_strGreeting = et_profile_greeting.getText().toString();
				App.m_MyUserInfo.m_strGreeting = et_profile_greeting.getText().toString();
				if(App.m_MyUserInfo.m_strUserType.equals(StaticString.VARIANT_PARTNER)) {
					App.m_MyUserInfo.m_strAffiliation = et_profile_company.getText().toString();
					data.m_PersonalData.mapPersonalData.put(PersonalData.AFFILIATION, et_profile_company.getText().toString());
				}
				m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
						PopupIndex.INDEX_PREVPOPUP_SAVEGREETING);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.set_profile_save_success).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if (a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if (a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE) {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES,
							PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else {
					m_Popup = new CommonPopup(SetProfileAct.this, SetProfileAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}

	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
}
