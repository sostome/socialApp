package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class GetPCClientAuthKeyRes extends Res{
	
	private final String JSON_AUTHTOKEN 			= "authToken";
	private final String JSON_CREATEDATE 			= "createdDate";
	private final String JSON_REMAINING				= "remaining";
	
	private String m_strAuthToken = "";
	private String m_strCreateDate = "";
	private int m_nRemaining = 0;
	
	public GetPCClientAuthKeyRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			m_strAuthToken = jsonRoot.getString(JSON_AUTHTOKEN);
			m_strCreateDate = jsonRoot.getString(JSON_CREATEDATE);
			m_nRemaining = jsonRoot.getInt(JSON_REMAINING);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getAuthToken()
	{
		return m_strAuthToken;
	}
	
	public String getCreateDate()
	{
		return m_strCreateDate;
	}
	
	public int getRemaining()
	{
		return m_nRemaining;
	}
}
