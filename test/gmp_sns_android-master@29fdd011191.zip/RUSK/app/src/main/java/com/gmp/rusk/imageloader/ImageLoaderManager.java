package com.gmp.rusk.imageloader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.text.TextUtils;
import android.widget.ImageView;

import com.gmp.rusk.utils.CommonLog;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;

public class ImageLoaderManager implements ImageDownloadCompleteListener{
	
	public interface ImageLoaderListener
	{
		public void onSuccess();
		public void onFail(String a_strErrorMsg);
		public void onNotModified();
	}
	
	private static ImageLoaderManager m_Instance = null;
	private ImageDownloader m_ImageDownloader = new ImageDownloader(this);
	
	private Context m_Context = null;
	
	private HashMap<String, ImageLoaderListener> m_mapImageLoaderListener = new LinkedHashMap<String, ImageLoaderListener>();
	private HashMap<String, Long> m_mapLastDownloadTime = new LinkedHashMap<String, Long>();
	private final int LASTDOWNLOAD_TERM = 1000 * 60 * 60 * 6;	// 6 시간

	public static ImageLoaderManager getInstance(Context a_Context)
	{
		if(m_Instance == null)
			m_Instance = new ImageLoaderManager(a_Context);
		else
			m_Instance.setContext(a_Context);
		
		return m_Instance;
	}
	
	private ImageLoaderManager(Context a_Context)
	{
		m_Context = a_Context;
	}
	
	private void setContext(Context a_Context)
	{
		m_Context = a_Context;
	}
	
	public void cancelDownload(ImageView a_ivImageView)
	{
		m_ImageDownloader.cancelDownload(a_ivImageView);
	}
	
	public Bitmap getLocalImage(String a_strUrl)
	{
		Bitmap bmp = null;
		bmp = getBitmapFromCache(a_strUrl);
		if(bmp != null)
			return bmp;
		
		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
		db.openReadOnly();
		String strFileName = db.getFileCache(a_strUrl);
		db.close();
		
		if(!TextUtils.isEmpty(strFileName))
		{
			// File Load And Set Image
			File file = new File(m_Context.getFilesDir(), strFileName);
			if(file != null && file.exists())
			{
				bmp = readImageFile(file);
				if(bmp != null)
					addBitmapToCache(a_strUrl, bmp);
			}
		}
		
		return bmp;
	}
	
	public Bitmap getLocalRoundImage(String a_strUrl)
	{
		Bitmap bmp = null;
		bmp = getBitmapFromCache(a_strUrl);
		if(bmp != null)
			return roundImage(bmp);
		
		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
		db.openReadOnly();
		String strFileName = db.getFileCache(a_strUrl);
		db.close();

		if(!TextUtils.isEmpty(strFileName))
		{
			// File Load And Set Image
			File file = new File(m_Context.getFilesDir(), strFileName);
			if(file != null && file.exists())
			{
				bmp = readImageFile(file);
				if(bmp != null)
				{
					addBitmapToCache(a_strUrl, bmp);
					bmp = roundImage(bmp);
				}
			}
		}
		
		return bmp;
	}
	
	public void getProfileImage(ImageView a_ivImage, String a_strUrl, int a_nResId, boolean a_isForceDownload)
	{
		//CommonLog.e("aaa", "ImageLoader Test : ----------------------------------");
		if(a_isForceDownload)
		{
			imageDownload(a_ivImage, a_strUrl, false);
		}
		else
		{
			
			
			Bitmap bmpCache = getBitmapFromCache(a_strUrl);

			Long lnLastDownload = m_mapLastDownloadTime.get(a_strUrl);
			Long lnCurrent = System.currentTimeMillis();

			if(bmpCache != null && lnLastDownload != null && lnLastDownload + LASTDOWNLOAD_TERM > lnCurrent){
				a_ivImage.setImageBitmap(bmpCache);
				//CommonLog.e("aaa", "ImageLoader Test : In Cache!");
				return;
			}
			else
				a_ivImage.setImageResource(a_nResId);
			
			//CommonLog.e("aaa", "ImageLoader Test : No Cache!");

			if(bmpCache == null || lnLastDownload == null || lnLastDownload + LASTDOWNLOAD_TERM < lnCurrent)
			{
				imageDownload(a_ivImage, a_strUrl, false);
				//CommonLog.e("aaa", "ImageLoader Test : Download");

			}
//			
//			FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
//			db.openReadOnly();
//			String strFileName = db.getFileCache(a_strUrl);
//			db.close();
//			
//			Bitmap bmp = null;
//			
//			if(!TextUtils.isEmpty(strFileName))
//			{
//				// File Load And Set Image
//				File file = new File(m_Context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), strFileName);
//				if(file != null && file.exists())
//				{
//					bmp = readImageFile(file);
//					if(bmp != null)
//					{
//						addBitmapToCache(a_strUrl, bmp);
//						bmp = roundImage(bmp);
//						a_ivImage.setImageBitmap(bmp);
//						CommonLog.e("aaa", "ImageLoader Test : In File!");
//						return;
//					}
//				}
//			}
			
			
		}
	}
	
	public Bitmap getImage(String a_strUrl, int a_nDefaultResId)
	{
		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
		db.openReadOnly();
		String strFileName = db.getFileCache(a_strUrl);
		db.close();
		
		Bitmap bmp = null;
		if(TextUtils.isEmpty(strFileName))
		{
			// Default Image Set
			bmp = ResourceToBitmap(a_nDefaultResId);
		}
		else
		{
			bmp = getBitmapFromCache(a_strUrl);
			if(bmp == null)
			{
				// File Load And Set Image
				File file = new File(m_Context.getFilesDir(), strFileName);
				if(file == null || !file.exists())
				{
					// Default Image Set
					bmp = ResourceToBitmap(a_nDefaultResId);
				}
				else
				{
					bmp = readImageFile(file);
					if(bmp == null)
						bmp = ResourceToBitmap(a_nDefaultResId);
					else
						addBitmapToCache(a_strUrl, bmp);
				}
			}
		}
		
		return bmp;
	}
	
	public void getImage(ImageView a_ivImage, String a_strUrl, int a_nResId)
	{
		Bitmap bmpCache = getBitmapFromCache(a_strUrl);
		if(bmpCache != null)
			a_ivImage.setImageBitmap(bmpCache);
		else
			a_ivImage.setImageResource(a_nResId);
			
		imageDownload(a_ivImage, a_strUrl, false);
//		else
//		{
//			FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
//			db.openReadOnly();
//			String strFileName = db.getFileCache(a_strUrl);
//			db.close();
//			
//			String strIfModifiedSince = "";
//			
//			if(TextUtils.isEmpty(strFileName))
//			{
//				// Default Image Set
//				setDafaultImage(a_ivImage, a_nResId);
//			}
//			else
//			{
//				// File Load And Set Image
//				File file = new File(m_Context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), strFileName);
//				if(file == null || !file.exists())
//				{
//					// Default Image Set
//					setDafaultImage(a_ivImage, a_nResId);
//				}
//				else
//				{
//					Bitmap bmp = readImageFile(file);
//					if(bmp != null)
//					{
//						strIfModifiedSince = "" + file.lastModified();
//						a_ivImage.setImageBitmap(bmp);
//						addBitmapToCache(a_strUrl, bmp);
//					}
//					else
//						setDafaultImage(a_ivImage, a_nResId);
//				}
//			}
//			
//			// Download 수행
//			m_ImageDownloader.download(a_strUrl, a_ivImage);
//		}
	}
	
	public void getImageRound(ImageView a_ivImage, String a_strUrl, int a_nResId)
	{
		
		Bitmap bmpCache = getBitmapFromCache(a_strUrl);
		if(bmpCache != null)
		{
			a_ivImage.setImageBitmap(roundImage(bmpCache));
			
//			GetImageTask task = new GetImageTask(a_ivImage, a_strUrl);
//			task.execute();
//			imageDownload(a_ivImage, a_strUrl);
		}
		else{
			a_ivImage.setImageBitmap(null);
		}
		
		imageDownload(a_ivImage, a_strUrl, true);
//		else
//		{
//			FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
//			db.openReadOnly();
//			String strFileName = db.getFileCache(a_strUrl);
//			db.close();
//			
//			String strIfModifiedSince = "";
//			
//			if(TextUtils.isEmpty(strFileName))
//			{
//				// Default Image Set
//				setDafaultImage(a_ivImage, a_nResId);
//			}
//			else
//			{
//				// File Load And Set Image
//				File file = new File(m_Context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), strFileName);
//				if(file == null || !file.exists())
//				{
//					// Default Image Set
//					setDafaultImage(a_ivImage, a_nResId);
//				}
//				else
//				{
//					Bitmap bmp = readImageFile(file);
//					if(bmp != null)
//					{
//						strIfModifiedSince = "" + file.lastModified();
//						
//
//				        Bitmap output = Bitmap.createBitmap(bmp.getWidth(), bmp
//				                .getHeight(), Config.ARGB_8888);
//				        Canvas canvas = new Canvas(output);
//
//				        final int color = 0xff424242;
//				        final Paint paint = new Paint();
//				        final Rect rect = new Rect(0, 0, bmp.getWidth(), bmp.getHeight());
//				        final RectF rectF = new RectF(rect);
//				        final float roundPx = 30;
//
//				        paint.setAntiAlias(true);
//				        canvas.drawARGB(0, 0, 0, 0);
//				        paint.setColor(color);
//				        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
//
//				        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
//				        canvas.drawBitmap(bmp, rect, rect, paint);
//				        
//						a_ivImage.setImageBitmap(output);
//						addBitmapToCache(a_strUrl, output);
//					}
//					else
//						setDafaultImage(a_ivImage, a_nResId);
//				}
//			}
//			// Download 수행
//			m_ImageDownloader.download(a_strUrl, a_ivImage, strIfModifiedSince);
//			m_ImageDownloader.download(a_strUrl, a_ivImage);
//		}
	}
	
	public void getImageRoundMine(ImageView a_ivImage, String a_strUrl, int a_nResId)
	{
		
		Bitmap bmpCache = getBitmapFromCache(a_strUrl);
		if(bmpCache != null)
		{
			a_ivImage.setImageBitmap(roundImage(bmpCache));
		}
		else{
			a_ivImage.setImageResource(a_nResId);
			imageDownload(a_ivImage, a_strUrl, true);
			
		}
	}
	
	public void getImageRoundBeforeSend(ImageView a_ivImage, String a_strUri, int a_nWidth, int a_nHeight)
	{

		Bitmap bmp = BitmapFactory.decodeFile(Uri.fromFile(new File(a_strUri)).getPath());
		int height = a_nWidth;
		int width = a_nHeight;
		
		Bitmap resizedBmp = null;

		if(height == 0 || width == 0){
			height = 1;
			width = 1;
		}
		if (width >= height) {
			height = (height * 290) / width;
			width = 290;
		} else if (width < height) {
			width = (width * 290) / height;
			height = 290;
		}
		
		if(bmp != null)
		{
			resizedBmp = Bitmap.createScaledBitmap(bmp, width, height, true);
		    a_ivImage.setImageBitmap(roundImage(resizedBmp));
		}

	}
	public void getImage(ImageView a_ivImage, String a_strUrl, int a_nResId, ImageLoaderListener a_ImageLoaderListener)
	{
		m_mapImageLoaderListener.put(a_strUrl, a_ImageLoaderListener);
		getImage(a_ivImage, a_strUrl, a_nResId);
	}
	
	public void getImageRound(ImageView a_ivImage, String a_strUrl, int a_nResId, ImageLoaderListener a_ImageLoaderListener)
	{
		m_mapImageLoaderListener.put(a_strUrl, a_ImageLoaderListener);
		getImageRound(a_ivImage, a_strUrl, a_nResId);
	}
	
	public void getImageRoundMine(ImageView a_ivImage, String a_strUrl, int a_nResId, ImageLoaderListener a_ImageLoaderListener)
	{
		m_mapImageLoaderListener.put(a_strUrl, a_ImageLoaderListener);
		getImageRoundMine(a_ivImage, a_strUrl, a_nResId);
	}
	
	private void setDafaultImage(ImageView a_ivImage, int a_nResId)
	{
		if(a_nResId > 0)
			a_ivImage.setImageResource(a_nResId);
	}
	
	private Bitmap readImageFile(File a_fileImage)
	{
		return BitmapFactory.decodeFile(a_fileImage.getPath());
	}
	
	private Bitmap ResourceToBitmap(int a_nRedId)
	{
		return BitmapFactory.decodeResource(m_Context.getResources(), a_nRedId);
	}

	@Override
	public void onComplete(String a_strUrl, Bitmap a_bmpImage) {
		// TODO Auto-generated method stub
		// Save File And Update DB
		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
		db.open();
		
		String strFileName = db.getFileCache(a_strUrl);
		if(TextUtils.isEmpty(strFileName))
		{
			String[] arrUrl = a_strUrl.split("/");
			strFileName = arrUrl[arrUrl.length - 1];
			db.insertFileCache(a_strUrl, strFileName);
		}
		
		File fileImage = new File(m_Context.getFilesDir(), strFileName);
		FileOutputStream fos = null;
		try
		{
			fos = new FileOutputStream(fileImage);
			a_bmpImage.compress(CompressFormat.JPEG, 100, fos);
			addBitmapToCache(a_strUrl, a_bmpImage);
		}
		catch(IOException e)
		{
//			e.printStackTrace();
		}
		catch(Exception e)
		{
//			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(fos != null)
					fos.close();
			}
			catch(IOException e)
			{
//				e.printStackTrace();
			}
		}
		
		db.close();
		
		m_mapLastDownloadTime.put(a_strUrl, System.currentTimeMillis());
		
		ImageLoaderListener imageLoaderListener = m_mapImageLoaderListener.get(a_strUrl);
		if(imageLoaderListener != null)
		{
			imageLoaderListener.onSuccess();
			m_mapImageLoaderListener.remove(a_strUrl);
		}
	}
	
	@Override
	public void onFail(String a_strUrl, int a_nErrorCode, String a_strErrorMsg) {
		// TODO Auto-generated method stub
		if(a_nErrorCode == 404)
		{
			CommonLog.e(ImageLoaderManager.class.getSimpleName(), "onFail ErrorCode 404");
			m_mapLastDownloadTime.put(a_strUrl, System.currentTimeMillis());
		}
		
		ImageLoaderListener imageLoaderListener = m_mapImageLoaderListener.get(a_strUrl);
		if(imageLoaderListener != null)
		{
			imageLoaderListener.onFail(a_strErrorMsg);
			m_mapImageLoaderListener.remove(a_strUrl);
		}
	}
	
	@Override
	public void onNotModified(String a_strUrl, Bitmap a_bmp) {
		// TODO Auto-generated method stub
		m_mapLastDownloadTime.put(a_strUrl, System.currentTimeMillis());
		if(a_bmp != null)
			addBitmapToCache(a_strUrl, a_bmp);
		
		ImageLoaderListener imageLoaderListener = m_mapImageLoaderListener.get(a_strUrl);
		if(imageLoaderListener != null)
		{
			imageLoaderListener.onNotModified();
			m_mapImageLoaderListener.remove(a_strUrl);
		}
	}
	
	private void imageDownload(ImageView a_ivImage, String a_strUrl, boolean a_isRounding)
	{
//		FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
//		db.openReadOnly();
//		String strFileName = db.getFileCache(a_strUrl);
//		db.close();
//		
//		String strIfModifiedSince = "";
//		
//		if(!TextUtils.isEmpty(strFileName))
//		{
//			// File Load And Set Image
//			File file = new File(m_Context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), strFileName);
//			if(file != null && file.exists())
//			{
//				strIfModifiedSince = "" + file.lastModified();
//			}
//		}
		
//		m_ImageDownloader.download(a_strUrl, a_ivImage, strIfModifiedSince);
		m_ImageDownloader.download(a_strUrl, a_ivImage, a_isRounding);
	}
	
	private Bitmap roundImage(Bitmap a_bmpOriginal)
	{
		Bitmap bmpRounding = Bitmap.createBitmap(a_bmpOriginal.getWidth(), a_bmpOriginal
                .getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(bmpRounding);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, a_bmpOriginal.getWidth(), a_bmpOriginal.getHeight());
        final RectF rectF = new RectF(rect);
		//Cork에서는 이미지가 round처리가 아닌 사각형이라 30 -> 0 으로 변경
        final float roundPx = 0;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
        canvas.drawBitmap(a_bmpOriginal, rect, rect, paint);
		return bmpRounding;
	}
	
//	private class GetImageTask extends AsyncTask<String, Void, String>
//	{
//		private ImageView m_ivImage;
//		private String m_strUrl;
//		public GetImageTask(ImageView a_ivImage, String a_strUrl)
//		{
//			m_ivImage = a_ivImage;
//			m_strUrl = a_strUrl;
//		}
//
//		@Override
//		protected String doInBackground(String... params) {
//			// TODO Auto-generated method stub
//			
//			FileCacheDBAdapter db = new FileCacheDBAdapter(m_Context);
//			db.openReadOnly();
//			String strFileName = db.getFileCache(m_strUrl);
//			db.close();
//			
//			String strIfModifiedSince = "";
//			
//			if(!TextUtils.isEmpty(strFileName))
//			{
//				// File Load And Set Image
//				File file = new File(m_Context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), strFileName);
//				if(file != null && file.exists())
//				{
//					strIfModifiedSince = "" + file.lastModified();
//				}
//			}
//
//			return strIfModifiedSince;
//		}
//		
//		@Override
//		protected void onPostExecute(String result) {
//			// TODO Auto-generated method stub
//			m_ImageDownloader.download(m_strUrl, m_ivImage, result);
//			super.onPostExecute(result);
//		}
//	}
	
    private static final int HARD_CACHE_CAPACITY = 20;

    // Hard cache, with a fixed maximum capacity and a life duration
    public final static HashMap<String, Bitmap> sHardBitmapCache =
        new LinkedHashMap<String, Bitmap>(HARD_CACHE_CAPACITY / 2, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(LinkedHashMap.Entry<String, Bitmap> eldest) {
            if (size() > HARD_CACHE_CAPACITY) {
                // Entries push-out of hard reference cache are transferred to soft reference cache
                sSoftBitmapCache.put(eldest.getKey(), new SoftReference<Bitmap>(eldest.getValue()));
                return true;
            } else
                return false;
        }
    };

    // Soft cache for bitmaps kicked out of hard cache
    private final static ConcurrentHashMap<String, SoftReference<Bitmap>> sSoftBitmapCache =
        new ConcurrentHashMap<String, SoftReference<Bitmap>>(HARD_CACHE_CAPACITY / 2);
    /**
     * Adds this bitmap to the cache.
     * @param bitmap The newly downloaded bitmap.
     */
    public static void addBitmapToCache(String url, Bitmap bitmap) {
        if (bitmap != null) {
            synchronized (sHardBitmapCache) {
                sHardBitmapCache.put(url, bitmap);
            }
        }
    }

    /**
     * @param url The URL of the image that will be retrieved from the cache.
     * @return The cached bitmap or null if it was not found.
     */
    public Bitmap getBitmapFromCache(String url) {
        // First try the hard reference cache
        synchronized (sHardBitmapCache) {
            final Bitmap bitmap = sHardBitmapCache.get(url);
            if (bitmap != null) {
                // Bitmap found in hard cache
                // Move element to first position, so that it is removed last
                sHardBitmapCache.remove(url);
                sHardBitmapCache.put(url, bitmap);
                return bitmap;
            }
        }

        // Then try the soft reference cache
        SoftReference<Bitmap> bitmapReference = sSoftBitmapCache.get(url);
        if (bitmapReference != null) {
            final Bitmap bitmap = bitmapReference.get();
            if (bitmap != null) {
                // Bitmap found in soft cache
                return bitmap;
            } else {
                // Soft reference has been Garbage Collected
                sSoftBitmapCache.remove(url);
            }
        }
        return null;
    }
}
