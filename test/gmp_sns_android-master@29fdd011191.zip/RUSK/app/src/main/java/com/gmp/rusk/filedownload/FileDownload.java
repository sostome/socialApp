package com.gmp.rusk.filedownload;

import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Base64;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.apache.http.HttpStatus;
import org.apache.http.conn.ssl.StrictHostnameVerifier;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class FileDownload {

	public MyApp App = MyApp.getInstance();

	public interface OnDownloadComplete{
		public void onComplete(String a_strFilePath);
		public void onDownloadFail();
		public void onProgess(int a_nCount, int a_nTotal);
		public void onStart();
	}
	
	private Context m_Context = null;
	
	private String m_strRoomId = "";
	private String m_strMsgId = "";
	private String m_strUrl = "";
	
	private OnDownloadComplete m_OnDownloadComplete = null;
	private FileDownloadTask m_DownloadTask = null;
	
	private final String SNS_PREFIX = "SNS_";
	
	private boolean m_isSaveTTalkFolder = true;
	private boolean m_isVcard = false;
	
	public FileDownload(Context a_Context, String a_strUrl)
	{
		m_Context = a_Context;
		m_strUrl = a_strUrl;
	}
	
	public FileDownload(Context a_Context, String a_strRoomId, String a_strMsgId, String a_strUrl)
	{
		m_Context = a_Context;
		m_strRoomId = a_strRoomId;
		m_strMsgId = a_strMsgId;
		m_strUrl = Utils.encodingUrl(a_strUrl);
	}
	
	public FileDownload(Context a_Context, String a_strRoomId, String a_strMsgId, String a_strUrl, boolean a_isVcard)
	{
		m_Context = a_Context;
		m_strRoomId = a_strRoomId;
		m_strMsgId = a_strMsgId;
		m_strUrl = Utils.encodingUrl(a_strUrl);
		m_isVcard = a_isVcard;
	}
	
	public FileDownload(Context a_Context, int a_nGroupId, int a_nFileId, String a_strUrl, boolean a_isSaveTTalkFolder)
	{
		// Prefix
		m_Context = a_Context;
		m_strRoomId = SNS_PREFIX + a_nGroupId;
		m_strMsgId = SNS_PREFIX + a_nFileId;
		m_strUrl = Utils.encodingUrl(a_strUrl);
		m_isSaveTTalkFolder = a_isSaveTTalkFolder;
	}
	
	public void startDownload(OnDownloadComplete a_OnDownloadComplate)
	{
		m_OnDownloadComplete = a_OnDownloadComplate;
		m_handlerDownload.sendEmptyMessage(HANDLER_WHAT_DOWNLOAD);
	}
	
	public void stopDownload()
	{
		m_handlerDownload.removeMessages(HANDLER_WHAT_DOWNLOAD);
		if(m_DownloadTask != null)
			m_DownloadTask.cancel(true);
		
		m_OnDownloadComplete = null;
	}
	
	public void startBackUpDownload(OnDownloadComplete a_OnDownloadComplate)
	{
		m_OnDownloadComplete = a_OnDownloadComplate;
		m_DownloadTask = new FileDownloadTask();
		m_DownloadTask.execute(m_strUrl);
	}
	private String downloadFile(String a_strUrl)
	{
		String strTempUrl = a_strUrl.trim();
		if(strTempUrl.equals(""))
			return null;
    	
		String strFilePath = "";
    	
    	try
	    {
			//WebAPI.trustAllHosts();
	        URL connectUrl = new URL(a_strUrl);
			HttpsURLConnection con = null;
			
			HttpsURLConnection https = (HttpsURLConnection) connectUrl.openConnection();
			
			https.setHostnameVerifier(new StrictHostnameVerifier());
			//https.setHostnameVerifier(WebAPI.DO_NOT_VERIFY);

			con = https;			
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Connection", "close");
			
			//headerSet
			con.setRequestProperty("X-Device-OS", "A");
			con.setRequestProperty("Accept-Language", App.m_strLocale);
			con.setRequestProperty("X-Device-OS-Version", Utils.getBuildOSVersion());	
			con.setRequestProperty("X-Device-Model", Utils.getBuildModel());
			con.setRequestProperty("X-Device-Vender", Utils.getBuildManufacturer());
			
			TelephonyManager tm = (TelephonyManager)App.getInstance().getSystemService(Context.TELEPHONY_SERVICE);
			
			//if(!AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
				con.setRequestProperty("X-Device-UID", tm.getDeviceId());
			
			
			con.setRequestProperty("X-App-Version", Utils.getApplicationVersion(App.getInstance()));
			if(AppSetting.FEATURE_VARIANT.equals("S"))
				con.setRequestProperty("X-App-Variant", StaticString.VARIANT_PARTNER);
			else
				con.setRequestProperty("X-App-Variant", AppSetting.FEATURE_VARIANT);
			
			String strPartnerID = App.m_PartnerID;
			SharedPref pref = SharedPref.getInstance(App.getInstance());
			
			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
			{
				// 정직원
				con.setRequestProperty("Authorization", "GMP " + Base64.encodeToString((App.m_GMPData.m_strCompanyCode+"."+App.m_GMPData.m_strRegularID+":"+App.m_GMPData.m_strAuthKey).getBytes(), Base64.NO_WRAP));
				con.setRequestProperty("Authorization-Mdn", App.m_Mdn);
			}
			else if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
			{
				// 파트너
				con.setRequestProperty("Authorization", "Basic " + Base64.encodeToString((strPartnerID+":"+App.m_PartnerPW).getBytes(), 0));
			}
			
			System.setProperty("http.keepAlive", "false");
	        
			con.setRequestProperty("Cookie", pref.getStringPref(SharedPref.PREF_COOKIE, ""));
			
			con.setRequestMethod("GET");
			con.setDoInput(true);
			
			con.setDefaultUseCaches(false);
			
			if (con.getResponseCode() == HttpStatus.SC_OK)
			{
				InputStream inputStream = null;
				FileOutputStream fos = null;
				
	            try {
	            	inputStream = con.getInputStream();
	            	
	            	int nLength = (int)con.getContentLength();
					int nRead;
					byte[] tmpByte = new byte[nLength];
					
					String strFileDirectory = m_Context.getFilesDir().getAbsolutePath();
					/*if(m_isVcard)
						strFileDirectory = m_Context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getPath();
					else
					{
						if(m_isSaveTTalkFolder)
							strFileDirectory = Environment.getExternalStorageDirectory() + m_Context.getString(R.string.takepicture_save_directory);
						else
							strFileDirectory = m_Context.getExternalFilesDir(Environment.DIRECTORY_MOVIES).getPath();
					}*/
					
					String[] strsSplitUrl = m_strUrl.split("/");
					String strFileName = strsSplitUrl[strsSplitUrl.length - 1] ;
					File file = new File(strFileDirectory, strFileName);
					file.setReadable(true);
	                fos = new FileOutputStream(file);
	                int nDownloadCount = 0;
	                for (;;) {  
	                	nRead = inputStream.read(tmpByte);
	                	nDownloadCount += nRead;
	                    if (nRead <= 0) {  
	                        break;  
	                    }  
	                    fos.write(tmpByte, 0, nRead);  
	                    if(m_DownloadTask.isCancelled())
	                    {
	                    	break;
	                    }
	                    m_DownloadTask.setProgress(nDownloadCount, nLength);
	                }    
	                
	                if(!m_DownloadTask.isCancelled())
	                {
		                strFilePath = file.getPath();
		                insertFileDownload(strFilePath);
	                }
	            } finally {
	                if (inputStream != null)
	                    inputStream.close();
	                
	                if(fos != null)
						fos.close();
	                
	                con.disconnect();
	            }
			}
	    }
    	catch (IOException e) {
        	e.printStackTrace();
        } catch (IllegalStateException e) {
        	e.printStackTrace();
        } catch (Exception e) {
        	e.printStackTrace();
        }finally {
        }
    	
    	return strFilePath;
	}
	
	private String checkFileDownload()
	{
		String strFilePath = null;
		FileDownloadDBAdapter db = new FileDownloadDBAdapter(m_Context);
		db.openReadOnly();
		
		Cursor cursor = db.getFileDownload(m_strRoomId, m_strMsgId);
		
		if(cursor.moveToFirst())
		{
			strFilePath = cursor.getString(cursor.getColumnIndex(FileDownloadDBAdapter.KEY_FILEDOWNLOAD_FILEPATH));
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				strFilePath = crypto.decrypt(strFilePath);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		cursor.close();
		db.close();
		
		return strFilePath;
	}
	
	private void insertFileDownload(String a_strFilePath)
	{
		FileDownloadDBAdapter db = new FileDownloadDBAdapter(m_Context);
		db.open();
		db.insertRoom(m_strRoomId, m_strMsgId, a_strFilePath);
		db.close();
	}
	
	private void deleteFileDownloadDB()
	{
		FileDownloadDBAdapter db = new FileDownloadDBAdapter(m_Context);
		db.open();
		db.deleteFileDownload(m_strRoomId, m_strMsgId);
		db.close();
	}
	
	private byte[] readFile(String a_strFilePath)
	{
		byte[] fileData = null;
		File file = new File(a_strFilePath);
		
		try {
			FileInputStream isFile = new FileInputStream(file);
			int nCount = isFile.available();
			if(nCount > 0)
			{
				fileData = new byte[nCount];
				isFile.read(fileData);
			}
			if(isFile != null)
			{
				isFile.close();
			}
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return fileData;
	}
	
	private final int HANDLER_WHAT_DOWNLOAD = 0;
	private Handler m_handlerDownload = new Handler()
	{
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			if(msg.what == HANDLER_WHAT_DOWNLOAD)
			{
				String strFilePath = checkFileDownload();
				if(!TextUtils.isEmpty(strFilePath))
				{
					byte[] readData = readFile(strFilePath);
					if(readData != null && readData.length > 0)
					{
						m_OnDownloadComplete.onComplete(strFilePath);
					}
					else
					{
						deleteFileDownloadDB();
						m_DownloadTask = new FileDownloadTask();
						m_DownloadTask.execute(m_strUrl);
					}
				}
				else
				{
					m_DownloadTask = new FileDownloadTask();
					m_DownloadTask.execute(m_strUrl);
				}
			}
			super.handleMessage(msg);
		}
	};
	
	private class FileDownloadTask extends AsyncTask<String, Integer, String>
	{
		@Override
		protected void onCancelled() {
			// TODO Auto-generated method stub
			super.onCancelled();
		}
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			if(m_OnDownloadComplete != null)
				m_OnDownloadComplete.onStart();
		}
		
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			return downloadFile(params[0]);
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			if(m_OnDownloadComplete != null)
			{
				if(!TextUtils.isEmpty(result))
					m_OnDownloadComplete.onComplete(result);
				else
					m_OnDownloadComplete.onDownloadFail();
			}
			
			super.onPostExecute(result);
		}
		
		@Override
		protected void onProgressUpdate(Integer... values) {
			// TODO Auto-generated method stub
			int nCount = values[0];
			int nTotal = values[1];
			if(m_OnDownloadComplete != null)
				m_OnDownloadComplete.onProgess(nCount, nTotal);
			
			super.onProgressUpdate(values);
		}
				
		public void setProgress(int a_nCount, int a_nTotal)
		{
			publishProgress(a_nCount, a_nTotal);
		}
	}

}
