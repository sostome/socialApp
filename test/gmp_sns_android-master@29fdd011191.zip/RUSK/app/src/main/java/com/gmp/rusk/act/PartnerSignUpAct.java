package com.gmp.rusk.act;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetPartnerIdRedundancyCheckReq;
import com.gmp.rusk.request.PostBecomePartnerReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.StringUtil;
import com.gmp.rusk.utils.Utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PartnerSignUpAct
 * @author subi78
 * 파트너 및 가사번 회원가입 Activity
 */
public class PartnerSignUpAct extends Activity implements OnClickListener {

	public MyApp App = MyApp.getInstance();
	private boolean m_isPartner = true;
	private String m_strUserId = "";
	
	private int m_nApprovalUserNo = 0;
	private String m_strApprovalUserName = "";
	
	EditText et_partner_signup_id;
	EditText et_partner_signup_pw;
	EditText et_partner_signup_re_pw;
	EditText et_partner_signup_name;
	EditText et_partner_signup_company;
	EditText et_partner_signup_email;
	TextView tv_partner_signup_mobile;
	TextView tv_partner_signup_approval;
	
	private ProgressDlg m_Progress = null;
	
	private CommonPopup m_Popup = null;
	
	private String m_strUserIdCheck = "";
	private boolean m_isUserIdCheck = false;
	public boolean m_isRunning = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_partner_signup);
		
		
		// data 가져 오는 부분 구현
		Bundle bundle = getIntent().getExtras();
		
		if (bundle != null)
		{
			m_isPartner = bundle.getBoolean(IntentKeyString.INTENT_KEY_USERID_TYPE,true);
			if(!m_isPartner)
				m_strUserId = bundle.getString(IntentKeyString.INTENT_KEY_USERID_ID);
			m_nApprovalUserNo = bundle.getInt(IntentKeyString.INTENT_KEY_USERID_APPROVAL_USERNO);
			m_strApprovalUserName = bundle.getString(IntentKeyString.INTENT_KEY_USERID_APPROVAL_USERNAME);
			
		}
		
		setSignUpUI();
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		m_isRunning = true;
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		m_isRunning = false;
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		m_isRunning = false;
	}
	
	private void setSignUpUI()
	{
		et_partner_signup_id = (EditText)findViewById(R.id.et_partner_signup_id);
		et_partner_signup_pw = (EditText)findViewById(R.id.et_partner_signup_pw);
		et_partner_signup_re_pw = (EditText)findViewById(R.id.et_partner_signup_re_pw);
		et_partner_signup_name = (EditText)findViewById(R.id.et_partner_signup_name);
		et_partner_signup_company = (EditText)findViewById(R.id.et_partner_signup_company);
		et_partner_signup_company.setOnKeyListener(new View.OnKeyListener() {
			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				// TODO Auto-generated method stub
				if (keyCode == KeyEvent.KEYCODE_ENTER) {
					return true;
				}
				return false;
			}
		});
		et_partner_signup_company.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				if(et_partner_signup_company.getText().toString().contains(" ")){
					String strReplaceText = et_partner_signup_company.getText().toString();
					strReplaceText = strReplaceText.replace(" ", "");
					et_partner_signup_company.setText(strReplaceText);
					et_partner_signup_company.setSelection(start);
				}
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});

		et_partner_signup_email = (EditText)findViewById(R.id.et_partner_signup_email);
		tv_partner_signup_mobile = (TextView)findViewById(R.id.tv_partner_signup_mobile);
		tv_partner_signup_approval = (TextView)findViewById(R.id.tv_partner_signup_approval);
		
		et_partner_signup_id.setFilters(new InputFilter[]{Utils.filterAlphaNum});
		
		
		if(m_strUserId != null)
			et_partner_signup_id.setText(m_strUserId);
		if(m_strUserId != null)
			tv_partner_signup_approval.setText(m_strApprovalUserName);
		
		tv_partner_signup_mobile.setText(Utils.getPhoneNumberWithHyphen(Utils.getPhoneNumber(this)));
		
		TextView tv_duplicate = (TextView)findViewById(R.id.tv_duplicate);
		tv_duplicate.setOnClickListener(this);

		ImageView btnCancel = (ImageView) findViewById(R.id.btn_cancel);
		btnCancel.setOnClickListener(this);
		ImageView btn_ok = (ImageView)findViewById(R.id.btn_ok);
		btn_ok.setOnClickListener(this);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(requestCode == StaticString.REQUESTCODE_PARTNER_SIGNUP_SUCCESS)
		{
			if(resultCode == Activity.RESULT_OK)
			{
				setResult(Activity.RESULT_OK);
				finish();
			}
		}
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE)
			{	
				popup_ok_long.cancel();
				App.initPartnerLogin(this);
				finish();
			}
			else
				popup_ok_long.cancel();
		}
		else if(v.getId() == R.id.btn_cancel) {
			finish();
		} else if(v.getId() == R.id.btn_ok)
		{
			String strUserId = et_partner_signup_id.getText().toString();
			String strPw = et_partner_signup_pw.getText().toString();
			String strRePw = et_partner_signup_re_pw.getText().toString();
			String strName = et_partner_signup_name.getText().toString();
			String strCompany = et_partner_signup_company.getText().toString();
			String strEmail = et_partner_signup_email.getText().toString();
			strCompany = strCompany.replace(" ", "");
			
			
			if(strUserId.contains(" ") || strUserId.equals(""))
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_id_bad_input).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			if(strUserId.length() > 12 || strUserId.length() < 6)
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_userid_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			if(!m_isUserIdCheck)
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_useid_not).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			else
			{
				if(!strUserId.equals(m_strUserIdCheck))
				{
					m_strUserIdCheck = "";
					m_isUserIdCheck = false;
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.partner_signup_popup_useid_not).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}

			if(strPw.contains(" ") || strRePw.contains(" "))
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_bad_input).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			if(strPw.equals("")){
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			if(strPw.length() > 20 || strPw.length() < 8)
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			} else {
				String input = strPw;
				Pattern p = Pattern.compile("([a-zA-Z0-9].*[!,@,#,$,%,^,&,*,?,_,~])|([!,@,#,$,%,^,&,*,?,_,~].*[a-zA-Z0-9])");
				Matcher m = p.matcher(input);
				if (m.find()){
					//정상적인 비밀번호 이므로 통과
				}else{
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.partner_signup_popup_pw_length).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}

			if(strRePw.length() == 0){
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_reinput).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}


			if(!strPw.equals("")&&!strRePw.equals("")){
				if(strPw.equals(strRePw)){
					//비밀번호, 비밀번호 확인 같으면 통과
				} else {
					//다르면 팝업
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							getString(R.string.cork_pop_signup_popup_pw_r_wrong_input).toString());
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					return;
				}
			}

			
			if(!strPw.equals(strRePw))
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_pw_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(strName.length() > 15 || strName.length() < 2)
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_name_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(strCompany.length() > 30 || strCompany.length() < 2)
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_company_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			//소속에 빈칸 있는 경우 팝업
			if(strCompany.contains(" ")){
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						String.format(getString(R.string.cork_pop_signup_popup_company_space), strCompany));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			if(strCompany.contains("|"))
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_conpany_pipe_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			if(!Utils.isEmailAddress(strEmail))
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_email_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			boolean isInEmoticon = false;

			int[] codeCount = StringUtil.toCodePointArray(strCompany);
			for(int i = 0; i < codeCount.length; i++){
				if(Character.charCount(codeCount[i]) > 1){
					isInEmoticon = true;
					break;
				}
			}

			if(isInEmoticon){
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_company_special).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			requestBecomePartnerReq(strUserId, strPw, strName, strEmail, tv_partner_signup_mobile.getText().toString(), strCompany, m_nApprovalUserNo);
		}
		else if(v.getId() == R.id.tv_duplicate)
		{
			String strUserId = et_partner_signup_id.getText().toString();
			if(strUserId.length() > 12 || strUserId.length() < 6)
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_userid_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}
			
			if(strUserId.length() > 5)
				requestPartnerRedundancyCheck(strUserId);
			else
			{
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_userid_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			
		}
	}
	
	private void requestPartnerRedundancyCheck(String a_strUserId)
	{
		showProgress();
		GetPartnerIdRedundancyCheckReq req = new GetPartnerIdRedundancyCheckReq(a_strUserId);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				m_isUserIdCheck = true;
				m_strUserIdCheck = et_partner_signup_id.getText().toString();
				m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
						CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(
						getString(R.string.pop_error_title).toString(),
						getString(R.string.partner_signup_popup_useid_ok).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				m_isUserIdCheck = false;
				if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}
	
	private void requestBecomePartnerReq(String a_strUserId, String a_strPassword, String a_strName, String a_strEmail, String a_strMobile, String a_strCompany, int a_nApprovalUnserNo)
	{
		showProgress();
		PostBecomePartnerReq req = new PostBecomePartnerReq(a_strUserId, a_strPassword, a_strName, a_strEmail, a_strMobile, a_strCompany, a_nApprovalUnserNo);
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {
	
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
			}
	
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				Intent intent = new Intent(PartnerSignUpAct.this, PartnerSignUpSuccessAct.class);
				startActivityForResult(intent, StaticString.REQUESTCODE_PARTNER_SIGNUP_SUCCESS);
			}
	
			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				m_isUserIdCheck = false;
				if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(PartnerSignUpAct.this, PartnerSignUpAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}			
			}
		});
	}
	
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void isCheckShowPopup(){
		if(m_isRunning){
			m_Popup.show();
		} 
	}
	
}
