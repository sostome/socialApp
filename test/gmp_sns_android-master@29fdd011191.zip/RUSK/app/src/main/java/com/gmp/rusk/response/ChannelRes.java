package com.gmp.rusk.response;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.datamodel.ChannelCommentData;
import com.gmp.rusk.datamodel.ChannelData;
import com.gmp.rusk.datamodel.ChannelFileData;
import com.gmp.rusk.datamodel.ChannelNoticeData;
import com.gmp.rusk.datamodel.ChannelThreadData;
import com.gmp.rusk.datamodel.CompanyEntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.NoticeChannelData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * @author Stan
 *		   서버 Interface 의 Response  데이터를 담을 추상 클래스
 */
public abstract class ChannelRes implements ChannelResObject, ChannelThreadResObject, ChannelFileResObject, ChannelCommentResObject{
	public MyApp App = MyApp.getInstance();

	public static final String RES_TYPE_CHANNEL = "channel";
	public static final String RES_TYPE_CHANNEL_LIST = "channel_list";
	public static final String RES_TYPE_CHANNEL_THREAD = "thread";
	public static final String RES_TYPE_CHANNEL_THREAD_LIST = "thread_list";
	public static final String RES_TYPE_CHANNEL_NOTICE_LIST = "notice_list";
	public static final String RES_TYPE_CHANNEL_COMMENT = "comment";
	public static final String RES_TYPE_CHANNEL_FILES = "files";

	public final String JSON_RESULT = "result";
	public final String JSON_MESSAGE = "message";

	protected String m_strResData = "";						// Result Data

//	protected int m_nResultCode = ApiResult.RESULT_FAIL;	// result
	protected int m_nResultCode = 0;

	protected String m_strMessage = "";						// message

	protected JSONObject jsonRoot = null;

	ChannelData m_ChannelData = new ChannelData();
	//공지채널
	ArrayList<NoticeChannelData> m_arrNoticeChannelData = new ArrayList<NoticeChannelData>();
	//공지채널의 게시물
	ArrayList<ChannelNoticeData> m_arrChannelNoticeData = new ArrayList<ChannelNoticeData>();
	ArrayList<ChannelData> m_arrMemberChannelData = new ArrayList<ChannelData>();
	ArrayList<ChannelData> m_arrInvitingChannelData = new ArrayList<ChannelData>();
	ChannelThreadData m_ChannelThreadData = new ChannelThreadData();
	ArrayList<ChannelThreadData> m_arrChannelThreadData = new ArrayList<ChannelThreadData>();
	ArrayList<ChannelFileData> m_arrChannelFileData = new ArrayList<ChannelFileData>();
	//채널 게시물들 중 공지사항
	ArrayList<ChannelThreadData> m_arrChannelThreadNoticeData = new ArrayList<ChannelThreadData>();

	ArrayList<ChannelCommentData> m_arrChannelCommentData = new ArrayList<ChannelCommentData>();

	int m_nImageCount = 0;
	int m_nMovieFileCount = 0;
	int m_nNormalFileCount = 0;

	public ChannelRes(String a_strData) {
		m_strResData = a_strData;
		
		parseResultCode();

	}

	public ChannelRes(String a_strData, String a_strType){
		m_strResData = a_strData;
		parseResultCode();
		if(a_strType.equals(RES_TYPE_CHANNEL)){
			parseChannelData();
		} else if(a_strType.equals(RES_TYPE_CHANNEL_LIST)){
			parseChannelListData();
		} else if(a_strType.equals(RES_TYPE_CHANNEL_THREAD)){
			parseChannelThreadData();
		} else if(a_strType.equals(RES_TYPE_CHANNEL_THREAD_LIST)){
			parseChannelThreadListData();
		} else if(a_strType.equals(RES_TYPE_CHANNEL_NOTICE_LIST)){
			parseChannelNoticeListData();
		} else if(a_strType.equals(RES_TYPE_CHANNEL_FILES)){
			parseChannelFileListData();
		}
		else if(a_strType.equals(RES_TYPE_CHANNEL_COMMENT)){
			parseChannelCommentData();
		}

	}
	// Parse resultCode and Message based on JSON 
	private void parseResultCode() {
		try
		{
			jsonRoot = new JSONObject(m_strResData);
			// set result code
			if(!jsonRoot.isNull(JSON_RESULT)) {
				m_nResultCode = jsonRoot.getInt(JSON_RESULT);
			}

			// set result message
			if(!jsonRoot.isNull(JSON_MESSAGE)) {
				m_strMessage = jsonRoot.getString(JSON_MESSAGE);
			} 	
			
			if(m_nResultCode != ApiResult.RESULT_SUCCESS) {
					//m_strMessage = NetError.getErrMessage(App.mContext, m_nResType, m_nResultCode);
			}				
			
							
		}
		catch(Exception e)
		{
			CommonLog.e(ChannelRes.class, "" + e.toString());
			m_strMessage = "JSON Error";
		}
		
	}

	@Override
	public void parseChannelData() {

		try {
			m_ChannelData.m_nChannelNo = jsonRoot.getInt(JSON_CHANNELNO);
			m_ChannelData.m_strName = jsonRoot.getString(JSON_NAME);
			m_ChannelData.m_isOwner = jsonRoot.getBoolean(JSON_OWNER);
			if(!jsonRoot.isNull(JSON_OWNERUSERNO))
				m_ChannelData.m_nOwnerUserNo = jsonRoot.getInt(JSON_OWNERUSERNO);
			if(!jsonRoot.isNull(JSON_INVITATIONCOUNT))
				m_ChannelData.m_nInvitaionCount = jsonRoot.getInt(JSON_INVITATIONCOUNT);
			if(!jsonRoot.isNull(JSON_MEMBERCOUNT))
				m_ChannelData.m_nMemberCount = jsonRoot.getInt(JSON_MEMBERCOUNT);
			if(!jsonRoot.isNull(JSON_STATUS))
				m_ChannelData.m_strStatus = jsonRoot.getString(JSON_STATUS);
			if(!jsonRoot.isNull(JSON_CHANNELNOTICONFIG)){
				JSONObject jsonChannelNotiConfig = jsonRoot.getJSONObject(JSON_CHANNELNOTICONFIG);
				m_ChannelData.m_isThreadNotificationOn = jsonChannelNotiConfig.getBoolean(JSON_THREADNOTIFICATION);
				m_ChannelData.m_isCommentNotificationOn = jsonChannelNotiConfig.getBoolean(JSON_COMMENTNOTIFICATION);

			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void parseChannelListData() {
		try {
			JSONArray jsonNoticeChannelList = jsonRoot.getJSONArray(JSON_NOTICECHANNELS);
			for(int a = 0; a < jsonNoticeChannelList.length(); a++){
				JSONObject jsonNoticeChannel = jsonNoticeChannelList.getJSONObject(a);
				NoticeChannelData jsonNoticeChannelData = new NoticeChannelData();
				jsonNoticeChannelData.m_nNoticeChannelNo = jsonNoticeChannel.getInt(JSON_NOTICECHANNELNO);
				jsonNoticeChannelData.m_strNoticeName = jsonNoticeChannel.getString(JSON_NOTICECHANNELNAME);
				m_arrNoticeChannelData.add(jsonNoticeChannelData);
			}

			JSONArray jsonMemberChannelList = jsonRoot.getJSONArray(JSON_RESULTS);
			for(int i = 0; i < jsonMemberChannelList.length(); i++){
				JSONObject jsonMemberChannel = jsonMemberChannelList.getJSONObject(i);
				ChannelData jsonMemberData = new ChannelData();
				jsonMemberData.m_nChannelNo = jsonMemberChannel.getInt(JSON_CHANNELNO);
				jsonMemberData.m_strName = jsonMemberChannel.getString(JSON_NAME);
				jsonMemberData.m_isOwner = jsonMemberChannel.getBoolean(JSON_OWNER);
				if(!jsonMemberChannel.isNull(JSON_OWNERUSERNO))
					jsonMemberData.m_nOwnerUserNo = jsonMemberChannel.getInt(JSON_OWNERUSERNO);
				if(!jsonMemberChannel.isNull(JSON_INVITATIONCOUNT))
					jsonMemberData.m_nInvitaionCount = jsonMemberChannel.getInt(JSON_INVITATIONCOUNT);
				if(!jsonMemberChannel.isNull(JSON_MEMBERCOUNT))
					jsonMemberData.m_nMemberCount = jsonMemberChannel.getInt(JSON_MEMBERCOUNT);
				if(!jsonMemberChannel.isNull(JSON_STATUS))
					jsonMemberData.m_strStatus = jsonMemberChannel.getString(JSON_STATUS);
				m_arrMemberChannelData.add(jsonMemberData);
			}

			JSONArray jsonInvitingChannelList = jsonRoot.getJSONArray(JSON_INVITATIONS);
			for(int i = 0; i < jsonInvitingChannelList.length(); i++){
				JSONObject jsonInvitingChannel = jsonInvitingChannelList.getJSONObject(i);
				ChannelData jsonInvitingData = new ChannelData();
				jsonInvitingData.m_nChannelNo = jsonInvitingChannel.getInt(JSON_CHANNELNO);
				jsonInvitingData.m_strName = jsonInvitingChannel.getString(JSON_NAME);
				jsonInvitingData.m_isOwner = jsonInvitingChannel.getBoolean(JSON_OWNER);
				if(!jsonInvitingChannel.isNull(JSON_OWNERUSERNO))
					jsonInvitingData.m_nOwnerUserNo = jsonInvitingChannel.getInt(JSON_OWNERUSERNO);
				if(!jsonInvitingChannel.isNull(JSON_INVITATIONCOUNT))
					jsonInvitingData.m_nInvitaionCount = jsonInvitingChannel.getInt(JSON_INVITATIONCOUNT);
				if(!jsonInvitingChannel.isNull(JSON_MEMBERCOUNT))
					jsonInvitingData.m_nMemberCount = jsonInvitingChannel.getInt(JSON_MEMBERCOUNT);
				if(!jsonInvitingChannel.isNull(JSON_STATUS))
					jsonInvitingData.m_strStatus = jsonInvitingChannel.getString(JSON_STATUS);
				m_arrInvitingChannelData.add(jsonInvitingData);
			}

		}
		catch (JSONException e) {

		}
	}

	@Override
	public void parseChannelThreadData() {

		try {
			m_ChannelThreadData.m_nThreadNo = jsonRoot.getInt(JSON_THREADNO);
			m_ChannelThreadData.m_nUserNo = jsonRoot.getInt(JSON_USERNO);
			m_ChannelThreadData.m_strBody = jsonRoot.getString(JSON_BODY);
			m_ChannelThreadData.m_isNotice = jsonRoot.getBoolean(JSON_NOTICE);
			m_ChannelThreadData.m_isRead = jsonRoot.getBoolean(JSON_READ);
			m_ChannelThreadData.m_strCreatedDate = jsonRoot.getString(JSON_CREATEDDATE);
			if(!jsonRoot.isNull(JSON_UPDATEDDATE))
				m_ChannelThreadData.m_strUpdatedTime = jsonRoot.getString(JSON_UPDATEDDATE);
			m_ChannelThreadData.m_nLikeCount = jsonRoot.getInt(JSON_LIKECOUNT);
			m_ChannelThreadData.m_isLiked = jsonRoot.getBoolean(JSON_LIKED);
			if(!jsonRoot.isNull(JSON_THREADTYPE))
				m_ChannelThreadData.m_strThreadType = jsonRoot.getString(JSON_THREADTYPE);
			if(!jsonRoot.isNull(JSON_CREATETYPE))
				m_ChannelThreadData.m_strCreateType = jsonRoot.getString(JSON_CREATETYPE);

			m_ChannelThreadData.m_nCommentCount = jsonRoot.getInt(JSON_COMMENTCOUNT);
			if(!jsonRoot.isNull(JSON_FILES)) {
				JSONArray jsonFiles = jsonRoot.getJSONArray(JSON_FILES);
				for(int i = 0; i < jsonFiles.length(); i++){
					ChannelFileData fileData = new ChannelFileData();
					JSONObject jsonFile = jsonFiles.getJSONObject(i);
					if(jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
						fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
						fileData.m_strType = jsonFile.getString(JSON_TYPE);
						fileData.m_strUrl = jsonFile.getString(JSON_URL);
						fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
						if(jsonFile.has(JSON_WIDEPREVIEWURL))
							fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
						fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
						fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
						m_ChannelThreadData.m_arrChannelFileData.add(fileData);
					}
				}
				for(int i = 0; i < jsonFiles.length(); i++){
					ChannelFileData fileData = new ChannelFileData();
					JSONObject jsonFile = jsonFiles.getJSONObject(i);
					if(!jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
						fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
						fileData.m_strType = jsonFile.getString(JSON_TYPE);
						fileData.m_strUrl = jsonFile.getString(JSON_URL);
						fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
						if(jsonFile.has(JSON_WIDEPREVIEWURL))
							fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
						fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
						fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
						m_ChannelThreadData.m_arrChannelFileData.add(fileData);
					}
				}

			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void parseChannelThreadListData() {

		try {
			if(!jsonRoot.isNull(JSON_NOTICES)) {
				JSONArray jsonNotices = jsonRoot.getJSONArray(JSON_NOTICES);

				for (int i = 0; i < jsonNotices.length(); i++) {
					ChannelThreadData threadData = new ChannelThreadData();
					JSONObject jsonNotice = jsonNotices.getJSONObject(i);
					threadData.m_nThreadNo = jsonNotice.getInt(JSON_THREADNO);
					threadData.m_nUserNo = jsonNotice.getInt(JSON_USERNO);
					threadData.m_strBody = jsonNotice.getString(JSON_BODY);
					threadData.m_isNotice = jsonNotice.getBoolean(JSON_NOTICE);
					threadData.m_isRead = jsonNotice.getBoolean(JSON_READ);
					if(!jsonNotice.isNull(JSON_THREADTYPE))
						threadData.m_strThreadType = jsonNotice.getString(JSON_THREADTYPE);
					threadData.m_strCreatedDate = jsonNotice.getString(JSON_CREATEDDATE);
					if (!jsonNotice.isNull(JSON_UPDATEDDATE))
						threadData.m_strUpdatedTime = jsonNotice.getString(JSON_UPDATEDDATE);
					threadData.m_nLikeCount = jsonNotice.getInt(JSON_LIKECOUNT);
					threadData.m_isLiked = jsonNotice.getBoolean(JSON_LIKED);
					threadData.m_nCommentCount = jsonNotice.getInt(JSON_COMMENTCOUNT);
					if (!jsonNotice.isNull(JSON_FILES)) {
						JSONArray jsonFiles = jsonNotice.getJSONArray(JSON_FILES);
						for (int j = 0; j < jsonFiles.length(); j++) {
							ChannelFileData fileData = new ChannelFileData();
							JSONObject jsonFile = jsonFiles.getJSONObject(j);
							if(jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
								fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
								fileData.m_strType = jsonFile.getString(JSON_TYPE);
								fileData.m_strUrl = jsonFile.getString(JSON_URL);
								fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
								if(jsonFile.has(JSON_WIDEPREVIEWURL))
									fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
								fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
								fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
								threadData.m_arrChannelFileData.add(fileData);
							}
						}
						for (int j = 0; j < jsonFiles.length(); j++) {
							ChannelFileData fileData = new ChannelFileData();
							JSONObject jsonFile = jsonFiles.getJSONObject(j);
							if(!jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
								fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
								fileData.m_strType = jsonFile.getString(JSON_TYPE);
								fileData.m_strUrl = jsonFile.getString(JSON_URL);
								fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
								if(jsonFile.has(JSON_WIDEPREVIEWURL))
									fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
								fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
								fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
								threadData.m_arrChannelFileData.add(fileData);
							}
						}
					}
					m_arrChannelThreadNoticeData.add(threadData);
				}
			}

			JSONArray jsonThreads = jsonRoot.getJSONArray(JSON_THREADS);

			for(int i = 0; i < jsonThreads.length(); i++) {
				ChannelThreadData threadData = new ChannelThreadData();
				JSONObject jsonThread = jsonThreads.getJSONObject(i);
				threadData.m_nThreadNo = jsonThread.getInt(JSON_THREADNO);
				threadData.m_nUserNo = jsonThread.getInt(JSON_USERNO);
				threadData.m_strBody = jsonThread.getString(JSON_BODY);
				threadData.m_isNotice = jsonThread.getBoolean(JSON_NOTICE);
				threadData.m_isRead = jsonThread.getBoolean(JSON_READ);
				if(!jsonThread.isNull(JSON_THREADTYPE))
					threadData.m_strThreadType = jsonThread.getString(JSON_THREADTYPE);
				threadData.m_strCreatedDate = jsonThread.getString(JSON_CREATEDDATE);
				if (!jsonThread.isNull(JSON_UPDATEDDATE))
					threadData.m_strUpdatedTime = jsonThread.getString(JSON_UPDATEDDATE);
				threadData.m_nLikeCount = jsonThread.getInt(JSON_LIKECOUNT);
				threadData.m_isLiked = jsonThread.getBoolean(JSON_LIKED);
				threadData.m_nCommentCount = jsonThread.getInt(JSON_COMMENTCOUNT);
				if (!jsonThread.isNull(JSON_FILES)) {
					JSONArray jsonFiles = jsonThread.getJSONArray(JSON_FILES);
					for (int j = 0; j < jsonFiles.length(); j++) {
						ChannelFileData fileData = new ChannelFileData();
						JSONObject jsonFile = jsonFiles.getJSONObject(j);
						if(jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
							fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
							fileData.m_strType = jsonFile.getString(JSON_TYPE);
							fileData.m_strUrl = jsonFile.getString(JSON_URL);
							fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
							if(jsonFile.has(JSON_WIDEPREVIEWURL))
								fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
							fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
							fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
							threadData.m_arrChannelFileData.add(fileData);
						}
					}
					for (int j = 0; j < jsonFiles.length(); j++) {
						ChannelFileData fileData = new ChannelFileData();
						JSONObject jsonFile = jsonFiles.getJSONObject(j);
						if(!jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
							fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
							fileData.m_strType = jsonFile.getString(JSON_TYPE);
							fileData.m_strUrl = jsonFile.getString(JSON_URL);
							fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
							if(jsonFile.has(JSON_WIDEPREVIEWURL))
								fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
							fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
							fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
							threadData.m_arrChannelFileData.add(fileData);
						}
					}
				}
				m_arrChannelThreadData.add(threadData);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void parseChannelNoticeListData() {
		try {
			JSONArray jsonThreads = jsonRoot.getJSONArray(JSON_NOTICETHREADS);

			for(int i = 0; i < jsonThreads.length(); i++) {
				ChannelNoticeData noticeData = new ChannelNoticeData();
				JSONObject jsonNotice = jsonThreads.getJSONObject(i);
				noticeData.m_nThreadNo = jsonNotice.getInt(JSON_THREADNO);
				noticeData.m_strTitle = jsonNotice.getString(JSON_TITLE);
				noticeData.m_strBody = jsonNotice.getString(JSON_BODY);
				noticeData.m_strCreatedDate = jsonNotice.getString(JSON_CREATEDDATE);
				if (!jsonNotice.isNull(JSON_UPDATEDDATE))
					noticeData.m_strUpdatedTime = jsonNotice.getString(JSON_UPDATEDDATE);
				if (!jsonNotice.isNull(JSON_FILES)) {
					JSONArray jsonFiles = jsonNotice.getJSONArray(JSON_FILES);
					for (int j = 0; j < jsonFiles.length(); j++) {
						ChannelFileData fileData = new ChannelFileData();
						JSONObject jsonFile = jsonFiles.getJSONObject(j);
						if(jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
							fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
							fileData.m_strType = jsonFile.getString(JSON_TYPE);
							fileData.m_strUrl = jsonFile.getString(JSON_URL);
							fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
							if(jsonFile.has(JSON_WIDEPREVIEWURL))
								fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
							fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
							fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
							noticeData.m_arrChannelFileData.add(fileData);
						}
					}
					for (int j = 0; j < jsonFiles.length(); j++) {
						ChannelFileData fileData = new ChannelFileData();
						JSONObject jsonFile = jsonFiles.getJSONObject(j);
						if(!jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
							fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
							fileData.m_strType = jsonFile.getString(JSON_TYPE);
							fileData.m_strUrl = jsonFile.getString(JSON_URL);
							fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
							if(jsonFile.has(JSON_WIDEPREVIEWURL))
								fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
							fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
							fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
							noticeData.m_arrChannelFileData.add(fileData);
						}
					}
				}
				m_arrChannelNoticeData.add(noticeData);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void parseChannelCommentData() {
		try {
			JSONArray jsonComments = jsonRoot.getJSONArray(JSON_COMMENTS);

			for(int i = 0; i < jsonComments.length(); i++){
				JSONObject jsonComment = jsonComments.getJSONObject(i);
				ChannelCommentData commentData = new ChannelCommentData();
				commentData.m_nCommentNo = jsonComment.getInt(JSON_COMMENTNO);
				commentData.m_nUserNo = jsonComment.getInt(JSON_USERNO);
				commentData.m_strBody = jsonComment.getString(JSON_BODY);
				commentData.m_strCreatedDate = jsonComment.getString(JSON_CREATEDDATE);
				if(jsonComment.isNull(JSON_UPDATEDDATE)){
					commentData.m_strUpdatedTime = jsonComment.getString(JSON_UPDATEDDATE);
				}
				commentData.m_nLikeCount = jsonComment.getInt(JSON_LIKECOUNT);
				commentData.m_isLiked = jsonComment.getBoolean(JSON_LIKED);
				m_arrChannelCommentData.add(commentData);
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void parseChannelFileListData() {
		try {
			if (!jsonRoot.isNull(JSON_FILES)) {
				JSONArray jsonFiles = jsonRoot.getJSONArray(JSON_FILES);
				for (int i = 0; i < jsonFiles.length(); i++) {
					ChannelFileData fileData = new ChannelFileData();
					JSONObject jsonFile = jsonFiles.getJSONObject(i);
					if(jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
						fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
						fileData.m_strType = jsonFile.getString(JSON_TYPE);
						fileData.m_strUrl = jsonFile.getString(JSON_URL);
						fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
						if(jsonFile.has(JSON_WIDEPREVIEWURL))
							fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
						fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
						fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
						m_arrChannelFileData.add(fileData);
					}
				}
				for (int i = 0; i < jsonFiles.length(); i++) {
					ChannelFileData fileData = new ChannelFileData();
					JSONObject jsonFile = jsonFiles.getJSONObject(i);
					if(!jsonFile.getString(JSON_TYPE).equals(StaticString.FILE_TYPE_VIDEO)) {
						fileData.m_nFileNo = jsonFile.getInt(JSON_FILENO);
						fileData.m_strType = jsonFile.getString(JSON_TYPE);
						fileData.m_strUrl = jsonFile.getString(JSON_URL);
						fileData.m_strPreviewUrl = jsonFile.getString(JSON_PREVIEWURL);
						if(jsonFile.has(JSON_WIDEPREVIEWURL))
							fileData.m_strWidePreviewUrl = jsonFile.getString(JSON_WIDEPREVIEWURL);
						fileData.m_strFileName = jsonFile.getString(JSON_FILENAME);
						fileData.m_lnFileSize = jsonFile.getInt(JSON_FILESIZE);
						fileData.m_strTime = jsonFile.getString(JSON_CREATEDDATE);
						m_arrChannelFileData.add(fileData);
					}
				}
				m_nImageCount = jsonRoot.getInt(JSON_IMAGECOUNT);
				m_nMovieFileCount = jsonRoot.getInt(JSON_MOVIEFILECOUNT);
				m_nNormalFileCount = jsonRoot.getInt(JSON_NORMALFILECOUNT);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void parseChannelFileData() {

	}

	@Override
	public ChannelData getChannelData() {
		return m_ChannelData;
	}

	@Override
	public ArrayList<NoticeChannelData> getNoticeChannelListData() {
		return m_arrNoticeChannelData;
	}

	@Override
	public ArrayList<ChannelData> getMemberChannelListData() {
		return m_arrMemberChannelData;
	}

	@Override
	public ArrayList<ChannelData> getInvitingChannelListData() {
		return m_arrInvitingChannelData;
	}

	@Override
	public ChannelThreadData getChannelThreadData() {
		return m_ChannelThreadData;
	}

	@Override
	public ArrayList<ChannelThreadData> getChannelThreadListData() {
		return m_arrChannelThreadData;
	}

	@Override
	public ArrayList<ChannelThreadData> getChannelThreadNoticeListData() {
		return m_arrChannelThreadNoticeData;
	}

	@Override
	public ArrayList<ChannelNoticeData> getChannelNoticeListData() {
		return m_arrChannelNoticeData;
	}

	@Override
	public ArrayList<ChannelCommentData> getChannelCommentData() {
		return m_arrChannelCommentData;
	}

	@Override
	public ChannelFileData getChannelFileData() {
		return null;
	}

	@Override
	public ArrayList<ChannelFileData> getChannelFileListData() {
		return m_arrChannelFileData;
	}

	@Override
	public int getChannelImageCount() {
		return m_nImageCount;
	}

	@Override
	public int getChannelMovieFileCount() {
		return m_nMovieFileCount;
	}

	@Override
	public int getChannelNormalFileCount() {
		return m_nNormalFileCount;
	}

	// Get Result Code
	public int getResultCode() {
		return m_nResultCode;
	}
	
	// get Message
	public String getMessage() {
		return m_strMessage;
	}
	
	// Parse each data based on JSON
	public abstract void parseData();
	
}
