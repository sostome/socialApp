package com.gmp.rusk.request;

import java.util.ArrayList;

import android.util.SparseBooleanArray;



/**
 *	@author dym
 *			모임 뱃지 삭제
 *			method : delete
 */

public class DeleteSNSGroupBadgeReq extends Req{
	
	private String APINAME = "group";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "DELETE";
	
	
	public DeleteSNSGroupBadgeReq(ArrayList<Integer> a_arrNos)
	{
		String strNos = "";
		int nSize = 0;
		if(a_arrNos != null)
			nSize = a_arrNos.size();
		for(int i = 0; i < nSize; i++)
		{
			strNos = strNos + a_arrNos.get(i);
			
			if(i < nSize - 1)
				strNos = strNos + ",";
		}
		APINAME = APINAME + "/badgeDelete/" + strNos; 
	}
	
	public DeleteSNSGroupBadgeReq(SparseBooleanArray a_arrNos)
	{
		String strNos = "";
		int nSize = 0;
		if(a_arrNos != null)
			nSize = a_arrNos.size();
		for(int i = 0; i < nSize; i++)
		{
			int nBoardId = a_arrNos.keyAt(i);
			Boolean isRead = a_arrNos.get(nBoardId);
			
			if(isRead)
			{
				strNos = strNos + a_arrNos.get(i);
				
				if(i < nSize - 1)
					strNos = strNos + ",";
			}
		}
		APINAME = APINAME + "/badgeDelete/" + strNos; 
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
