package com.gmp.rusk.response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.SNSBoardData;
import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.datamodel.SNSReplyData;
import com.gmp.rusk.utils.CommonLog;

public class GetGroupBoardRes extends ChannelRes{

	
	public GetGroupBoardRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		// TODO Auto-generated constructor stub

	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}

}