package com.gmp.rusk.act;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-30.
 */

public class ChannelNoticeDetailAct extends CustomActivity {

    private String m_strChannelName = "";
    private String m_strChannelTitle = "";
    private String m_strChannelBody = "";
    private ArrayList<String> m_arrUrl = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.act_channel_notice_detail);
        getIntentData();
        setUI();
    }

    private void getIntentData(){
        m_strChannelName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_NAME);
        m_strChannelTitle = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_TITLE);
        m_strChannelBody = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_BODY);
        m_arrUrl = getIntent().getStringArrayListExtra(IntentKeyString.INTENT_KEY_CHANNEL_NOTICELIST_FILE);
    }

    private void setUI(){

        TextView strName = (TextView)findViewById(R.id.tv_channel_notice_detail_top_text);
        TextView strTitle = (TextView)findViewById(R.id.tv_channel_notice_detail_title);
        TextView strBody = (TextView)findViewById(R.id.tv_channel_notice_detail_body);
        LinearLayout layoutView = (LinearLayout)findViewById(R.id.layout_channel_notice_detail_addview);
        ImageView ivBackArrow = (ImageView)findViewById(R.id.iv_channel_notice_detail_back);

        strName.setText(m_strChannelName);
        strTitle.setText(m_strChannelTitle);
        strBody.setText(m_strChannelBody);

        layoutView.removeAllViews();
        for(int i = 0; i < m_arrUrl.size(); i++){
            LayoutInflater li = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View view = li.inflate(R.layout.layout_notice_image, null);
            ImageView ivView = (ImageView)view.findViewById(R.id.iv_notice_detail_image);
            ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(this);
            imageLoaderMng.cancelDownload(ivView);
            imageLoaderMng.getProfileImage(ivView, m_arrUrl.get(i), 0, false);

            layoutView.addView(view);
        }

        ivBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }
}
