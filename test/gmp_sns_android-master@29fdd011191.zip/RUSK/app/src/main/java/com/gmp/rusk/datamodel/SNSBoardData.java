package com.gmp.rusk.datamodel;

import java.util.ArrayList;

public class SNSBoardData {
	
	public int m_nBoardNo = 0;
	public int m_nBoardOwnerNo = 0;
	public String m_strGroupName = "";
	public String m_strOwnerName = "";
	public String m_strCompanyOrDepartment = "";
	public String m_strOwnerImageUrl = "";
	public String m_strOwnerType = "";
	public String m_strCreatedDate = "";
	public String m_strUpdateDate = "";
	public String m_strComment = "";
	public int m_nReplyCount = 0;
	public boolean m_isNoticed = false;
	public boolean m_isLiked = false;
	public int m_nLikeCount = 0;
	public ArrayList<SNSBoardFileData> m_arrBoardFileData = new ArrayList<SNSBoardFileData>();
	public ArrayList<SNSReplyData> m_arrReplyData = new ArrayList<SNSReplyData>();
}
