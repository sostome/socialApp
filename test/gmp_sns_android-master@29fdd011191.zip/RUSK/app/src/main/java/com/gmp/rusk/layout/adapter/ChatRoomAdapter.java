package com.gmp.rusk.layout.adapter;

import java.util.ArrayList;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.act.ChatRoomAct;
import com.gmp.rusk.datamodel.ChatRoomData;
import com.gmp.rusk.datamodel.ReadCountData;
import com.gmp.rusk.layout.ChatRoomLayout;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class ChatRoomAdapter extends BaseAdapter {
	Context m_Context;
	// ChatRoomData m_ChatRoomData;
	ArrayList<ChatRoomData> m_arrChatRoomData;
	ArrayList<View> m_layout = new ArrayList<View>();
	int nDataNumber = -1;
	MyApp App = new MyApp();
	ChatRoomAct.TiniItemSelectListener m_tiniSelectListener;

	public ChatRoomAdapter(Context context) {
		m_arrChatRoomData = new ArrayList<ChatRoomData>();
		m_Context = context;
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getItemViewType(int position) {
		return m_arrChatRoomData.get(position).m_nType;
	}

	public void setInvisibleTiniMessageIsFirst(int firstVisible,int count,int total){

		//현재 스크롤 상태에서 보이는 목록이 위쪽 처리해야하는 것은 전체에서 안 보이는 목록의 m_isFirstDraw값을 true로 해주는 것이다.
		if(firstVisible==0){
			for(int i=count;i<total;i++){
				m_arrChatRoomData.get(i).m_isHaveToDraw = true;
			}
		}
		else if(firstVisible+count == total){
			for(int i=0;i<firstVisible;i++)
				m_arrChatRoomData.get(i).m_isHaveToDraw = true;
		}
		else {
			for(int i=0;i<firstVisible;i++)
				m_arrChatRoomData.get(i).m_isHaveToDraw = true;
			for(int i=firstVisible+count;i<total;i++)
				m_arrChatRoomData.get(i).m_isHaveToDraw = true;
		}
	}
	public void add(ChatRoomData roomData) {
		// nDataNumber += 1;
		// if(m_arrChatRoomData.size() > nDataNumber){
		// m_arrChatRoomData.remove(nDataNumber);
		// }
		// m_arrChatRoomData.add(nDataNumber, roomData);
		if(m_arrChatRoomData != null)
		m_arrChatRoomData.add(roomData);
	}

	public void addAll(ArrayList<ChatRoomData> arrRoomData) {
		if(m_arrChatRoomData != null) {
		m_arrChatRoomData.clear();
		// for(int i = 0; i < arrRoomData.size(); i++){
		// if(m_arrChatRoomData.size() > i){
		// m_arrChatRoomData.remove(i);
		// }
		// }
		m_arrChatRoomData.addAll(arrRoomData);
	}
	}

	public void clear() {
		// nDataNumber = -1;
		if(m_arrChatRoomData != null)
		m_arrChatRoomData.clear();
		// notifyDataSetChanged();
	}



	public void clearAll() {
		m_arrChatRoomData.clear();
	}

	public void dataSetChanged() {
		notifyDataSetChanged();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		// if(m_arrChatRoomData != null && m_arrChatRoomData.size()>position){
		// m_ChatRoomData = m_arrChatRoomData.get(position);
		// }
		// CommonLog.e(m_Context, "This Data : " +
		// m_ChatRoomData.m_strMessageID);
		// ChatRoomData oldData = new ChatRoomData();
		// if (convertView != null) {
		//
		// oldData = (ChatRoomData) convertView.getTag();
		// // CommonLog.e(m_Context, "Old Data : " + oldData.m_strMessageID);
		// for (int i = 0; i < m_layout.size(); i++) {
		//
		// ChatRoomData data = (ChatRoomData) m_layout.get(i).getTag();
		// CommonLog.e(m_Context, "Data : " + data.m_strMessageID);
		// if (data.m_strMessageID != null &&
		// data.m_strMessageID.equals(m_ChatRoomData.m_strMessageID)) {
		// m_ChatRoomData.m_arrRead = data.m_arrRead;
		// }
		// }
		// }

		// if (m_ChatRoomData.m_nType == StaticString.CHAT_ROOM_SYSTEM_MSG) {
		// ChatRoomSystemLayout m_ChatRoomSystmeMSG = new
		// ChatRoomSystemLayout(m_Context, m_ChatRoomData.m_strSystemMSG);
		// convertView = m_ChatRoomSystmeMSG;
		// } else if (m_ChatRoomData.m_nType ==
		// StaticString.CHAT_ROOM_OTHER_MESSAGE) {
		// ChatRoomOtherMSGLayout m_ChatRoomOtherMSG = new
		// ChatRoomOtherMSGLayout(m_Context, m_ChatRoomData.m_nNO,
		// m_ChatRoomData.m_strName, m_ChatRoomData.m_strOtherMSG,
		// m_ChatRoomData.m_arrRead, m_ChatRoomData.m_arrTotalRead,
		// m_ChatRoomData.m_lDate, m_ChatRoomData.m_strMessageID,
		// m_ChatRoomData.m_isAvailable);
		// convertView = m_ChatRoomOtherMSG;
		// } else if (m_ChatRoomData.m_nType ==
		// StaticString.CHAT_ROOM_MY_MESSAGE) {
		// ChatRoomMyMSGLayout m_ChatRoomMyMSG = new
		// ChatRoomMyMSGLayout(m_Context, m_ChatRoomData.m_nSendStatus,
		// m_ChatRoomData.m_strRoomID, m_ChatRoomData.m_nNO,
		// m_ChatRoomData.m_strMyMSG, m_ChatRoomData.m_arrRead,
		// m_ChatRoomData.m_arrTotalRead, m_ChatRoomData.m_lDate,
		// m_ChatRoomData.m_strMessageID);
		// convertView = m_ChatRoomMyMSG;
		// } else if (m_ChatRoomData.m_nType == StaticString.CHAT_ROOM_MY_IMAGE)
		// {
		// ChatRoomMyImageLayout m_ChatRoomMyImage = new
		// ChatRoomMyImageLayout(m_Context, m_ChatRoomData.m_nSendStatus,
		// m_ChatRoomData.m_strRoomID, m_ChatRoomData.m_nNO,
		// m_ChatRoomData.m_strMyImageUrl, m_ChatRoomData.m_nWidht,
		// m_ChatRoomData.m_nHeight, m_ChatRoomData.m_strMyImageThumbUrl,
		// m_ChatRoomData.m_arrRead,
		// m_ChatRoomData.m_arrTotalRead, m_ChatRoomData.m_lDate,
		// m_ChatRoomData.m_strMessageID);
		// convertView = m_ChatRoomMyImage;
		// } else if (m_ChatRoomData.m_nType ==
		// StaticString.CHAT_ROOM_OTHER_IMAGE) {
		// ChatRoomOtherImageLayout m_ChatRoomOtherImage = new
		// ChatRoomOtherImageLayout(m_Context, m_ChatRoomData.m_nSendStatus,
		// m_ChatRoomData.m_strRoomID, m_ChatRoomData.m_nNO,
		// m_ChatRoomData.m_strName, m_ChatRoomData.m_strOtherImageUrl,
		// m_ChatRoomData.m_nWidht, m_ChatRoomData.m_nHeight,
		// m_ChatRoomData.m_strOtherImageThumbUrl,
		// m_ChatRoomData.m_arrRead, m_ChatRoomData.m_arrTotalRead,
		// m_ChatRoomData.m_lDate, m_ChatRoomData.m_strMessageID,
		// m_ChatRoomData.m_isAvailable);
		// convertView = m_ChatRoomOtherImage;
		// } else if (m_ChatRoomData.m_nType ==
		// StaticString.CHAT_ROOM_OTHER_FILE) {
		// ChatRoomOtherFileLayout m_ChatRoomOtherFile = new
		// ChatRoomOtherFileLayout(m_Context, m_ChatRoomData.m_strRoomID,
		// m_ChatRoomData.m_nNO, m_ChatRoomData.m_strName,
		// m_ChatRoomData.m_strOtherMSG, m_ChatRoomData.m_strOtherFile,
		// m_ChatRoomData.m_arrRead, m_ChatRoomData.m_arrTotalRead,
		// m_ChatRoomData.m_lDate,
		// m_ChatRoomData.m_strMessageID, m_ChatRoomData.m_isAvailable);
		// convertView = m_ChatRoomOtherFile;
		// } else if (m_ChatRoomData.m_nType == StaticString.CHAT_ROOM_MY_FILE)
		// {
		// ChatRoomMyFileLayout m_ChatRoomMyFile = new
		// ChatRoomMyFileLayout(m_Context, m_ChatRoomData.m_nSendStatus,
		// m_ChatRoomData.m_strRoomID, m_ChatRoomData.m_nNO,
		// m_ChatRoomData.m_strMyMSG, m_ChatRoomData.m_strMyFile,
		// m_ChatRoomData.m_arrRead, m_ChatRoomData.m_arrTotalRead,
		// m_ChatRoomData.m_lDate,
		// m_ChatRoomData.m_strMessageID);
		// convertView = m_ChatRoomMyFile;
		// }

		if (convertView == null) {
			convertView = new ChatRoomLayout(m_Context);
		}
		if (m_arrChatRoomData != null && m_arrChatRoomData.size() > position) {
			// if(m_arrChatRoomData != null && m_arrChatRoomData.size()>position
			// && m_arrChatRoomData.size()/2 < position){

			((ChatRoomLayout) convertView).setPosition(position);
			((ChatRoomLayout) convertView).setData(m_arrChatRoomData.get(position));
			if(m_arrChatRoomData.get(position).m_nType == StaticString.CHAT_ROOM_TINI_MESSAGE)
				((ChatRoomLayout) convertView).setTiniSelectListener(m_tiniSelectListener);
			// ((ChatRoomLayout) convertView).setData(m_ChatRoomData);
			// convertView.setVisibility(View.VISIBLE);
			return convertView;
		}
		// else if(m_arrChatRoomData != null &&
		// m_arrChatRoomData.size()>position && m_arrChatRoomData.size()/2 >=
		// position){
		// ((ChatRoomLayout)
		// convertView).setData(m_arrChatRoomData.get(position));
		// // ((ChatRoomLayout) convertView).setData(m_ChatRoomData);
		// convertView.setVisibility(View.GONE);
		// return convertView;
		// }
		else
			return null;
		// convertView.setTag(m_ChatRoomData);
		//
		// for (int i = 0; i < m_layout.size(); i++) {
		// ChatRoomData data = (ChatRoomData) m_layout.get(i).getTag();
		// if (data.m_strMessageID == oldData.m_strMessageID) {
		// m_layout.remove(i);
		// break;
		// }
		// }
		//
		// m_layout.add(convertView);

	}

	public void setUIChange(ChatRoomData data) {
		for (int i = 0; i < m_layout.size(); i++) {
			ChatRoomData oldData2 = (ChatRoomData) m_layout.get(i).getTag();
			// CommonLog.e(m_Context, "OldData : " + oldData2.m_strMessageID);
			// CommonLog.e(m_Context, "NewData : " + data.m_strMessageID);
			if (data.m_strMessageID.equals(oldData2.m_strMessageID)) {
				// Layout layout = m_layout.get(i);
				// layout.setData(data);
				CommonLog.e(m_Context, "Change UI");
				m_layout.get(i).setTag(data);
				break;
			}
		}
	}
	public void setTiniSelectItemListener(ChatRoomAct.TiniItemSelectListener aTiniListener){
		m_tiniSelectListener = aTiniListener;
	}
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return m_arrChatRoomData.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return m_arrChatRoomData.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	public void setChangeData(ArrayList<ReadCountData> arrReadCountData) {
		// TODO Auto-generated method stub
		for (ReadCountData countData : arrReadCountData) {
			for (ChatRoomData data : m_arrChatRoomData) {
				if (data.m_strMessageID != null && data.m_strMessageID.equals(countData.m_strMessageId)) {
					data.m_nNoReadCount -= 1;

					break;
				}
			}
		}
	}

	public void setChangeCountData(ArrayList<ReadCountData> arrReadCountData) {
		// TODO Auto-generated method stub
		for (ReadCountData countData : arrReadCountData) {
			for (ChatRoomData data : m_arrChatRoomData) {
				if (data.m_strMessageID != null && data.m_strMessageID.equals(countData.m_strMessageId)) {
					if(countData.m_nCount < data.m_nNoReadCount) {
						data.m_nNoReadCount = countData.m_nCount;
					}
					break;
				}
			}
		}
	}
	
	public void setMyMessageChange(ChatRoomData roomData) {

		boolean isMessage = false;
		for (ChatRoomData data : m_arrChatRoomData) {
			if (data.m_strMessageID != null && data.m_strMessageID.equals(roomData.m_strMessageID)) {
				// data.m_arrRead = roomData.m_arrRead;
				// data.m_arrTotalRead = roomData.m_arrTotalRead;
				data.m_isImageAvailable = roomData.m_isImageAvailable;
				data.m_lDate = roomData.m_lDate;
				data.m_nHeight = roomData.m_nHeight;
				data.m_nNO = roomData.m_nNO;
				data.m_nRead = roomData.m_nRead;
				data.m_nSendStatus = roomData.m_nSendStatus;
				data.m_nType = roomData.m_nType;
				data.m_nWidht = roomData.m_nWidht;
				data.m_strMessageID = roomData.m_strMessageID;
				data.m_strMimetype = roomData.m_strMimetype;
				data.m_strMyFile = roomData.m_strMyFile;
				data.m_strMyImageThumbUrl = roomData.m_strMyImageThumbUrl;
				data.m_strMyImageUrl = roomData.m_strMyImageUrl;
				data.m_strMyMSG = roomData.m_strMyMSG;
				data.m_strName = roomData.m_strName;
				data.m_strOtherFile = roomData.m_strOtherFile;
				data.m_strOtherImageThumbUrl = roomData.m_strOtherImageThumbUrl;
				data.m_strOtherImageUrl = roomData.m_strOtherImageUrl;
				data.m_strOtherMSG = roomData.m_strOtherMSG;
				data.m_strRoomID = roomData.m_strRoomID;
				data.m_strSystemMSG = roomData.m_strSystemMSG;
				data.m_nNoReadCount = roomData.m_nNoReadCount;
				data.m_EmoticonName = roomData.m_EmoticonName;
				data.m_JsonObject = roomData.m_JsonObject;
				isMessage = true;
				break;
			}
		}
		if(!isMessage){
			m_arrChatRoomData.add(roomData);
		}
	}

	public void setMyDataChange(ChatRoomData roomData) {
		boolean isMessage = false;
		for(int i = 0; i < m_arrChatRoomData.size(); i++){
			if(m_arrChatRoomData.get(i).m_strMessageID != null && m_arrChatRoomData.get(i).m_strMessageID.equals(roomData.m_strMessageID)){
				isMessage = true;
				m_arrChatRoomData.set(i, roomData);
				break;
			}
		}
		if(!isMessage){
			m_arrChatRoomData.add(roomData);
		}
//		for (ChatRoomData data : m_arrChatRoomData) {
//			if (data.m_strMessageID != null && data.m_strMessageID.equals(roomData.m_strMessageID)) {
//				m_arrChatRoomData.remove(data);
//				m_arrChatRoomData.add(roomData);
//				break;
//			}
//		}
	}

	public void setFailChange(String strMsgID) {
		for (ChatRoomData data : m_arrChatRoomData) {
			if (data.m_strMessageID != null && strMsgID.equals(data.m_strMessageID)) {
				ChatRoomData changeData = new ChatRoomData();
				// changeData.m_arrRead = data.m_arrRead;
				// changeData.m_arrTotalRead = data.m_arrTotalRead;
				changeData.m_isImageAvailable = data.m_isImageAvailable;
				changeData.m_lDate = data.m_lDate;
				changeData.m_nHeight = data.m_nHeight;
				changeData.m_nNO = data.m_nNO;
				changeData.m_nRead = data.m_nRead;
				changeData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_FAIL;
				changeData.m_nType = data.m_nType;
				changeData.m_nWidht = data.m_nWidht;
				changeData.m_strMessageID = data.m_strMessageID;
				changeData.m_strMimetype = data.m_strMimetype;
				changeData.m_strMyFile = data.m_strMyFile;
				changeData.m_strMyImageThumbUrl = data.m_strMyImageThumbUrl;
				changeData.m_strMyImageUrl = data.m_strMyImageUrl;
				changeData.m_strMyMSG = data.m_strMyMSG;
				changeData.m_strName = data.m_strName;
				changeData.m_strOtherFile = data.m_strOtherFile;
				changeData.m_strOtherImageThumbUrl = data.m_strOtherImageThumbUrl;
				changeData.m_strOtherImageUrl = data.m_strOtherImageUrl;
				changeData.m_strOtherMSG = data.m_strOtherMSG;
				changeData.m_strRoomID = data.m_strRoomID;
				changeData.m_strSystemMSG = data.m_strSystemMSG;
				changeData.m_nNoReadCount = data.m_nNoReadCount;
				changeData.m_JsonObject = data.m_JsonObject;
				m_arrChatRoomData.remove(data);
				m_arrChatRoomData.add(changeData);
				break;
			}
		}
	}

	public void deleteResendMessage(ChatRoomData roomData){
		
		m_arrChatRoomData.remove(roomData);
					
	}
	public long getFirstTimeStamp() {
		for (ChatRoomData data : m_arrChatRoomData) {
			if (data.m_lDate != 0) {
				return data.m_lDate;
			}
		}
		return 0;
	}

	public void notifyDataSetChanged(){
		/*for (int x = m_arrChatRoomData.size() - 1; x >= 0; x--) {
			if (m_arrChatRoomData.get(x).) {

				break;
			}
		}*/
		ArrayList<ChatRoomData> tempChatRoomData = new ArrayList<ChatRoomData>();
		ArrayList<ChatRoomData> tempChatRoomFailData = new ArrayList<ChatRoomData>();
		int nDataSize = m_arrChatRoomData.size();
		for(int i = 0; i < nDataSize; i++){
			if(m_arrChatRoomData.get(i).m_nSendStatus != StaticString.CHAT_SEND_STATUS_FAIL){
				tempChatRoomData.add(m_arrChatRoomData.get(i));
			} else {
				tempChatRoomFailData.add(m_arrChatRoomData.get(i));
			}
		}
		m_arrChatRoomData = new ArrayList<ChatRoomData>(tempChatRoomData);
		m_arrChatRoomData.addAll(tempChatRoomFailData);

		super.notifyDataSetChanged();
	}
}
