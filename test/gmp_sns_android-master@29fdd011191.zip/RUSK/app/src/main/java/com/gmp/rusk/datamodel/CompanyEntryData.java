package com.gmp.rusk.datamodel;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-03.
 */

public class CompanyEntryData {

    public String strCode = "";
    public String strName = "";
    public ArrayList<Integer> arrMessageValidityPeriods = new ArrayList<Integer>();
    public boolean isPartnerRegularSearchEnabled = false;
    public boolean isPartnerChannelCreationEnabled = false;
    public boolean isRegularMobileImageSharingEnabled = false;
    public boolean isRegularMobileImageDownloadEnabled = false;
    public boolean isRegularMobileNormalFileSharingEnabled = false;
    public boolean isRegularMobileNormalFileDownloadEnabled = false;
    public boolean isRegularPcImageSharingEnabled = false;
    public boolean isRegularPcImageDownloadEnabled = false;
    public boolean isRegularPcNormalFileSharingEnabled = false;
    public boolean isRegularPcNormalFileDownloadEnabled = false;
    public boolean isPartnerMobileImageSharingEnabled = false;
    public boolean isPartnerMobileImageDownloadEnabled = false;
    public boolean isPartnerMobileNormalFileSharingEnabled = false;
    public boolean isPartnerMobileNormalFileDownloadEnabled = false;
    public boolean isPartnerPcImageSharingEnabled = false;
    public boolean isPartnerPcImageDownloadEnabled = false;
    public boolean isPartnerPcNormalFileSharingEnabled = false;
    public boolean isPartnerPcNormalFileDownloadEnabled = false;
    public boolean isregularTApiCallEnabled = false;

}
