package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

	public class RequestEx implements PacketExtension{
		public static final String NAMESPACE = "urn:xmpp:receipts";
		public static final String ELEMENT_NAME = "request";
		
		public RequestEx(){}

		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}

		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();
			buf.append("<request xmlns='").append(NAMESPACE).append("'/>");
			return buf.toString();
		}
		
		public static class Provider implements PacketExtensionProvider {

			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
	            parser.next();
//				final String id = parser.getText();
				// Advance to end of extension.
				while(parser.getEventType() != XmlPullParser.END_TAG) {
					parser.next();
				}

				return new RequestEx();
			}
		}
	}