package com.gmp.rusk.datamodel;

public class SetSuggestBoardFileData {

	
	public int m_nFileNo = -1;

	public String m_strURL = "";
	public String m_strPreviewURL = "";
	public String m_strFileName = "";
	public long m_lnFileSize = 0L;

}
