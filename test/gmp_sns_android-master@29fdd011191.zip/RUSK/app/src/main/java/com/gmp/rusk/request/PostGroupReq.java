package com.gmp.rusk.request;

import org.json.JSONObject;


import com.gmp.rusk.utils.CommonLog;

/**
 *	@author dym
 *			모임 생성 
 *			method : post
 */

public class PostGroupReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";

	private final String JSON_NAME = "name";
	
	private String m_strGroupName = "";
	
	public PostGroupReq(String a_strGroupName)
	{
		m_strGroupName = a_strGroupName;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_NAME, m_strGroupName);
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PostGroupReq.class.getSimpleName(), "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
