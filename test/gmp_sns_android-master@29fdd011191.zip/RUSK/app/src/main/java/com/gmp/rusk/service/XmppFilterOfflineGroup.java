package com.gmp.rusk.service;

import android.content.Context;


import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChattingMessageData;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.ChattingDBManagerForDelayMessage;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.extension.ClearEx;
import com.gmp.rusk.extension.DelayInformationTTalk;
import com.gmp.rusk.extension.EmoticonEx;
import com.gmp.rusk.extension.FileEx;
import com.gmp.rusk.extension.GroupNoticeEx;
import com.gmp.rusk.extension.KickEx;
import com.gmp.rusk.extension.OwnerEx;
import com.gmp.rusk.extension.QuitEx;
import com.gmp.rusk.extension.ReadEx;
import com.gmp.rusk.extension.RequestEx;
import com.gmp.rusk.extension.RoomTitleChangeEx;
import com.gmp.rusk.extension.UserEx;
import com.gmp.rusk.utils.LocalAesCrypto;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;

public class XmppFilterOfflineGroup extends XmppFilterMessage{

	private LinkedList<Packet> m_QueuePacket;
	com.gmp.rusk.db.RoomDBManager m_DelayRoomDB;
	com.gmp.rusk.db.ContactsDBManager m_ContactsDBManager;
	ChattingDBManagerForDelayMessage m_DelayMessageDB;
	
	Context m_Context;
	long m_lEditTime;
	
	public XmppFilterOfflineGroup(Context context, Long a_lTime, ChattingDBManagerForDelayMessage a_DelayMessageDB, com.gmp.rusk.db.RoomDBManager a_DelayRoomDB, com.gmp.rusk.db.ContactsDBManager a_ContactsDBManager){
		
		m_DelayMessageDB = a_DelayMessageDB;
		m_DelayRoomDB = a_DelayRoomDB;
		m_ContactsDBManager = a_ContactsDBManager;
		m_Context = context;
		m_lEditTime = a_lTime;
		m_QueuePacket = new LinkedList<Packet>();
		App.m_arrKickRoomInfo = new ArrayList<ArrayList<String>>();
		setContext(context);
	}
	
	public LinkedList<Packet> getQueue() {
		return m_QueuePacket;
	}
	
	public void clearQueue() {
		m_QueuePacket.clear();
	}
	
	public void setFilterGroup(final Packet message){
		
		PacketExtension packetExtensionReceq = message.getExtension(RequestEx.NAMESPACE);
		PacketExtension packetExtensionRead = message.getExtension(ReadEx.NAMESPACE);
		UserEx userEx = (UserEx) message.getExtension(UserEx.NAMESPACE);
		QuitEx quitEx = (QuitEx) message.getExtension(QuitEx.NAMESPACE);
		KickEx kickEx = (KickEx) message.getExtension(KickEx.NAMESPACE);
		OwnerEx ownerEx = (OwnerEx) message.getExtension(OwnerEx.NAMESPACE);
		ClearEx clearEx = (ClearEx) message.getExtension(ClearEx.NAMESPACE);
		FileEx fileEx = (FileEx) message.getExtension(FileEx.NAMESPACE);
		EmoticonEx emoticonEx = (EmoticonEx) message.getExtension(EmoticonEx.NAMESPACE);
		GroupNoticeEx groupNoticeEx = (GroupNoticeEx) message.getExtension(GroupNoticeEx.NAMESPACE);
		RoomTitleChangeEx roomTitleChangeEx = (RoomTitleChangeEx) message.getExtension(RoomTitleChangeEx.NAMESPACE);

		if (message.getError() != null) {
			if (message.getError().getCode() == 404) {

			}
		}  else if (!message.getFrom().equals("cork.com") && (message.getFrom().split("@")[1]).split("/")[0].equals("groupchat.cork.com")) {
			ArrayList<Integer> arrCheckUser = new ArrayList<Integer>();

			arrCheckUser = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]);
			if (userEx != null || arrCheckUser.size() > 0) {
				// 파일 전송
				if (fileEx != null) {
					if (fileEx.getElementName().equals(FileEx.ELEMENT_NAME)) {

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

						ArrayList<Integer> arrId = new ArrayList<Integer>();

						if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_NORMAL)) {
							if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							} else {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							}
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 이미지 라면 추가로 width, height, 썸네일
						// url도 추가한다
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_IMAGE)) {
							if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_IMAGE;
							} else {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_IMAGE;
							}
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strWidth = fileEx.getWidth();
							utils.strHeight = fileEx.getHeight();
							utils.strThumb = fileEx.getThumb();
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						// 동영상일 경우 fileName에 "" 을 넣도록
						// 한다.(ios에서 어떤 값을 보내더라도 무시하기 위함)
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_VIDEO)) {
							if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							} else {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							}
							String strCreateTime = "";
							if (fileEx.getCreateTime() != null && !fileEx.getCreateTime().equals("0")) {
								strCreateTime = fileEx.getCreateTime();
							} else {
								strCreateTime = Long.toString(delay.getStamp().getTime());
							}
							XmppUtils utils = new XmppUtils();
							utils.strMimeType = fileEx.getMimetype();
							utils.strCreateTime = strCreateTime;
							utils.strUrl = fileEx.getUrl();
							utils.strThumb = fileEx.getThumb();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}
						else if (fileEx.getMimetype() != null && fileEx.getMimetype().equals(StaticString.FILE_TYPE_CONTACT)) {
							if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_FILE;
							} else {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_FILE;
							}
							XmppUtils utils = new XmppUtils();
							utils.strFileName = fileEx.getFileName();
							utils.strMimeType = fileEx.getMimetype();
							utils.strUrl = fileEx.getUrl();
							utils.strVdi = fileEx.getVdi();
							a_chattingMsgData.m_strMsgText = utils.getFileExText();
						}

						if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
							a_chattingMsgData.m_nSendUserId = 0;
						} else {
							a_chattingMsgData.m_nSendUserId = Integer.parseInt(message.getFrom().split("/")[1]);
						}
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
						if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
							a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 1;
							a_chattingMsgData.m_isRead = true;
						} else {
							a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 2;
						}

						int nResult = 0;
						if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
							if(delay.getStamp().getTime() > m_lEditTime)
							nResult = m_DelayMessageDB.updateChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
							if(nResult == 0)
								m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
						} else {
							if(delay.getStamp().getTime() > m_lEditTime)
							nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
						}
						if(nResult != -1){
						Packet receivePacket = new Packet() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
								StringBuilder buf = new StringBuilder();
								buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
								buf.append("\" id=\"").append(strPacketID);
								buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
								buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
								buf.append("</message>");

								return buf.toString();
							}
						};
						m_QueuePacket.add(receivePacket);
						}

					}
				}

				else if (userEx != null) {
					if (userEx.getElementName().equals(UserEx.ELEMENT_NAME)) {

						if (userEx.getOwnerUser() != null) {
							// 방장 포함 아이디 리스트
							// 자신이 그룹방을 나간 뒤, 앱 삭제, 그리고 초대를
							// 받았을때 방에 중복으로 보이는 문제 해결을 위함

							ArrayList<String> arrStrTempUserIDList = new ArrayList<String>(userEx.getUsers());
							arrStrTempUserIDList.add(userEx.getOwnerUser());
							ArrayList<String> arrStrUserIdList = new ArrayList<String>(arrStrTempUserIDList);

							ArrayList<Integer> arrUserIdList = new ArrayList<Integer>();

							ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
							ArrayList<Integer> arrDBSetUserIdList = new ArrayList<Integer>();
							for (String user : arrStrUserIdList) {
								arrUserIdList.add(Integer.parseInt(user));
								UserListData data = m_ContactsDBManager.getContacts(Integer.parseInt(user));
								if (data != null) {
									arrUserListData.add(data);
								} else {
									arrDBSetUserIdList.add(Integer.parseInt(user));
								}

							}

							if (!arrDBSetUserIdList.isEmpty()) {
								int[] arrDBsetUser = new int[arrDBSetUserIdList.size()];
								for (int i = 0; i < arrDBSetUserIdList.size(); i++) {
									arrDBsetUser[i] = arrDBSetUserIdList.get(i);
								}
								CountDownLatch latch = new CountDownLatch(1);
								requestAddedByUserList(arrDBsetUser, latch);

								try {
									latch.await();

								} catch (InterruptedException e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}
								for (UserListData userListData : m_arrDBSetUser) {
									arrUserListData.add(userListData);
								}
							}

							ArrayList<String> arrTitleName = new ArrayList<String>();
							StringBuffer title = new StringBuffer();
							for (int i = 0; i < arrUserListData.size(); i++) {
								if(arrUserListData.get(i) == null){
									arrTitleName.add(m_Context.getString(R.string.not_in_db_user));
								} else {
									arrTitleName.add(arrUserListData.get(i).m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}
							}
							
							Collections.sort(arrTitleName, Utils.nameComparator);
							
							for (int i = 0; i < arrTitleName.size(); i++) {

								title.append(arrTitleName.get(i));
								
								if (i != arrTitleName.size() - 1) {
									title.append(", ");
								}
							}
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							final long lTime = delay.getStamp().getTime();

							boolean isAlreadyMakeRoom = false;
							// 최초 접속시 방생성하고 유저 등록 했다면, 건너뜀(딜레이드 메세지 일때)
							if (delay.getType() != null && delay.getIdx() != null) {
								if (delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) || delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)) {
									SharedPref pref = SharedPref.getInstance(m_Context);

									if (pref.getLongPref(message.getFrom().split("@")[0], 0) > lTime) {
										isAlreadyMakeRoom = true;
									}

								}
							}
							// 방 만들고 채팅 유저 등록

							int nDBResult = 0;
							if (!isAlreadyMakeRoom) {
								ChattingRoomInfoData roomInfoData;
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									if (userEx.getRoomName() != null) {
										if(userEx.getImage() != null) {
											roomInfoData = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(userEx.getRoomName()),
													true, Integer.parseInt(userEx.getOwnerUser()), true,userEx.getImage());
										} else {
											roomInfoData = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(userEx.getRoomName()),
													true, Integer.parseInt(userEx.getOwnerUser()), true);
										}
										m_DelayRoomDB.insertRoom(roomInfoData);
									} else {
										roomInfoData = new ChattingRoomInfoData(message.getFrom().split("@")[0], crypto.encrypt(title.toString()), true,
												Integer.parseInt(userEx.getOwnerUser()), false);
										m_DelayRoomDB.insertRoom(roomInfoData);
									}
								} catch (NumberFormatException e) {
									// TODO Auto-generated catch
									// block
									e.printStackTrace();
								} catch (Exception e) {
									// TODO Auto-generated catch
									// block
									e.printStackTrace();
								}
								nDBResult = m_DelayMessageDB.insertChattingUser(message.getFrom().split("@")[0], arrUserIdList);
								
							} else {
								nDBResult = 0;

							}
							// 그룹 채팅방을 본인이 만들었다면
							if (nDBResult != -1) {

								// 그룹채팅 방 최초 생성
								// 초대 메시지 삽입
								String pattern = "a h:mm";
								UserListData userData;
								SimpleDateFormat format = new SimpleDateFormat(pattern);
								String date = (String) format.format(new Timestamp(lTime));
								ArrayList<String> userName = new ArrayList<String>();
								for (int i = 0; i < arrUserIdList.size(); i++) {
									if (arrUserIdList.get(i) != Integer.parseInt(userEx.getOwnerUser())) {
										userData = (m_ContactsDBManager.getContacts(arrUserIdList.get(i)));
										if(userData == null){
											userName.add(m_Context.getString(R.string.not_in_db_user));
										} else {
											userName.add(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
										}
									}
								}
								// 초대자 이름
								UserListData userInviter = null;
								if (message.getFrom().split("@")[1].equals("groupchat.cork.com")) {
									userInviter = (m_ContactsDBManager.getContacts(Integer.parseInt(userEx.getOwnerUser())));
								} else {
									userInviter = (m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("/")[1])));
								}

								String strInviterName;
								
								if(userInviter == null){
									strInviterName = m_Context.getString(R.string.not_in_db_user);
								} else {
									strInviterName= (userInviter.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}

								String userList = "";
								for (int j = 0; j < userName.size(); j++) {
									userList += userName.get(j) + m_Context.getString(R.string.chatroom_korean_user);
									if (j != userName.size() - 1 && j != 9) {
										userList += m_Context.getString(R.string.chatroom_comma);
									}
									if (j == 9 && userName.size() > 10) {
										break;
									}
								}
								ChattingMessageData data = new ChattingMessageData();
								if (userName.size() < 11) {
									data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_inviteuser_over_ten), strInviterName, userList) + date;
								} else {
									data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_inviteuser_under_ten), strInviterName, userList, (userName.size() - 10)) + date;
								}
								data.m_nMsgType = 1;
								data.m_isRead = true;
								data.m_strMsgId = message.getPacketID();
								data.m_lnMsgSendTime = lTime;

								// 앱 삭제후 방 재생성시 초대 받을 대상이 모두
								// 방안에 있다면
								int nDBResult2 = 0;
								if (!arrStrUserIdList.isEmpty()) {
									if (!userList.equals("")) {
										if(delay.getStamp().getTime() > m_lEditTime)
										nDBResult2 = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
									}
								}

								if (nDBResult2 != -1) {
									int nDBResult3 = 0;
									if (((Message) message).getBody() != null) {

										data.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;

										data.m_strMsgId = data.m_strMsgId + "a";
										data.m_lnMsgSendTime += 1;
										// 앱 삭제후 방 재생성시 초대
										// 받을 대상이 모두 방안에 있다면

										if (!arrStrUserIdList.isEmpty()) {
											if(delay.getStamp().getTime() > m_lEditTime)
											nDBResult3 = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
										}

									}
									arrStrUserIdList = new ArrayList<String>();
									
									if(nDBResult3 != -1){
									Packet receivePacket = new Packet() {

										@Override
										public String toXML() {
											// TODO
											// Auto-generated
											// method
											// stub
											final String strPacketID = Long.toString(System.currentTimeMillis()) + "_"
													+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
											StringBuilder buf = new StringBuilder();
											buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
													.append(SERVICE_NAME);
											buf.append("\" id=\"").append(strPacketID);
											buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
											buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
											buf.append("</message>");

											return buf.toString();
										}
									};
									m_QueuePacket.add(receivePacket);
									}

								}
							}

						} else {
							// 기존 방에서 초대시
							// 자신이 그룹방을 나간 뒤, 앱 삭제, 그리고 초대를
							// 받았을때 방에 중복으로 보이는 문제 해결을 위함
							ArrayList<String> arrStrTempUserIDList = new ArrayList<String>(userEx.getUsers());
							ArrayList<String> arrStrUserIdListNoOwner = new ArrayList<String>(userEx.getUsers());

							ArrayList<Integer> arrUserIdListNoOwner = new ArrayList<Integer>();
							ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();
							ArrayList<Integer> arrDBSetUserIdList = new ArrayList<Integer>();
							for (String user : arrStrUserIdListNoOwner) {
								arrUserIdListNoOwner.add(Integer.parseInt(user));

								UserListData data = m_ContactsDBManager.getContacts(Integer.parseInt(user));
								if (data != null) {
									arrUserListData.add(data);
								} else {
									arrDBSetUserIdList.add(Integer.parseInt(user));
								}
							}
							if (!arrDBSetUserIdList.isEmpty()) {

								int[] arrDBsetUser = new int[arrDBSetUserIdList.size()];
								for (int i = 0; i < arrDBSetUserIdList.size(); i++) {
									arrDBsetUser[i] = arrDBSetUserIdList.get(i);
								}
								CountDownLatch latch = new CountDownLatch(1);
								requestAddedByUserList(arrDBsetUser, latch);

								try {
									latch.await();

								} catch (InterruptedException e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}
								for (UserListData userListData : m_arrDBSetUser) {
									arrUserListData.add(userListData);
								}
							}
							String strNewTitle = "";

							ChattingRoomInfoData roomInfoData = m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]);
							if (roomInfoData != null) {
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									strNewTitle = crypto.decrypt(roomInfoData.m_strRoomTitle);
								} catch (Exception e1) {
									// TODO Auto-generated catch
									// block
									e1.printStackTrace();
								}
							}

							ArrayList<String> arrTitleName = new ArrayList<String>();
							String[] arrTitle = strNewTitle.split(", ");
							for(int ab = 0; ab < arrTitle.length; ab++){
								arrTitleName.add(arrTitle[ab]);
							}
							
							StringBuffer strAddTitle = new StringBuffer();
							for (int i = 0; i < arrUserListData.size(); i++) {
								if(arrUserListData.get(i) == null){
									arrTitleName.add(m_Context.getString(R.string.not_in_db_user));
								} else {
									arrTitleName.add(arrUserListData.get(i).m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}
							}

							Collections.sort(arrTitleName, Utils.nameComparator);
							
							for (int i = 0; i < arrTitleName.size(); i++) {

								strAddTitle.append(arrTitleName.get(i));
								
								if (i != arrTitleName.size() - 1) {
									strAddTitle.append(", ");
								}
							}
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							final long lTime = delay.getStamp().getTime();

							boolean isAlreadyMakeRoom = false;
							// 최초 접속시 방생성하고 유저 등록 했다면, 건너뜀(딜레이드 메세지 일때)
							if (delay.getType() != null && delay.getIdx() != null) {
								if (delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) || delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)) {
									SharedPref pref = SharedPref.getInstance(m_Context);

									if (pref.getLongPref(message.getFrom().split("@")[0], 0) > lTime) {
										isAlreadyMakeRoom = true;
									}
								}
							}

							int nDBResult = 0;
							if (!isAlreadyMakeRoom) {
								nDBResult = m_DelayMessageDB.insertChattingUser(message.getFrom().split("@")[0], arrUserIdListNoOwner);
							} else {
								nDBResult = 0;
							}
							if (nDBResult != -1) {
								if (m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]) != null
										&& !m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]).m_isTitleEdited)
									try {
										LocalAesCrypto crypto = new LocalAesCrypto();
										m_DelayRoomDB.updateRoom(message.getFrom().split("@")[0], crypto.encrypt(strAddTitle.toString()), false);
									} catch (Exception e) {
										// TODO
										// Auto-generated
										// catch block
										e.printStackTrace();
									}

								// 초대 메시지 삽입
								String pattern = "a h:mm";
								UserListData userData;
								SimpleDateFormat format = new SimpleDateFormat(pattern);
								String date = (String) format.format(new Timestamp(lTime));
								ArrayList<String> userName = new ArrayList<String>();
								for (int i = 0; i < arrUserIdListNoOwner.size(); i++) {
									userData = (m_ContactsDBManager.getContacts(arrUserIdListNoOwner.get(i)));
									if(userData == null){
										userName.add(m_Context.getString(R.string.not_in_db_user));
									} else {
										userName.add(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
									}							
								}

								// 초대자 이름
								UserListData userInviter = (m_ContactsDBManager.getContacts(Integer.parseInt(message.getFrom().split("/")[1])));
								String strInviterName;
								if(userInviter == null){
									strInviterName = m_Context.getString(R.string.not_in_db_user);
								} else {
									strInviterName = userInviter.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								}
								String userList = "";
								for (int j = 0; j < userName.size(); j++) {
									userList += userName.get(j) + m_Context.getString(R.string.chatroom_korean_user);
									if (j != userName.size() - 1 && j != 9) {
										userList += m_Context.getString(R.string.chatroom_comma);
									}
									if (j == 9 && userName.size() > 10) {
										break;
									}
								}
								ChattingMessageData data = new ChattingMessageData();
								if (userName.size() < 11) {
									data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_inviteuser_over_ten), strInviterName, userList) + date;
								} else {
									data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_inviteuser_under_ten), strInviterName, userList, (userName.size() - 10)) + date;
								}
								data.m_nMsgType = 1;
								data.m_isRead = true;
								data.m_strMsgId = message.getPacketID();
								data.m_lnMsgSendTime = lTime;

								// 앱 삭제후 방 재생성시 초대 받을 대상이 모두
								// 방안에 있다면
								int nDBResult2 = 0;
								if (!arrStrUserIdListNoOwner.isEmpty()) {
									if (!userList.equals("")) {
										if(delay.getStamp().getTime() > m_lEditTime)
										nDBResult2 = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
									}
								}

								if (nDBResult2 != -1) {
									int nDBResult3 = 0;
									if (((Message) message).getBody() != null) {

										data.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;

										data.m_strMsgId = data.m_strMsgId + "a";
										data.m_lnMsgSendTime += 1;
										// 앱 삭제후 방 재생성시 초대
										// 받을 대상이 모두 방안에 있다면
										if (!arrStrUserIdListNoOwner.isEmpty()) {
											if(delay.getStamp().getTime() > m_lEditTime)
											nDBResult3 = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
										}

									}

								
								if(nDBResult3 != -1){
								Packet receivePacket = new Packet() {

									@Override
									public String toXML() {
										// TODO
										// Auto-generated
										// method
										// stub
										final String strPacketID = Long.toString(System.currentTimeMillis()) + "_"
												+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
										StringBuilder buf = new StringBuilder();
										buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
												.append(SERVICE_NAME);
										buf.append("\" id=\"").append(strPacketID);
										buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
										buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
										buf.append("</message>");

										return buf.toString();
									}
								};
								m_QueuePacket.add(receivePacket);
								}
								}
							}

						}
					}
				}
				// 방장 전달

				// 방 나가기
				else if (quitEx != null) {

					if (quitEx.getElementName().equals(QuitEx.ELEMENT_NAME)) {

						if (quitEx.getUser().equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))) {

							Packet receivePacket = new Packet() {

								@Override
								public String toXML() {
									// TODO Auto-generated
									// method stub
									final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
									StringBuilder buf = new StringBuilder();
									buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
											.append(SERVICE_NAME);
									buf.append("\" id=\"").append(strPacketID);
									buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
									buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
									buf.append("</message>");

									return buf.toString();
								}
							};
							m_QueuePacket.add(receivePacket);

							m_DelayRoomDB.deleteRoom(message.getFrom().split("@")[0]);
							App.m_isRoomDelete = true;

							m_DelayMessageDB.deleteChattingMessage(message.getFrom().split("@")[0]);
							m_DelayMessageDB.deleteChattingUser(message.getFrom().split("@")[0]);

						} else {
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							String pattern = "a h:mm";
							long lTime = delay.getStamp().getTime();
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(lTime));

							boolean isAlreadyMakeRoom = false;
							// 최초 접속시 방생성하고 유저 등록 했다면, 건너뜀(딜레이드 메세지 일때)

							if (delay.getType() != null && delay.getIdx() != null) {
								if (delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) || delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)) {
									SharedPref pref = SharedPref.getInstance(m_Context);

									if (pref.getLongPref(message.getFrom().split("@")[0], 0) > lTime) {
										isAlreadyMakeRoom = true;
									}
								}
							}
							if (!isAlreadyMakeRoom) {
								m_DelayMessageDB.deleteChattingUser(message.getFrom().split("@")[0], Integer.parseInt(quitEx.getUser()));
							}

							ArrayList<Integer> arrNowChatUser = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]);	
							
							ArrayList<String> arrTitleName = new ArrayList<String>();
							StringBuffer title = new StringBuffer();
							for (int i = 0; i < arrNowChatUser.size(); i++) {
								UserListData userListData = m_ContactsDBManager.getContacts(arrNowChatUser.get(i));
								if(userListData == null){
									arrTitleName.add(m_Context.getString(R.string.not_in_db_user));
								} else {
									arrTitleName.add(userListData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}
							}
							
							Collections.sort(arrTitleName, Utils.nameComparator);
							
							for (int i = 0; i < arrTitleName.size(); i++) {

								title.append(arrTitleName.get(i));
								
								if (i != arrTitleName.size() - 1) {
									title.append(", ");
								}
							}
							
							if (m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]) != null
									&& !m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]).m_isTitleEdited)
								try {
									LocalAesCrypto crypto = new LocalAesCrypto();
									m_DelayRoomDB.updateRoom(message.getFrom().split("@")[0], crypto.encrypt(title.toString()), false);
								} catch (Exception e) {
									// TODO Auto-generated
									// catch block
									e.printStackTrace();
								}

							ChattingMessageData data = new ChattingMessageData();

							data.m_strMsgText = "";
							data.m_nMsgType = 1;
							data.m_lnMsgSendTime = lTime;
							data.m_strMsgId = message.getPacketID();
							data.m_isRead = true;
							UserListData userData = m_ContactsDBManager.getContacts(Integer.parseInt(quitEx.getUser()));
							if (userData != null) {
								String strUserName = userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_exit), strUserName) + date;

								int nResult = 0;
								if(delay.getStamp().getTime() > m_lEditTime)
								nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);

								if(nResult != -1){
								Packet receivePacket = new Packet() {

									@Override
									public String toXML() {
										// TODO
										// Auto-generated
										// method stub
										final String strPacketID = Long.toString(System.currentTimeMillis()) + "_"
												+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
										StringBuilder buf = new StringBuilder();
										buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
												.append(SERVICE_NAME);
										buf.append("\" id=\"").append(strPacketID);
										buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
										buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
										buf.append("</message>");

										return buf.toString();
									}
								};
								m_QueuePacket.add(receivePacket);
								}

							} else {
								Packet receivePacket = new Packet() {

									@Override
									public String toXML() {
										// TODO
										// Auto-generated
										// method stub
										final String strPacketID = Long.toString(System.currentTimeMillis()) + "_"
												+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
										StringBuilder buf = new StringBuilder();
										buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
												.append(SERVICE_NAME);
										buf.append("\" id=\"").append(strPacketID);
										buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
										buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
										buf.append("</message>");

										return buf.toString();
									}
								};
								m_QueuePacket.add(receivePacket);
							}
						}
					}
				} else if (ownerEx != null) {

					if (ownerEx.getElementName().equals(OwnerEx.ELEMENT_NAME)) {
						ChattingRoomInfoData updateRoomData = m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]);

						if (updateRoomData != null && updateRoomData.m_nRoomOwnerId == App.m_MyUserInfo.m_nUserNo) {
							Packet receivePacket = new Packet() {

								@Override
								public String toXML() {
									// TODO Auto-generated
									// method stub
									final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
									StringBuilder buf = new StringBuilder();
									buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
											.append(SERVICE_NAME);
									buf.append("\" id=\"").append(strPacketID);
									buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
									buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
									buf.append("</message>");

									return buf.toString();
								}
							};
							m_QueuePacket.add(receivePacket);
						} else {

							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							String pattern = "a h:mm";
							long lTime = delay.getStamp().getTime();
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(lTime));
							boolean isAlreadyMakeRoom = false;
							// 최초 접속시 방생성하고 유저 등록 했다면, 건너뜀(딜레이드 메세지 일때)

							if (delay.getType() != null && delay.getIdx() != null) {
								if (delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) || delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)) {
									SharedPref pref = SharedPref.getInstance(m_Context);

									if (pref.getLongPref(message.getFrom().split("@")[0], 0) > lTime) {
										isAlreadyMakeRoom = true;
									}
								}
							}

							int nRoomResult = 0;
							if (!isAlreadyMakeRoom && updateRoomData != null) {

								nRoomResult = m_DelayRoomDB.updateRoom(message.getFrom().split("@")[0], Integer.parseInt(ownerEx.getUser()));
							}
							if(nRoomResult != -1){
							ChattingMessageData data = new ChattingMessageData();

							data.m_strMsgText = "";
							data.m_nMsgType = 1;
							data.m_lnMsgSendTime = lTime;
							data.m_isRead = true;
							data.m_strMsgId = message.getPacketID();
							UserListData userData = m_ContactsDBManager.getContacts(Integer.parseInt(ownerEx.getUser()));
							String strUserName;
							if(userData == null){
								strUserName = m_Context.getString(R.string.not_in_db_user);
							} else {
								strUserName = userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
							}						
							data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_owner)) + date;

							int nResult = 0;
							if(delay.getStamp().getTime() > m_lEditTime)
							nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);

							if(nResult != -1){
							Packet receivePacket = new Packet() {

								@Override
								public String toXML() {
									// TODO
									// Auto-generated
									// method stub
									final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
									StringBuilder buf = new StringBuilder();
									buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
											.append(SERVICE_NAME);
									buf.append("\" id=\"").append(strPacketID);
									buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
									buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
									buf.append("</message>");

									return buf.toString();
								}
							};
							m_QueuePacket.add(receivePacket);
							}
							}

						}
					}

				}
				// 추방
				else if (kickEx != null) {
					if (kickEx.getElementName().equals(KickEx.ELEMENT_NAME)) {

						// 강퇴시
						boolean isKickMe = false;

						for (String kickUser : kickEx.getUsers()) {
							if (Integer.parseInt(kickUser) == App.m_MyUserInfo.m_nUserNo) {
								isKickMe = true;
								break;
							}
						}
						// 자신이 아닐경우
						if (!isKickMe) {
							ArrayList<String> arrStrUserIdListNoOwner = kickEx.getUsers();
							ArrayList<Integer> arrUserIdListNoOwner = new ArrayList<Integer>();
							ArrayList<UserListData> arrUserListData = new ArrayList<UserListData>();

							for (String user : arrStrUserIdListNoOwner) {

								arrUserListData.add(m_ContactsDBManager.getContacts(Integer.parseInt(user)));

								arrUserIdListNoOwner.add(Integer.parseInt(user));
							}
							// 타이틀 재설정 필요
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							long lTime = delay.getStamp().getTime();

							boolean isAlreadyMakeRoom = false;
							// 최초 접속시 방생성하고 유저 등록 했다면, 건너뜀(딜레이드 메세지 일때)

							if (delay.getType() != null && delay.getIdx() != null) {
								if (delay.getType().equals(StaticString.MESSAGE_OFFLINE_TYPE) || delay.getIdx().equals(StaticString.MESSAGE_OFFLINE_IDX)) {
									SharedPref pref = SharedPref.getInstance(m_Context);

									if (pref.getLongPref(message.getFrom().split("@")[0], 0) > lTime) {
										isAlreadyMakeRoom = true;
									}
								}
							}
							if (!isAlreadyMakeRoom) {
								for (int nKickUser : arrUserIdListNoOwner) {
									m_DelayMessageDB.deleteChattingUser(message.getFrom().split("@")[0], nKickUser);
								}
							}
							ArrayList<Integer> newChattingUSerList = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]);
							StringBuffer strNewTitle = new StringBuffer();
							ArrayList<String> arrTitleName = new ArrayList<String>();
							
							for (int i = 0; i < newChattingUSerList.size(); i++) {
								UserListData userData = m_ContactsDBManager.getContacts(newChattingUSerList.get(i));
								if(userData == null){
									arrTitleName.add(m_Context.getString(R.string.not_in_db_user));
								} else {
									arrTitleName.add(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}
							}
							
							Collections.sort(arrTitleName, Utils.nameComparator);
							
							for (int i = 0; i < arrTitleName.size(); i++) {

								strNewTitle.append(arrTitleName.get(i));
								
								if (i != arrTitleName.size() - 1) {
									strNewTitle.append(", ");
								}
							}			

							// 강퇴 메시지 삽입
							String pattern = "a h:mm";
							UserListData userData;
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(lTime));
							ArrayList<String> userName = new ArrayList<String>();
							for (int i = 0; i < arrUserIdListNoOwner.size(); i++) {
								userData = (m_ContactsDBManager.getContacts(arrUserIdListNoOwner.get(i)));
								if(userData == null){
									userName.add(m_Context.getString(R.string.not_in_db_user));
								} else {
									userName.add(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
								}						
							}
							// 방장 이름
							UserListData userKicker = null;

							ChattingRoomInfoData roomData = m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]);
							int nResult = 0;
							if (roomData != null) {
								userKicker = (m_ContactsDBManager.getContacts(roomData.m_nRoomOwnerId));

								if (m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]) != null
										&& !m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]).m_isTitleEdited)
									try {
										LocalAesCrypto crypto = new LocalAesCrypto();
										m_DelayRoomDB.updateRoom(message.getFrom().split("@")[0], crypto.encrypt(strNewTitle.toString()), false);
									} catch (Exception e) {
										// TODO Auto-generated
										// catch block
										e.printStackTrace();
									}
								String strKickerName;
								if(userKicker == null){
									strKickerName = m_Context.getString(R.string.not_in_db_user);
								} else {
									strKickerName = userKicker.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								}
								String userList = "";

								for (int j = 0; j < userName.size(); j++) {
									userList += userName.get(j) + m_Context.getString(R.string.chatroom_korean_user);
									if (j != userName.size() - 1 && j != 9) {
										userList += m_Context.getString(R.string.chatroom_comma);
									}
									if (j == 9 && userName.size() > 10) {
										break;
									}
								}
								ChattingMessageData data = new ChattingMessageData();
								if (userName.size() < 11) {
									data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_kickuser_over_ten), strKickerName, userList) + date;
								} else {
									data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_kickuser_under_ten), strKickerName, userList, (userName.size() - 10)) + date;
								}
								data.m_nMsgType = 1;
								data.m_strMsgId = message.getPacketID();
								data.m_isRead = true;
								data.m_lnMsgSendTime = lTime;
								if(delay.getStamp().getTime() > m_lEditTime)
								nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
							}
							if(nResult != -1){
							Packet receivePacket = new Packet() {

								@Override
								public String toXML() {
									// TODO
									// Auto-generated
									// method stub
									final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
									StringBuilder buf = new StringBuilder();
									buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
											.append(SERVICE_NAME);
									buf.append("\" id=\"").append(strPacketID);
									buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
									buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
									buf.append("</message>");

									return buf.toString();
								}
							};

							m_QueuePacket.add(receivePacket);
							}

						}
						// 자신이 강퇴된 경우
						else {

							UserListData userKicker = null;
							// int nOwnerID = 0;
							String strKickerName = null;
							ChattingRoomInfoData roomData = m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]);

							if (roomData != null) {
								userKicker = (m_ContactsDBManager.getContacts(roomData.m_nRoomOwnerId));
								if(userKicker == null){
									strKickerName = m_Context.getString(R.string.not_in_db_user);
								} else {
									strKickerName = userKicker.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
								}
								
								m_DelayMessageDB.deleteChattingMessage(message.getFrom().split("@")[0]);
								m_DelayMessageDB.deleteChattingUser(message.getFrom().split("@")[0]);

								m_DelayRoomDB.deleteRoom(message.getFrom().split("@")[0]);
								App.m_isRoomDelete = true;
								ArrayList<String> arrKickRoomInfo = new ArrayList<String>();
								arrKickRoomInfo.add(strKickerName);
								arrKickRoomInfo.add(message.getFrom().split("@")[0]);
								App.m_arrKickRoomInfo.add(arrKickRoomInfo);
								
							}
							Packet receivePacket = new Packet() {

								@Override
								public String toXML() {
									// TODO Auto-generated
									// method stub
									final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
									StringBuilder buf = new StringBuilder();
									buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@")
											.append(SERVICE_NAME);
									buf.append("\" id=\"").append(strPacketID);
									buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
									buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
									buf.append("</message>");

									return buf.toString();
								}
							};
							m_QueuePacket.add(receivePacket);

						}
					}
				}
				// 초기화
				else if (clearEx != null) {
					if (clearEx.getElementName().equals(ClearEx.ELEMENT_NAME)) {

						m_DelayMessageDB.deleteChattingMessage(message.getFrom().split("@")[0]);

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
						long lTime = delay.getStamp().getTime();

						String pattern = "a h:mm";
						SimpleDateFormat format = new SimpleDateFormat(pattern);
						String date = (String) format.format(new Timestamp(lTime));

						// 방장 이름
						UserListData userClear = null;
						ChattingRoomInfoData roomData = m_DelayRoomDB.getChattingRoom(message.getFrom().split("@")[0]);

						int nResult = 0;
						if (roomData != null) {
							userClear = (m_ContactsDBManager.getContacts(roomData.m_nRoomOwnerId));
							String strClearName;
							if(userClear == null){
								strClearName = m_Context.getString(R.string.not_in_db_user);
							} else {
								strClearName = userClear.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
							}
							ChattingMessageData data = new ChattingMessageData();

							data.m_strMsgText = String.format(m_Context.getString(R.string.chatroom_clear), strClearName) + date;
							data.m_nMsgType = 1;
							data.m_strMsgId = message.getPacketID();
							data.m_isRead = true;
							data.m_lnMsgSendTime = lTime;
							if(delay.getStamp().getTime() > m_lEditTime)
							nResult = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], data);
						}						
						
						if(nResult != -1){
						Packet receivePacket = new Packet() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
								StringBuilder buf = new StringBuilder();
								buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
								buf.append("\" id=\"").append(strPacketID);
								buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
								buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
								buf.append("</message>");

								return buf.toString();
							}
						};
						m_QueuePacket.add(receivePacket);
						}
					}
				} else if(roomTitleChangeEx != null) {
					String bodyMsg = null;
					ChattingMessageData data = new ChattingMessageData();
					int nDBResult = 0;

					if((((Message) message).getBody())!=null)
						bodyMsg = (((Message) message).getBody()).toString();
					if(bodyMsg !=null) {
						ChattingDBManager chattingDBMng = new ChattingDBManager(m_Context);
						chattingDBMng.openWritable(message.getFrom().split("@")[0]);
						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
						long lTime = delay.getStamp().getTime();

						String pattern = "a h:mm";
						SimpleDateFormat format = new SimpleDateFormat(pattern);
						String date = (String) format.format(new Timestamp(lTime));
						data.m_strMsgText = bodyMsg+"\n" + date;
						data.m_nMsgType = 1;
						data.m_strMsgId = message.getPacketID();
						data.m_isRead = true;
						data.m_lnMsgSendTime = lTime;

					/*	if (delay.getStamp().getTime() > lnEditTime)*/
						nDBResult = chattingDBMng.insertMessage(data);
						chattingDBMng.close();
					}
					try {
						LocalAesCrypto crypto = new LocalAesCrypto();
						TTalkDBManager.RoomDBManager.updateRoom(m_Context,message.getFrom().split("@")[0],
								crypto.encrypt(roomTitleChangeEx.getRoomName()), true);
						/*if (mXmppListener.getNotifyListner() != null && mXmppListener.getPacketListener() == null && mXmppListener.getGroupPacketListener() == null) {
							mXmppListener.getNotifyListner().onTitleChanged();
						}*/
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(nDBResult != -1){
						Packet receivePacket = new Packet() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
								StringBuilder buf = new StringBuilder();
								buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
								buf.append("\" id=\"").append(strPacketID);
								buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
								buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
								buf.append("</message>");

								return buf.toString();
							}
						};
						m_QueuePacket.add(receivePacket);
					}

				} else if(groupNoticeEx !=null){
					int nDBResult = 0;
					int nDBResult2 = 0;

					String groupId  = groupNoticeEx.getGroupId();
					String boardNo = groupNoticeEx.getBoardNo();
					String text  = groupNoticeEx.getText();
					String imageCount = groupNoticeEx.getImageCount();
					String image = groupNoticeEx.getImage();
					String fileSize = groupNoticeEx.getFileSize();
					String fileCount = groupNoticeEx.getFileCount();
					String fileName = groupNoticeEx.getFileName();

					ChattingMessageData a_chattingMsgData;
					a_chattingMsgData = new ChattingMessageData();

					DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");

					a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SNS_NOTICE_MESSAGE;
					a_chattingMsgData.m_strMsgText = text;
					int sendUser = Integer.parseInt(message.getFrom().split("/")[1]);

					a_chattingMsgData.m_strMsgId = message.getPacketID();
					a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
					a_chattingMsgData.m_nSendUserId = sendUser;
					a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size()-1;
					ArrayList<String> addedList = new ArrayList<>();
					addedList.add(groupId);
					addedList.add(boardNo);
					addedList.add(imageCount);
					addedList.add(image);
					addedList.add(fileCount);
					addedList.add(fileSize);
					addedList.add(fileName);

					a_chattingMsgData.m_SNSNoticeAddedList = addedList;
					if(delay.getStamp().getTime() > m_lEditTime)
						nDBResult2 = m_DelayMessageDB.updateChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
					if(nDBResult2 == 0)
						m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);

					if (nDBResult != -1 && nDBResult2 != -1) {

						Packet receivePacket = new Packet() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
								StringBuilder buf = new StringBuilder();
								buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
								buf.append("\" id=\"").append(strPacketID);
								buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
								buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
								buf.append("</message>");

								return buf.toString();
							}
						};
						m_QueuePacket.add(receivePacket);

					}

				} else if (packetExtensionRead != null) {

					if (packetExtensionRead.getElementName().equals(ReadEx.ELEMENT_NAME)) {
//							ReadEx readEx = (ReadEx) message.getExtension(ReadEx.NAMESPACE);
//							// ArrayList<ReadCountData> arrReadCountData = new
//							// ArrayList<ReadCountData>();
//
//							HashMap<String, Boolean> mapNoReadMessageID = new HashMap<String, Boolean>();
//
//							for (String readId : readEx.getIds()) {
//								mapNoReadMessageID.put(readId, true);
//								// ReadCountData readCountData = new
//								// ReadCountData();
//								//
//								// ChattingMessageData chattingMsg =
//								// chattingDBMngd.getChattingMessage(readId);
//								// readCountData.m_strRoomId =
//								// message.getFrom().split("@")[0];
//								// readCountData.m_strMessageId = readId;
//								// readCountData.m_strCreateDate = "" +
//								// chattingMsg.m_lnMsgSendTime;
//								// readCountData.m_nCount =
//								// chattingMsg.m_nNoReadUserCount - 1;
//								// arrReadCountData.add(readCountData);
//							}
//							// chattingDBMngd.updateNoReadUserCount(arrReadCountData);
//							m_DelayMessageDB.updateReadMessage(message.getFrom().split("@")[0], mapNoReadMessageID);
//
//							// if (m_GroupPacketListener != null) {
//							// //
//							// m_GroupPacketListener.onPrintMessage(strPushMessage,
//							// // message.getFrom().split("@")[0],
//							// //
//							// Integer.parseInt(message.getFrom().split("/")[1]));
//							// m_GroupPacketListener.setReadMessage(message.getFrom().split("@")[0],
//							// readEx.getIds());
//							// }

					}
				} else if (packetExtensionReceq != null) {
					if (packetExtensionReceq.getElementName().equals(RequestEx.ELEMENT_NAME)) {

						String strPushMessage = "";

						int nDBResult2 = 0;
						boolean isSystemMessage = false;
						if (message.getFrom().split("/")[1].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))) {

							ChattingMessageData a_chattingMsgData;
							a_chattingMsgData = new ChattingMessageData();

							if (message.getExtension("info", "urn:xmpp:urgent") != null) {

								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;

							}
							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							if (message.getExtension("info", "urn:xmpp:event") != null) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
								String pattern = "a h:mm";
								SimpleDateFormat format = new SimpleDateFormat(pattern);
								String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
								if (((Message) message).getBody() != null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;

								a_chattingMsgData.m_isRead = true;
								isSystemMessage = true;
							} else {
								if(((Message) message).getBody()!=null)
									a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
								else
									a_chattingMsgData.m_strMsgText = "";
								if (emoticonEx !=null){
									a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
									a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
								}

							}

							ArrayList<Integer> readUser = new ArrayList<Integer>();

							a_chattingMsgData.m_nSendUserId = 0;
							a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
							a_chattingMsgData.m_strMsgId = message.getPacketID();
							a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();
							if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
								a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 1;
								a_chattingMsgData.m_isRead = true;
							} else {
								a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 2;
							}
							if(delay.getStamp().getTime() > m_lEditTime)
							nDBResult2 = m_DelayMessageDB.updateChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
							if(nDBResult2 == 0)
								m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
						} else {
							ChattingMessageData a_chattingMsgData;
							a_chattingMsgData = new ChattingMessageData();

							if (message.getExtension("info", "urn:xmpp:urgent") != null) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
							}

							DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
							if (message.getExtension("info", "urn:xmpp:event") != null) {
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
								String pattern = "a h:mm";
								SimpleDateFormat format = new SimpleDateFormat(pattern);
								String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
								if (((Message) message).getBody() != null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;
								a_chattingMsgData.m_isRead = true;
								isSystemMessage = true;
							} else {
								if(((Message) message).getBody()!=null)
									a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
								else
									a_chattingMsgData.m_strMsgText = "";
								if (emoticonEx !=null){
									a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
									a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
								}
							}

							int sendUser = Integer.parseInt(message.getFrom().split("/")[1]);

							a_chattingMsgData.m_strMsgId = message.getPacketID();
							a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();

							a_chattingMsgData.m_nSendUserId = sendUser;
							if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
								a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 1;
								a_chattingMsgData.m_isRead = true;
							} else {
								a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 2;
							}
							if(delay.getStamp().getTime() > m_lEditTime){
								nDBResult2 = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
							}
							strPushMessage = a_chattingMsgData.m_strMsgText;

						}
						if(nDBResult2 != -1){
						Packet receivePacket = new Packet() {

							@Override
							public String toXML() {
								// TODO Auto-generated
								// method stub
								final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
								StringBuilder buf = new StringBuilder();
								buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
								buf.append("\" id=\"").append(strPacketID);
								buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
								buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
								buf.append("</message>");

								return buf.toString();
							}
						};
						m_QueuePacket.add(receivePacket);
						}
					}
				}
						
				
				

				// received, request 등 아무것도 포함되지 않았을때
				else {
					String strPushMessage = "";
					int nDBResult2 = 0;
					boolean isSystemMessage = false;
					if (message.getFrom().split("/")[1].equals(Integer.toString(App.m_MyUserInfo.m_nUserNo))) {

						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();

						if (message.getExtension("info", "urn:xmpp:urgent") != null) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;
						}
						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
						if (message.getExtension("info", "urn:xmpp:event") != null) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
							String pattern = "a h:mm";
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
							if (((Message) message).getBody() != null)
							a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;

							a_chattingMsgData.m_isRead = true;
							isSystemMessage = true;
						} else {
							if(((Message) message).getBody()!=null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
							else
								a_chattingMsgData.m_strMsgText = "";
							if (emoticonEx !=null){
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_MY_EMOTICON_MESSAGE;
								a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
							}
						}

						ArrayList<Integer> readUser = new ArrayList<Integer>();

						a_chattingMsgData.m_nSendUserId = 0;
						a_chattingMsgData.m_nSendStatus = StaticString.CHAT_SEND_STATUS_SUCCESS;
						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();

						if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
							a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 1;
							a_chattingMsgData.m_isRead = true;
						} else {
							a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 2;
						}
						if(delay.getStamp().getTime() > m_lEditTime)
						nDBResult2 = m_DelayMessageDB.updateChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
						if(nDBResult2 == 0)
							m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
					} else {
						ChattingMessageData a_chattingMsgData;
						a_chattingMsgData = new ChattingMessageData();
						if (message.getExtension("info", "urn:xmpp:urgent") != null) {

							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_URGENT_MESSAGE;

						}

						DelayInformationTTalk delay = (DelayInformationTTalk) message.getExtension("delay", "urn:xmpp:delay");
						if (message.getExtension("info", "urn:xmpp:event") != null) {
							a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_SYSTEM_MSG;
							String pattern = "a h:mm";
							SimpleDateFormat format = new SimpleDateFormat(pattern);
							String date = (String) format.format(new Timestamp(delay.getStamp().getTime()));
							if (((Message) message).getBody() != null)
							a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody()) + "\n" + date;
							a_chattingMsgData.m_isRead = true;
							isSystemMessage = true;
						} else {
							if(((Message) message).getBody()!=null)
								a_chattingMsgData.m_strMsgText = Utils.unescapeXMLChars(((Message) message).getBody());
							else
								a_chattingMsgData.m_strMsgText = "";
							if (emoticonEx !=null){
								a_chattingMsgData.m_nMsgType = StaticString.CHAT_ROOM_OTHER_EMOTICON_MESSAGE;
								a_chattingMsgData.m_strEmoticon = emoticonEx.getEmoticonName();
							}
						}

						int sendUser = Integer.parseInt(message.getFrom().split("/")[1]);

						a_chattingMsgData.m_strMsgId = message.getPacketID();
						a_chattingMsgData.m_lnMsgSendTime = delay.getStamp().getTime();

						a_chattingMsgData.m_nSendUserId = sendUser;
						if (Integer.parseInt(message.getFrom().split("/")[1]) == App.m_MyUserInfo.m_nUserNo) {
							a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 1;
							a_chattingMsgData.m_isRead = true;
						} else {
							a_chattingMsgData.m_nNoReadUserCount = m_DelayMessageDB.getChattingUser(message.getFrom().split("@")[0]).size() - 2;
						}
						if(delay.getStamp().getTime() > m_lEditTime)
						nDBResult2 = m_DelayMessageDB.insertChattingMessage(message.getFrom().split("@")[0], a_chattingMsgData);
						strPushMessage = a_chattingMsgData.m_strMsgText;

					}
					if(nDBResult2 != -1){
					Packet receivePacket = new Packet() {

						@Override
						public String toXML() {
							// TODO Auto-generated
							// method stub
							final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
							StringBuilder buf = new StringBuilder();
							buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@").append(SERVICE_NAME);
							buf.append("\" id=\"").append(strPacketID);
							buf.append("\" to=\"").append(message.getFrom().split("@")[0]).append("@groupchat." + SERVICE_NAME).append("\">");
							buf.append("<received xmlns='urn:xmpp:receipts' ").append("id='").append(message.getPacketID()).append("'/>");
							buf.append("</message>");

							return buf.toString();
						}
					};
					m_QueuePacket.add(receivePacket);
					}
				}
			}
		}
	}
}
