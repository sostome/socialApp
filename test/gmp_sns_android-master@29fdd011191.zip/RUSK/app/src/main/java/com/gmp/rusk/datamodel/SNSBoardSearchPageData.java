package com.gmp.rusk.datamodel;

/**
 * Created by 강철 on 2016-04-19.
 */
public class SNSBoardSearchPageData {

    public int m_nSize = 0;
    public int m_nTotalElements = 0;
    public int m_nTotalPage = 0;
    public int m_nNumber = 0;
    
}
