package com.gmp.rusk.extension;

import java.util.ArrayList;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class UserEx implements PacketExtension {
	public static final String NAMESPACE = "urn:xmpp:groupchat:join";
	public static final String ELEMENT_NAME = "info";

	private ArrayList<String> users;
	private String image;
	private String owner_user;
	private String roomname;

	public UserEx() {
	}

	public UserEx(ArrayList<String> users, String owner_user, String roomname,String image) {
		this.users = users;
		this.owner_user = owner_user;
		this.roomname = roomname;
		this.image = image;
	}

	//
	//
	@Override
	public String getElementName() {
		// TODO Auto-generated method stub
		return ELEMENT_NAME;
	}

	@Override
	public String getNamespace() {
		// TODO Auto-generated method stub
		return NAMESPACE;
	}

	public ArrayList<String> getUsers() {
		return users;
	}

	public String getOwnerUser() {
		return owner_user;
	}
	
	public String getRoomName() {
		return roomname;
	}

	public String getImage() {
		return image;
	}

	@Override
	public String toXML() {
		// TODO Auto-generated method stub
		StringBuilder buf = new StringBuilder();
		// 1.5.5 에서 규격 수정됨

		// buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
		return buf.toString();
	}

	public static class Provider implements PacketExtensionProvider {

		public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
			ArrayList<String> users = new ArrayList<String>();
			String owner_user = null;
			String roomname = null;
			String image = null;
			boolean done = false;
			while (!done) {
				int eventType = parser.getEventType();
				if (eventType == XmlPullParser.START_TAG) {
					if (parser.getName().equals("user")) {
						if (parser.getAttributeCount() == 1) {
							owner_user = parser.nextText();
						} else {
							
							users.add(parser.nextText());
						}

					}
					else if(parser.getName().equals("image")){
						image = parser.nextText();
					}
					else if (parser.getName().equals("roomname")){
						roomname = parser.nextText();
					}
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals(ELEMENT_NAME)) {
						done = true;
					}
				}
				if (!done)
					parser.next();
			}
			return new UserEx(users, owner_user, roomname,image);
		}
	}
}