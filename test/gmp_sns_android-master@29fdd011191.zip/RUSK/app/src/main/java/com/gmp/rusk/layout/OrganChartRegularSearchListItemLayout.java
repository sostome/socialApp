package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;


import com.gmp.rusk.R;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.datamodel.DepartmentUserListData;
import com.gmp.rusk.datamodel.FellowRedactionListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

/**
 * FellowListItemLayout
 * 동료 리스트 Item Layout
 */
public class OrganChartRegularSearchListItemLayout extends CustomLinearLayout implements OnClickListener, OnCheckedChangeListener{
	
	private Context m_Context;
	
	private DepartmentUserListData m_DepartmentUserListData = null;
	
	private OnCheckedChangedListener m_CheckedChangeListener = null;
	
	CheckBox cb_redaction;
	
	public OrganChartRegularSearchListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public OrganChartRegularSearchListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context a_Context)
	{
		m_Context = a_Context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listitem_fellow_checkbox, this);
	}
	
	public void setFellowRedactionListData(DepartmentUserListData a_Data)
	{
		m_DepartmentUserListData = a_Data;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		ImageView iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
		iv_profile_pic.setOnClickListener(this);
		ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);

		if(m_DepartmentUserListData.getImageAvailable())
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_DepartmentUserListData.getUserNo(), true), R.drawable.profile_pic_default, false);
		}
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}

		TextView tv_name = (TextView)findViewById(R.id.tv_name);
		TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
		LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
		TextView tv_position = (TextView) findViewById(R.id.tv_position);
		LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
		TextView tv_charge = (TextView) findViewById(R.id.tv_charge);
		tv_name.setText(m_DepartmentUserListData.getName());

		if(m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_DepartmentUserListData.m_strPosition !=null && !m_DepartmentUserListData.m_strPosition.equals("")){
			layout_position.setVisibility(VISIBLE);
			tv_position.setText(m_DepartmentUserListData.m_strPosition);
		} else {
			layout_position.setVisibility(GONE);
		}

		if(m_DepartmentUserListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_DepartmentUserListData.m_strCharge!=null && !m_DepartmentUserListData.m_strCharge.equals("")){
			layout_charge.setVisibility(VISIBLE);
			tv_charge.setText(m_DepartmentUserListData.m_strCharge);
		} else {
			layout_charge.setVisibility(GONE);
		}

		if(m_DepartmentUserListData.getAvailable())
		{
			tv_uninstall.setVisibility(GONE);
		}
		else
		{
			tv_uninstall.setVisibility(VISIBLE);
		}

		TextView tv_departments = (TextView)findViewById(R.id.tv_departments);

		tv_departments.setText(m_DepartmentUserListData.m_strDepartment+" | "+m_DepartmentUserListData.m_strCompanyName);

		RelativeLayout layout_listitem_search = (RelativeLayout)findViewById(R.id.layout_listitem_redaction);
		layout_listitem_search.setOnClickListener(this);
		
		
		//CommonLog.e("","App.m_EntryData.m_nUserNo : " + App.m_EntryData.m_nUserNo);
		//CommonLog.e("","m_DepartmentUserListData.getUserNo() : " + m_FellowRedactionListData.m_nUserNo);
		
		cb_redaction = (CheckBox)findViewById(R.id.cb_user);
		cb_redaction.setOnCheckedChangeListener(this);
		
		if(App.m_EntryData.m_nUserNo == m_DepartmentUserListData.m_nUserNo || !m_DepartmentUserListData.m_isAvailable)
			cb_redaction.setVisibility(View.INVISIBLE);
		else
			cb_redaction.setVisibility(View.VISIBLE);
		
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.layout_listitem_redaction) {
			//doShowProfile();
			if(cb_redaction.getVisibility() == View.VISIBLE && cb_redaction.isChecked())
				cb_redaction.setChecked(false);
			else if(cb_redaction.getVisibility() == View.VISIBLE && !cb_redaction.isChecked())
				cb_redaction.setChecked(true);
		} else if(v.getId() == R.id.iv_profile_pic) {
			doShowProfile();
		}
	}
	
	private void doShowProfile()
	{
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_DepartmentUserListData.m_nUserNo);
		m_Context.startActivity(intent);
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if(buttonView.getId() == R.id.cb_user)
		{
			if(isChecked)
			{
				m_DepartmentUserListData.m_isChecked = true;
				m_CheckedChangeListener.onChecked(true, m_DepartmentUserListData);
			}
			else
			{
				m_DepartmentUserListData.m_isChecked = false;
				m_CheckedChangeListener.onChecked(false, m_DepartmentUserListData);
			}
		}
	}
	
	
	public void setCheckedChangedListener(OnCheckedChangedListener a_Listener)
	{
		m_CheckedChangeListener = a_Listener;
	}

	public interface OnCheckedChangedListener {
        public void onChecked(boolean a_isChecked, DepartmentUserListData fellowRedactionListData);
    }
}
