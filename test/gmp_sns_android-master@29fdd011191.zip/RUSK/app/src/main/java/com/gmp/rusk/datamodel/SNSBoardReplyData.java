package com.gmp.rusk.datamodel;

import java.util.ArrayList;

public class SNSBoardReplyData {

	public int m_nGroupId = 0;
	public int m_nBoardNo = 0;
	public int m_nReplyNo = 0;

}
