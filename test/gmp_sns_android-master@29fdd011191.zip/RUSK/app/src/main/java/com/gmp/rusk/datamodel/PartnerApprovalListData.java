package com.gmp.rusk.datamodel;

public class PartnerApprovalListData {
	int m_nUserNo = 0;					//사용자 번호
	String m_strName = "";				//사용자 이름
	String m_strCompany = "";			//파트너 소속
	
	public PartnerApprovalListData(int a_nUserNo, String a_strName, String a_strCompany) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		m_strCompany = a_strCompany;
	}
}
