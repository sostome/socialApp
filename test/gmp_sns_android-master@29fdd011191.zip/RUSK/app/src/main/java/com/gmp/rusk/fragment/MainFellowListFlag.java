package com.gmp.rusk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.layout.FellowListItemLayout;
import com.gmp.rusk.listview.SectionListAdapter;
import com.gmp.rusk.listview.SectionListItem;
import com.gmp.rusk.listview.SectionListView;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetUserListReq;
import com.gmp.rusk.response.GetUserListRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.SoundSearcher;
import com.gmp.rusk.utils.StringMatcher;
import com.gmp.rusk.utils.Utils;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;

import me.thanel.swipeactionview.SwipeActionView;

/**
 * MainFellowListFlag
 * 
 * @author subi78 MainTabAct - 동료리스트 Fragment
 */
public class MainFellowListFlag extends Fragment implements OnClickListener {
	public MyApp App = MyApp.getInstance();
	private View m_vFellowList = null;

	private FragmentActivity m_Activity = null;

	private SectionListView m_lvFellowList = null;
	private FellowListAdapter m_FellowListAdapter = null;
	//private SearchFellowListAdapter m_SearchFellowListAdapter = null;
	private SectionListAdapter m_SectionListAdapter = null;
	FrameLayout m_layoutSearchFellow = null;
	LinearLayout m_layoutNoList = null;
	LinearLayout m_layoutNoFriend = null;
	private ArrayList<SectionListItem> m_SectionListItems = null; // SectionListView
																	// 에 넣는 Item
																	// 생성

	// private ArrayList<UserListData> m_arrAddedFellowListData = null;
	private ArrayList<FellowListData> m_arrNewFellowListData = null;

	private ArrayList<FellowListData> m_arrSearchFellowListData = null;

	private SectionListItem item = null;

	Spinner spn_search_type;

	EditText et_search_keyword;
	ImageButton ib_cancel;

	private LinearLayout m_layoutQuickSearch = null;
	private TextView m_tvQuickSearchIndex = null;

	private InputMethodManager imm;

	int nState = 0;
	final int GONE_SEARCH = 0;
	final int VISIBLE_SEARCH = 1;
	final int REMOVE_SEARCH = 2;
	final int GONE_STOP = 3; // 색인 검색시..

	private CommonPopup m_Popup = null;

	private ProgressDlg m_Progress = null;

	static MainFellowListFlag newInstance() {
		MainFellowListFlag f = new MainFellowListFlag();
		return f;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		m_Activity = getActivity();
		// XmppConnection xmpp = new XmppConnection(App.m_MyUserInfo.m_nUserNo,
		// m_Activity);
		imm = (InputMethodManager) m_Activity.getSystemService(Context.INPUT_METHOD_SERVICE);
	}

	/**
	 * The Fragment's UI is just a simple text view showing its instance number.
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

		m_vFellowList = inflater.inflate(R.layout.fragact_fellowlist, container, false);

		requestUpdateUserList();
		//initSearch();
		//initSectionListViewUi();
		//initQuickSearch();
		return m_vFellowList;
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		// sortFellowListData();
		((MainTabAct) m_Activity).setTopButton(((MainTabAct) m_Activity).TAB_BTN_ORGANCHART);
		if (m_SectionListAdapter != null && m_FellowListAdapter != null && App.m_isChangeFellow) {
			App.m_isChangeFellow = false;
			m_SectionListAdapter.notifyDataSetChanged();
			m_FellowListAdapter.notifyDataSetChanged();
			CommonLog.e("", "chage FellowList.... true");
		}

		if (m_SectionListItems != null && m_arrSearchFellowListData != null) {
			// 여긴 화면 변화 필요 없음
		} else {
			if (m_arrNewFellowListData != null && App.m_arrFellowListData != null && m_SectionListItems != null) {
				if (m_SectionListItems.size() != (App.m_arrFellowListData.size() + m_arrNewFellowListData.size())) {
					initSearch();
					initSectionListViewUi();
				}
			} else {
				if (App.m_arrFellowListData != null && m_SectionListItems != null) {
					if (m_SectionListItems.size() != App.m_arrFellowListData.size()) {
						initSearch();
						initSectionListViewUi();
					}
				}
			}
		}
	}
	
	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (imm != null && et_search_keyword != null)
			imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
	}

	private void initSearch() {
		m_layoutSearchFellow = (FrameLayout)m_vFellowList.findViewById(R.id.layout_search_fellow);
		m_layoutSearchFellow.setVisibility(View.GONE);
		m_layoutNoFriend = (LinearLayout)m_vFellowList.findViewById(R.id.layout_no_friend);
		m_layoutNoList = (LinearLayout)m_vFellowList.findViewById(R.id.layout_no_list);
		et_search_keyword = (EditText) m_vFellowList.findViewById(R.id.et_search_keyword);
		// et_search_keyword.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
		et_search_keyword.setText("");
		ib_cancel = (ImageButton) m_vFellowList.findViewById(R.id.ib_cancel);
		ib_cancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				et_search_keyword.setText("");
				m_layoutNoList.setVisibility(View.GONE);
				m_layoutSearchFellow.setVisibility(View.VISIBLE);
				//((MainTabAct) m_Activity).setRightFloatButton(true, ((MainTabAct) m_Activity).TAB_RIGHTBTN_FELLOWLIST);
				//((MainTabAct) m_Activity).setLeftTopButton(true, ((MainTabAct) m_Activity).TAB_LEFTBTN_FELLOWLIST);
				imm.hideSoftInputFromWindow(et_search_keyword.getWindowToken(), 0);
			}
		});

		et_search_keyword.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				CommonLog.e("EditAction", "actionId1 : " + actionId);

				/*switch (actionId) {
				case EditorInfo.IME_ACTION_SEARCH:
					// requestAddedByPartner(v.getText().toString());

					if (!Utils.UseChar(v.getText().toString())) {
						m_Popup = new CommonPopup(m_Activity, MainFellowListFlag.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
						m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.regular_expression_search).toString());
						m_Popup.setCancelable(false);
						m_Popup.show();
						return false;
					}

					break;
				}*/
				return true;
			}
		});

		et_search_keyword.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if (s.toString().length() > 0) {
					ib_cancel.setVisibility(View.VISIBLE);
					SearchListViewUi(s.toString());
					//((MainTabAct) m_Activity).setLeftTopButton(false, ((MainTabAct) m_Activity).TAB_LEFTBTN_FELLOWLIST);
				} else {
					ib_cancel.setVisibility(View.INVISIBLE);
					m_layoutNoList.setVisibility(View.GONE);
					m_layoutSearchFellow.setVisibility(View.VISIBLE);
					initSectionListViewUi();
					//((MainTabAct) m_Activity).setRightFloatButton(true, ((MainTabAct) m_Activity).TAB_RIGHTBTN_FELLOWLIST);
					//((MainTabAct) m_Activity).setLeftTopButton(true, ((MainTabAct) m_Activity).TAB_LEFTBTN_FELLOWLIST);
				}
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub

			}
		});

	}

	private ArrayList<FellowListData> sortFellowListData() {
		if (App.m_arrFellowListData == null)
			return App.m_arrFellowListData;

		ArrayList<FellowListData> arrBufFellowListData = new ArrayList<FellowListData>();

		for (FellowListData data : App.m_arrFellowListData)
			arrBufFellowListData.add(data);
		Collections.sort(arrBufFellowListData, myComparator);

		App.m_arrFellowListData = null;
		App.m_arrFellowListData = new ArrayList<FellowListData>();

		for (FellowListData data : arrBufFellowListData)
			App.m_arrFellowListData.add(data);

		return App.m_arrFellowListData;
	}

	private void selectNewFellowList() throws Exception {
		String nYesterdayTime = Utils.getPrevHourTime();

		m_arrNewFellowListData = new ArrayList<FellowListData>();
		if(App.m_arrFellowListData != null) {
			for (FellowListData data : App.m_arrFellowListData) {
//			CommonLog.e("", "addtime : " + data.m_strFellowAddTime);
//			CommonLog.e("", "hidetime : " + nYesterdayTime);
				if (data.m_strFellowAddTime != null && !data.m_strFellowAddTime.equals("")) {
					if (Long.parseLong(data.m_strFellowAddTime) > Long.parseLong(nYesterdayTime)) {
						m_arrNewFellowListData.add(data);
					}
				}
			}
		}
	}

	private ArrayList<FellowListData> SearchFellowList(String a_Keyword) {
		a_Keyword = a_Keyword.trim().replace(" ", "").toLowerCase();
		m_arrSearchFellowListData = null;
		m_arrSearchFellowListData = new ArrayList<FellowListData>();
		String strLowerKeyword = a_Keyword.toLowerCase();
		if(a_Keyword.length() != 0) {
			if (App.m_arrFellowListData != null) {
				for (FellowListData data : App.m_arrFellowListData) {
					if (data.m_strName != null) {
						if (data.m_strUserType.equals("R")) {
							if(StringMatcher.match(data.m_strName.toLowerCase(),strLowerKeyword)||StringMatcher.match(data.m_strDepartment.toLowerCase(),strLowerKeyword)||StringMatcher.match(data.m_strCompany.toLowerCase(),strLowerKeyword))
								m_arrSearchFellowListData.add(data);
						} else {
							if (StringMatcher.match(data.m_strName.toLowerCase(), strLowerKeyword)||StringMatcher.match(data.m_strAffiliation.toLowerCase(),strLowerKeyword)) {
								m_arrSearchFellowListData.add(data);
							}
						}
					}
				}
			}
		}
		return m_arrSearchFellowListData;
	}

	private void initSectionListViewUi() {
		m_arrSearchFellowListData = null;
		if (App.m_arrFellowListData != null)
			sortFellowListData();

		m_lvFellowList = (SectionListView) m_vFellowList.findViewById(R.id.lv_fellowlist_list);

		try {
			selectNewFellowList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// m_SectionListItems Init
		if (m_SectionListItems == null)
			m_SectionListItems = new ArrayList<SectionListItem>();
		else
			m_SectionListItems.clear();

		m_SectionListItems = new ArrayList<SectionListItem>();

		/*item = new SectionListItem(App.m_MyUserInfo, getString(R.string.layout_sectionstring_profile));
		m_SectionListItems.add(item);*/
		if(App.m_arrFellowListData.size() == 0 ){
			m_layoutSearchFellow.setVisibility(View.GONE);
			m_layoutNoFriend.setVisibility(View.VISIBLE);
		} else {
			m_layoutSearchFellow.setVisibility(View.VISIBLE);
			m_layoutNoFriend.setVisibility(View.GONE);
			if (m_arrNewFellowListData != null) {
				for (FellowListData data : m_arrNewFellowListData) {
					item = new SectionListItem(data, getString(R.string.layout_sectionstring_new_fellows) + " " + m_arrNewFellowListData.size());
					m_SectionListItems.add(item);
				}
			}

			if (App.m_arrFellowListData != null) {
				for (FellowListData data : App.m_arrFellowListData) {
					SectionListItem item = new SectionListItem(data, getString(R.string.layout_sectionstring_fellows) + " " + App.m_arrFellowListData.size());
					m_SectionListItems.add(item);
				}
			}

			m_FellowListAdapter = new FellowListAdapter();
			m_FellowListAdapter.areAllItemsEnabled();
			m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_FellowListAdapter);
			m_lvFellowList.setAdapter(m_SectionListAdapter);
			m_lvFellowList.setOnScrollListener(new OnScrollListener() {

				@Override
				public void onScrollStateChanged(AbsListView view, int scrollState) {
					// TODO Auto-generated method stub

					if (scrollState == SCROLL_STATE_FLING && nState == GONE_SEARCH) {
						Animation ani = AnimationUtils.loadAnimation(m_Activity, R.anim.anim_alpha);
						ani.setAnimationListener(new Animation.AnimationListener() {

							@Override
							public void onAnimationStart(Animation animation) {
								// TODO Auto-generated method stub
								nState = VISIBLE_SEARCH;
							}

							@Override
							public void onAnimationRepeat(Animation animation) {
								// TODO Auto-generated method stub

							}

							@Override
							public void onAnimationEnd(Animation animation) {
								// TODO Auto-generated method stub
								nState = REMOVE_SEARCH;
								Animation ani_gone = AnimationUtils.loadAnimation(m_Activity, R.anim.anim_alpha_gone);
								ani_gone.setAnimationListener(new Animation.AnimationListener() {

									@Override
									public void onAnimationStart(Animation animation) {
										// TODO Auto-generated method stub

									}

									@Override
									public void onAnimationRepeat(Animation animation) {
										// TODO Auto-generated method stub

									}

									@Override
									public void onAnimationEnd(Animation animation) {
										// TODO Auto-generated method stub
										nState = GONE_SEARCH;
									}
								});
								m_layoutQuickSearch.setVisibility(View.GONE);
								m_layoutQuickSearch.startAnimation(ani_gone);
							}
						});
						m_layoutQuickSearch.setVisibility(View.VISIBLE);
						m_layoutQuickSearch.startAnimation(ani);
					} else if (scrollState == SCROLL_STATE_FLING && nState == REMOVE_SEARCH) {
						nState = REMOVE_SEARCH;
						Animation ani_gone = AnimationUtils.loadAnimation(m_Activity, R.anim.anim_alpha_gone);
						ani_gone.setAnimationListener(new Animation.AnimationListener() {

							@Override
							public void onAnimationStart(Animation animation) {
								// TODO Auto-generated method stub

							}

							@Override
							public void onAnimationRepeat(Animation animation) {
								// TODO Auto-generated method stub

							}

							@Override
							public void onAnimationEnd(Animation animation) {
								// TODO Auto-generated method stub
								nState = GONE_SEARCH;
							}
						});
						m_layoutQuickSearch.setVisibility(View.GONE);
						m_layoutQuickSearch.startAnimation(ani_gone);
					}
				}

				@Override
				public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
					// TODO Auto-generated method stub
					if (m_SectionListAdapter != null)
						m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
				}
			});
		}
	}

	private void SearchListViewUi(String a_Keyword) {
		m_lvFellowList = (SectionListView) m_vFellowList.findViewById(R.id.lv_fellowlist_list);

		SearchFellowList(a_Keyword.trim());

		// m_SectionListItems Init
		if (m_SectionListItems == null)
			m_SectionListItems = new ArrayList<SectionListItem>();
		else
			m_SectionListItems.clear();

		m_SectionListItems = new ArrayList<SectionListItem>();

		if (m_arrSearchFellowListData != null) {
			if (m_arrSearchFellowListData.size() == 0){
				m_layoutNoList.setVisibility(View.VISIBLE);
				m_layoutSearchFellow.setVisibility(View.GONE);
			}
			for (FellowListData data : m_arrSearchFellowListData) {
				SectionListItem item = new SectionListItem(data, getString(R.string.layout_sectionstring_search_result) + " " + m_arrSearchFellowListData.size());
				m_SectionListItems.add(item);
				m_layoutNoList.setVisibility(View.GONE);
				m_layoutSearchFellow.setVisibility(View.VISIBLE);
			}
		} else {

		}

		m_FellowListAdapter = new FellowListAdapter();
		m_FellowListAdapter.areAllItemsEnabled();
		m_SectionListAdapter = new SectionListAdapter(m_Activity.getLayoutInflater(), m_FellowListAdapter);
		m_lvFellowList.setAdapter(m_SectionListAdapter);
		m_lvFellowList.setOnScrollListener(new OnScrollListener() {

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				if (m_SectionListAdapter != null)
					m_SectionListAdapter.makeSectionInvisibleIfFirstInList(firstVisibleItem);
			}
		});

	}

	private final char[] QUICKSEARCH_CHOSUNG = { 'ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ', 'A', 'F', 'J', 'O', 'S', 'Z', '#' };

	private void initQuickSearch() {
		m_tvQuickSearchIndex = (TextView) m_vFellowList.findViewById(R.id.tv_quicksearchlayout_index);
		m_tvQuickSearchIndex.setVisibility(View.GONE);

		m_layoutQuickSearch = (LinearLayout) m_vFellowList.findViewById(R.id.layout_quicksearchlayout_quicksearch);
		m_layoutQuickSearch.setVisibility(View.GONE);
		m_layoutQuickSearch.setOnTouchListener(new OnTouchListener() {

			private String m_strLastChosung = "";

			@Override
			public boolean onTouch(View view, MotionEvent event) {
				// TODO Auto-generated method stub
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					showQuickSearchIndexTextView();
				case MotionEvent.ACTION_MOVE: {
					nState = GONE_STOP;
					Animation ani_gone = AnimationUtils.loadAnimation(m_Activity, R.anim.anim_alpha_gone);
					ani_gone.setAnimationListener(new Animation.AnimationListener() {

						@Override
						public void onAnimationStart(Animation animation) {
							// TODO Auto-generated method stub

						}

						@Override
						public void onAnimationRepeat(Animation animation) {
							// TODO Auto-generated method stub

						}

						@Override
						public void onAnimationEnd(Animation animation) {
							// TODO Auto-generated method stub
							nState = GONE_SEARCH;
						}
					});
					m_layoutQuickSearch.setVisibility(View.GONE);
					m_layoutQuickSearch.startAnimation(ani_gone);

					LinearLayout indexBar = (LinearLayout) view;
					int fEventX = (int) event.getX();
					int fEventY = (int) event.getY();

					for (int i = 0; i < indexBar.getChildCount(); i++) {
						View child = indexBar.getChildAt(i);

						if (fEventX > child.getLeft() && fEventX < child.getRight() && fEventY > child.getTop() && fEventY < child.getBottom()) {
							if (child instanceof TextView) {
								String strChosung = ((TextView) child).getText().toString();
								// moveSection(strChosung);
								if (!m_strLastChosung.equals(strChosung)) {
									CommonLog.e(MainFellowListFlag.class.getSimpleName(), "Quick Search : " + strChosung);
									m_strLastChosung = strChosung;
									moveQuickSearch(strChosung);
									m_tvQuickSearchIndex.setText(strChosung);
								}
							}
							break;
						}
					}
				}
					break;

				case MotionEvent.ACTION_UP:
					hideQuickSearchIndexTextView();
					break;
				}

				return true;
			}
		});
	}

	private ArrayList<String> CHOSUNG_HANGLE = new ArrayList<String>();

	private void moveQuickSearch(String a_strChoSung) {
		setChosungArrayList();
		int nPosition = 0;
		int nFellowPosition = 0;
		boolean isMove = false;
		for (SectionListItem item : m_SectionListItems) {
			if (item.section.startsWith(getString(R.string.layout_sectionstring_fellows))) {
				FellowListData fellowListData = (FellowListData) item.item;
				String strNameChosung = Utils.getChosungFirstString(fellowListData.m_strName);
				if (a_strChoSung.equals(strNameChosung.toUpperCase())) {
					int nSectionCount = m_SectionListAdapter.getSectionCount();
					m_lvFellowList.setSelection(nPosition + nSectionCount);
					isMove = true;
					break;
				}

				if (Utils.isHangul(a_strChoSung)) {
					int nSearchChosungIdx = CHOSUNG_HANGLE.indexOf(a_strChoSung);
					int nNameChosungIdx = CHOSUNG_HANGLE.indexOf(strNameChosung);
					if ((nSearchChosungIdx < nNameChosungIdx) || Utils.isEnglish(strNameChosung.charAt(0))) {
						int nSectionCount = m_SectionListAdapter.getSectionCount();
						m_lvFellowList.setSelection(nPosition + nSectionCount);
						isMove = true;
						break;
					}
				} else if (Utils.isEnglish(a_strChoSung.charAt(0)) && Utils.isEnglish(strNameChosung.charAt(0))) {
					if ((a_strChoSung.charAt(0) < strNameChosung.charAt(0))) {
						int nSectionCount = m_SectionListAdapter.getSectionCount();
						m_lvFellowList.setSelection(nPosition + nSectionCount);
						isMove = true;
						break;
					}
				}

				if (a_strChoSung.equals(getString(R.string.quicksearch_sharp))) {
					if (!Utils.isHangul(strNameChosung) && !Utils.isEnglish(strNameChosung.charAt(0))) {
						int nSectionCount = m_SectionListAdapter.getSectionCount();
						m_lvFellowList.setSelection(nPosition + nSectionCount);
						isMove = true;
						break;
					}
				}

				nFellowPosition = nPosition;
			}
			nPosition++;
		}

		if (!isMove) {
			int nSectionCount = m_SectionListAdapter.getSectionCount();
			m_lvFellowList.setSelection(nFellowPosition + nSectionCount);
		}

		CHOSUNG_HANGLE.clear();
	}

	private void setChosungArrayList() {
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ga));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_na));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_da));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_la));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ma));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ba));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_sa));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_aa));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ja));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_cha));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ka));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ta));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_pa));
		CHOSUNG_HANGLE.add(getString(R.string.quicksearch_ha));
	}

	private void showQuickSearchIndexTextView() {
		if (m_tvQuickSearchIndex.getAnimation() != null)
			m_tvQuickSearchIndex.getAnimation().cancel();

		m_tvQuickSearchIndex.setVisibility(View.VISIBLE);
	}

	private void hideQuickSearchIndexTextView() {
		Animation ani_gone = AnimationUtils.loadAnimation(m_Activity, R.anim.anim_alpha_gone);
		ani_gone.setAnimationListener(new Animation.AnimationListener() {

			@Override
			public void onAnimationStart(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationRepeat(Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationEnd(Animation animation) {
				// TODO Auto-generated method stub
			}
		});
		m_tvQuickSearchIndex.setVisibility(View.GONE);
		m_tvQuickSearchIndex.startAnimation(ani_gone);
	}

	// FellowList Adapter
	private class FellowListAdapter extends BaseAdapter {

		public FellowListAdapter() {
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_SectionListItems != null)
				return m_SectionListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (m_SectionListItems != null)
				return m_SectionListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			FellowListData data = (FellowListData) m_SectionListItems.get(nPosition).item;

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new FellowListItemLayout(m_Activity);

			String strSection = (String) m_SectionListItems.get(nPosition).section;

			RelativeLayout layout_listitem_search = (RelativeLayout) ((FellowListItemLayout) convertView).findViewById(R.id.layout_listitem_fellow);
			ImageView iv_profile_pic_frame = (ImageView) ((FellowListItemLayout) convertView).findViewById(R.id.iv_profile_pic_frame);
			if (strSection.startsWith(getString(R.string.layout_sectionstring_new_fellows))) {
				layout_listitem_search.setBackgroundResource(R.drawable.sel_fellow_new_listitem);
				iv_profile_pic_frame.setImageResource(R.drawable.sel_profile_pic_frame_new);
			} else {
				layout_listitem_search.setBackgroundResource(R.drawable.chatroom_listitem_selecter);
				iv_profile_pic_frame.setImageResource(R.drawable.sel_profile_pic_frame);
			}

			((FellowListItemLayout) convertView).setFellowListData(data);
			((FellowListItemLayout) convertView).setFellowDeleteByListener(mFellowDeleteByListener);

			return convertView;
		}
	}

	// FellowList Adapter
	private class SearchFellowListAdapter extends BaseAdapter {

		public SearchFellowListAdapter() {
		}

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			if (m_SectionListItems != null)
				return m_SectionListItems.size();
			return 0;
		}

		@Override
		public Object getItem(int position) {
			if (m_SectionListItems != null)
				return m_SectionListItems.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			final int nPosition = position;
			FellowListData data = (FellowListData) m_SectionListItems.get(nPosition).item;

			// convertView null 시 새로 생성하자
			if (convertView == null)
				convertView = new FellowListItemLayout(m_Activity);

			((FellowListItemLayout) convertView).setFellowListData(data);

			((FellowListItemLayout) convertView).setFellowDeleteByListener(mFellowDeleteByListener);

			// SectionListItem strSetion = (SectionListItem)
			// m_SectionListItems.get(nPosition);

			return convertView;
		}
	}

	private final static Comparator<FellowListData> myComparator = new Comparator<FellowListData>() {
		private final Collator collator = Collator.getInstance(new Locale("ko"));

		@Override
		public int compare(FellowListData lhs, FellowListData rhs) {
			// TODO Auto-generated method stub
			boolean isLeftNumber = true;
			boolean isRightNumber = true;
			char leftChar = lhs.m_strName.charAt(0);
			char rightChar = rhs.m_strName.charAt(0);

			if(leftChar < '0' || leftChar > '9'){
				isLeftNumber = false;
			} 
			if(rightChar < '0' || rightChar > '9'){
				isRightNumber = false;
			}
			
			if(isLeftNumber && !isRightNumber){
				return 1;
			} else if(!isLeftNumber && isRightNumber){
				return -1;
			} else
				return collator.compare(lhs.m_strName, rhs.m_strName);
		}

	};

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
		}
	}

	FellowListItemLayout.OnFellowDeleteByListener mFellowDeleteByListener = new FellowListItemLayout.OnFellowDeleteByListener() {
		@Override
		public void onNotifyChageList() {
			initSearch();
			initSectionListViewUi();
		}

		@Override
		public void setSwipeView(SwipeActionView swipeActionView) {
			((MainTabAct)getActivity()).setSwipeView(swipeActionView);
		}
	};

	private void requestUpdateUserList(){
		SharedPref pref = SharedPref.getInstance(m_Activity);
		String strTimeStamp = pref.getStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING);

		GetUserListReq req = new GetUserListReq(strTimeStamp);
		WebAPI webApi = new WebAPI(m_Activity);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				GetUserListRes res = new GetUserListRes(a_strData, Res.RES_TYPE_USER_LIST);
				if (res.getUserListData() != null) {
					SparseArray<UserListData> savedUserListData = TTalkDBManager.ContactsDBManager.getContactsReturnSparseArray(m_Activity);
					ArrayList<UserListData> arrInsertUserListData = new ArrayList<UserListData>();
					ArrayList<UserListData> arrUpdateUserListData = new ArrayList<UserListData>();

					for (UserListData data : res.getUserListData()) {
//						UserListData getitem = ContactsDBManager.getContacts(m_Activity, data.m_nUserNo);
						UserListData getitem = savedUserListData.get(data.m_nUserNo);
						if (getitem == null) {
							UserListData item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable,
									data.m_isActive, data.m_strGreeting, data.m_strUserStatus, false, "");
//							ContactsDBManager.insertContacts(m_Activity, item);
							arrInsertUserListData.add(item);
						} else {
							UserListData item = null;
							if (data.m_strUserStatus.equals("A"))
								item = new UserListData(data.m_nUserNo, data.m_PersonalData, data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, getitem.m_strFellowAddTime);
							else
								item = new UserListData(data.m_nUserNo, data.m_PersonalData,  data.m_strUserType, data.m_isImageAvailable, data.m_isActive,
										data.m_strGreeting, data.m_strUserStatus, getitem.m_isFellow, "");

//							ContactsDBManager.updateContacts(m_Activity, item);
							arrUpdateUserListData.add(item);
						}
					}
					if(arrInsertUserListData.size() > 0 )
						TTalkDBManager.ContactsDBManager.insertContacts(m_Activity, arrInsertUserListData);
					if(arrUpdateUserListData.size() > 0 )
						TTalkDBManager.ContactsDBManager.updateContacts(m_Activity, arrUpdateUserListData);
				}

				SharedPref pref = SharedPref.getInstance(m_Activity);
				pref.setStringPref(SharedPref.PREF_USERLIST_TIMESTAMP_STRING, res.m_strTimestamp);

				try {
					setFellowList();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					initSearch();
					initSectionListViewUi();
					initQuickSearch();
				}
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				((MainTabAct)m_Activity).showErrorPopup(a_nErrorCode, a_strMessage);
			}
		});
	}

	private ArrayList<FellowListData> setFellowList() throws Exception {
		ArrayList<UserListData> arrAddedFellowListData = TTalkDBManager.ContactsDBManager.getContactsByFellows(m_Activity);
		App.m_arrFellowListData = new ArrayList<FellowListData>();
		CommonLog.e("", "setFellowList() lol : " + App.m_EntryData.m_strLol);
		for (UserListData data : arrAddedFellowListData) {
			HashMap<String, String> personalData = data.m_PersonalData.mapPersonalData;
			if (data.m_strUserType.equals("R")) {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME),personalData.get(PersonalData.COMPANY_NAME),personalData.get(PersonalData.SECOND_CHARGE),personalData.get(PersonalData.POSITION),personalData.get(PersonalData.DEPARTMENT), personalData.get(PersonalData.PARENT_DEPARTMENT),"",
						personalData.get(PersonalData.CHARGE), data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			} else {
				FellowListData fellowListData = new FellowListData(data.m_nUserNo, data.m_strUserType, personalData.get(PersonalData.NAME), "", "",personalData.get(PersonalData.POSITION),"","", personalData.get(PersonalData.AFFILIATION), personalData.get(PersonalData.CHARGE),
						data.m_isImageAvailable, data.m_isActive, data.m_strFellowAddTime, data.m_strGreeting);
				if (data.m_strUserStatus.equals("A"))
					App.m_arrFellowListData.add(fellowListData);
			}
		}
		return App.m_arrFellowListData;
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Activity);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}