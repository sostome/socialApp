/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.gmp.rusk.imageloader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Base64;
import android.widget.ImageView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.apache.http.HttpStatus;
import org.apache.http.conn.ssl.StrictHostnameVerifier;
import org.apache.http.impl.cookie.DateUtils;

import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.Date;
import java.util.concurrent.RejectedExecutionException;

import javax.net.ssl.HttpsURLConnection;

import ezvcard.util.IOUtils;

/**
 * This helper class download images from the Internet and binds those with the provided ImageView.
 *
 * <p>It requires the INTERNET permission, which should be added to your application's manifest
 * file.</p>
 *
 * A local cache of downloaded images is maintained internally to improve performance.
 */
public class ImageDownloader {
	public MyApp App = MyApp.getInstance();
	private ImageDownloadCompleteListener m_CompleteListener = null;
	
	private final int MAX_AGE = 60 * 60 * 6; 
	
	public ImageDownloader(ImageDownloadCompleteListener a_Listener)
	{
		m_CompleteListener = a_Listener;
	}

    /**
     * Download the specified image from the Internet and binds it to the provided ImageView. The
     * binding is immediate if the image is found in the cache and will be done asynchronously
     * otherwise. A null bitmap will be associated to the ImageView if an error occurs.
     *
     * @param url The URL of the image to download.
     * @param imageView The ImageView to bind the downloaded image to.
     */
        
//    public void download(String url, ImageView imageView, String a_strIfModifiedSince) {
	public void download(String url, ImageView imageView, boolean a_isRounding) {
    		forceDownload(url, imageView, a_isRounding);
    }
	
	public void cancelDownload(ImageView imageView)
	{
		BitmapDownloaderTask bitmapDownloaderTask = getBitmapDownloaderTask(imageView);
		if (bitmapDownloaderTask != null) {
			bitmapDownloaderTask.cancel(true);
		}
	}
    
    /*
     * Same as download but the image is always downloaded and the cache is not used.
     * Kept private at the moment as its interest is not clear.
       private void forceDownload(String url, ImageView view) {
          forceDownload(url, view, null);
       }
     */

    /**
     * Same as download but the image is always downloaded and the cache is not used.
     * Kept private at the moment as its interest is not clear.
     */
    private void forceDownload(String url, ImageView imageView, boolean a_isRounding) {
        // State sanity: url is guaranteed to never be null in DownloadedDrawable and cache keys.
        if (url == null) {
        	if(imageView != null)
        		imageView.setImageDrawable(null);
            return;
        }
        try{
	        if (cancelPotentialDownload(url, imageView)) {
	        	BitmapDownloaderTask task = new BitmapDownloaderTask(imageView, a_isRounding);
                DownloadedDrawable downloadedDrawable = new DownloadedDrawable(task);
//                imageView.setImageDrawable(downloadedDrawable);
                if(imageView != null)
                	imageView.setTag(downloadedDrawable);
                task.execute(url);
	        }
        }catch (RejectedExecutionException e) {
			// TODO: handle exception
//        	e.printStackTrace();
		}
    }

    /**
     * Returns true if the current download has been canceled or if there was no download in
     * progress on this image view.
     * Returns false if the download in progress deals with the same url. The download is not
     * stopped in that case.
     */
    private static boolean cancelPotentialDownload(String url, ImageView imageView) {
        BitmapDownloaderTask bitmapDownloaderTask = getBitmapDownloaderTask(imageView);

        if (bitmapDownloaderTask != null) {
            String bitmapUrl = bitmapDownloaderTask.url;
            if ((bitmapUrl == null) || (!bitmapUrl.equals(url))) {
            	CommonLog.e(ImageDownloader.class.getSimpleName(), "cancelDownload");
                bitmapDownloaderTask.cancel(true);
            } else {
                // The same URL is already being downloaded.
                return false;
            }
        }
        return true;
    }

    /**
     * @param imageView Any imageView
     * @return Retrieve the currently active download task (if any) associated with this imageView.
     * null if there is no such task.
     */
    private static BitmapDownloaderTask getBitmapDownloaderTask(ImageView imageView) {
        if (imageView != null) {
//            Drawable drawable = imageView.getDrawable();
        	DownloadedDrawable drawable = (DownloadedDrawable)imageView.getTag();
        	if(drawable != null)
        	{
//            if (drawable instanceof DownloadedDrawable) {
//                DownloadedDrawable downloadedDrawable = (DownloadedDrawable)drawable;
                return drawable.getBitmapDownloaderTask();
        	}
//            }
        }
        return null;
    }
    
    public BitmapDownloadInfo downloadBitmap(String url, long a_lnIfModifiedSince) 
    {
    	CommonLog.e(ImageDownloader.class.getSimpleName(), "downloadBitmap : " + url);
    	String strTempUrl = url.trim();
    	if(strTempUrl.equals(""))
    		return null;
    	
    	BitmapDownloadInfo bmpDownloadInfo = null;
    	
    	try
	    {
			//2016년 고도화 개발 서버 사용
			//WebAPI.trustAllHosts();
			URL connectUrl = new URL(url);
			HttpsURLConnection con = null;
			
			HttpsURLConnection https = (HttpsURLConnection) connectUrl.openConnection();

			//상용 서버 사용
			https.setHostnameVerifier(new StrictHostnameVerifier());
			//2016년 고도화 개발 서버 사용
			//https.setHostnameVerifier(WebAPI.DO_NOT_VERIFY);
			con = https;			
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Connection", "close");
			
			//headerSet
			con.setRequestProperty("X-Device-OS", "A");
			con.setRequestProperty("Accept-Language", App.m_strLocale);
			con.setRequestProperty("X-Device-OS-Version", Utils.getBuildOSVersion());	
			con.setRequestProperty("X-Device-Model", Utils.getBuildModel());
			con.setRequestProperty("X-Device-Vender", Utils.getBuildManufacturer());
			
			TelephonyManager tm = (TelephonyManager)App.getInstance().getSystemService(Context.TELEPHONY_SERVICE);
			
			//if(!AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
				con.setRequestProperty("X-Device-UID", tm.getDeviceId());
			
			
			con.setRequestProperty("X-App-Version", Utils.getApplicationVersion(App.getInstance()));
			if(AppSetting.FEATURE_VARIANT.equals("S"))
				con.setRequestProperty("X-App-Variant", StaticString.VARIANT_PARTNER);
			else
				con.setRequestProperty("X-App-Variant", AppSetting.FEATURE_VARIANT);
			
			String strPartnerID = App.m_PartnerID;
			SharedPref pref = SharedPref.getInstance(App.getInstance());
			
			if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
			{
				// 정직원
				con.setRequestProperty("Authorization", "GMP " + Base64.encodeToString((App.m_GMPData.m_strCompanyCode+"."+App.m_GMPData.m_strRegularID+":"+App.m_GMPData.m_strAuthKey).getBytes(), Base64.NO_WRAP));
				con.setRequestProperty("Authorization-Mdn", App.m_Mdn);
			}
			else
			{
				// 파트너
				con.setRequestProperty("Authorization", "Basic " + Base64.encodeToString((strPartnerID+":"+App.m_PartnerPW).getBytes(), 0));
			}
			
			System.setProperty("http.keepAlive", "false");
	        
			con.setRequestProperty("Cookie", pref.getStringPref(SharedPref.PREF_COOKIE, ""));
			
			if(a_lnIfModifiedSince != 0L)
		   {
			   String lastModified = DateUtils.formatDate(new Date(a_lnIfModifiedSince), "EEE, d MMM yyyy HH:mm:ss 'GMT'");
			   con.setRequestProperty("If-Modified-Since", lastModified);
		   }
			
//			con.setRequestProperty("max-age", "" + MAX_AGE);
			
			con.setRequestMethod("GET");
			con.setDoInput(true);
			
			con.setDefaultUseCaches(false);
			
			if (con.getResponseCode() != HttpStatus.SC_OK) {
				bmpDownloadInfo = new BitmapDownloadInfo();
				bmpDownloadInfo.m_nHttpStatusCode = con.getResponseCode();
				bmpDownloadInfo.m_strHttpErrorMsg = con.getResponseMessage();
				con.disconnect();
			}
			else
			{
				// Pull content stream from response
				InputStream inputStream = null;
	            try {
	            	inputStream = con.getInputStream();

	            	byte[] streamByte = IOUtils.toByteArray(new FlushedInputStream(inputStream));
	                // return BitmapFactory.decodeStream(inputStream);
	                // Bug on slow connections, fixed in future release.
	                BitmapFactory.Options options = new BitmapFactory.Options();

					options.inJustDecodeBounds = true;

					//BitmapFactory.decodeStream(new FlushedInputStream(inputStream),null,options);
					BitmapFactory.decodeByteArray(streamByte, 0, streamByte.length, options);
					int width = options.outWidth;
					int height = options.outHeight;
					int scale = 1;
					if(width > 1920 || height > 1920){
						scale = (int)Math.pow(2, (int)Math.round(Math.log(1920/(double)Math.max(height, width)) / Math.log(0.5)));
					}
					options.inJustDecodeBounds = false;
					options.inSampleSize = scale;

	                options.inPreferredConfig = Bitmap.Config.RGB_565;

//	                Bitmap original = BitmapFactory.decodeStream(new FlushedInputStream(inputStream));
	                //Bitmap original = BitmapFactory.decodeStream(new FlushedInputStream(inputStream),null,options);
					Bitmap original = BitmapFactory.decodeByteArray(streamByte, 0, streamByte.length, options);
	                System.gc();
	                bmpDownloadInfo = new BitmapDownloadInfo();
	                bmpDownloadInfo.m_nHttpStatusCode = con.getResponseCode();
	                bmpDownloadInfo.m_bmpDownload = original;
	            } finally {
	                if (inputStream != null) {
	                    inputStream.close();
	                }
	                con.disconnect();
	            }
			}
	    }
    	catch (IOException e) {
        	e.printStackTrace();
        } catch (IllegalStateException e) {
        	e.printStackTrace();
        } catch (Exception e) {
        	e.printStackTrace();
        }finally {
        }
    	return bmpDownloadInfo;
    }

//   public BitmapDownloadInfo downloadBitmap(String url, long a_lnIfModifiedSince) {
//	   
//       // AndroidHttpClient is not allowed to be used from the main thread
//	   String strTempUrl = url.trim();
//	   if(strTempUrl.equals(""))
//		   return null;
//	   
//	   
//	   CommonLog.e(ImageDownloader.class.getSimpleName(), "Image Url : " + url);
//	   final HttpClient client = AndroidHttpClient.newInstance("Android");
//	   final HttpGet getRequest = new HttpGet(url);
//	   if(a_lnIfModifiedSince != 0L)
//	   {
//		   String lastModified = DateUtils.formatDate(new Date(a_lnIfModifiedSince), "EEE, d MMM yyyy HH:mm:ss 'GMT'");
//		   getRequest.addHeader("If-Modified-Since", lastModified);
//	   }
//	   
//	   
//	   try {
//		   HttpResponse response = client.execute(getRequest);
//		   final int statusCode = response.getStatusLine().getStatusCode();
//		   BitmapDownloadInfo bmpDownloadInfo = new BitmapDownloadInfo();
//		   bmpDownloadInfo.m_nHttpStatusCode = statusCode;
//		   CommonLog.e(ImageDownloader.class.getSimpleName(), "https status code : " + statusCode);
//		   if (statusCode != HttpStatus.SC_OK) {
//			   HttpEntity entity = response.getEntity();
//			   if(entity != null && entity.getContent() != null)
//			   {
//				   BufferedReader in = new BufferedReader(new InputStreamReader(entity.getContent()));
//				   StringBuffer sb = new StringBuffer("");
//				   String line = "";
//				   String NL = System.getProperty("line.separator");
//				   while ((line = in.readLine()) != null)
//				   {
//					   sb.append(line + NL);
//				   }
//				   in.close();
//				   bmpDownloadInfo.m_strHttpErrorMsg = sb.toString();
//			   }
//			   return bmpDownloadInfo;
//		   }
//
//            final HttpEntity entity = response.getEntity();
//            if (entity != null) {
//                InputStream inputStream = null;
//                try {
//                    inputStream = entity.getContent();
//                    // return BitmapFactory.decodeStream(inputStream);
//                    // Bug on slow connections, fixed in future release.
//                    BitmapFactory.Options options = new BitmapFactory.Options();
//                    options.inSampleSize = 1;
//                    options.inPreferredConfig = Bitmap.Config.RGB_565;
//                    
////                    Bitmap original = BitmapFactory.decodeStream(new FlushedInputStream(inputStream));
//                    Bitmap original = BitmapFactory.decodeStream(new FlushedInputStream(inputStream),null,options);
//                    
//                    System.gc();
//                    
//                    bmpDownloadInfo.m_bmpDownload = original;
//                    
//                    return bmpDownloadInfo;
//                    
//                } finally {
//                    if (inputStream != null) {
//                        inputStream.close();
//                    }
//                    entity.consumeContent();
//                }
//            }
//        } catch (IOException e) {
//        	e.printStackTrace();
//            getRequest.abort();
//        } catch (IllegalStateException e) {
//        	e.printStackTrace();
//            getRequest.abort();
//        } catch (Exception e) {
//        	e.printStackTrace();
//            getRequest.abort();
//        }finally {
//            if ((client instanceof AndroidHttpClient)) {
//                ((AndroidHttpClient) client).close();
//            }
//        }
//        return null;
//    }
    
    private String getFileLastModifiedSince(String a_strUrl)
    {
    	FileCacheDBAdapter db = new FileCacheDBAdapter(App.getInstance());
		db.openReadOnly();
		String strFileName = db.getFileCache(a_strUrl);
		db.close();
		
		String strIfModifiedSince = "";
		
		if(!TextUtils.isEmpty(strFileName))
		{
			// File Load And Set Image
			File file = new File(App.getInstance().getFilesDir(), strFileName);
			if(file != null && file.exists())
			{
				Bitmap bmp = readImageFile(file);
				if(bmp != null)
				{
					strIfModifiedSince = "" + file.lastModified();
					ImageLoaderManager.addBitmapToCache(a_strUrl, bmp);
				}
			}
		}
		
		return strIfModifiedSince;
    }
    
    private Bitmap getFile(String a_strUrl)
    {
    	FileCacheDBAdapter db = new FileCacheDBAdapter(App.getInstance());
		db.openReadOnly();
		String strFileName = db.getFileCache(a_strUrl);
		db.close();
		
		if(!TextUtils.isEmpty(strFileName))
		{
	    	File file = new File(App.getInstance().getFilesDir(), strFileName);
			if(file == null || !file.exists())
			{
				return null;
			}
			else
			{
				Bitmap bmp = readImageFile(file);
				if(bmp != null)
				{
					ImageLoaderManager.addBitmapToCache(a_strUrl, bmp);
					return bmp;
				}
				return null;
			}
		}
		else
			return null;
    }
    
    private Bitmap readImageFile(File a_fileImage)
	{
		return BitmapFactory.decodeFile(a_fileImage.getPath());
	}

    /*
     * An InputStream that skips the exact number of bytes provided, unless it reaches EOF.
     */
    static class FlushedInputStream extends FilterInputStream {
        public FlushedInputStream(InputStream inputStream) {
            super(inputStream);
        }

        @Override
        public long skip(long n) throws IOException {
            long totalBytesSkipped = 0L;
            while (totalBytesSkipped < n) {
                long bytesSkipped = in.skip(n - totalBytesSkipped);
                if (bytesSkipped == 0L) {
                    int b = read();
                    if (b < 0) {
                        break;  // we reached EOF
                    } else {
                        bytesSkipped = 1; // we read one byte
                    }
                }
                totalBytesSkipped += bytesSkipped;
            }
            return totalBytesSkipped;
        }
    }
    
    class BitmapDownloadInfo{
    	public Bitmap m_bmpDownload = null;
    	public int m_nHttpStatusCode = -1;
    	public String m_strHttpErrorMsg = "";
    }

    /**
     * The actual AsyncTask that will asynchronously download the image.
     */
    class BitmapDownloaderTask extends AsyncTask<String, Void, BitmapDownloadInfo> {
        private String url;
        private final WeakReference<ImageView> imageViewReference;
        private boolean m_isRounding;

        public BitmapDownloaderTask(ImageView imageView, boolean a_isRounding) {
            imageViewReference = new WeakReference<ImageView>(imageView);
            m_isRounding = a_isRounding;
        }

        /**
         * Actual download method.
         */
        @Override
        protected BitmapDownloadInfo doInBackground(String... params) {
            url = params[0];
            String strIfModifiedSince = getFileLastModifiedSince(url); 
            long lnIfModifiedSince = 0L;
            if(!TextUtils.isEmpty(strIfModifiedSince))
            	lnIfModifiedSince = Long.parseLong(strIfModifiedSince);
            
            BitmapDownloadInfo bmpDownloadInfo = downloadBitmap(url, lnIfModifiedSince);
            return bmpDownloadInfo;
        }

        /**
         * Once the image is downloaded, associates it to the imageView
         */
        @Override
        protected void onPostExecute(BitmapDownloadInfo bmpDownloadInfo) {
        	if(bmpDownloadInfo == null)
        	{
        		m_CompleteListener.onFail(url, -1, null);
        		return;
        	}
        	if(bmpDownloadInfo.m_nHttpStatusCode == HttpStatus.SC_NOT_MODIFIED)
        	{
        		Bitmap bmp = null;
        		
        		if (!isCancelled()) 
                {
        			bmp = getFile(url);
	        		if (imageViewReference != null) 
		            {
	        			ImageView imageView = imageViewReference.get();
	        			if(m_isRounding)
	        			{
	        				Bitmap output = Bitmap.createBitmap(bmp.getWidth(), bmp
					                .getHeight(), Config.ARGB_8888);
					        Canvas canvas = new Canvas(output);
	
					        final int color = 0xff424242;
					        final Paint paint = new Paint();
					        final Rect rect = new Rect(0, 0, bmp.getWidth(), bmp.getHeight());
					        final RectF rectF = new RectF(rect);
					        final float roundPx = 30;
	
					        paint.setAntiAlias(true);
					        canvas.drawARGB(0, 0, 0, 0);
					        paint.setColor(color);
					        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
	
					        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
					        canvas.drawBitmap(bmp, rect, rect, paint);
					        if(imageView != null)
					        	imageView.setImageBitmap(output);
	        			}
	        			else {
	        				if(imageView != null)
	        					imageView.setImageBitmap(bmp);
	        			}
		            }
                }
        		
        		m_CompleteListener.onNotModified(url, bmp);
        		return;
        	}
        	
        	if(bmpDownloadInfo.m_nHttpStatusCode != HttpStatus.SC_OK)
        	{
        		//CommonLog.e(ImageDownloader.class.getSimpleName(), "Image Download Fail... " + bmpDownloadInfo.m_nHttpStatusCode);
        		m_CompleteListener.onFail(url, bmpDownloadInfo.m_nHttpStatusCode, bmpDownloadInfo.m_strHttpErrorMsg);
        		return;
        	}
        	
       		// Send Listener
        	m_CompleteListener.onComplete(url, bmpDownloadInfo.m_bmpDownload);
        		
            if (!isCancelled()) 
            {
            	CommonLog.e(ImageDownloader.class.getSimpleName(), "is not canceled!!!");
	            if (imageViewReference != null) 
	            {
	                ImageView imageView = imageViewReference.get();
	                BitmapDownloaderTask bitmapDownloaderTask = getBitmapDownloaderTask(imageView);
	                // Change bitmap only if this process is still associated with it
	                // Or if we don't use any bitmap to task association (NO_DOWNLOADED_DRAWABLE mode)
	                if (this == bitmapDownloaderTask) 
	                {
	                	try
	                	{
	                		if(m_isRounding)
	            			{
	            				Bitmap output = Bitmap.createBitmap(bmpDownloadInfo.m_bmpDownload.getWidth(), bmpDownloadInfo.m_bmpDownload
	    				                .getHeight(), Config.ARGB_8888);
	    				        Canvas canvas = new Canvas(output);

	    				        final int color = 0xff424242;
	    				        final Paint paint = new Paint();
	    				        final Rect rect = new Rect(0, 0, bmpDownloadInfo.m_bmpDownload.getWidth(), bmpDownloadInfo.m_bmpDownload.getHeight());
	    				        final RectF rectF = new RectF(rect);
	    				        final float roundPx = 0;

	    				        paint.setAntiAlias(true);
	    				        canvas.drawARGB(0, 0, 0, 0);
	    				        paint.setColor(color);
	    				        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

	    				        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
	    				        canvas.drawBitmap(bmpDownloadInfo.m_bmpDownload, rect, rect, paint);
	    				        if(imageView != null)
	    				        	imageView.setImageBitmap(output);
	            			}
	                		else{
	                			if(imageView != null)
	                				imageView.setImageBitmap(bmpDownloadInfo.m_bmpDownload);	
	                		}
	                	} 
	                	catch(Exception e)
	                	{
//	                		e.printStackTrace();
	                	}
	                    
	                }
	            }
            }
            else
            {
            	CommonLog.e(ImageDownloader.class.getSimpleName(), "iscanceled!!!");
            	bmpDownloadInfo.m_bmpDownload.recycle();
            	bmpDownloadInfo.m_bmpDownload = null;
            }
        }
    }

    /**
     * A fake Drawable that will be attached to the imageView while the download is in progress.
     *
     * <p>Contains a reference to the actual download task, so that a download task can be stopped
     * if a new binding is required, and makes sure that only the last started download process can
     * bind its result, independently of the download finish order.</p>
     */
    static class DownloadedDrawable {//extends ColorDrawable {
        private final WeakReference<BitmapDownloaderTask> bitmapDownloaderTaskReference;

        public DownloadedDrawable(BitmapDownloaderTask bitmapDownloaderTask) {
            bitmapDownloaderTaskReference =
                new WeakReference<BitmapDownloaderTask>(bitmapDownloaderTask);
        }

        public BitmapDownloaderTask getBitmapDownloaderTask() {
            return bitmapDownloaderTaskReference.get();
        }
    }
}
