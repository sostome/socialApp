package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

public class IQKickErrorEx extends IQ {
	public final static String NAMESPACE = "jabber:iq:kick";
//	private final String NAMESPACE_Q = "<query xmlns=\"jabber:iq:kick\">";

	private String namespace = null;
	String errorCode;
	String errorText;

	public IQKickErrorEx() {
	}

	public IQKickErrorEx(String namespace, String errorCode, String errorText) {
		this.namespace = namespace;
		this.errorCode = errorCode;
		this.errorText = errorText;
	}

	
	@Override
	public String getChildElementXML() {
		StringBuilder buf = new StringBuilder();
//		buf.append(NAMESPACE_Q);
//		if (namespace != null) {
//			buf.append("<user>").append(namespace).append("</user>");
//		}
//		buf.append("</query>");
		return buf.toString();
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getNamespace() {
		return namespace;
	}
	
	public String getCode(){
		return this.errorCode;
	}
	
	public String getText(){
		return this.errorText;
	}

	public static class Provider implements IQProvider {

		@Override
		public IQ parseIQ(XmlPullParser parser) throws Exception {
			// TODO Auto-generated method stub
			String namespace = null;
			String errorCode = null;
			String errorText = null;
			boolean done = false;
			int cnt = parser.getAttributeCount();
			for(int i = 0; i < cnt; i++){
				if(parser.getAttributeName(i).equals("error")){
					errorCode = parser.getAttributeValue(i);	
				}
			}
			while (!done) {
				int eventType = parser.next();
				if (eventType == XmlPullParser.START_TAG) {
//					if (parser.getName().equals("query")) {
//						//errorCode = parser.nextText();
//						errorText = parser.nextText();
//					} 
				} else if (eventType == XmlPullParser.END_TAG) {
					if (parser.getName().equals("query")) {
						namespace = parser.getNamespace();
						done = true;

					}
				} else if (eventType == XmlPullParser.TEXT) {
					errorText = parser.getText();
				}
			}
			return new IQKickErrorEx(namespace, errorCode, errorText);
		}

	}

}