package com.gmp.rusk.datamodel;

public class DepartmentsData {
	String m_strDepartmentCode = "";		//부서 코드
	String m_strDepartmentName = "";		//부서 이름
	boolean m_isLeaf = false;				//Leaf 노드 여부
	
	public DepartmentsData(String a_strDepartmentCode, String a_strDepartmentName, boolean a_isLeaf) {
		m_strDepartmentCode = a_strDepartmentCode;
		m_strDepartmentName = a_strDepartmentName;
		m_isLeaf = a_isLeaf;
	}
	
	public String getDepartmentCode(){
		return m_strDepartmentCode;
	}
	
	public String getDepartmentName(){
		return m_strDepartmentName;
	}
}
