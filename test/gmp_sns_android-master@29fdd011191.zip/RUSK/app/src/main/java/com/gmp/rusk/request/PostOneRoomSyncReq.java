package com.gmp.rusk.request;

import org.json.JSONObject;


import com.gmp.rusk.utils.CommonLog;

/**
 *	@author kch
 *			개인방 동기화 
 *			method : post
 */

public class PostOneRoomSyncReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	private final String JSON_PAYLOAD		= "payload";
	private final String JSON_TYPE	 		= "type";
	private final String JSON_JID		 	= "jid";
	
	
	private String m_strRoomId = "";
	
	public PostOneRoomSyncReq(String a_strRoomID)
	{
		APINAME = APINAME + "/" + App.m_MyUserInfo.m_nUserNo + "/sync";
		m_strRoomId = a_strRoomID;
	}
	

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			JSONObject jsonObj2 = new JSONObject();
			jsonObj2.put(JSON_TYPE, "oneOnOneQuit");
			jsonObj2.put(JSON_JID, m_strRoomId);
			
			jsonObj.put(JSON_PAYLOAD, jsonObj2);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PostOneRoomSyncReq.class.getSimpleName(), "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
