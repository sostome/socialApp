package com.gmp.rusk.act;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.db.DBBackup;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetPCClientAuthKeyReq;
import com.gmp.rusk.request.PostPCClientAuthKeyCheckReq;
import com.gmp.rusk.request.PostPCClientSyncFileUploadReq;
import com.gmp.rusk.response.GetPCClientAuthKeyRes;
import com.gmp.rusk.response.PostPCClientAuthKeyCheckRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;

/** 
 * PC 버전 인증번호 화면
 * 인증번호 받을때는 XMPP에 연결되지 않게 한다.
 * @author DoYoungmin
 *
 */
public class PCClientAuthAct extends Activity implements OnClickListener{
	
	private final int AUTHSTATE_INPUTKEY 			= 1;	// 인증번호 입력
	private final int AUTHSTATE_DATASYNC 			= 2;	// 데이터 내보내기 중
	private final int AUTHSTATE_DATASYNCERROR 		= 3;	// 데이터 내보내기 에러
	private final int AUTHSTATE_COMPLETE 			= 4;	// PC버전 활성화 완료
	private final int AUTHSTATE_STOP 				= 5;	// 발급된 인증번호가 없거나 유효기간 만료
	
	private int m_nAuthState = AUTHSTATE_INPUTKEY;
	
	private Bitmap[] m_bmpDataSync = new Bitmap[5];
	
	private ProgressDlg m_Progress = null;
	
	private String m_strSyncFileId = "";
	
	private static String m_strAuthKey = "";
	private static WebAPI m_apiCheckAuth = null;

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_set_pcclientauth);
		
		initUI();
		initBitmapData();
		
		setAuthState(AUTHSTATE_INPUTKEY);
		setAuthKeyText("");
		
		// LongPolling에 진입했을때 Back으로 화면을 나갔다가 다시 들어오면 LongPolling때문에 getAuthKey Request가 LongPolling이 끝날때까지 대기하는 문제 때문에 진행중인지 체크 필요
		if(m_apiCheckAuth == null)
		{
			getAuthKey();
		}
		else
		{
			setAuthKeyText(m_strAuthKey);
		}
	}
	
	private void initUI()
	{
		ImageView ivClose = (ImageView)findViewById(R.id.btn_cancel);
		ivClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		LinearLayout ibNext = (LinearLayout)findViewById(R.id.ib_pcclientauth_next);
		ibNext.setOnClickListener(this);
		setNextButtonEnable(false);
	}
	
	private void initBitmapData()
	{
		m_bmpDataSync[0] = BitmapFactory.decodeResource(getResources(), R.drawable.img_1_1);
		m_bmpDataSync[1] = BitmapFactory.decodeResource(getResources(), R.drawable.img_1_2);
		m_bmpDataSync[2] = BitmapFactory.decodeResource(getResources(), R.drawable.img_1_3);
		m_bmpDataSync[3] = BitmapFactory.decodeResource(getResources(), R.drawable.img_1_4);
		m_bmpDataSync[4] = BitmapFactory.decodeResource(getResources(), R.drawable.img_1_5);
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		m_bmpDataSync[0].recycle();
		m_bmpDataSync[1].recycle();
		m_bmpDataSync[2].recycle();
		m_bmpDataSync[3].recycle();
		m_bmpDataSync[4].recycle();
		super.onDestroy();
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.ib_pcclientauth_next)
		{
			setAuthState(AUTHSTATE_DATASYNC);
			startDataSync();
		}
/*		else if(nId == R.id.tv_pcclientauth_authstate_inputkey)
		{
			setAuthState(AUTHSTATE_INPUTKEY);
			setAuthKeyText("0");
		}
		else if(nId == R.id.tv_pcclientauth_authstate_datasync)
		{
			setAuthState(AUTHSTATE_DATASYNCERROR);
		}
		else if(nId == R.id.tv_pcclientauth_authstate_complete)
		{
			setAuthState(AUTHSTATE_COMPLETE);
		}*/
	}
	
	private void setAuthState(int a_nState)
	{
		m_nAuthState = a_nState;
		TextView tvTitle = (TextView)findViewById(R.id.tv_pcclientauth_title);
		
		LinearLayout layoutIng = (LinearLayout)findViewById(R.id.layout_pcclientauth_ing);
		LinearLayout layoutStop = (LinearLayout)findViewById(R.id.layout_pcclientauth_stop);
		ImageView ivAuthState = (ImageView)findViewById(R.id.iv_pcclientauth_authstate);
		RelativeLayout layoutInputKey = (RelativeLayout)findViewById(R.id.layout_pcclientauth_authstate_inputkey);
		LinearLayout layoutDataSync = (LinearLayout)findViewById(R.id.layout_pcclientauth_authstate_datasync);
		LinearLayout layoutComplete = (LinearLayout)findViewById(R.id.layout_pcclientauth_authstate_complete);
		
		if(a_nState == AUTHSTATE_INPUTKEY)
		{
			tvTitle.setText(R.string.act_set_pcclientauth_title_auth);
			layoutIng.setVisibility(View.VISIBLE);
			layoutStop.setVisibility(View.GONE);

			ivAuthState.setBackgroundResource(R.drawable.img_step_1);

			layoutInputKey.setVisibility(View.VISIBLE);
			layoutDataSync.setVisibility(View.GONE);
			layoutComplete.setVisibility(View.GONE);

		}
		else if(a_nState == AUTHSTATE_DATASYNC || a_nState == AUTHSTATE_DATASYNCERROR)
		{
			tvTitle.setText(R.string.act_set_pcclientauth_title_datasync);
			layoutIng.setVisibility(View.VISIBLE);
			layoutStop.setVisibility(View.GONE);
			ivAuthState.setBackgroundResource(R.drawable.img_step_2);

			layoutInputKey.setVisibility(View.GONE);
			layoutDataSync.setVisibility(View.VISIBLE);
			layoutComplete.setVisibility(View.GONE);

			
			ImageView ivDataSync = (ImageView)findViewById(R.id.iv_pcclientauth_datasync);
			if(a_nState == AUTHSTATE_DATASYNC)
			{
				m_hDataSyncImageAnimation.sendEmptyMessage(0);
			}
			else 
			{
				ivDataSync.setBackgroundResource(R.drawable.img_pc_fail);
				TextView tvDataSyncMsg1 = (TextView)findViewById(R.id.tv_pcclientauth_authstate_datasync_msg1);
				TextView tvDataSyncMsg2 = (TextView)findViewById(R.id.tv_pcclientauth_authstate_datasync_msg2);
				
				tvDataSyncMsg1.setText(R.string.set_pcclientauth_authstate_datasync_errormsg);
				tvDataSyncMsg2.setVisibility(View.GONE);
			}
		}
		else if(a_nState == AUTHSTATE_COMPLETE)
		{
			tvTitle.setText(R.string.act_set_pcclientauth_title_complete);
			layoutIng.setVisibility(View.VISIBLE);
			layoutStop.setVisibility(View.GONE);
			ivAuthState.setBackgroundResource(R.drawable.img_step_3);
			layoutInputKey.setVisibility(View.GONE);
			layoutDataSync.setVisibility(View.GONE);
			layoutComplete.setVisibility(View.VISIBLE);

		}
		else if(a_nState == AUTHSTATE_STOP)
		{
			tvTitle.setText(R.string.act_set_pcclientauth_title_auth);
			layoutIng.setVisibility(View.GONE);
			layoutStop.setVisibility(View.VISIBLE);
		}
	}
	
	private void setAuthKeyText(String a_strAuthKey)
	{
		TextView tvAuthKey1 = (TextView)findViewById(R.id.tv_pcclientauth_authkey_1);
		TextView tvAuthKey2 = (TextView)findViewById(R.id.tv_pcclientauth_authkey_2);
		TextView tvAuthKey3 = (TextView)findViewById(R.id.tv_pcclientauth_authkey_3);
		TextView tvAuthKey4 = (TextView)findViewById(R.id.tv_pcclientauth_authkey_4);
		if (a_strAuthKey.length() == 4) {


			tvAuthKey1.setText(a_strAuthKey.charAt(0)+"");
			tvAuthKey2.setText(a_strAuthKey.charAt(1)+"");
			tvAuthKey3.setText(a_strAuthKey.charAt(2)+"");
			tvAuthKey4.setText(a_strAuthKey.charAt(3)+"");
		}
	}
	
	private void setNextButtonEnable(boolean a_isEnable)
	{
		LinearLayout ibNext = (LinearLayout)findViewById(R.id.ib_pcclientauth_next);
		ibNext.setEnabled(a_isEnable);
		if(a_isEnable) {
			ibNext.setBackgroundColor(Color.parseColor("#323145"));
		}
	}
	
	private void getAuthKey()
	{
		GetPCClientAuthKeyReq req = new GetPCClientAuthKeyReq();
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetPCClientAuthKeyRes res = new GetPCClientAuthKeyRes(a_strData);
				m_strAuthKey = res.getAuthToken();
				setAuthKeyText(m_strAuthKey);
				closeProgress();
				checkAuthKey(m_strAuthKey);
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				if(nErrorCode == ApiResult.HTTP_SERVER_NOT_FOUND)
				{
					setAuthState(AUTHSTATE_STOP);
				}
				else
				{
					
				}
			}
		});
	}
	
	private void checkAuthKey(String a_strAuthToken)
	{
		PostPCClientAuthKeyCheckReq req = new PostPCClientAuthKeyCheckReq(a_strAuthToken);
		m_apiCheckAuth = new WebAPI(this);
		m_apiCheckAuth.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				PostPCClientAuthKeyCheckRes res = new PostPCClientAuthKeyCheckRes(a_strData);
				m_strSyncFileId = res.getSyncFileId();
				setNextButtonEnable(true);
				m_apiCheckAuth = null;
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				if(nErrorCode == ApiResult.HTTP_SERVER_NOT_FOUND || nErrorCode == ApiResult.HTTP_SERVER_TIMEOUT || nErrorCode == ApiResult.HTTP_ERR_TIME_OUT || nErrorCode == ApiResult.HTTP_USER_DEFINE)
				{
					setAuthState(AUTHSTATE_STOP);
				}
				else
				{
					
				}
				m_apiCheckAuth = null;
			}
		});
	}
	
	private void startDataSync()
	{
		DataSyncTask task = new DataSyncTask();
		task.execute();
	}
	
	private void sendDataSyncData(String a_strJson)
	{
		PostPCClientSyncFileUploadReq req = new PostPCClientSyncFileUploadReq(m_strSyncFileId);
		req.setSyncFileInfo(m_strSyncFileId, a_strJson.getBytes());
		WebAPI api = new WebAPI(this);
		api.requestUpload(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				setAuthState(AUTHSTATE_COMPLETE);
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				setAuthState(AUTHSTATE_DATASYNCERROR);
			}
		});
	}
	
	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private class DataSyncTask extends AsyncTask<Void, Void, String>
	{
		@Override
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String strJson = DBBackup.makeJsonByte(PCClientAuthAct.this);
			CommonLog.e(PCClientAuthAct.class.getSimpleName(), "DB Backup Json : " + strJson);
			return strJson;
		}
		
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			sendDataSyncData(result);
		}
	}
	
	private final int HANDLER_DATASYNCIMAGEANIMATION_DELAYTIME = 300;
	private Handler m_hDataSyncImageAnimation = new Handler()
	{
		private int m_nCount = 0;
		@Override
		public void handleMessage(Message msg) 
		{
			if(m_nAuthState == AUTHSTATE_DATASYNC)
			{
			/*	Bitmap bmp = m_bmpDataSync[m_nCount];*/
				ImageView ivDataSync = (ImageView)findViewById(R.id.iv_pcclientauth_datasync);
				ivDataSync.setBackgroundResource(R.drawable.img_pc_send);
			/*	ivDataSync.setImageBitmap(bmp);
				if(m_nCount == 4)
					m_nCount = 0;
				else
					m_nCount++;
				
				m_hDataSyncImageAnimation.sendEmptyMessageDelayed(0, HANDLER_DATASYNCIMAGEANIMATION_DELAYTIME);*/
			}
			super.handleMessage(msg);
		}
	};
}
