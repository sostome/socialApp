package com.gmp.rusk.response;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.datamodel.CompanyData;
import com.gmp.rusk.datamodel.CompanyEntryData;
import com.gmp.rusk.datamodel.FellowListData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.utils.CommonLog;

import java.util.ArrayList;

/**
 * @author Stan
 *		   서버 Interface 의 Response  데이터를 담을 추상 클래스
 */
public abstract class Res implements CompanyResObject, UserEntryResObject, UserInfoResObject, UserListResObject{
	public MyApp App = MyApp.getInstance();

	public final String JSON_RESULT = "result";
	public final String JSON_RESULTS = "results";
	public final String JSON_MESSAGE = "message";

	public static final String RES_TYPE_USER_COMPANY = "compnay";
	public static final String RES_TYPE_USER_ENTRY = "entry";
	public static final String RES_TYPE_USER_INFO = "info";
	public static final String RES_TYPE_USER_LIST = "list";
	public static final String RES_TYPE_USER_INFO_SINGLE = "info_single";

	protected String m_strResData = "";						// Result Data
	
//	protected int m_nResultCode = ApiResult.RESULT_FAIL;	// result
	protected int m_nResultCode = 0;
	
	protected String m_strMessage = "";						// message

	protected JSONObject jsonRoot = null;

	public CompanyEntryData m_CompanyEntryData = new CompanyEntryData();
	public FellowListData m_EntryUserInfoData = new FellowListData();
	public ArrayList<UserInfoData> m_arrUserInfoData = new ArrayList<UserInfoData>();
	public ArrayList<UserListData> m_arrUserListDatas = new ArrayList<UserListData>();
	public UserListData m_myUserListData = null;
	public String m_strTimestamp = "";

	public Res(String a_strData) {
		m_strResData = a_strData;

		parseResultCode();

	}

	public Res(String a_strData, String a_strType){
		m_strResData = a_strData;

		parseResultCode();
		//Info 로 받을 경우는 데이터를 직접 사용할 경우, List로 받을 경우는 데이터를 DB에 넣을 경우에 사용 한다.
		if(a_strType.equals(RES_TYPE_USER_COMPANY)) {
			parseCompanyData();
		} else if(a_strType.equals(RES_TYPE_USER_ENTRY)) {
			parseCompanyData();
			parseEntryUserData();
		} else if(a_strType.equals(RES_TYPE_USER_INFO)) {
			parseUserInfoData();
		} else if(a_strType.equals(RES_TYPE_USER_LIST)) {
			parseUserListdata();
		} else if(a_strType.equals(RES_TYPE_USER_INFO_SINGLE)){
			parseUserInfoDataSingle();
		}
	}
	
	// Parse resultCode and Message based on JSON 
	private void parseResultCode() {
		try
		{
			jsonRoot = new JSONObject(m_strResData);
			// set result code
			if(!jsonRoot.isNull(JSON_RESULT)) {
				m_nResultCode = jsonRoot.getInt(JSON_RESULT);
			}

			// set result message
			if(!jsonRoot.isNull(JSON_MESSAGE)) {
				m_strMessage = jsonRoot.getString(JSON_MESSAGE);
			} 	
			
			if(m_nResultCode != ApiResult.RESULT_SUCCESS) {
					//m_strMessage = NetError.getErrMessage(App.mContext, m_nResType, m_nResultCode);
			}				
			
							
		}
		catch(Exception e)
		{
			CommonLog.e(Res.class, "" + e.toString());
			m_strMessage = "JSON Error";
		}
		
	}

	@Override
	public void parseCompanyData() {

		try {
			if (!jsonRoot.isNull(JSON_COMPANY)) {
				JSONObject jsonCompanyItem = jsonRoot.getJSONObject(JSON_COMPANY);
				//m_CompanyEntryData = new CompanyEntryData();
				m_CompanyEntryData.strCode = jsonCompanyItem.getString(JSON_CODE);
				m_CompanyEntryData.strName = jsonCompanyItem.getString(JSON_NAME);
				//m_CompanyEntryData.arrMessageValidityPeriods = jsonCompanyItem.getJSONObject(JSON_MESSAGEVALIDITYPERIODS);
				JSONArray arrMessageValidityPeriods = jsonCompanyItem.getJSONArray(JSON_MESSAGEVALIDITYPERIODS);
				for (int i = 0; i < arrMessageValidityPeriods.length(); i++) {
					m_CompanyEntryData.arrMessageValidityPeriods.add((Integer) arrMessageValidityPeriods.get(i));
				}
				m_CompanyEntryData.isPartnerRegularSearchEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERREGULARSEARCHENABLED);
				m_CompanyEntryData.isPartnerChannelCreationEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERCHANNELCREATIONENABLED);
				m_CompanyEntryData.isRegularMobileImageSharingEnabled = jsonCompanyItem.getBoolean(JSON_REGULARMOBILEIMAGESHARINGENABLED);
				m_CompanyEntryData.isRegularMobileImageDownloadEnabled = jsonCompanyItem.getBoolean(JSON_REGULARMOBILEIMAGEDOWNLOADENABLED);
				m_CompanyEntryData.isRegularMobileNormalFileSharingEnabled = jsonCompanyItem.getBoolean(JSON_REGULARMOBILENORMALFILESHARINGENABLED);
				m_CompanyEntryData.isRegularMobileNormalFileDownloadEnabled = jsonCompanyItem.getBoolean(JSON_REGULARMOBILENORMALFILEDOWNLOADENABLED);
				m_CompanyEntryData.isRegularPcImageSharingEnabled = jsonCompanyItem.getBoolean((JSON_REGULARPCIMAGESHARINGENABLED));
				m_CompanyEntryData.isRegularPcImageDownloadEnabled = jsonCompanyItem.getBoolean(JSON_REGULARPCIMAGEDOWNLOADENABLED);
				m_CompanyEntryData.isRegularPcNormalFileSharingEnabled = jsonCompanyItem.getBoolean(JSON_REGULARPCNORMALFILESHARINGENABLED);
				m_CompanyEntryData.isRegularPcNormalFileDownloadEnabled = jsonCompanyItem.getBoolean(JSON_REGULARPCNORMALFILEDOWNLOADENABLED);
				m_CompanyEntryData.isPartnerMobileImageSharingEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERMOBILEIMAGESHARINGENABLED);
				m_CompanyEntryData.isPartnerMobileImageDownloadEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERMOBILEIMAGEDOWNLOADENABLED);
				m_CompanyEntryData.isPartnerMobileNormalFileSharingEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERMOBILENORMALFILESHARINGENABLED);
				m_CompanyEntryData.isPartnerMobileNormalFileDownloadEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERMOBILENORMALFILEDOWNLOADENABLED);
				m_CompanyEntryData.isPartnerPcImageSharingEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERPCIMAGESHARINGENABLED);
				m_CompanyEntryData.isPartnerPcImageDownloadEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERPCIMAGEDOWNLOADENABLED);
				m_CompanyEntryData.isPartnerPcNormalFileSharingEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERPCNORMALFILESHARINGENABLED);
				m_CompanyEntryData.isPartnerPcNormalFileDownloadEnabled = jsonCompanyItem.getBoolean(JSON_PARTNERPCNORMALFILEDOWNLOADENABLED);
				m_CompanyEntryData.isregularTApiCallEnabled = jsonCompanyItem.getBoolean(JSON_REGULARTAPICALLENABLED);
				App.m_EntryData.m_MultiTenancy = m_CompanyEntryData;
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	@Override
	public void parseEntryUserData() {

		try {
			String[] arrNotViewCompany = {"SKHY", "SKHYCL", "SKHYCQ", "SKHYA"};
			if (!jsonRoot.isNull(JSON_USER)) {
				JSONObject jsonUserItem = jsonRoot.getJSONObject(JSON_USER);
				if(!jsonUserItem.isNull(JSON_USERID)){
					App.m_EntryData.m_strUserId = jsonUserItem.getString(JSON_USERID);
					m_EntryUserInfoData.m_strUserId = App.m_EntryData.m_strUserId;
				}
				App.m_EntryData.m_nUserNo = jsonUserItem.getInt(JSON_USERNO);
				m_EntryUserInfoData.m_nUserNo = App.m_EntryData.m_nUserNo;
				App.m_EntryData.m_strUserType = jsonUserItem.getString(JSON_TYPE);
				m_EntryUserInfoData.m_strUserType = App.m_EntryData.m_strUserType;
				App.m_EntryData.m_strName = jsonUserItem.getString(JSON_NAME);
				m_EntryUserInfoData.m_strName = App.m_EntryData.m_strName;
				App.m_EntryData.m_strMobile = jsonUserItem.getString(JSON_MOBILE);
				m_EntryUserInfoData.m_strMobile = App.m_EntryData.m_strMobile;
				App.m_EntryData.m_strCompanyCode = jsonUserItem.getString(JSON_COMPANYCODE);
				boolean isSKH = false;
				for(int i = 0; i < arrNotViewCompany.length; i++){
					if(App.m_EntryData.m_strCompanyCode.equals(arrNotViewCompany[i])){
						isSKH = true;
						break;
					}
				}
				if(!isSKH) {
					ArrayList<CompanyData> arrRemovedCompanyData = new ArrayList<>();
					arrRemovedCompanyData.addAll(App.m_EntryData.m_arrCompanyData);
					for(int j = 0; j < App.m_EntryData.m_arrCompanyData.size(); j++){
						if(App.m_EntryData.m_arrCompanyData.get(j).strCode.equals("SKHY")){
							arrRemovedCompanyData.remove(App.m_EntryData.m_arrCompanyData.get(j));
						} else if(App.m_EntryData.m_arrCompanyData.get(j).strCode.equals("SKHYCL")){
							arrRemovedCompanyData.remove(App.m_EntryData.m_arrCompanyData.get(j));
						} else if(App.m_EntryData.m_arrCompanyData.get(j).strCode.equals("SKHYCQ")){
							arrRemovedCompanyData.remove(App.m_EntryData.m_arrCompanyData.get(j));
						} else if(App.m_EntryData.m_arrCompanyData.get(j).strCode.equals("SKHYA")){
							arrRemovedCompanyData.remove(App.m_EntryData.m_arrCompanyData.get(j));
						}
					}
					App.m_EntryData.m_arrCompanyData = arrRemovedCompanyData;
				}
				m_EntryUserInfoData.m_strCompanyCode = App.m_EntryData.m_strCompanyCode;
				if(!jsonUserItem.isNull(JSON_COMPANYNAME)){
					App.m_EntryData.m_strCompanyName = jsonUserItem.getString(JSON_COMPANYNAME);
					m_EntryUserInfoData.m_strCompany = App.m_EntryData.m_strCompanyName;
				}
				if (!jsonUserItem.isNull(JSON_DEPARTMENT)) {
					App.m_EntryData.m_strDepartment = jsonUserItem.getString(JSON_DEPARTMENT);
					m_EntryUserInfoData.m_strDepartment = App.m_EntryData.m_strDepartment;
				}
				if (!jsonUserItem.isNull(JSON_DEPARTMENTCODE)) {
					App.m_EntryData.m_strDepartmentCode = jsonUserItem.getString(JSON_DEPARTMENTCODE);
					m_EntryUserInfoData.m_strDepartmentCode = App.m_EntryData.m_strDepartmentCode;
				}
				if (!jsonUserItem.isNull(JSON_PARENTDEPARTMENT)) {
					App.m_EntryData.m_strParentDepartment = jsonUserItem.getString(JSON_PARENTDEPARTMENT);
					m_EntryUserInfoData.m_strParentDepartment = App.m_EntryData.m_strParentDepartment;
				}
				if (!jsonUserItem.isNull(JSON_CHARGE)) {
					App.m_EntryData.m_strCharge = jsonUserItem.getString(JSON_CHARGE);
					m_EntryUserInfoData.m_strCharge = App.m_EntryData.m_strCharge;
				}
				if (!jsonUserItem.isNull(JSON_SECONDCHARGE)) {
					App.m_EntryData.m_strSecondCharge = jsonUserItem.getString(JSON_SECONDCHARGE);
					m_EntryUserInfoData.m_strSecondCharge = App.m_EntryData.m_strSecondCharge;
				}
				if (!jsonUserItem.isNull(JSON_AFFILIATION)) {
					App.m_EntryData.m_strAffiliation = jsonUserItem.getString(JSON_AFFILIATION);
					m_EntryUserInfoData.m_strAffiliation = App.m_EntryData.m_strAffiliation;
					//일단 임시로 적용
					m_EntryUserInfoData.m_strCompany = App.m_EntryData.m_strAffiliation;
				}
				App.m_EntryData.m_isImageAvailable = jsonUserItem.getBoolean(JSON_IMAGEAVAILABLE);
				m_EntryUserInfoData.m_isImageAvailable = App.m_EntryData.m_isImageAvailable;
				if (!jsonRoot.isNull(JSON_GREETING)) {
					App.m_EntryData.m_strGreeting = jsonUserItem.getString(JSON_GREETING);
					m_EntryUserInfoData.m_strGreeting = App.m_EntryData.m_strGreeting;
				}
				App.m_EntryData.m_isActive = jsonUserItem.getBoolean(JSON_AVAILABLE);
				m_EntryUserInfoData.m_isActive = App.m_EntryData.m_isActive;

				PersonalData personalData = new PersonalData(App.m_EntryData.m_strName, App.m_EntryData.m_strEmail, App.m_EntryData.m_strMobile,
						App.m_EntryData.m_strCompanyCode, App.m_EntryData.m_strCompanyName, App.m_EntryData.m_strDepartment,
						App.m_EntryData.m_strParentDepartment, App.m_EntryData.m_strCharge, "", App.m_EntryData.m_strSecondCharge,
						App.m_EntryData.m_strAffiliation);

				m_myUserListData = new UserListData(App.m_EntryData.m_nUserNo, personalData, App.m_EntryData.m_strUserType, App.m_EntryData.m_isImageAvailable,
						App.m_EntryData.m_isActive, App.m_EntryData.m_strGreeting, "A", false, "");

			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	@Override
	public void parseUserInfoData() {

		try {
			if(!jsonRoot.isNull(JSON_USERS) || !jsonRoot.isNull(JSON_RESULTS)) {
				JSONArray jsonArray = null;
				if (!jsonRoot.isNull(JSON_USERS)) {
					jsonArray = jsonRoot.getJSONArray(JSON_USERS);
				} else if (!jsonRoot.isNull(JSON_RESULTS)) {
					jsonArray = jsonRoot.getJSONArray(JSON_RESULTS);
				}
				if (jsonArray != null) {
					for (int i = 0; i < jsonArray.length(); i++) {
						UserInfoData userInfoData = new UserInfoData();
						JSONObject userInfoDataObject = jsonArray.getJSONObject(i);
						userInfoData.m_nUserNo = userInfoDataObject.getInt(JSON_USERNO);
						userInfoData.m_strUserType = userInfoDataObject.getString(JSON_TYPE);
						userInfoData.m_strName = userInfoDataObject.getString(JSON_NAME);
						userInfoData.m_strEmail = userInfoDataObject.getString(JSON_EMAIL);
						userInfoData.m_strMobile = userInfoDataObject.getString(JSON_MOBILE);
						userInfoData.m_strCompanyCode = userInfoDataObject.getString(JSON_COMPANYCODE);
						if(!userInfoDataObject.isNull(JSON_COMPANYNAME)){
							userInfoData.m_strCompanyName = userInfoDataObject.getString(JSON_COMPANYNAME);
						}
						if (!userInfoDataObject.isNull(JSON_DEPARTMENT)) {
							userInfoData.m_strDepartment = userInfoDataObject.getString(JSON_DEPARTMENT);
						}
						if (!userInfoDataObject.isNull(JSON_PARENTDEPARTMENT)) {
							userInfoData.m_strParentDepartment = userInfoDataObject.getString(JSON_PARENTDEPARTMENT);
						}
						if (!userInfoDataObject.isNull(JSON_CHARGE)) {
							userInfoData.m_strCharge = userInfoDataObject.getString(JSON_CHARGE);
						}
						if (!userInfoDataObject.isNull(JSON_POSITION)) {
							userInfoData.m_strPosition = userInfoDataObject.getString(JSON_POSITION);
						}
						if (!userInfoDataObject.isNull(JSON_SECONDCHARGE)) {
							userInfoData.m_strSecondCharge = userInfoDataObject.getString(JSON_SECONDCHARGE);
						}
						if (!userInfoDataObject.isNull(JSON_AFFILIATION)) {
							userInfoData.m_strAffiliation = userInfoDataObject.getString(JSON_AFFILIATION);
						} else {
						}
						userInfoData.m_isImageAvailable = userInfoDataObject.getBoolean(JSON_IMAGEAVAILABLE);
						if (!userInfoDataObject.isNull(JSON_GREETING)) {
							userInfoData.m_strGreeting = userInfoDataObject.getString(JSON_GREETING);
						}
						userInfoData.m_isAvailable = userInfoDataObject.getBoolean(JSON_AVAILABLE);
						userInfoData.m_strStatus = userInfoDataObject.getString(JSON_STATUS);
						m_arrUserInfoData.add(userInfoData);
					}
				}
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	@Override
	public void parseUserInfoDataSingle() {

		try {

						UserInfoData userInfoData = new UserInfoData();
						JSONObject userInfoDataObject = jsonRoot;
						userInfoData.m_nUserNo = userInfoDataObject.getInt(JSON_USERNO);
						userInfoData.m_strUserType = userInfoDataObject.getString(JSON_TYPE);
						userInfoData.m_strName = userInfoDataObject.getString(JSON_NAME);
						userInfoData.m_strEmail = userInfoDataObject.getString(JSON_EMAIL);
						userInfoData.m_strMobile = userInfoDataObject.getString(JSON_MOBILE);
						userInfoData.m_strCompanyCode = userInfoDataObject.getString(JSON_COMPANYCODE);
						if(!userInfoDataObject.isNull(JSON_COMPANYNAME)){
							userInfoData.m_strCompanyName = userInfoDataObject.getString(JSON_COMPANYNAME);
						}
						if (!userInfoDataObject.isNull(JSON_DEPARTMENT)) {
							userInfoData.m_strDepartment = userInfoDataObject.getString(JSON_DEPARTMENT);
						}
						if (!userInfoDataObject.isNull(JSON_PARENTDEPARTMENT)) {
							userInfoData.m_strParentDepartment = userInfoDataObject.getString(JSON_PARENTDEPARTMENT);
						}
						if (!userInfoDataObject.isNull(JSON_CHARGE)) {
							userInfoData.m_strCharge = userInfoDataObject.getString(JSON_CHARGE);
						}
						if (!userInfoDataObject.isNull(JSON_POSITION)) {
							userInfoData.m_strPosition = userInfoDataObject.getString(JSON_POSITION);
						}
						if (!userInfoDataObject.isNull(JSON_SECONDCHARGE)) {
							userInfoData.m_strSecondCharge = userInfoDataObject.getString(JSON_SECONDCHARGE);
						}
						if (!userInfoDataObject.isNull(JSON_AFFILIATION)) {
							userInfoData.m_strAffiliation = userInfoDataObject.getString(JSON_AFFILIATION);
						} else {
						}
						userInfoData.m_isImageAvailable = userInfoDataObject.getBoolean(JSON_IMAGEAVAILABLE);
						if (!userInfoDataObject.isNull(JSON_GREETING)) {
							userInfoData.m_strGreeting = userInfoDataObject.getString(JSON_GREETING);
						}
						userInfoData.m_isAvailable = userInfoDataObject.getBoolean(JSON_AVAILABLE);
						userInfoData.m_strStatus = userInfoDataObject.getString(JSON_STATUS);
						m_arrUserInfoData.add(userInfoData);

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	@Override
	public void parseUserListdata() {


		int m_nUserNo = 0;						//사용자 번호
		String m_strUserType = "";				//사용자 유형 R:정직원 P:파트너
		String m_strName = "";					//이름
		String m_strEmail = "";				//이메일
		String m_strMobile = "";				//전화번호
		String m_strCompanyCode = "";
		String m_strCompanyName = "";
		String m_strDepartment = "";				//부서
		String m_strDepartmentCode = "";
		String m_strParentDepartment = "";					//소속
		String m_strCharge = "";					//직책
		String m_strPosition = "";					//지위
		String m_strSecondCharge = "";			//겸직 직책
		String m_strCompany = "";				//파트너회사명
		String m_strAffiliation = "";
		boolean m_isImageAvailable = false;		//이미지 보유 여부
		String m_strGreeting ="";
		boolean m_isAvailable = false;				//사용자 앱 설치 유무
		String m_strStatus = "";
		try {
			if(!jsonRoot.isNull(JSON_USERS)){
			JSONArray jsonArray = jsonRoot.getJSONArray(JSON_USERS);

				if(!jsonRoot.isNull(JSON_TIMESTAMP))
					m_strTimestamp = jsonRoot.getString(JSON_TIMESTAMP);

			for (int i = 0; i < jsonArray.length(); i++) {


				JSONObject userInfoDataObject = jsonArray.getJSONObject(i);

				if(!userInfoDataObject.isNull(JSON_USERNO))
					m_nUserNo = userInfoDataObject.getInt(JSON_USERNO);
				if(!userInfoDataObject.isNull(JSON_TYPE))
					m_strUserType = userInfoDataObject.getString(JSON_TYPE);
				if(!userInfoDataObject.isNull(JSON_NAME))
					m_strName = userInfoDataObject.getString(JSON_NAME);
				if(!userInfoDataObject.isNull(JSON_EMAIL))
					m_strEmail = userInfoDataObject.getString(JSON_EMAIL);
				if(!userInfoDataObject.isNull(JSON_MOBILE))
					m_strMobile = userInfoDataObject.getString(JSON_MOBILE);
				if(!userInfoDataObject.isNull(JSON_COMPANYCODE))
					m_strCompanyCode = userInfoDataObject.getString(JSON_COMPANYCODE);
				if(!userInfoDataObject.isNull(JSON_COMPANYNAME)){
					m_strCompanyName = userInfoDataObject.getString(JSON_COMPANYNAME);
				}
				if (!userInfoDataObject.isNull(JSON_DEPARTMENT)) {
					m_strDepartment = userInfoDataObject.getString(JSON_DEPARTMENT);
				}
				if (!userInfoDataObject.isNull(JSON_PARENTDEPARTMENT)) {
					m_strParentDepartment = userInfoDataObject.getString(JSON_PARENTDEPARTMENT);
				}
				if (!userInfoDataObject.isNull(JSON_CHARGE)) {
					m_strCharge = userInfoDataObject.getString(JSON_CHARGE);
				}
				if (!userInfoDataObject.isNull(JSON_POSITION)) {
					m_strPosition = userInfoDataObject.getString(JSON_POSITION);
				}
				if (!userInfoDataObject.isNull(JSON_SECONDCHARGE)) {
					m_strSecondCharge = userInfoDataObject.getString(JSON_SECONDCHARGE);
				}
				if (!userInfoDataObject.isNull(JSON_AFFILIATION)) {
					m_strAffiliation = userInfoDataObject.getString(JSON_AFFILIATION);
				}
				if(!userInfoDataObject.isNull(JSON_IMAGEAVAILABLE))
					m_isImageAvailable = userInfoDataObject.getBoolean(JSON_IMAGEAVAILABLE);
				if (!userInfoDataObject.isNull(JSON_GREETING)) {
					m_strGreeting = userInfoDataObject.getString(JSON_GREETING);
				}
				if(!userInfoDataObject.isNull(JSON_AVAILABLE))
					m_isAvailable = userInfoDataObject.getBoolean(JSON_AVAILABLE);
				if(!userInfoDataObject.isNull(JSON_STATUS))
					m_strStatus = userInfoDataObject.getString(JSON_STATUS);

				PersonalData personalData = new PersonalData(m_strName, m_strEmail, m_strMobile, m_strCompanyCode, m_strCompanyName, m_strDepartment, m_strParentDepartment, m_strCharge, m_strPosition, m_strSecondCharge,
						m_strAffiliation);

				UserListData userListData = new UserListData(m_nUserNo, personalData, m_strUserType, m_isImageAvailable,
						m_isAvailable, m_strGreeting, m_strStatus, false, "");
				m_arrUserListDatas.add(userListData);
			}
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	@Override
	public CompanyEntryData getCompanyData() {
		return m_CompanyEntryData;
	}

	@Override
	public FellowListData getEntryUserData(Context context) {
		if(TTalkDBManager.ContactsDBManager.getContacts(context, m_EntryUserInfoData.m_nUserNo) == null){
			TTalkDBManager.ContactsDBManager.insertContacts(context, m_myUserListData);
		}
		return m_EntryUserInfoData;
	}

	@Override
	public ArrayList<UserInfoData> getUserInfoDatas() {
		return m_arrUserInfoData;
	}

	@Override
	public ArrayList<UserListData> getUserListData() {
		return m_arrUserListDatas;
	}

	// Get Result Code
	public int getResultCode() {
		return m_nResultCode;
	}
	
	// get Message
	public String getMessage() {
		return m_strMessage;
	}
	
	// Parse each data based on JSON
	public abstract void parseData();
	
}
