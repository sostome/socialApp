package com.gmp.rusk.request;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;



/**
 *	@author kch
 *			BackUp 업로드
 *			method : post
 *			Accept Media Type: multipart/form-data
 */

public class PutBackUpFileUploadReq extends UploadReq{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "POST";
	
	
	public PutBackUpFileUploadReq()
	{
		APINAME = APINAME +"/"+App.m_MyUserInfo.m_nUserNo +"/backup";
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
	
	//private String m_strSyncFileId = "";
	private byte[] m_byteFileData = null;
	
	public void setSyncFileInfo(byte[] a_byteData)
	{
		m_byteFileData = a_byteData;
	}
	
	private final String MULTIPART_KEY_FILE = "file";

	
	@Override
	public MultipartEntity getMultiPartEntity()
	{
		if(m_byteFileData != null)
		{
			MultipartEntity multiPart = new MultipartEntity();
			
			ContentBody fileBody = new ByteArrayBody(m_byteFileData, "" + App.m_EntryData.m_nUserNo + "_backupData.json");
			multiPart.addPart(MULTIPART_KEY_FILE, fileBody);
			
			
			return multiPart;
		}
		else 
			return null;
	}
}
