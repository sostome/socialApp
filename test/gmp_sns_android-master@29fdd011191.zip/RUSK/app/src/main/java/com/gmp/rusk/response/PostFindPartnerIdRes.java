package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

public class PostFindPartnerIdRes extends Res{
	private final String JSON_USERID 					= "userId";
	
	public String m_strUserId = "";
	
	public PostFindPartnerIdRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if(!jsonRoot.isNull(JSON_USERID)) {
				m_strUserId = jsonRoot.optString(JSON_USERID);
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

}
