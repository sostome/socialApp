package com.gmp.rusk.act;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CommonPopupTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.layout.SNSUserListItemLayout;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetGroupUserReq;
import com.gmp.rusk.request.PutGroupOwnerReq;
import com.gmp.rusk.response.GetGroupUserRes;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.Utils;

import java.util.ArrayList;

/**
 * ChatRoomOwnerAct
 * 
 * @author kch 방장권한 위임 Activity
 */

public class SNSOwnerAct extends CustomActivity{

	ArrayList<UserListData> m_arrUserListDatas = null;
	UserListAdapter m_UserListAdapter;
	ImageView m_btnComplete;
	ArrayList<Integer> m_arrUserNo;
	// 진입시 방장
	int m_nOwnerNo;
	private ListView m_lvUserList = null;
	// 전달 해 줄 방장
	int m_nSendOwnerNo = 0;

	
	String m_strChatRoomID = "";

	CommonPopup m_Popup;
	int m_nGroupId;
	//int m_nPopupType;
	
	ArrayList<SNSGroupMemberData> m_arrInvitedMember = new ArrayList<SNSGroupMemberData>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_sns_owner);
		m_arrUserListDatas = new ArrayList<UserListData>();

		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_nGroupId = bundle.getInt(IntentKeyString.INTENT_KEY_SNSGROUPMEMBERLIST_GROUPID);
		}
		ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(this);
		for(int i = 0; i < arrRoomData.size(); i++){
			if(arrRoomData.get(i).m_strRoomId.split("\\_").length == 3){
				if(arrRoomData.get(i).m_strRoomId.split("\\_")[2].equals(Integer.toString(m_nGroupId))){
					m_strChatRoomID = arrRoomData.get(i).m_strRoomId;
					break;
				}
			}
		}
		
		getGroupMemberList();

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			m_nSendOwnerNo = 0;
			Intent intent = new Intent();

			setResult(RESULT_CANCELED, intent);
			finish();
		}
		return super.onKeyDown(keyCode, event);

	}

	
	public void initOrganChartUI() {
		ImageView btnTopClose = (ImageView)findViewById(R.id.btn_top_close);
		btnTopClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});

		m_lvUserList = (ListView) findViewById(R.id.lv_chat_member_list);
		m_btnComplete = (ImageView) findViewById(R.id.btn_complete);
		if (m_arrUserListDatas != null) {
			m_UserListAdapter = new UserListAdapter();
			m_lvUserList.setAdapter(m_UserListAdapter);
		}
		m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
		//m_btnComplete.setOnClickListener(this);
	}

	public void reDrawUI() {
		m_UserListAdapter.notifyDataSetChanged();
	}

	public void setOwner(int a_nOwner) {
		m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);
		m_btnComplete.setOnClickListener(this);
		m_nSendOwnerNo = a_nOwner;
	}

	public int getOwner() {
		return m_nSendOwnerNo;
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		if(m_UserListAdapter != null)
			m_UserListAdapter.notifyDataSetChanged();
		super.onResume();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		switch (v.getId()) {
		case R.id.btn_complete:

			if (m_nSendOwnerNo != 0) {
				
				boolean isInUser = true;
				//모임 방이 있는 경우, 모임방의 유저인지 아닌지 체크
				ArrayList<ChattingRoomInfoData> arrRoomData = RoomDBManager.getChattingRoom(SNSOwnerAct.this);
				for(int j = 0; j < arrRoomData.size(); j++){
					if(arrRoomData.get(j).m_strRoomId.split("\\_").length == 3){
						if(arrRoomData.get(j).m_strRoomId.split("\\_")[2].equals(Integer.toString(m_nGroupId))){
							ChattingDBManager dbMng = new ChattingDBManager(this);
							dbMng.openReadable(arrRoomData.get(j).m_strRoomId);
							ArrayList<Integer> arrUsers = dbMng.getChattingUser();
							dbMng.close();
							for(int x = 0; x < arrUsers.size(); x++){
								if(m_nSendOwnerNo == arrUsers.get(x)){
									break;
								}
								if(x == arrUsers.size() - 1){
									isInUser = false;
								}
							}
						}
					}
				}
				if(isInUser){
				String strName = "";
				for(int i = 0; i < m_arrUserListDatas.size(); i++){
					if(m_arrUserListDatas.get(i).m_nUserNo == m_nSendOwnerNo){
						strName = m_arrUserListDatas.get(i).m_PersonalData.mapPersonalData.get(PersonalData.NAME);
					}
				}
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getString(R.string.snsgroupowner_title), String.format(getString(R.string.snsgroupowner_popup_text), strName));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				}
				else {
					m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_SNS_OWNER_FAIL);
					m_Popup.setBodyAndTitleText(getString(R.string.snsgroupowner_title), getString(R.string.snsgroupowner_popup_nouser));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			} 
			break;
		case R.id.ib_pop_ok_long:
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			
			if(popup_ok_long.m_nPrevAction == CommonPopupTypeInt.COMMONPOPUP_SNS_OWNER){
			Intent intent = new Intent();

			setResult(RESULT_OK, intent);
			finish();
			} else {
				
			}
			popup_ok_long.cancel();
			break;
		case R.id.ib_pop_ok:
			
			final CommonPopup popup_ok = (CommonPopup)v.getTag();
			PutGroupOwnerReq req = new PutGroupOwnerReq(m_nGroupId, m_nSendOwnerNo);
			WebAPI api = new WebAPI(this);
			api.request(req, new WebListener() {
				
				@Override
				public void onPreRequest() {
					// TODO Auto-generated method stub
					//mService.passOwner(nUserID, strRoomID)
				}
				
				@Override
				public void onPostRequest(String a_strData) {
					// TODO Auto-generated method stub
					/*if(!m_strChatRoomID.equals(""))
						mService.passOwner(m_nSendOwnerNo, m_strChatRoomID);*/
					m_nSendOwnerNo = 0;
					popup_ok.cancel();
					m_Popup = new CommonPopup(SNSOwnerAct.this, SNSOwnerAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, CommonPopupTypeInt.COMMONPOPUP_SNS_OWNER);
					m_Popup.setBodyAndTitleText(getString(R.string.snsgroupowner_title), getString(R.string.snsgroupowner_popup_success_text));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
					
				}
				
				@Override
				public void onNetworkError(int nErrorCode, String strMessage) {
					// TODO Auto-generated method stub
					popup_ok.cancel();
					showErrorPopup(nErrorCode, strMessage);
				}
			});
			
			
			break;
		case R.id.ib_pop_cancel:
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			break;
		default:
			break;
		}
	}

	private class UserListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nUserListDataSize = 0;

			if (m_arrUserListDatas != null)
				nUserListDataSize = m_arrUserListDatas.size();

			return nUserListDataSize;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_arrUserListDatas != null && position < m_arrUserListDatas.size())
				return m_arrUserListDatas.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			UserListData userData;

			if (nPosition < m_arrUserListDatas.size()) {
				userData = (UserListData) m_arrUserListDatas.get(nPosition);
				// convertView null 시 새로 생성하자
				if (convertView == null)
					convertView = new SNSUserListItemLayout(SNSOwnerAct.this, SNSUserListItemLayout.CHATROOM_ITEM_TYPE_OWNER);
				((SNSUserListItemLayout) convertView).setUserListData(userData);
			}

			return convertView;
		}
	}

	private void getGroupMemberList()
	{
		GetGroupUserReq req = new GetGroupUserReq(m_nGroupId);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				GetGroupUserRes res = new GetGroupUserRes(a_strData);
				m_arrInvitedMember = res.getGroupMemberList();
				m_arrUserListDatas = new ArrayList<UserListData>();
				m_arrUserNo = new ArrayList<Integer>();
				for(int j = 0; j < m_arrInvitedMember.size(); j++){
					m_arrUserNo.add(m_arrInvitedMember.get(j).m_nUserNo);
				}
				for (int nUserNo : m_arrUserNo) {
					if (nUserNo != App.m_MyUserInfo.m_nUserNo) {
						UserListData userListData = ContactsDBManager.getContacts(SNSOwnerAct.this, nUserNo);
						if(userListData != null)
							m_arrUserListDatas.add(userListData);
					} else {
						UserListData userListData = ContactsDBManager.getContacts(SNSOwnerAct.this, nUserNo);
						if(userListData != null)
							m_arrUserListDatas.add(0,userListData);
					}
				}

				initOrganChartUI();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				//Toast.makeText(SNSOwnerAct.this, "Group Member List Fail : " + strMessage, Toast.LENGTH_SHORT).show();
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
	
}
