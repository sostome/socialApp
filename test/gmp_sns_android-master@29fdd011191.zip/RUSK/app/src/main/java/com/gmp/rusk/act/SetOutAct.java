package com.gmp.rusk.act;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeletePartnerWithdrawalReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.PopupIndex;

/**
 * SetOutAct
 * 
 * @author subi78 탈퇴 Activity
 */
public class SetOutAct extends CustomActivity {
	EditText et_password;

	private ProgressDlg m_Progress = null;
	private CommonPopup m_Popup = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_set_out);
		setResult(Activity.RESULT_CANCELED);
		setAccountManagementUI();
	}


	
	private void setAccountManagementUI() {
		et_password = (EditText) findViewById(R.id.et_password);
			ImageView btn_close = (ImageView) findViewById(R.id.btn_cancel);
		btn_close.setOnClickListener(this);

		ImageView btn_set_out_rightbtn = (ImageView) findViewById(R.id.btn_set_out_rightbtn);
		btn_set_out_rightbtn.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		if (v.getId() == R.id.btn_set_out_rightbtn) {
			String strPw = et_password.getText().toString();

			if (strPw.length() < 8) {
				m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.partner_signup_popup_pw_length).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			if (!strPw.equals(App.m_PartnerPW)) {
				m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.set_out_password_fail).toString());
				m_Popup.setCancelable(false);
				isCheckShowPopup();
				return;
			}

			requestDeletePartnerWithdrawal();
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if(popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED)
			{	
				popup_ok_long.cancel();
				App.expirePartnerLogin(this);
			}
			else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOPUP_OUT || popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(SetOutAct.this);
			}
			else
				popup_ok_long.cancel();
			
		} else if(v.getId() == R.id.btn_cancel){
			finish();
		}
	}

	private void requestDeletePartnerWithdrawal() {
		showProgress();
		DeletePartnerWithdrawalReq req = new DeletePartnerWithdrawalReq();
		WebAPI webApi = new WebAPI(this);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				
				// TODO Auto-generated method stub
				showOutCompletePopup();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				closeProgress();
				// TODO Auto-generated method stub
				if(a_nErrorCode == ApiResult.HTTP_SERVER_PARTNER_SESSION_EXPIRATION)
				{
					m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				} else if (a_nErrorCode == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
					m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_401_error));
					m_Popup.setCancelable(false);
					m_Popup.show();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_CHANGE_DEVICE)
				{
					m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE);
					m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.pop_changeDevice));
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else if(a_nErrorCode == ApiResult.HTTP_SERVER_PATNER_QUIT_SNS_ERROR)
				{
					m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
				else
				{
					m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this,
							CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
					m_Popup.setBodyAndTitleText(
							getString(R.string.pop_error_title).toString(),
							a_strMessage);
					m_Popup.setCancelable(false);
					isCheckShowPopup();
				}
			}
		});
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
	
	private void showOutCompletePopup()
	{
		closeProgress();
		if(m_Popup == null || !m_Popup.isShowing())
		{
			m_Popup = new CommonPopup(SetOutAct.this, SetOutAct.this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, PopupIndex.INDEX_PREVPOPUP_OUT);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title).toString(), getString(R.string.set_out_success).toString());
			m_Popup.setCancelable(false);
			isCheckShowPopup();
		}
	}

	
	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
}
