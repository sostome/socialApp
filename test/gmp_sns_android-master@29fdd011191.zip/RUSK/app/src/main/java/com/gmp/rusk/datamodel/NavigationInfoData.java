package com.gmp.rusk.datamodel;

public class NavigationInfoData {

	String m_strDepartmentCode = "";		//부서 코드
	String m_strDepartmentName = "";		//부서 이름
	
	public NavigationInfoData(String a_strDepartmentCode, String a_strDepartmentName) {
		m_strDepartmentCode = a_strDepartmentCode;
		m_strDepartmentName = a_strDepartmentName;
	}
	
	public String getDepartMentCode(){
		return m_strDepartmentCode;
	}
	
	public String getDepartMentName(){
		return m_strDepartmentName;
	}
}
