package com.gmp.rusk.db;

import android.content.Context;
import android.database.Cursor;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by kang on 2017-03-02.
 */

public class ChattingSelectDBManager {

    private ChattingSelectDBAdapter m_ChattingSelectDB = null;
    private Context m_Context = null;

    public ChattingSelectDBManager(Context a_Context){m_Context = a_Context;}

    public void openWritable(){
        m_ChattingSelectDB = new ChattingSelectDBAdapter(m_Context);
        m_ChattingSelectDB.open();
    }

    public void close(){
        m_ChattingSelectDB.close();
        m_ChattingSelectDB = null;
    }
    public int insertChattingSelect(String msgId, JSONArray selectList){
        return m_ChattingSelectDB.insertChattingSelectMessage(msgId,selectList);
    }
    public int deleteChattingMessage(){
        return m_ChattingSelectDB.deleteChattingSelect();
    }
    public int deleteChattingMessage(String a_strMsgId){
        return m_ChattingSelectDB.deleteChattingSelect(a_strMsgId);
    }
    public ArrayList<HashMap<String,String>> getSelectList(){

        ArrayList<HashMap<String,String>> arrSelectList = new ArrayList<>();
        Cursor cursor = m_ChattingSelectDB.getChattingSelect();
        if(cursor.moveToFirst()){
            do{
                String strMsgId = cursor.getString(0);
                String strSelectList = cursor.getString(1);
                HashMap<String,String> mapSelectList = new HashMap<>();
                mapSelectList.put(strMsgId,strSelectList);
                arrSelectList.add(mapSelectList);
            }while (cursor.moveToNext());
        }
        cursor.close();

        return arrSelectList;
    }
    public HashMap<String,String> getSelectList(String msgId){

        HashMap<String,String> mapSelectList = new HashMap<>();
        Cursor cursor = m_ChattingSelectDB.getChattingSelect(msgId);
        if(cursor.moveToFirst()){
            String strMsgId = cursor.getString(0);
            String strSelectList = cursor.getString(1);
            mapSelectList.put(strMsgId,strSelectList);
        }
        cursor.close();
        return mapSelectList;
    }
}
