package com.gmp.rusk.layout;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.datamodel.ApprovalListData;
import com.gmp.rusk.datamodel.UserInfoData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

/**
 * ApprovalUserListItemLayout
 * 승인자 List Item Layout
 */
public class ApprovalUserListItemLayout extends CustomLinearLayout implements OnClickListener{
	
	Button ib_approvalreq;
	Context m_Context;
	
	private OnApprovalRequestListener m_ApprovalRequestListener = null;
	
	private UserInfoData m_ApprovalSearchListData = null;
	
	private CommonPopup m_Popup = null;
	
	private ProgressDlg m_Progress = null;
	
	private String m_strImageUrlTemplate = "";
	
	public ApprovalUserListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public ApprovalUserListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}
	
	private void init(Context a_context)
	{
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		layoutInflater.inflate(R.layout.layout_listitem_partner_approvalreq, this);
		
	}
	
	public void setApprovalSearchListData(UserInfoData a_Data, String a_strImageUrlTemplate)
	{	
		m_ApprovalSearchListData = a_Data;
		m_strImageUrlTemplate = a_strImageUrlTemplate;
		setUiData();
	}
	
	// UI 세팅
	private void setUiData()
	{
		ImageView iv_profile_pic = (ImageView)findViewById(R.id.iv_profile_pic);
		
		
		if(m_ApprovalSearchListData.m_isImageAvailable)
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, m_strImageUrlTemplate.replace("{userNo}", ""+m_ApprovalSearchListData.m_nUserNo), R.drawable.profile_pic_default, false);		
		}
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}
		
		TextView tv_name = (TextView)findViewById(R.id.tv_name);
		TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
		tv_name.setText(m_ApprovalSearchListData.m_strName);
		LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
		TextView tv_position = (TextView) findViewById(R.id.tv_position);
		LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
		TextView tv_charge = (TextView) findViewById(R.id.tv_charge);

		if(m_ApprovalSearchListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_ApprovalSearchListData.m_strPosition !=null && !m_ApprovalSearchListData.m_strPosition.equals("")){
			layout_position.setVisibility(VISIBLE);
			tv_position.setText(m_ApprovalSearchListData.m_strPosition);
		} else {
			layout_position.setVisibility(GONE);
		}

		if(m_ApprovalSearchListData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_ApprovalSearchListData.m_strCharge!=null && !m_ApprovalSearchListData.m_strCharge.equals("")){
			layout_charge.setVisibility(VISIBLE);
			tv_charge.setText(m_ApprovalSearchListData.m_strCharge);
		} else {
			layout_charge.setVisibility(GONE);
		}

		if(m_ApprovalSearchListData.m_isAvailable)
		{
			tv_uninstall.setVisibility(GONE);
		}
		else
		{
			tv_uninstall.setVisibility(VISIBLE);
		}
		
		TextView tv_departments = (TextView)findViewById(R.id.tv_departments);

		if (m_ApprovalSearchListData.m_strUserType.equals(StaticString.VARIANT_REGULAR)) {
			tv_departments.setText(m_ApprovalSearchListData.m_strDepartment+" | "+m_ApprovalSearchListData.m_strCompany);
		}

		
		ib_approvalreq = (Button)findViewById(R.id.ib_approvalreq);
		ib_approvalreq.setOnClickListener(this);

//		UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_ApprovalSearchListData.m_nUserNo); 
		if(m_ApprovalSearchListData.m_isAvailable)
		{
			ib_approvalreq.setVisibility(View.VISIBLE);
			
//			if(userData != null)
//			{
//				if(userData.m_isFellow)
//					ib_approvalreq.setVisibility(View.INVISIBLE);
//			}
		}
		else
			ib_approvalreq.setVisibility(View.GONE);

		
		RelativeLayout layout_listitem_search = (RelativeLayout)findViewById(R.id.layout_listitem_search);
		layout_listitem_search.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()== R.id.ib_approvalreq)
		{	
			CommonLog.e("","ib_approvalreq");
			m_ApprovalRequestListener.onApprovalRequest(m_ApprovalSearchListData.m_nUserNo, m_ApprovalSearchListData.m_strName);
		}
		else if(v.getId()==R.id.layout_listitem_search)
		{
			CommonLog.e("","layout_listitem_search");
//			doShowProfile();
		}
		else if(v.getId()==R.id.ib_pop_ok_long)
		{
			m_Popup.hide();
		}
	}
	
//	private void doShowProfile()
//	{
//		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
//		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_ApprovalSearchListData.m_nUserNo);
//		m_Context.startActivity(intent);
//	}
	    
	public void setApprovalRequestListener(OnApprovalRequestListener a_Listener)
	{
		m_ApprovalRequestListener = a_Listener;
	}

	public interface OnApprovalRequestListener {
        public void onApprovalRequest(int a_nApprovalUserNo, String a_strApprovalUserName);
    }
	
    public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
    
	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context, a_strMsg);
		
		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
