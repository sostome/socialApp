package com.gmp.rusk.act;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;


import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.layout.ChatRoomUserListItemLayout;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

/**
 * ChatRoomOwnerAct
 * 
 * @author kch 방장권한 위임 Activity
 */

public class ChatRoomOwnerAct extends CustomActivity{

	ArrayList<UserListData> m_arrUserListDatas = null;
	UserListAdapter m_UserListAdapter;
	ImageView m_btnComplete;
	ImageView m_btnTopClose;
	ArrayList<Integer> m_arrUserNo;
	// 진입시 방장
	int m_nOwnerNo;
	private ListView m_lvUserList = null;
	// 전달 해 줄 방장
	int m_nSendOwnerNo = 0;
	String m_strSendOwnerName ="";

	// 채팅 리스트에서 넘어 왔을시 방 ID
	String m_strRoomID;
	UserListData m_UserListData;

	CommonPopup m_Popup;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_chatroom_menu_owner);
		m_arrUserListDatas = new ArrayList<UserListData>();

		Bundle bundle = getIntent().getExtras();

		if (bundle != null) {
			m_arrUserNo = bundle.getIntegerArrayList(IntentKeyString.INTENT_KEY_ARR_USERNO);
			m_nOwnerNo = bundle.getInt(IntentKeyString.INTENT_KEY_OWNERNO);
			m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID);
		}


		for(int nUserNo : m_arrUserNo){
			m_UserListData = ContactsDBManager.getContacts(this, nUserNo);
			m_arrUserListDatas.add(m_UserListData);
		}
		Collections.sort(m_arrUserListDatas,myComparator);
		for(int i = 0; i < m_arrUserListDatas.size(); i++){
			if(m_arrUserListDatas.get(i).m_nUserNo == App.m_MyUserInfo.m_nUserNo){
				UserListData tempData = m_arrUserListDatas.get(i);
				m_arrUserListDatas.remove(m_arrUserListDatas.get(i));
				m_arrUserListDatas.add(0, tempData);
			}
		}
		for(int i = 0; i < m_arrUserListDatas.size(); i++){
			if(m_arrUserListDatas.get(i).m_nUserNo == m_nOwnerNo && m_arrUserListDatas.get(i).m_nUserNo != App.m_MyUserInfo.m_nUserNo){
				UserListData tempData = m_arrUserListDatas.get(i);
				m_arrUserListDatas.remove(m_arrUserListDatas.get(i));
				m_arrUserListDatas.add(1, tempData);
			}
		}

		initUI();

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			m_nSendOwnerNo = 0;
			Intent intent = new Intent();

			setResult(RESULT_CANCELED, intent);
			finish();
		}
		return super.onKeyDown(keyCode, event);

	}

	
	public void initUI() {

		m_lvUserList = (ListView) findViewById(R.id.lv_chat_member_list);
		m_btnTopClose = (ImageView) findViewById(R.id.btn_top_close);
		m_btnComplete = (ImageView) findViewById(R.id.btn_complete);
		RelativeLayout layout_nolisttext;
		layout_nolisttext = (RelativeLayout) findViewById(R.id.layout_hinttext);
		if (m_arrUserListDatas != null) {
			layout_nolisttext.setVisibility(View.GONE);
			m_UserListAdapter = new UserListAdapter();
			m_lvUserList.setAdapter(m_UserListAdapter);
		}
		m_btnTopClose.setOnClickListener(this);
		m_btnComplete.setImageResource(R.drawable.btn_top_ok_disabled);
		//m_btnComplete.setOnClickListener(this);
	}

	public void reDrawUI() {
		m_UserListAdapter.notifyDataSetChanged();
	}

	public void setOwner(int a_nOwner) {
		m_nSendOwnerNo = a_nOwner;
	}

	public void setOwnerName(String a_nOwnerName){
		m_btnComplete.setImageResource(R.drawable.btn_btn_top_ok);
		m_btnComplete.setOnClickListener(this);
		m_strSendOwnerName = a_nOwnerName;
	}

	public int getOwner() {
		return m_nSendOwnerNo;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		super.onClick(v);
		switch (v.getId()) {
			case R.id.btn_top_close:
				finish();
				break;
		case R.id.btn_complete:

			if (m_nSendOwnerNo != 0) {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_title), String.format(getString(R.string.popup_exit_room_text_owner_check),m_strSendOwnerName));
				m_Popup.setCancelable(false);
				isCheckShowPopup();

			} else {
				m_Popup = new CommonPopup(this, this, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
				m_Popup.setBodyAndTitleText(getString(R.string.popup_title), getString(R.string.popup_exit_room_no_select));
				m_Popup.setCancelable(false);
				isCheckShowPopup();
			}
			break;
		case R.id.ib_pop_ok_long:
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			popup_ok_long.cancel();
			break;
		case R.id.ib_pop_ok:

			CommonPopup popup_ok = (CommonPopup)v.getTag();
			popup_ok.cancel();

			m_Popup = new CommonPopup(this, new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					CommonPopup popup_ok_long = (CommonPopup)v.getTag();
					popup_ok_long.cancel();
					Intent intentFinish = new Intent();
					intentFinish.putExtra(IntentKeyString.INTENT_KEY_PASS_OWNER, m_nSendOwnerNo);
					if (m_strRoomID != null) {
						intentFinish.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_strRoomID);
					}
					setResult(RESULT_OK, intentFinish);
					m_nSendOwnerNo = 0;
					finish();
				}
			}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
			m_Popup.setBodyAndTitleText(getString(R.string.pop_error_title), getString(R.string.cork_pop_owner_complete));
			m_Popup.setCancelable(false);
			isCheckShowPopup();
			break;
		case R.id.ib_pop_cancel:		
			CommonPopup popup_cancel = (CommonPopup)v.getTag();
			popup_cancel.cancel();
			break;
		default:
			break;
		}
	}

	private class UserListAdapter extends BaseAdapter {

		@Override
		public void notifyDataSetChanged() {
			// TODO Auto-generated method stub

			super.notifyDataSetChanged();
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			int nUserListDataSize = 0;

			if (m_arrUserListDatas != null)
				nUserListDataSize = m_arrUserListDatas.size();

			return nUserListDataSize;
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			if (m_arrUserListDatas != null && position < m_arrUserListDatas.size())
				return m_arrUserListDatas.get(position);
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;

			UserListData userData;

			if (nPosition < m_arrUserListDatas.size()) {
				userData = (UserListData) m_arrUserListDatas.get(nPosition);
				// convertView null 시 새로 생성하자
				if (convertView == null)
					convertView = new ChatRoomUserListItemLayout(ChatRoomOwnerAct.this, ChatRoomUserListItemLayout.CHATROOM_ITEM_TYPE_OWNER);
				((ChatRoomUserListItemLayout) convertView).setOwner(m_nOwnerNo);
				((ChatRoomUserListItemLayout) convertView).setUserListData(userData);
			}

			return convertView;
		}
	}

	private final static Comparator<UserListData> myComparator = new Comparator<UserListData>() {
		private final Collator collator = Collator.getInstance(new Locale("ko"));

		@Override
		public int compare(UserListData lhs, UserListData rhs) {
			// TODO Auto-generated method stub
			boolean isLeftNumber = true;
			boolean isRightNumber = true;

			char leftChar = lhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME).charAt(0);
			char rightChar = rhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME).charAt(0);

			if(leftChar < '0' || leftChar > '9'){
				isLeftNumber = false;
			}
			if(rightChar < '0' || rightChar > '9'){
				isRightNumber = false;
			}

			if(isLeftNumber && !isRightNumber){
				return 1;
			} else if(!isLeftNumber && isRightNumber){
				return -1;
			} else
				return collator.compare(lhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME), rhs.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
		}

	};

	private void isCheckShowPopup(){
		if(super.m_isRunning){
			m_Popup.show();
		} 
	}
	
}
