package com.gmp.rusk.network;

public class ApiResult {

    public static final String RESULT_OK					= "200";
    public static final String RESULT_DISCONNECT			= "-999";

    public static final int RESULT_SUCCESS	= 200;
    public static final int RESULT_FAIL	= 999;

    public static final int ERR_NONE = 200;

    public static final int ERR_ETC = 999999;
    public static final int ERR_HTTP_NETWORK_ERROR = 500;


    public static final int HTTP_STATUS_OK = 200;

    public static final int HTTP_USER_DEFINE = 100000;
    public static final int HTTP_ERR_DISCONNECTED = HTTP_USER_DEFINE;
    public static final int HTTP_ERR_TIME_OUT = HTTP_USER_DEFINE+10;
    public static final int HTTP_ERR_SOCKET_ERROR = HTTP_USER_DEFINE+15;
    public static final int HTTP_ERR_ENCODING_EXCEPTION = HTTP_USER_DEFINE + 20;
    public static final int HTTP_ERR_JSON_EXCEPTION = HTTP_USER_DEFINE + 30;
    public static final int HTTP_ERR_PROTOCOL_EXCEPTION = HTTP_USER_DEFINE + 40;
    public static final int HTTP_ERR_IO_EXCEPTION = HTTP_USER_DEFINE + 50;
    public static final int LOCAL_ERR_JSON_EXCEPTION = HTTP_USER_DEFINE + 60;
    public static final int LOCAL_ERR_RESULT = HTTP_USER_DEFINE + 70;
    public static final int HTTP_ERR_UNKNOWN_EXCEPTION = HTTP_USER_DEFINE + 10000;



    //Server 정의 Code
    public static final int HTTP_SERVER_NOT_JOIN = 202;								// 파트너 가입 승인되지 않음, 정직원 가입신청 필요함
    public static final int HTTP_SERVER_NOT_EMAIL_CERTIFICATION = 203;				// 파트너 이메일 인증 하지 않음
    public static final int HTTP_SERVER_NOT_DEFINED = 400;
    public static final int HTTP_SERVER_UNAUTHORIZED = 401;							// 인증이 필요하거나 일치하는 사용자 정보가 없음
    public static final int HTTP_SERVER_REQUEST_FAIL = 403;							// 요청이 거부되었음, 권한이 불충분하거나 잘못 된 요청
    public static final int HTTP_SERVER_NOT_FOUND = 404;							// 찾을수 없음, PCClient AuthToken API 에선 유효한 인증키 없는 경우
    public static final int HTTP_SERVER_PATNER_QUIT_SNS_ERROR = 406;				// 파트너 탈퇴시, 방장인 모임이 남아 있을 경우
    public static final int HTTP_SERVER_CHANGE_DEVICE = 412;						// 파트너 유저의 경우, 단말 ID값이 변경되었을 경우의 에러
    public static final int HTTP_SERVER_BACKUP_FAIL = 417;						// 파트너 유저의 경우, 단말 ID값이 변경되었을 경우의 에러
    public static final int HTTP_SERVER_PARTNER_SESSION_EXPIRATION = 419;			// 파트너 only 세션 만료
    public static final int HTTP_SERVER_ERROR = 500;								// 서버에러
    public static final int HTTP_SERVER_CLOSE = 503;								// 서버점검
    public static final int HTTP_SERVER_TIMEOUT = 504;								// Time Out
    public static final int HTTP_SERVER_CHANNEL_OUT = 510;                          //채널에서 강퇴 되었을 경우

    //Restful 오류 정의
    public static final int HTTP_SERVER_RESTFUL_ERROR_NOT_FOUND	= 404;
    public static final int HTTP_SERVER_RESTFUL_ERROR_NOT_INVITED_SNSGROUP	= 409;

    // 결과는 항상 이걸로 체크
    public int error_code = ERR_NONE;
    public int error_detail = 200;
}