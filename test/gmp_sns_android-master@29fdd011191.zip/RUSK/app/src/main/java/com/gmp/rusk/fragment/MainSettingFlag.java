package com.gmp.rusk.fragment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.AgreementAgreeAct;
import com.gmp.rusk.act.ApprovalTabAct;
import com.gmp.rusk.act.MainTabAct;
import com.gmp.rusk.act.PCClientManagerAct;
import com.gmp.rusk.act.RecommendCorkAct;
import com.gmp.rusk.act.SetAccountManagementAct;
import com.gmp.rusk.act.SetAlarmAct;
import com.gmp.rusk.act.SetDeviceChangeAct;
import com.gmp.rusk.act.SetLicenseInfo;
import com.gmp.rusk.act.SetProfileAct;
import com.gmp.rusk.act.SetSaveChatMessageTermAct;
import com.gmp.rusk.act.SetTermsAct;
import com.gmp.rusk.act.SetTextSizeAct;
import com.gmp.rusk.act.TutorialAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;


/**
 * MainSettingFlag
 * @author subi78
 * MainTabAct - 설정 Fragment
 */
public class MainSettingFlag extends Fragment implements OnClickListener{
	public MyApp App = MyApp.getInstance();
	private View m_vSetting = null;	
	
	private FragmentActivity m_Activity = null;
	
	TextView tv_set_alram_status ,tv_set_textsize;
	TextView tv_set_versioninfo_status;
	TextView tv_set_push_status;
	
	SharedPref pref;
	
	private CommonPopup m_Popup = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        m_Activity = getActivity();
    }
    
    /**
     * The Fragment's UI is just a simple text view showing its
     * instance number.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    	
    	m_vSetting = inflater.inflate(R.layout.fragact_setting, container, false);
    	
    	((MainTabAct)m_Activity).setTitle(getString(R.string.settingtab_title));
		((MainTabAct)getActivity()).setTopButton(MainTabAct.TAB_BTN_SETTTING);

		/*((MainTabAct) m_Activity).setRightTopButton(false, ((MainTabAct) m_Activity).TAB_RIGHTBTN_SETTTING);
		((MainTabAct) m_Activity).setRightFloatButton(false, ((MainTabAct) m_Activity).TAB_RIGHTBTN_SETTTING);
		((MainTabAct) m_Activity).setLeftTopButton(false, ((MainTabAct) m_Activity).TAB_LEFTBTN_SETTTING);*/
    	
    	pref = SharedPref.getInstance(m_Activity);
//    	requestGetPartnerApprovalList();
        return m_vSetting;
    }
    
    @Override
    public void onResume() {
    	// TODO Auto-generated method stub
    	super.onResume();
    	initSettingUI();
    }
    
	@Override
	public void onClick(View v) {
		Intent intent = null;
		
		// TODO Auto-generated method stub
		if(v.getId() == R.id.layout_set_profile)
		{
			intent = new Intent(m_Activity, SetProfileAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_partner_management)
		{		
			intent = new Intent(m_Activity, ApprovalTabAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_account_management)
		{
			intent = new Intent(m_Activity, SetAccountManagementAct.class);
			startActivity(intent);
		}
//		else if(v.getId() == R.id.layout_set_push)
//		{
//			intent = new Intent(m_Activity, SetPushAct.class);
//			startActivity(intent);
//		}
		else if(v.getId() == R.id.layout_set_alram)
		{
			intent = new Intent(m_Activity, SetAlarmAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_savechatmessageterm)
		{
			intent = new Intent(m_Activity, SetSaveChatMessageTermAct.class);
			startActivity(intent);
		} else if(v.getId() == R.id.layout_set_recommend_cork) {
			intent = new Intent(m_Activity, RecommendCorkAct.class);
			startActivity(intent);
		}
		else if (v.getId() == R.id.layout_set_service_condition)
		{
			//서비스 이용 약관 페이지
			intent = new Intent(m_Activity, SetTermsAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_partnerlogout)
		{
			showPartnerLogoutPopup();
		}
		else if(v.getId() == R.id.layout_set_pcclientmanager)
		{
			intent = new Intent(m_Activity, PCClientManagerAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_tutorial)
		{
			intent = new Intent(m_Activity, TutorialAct.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_versioninfo)
		{

		}
		else if(v.getId() == R.id.layout_set_licenseinfo)
		{
			intent = new Intent(m_Activity, SetLicenseInfo.class);
			startActivity(intent);
		}
		else if(v.getId() == R.id.layout_set_devicechange)
		{
			intent = new Intent(m_Activity, SetDeviceChangeAct.class);
			startActivity(intent);
		} else if(v.getId() == R.id.layout_set_sendmail)
		{
			intent = new Intent(Intent.ACTION_VIEW);
			intent.setData(Uri.parse("toktok://com.skt.pe.activity.mobileclient.qna"));
			if (intent.resolveActivity(getContext().getPackageManager()) != null) {
				startActivity(intent);
			} else {
				intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.toktok.sk.com")).addCategory(Intent.CATEGORY_BROWSABLE);
				startActivity(intent);
			}

		} else if(v.getId() == R.id.layout_set_textsize){
			intent = new Intent(m_Activity, SetTextSizeAct.class);
			startActivity(intent);
		}
	}
	
    private void initSettingUI()
    {
    	LinearLayout layout_set_profile = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_profile);
    	LinearLayout layout_set_partner_management = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_partner_management);
    	LinearLayout layout_set_account_management = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_account_management);
    	LinearLayout layoutSetSaveChatMessageTerm = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_savechatmessageterm);
		LinearLayout layoutServiceCondition = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_service_condition);
    	LinearLayout layoutPartnerLogout = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_partnerlogout);

    	LinearLayout layoutPCClientManager = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_pcclientmanager);
    	LinearLayout layoutTutorial = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_tutorial);
    	LinearLayout layoutDeviceChange = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_devicechange);
		LinearLayout layoutLicenseInfo = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_licenseinfo);
    	
//    	LinearLayout layout_set_push = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_push);
    	LinearLayout layout_set_alram = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_alram);

		LinearLayout layoutSendMail = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_sendmail);

		LinearLayout layoutTextSize = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_textsize);
		LinearLayout layoutRecommend = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_recommend_cork);
/*
    	LinearLayout layoutMigration = (LinearLayout)m_vSetting.findViewById(R.id.layout_set_migration);
*/

    	tv_set_alram_status = (TextView)m_vSetting.findViewById(R.id.tv_set_alram_status);
		tv_set_textsize = (TextView)m_vSetting.findViewById(R.id.tv_set_textsize);

    	tv_set_versioninfo_status = (TextView)m_vSetting.findViewById(R.id.tv_set_versioninfo_status);
    	//push 알람 통합 으로 push쪽 삭제
//    	tv_set_push_status = (TextView)m_vSetting.findViewById(R.id.tv_set_push_status);
//    	
//    	if(pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM,true))
//    		tv_set_push_status.setText("ON");
//    	else
//    		tv_set_push_status.setText("OFF");
//    	
//    	if(pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND,true) || pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE,true))
//    	  	tv_set_alram_status.setText("ON");
//    	else
//    		tv_set_alram_status.setText("OFF");
    	
    	if(pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM,true))
    	  	tv_set_alram_status.setText(R.string.set_alarm_on);
    	else
    		tv_set_alram_status.setText(R.string.set_alarm_off);

		if(StaticString.SETTEXTSIZE_SMALL == pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL)){
			 tv_set_textsize.setText(R.string.set_textsize_small);
		} else if(StaticString.SETTEXTSIZE_NORMAL == pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL)){
			tv_set_textsize.setText(R.string.set_textsize_normal);
		} else if(StaticString.SETTEXTSIZE_BIG == pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL)){
			tv_set_textsize.setText(R.string.set_textsize_big);
		}

    	tv_set_versioninfo_status.setText(Utils.getApplicationVersion(m_Activity) + " T");
    	
    	if(AppSetting.FEATURE_VARIANT.equals("R"))
    	{
    		layout_set_partner_management.setVisibility(View.VISIBLE);
			layoutServiceCondition.setVisibility(View.GONE);
    		layout_set_account_management.setVisibility(View.GONE);
			layoutServiceCondition.setVisibility(View.GONE);
    		layoutPartnerLogout.setVisibility(View.GONE);
			layoutRecommend.setVisibility(View.VISIBLE);
			layoutSendMail.setVisibility(View.VISIBLE);
    		
    		
    		TextView tv_set_partner_management_new = (TextView)m_vSetting.findViewById(R.id.tv_set_partner_management_new);
    		if(pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT,0) > 0)
    		{
    			tv_set_partner_management_new.setVisibility(View.VISIBLE);
    			tv_set_partner_management_new.setText(""+pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT,0));
    		}else
    			tv_set_partner_management_new.setVisibility(View.INVISIBLE);
    	}
    	else
    	{
    		layout_set_partner_management.setVisibility(View.GONE);
			layoutServiceCondition.setVisibility(View.VISIBLE);
			layout_set_account_management.setVisibility(View.VISIBLE);
			layoutPartnerLogout.setVisibility(View.VISIBLE);
			layoutRecommend.setVisibility(View.GONE);
			layoutPCClientManager.setVisibility(View.VISIBLE);
			layoutSendMail.setVisibility(View.GONE);

    	}
    	
    	layout_set_profile.setOnClickListener(this);
    	layout_set_partner_management.setOnClickListener(this);
    	layout_set_account_management.setOnClickListener(this);
//    	layout_set_push.setOnClickListener(this);
    	layout_set_alram.setOnClickListener(this);
    	layoutSetSaveChatMessageTerm.setOnClickListener(this);
    	layoutPCClientManager.setOnClickListener(this);
    	layoutPartnerLogout.setOnClickListener(this);
		layoutServiceCondition.setOnClickListener(this);
		layoutPCClientManager.setOnClickListener(this);
		layoutDeviceChange.setOnClickListener(this);
		layoutLicenseInfo.setOnClickListener(this);
		layoutSendMail.setOnClickListener(this);
		layoutTextSize.setOnClickListener(this);
		layoutRecommend.setOnClickListener(this);
		layoutTutorial.setOnClickListener(this);
		/*layoutMigration.setOnClickListener(this);*/
    }
    
    private void showPartnerLogoutPopup()
    {
    	m_Popup = new CommonPopup(getActivity(), new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					App.expirePartnerLogin(getActivity());
				}
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.set_partnerlogout_popup_title), getString(R.string.set_partnerlogout_popup_msg));
		m_Popup.setCancelable(false);
		m_Popup.show();
    }

	private void showSendMailPopup()
	{
		m_Popup = new CommonPopup(getActivity(), new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					Intent intent = new Intent(Intent.ACTION_SEND);
					intent.setType("message/rfc822");
					intent.putExtra(Intent.EXTRA_EMAIL  , new String[]{"talk_help@uangel.com"});
					intent.putExtra(Intent.EXTRA_TEXT  , getString(R.string.set_sendmail_message_detail));
					startActivity(intent);
				}
				CommonPopup popup = (CommonPopup)v.getTag();
				popup.cancel();
				popup.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.set_sendmail), getString(R.string.set_sendmail_message));
		m_Popup.setCancelable(false);
		m_Popup.show();
	}
}