package com.gmp.rusk.layout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.act.SNSGroupMemeberInviteAct;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.SearchListCheckData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.datamodel.UserSearchListData;
import com.gmp.rusk.datamodel.UserSearchListDataValue;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.ApiResult;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.PopupIndex;
import com.gmp.rusk.utils.StaticString;

/**
 * AddedByFellowListItemLayout 추천 동료 List Item Layout
 */
public class SNSInviteAllUserListItemLayout extends CustomLinearLayout implements OnClickListener, OnCheckedChangeListener {
	Context m_Context;

	private UserSearchListData m_UserSearchListData = null;
	private RegularSearchListData m_RegularSearchListData = null;
	private PartnerSearchListData m_PartnerSearchListData = null;
	private UserSearchListDataValue m_UserSearchListDataValue = null;

	private CommonPopup m_Popup = null;

	private ProgressDlg m_Progress = null;
	CheckBox cb_invite;
	private OnCheckedChangedListener m_CheckedChangeListener = null;

	public SNSInviteAllUserListItemLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		init(context);
	}

	public SNSInviteAllUserListItemLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
	}

	private void init(Context a_context) {
		this.m_Context = a_context;
		LayoutInflater layoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		layoutInflater.inflate(R.layout.layout_listitem_chat, this);

	}

	public void setUserSearchListData(UserSearchListData a_Data) {
		m_UserSearchListData = a_Data;
		if (m_UserSearchListData.m_isRegular) {
			m_RegularSearchListData = (RegularSearchListData) m_UserSearchListData.m_UserData;
			m_PartnerSearchListData = null;
		} else {
			m_PartnerSearchListData = (PartnerSearchListData) m_UserSearchListData.m_UserData;
			m_RegularSearchListData = null;
		}
		if (m_RegularSearchListData != null) {
			m_UserSearchListDataValue = new UserSearchListDataValue(m_RegularSearchListData.m_nUserNo, m_RegularSearchListData.m_strName,
					m_RegularSearchListData.m_strCharge, m_RegularSearchListData.m_strCompanyName, m_RegularSearchListData.m_strSecondCharge, m_RegularSearchListData.m_strPosition,m_RegularSearchListData.m_strDepartment,null,
					m_RegularSearchListData.m_isImageAvailable, m_RegularSearchListData.m_isAvailable, StaticString.VARIANT_REGULAR);
		} else {
			m_UserSearchListDataValue = new UserSearchListDataValue(m_PartnerSearchListData.m_nUserNo, m_PartnerSearchListData.m_strName, m_PartnerSearchListData.m_strCharge, null, null,m_PartnerSearchListData.m_strPosition,null,
					m_PartnerSearchListData.m_strAffliaction, m_PartnerSearchListData.m_isImageAvailable, m_PartnerSearchListData.m_isAvailable, m_PartnerSearchListData.m_strType);
		}
		setUiData();
	}

	// UI 세팅
	private void setUiData() {
		ImageView iv_profile_pic = (ImageView) findViewById(R.id.iv_profile_pic);
		iv_profile_pic.setOnClickListener(this);
		ImageView iv_notfellow_pic = (ImageView)findViewById(R.id.iv_profile_notfellow_pic);

		if (m_UserSearchListDataValue.m_isImageAvailable) 
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			App.imageloader.getProfileImage(iv_profile_pic, App.getImageDownLoaderUrl(m_UserSearchListDataValue.m_nUserNo, true), R.drawable.profile_pic_default, false);
		} 
		else
		{
			App.imageloader.cancelDownload(iv_profile_pic);
			iv_profile_pic.setImageResource(R.drawable.profile_pic_default);
		}

		ImageView ivIconPartner = (ImageView) findViewById(R.id.iv_chatlist_icon_partner);
		if(m_UserSearchListDataValue.m_strUserType.equals(StaticString.VARIANT_REGULAR)){
			ivIconPartner.setVisibility(GONE);
		} else {
			ivIconPartner.setVisibility(VISIBLE);
		}

		TextView tv_name = (TextView) findViewById(R.id.tv_name);
		LinearLayout layout_position = (LinearLayout) findViewById(R.id.layout_position);
		TextView tv_position = (TextView) findViewById(R.id.tv_position);
		LinearLayout layout_charge = (LinearLayout) findViewById(R.id.layout_charge);
		TextView tv_charge = (TextView) findViewById(R.id.tv_charge);
		TextView tv_uninstall = (TextView) findViewById(R.id.tv_uninstall);
		tv_name.setText(m_UserSearchListDataValue.m_strName);
		if(m_UserSearchListDataValue.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_UserSearchListDataValue.m_strPosition !=null && !m_UserSearchListDataValue.m_strPosition.equals("")){
			layout_position.setVisibility(VISIBLE);
			tv_position.setText(m_UserSearchListDataValue.m_strPosition);
		} else {
			layout_position.setVisibility(GONE);
		}

		if(m_UserSearchListDataValue.m_strUserType.equals(StaticString.VARIANT_REGULAR) && m_UserSearchListDataValue.m_strCharge!=null && !m_UserSearchListDataValue.m_strCharge.equals("")){
			layout_charge.setVisibility(VISIBLE);
			tv_charge.setText(m_UserSearchListDataValue.m_strCharge);
		} else {
			layout_charge.setVisibility(GONE);
		}

		if (m_UserSearchListDataValue.m_isAvailable) {
			tv_uninstall.setVisibility(GONE);
		} else {
			tv_uninstall.setVisibility(VISIBLE);
		}

		TextView tv_departments = (TextView) findViewById(R.id.tv_departments);


		if (m_UserSearchListDataValue.m_strUserType.equals(StaticString.VARIANT_REGULAR)) {
			tv_departments.setText(m_UserSearchListDataValue.m_strDepartment+" | "+m_UserSearchListDataValue.m_strCompany);
		} else {
			tv_departments.setText(m_UserSearchListDataValue.m_strAffiliation);
		}

		UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(m_Context, m_UserSearchListDataValue.m_nUserNo);

		iv_notfellow_pic.setVisibility(View.GONE);
		cb_invite = (CheckBox) findViewById(R.id.cb_invite);
		cb_invite.setOnCheckedChangeListener(this);
		if(userData == null || !userData.m_isActive){
			cb_invite.setVisibility(View.INVISIBLE);
		} else if(userData != null && userData.m_isActive){
			cb_invite.setVisibility(View.VISIBLE);
		}
		RelativeLayout layout_listitem_search = (RelativeLayout) findViewById(R.id.layout_listitem);
		layout_listitem_search.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.layout_listitem) {
			//doShowProfile();
			if(cb_invite.getVisibility() == View.VISIBLE && cb_invite.isChecked())
				cb_invite.setChecked(false);
			else if(cb_invite.getVisibility() == View.VISIBLE && !cb_invite.isChecked())
				cb_invite.setChecked(true);
		} else if(v.getId() == R.id.iv_profile_pic) {
			doShowProfile();
		} else if (v.getId() == R.id.ib_pop_ok_long) {
			CommonPopup popup_ok_long = (CommonPopup)v.getTag();
			if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_SESSION_EXPIRE || popup_ok_long.m_nPrevAction == ApiResult.HTTP_SERVER_UNAUTHORIZED) {
				popup_ok_long.cancel();
				App.expirePartnerLogin(m_Context);
			} else if (popup_ok_long.m_nPrevAction == PopupIndex.INDEX_PREVPOP_CHANGE_DEVICE) {
				popup_ok_long.cancel();
				App.initPartnerLogin(m_Context);
			} else {
				popup_ok_long.cancel();
			}
		}
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		if (buttonView.getId() == R.id.cb_invite) {
			if (isChecked) {
					SearchListCheckData addData = new SearchListCheckData(m_UserSearchListDataValue.m_nUserNo, m_UserSearchListDataValue.m_strName);
					//addData.m_isChecked = true;
					((SNSGroupMemeberInviteAct) m_Context).addSearchList(addData);
					m_CheckedChangeListener.onChecked(true, m_UserSearchListDataValue.m_nUserNo);

			} else {
				((SNSGroupMemeberInviteAct) m_Context).removeListData(m_UserSearchListDataValue.m_nUserNo);
				m_CheckedChangeListener.onChecked(false, m_UserSearchListDataValue.m_nUserNo);
			}
		}
	}

	public void setCheckedChangedListener(OnCheckedChangedListener a_Listener) {
		m_CheckedChangeListener = a_Listener;
	}

	public interface OnCheckedChangedListener {
		public void onChecked(boolean a_isChecked, int a_nUserId);
		public void onDataSetChagnged();
	}
	
	private void doShowProfile() {
		Intent intent = new Intent(m_Context, ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, m_UserSearchListDataValue.m_nUserNo);
		m_Context.startActivity(intent);
	}

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(m_Context, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
