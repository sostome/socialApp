package com.gmp.rusk.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;

import org.jivesoftware.smack.packet.Packet;

import android.content.Context;

import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.ChattingDBManagerForDelayMessage;

import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

public class XmppFilterOffline {

	private Context m_Context;
	private LinkedList<Packet> m_QueuePacket;
	private final String SERVICE_NAME = "cork.com";
	// 그룹채팅방에 DB에 없는 사용자가 있을시 처리를 위함
	ArrayList<UserListData> m_arrDBSetUser = new ArrayList<UserListData>();
	SharedPref pref;
	long lEditTime;
	
	com.gmp.rusk.db.RoomDBManager m_DelayRoomDB;
	com.gmp.rusk.db.ContactsDBManager m_ContactsDBManager;
	ChattingDBManagerForDelayMessage m_DelayMessageDB;
	
	XmppFilterOfflineSingle m_XmppFilterOfflineSingle;
	XmppFilterOfflineGroup m_XmppFilterOfflineGroup;
	XmppFilterPCSystemOffline m_XmppFilterPCSystemOffline;
	
	public XmppFilterOffline(Context context, final String a_strUserName , ChattingDBManagerForDelayMessage a_DelayMessageDB, com.gmp.rusk.db.RoomDBManager a_DelayRoomDB, com.gmp.rusk.db.ContactsDBManager a_ContactsDBManager) {
		m_Context = context;
		m_QueuePacket = new LinkedList<Packet>();
		
		m_DelayMessageDB = a_DelayMessageDB;
		m_DelayRoomDB = a_DelayRoomDB;
		m_ContactsDBManager = a_ContactsDBManager;
		
		
		pref = SharedPref.getInstance(m_Context);
		int nSaveChatMsgTerm = pref.getIntegerPref(SharedPref.PREF_SAVECHATMESSAGETERM, StaticString.CHATMESSAGETERM_3WEEKBEFORE);
		int nBeforeDay = 21;
		
		if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3WEEKBEFORE)
			nBeforeDay = 21;
		else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_2WEEKBEFORE)
			nBeforeDay = 14;
		else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_1WEEKBEFORE)
			nBeforeDay = 7;
		else if(nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3DAYBEFORE)
			nBeforeDay = 3;
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) - nBeforeDay);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		
		lEditTime = calendar.getTimeInMillis();
		
		m_XmppFilterOfflineSingle = new XmppFilterOfflineSingle(context, lEditTime, a_strUserName, a_DelayMessageDB, a_DelayRoomDB, a_ContactsDBManager);
		m_XmppFilterOfflineGroup = new XmppFilterOfflineGroup(context, lEditTime, a_DelayMessageDB, a_DelayRoomDB, a_ContactsDBManager);
		m_XmppFilterPCSystemOffline = new XmppFilterPCSystemOffline(context, lEditTime, a_DelayMessageDB, a_DelayRoomDB, a_ContactsDBManager);
	}

	public LinkedList<Packet> getQueue() {
		m_QueuePacket.addAll(m_XmppFilterPCSystemOffline.getQueue());
		m_XmppFilterPCSystemOffline.clearQueue();
		m_QueuePacket.addAll(m_XmppFilterOfflineSingle.getQueue());
		m_XmppFilterOfflineSingle.clearQueue();
		m_QueuePacket.addAll(m_XmppFilterOfflineGroup.getQueue());
		m_XmppFilterOfflineGroup.clearQueue();
		return m_QueuePacket;

	}

	public void clearQueue() {
		m_QueuePacket.clear();
	}

	public void setFilter(Packet message){
		m_XmppFilterPCSystemOffline.setFilter(message);
		m_XmppFilterOfflineSingle.setFilterSingle(message);
		m_XmppFilterOfflineGroup.setFilterGroup(message);	
	}

}
