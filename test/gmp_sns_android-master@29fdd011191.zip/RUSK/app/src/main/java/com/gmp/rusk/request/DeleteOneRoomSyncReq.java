package com.gmp.rusk.request;

import java.util.ArrayList;



/**
 *	@author kch
 *			룸 싱크 삭제
 *			method : delete
 */

public class DeleteOneRoomSyncReq extends Req{
	
	private String APINAME = "user";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "DELETE";
	
	
	public DeleteOneRoomSyncReq(ArrayList<String> a_nMessageIds)
	{
		int nMessageIdSize = a_nMessageIds.size();
		

		StringBuffer strMessageIds = new StringBuffer();
		for(int i = 0; i < nMessageIdSize; i++)
		{
			strMessageIds.append(a_nMessageIds.get(i)+",");
		}
		
		APINAME = APINAME + "/" + App.m_EntryData.m_nUserNo + "/sync/" + strMessageIds.substring(0, strMessageIds.length()-1); 
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
