package com.gmp.rusk.datamodel;

public class SearchListCheckData {
	public int m_nUserNo = 0;					//사용자 번호
	public String m_strName = "";				//사용자 이름
	
	public SearchListCheckData(int a_nUserNo, String a_strName) {
		m_nUserNo = a_nUserNo;
		m_strName = a_strName;
		
	}
}
