package com.gmp.rusk.imageloader;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class FileCacheDBAdapter {
	
	// Database File Name
	private static final String DATABASE_NAME 				= "file_cache.db";
	
	private final int DATABASE_VERSION = 1;
	
	// Room Table Name
	private static final String TABLE_FILECACHE 			= "FileCache";
	
	// Room Table Field Name
	public static final String KEY_IDX							= "idx";				// IDX
	public static final String KEY_FILECACHE_URL				= "url";				// Url
	public static final String KEY_FILECACHE_LOCALFILENAME		= "localfilename";		// Local File Name
	
	// Create Table Query
	private final String FILECACHE_CREATE = "create table " + TABLE_FILECACHE 		+ " (" + 
												KEY_IDX 							+ " integer primary key autoincrement, " +
												KEY_FILECACHE_URL 					+ " text not null, " +
												KEY_FILECACHE_LOCALFILENAME 		+ " text not null);";
	
	// Drop Table Query 
	private final String FILECACHE_DROP = "DROP TABLE IF EXISTS " + TABLE_FILECACHE;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private FileCacheDBHelper m_dbHelper = null;
	
	public FileCacheDBAdapter(Context context)
	{
		m_context = context;
		m_dbHelper = new FileCacheDBHelper(m_context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	// Database Open Read & Write Permission
	public FileCacheDBAdapter open() throws SQLException
	{
		m_db = m_dbHelper.getWritableDatabase();
		return this;
	}
	
	// Database Open Read Permission
	public FileCacheDBAdapter openReadOnly() throws SQLException
	{
		m_db = m_dbHelper.getReadableDatabase();
		return this;
	}
	
	// Database Close
	public void close()
	{
		m_db.close();
	}
	
	public int insertFileCache(String a_strUrl, String a_strFileName)
	{
		int nCount = 0;
		
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_FILECACHE_URL, a_strUrl);
			value.put(KEY_FILECACHE_LOCALFILENAME, a_strFileName);
			m_db.insert(TABLE_FILECACHE, null, value);
			nCount++;
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	public int deleteFileCache()
	{
		return m_db.delete(TABLE_FILECACHE, null, null);
	}
	
	public int deleteFileCache(String a_strFileName)
	{
		return m_db.delete(TABLE_FILECACHE, KEY_FILECACHE_LOCALFILENAME + "=\"" + a_strFileName + "\"", null);
	}
	
	public String getFileCache(String a_strUrl)
	{
		Cursor cursor = m_db.query(TABLE_FILECACHE, null, KEY_FILECACHE_URL + "=\"" + a_strUrl + "\"", null, null, null, null);
		String strResult = "";
		
		if(cursor.moveToFirst())
		{
			strResult = cursor.getString(cursor.getColumnIndex(KEY_FILECACHE_LOCALFILENAME));
		}
		
		cursor.close();
		
		return strResult;
	}
	
	// SQLite Open Helper Class
	private class FileCacheDBHelper extends SQLiteOpenHelper
	{

		public FileCacheDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(FILECACHE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			db.execSQL(FILECACHE_DROP);
			onCreate(db);
		}
	}
}
