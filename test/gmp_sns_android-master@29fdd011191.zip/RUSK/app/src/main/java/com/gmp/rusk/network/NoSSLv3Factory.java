package com.gmp.rusk.network;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import android.content.Context;

public class NoSSLv3Factory extends SSLSocketFactory {
	private final SSLSocketFactory delegate;
	public static NoSSLv3Factory m_Instance = null;
	
	public static final NoSSLv3Factory getInstance(){
		if(m_Instance == null){
			m_Instance = new NoSSLv3Factory();
		}	
		return m_Instance;	
	}
	
	public NoSSLv3Factory() {
		this.delegate = HttpsURLConnection.getDefaultSSLSocketFactory();
	}

	@Override
	public String[] getDefaultCipherSuites() {
		return delegate.getDefaultCipherSuites();
	}

	@Override
	public String[] getSupportedCipherSuites() {
		return delegate.getSupportedCipherSuites();
	}

	private static Socket makeSocketSafe(Socket socket) {
		if (socket instanceof SSLSocket) {
			socket = new NoSSLv3SSLSocket((SSLSocket) socket);
		}
		return socket;
	}

	@Override
	public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
		return makeSocketSafe(delegate.createSocket(s, host, port, autoClose));
	}

	@Override
	public Socket createSocket(String host, int port) throws IOException {
		return makeSocketSafe(delegate.createSocket(host, port));
	}

	@Override
	public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
		return makeSocketSafe(delegate.createSocket(host, port, localHost, localPort));
	}

	@Override
	public Socket createSocket(InetAddress host, int port) throws IOException {
		return makeSocketSafe(delegate.createSocket(host, port));
	}

	@Override
	public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
		return makeSocketSafe(delegate.createSocket(address, port, localAddress, localPort));
	}

	static {
		HttpsURLConnection.setDefaultSSLSocketFactory(new NoSSLv3Factory());
	}
}
