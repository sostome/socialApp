package com.gmp.rusk.datamodel;

import java.util.ArrayList;

public class SNSGroupDetailData {
	
	public int m_nGroupId = 0;
	public String m_strGroupName = "";
	public int m_nImageIndex = -1;
	public String m_strImageUrl = "";
	public boolean m_isOwned = false;
	public int m_nUserCount = 0;
	public boolean m_isBoardAlarm = true;
	public boolean m_isReplyAlarm = true;
	
	public ArrayList<SNSBoardData> m_arrBoardData = new ArrayList<SNSBoardData>();
}
