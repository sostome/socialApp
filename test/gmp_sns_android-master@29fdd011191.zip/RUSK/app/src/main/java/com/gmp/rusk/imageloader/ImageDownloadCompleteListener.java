package com.gmp.rusk.imageloader;

import android.graphics.Bitmap;

public interface ImageDownloadCompleteListener {

	public void onComplete(String a_strUrl, Bitmap a_bmpImage);
	public void onFail(String a_strUrl, int a_nErrorCode, String a_strErrorMsg);
	public void onNotModified(String a_strUrl, Bitmap a_bmpImage);
}
