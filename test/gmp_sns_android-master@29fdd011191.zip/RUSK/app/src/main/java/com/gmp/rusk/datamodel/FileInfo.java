package com.gmp.rusk.datamodel;

import java.io.File;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

@SuppressWarnings("serial")
public class FileInfo implements Serializable{
	
	//최상위 페이지를 보여줄때 사용
	public FileInfo(){
		
	}
	public FileInfo(File fd,int type)
	{
		m_intType = type;
		try{
			m_strName = new String(fd.getName().getBytes(), "utf-8");
			m_strPath = new String(fd.getAbsolutePath().getBytes(), "utf-8");
		}catch(UnsupportedEncodingException e)
		{  
		}
		
		m_lnSize = fd.length();
	}
	
	public boolean m_intSelected = false;
	public int m_intSelectIndex = -1;	  //selectlist index
	public int m_intType = 0;
	public String m_strName = "";
	public String m_strPath = "";
	public long m_lnSize = 0L;
}