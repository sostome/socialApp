package com.gmp.rusk.takemedia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;

import com.gmp.rusk.R;
import com.gmp.rusk.act.GalleryMultiselectorListAct;
import com.gmp.rusk.act.GalleryMultiselectorListAct.GalleryAction;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.yalantis.ucrop.UCrop;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;

public class TakeMediaIntent {
	
	public static final int REQUESTCODE_ALBUM = 5000;
	public static final int REQUESTCODE_CAMERA = REQUESTCODE_ALBUM + 1;
	public static final int REQUESTCODE_CROP = REQUESTCODE_CAMERA + 1;
	public static final int REQUESTCODE_VIDEO = REQUESTCODE_CROP + 1;
	public static final int REQUESTCODE_FILE = REQUESTCODE_VIDEO + 1;
	
	private final String ACTION_CROP = "com.android.camera.action.CROP";
	
	private final String CROP_FILENAME = "crop_";
	private final String SCALE_FILENAME = "scale_";
	
	private Context m_Context = null;
	
	private String m_strSaveDirectory = "";
	public String m_strSaveFileName = "";
	
	public TakeMediaIntent(Context a_Context)
	{
		m_Context = a_Context;
		//m_strSaveDirectory = m_Context.getFilesDir().getPath();
		m_strSaveDirectory = m_Context.getExternalFilesDir(Environment.DIRECTORY_PICTURES).getPath();
		File path = new File(m_strSaveDirectory);
		if(path.isDirectory()){
			File[] childFileList = path.listFiles();
			for(File childFile : childFileList){
				childFile.delete();
			}
			path.delete();
		}
	    if(!path.isDirectory()) 
	    {
	    	path.mkdirs();
	    }
	}

	public void deleteDirectory(){
		File path = new File(m_strSaveDirectory);
		if(path.isDirectory()){
			File[] childFileList = path.listFiles();
			for(File childFile : childFileList){
				childFile.delete();
			}
			path.delete();
		}
	}
	public void doGetImageFromAlbum()
	{
		/*Intent intent = new Intent(Intent.ACTION_PICK);
		intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_ALBUM);*/

		Intent intent = new Intent(m_Context, GalleryMultiselectorListAct.class);
		intent.setAction(GalleryAction.ACTION_IMAGE_LIST);
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_COUNT_LIMIT, 1);		//파일 선택 갯수 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_SIZE_LIMIT, 104857600L);		//파일 용량 선택 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FROM, GalleryMultiselectorListAct.FROMACTIVITY_PROFILE);				// 채팅방 or 모임
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_ALBUM);
	}
	//GalleryAction.ACTION_IMAGE_LIST; 사진 겔러리
	public void doGetMultiSelectImageFromGallery(int a_nFromActivity, int max_select_count, long max_select_size )
	{
		Intent intent = new Intent(m_Context, GalleryMultiselectorListAct.class);
		intent.setAction(GalleryAction.ACTION_IMAGE_LIST);
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_COUNT_LIMIT, max_select_count);		//파일 선택 갯수 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_SIZE_LIMIT, max_select_size);		//파일 용량 선택 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FROM, a_nFromActivity);				// 채팅방 or 모임
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_ALBUM);
	}

	public void doGetMultiSelectImageFromGalleryFrag(Fragment fragment, int a_nFromActivity, int max_select_count, long max_select_size )
	{
		Intent intent = new Intent(m_Context, GalleryMultiselectorListAct.class);
		intent.setAction(GalleryAction.ACTION_IMAGE_LIST);
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_COUNT_LIMIT, max_select_count);		//파일 선택 갯수 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_SIZE_LIMIT, max_select_size);		//파일 용량 선택 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FROM, a_nFromActivity);				// 채팅방 or 모임
		fragment.startActivityForResult(intent, REQUESTCODE_ALBUM);
	}
	//GalleryAction.ACTION_VIDEO_LIST; 비디오 겔러리 
	public void doGetMultiSelectVideoFromGallery(int max_select_count, long max_select_size)
	{
		Intent intent = new Intent(m_Context, GalleryMultiselectorListAct.class);
		intent.setAction(GalleryAction.ACTION_VIDEO_LIST);
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_COUNT_LIMIT, max_select_count);		//파일 선택 갯수 제한
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_SIZE_LIMIT, max_select_size);		//파일 용량 선택 제한 
		intent.putExtra(IntentKeyString.INTENT_KEY_GALLERYMULTISELECTOR_FROM, GalleryMultiselectorListAct.FROMACTIVITY_SNS);	// 채팅방 or 모임
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_VIDEO);
	}
	
	public boolean doTakeImageFromCamera()
	{
		if(!FileUtil.externalMemoryAvailable() || 
				FileUtil.getAvailableExternalMemorySize() < 4 * 1024 * 1024){
			return false;
		}
		
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		
		String url = "Cork_" + String.valueOf(System.currentTimeMillis()) + ".jpg";
		SharedPref pref = SharedPref.getInstance(m_Context);
		pref.setStringPref(SharedPref.PREF_TAKEPICTURE_TEMPFILENAME, url);
		intent.putExtra(MediaStore.EXTRA_SCREEN_ORIENTATION, 90);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(m_strSaveDirectory, url)));
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_CAMERA);
		return true;
	}

	public boolean doTakeImageFromCameraFrag(Fragment fragment)
	{
		if(!FileUtil.externalMemoryAvailable() ||
				FileUtil.getAvailableExternalMemorySize() < 4 * 1024 * 1024){
			return false;
		}

		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		String url = "Cork_" + String.valueOf(System.currentTimeMillis()) + ".jpg";
		SharedPref pref = SharedPref.getInstance(m_Context);
		pref.setStringPref(SharedPref.PREF_TAKEPICTURE_TEMPFILENAME, url);
		intent.putExtra(MediaStore.EXTRA_SCREEN_ORIENTATION, 90);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(m_strSaveDirectory, url)));
		fragment.startActivityForResult(intent, REQUESTCODE_CAMERA);
		return true;
	}

	public void doGetVideoFromAlbum()
	{
		Intent intent = new Intent(Intent.ACTION_PICK);
		intent.setType("video/*");
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_VIDEO);
	}
	
	public void doCropImageFromCameraWithAspect()
	{
		SharedPref pref = SharedPref.getInstance(m_Context);
		String strUri = pref.getStringPref(SharedPref.PREF_TAKEPICTURE_TEMPFILENAME);

		/*ContentValues values = new ContentValues();
    	values.put(Images.Media.TITLE, "TTalk"); 
    	
    	values.put(Images.Media.DISPLAY_NAME, "TTalk");
        values.put(Images.Media.BUCKET_ID, "TTalk"); 
        values.put(Images.Media.DESCRIPTION, "TTalk"); 
        values.put(Images.Media.MIME_TYPE, "image/jpeg"); 
        values.put(Images.Media.DATA, m_strSaveDirectory + "/" + strUri);
        m_Context.getContentResolver().insert(Images.Media.EXTERNAL_CONTENT_URI, values);*/
        
		doCropImage(Uri.fromFile(new File(m_strSaveDirectory, strUri)), true);
	}
	
	public void doCropImageFromCameraWithoutAspect()
	{
		SharedPref pref = SharedPref.getInstance(m_Context);
		String strUri = pref.getStringPref(SharedPref.PREF_TAKEPICTURE_TEMPFILENAME);
		
		/*ContentValues values = new ContentValues();
    	values.put(Images.Media.TITLE, "TTalk"); 
    	
    	values.put(Images.Media.DISPLAY_NAME, "TTalk");
        values.put(Images.Media.BUCKET_ID, "TTalk"); 
        values.put(Images.Media.DESCRIPTION, "TTalk"); 
        values.put(Images.Media.MIME_TYPE, "image/jpeg"); 
        values.put(Images.Media.DATA, m_strSaveDirectory + "/" + strUri);
        m_Context.getContentResolver().insert(Images.Media.EXTERNAL_CONTENT_URI, values);*/
        
		doCropImage(Uri.fromFile(new File(m_strSaveDirectory, strUri)), false);
	}
	
	public void doCropImageFromAlbumWithAspect(Uri a_Uri)
	{
		//구글 포토사용시를 대처하기 위함 이었으나, 자체 이미지 셀렉터로 변경되어 사용하지 않음
		/*if(a_Uri.toString().startsWith("content://com.google.android.apps.photos.contentprovider")){
			try {
				a_Uri = getPhotosPhotoUri(a_Uri.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/

		doCropImage(a_Uri, true);
	}

	protected Uri getPhotosPhotoUri(String uri) throws IOException {
		Uri parsedUri;
		uri = uri.replace("content://com.google.android.apps.photos.contentprovider", "");

		String[] parts = uri.split("/");
		return Uri.parse(URLDecoder.decode(parts[3]));
		/*if (parts.length > 4) {
			String finalString = "";

			for(int i = 3 ; i < parts.length - 2 ; i ++){
				if(!finalString.isEmpty()){
					finalString +="/";
				}
				finalString += parts[i];
			}

			return parsedUri = Uri.parse(URLDecoder.decode(finalString));

		}else{
			return parsedUri = Uri.parse(uri);
		}*/
	}

	public void doCropImageFromAlbumWithoutAspect(Uri a_Uri)
	{
		doCropImage(a_Uri, false);
	}
	
	public void doCropImage(Uri a_Uri, boolean a_isAspect)
	{
/*		Intent intent = new Intent(ACTION_CROP);
		intent.setDataAndType(a_Uri, "image*//*");
//		intent.putExtra("outputX", a_nWidth);
//		intent.putExtra("outputY", a_nHeight);
		if(a_isAspect)
		{
			intent.putExtra("aspectX", 1);
			intent.putExtra("aspectY", 1);
		}
		intent.putExtra("scale", true);
		m_strSaveFileName = CROP_FILENAME + System.currentTimeMillis() + ".jpg";
		intent.putExtra("output", Uri.fromFile(new File(m_strSaveDirectory, m_strSaveFileName)));
//		intent.putExtra("return-data", true);
		((Activity)m_Context).startActivityForResult(intent, REQUESTCODE_CROP);*/

		m_strSaveFileName = CROP_FILENAME + System.currentTimeMillis() + ".jpg";
		UCrop.Options options = new UCrop.Options();
		options.setStatusBarColor(Color.BLACK);
		options.setToolbarColor(Color.WHITE);
		options.setToolbarWidgetColor(Color.BLACK);
		UCrop.of(a_Uri, Uri.fromFile(new File(m_strSaveDirectory, m_strSaveFileName))).withAspectRatio(1,1)
				.withMaxResultSize(1920, 1920).withOptions(options).start((Activity)m_Context);
	}

	public void deleteImage() {
		File file = new File(m_strSaveDirectory, m_strSaveFileName);
		if(file.exists()){
			file.delete();
		}
	}
	public Bitmap getCropImageBitmap()
	{
		return BitmapFactory.decodeFile(Uri.fromFile(new File(m_strSaveDirectory, m_strSaveFileName)).getPath());
	}
	
	public byte[] getCropImageByte()
	{
		byte[] imgData = null;
		File file = new File(m_strSaveDirectory, m_strSaveFileName);
		try {
			FileInputStream isFile = new FileInputStream(file);
			int nCount = isFile.available();
			if(nCount > 0)
			{
				imgData = new byte[nCount];
				isFile.read(imgData);
			}
			if(isFile != null)
			{
				isFile.close();
			}
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}

		return imgData;
	}
	
	public String getCropImageFilePath()
	{
		return m_strSaveDirectory +"/"+ m_strSaveFileName;
	}
	
	public String getCropImageFileName()
	{
		return m_strSaveFileName;
	}

	public void scaleAlbumImage(Uri a_Uri)
	{
		try {
			Cursor cursor = m_Context.getContentResolver().query(a_Uri, null, null, null, null );
			cursor.moveToNext();
			String path = cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DATA));
			cursor.close();
			int nDegree = getRotationForImage(path);
			Bitmap bm = Images.Media.getBitmap(m_Context.getContentResolver(), a_Uri);
			Bitmap bmpRotate = rotate(bm, nDegree);

			scaleBitmap(bmpRotate);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void scaleCameraImage()
	{
		SharedPref pref = SharedPref.getInstance(m_Context);
		String strUri = pref.getStringPref(SharedPref.PREF_TAKEPICTURE_TEMPFILENAME);
		
		int nDegree = getRotationForImage(m_strSaveDirectory + "/" + strUri);
		
		Bitmap bm = BitmapFactory.decodeFile(m_strSaveDirectory + "/" + strUri);
		Bitmap bmpRotate = rotate(bm, nDegree);
		scaleBitmap(bmpRotate);
	}
	
	public void scaleCropImage()
	{
		int nDegree = getRotationForImage(m_strSaveDirectory + "/" + m_strSaveFileName);
		
		Bitmap bm = BitmapFactory.decodeFile(m_strSaveDirectory + "/" + m_strSaveFileName);
		Bitmap bmpRotate = rotate(bm, nDegree);
		scaleBitmap(bmpRotate);
	}
	
	private void scaleBitmap(Bitmap a_Bmp)
	{
		Bitmap bmpScale;
		
		if(a_Bmp.getWidth() > 1920 || a_Bmp.getHeight() > 1920)
			if(a_Bmp.getWidth() > 1920)
				bmpScale = Bitmap.createScaledBitmap(a_Bmp, 1920, a_Bmp.getHeight()*1920/a_Bmp.getWidth(), false);
			else
				bmpScale = Bitmap.createScaledBitmap(a_Bmp, a_Bmp.getWidth()*1920/a_Bmp.getHeight(), 1920,  false);
		else
			bmpScale = a_Bmp;
		
		m_strSaveFileName = SCALE_FILENAME + System.currentTimeMillis() + ".jpg";
		File copyFile = new File(m_strSaveDirectory, m_strSaveFileName);

		OutputStream out = null;
		        
		try {
		            
		    copyFile.createNewFile();
		    out = new FileOutputStream(copyFile);
		            
		    bmpScale.compress(CompressFormat.JPEG, 60, out);
		} 
		catch (Exception e) {         
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public int getRotationForImage(String path) 
	{
		int rotation = 0;
	    try { 
	        ExifInterface exif = new ExifInterface(path);
	        int exifOrientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
	        rotation = exifOrientationToDegrees(exifOrientation);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    return rotation;
	}
	
	public int exifOrientationToDegrees(int exifOrientation)
	{
		if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_90)
		{
			return 90;
	    }
		else if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_180)
		{
			return 180;
		}
		else if(exifOrientation == ExifInterface.ORIENTATION_ROTATE_270)
		{
			return 270;
		}
		return 0;
	}
	
	public Bitmap rotate(Bitmap bitmap, int degrees)
	{
		if(degrees != 0 && bitmap != null)
		{
			Matrix m = new Matrix();
			m.setRotate(degrees, (float) bitmap.getWidth() / 2, (float) bitmap.getHeight() / 2);
			try
			{
				Bitmap converted = Bitmap.createBitmap(bitmap, 0, 0,
						bitmap.getWidth(), bitmap.getHeight(), m, true);
				if(bitmap != converted)
				{
					bitmap.recycle();
					bitmap = converted;
				}
		    }
		    catch(OutOfMemoryError ex)
		    {
		    	// 메모리가 부족하여 회전을 시키지 못할 경우 그냥 원본을 반환합니다.
		    }
		}
		return bitmap;
	}
}
