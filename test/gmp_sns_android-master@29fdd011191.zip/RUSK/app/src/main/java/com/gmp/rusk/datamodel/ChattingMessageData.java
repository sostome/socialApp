package com.gmp.rusk.datamodel;

import java.util.ArrayList;

public class ChattingMessageData {
	
	public int m_nIdx = -1;						// Chatting Database Primary Key
	public String m_strMsgId = "";				// Message Id
	public int m_nSendUserId = 0;				// Message Send User Id
	public long m_lnMsgSendTime = 0L;			// Message Send Millisecond Time
	public int m_nMsgType = 0;					// Message Type
	public String m_strMsgText = "";			// Message Text
	public boolean m_isRead = false;			// Message 내가 읽었는지 에 대한 true/false
	public int m_nSendStatus = 2;				// Message Send Status
//	public ArrayList<Integer> m_arrReadUser = new ArrayList<Integer>();		// Message Read User List Array
//	public ArrayList<Integer> m_arrCurrentUser = new ArrayList<Integer>();	// Message Insert 당시의 채팅 참여자 User List Array
	public ArrayList<String> m_SNSNoticeAddedList = new ArrayList<>();
	//그룹 Id,board No, 이미지 수,이미지,파일 수, 파일 사이즈, 파일 /순서로 넣음
	public int m_nNoReadUserCount = 0;
	public String m_strEmoticon = "";
}
