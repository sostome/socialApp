package com.gmp.rusk.response;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.utils.CommonLog;

public class GetOneRoomSyncRes extends Res{
	
	private final String JSON_RESULT 			= "result";
	private final String JSON_PAYLOADS			= "payloads";
	private final String JSON_MESSAGEID			= "messageId";
	private final String JSON_TIMESTAMP			= "timestamp";
	private final String JSON_PAYLOAD			= "payload";
	private final String JSON_TYPE				= "type";
	private final String JSON_JID				= "jid";

	private ArrayList<String> m_arrMessageIds;
	private HashMap<String, Long> m_mapIdAndTimeStamp;
	public GetOneRoomSyncRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		m_arrMessageIds = new ArrayList<String>();
		m_mapIdAndTimeStamp = new HashMap<String, Long>();
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			if(jsonRoot.has(JSON_PAYLOADS)){
			JSONArray jsonPayloads = jsonRoot.getJSONArray(JSON_PAYLOADS);
			for(int i = 0; i < jsonPayloads.length(); i++){
				JSONObject jsonObj = (JSONObject) jsonPayloads.get(i);
				m_arrMessageIds.add(jsonObj.getString(JSON_MESSAGEID));
				JSONObject jsonPayload = jsonObj.getJSONObject(JSON_PAYLOAD);
				m_mapIdAndTimeStamp.put(jsonPayload.getString(JSON_JID), jsonObj.getLong(JSON_TIMESTAMP));
			}
			}
			//m_strBackUp = jsonRoot.getString(JSON_RESULT);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<String> getMessageIds(){
		return m_arrMessageIds;
	}
	
	public HashMap<String, Long> getIdAndTimeStamp(){
		return m_mapIdAndTimeStamp;
	}
//	public String getResult()
//	{
//		return m_strBackUp;
//	}
}
