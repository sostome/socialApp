package com.gmp.rusk.request;

import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 *	@author kch
 *			모임 게시글 공지 등록
 *			method : put
 */

public class PutGroupBoardNoticeReq extends Req{

	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";

	private final String JSON_VALIDPARIOD		= "validPeriod";

	private int m_nValidPeriod = 0;


	public PutGroupBoardNoticeReq(int a_nGroupId, int a_nThreadId, int a_nValidPeriod)
	{
		APINAME = APINAME +"/" + a_nGroupId + "/thread/" + a_nThreadId + "/notice";

		m_nValidPeriod = a_nValidPeriod;
	}


	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_VALIDPARIOD, m_nValidPeriod);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PutGroupBoardNoticeReq.class.getSimpleName(), "" + e.getMessage());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
