package com.gmp.rusk.request;

import com.gmp.rusk.MyApp;

/**
 * @author Stan
 *		   서버Interface 통신을 위한 Req 추상크래스
 */
abstract public class Req {
	public MyApp App = MyApp.getInstance();
	private final int REQUEST_TYPE_JSON = 1;
	private final int REQUEST_TYPE_RESUTFUL = 2;
	private final int REQUEST_TYPE_NAMEVALUEPAIR = 3;
	protected  int m_nRequestType = REQUEST_TYPE_JSON;
	
	private boolean m_isLongPolling = false;
	
	abstract public String getAPIName();
	abstract public String getMethod();
	abstract public String getIsAuthentification();
	
	abstract public String getJsonData();
	abstract public String getParamData();
	abstract public String getNameValuePair();

	public String MakeRequestData() {
		if(m_nRequestType == REQUEST_TYPE_JSON) {
			return getJsonData();			
		} else if (m_nRequestType == REQUEST_TYPE_RESUTFUL) {
			return getParamData();
		} else if (m_nRequestType == REQUEST_TYPE_NAMEVALUEPAIR){
			return getNameValuePair();
		}
		return null;
	}
	
	protected void setLongPolling(boolean a_isLongPolling)
	{
		m_isLongPolling = a_isLongPolling;
	}
	
	public boolean getIsLongPolling()
	{
		return m_isLongPolling;
	}
	
	public String getLongPolling()
	{
		return m_isLongPolling ? "true" : "false";
	}

}
