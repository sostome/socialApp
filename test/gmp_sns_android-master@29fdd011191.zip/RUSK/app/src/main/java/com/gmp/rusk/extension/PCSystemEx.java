package com.gmp.rusk.extension;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class PCSystemEx implements PacketExtension{
		public static final String NAMESPACE = "urn:utalk:system";
		public static final String ELEMENT_NAME = "info";
		
		private String type;
		private String hostname;
		private String deviceUID;
		private String groupId;
		private String boardNo;
		private String replyNo;
		private String approvalUserNo;
		
		
		public PCSystemEx(){}
		public PCSystemEx(String type, String hostname, String deviceUID, String groupId, String boardNo, String replyNo, String approvalUserNo){
			this.type = type;
			this.hostname = hostname;
			this.deviceUID = deviceUID;
			this.groupId = groupId;
			this.boardNo = boardNo;
			this.replyNo = replyNo;
			this.approvalUserNo = approvalUserNo;
		}

		
		@Override
		public String getElementName() {
			// TODO Auto-generated method stub
			return ELEMENT_NAME;
		}

		@Override
		public String getNamespace() {
			// TODO Auto-generated method stub
			return NAMESPACE;
		}
		
		public String getType(){
			return type;
		}

		public String getApprovalUserNo() {return approvalUserNo;}
		@Override
		public String toXML() {
			// TODO Auto-generated method stub
			StringBuilder buf = new StringBuilder();
			buf.append("SystemEx : ");
			buf.append("<type : " + this.type + ">");
			buf.append("<hostname : " + this.hostname + ">");
			buf.append("<deviceUID : " + this.deviceUID + ">");
			buf.append("<groupId : " + this.groupId + ">");
			buf.append("<boardNo : " + this.boardNo + ">");
			buf.append("<replyNo : " + this.replyNo + ">");
			return buf.toString();
		}
		
		public static class Provider implements PacketExtensionProvider {

			public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
	            String type = "";
	            String hostname = "";
	            String deviceUID = "";
	            String groupId = "";
	            String boardNo = "";
	            String replyNo = "";
				String applovalUserNo = "";
				boolean done = false;
				int cnt = parser.getAttributeCount();
				for(int i = 0; i < cnt; i++){
					if(parser.getAttributeName(i).equals("type")){
						type = parser.getAttributeValue(i);		
					}
				}
				while(!done){
					int eventType = parser.next();					
					if (eventType == XmlPullParser.START_TAG) {
		                if (parser.getName().equals("hostname")) {
		                	hostname = parser.nextText();
		                } else if(parser.getName().equals("deviceUID")){
		                	deviceUID = parser.nextText();
		                } else if(parser.getName().equals("groupId")){
		                	deviceUID = parser.nextText();
		                } else if(parser.getName().equals("boardNo")){
		                	deviceUID = parser.nextText();
		                } else if(parser.getName().equals("replyNo")){
		                	deviceUID = parser.nextText();
		                } else if(parser.getName().equals("approvalUserNo")){
							applovalUserNo = parser.nextText();
						}
		            }
		            else if (eventType == XmlPullParser.END_TAG) {
		                if (parser.getName().equals(ELEMENT_NAME)) {
		                    done = true;
		                }
		            }
				}
				return new PCSystemEx(type, hostname, deviceUID, groupId, boardNo, replyNo, applovalUserNo);
			}
		}
	}