package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.PartnerSearchListData;
import com.gmp.rusk.datamodel.RegularSearchListData;
import com.gmp.rusk.datamodel.UserSearchListData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.StaticString;

public class PostSearchUserRes extends Res{

	
	ArrayList<UserSearchListData> m_arrUserSearchListDatas = null;
	
	public PostSearchUserRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_RESULTS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_RESULTS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrUserSearchListDatas = new ArrayList<UserSearchListData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						UserSearchListData data = null;
						int nUserNo = jsonItem.optInt(JSON_USERNO);
						String strType = jsonItem.optString(JSON_TYPE);
						String strName = jsonItem.optString(JSON_NAME);
						boolean isImageAvailable = jsonItem.optBoolean(JSON_IMAGEAVAILABLE);
						boolean isAvailable = jsonItem.optBoolean(JSON_AVAILABLE);

						if(strType.equals("R"))
						{
							String strCompanyName = jsonItem.optString(JSON_COMPANYNAME);
							String strCharge = jsonItem.optString(JSON_CHARGE);
							String strSecondCharge = jsonItem.optString(JSON_SECONDCHARGE);
							String strPosition = jsonItem.optString(JSON_POSITION);
							String strDepartment = jsonItem.optString(JSON_DEPARTMENT);
							String strParentDepartment = jsonItem.optString(JSON_PARENTDEPARTMENT);
							
							RegularSearchListData item = new RegularSearchListData(nUserNo, strName,strCompanyName ,strCharge,strSecondCharge,strPosition ,strDepartment, strParentDepartment, isImageAvailable, isAvailable);
							
							data = new UserSearchListData();
							data.m_isRegular = true;
							data.m_UserData = item;
							
							m_arrUserSearchListDatas.add(data);
						}
						else if(strType.equals("P"))
						{

							String strCharge = jsonItem.optString(JSON_CHARGE);
							String strPosition = jsonItem.optString(JSON_POSITION);
							String strAffliation = jsonItem.optString(JSON_AFFILIATION);

							strType = StaticString.VARIANT_PARTNER;
							
							PartnerSearchListData item = new PartnerSearchListData(nUserNo, strName,strCharge,strPosition, strAffliation, isImageAvailable, isAvailable, strType);
							
							data = new UserSearchListData();
							data.m_isRegular = false;
							data.m_UserData = item;
							
							m_arrUserSearchListDatas.add(data);
						}
					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}
	
	public ArrayList<UserSearchListData> getUserSearchListData()
	{
		return m_arrUserSearchListDatas;
	}

}
