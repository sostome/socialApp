package com.gmp.rusk.request;


import com.gmp.rusk.utils.SharedPref;

/**
 *	@author kch
 *			모임 조회
 *			method : get
 */

public class GetGroupDetailReq extends Req{

	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "GET";

	public GetGroupDetailReq(int a_nChannelNo)
	{
		APINAME = APINAME + "/" + a_nChannelNo;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
