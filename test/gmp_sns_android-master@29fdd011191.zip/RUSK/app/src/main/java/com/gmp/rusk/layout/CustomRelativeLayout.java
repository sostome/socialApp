package com.gmp.rusk.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

import com.gmp.rusk.MyApp;

/**
 * Created by kang on 2017-05-18.
 */

public class CustomRelativeLayout extends RelativeLayout {
    public MyApp App = MyApp.getInstance();
    public CustomRelativeLayout(Context context) {
        super(context);

    }

    public CustomRelativeLayout(Context context, AttributeSet attrs) {
        super(context);
    }
}
