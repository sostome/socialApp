package com.gmp.rusk.push;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.text.TextUtils;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.PushPopupScreenOffAct;
import com.gmp.rusk.broadcastreceiver.PushBroadcastReceiver;
import com.gmp.rusk.customview.CommonPopupAct;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.PushPopupScreenOnToast;
import com.gmp.rusk.datamodel.SNSAlarmData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.db.TTalkDBManager.SNSGroupDBManager;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IconBadge;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.List;

public class PushController {

	private static MyApp App = MyApp.getInstance();

//	private static final String TAG = PushController.class.getSimpleName();

	private static final String JSON_AOM_ALERT 		= "alert";
	//유라클 푸시에서 전달 하는 방식 변경으로 변환함
	private static final String JSON_AOM_MESSAGE 	= "MESSAGE";
	private static final String JSON_AOM_EXT 		= "EXT";
	private static final String JSON_AOM_PAYLOAD 	= "mps";
	private static final String JSON_AOM_NAME 		= "name";
	private static final String JSON_AOM_USERNO 	= "userNo";
	private static final String JSON_AOM_IMG 		= "img";
	private static final String JSON_AOM_GID 		= "gid";
	private static final String JSON_AOM_TYPE		= "type";
/*	private static final String JSON_AOM_BADGE		= "b";
	private static final String JSON_AOM_GROUP		= "g";
	private static final String JSON_AOM_REPLY		= "r";*/
	private static final String JSON_AOM_ISSILENT 	= "isSilent";
	private static final String JSON_AOM_COUNT = "count";
	private static final String JSON_AOM_CHANNELID = "cid";
	private static final String JSON_AOM_THREADNO = "tno";
	private static final String JSON_AOM_COMMENTNO = "cno";


	private static final String AOM_TYPE_CHAT			 	= "me";
	private static final String AOM_TYPE_GROUPCHATKICK 			= "gck";
	private static final String AOM_TYPE_APPROVALREQUEST 		= "ar";
	private static final String AOM_TYPE_SNS			 		= "cu";
	private static final String AOM_TYPE_SNS_INVITE			 	= "ci";



	
	private static int TTALK_NOTIFICATION_ID = 1111;
	
	private static PushPopupScreenOnToast m_pushToast = null;
	
	public static void recvPushMessage(Context a_Context, String a_strMessage)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;
		
		try {
			JSONObject jsonRoot = new JSONObject(a_strMessage);
			String strAlert = jsonRoot.getString(JSON_AOM_MESSAGE);
			JSONObject jsonPayload = new JSONObject(jsonRoot.getString(JSON_AOM_EXT));
			
			if(jsonPayload.has(JSON_AOM_TYPE) && !jsonPayload.getString(JSON_AOM_TYPE).equals(AOM_TYPE_CHAT))
			{
				processPushSystemMessage(a_Context, strAlert, jsonPayload);
			}
			else if(jsonPayload.has(JSON_AOM_TYPE) && jsonPayload.getString(JSON_AOM_TYPE).equals(AOM_TYPE_CHAT))
			{
				processPushMessage(a_Context, strAlert, jsonPayload);
			}
			
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void processPushMessage(final Context a_Context, final String a_strAlert, JSONObject a_jsonObj) throws JSONException
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		
		String strName = "";
		if(a_jsonObj.has(JSON_AOM_NAME))
			strName = a_jsonObj.getString(JSON_AOM_NAME);
		final int nUserNo = a_jsonObj.getInt(JSON_AOM_USERNO);
		String strImg = "";
		if(a_jsonObj.has(JSON_AOM_IMG))
			strImg = a_jsonObj.getString(JSON_AOM_IMG);
		
		boolean isSilent = false;
		if(a_jsonObj.has(JSON_AOM_ISSILENT))
			isSilent = a_jsonObj.getBoolean(JSON_AOM_ISSILENT);
		
		boolean isGroupChat = false;
		String strRoomId;
		if(a_jsonObj.has(JSON_AOM_GID))
		{
			strRoomId = a_jsonObj.getString(JSON_AOM_GID);
			isGroupChat = true;
		}
		else
			strRoomId = "" + nUserNo;
		
		String strGid = isGroupChat ? strRoomId : null;
		
		boolean isRoomAlarm = TTalkDBManager.RoomDBManager.isRoomAlarm(a_Context, strRoomId);
		
		if(!isRoomAlarm || isSilent)
		{
			CommonLog.e(PushController.class.getSimpleName(), strRoomId + " Room Alarm off or isSilent is true");
			return;
			
		}
		else
		{
			CommonLog.e(PushController.class.getSimpleName(), strRoomId + " Room Alarm on");
		}
		
		boolean isAlarmPopup = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
		if(isAlarmPopup)
		{
			PowerManager pm = (PowerManager)a_Context.getSystemService(Context.POWER_SERVICE);
			boolean isScreenOn = pm.isScreenOn();
			
			if(isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning)
			{
				if(isTopActivity(a_Context))
					return;
				
				if(isXMPPServiceRunning(a_Context))
					return;

				Handler mHandler = new Handler(Looper.getMainLooper());
				final String finalStrName = strName;
				final String finalStrImg = strImg;
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						if(m_pushToast == null)
							m_pushToast = new PushPopupScreenOnToast(a_Context);

						m_pushToast.showToast(nUserNo, finalStrName, a_strAlert, finalStrImg);
					}
				});

			}
			else
			{
				if(!isScreenOn)
				{
					startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_MSG, nUserNo, strName, a_strAlert, strImg, strGid);
				}
				else
				{
					if(isTopActivity(a_Context) && !PushPopupScreenOffAct.m_isPushPopupRunning)
					{
						return;
					}
					else
					{
						startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_MSG, nUserNo, strName, a_strAlert, strImg, strGid);
					}
				}
			}
		}
		
		increasePushMessageIconBadge(a_Context);
		buildMessageNotification(a_Context, nUserNo, strName, a_strAlert, strImg, strGid);
	}
	
	private static void processPushSystemMessage(final Context a_Context, final String a_strAlert, JSONObject a_jsonObj) throws JSONException
	{
		boolean isSilent = false;
		if(a_jsonObj.has(JSON_AOM_ISSILENT))
			isSilent = a_jsonObj.getBoolean(JSON_AOM_ISSILENT);
		
		if(isSilent)
		{
			CommonLog.e(PushController.class.getSimpleName(), " isSilent is true");
			return;
			
		}
		
		SharedPref pref = SharedPref.getInstance(a_Context);
		
		String strType = a_jsonObj.getString(JSON_AOM_TYPE);
		if(strType.equals(AOM_TYPE_GROUPCHATKICK))
		{
			boolean isAlarmPopup = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
			if(isAlarmPopup)
			{
				increasePushMessageIconBadge(a_Context);
				
				PowerManager pm = (PowerManager)a_Context.getSystemService(Context.POWER_SERVICE);
				boolean isScreenOn = pm.isScreenOn();
				
				if(isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning)
				{
					Handler mHandler = new Handler(Looper.getMainLooper());
					mHandler.post(new Runnable() {
						@Override
						public void run() {
							if(m_pushToast == null)
								m_pushToast = new PushPopupScreenOnToast(a_Context);

							m_pushToast.showToast(a_strAlert);
						}
					});
				}
				else
				{
					startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_KICK, -1, null, a_strAlert, null, null);
				}
			}
			
			buildKickNotification(a_Context, a_strAlert);
		}
		else if(strType.equals(AOM_TYPE_APPROVALREQUEST))
		{
			int nBadge = a_jsonObj.getInt(JSON_AOM_COUNT);
			pref.setIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, nBadge);
			
			Intent intent = new Intent(StaticString.BROADCAST_APPROVALREQUESTBADGE_RECEIVER);
			a_Context.sendBroadcast(intent, StaticString.BROADCAST_PERMISSION_APPROVALREQUESTBADGE);
			
			boolean isAlarmPopup = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
			if(isAlarmPopup)
			{
				updateIconBadge(a_Context);
				
				PowerManager pm = (PowerManager)a_Context.getSystemService(Context.POWER_SERVICE);
				boolean isScreenOn = pm.isScreenOn();
				
				if(isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning)
				{
					Handler mHandler = new Handler(Looper.getMainLooper());
					mHandler.post(new Runnable() {
					@Override
					public void run() {
						if(m_pushToast == null)
							m_pushToast = new PushPopupScreenOnToast(a_Context);

						m_pushToast.showToast(a_strAlert);
					}
				});
				}
				else
				{
					startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_REQUEST, -1, a_Context.getString(R.string.app_name), a_strAlert, null, null);
				}
			}
			
			buildRequestNotification(a_Context, a_strAlert, nBadge);
		}
		else if(strType.equals(AOM_TYPE_SNS_INVITE)){
			PowerManager pm = (PowerManager)a_Context.getSystemService(Context.POWER_SERVICE);
			boolean isScreenOn = false;
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
				isScreenOn = pm.isInteractive();
			}
			else if(Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT_WATCH){
				isScreenOn = pm.isScreenOn();
			}

			if(isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning)
			{
				Handler mHandler = new Handler(Looper.getMainLooper());
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						if(m_pushToast == null)
							m_pushToast = new PushPopupScreenOnToast(a_Context);

						m_pushToast.showToast(a_strAlert);
					}
				});

			}
			else
			{
				startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_INVITE, a_Context.getString(R.string.app_name), a_strAlert, 0, 0, 0);
			}
			buildSNSInviteNotification(a_Context, a_strAlert);
			increaseSNSPushIconBadge(a_Context);
		}
		else if(strType.equals(AOM_TYPE_SNS))
		{
			int nBoardId = -1;
			int nGroupId = -1;
			int nReplyId = 0;
			if(a_jsonObj.has(JSON_AOM_THREADNO))
				nBoardId = a_jsonObj.getInt(JSON_AOM_THREADNO);
			if(a_jsonObj.has(JSON_AOM_CHANNELID))
				nGroupId = a_jsonObj.getInt(JSON_AOM_CHANNELID);
			if(a_jsonObj.has(JSON_AOM_COMMENTNO))
				nReplyId = a_jsonObj.getInt(JSON_AOM_COMMENTNO);

			if(nGroupId == pref.getIntegerPref(SharedPref.PREF_CHANNEL_LASTVIEW) && (App.mAppStatus == MyApp.AppStatus.FOREGROUND) && App.m_isInChannelList) {
				return;
			} else {
			}

			if(nReplyId != 0)
			{
				boolean isAlarmPopup = pref.getBooleanPref(SharedPref.PREF_SNSGROUP_REPLY_ALARM, true);

				if(isAlarmPopup)
				{
					PowerManager pm = (PowerManager)a_Context.getSystemService(Context.POWER_SERVICE);
					boolean isScreenOn = false;
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
						isScreenOn = pm.isInteractive();
					}
					else if(Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT_WATCH){
						isScreenOn = pm.isScreenOn();
					}

					if(isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning)
					{
						Handler mHandler = new Handler(Looper.getMainLooper());
						mHandler.post(new Runnable() {
							@Override
							public void run() {
								if(m_pushToast == null)
									m_pushToast = new PushPopupScreenOnToast(a_Context);

								m_pushToast.showToast(a_strAlert);
							}
						});

					}
					else
					{
						startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_REPLY, a_Context.getString(R.string.app_name), a_strAlert, nGroupId, nBoardId, nReplyId);
					}
				}
				else
					return;

				buildSNSNotification(a_Context, a_strAlert, nGroupId, nBoardId, nReplyId);
			}
			else
			{
				boolean isAlarmPopup = pref.getBooleanPref(SharedPref.PREF_SNSGROUP_BOARD_ALARM, true);

				if(isAlarmPopup)
				{
					PowerManager pm = (PowerManager)a_Context.getSystemService(Context.POWER_SERVICE);
					boolean isScreenOn = pm.isScreenOn();

					if(isScreenOn && !PushPopupScreenOffAct.m_isPushPopupRunning)
					{
						Handler mHandler = new Handler(Looper.getMainLooper());
						mHandler.post(new Runnable() {
							@Override
							public void run() {
								if(m_pushToast == null)
									m_pushToast = new PushPopupScreenOnToast(a_Context);

								m_pushToast.showToast(a_strAlert);
							}
						});
					}
					else
					{
						startPushPopupScreenOffAct(a_Context, IntentKeyString.INTENT_VALUE_PUSHPOPUP_TYPE_SNS_BOARD, a_Context.getString(R.string.app_name), a_strAlert, nGroupId, nBoardId, nReplyId);
					}
				}
				else
					return;

				buildSNSNotification(a_Context, a_strAlert, nGroupId, nBoardId, nReplyId);
			}

			insertSNSDB(a_Context, nGroupId, nBoardId, nReplyId);
			increaseSNSPushIconBadge(a_Context);

			Intent intent = new Intent(StaticString.BROADCAST_SNSPUSH_RECEIVER);
			a_Context.sendBroadcast(intent, StaticString.BROADCAST_PERMISSION_SNSPUSH);
		}
	}
	
	private static boolean isTopActivity(Context a_Context)
	{
		ActivityManager am = (ActivityManager)a_Context.getSystemService(Context.ACTIVITY_SERVICE);
		List<ActivityManager.RunningAppProcessInfo> task = am.getRunningAppProcesses();
		//com.gmp.rusk 밖에 나오지 않으나, 혹시 모르므로 for 문 사용
		for(int i = 0; i < task.size(); i++){
			if(a_Context.getPackageName().equals(task.get(i).processName)){
				if(ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND == task.get(i).importance){
			return true;
				}
			}
		}
		
		return false;
	}
	
	public static Boolean isXMPPServiceRunning(Context a_Context) 
	{
		ActivityManager activityManager = (ActivityManager)a_Context.getSystemService(Context.ACTIVITY_SERVICE);
		String strXMPPServiceName = "com.gmp.rusk.service.XmppConnectionService";
		for (RunningServiceInfo runningServiceInfo : activityManager.getRunningServices(Integer.MAX_VALUE)) 
		{
			if (strXMPPServiceName.equals(runningServiceInfo.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
	
	public static void showPushToast(Context a_Context, int a_nUserNo, String a_strName, String a_strAlert, String a_strImage, String a_strRoomId)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;
		
		boolean isAlarmPopup = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM_POPUP, true);
		if(!isAlarmPopup)
			return;
		
		boolean isRoomAlarm = TTalkDBManager.RoomDBManager.isRoomAlarm(a_Context, a_strRoomId);
		if(!isRoomAlarm)
			return;
		
		if(m_pushToast == null)
			m_pushToast = new PushPopupScreenOnToast(a_Context);
		
		m_pushToast.showToast(a_nUserNo, a_strName, a_strAlert, a_strImage);
	}
	
	public static void buildMessageNotification(Context a_Context, int a_nFriendUserNo, String a_strName, String a_strMsg, String a_strImageUrl, String a_strGid)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;
		
		String strRoomId;
		if(TextUtils.isEmpty(a_strGid)) {
			if(a_nFriendUserNo == 0 && a_strName.equals("cork.com")){
				strRoomId = "1";
			} else {
				strRoomId = "" + a_nFriendUserNo;
			}
		}
		else
			strRoomId = "" + a_strGid;
		
		boolean isRoomAlarm = TTalkDBManager.RoomDBManager.isRoomAlarm(a_Context, strRoomId);
		if(!isRoomAlarm)
			return;
		
		NotificationManager nm = (NotificationManager)a_Context.getSystemService(Context.NOTIFICATION_SERVICE);
//		NotificationManagerCompat nm = NotificationManagerCompat.from(a_Context);
		
		Intent intent;
		
		if(a_strGid != null)
		{
			intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_MESSAGE_GROUP);
			intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_GROUPID, a_strGid);
		}
		else
		{
			intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_MESSAGE_NORMAL);
			if(a_nFriendUserNo == 0 && a_strName.equals("cork.com")){
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_USERID, 1);
			} else {
				intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_USERID, a_nFriendUserNo);
			}
		}
		
		PendingIntent pie= PendingIntent.getBroadcast(a_Context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
		
		boolean isPreview = pref.getBooleanPref(SharedPref.PREF_PUSH_PREVIEW, true);
		
		String strTitle, strMsg;
		
		if(isPreview)
		{
			if(a_nFriendUserNo == 0 && a_strName.equals("cork.com")){
				strTitle = a_Context.getString(R.string.app_name);
			} else {
				strTitle = a_strName;
			}
			strMsg = a_strMsg;
		}
		else
		{
			strTitle = a_Context.getString(R.string.app_name);
			strMsg = a_Context.getString(R.string.pushpopup_defaultmsg);
		}
		
		boolean isSound = pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
		boolean isVibrate = pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
		ImageLoaderManager imageLoader = ImageLoaderManager.getInstance(a_Context);
		Bitmap bmpLargeIcon = null;

		if(a_nFriendUserNo != 0) {
			if (a_strImageUrl.equals(a_Context.getString(R.string.app_name))) {
				bmpLargeIcon = BitmapFactory.decodeResource(a_Context.getResources(), R.drawable.img_profile_cork);
			} else {
				bmpLargeIcon = imageLoader.getImage(a_strImageUrl, R.drawable.profile_pic_default);
			}
		} else if (a_nFriendUserNo == 0 && a_strName.equals("cork.com")){
			bmpLargeIcon = BitmapFactory.decodeResource(a_Context.getResources(), R.drawable.img_profile_cork);
		}

		int nSmallIcon = 0;
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
			nSmallIcon = R.drawable.ic_launcher;
		} else {
			nSmallIcon = R.drawable.ic_launcher_push;
		}
		Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		NotificationCompat.Builder pushNotiBuilder = new NotificationCompat.Builder(a_Context)
									.setContentTitle(strTitle)
									.setContentText(strMsg)
									.setSmallIcon(nSmallIcon)
									.setLargeIcon(bmpLargeIcon)
									.setTicker(strMsg)
//									.setContentInfo("1")
									.setAutoCancel(true);

		if(isSound)
			pushNotiBuilder.setSound(notificationSound);
		if(isVibrate)
			pushNotiBuilder.setVibrate(new long[]{0L, 500L});
		
		if(intent != null)
			pushNotiBuilder.setContentIntent(pie);
		
		nm.cancel(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID);
		
		LAST_NOTIFICATION_TAG = strRoomId;
		
		nm.notify(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID, pushNotiBuilder.build());
	}
	
	public static void buildKickNotification(Context a_Context, String a_strMsg)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;
		
		NotificationManager nm = (NotificationManager)a_Context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_KICK);
		
		PendingIntent pie= PendingIntent.getBroadcast(a_Context, 0, intent, PendingIntent.FLAG_ONE_SHOT);
		
		boolean isSound = pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
		boolean isVibrate = pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
		Bitmap bmpLargeIcon = BitmapFactory.decodeResource(a_Context.getResources(), R.drawable.ic_launcher);
		Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		int nSmallIcon = 0;
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
			nSmallIcon = R.drawable.ic_launcher;
		} else {
			nSmallIcon = R.drawable.ic_launcher_push;
		}
		NotificationCompat.Builder pushNotiBuilder = new NotificationCompat.Builder(a_Context)
									.setContentTitle(a_Context.getString(R.string.app_name))
									.setContentText(a_strMsg)
									.setSmallIcon(nSmallIcon)
									.setLargeIcon(bmpLargeIcon)
									.setTicker(a_strMsg)
									.setAutoCancel(true);
		
		if(isSound)
			pushNotiBuilder.setSound(notificationSound);
		if(isVibrate)
			pushNotiBuilder.setVibrate(new long[]{0L, 500L});
		
		if(intent != null)
			pushNotiBuilder.setContentIntent(pie);
		

		nm.cancel(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID);
		
		LAST_NOTIFICATION_TAG = LAST_NOTIFICATION_TAG_KICK;
		
		nm.notify(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID, pushNotiBuilder.build());
	}
	
	public static void buildRequestNotification(Context a_Context, String a_strMsg, int a_nBadge)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;
		
		NotificationManager nm = (NotificationManager)a_Context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		Intent intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_APPROVALREQUEST);
		
		PendingIntent pie= PendingIntent.getBroadcast(a_Context, 0, intent, PendingIntent.FLAG_ONE_SHOT);
				
		boolean isSound = pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
		boolean isVibrate = pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
		Bitmap bmpLargeIcon = BitmapFactory.decodeResource(a_Context.getResources(), R.drawable.ic_launcher);
		Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		int nSmallIcon = 0;
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
			nSmallIcon = R.drawable.ic_launcher;
		} else {
			nSmallIcon = R.drawable.ic_launcher_push;
		}
		NotificationCompat.Builder pushNotiBuilder = new NotificationCompat.Builder(a_Context)
									.setContentTitle(a_Context.getString(R.string.app_name))
									.setContentText(a_strMsg)
									.setSmallIcon(nSmallIcon)
									.setLargeIcon(bmpLargeIcon)
									.setTicker(a_strMsg)
									.setAutoCancel(true);
		
		if(isSound)
			pushNotiBuilder.setSound(notificationSound);
		if(isVibrate)
			pushNotiBuilder.setVibrate(new long[]{0L, 500L});
		
		if(intent != null)
			pushNotiBuilder.setContentIntent(pie);
		

		nm.cancel(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID);
		
		LAST_NOTIFICATION_TAG = LAST_NOTIFICATION_TAG_REQUEST;
		
		nm.notify(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID, pushNotiBuilder.build());
	}

	public static void buildSNSInviteNotification(Context a_Context, String a_strMsg)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;

		NotificationManager nm = (NotificationManager)a_Context.getSystemService(Context.NOTIFICATION_SERVICE);

		Intent intent = new Intent(PushBroadcastReceiver.ACTION_PUSH_SNS_INVITE);

		PendingIntent pie= PendingIntent.getBroadcast(a_Context, 0, intent, PendingIntent.FLAG_ONE_SHOT);

		boolean isSound = pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
		boolean isVibrate = pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
		Bitmap bmpLargeIcon = BitmapFactory.decodeResource(a_Context.getResources(), R.drawable.ic_launcher);
		Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		int nSmallIcon = 0;
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
			nSmallIcon = R.drawable.ic_launcher;
		} else {
			nSmallIcon = R.drawable.ic_launcher_push;
		}
		NotificationCompat.Builder pushNotiBuilder = new NotificationCompat.Builder(a_Context)
				.setContentTitle(a_Context.getString(R.string.app_name))
				.setContentText(a_strMsg)
				.setSmallIcon(nSmallIcon)
				.setLargeIcon(bmpLargeIcon)
				.setTicker(a_strMsg)
				.setAutoCancel(true);

		if(isSound)
			pushNotiBuilder.setSound(notificationSound);
		if(isVibrate)
			pushNotiBuilder.setVibrate(new long[]{0L, 500L});

		if(intent != null)
			pushNotiBuilder.setContentIntent(pie);


		nm.cancel(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID);

		LAST_NOTIFICATION_TAG = LST_NOTIFICATION_TAG_SNSINVITE;

		nm.notify(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID, pushNotiBuilder.build());
	}

	public static void buildSNSNotification(Context a_Context, String a_strMsg, int a_nGroupId, int a_nBoardId, int a_nReplyId)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		boolean isAlarm = pref.getBooleanPref(SharedPref.PREF_PUSH_RECEIVE_ALRAM, true);
		if(!isAlarm)
			return;
		
		NotificationManager nm = (NotificationManager)a_Context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		String strAction;
		if(a_nReplyId > 0)
			strAction = PushBroadcastReceiver.ACTION_PUSH_SNS_REPLY;
		else
			strAction = PushBroadcastReceiver.ACTION_PUSH_SNS_BOARD;
		
		CommonLog.e(PushController.class.getSimpleName(), "groupId: " + a_nGroupId);
		CommonLog.e(PushController.class.getSimpleName(), "boardId: " + a_nBoardId);
		CommonLog.e(PushController.class.getSimpleName(), "replyId: " + a_nReplyId);
		
		Intent intent = new Intent(strAction);
		intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSGROUPID, a_nGroupId);
		intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSBOARDID, a_nBoardId);
		if(a_nReplyId != 0)
			intent.putExtra(IntentKeyString.INTENT_KEY_PUSHBROADCAST_SNSREPLYID, a_nReplyId);
		
		PendingIntent pie= PendingIntent.getBroadcast(a_Context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
				
		boolean isSound = pref.getBooleanPref(SharedPref.PREF_ALRAM_SOUND, true);
		boolean isVibrate = pref.getBooleanPref(SharedPref.PREF_ALRAM_VIBRATE, true);
		Bitmap bmpLargeIcon = BitmapFactory.decodeResource(a_Context.getResources(), R.drawable.ic_launcher);
		Uri notificationSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		int nSmallIcon = 0;
		if(Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP){
			nSmallIcon = R.drawable.ic_launcher;
		} else {
			nSmallIcon = R.drawable.ic_launcher_push;
		}
		NotificationCompat.Builder pushNotiBuilder = new NotificationCompat.Builder(a_Context)
									.setContentTitle(a_Context.getString(R.string.app_name))
									.setContentText(a_strMsg)
									.setSmallIcon(nSmallIcon)
									.setLargeIcon(bmpLargeIcon)
									.setTicker(a_strMsg)
									.setAutoCancel(true);
		
		if(isSound)
			pushNotiBuilder.setSound(notificationSound);
		if(isVibrate)
			pushNotiBuilder.setVibrate(new long[]{0L, 500L});
		
		if(intent != null)
			pushNotiBuilder.setContentIntent(pie);
		

		nm.cancel(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID);
		
		//if(a_nReplyId > 0)
		//	LAST_NOTIFICATION_TAG = ""+a_nReplyId;
		//else
			LAST_NOTIFICATION_TAG = ""+a_nBoardId;
		
		nm.notify(LAST_NOTIFICATION_TAG, TTALK_NOTIFICATION_ID, pushNotiBuilder.build());
	}
	
	public static void showKickPopup(final Context a_Context, String a_strMessage, final String a_strRoomID)
	{
		Intent intent;

		intent = new Intent(a_Context, CommonPopupAct.class);
		intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BTNTYPE, CommonPopupBtnTypeInt.POP_BTNTYPE_YES);
		intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_TITLE, a_Context.getString(R.string.pop_error_title));
		intent.putExtra(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BODY, a_strMessage);
		intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID_KICK, a_strRoomID);
		a_Context.startActivity(intent);
	}
	
	private static String LAST_NOTIFICATION_TAG_KICK = "kick";
	private static String LAST_NOTIFICATION_TAG_REQUEST = "request";
	private static String LAST_NOTIFICATION_TAG_SNSBOARD = "snsboard";
	private static String LAST_NOTIFICATION_TAG_SNSREPLY = "snsreply";
	private static String LST_NOTIFICATION_TAG_SNSINVITE = "snsinvite";
	private static String LAST_NOTIFICATION_TAG = "";
	
	public static void cancelNotification(Context a_Context, String a_strTag)
	{
		NotificationManager nm = (NotificationManager)a_Context.getSystemService(Context.NOTIFICATION_SERVICE);
		nm.cancel(a_strTag, TTALK_NOTIFICATION_ID);
	}
	
	private static void startPushPopupScreenOffAct(Context a_Context, String a_strPushType, int a_nFriendNo, String a_strName, String a_strMsg, String a_strImgUrl, String a_strGid)
	{
		if(!NotificationManagerCompat.from(a_Context).areNotificationsEnabled()){
			CommonLog.e(PushController.class.getSimpleName(), "App setting alarm is off");
		} else {
			Intent intentPushPopup = new Intent(a_Context, PushPopupScreenOffAct.class);
			intentPushPopup.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
			intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_PUSHTYPE, a_strPushType);
			if (a_nFriendNo > -1)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_USERNO, a_nFriendNo);
			if (a_strName != null)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_NAME, a_strName);
			if (a_strMsg != null)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_MESSAGE, a_strMsg);
			if (a_strImgUrl != null)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_IMGURL, a_strImgUrl);
			if (a_strGid != null)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_GID, a_strGid);
			a_Context.startActivity(intentPushPopup);
		}
	}
	
	// SNS Push
	private static void startPushPopupScreenOffAct(Context a_Context, String a_strPushType, String a_strName, String a_strMsg, int a_nGroupId, int a_nBoardId, int a_nReplyId)
	{
		if(!NotificationManagerCompat.from(a_Context).areNotificationsEnabled()){
			CommonLog.e(PushController.class.getSimpleName(), "App setting alarm is off");
		} else {
			Intent intentPushPopup = new Intent(a_Context, PushPopupScreenOffAct.class);
			intentPushPopup.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
			intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_PUSHTYPE, a_strPushType);
			if (a_strName != null)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_NAME, a_strName);
			if (a_strMsg != null)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_MESSAGE, a_strMsg);
			intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSGROUPID, a_nGroupId);
			intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSBOARDID, a_nBoardId);
			if (a_nReplyId > -1)
				intentPushPopup.putExtra(IntentKeyString.INTENT_KEY_PUSHPOPUP_SNSREPLYID, a_nReplyId);

			a_Context.startActivity(intentPushPopup);
		}
	}
	
	private static void increasePushMessageIconBadge(Context a_Context)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
		pref.setIntegerPref(SharedPref.PREF_BADGE_COUNT, ++nBadgeCount);
		IconBadge.updateIconBadge(a_Context);
	}
	
	private static void increaseSNSPushIconBadge(Context a_Context)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, 0);
		pref.setIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, ++nBadgeCount);
		IconBadge.updateIconBadge(a_Context);
	}
	
	private static void insertSNSDB(Context a_Context, int a_nGroupId, int a_nBoardId, int a_nReplyId)
	{
		SNSAlarmData data = new SNSAlarmData();
		data.m_nBoardNo = a_nBoardId;
		data.m_nGroupId = a_nGroupId;
		if(a_nReplyId != 0)
			data.m_nReplyNo = a_nReplyId;
		
		data.m_strType = SNSAlarmData.ALARMTYPE_PUSH;
		
		Calendar calendar = Calendar.getInstance();
		
		int nYear = calendar.get(Calendar.YEAR);
		int nMonth = calendar.get(Calendar.MONTH) + 1;
		int nDay = calendar.get(Calendar.DAY_OF_MONTH);
		int nHour = calendar.get(Calendar.HOUR_OF_DAY);
		int nMinute = calendar.get(Calendar.MINUTE);
		int nSecond = calendar.get(Calendar.SECOND);
		String strDate = String.format("%04d%02d%02d%02d%02d%02d", nYear, nMonth, nDay, nHour, nMinute, nSecond);
		data.m_strCreateDate = strDate;
		data.m_strUpdateDate = strDate;
		data.m_isAlarmRead = false;
		data.m_isBoardRead = false;
		data.m_lnCreateMillisecond = System.currentTimeMillis();
		
		SNSGroupDBManager.insertSNSAlarm(a_Context, data);
	}
	
	private static void updateIconBadge(Context a_Context)
	{
		IconBadge.updateIconBadge(a_Context);
	}
}
