package com.gmp.rusk.service;

import android.content.Context;
import android.graphics.Bitmap;


import com.gmp.rusk.db.ChattingDBManager;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.Utils;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class XmppSendPacket extends XmppConnectionService {

	private final String SERVICE_NAME = "cork.com";
	private final String SERVICE_NAMEG = "groupchat.cork.com";
	private final String TMS_ALL = "/TMS_ALL";
	private final String TMS = "/TMS";
	private final String TAG = XmppConnectionService.class.getSimpleName();
	private XMPPConnection connection;
	private Context mContext;

	public XmppSendPacket(XMPPConnection superConnection, Context context) {
		// TODO Auto-generated constructor stub
		connection = superConnection;
		mContext = context;
	}

	// 개인 채팅 메세지 발송
	synchronized public void sendMessage(String strEditText,
			String strSendMessage, int nFriendUserNumber, String strPacketID) {

		if (strEditText.equals("") && strSendMessage.equals("")) {

		} else {

			Message sendMSG = new Message();
			if (!strSendMessage.equals("")) {
				sendMSG.setBody(Utils.escapeXMLChars(strSendMessage));

			} else {
				sendMSG.setBody(Utils.escapeXMLChars(strEditText));
			}

			sendMSG.setTo(Integer.toString(nFriendUserNumber) + "@"
					+ SERVICE_NAME + TMS_ALL);
			sendMSG.setFrom(Integer.toString(App.m_MyUserInfo.m_nUserNo) + "@"
					+ SERVICE_NAME);
			sendMSG.setPacketID(strPacketID);
			sendMSG.addExtension(new PacketExtension() {

				@Override
				public String toXML() {
					// TODO Auto-generated method stub
					return "<request xmlns='urn:xmpp:receipts'/>";
				}

				@Override
				public String getElementName() {
					// TODO Auto-generated method stub
					return null;
				}

				@Override
				public String getNamespace() {
					// TODO Auto-generated method stub
					return null;
				}

			});
			CommonLog.e(this, "최초 전송 : " + sendMSG.toXML());
			if (connection.isConnected())
				connection.sendPacket(sendMSG);
			else {
				Queue<Packet> temp = new LinkedList<Packet>();
				boolean isSamePacket = false;
				while (true) {
					if (m_queuePacket.peek() != null) {
						Packet tempPacket = m_queuePacket.poll();
						if (tempPacket.toXML().equals(sendMSG.toXML())) {
							isSamePacket = true;
							CommonLog.e(TAG, "Same Packet");
						}
						temp.add(tempPacket);
					} else {
						break;
					}
				}
				if (!isSamePacket) {
					temp.add(sendMSG);
				}
				m_queuePacket = temp;
			}

		}
	}

	// 그룹 채팅 메세지 발송
	synchronized public void sendMessageGroup(final String strEditText,
			final String strSendMessage, final String strRoomID,
			final String strPacketID) {

		if (strEditText.equals("") && strSendMessage.equals("")) {

		} else {

			Packet msgPacket = new Packet() {

				@Override
				public String toXML() {
					// TODO Auto-generated method stub

					StringBuilder buf = new StringBuilder();
					buf.append("<message")
							.append(" from=\"")
							.append(Integer
									.toString(App.m_MyUserInfo.m_nUserNo))
							.append("@").append(SERVICE_NAME);
					buf.append("\" id=\"").append(strPacketID);
					buf.append("\" to=\"").append(strRoomID)
							.append("@groupchat." + SERVICE_NAME).append("\">");
					if (!strSendMessage.equals("")) {
						buf.append("<body>")
								.append(Utils.escapeXMLChars(strSendMessage))
								.append("</body>");
					} else {
						buf.append("<body>")
								.append(Utils.escapeXMLChars(strEditText))
								.append("</body>");
					}
					buf.append("<request xmlns='urn:xmpp:receipts'/>");
					buf.append("</message>");

					return buf.toString();
				}
			};
			CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());

			if (connection.isConnected())
				connection.sendPacket(msgPacket);
			else {

				Queue<Packet> temp = new LinkedList<Packet>();
				boolean isSamePacket = false;
				while (true) {
					if (m_queuePacket.peek() != null) {
						Packet tempPacket = m_queuePacket.poll();
						if (tempPacket.toXML().equals(msgPacket.toXML())) {
							isSamePacket = true;
							CommonLog.e(TAG, "Same Packet");
						}
						temp.add(tempPacket);
					} else {
						break;
					}
				}
				if (!isSamePacket) {
					temp.add(msgPacket);
				}
				m_queuePacket = temp;
			}
		}
	}

	// 개인 긴급 메세지 발송
	synchronized public void sendUrgentMessage(final String strEditText,
			final int nFriendUserNumber, final String strPacketID) {
		Packet sendUrgentPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				// byte[] data;
				StringBuilder buf = new StringBuilder();
				buf.append("<message")
						.append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo)
								+ "@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(nFriendUserNumber)
						.append("@" + SERVICE_NAME + TMS_ALL).append("\">");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("<info xmlns='urn:xmpp:urgent'/>");
				buf.append("<body>").append(Utils.escapeXMLChars(strEditText))
						.append("</body>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + sendUrgentPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(sendUrgentPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendUrgentPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendUrgentPacket);
			}
			m_queuePacket = temp;
		}

	}

	// 그룹 긴급 메세지 발송
	synchronized public void sendUrgentMessageGroup(final String strEditText,
			final String strRoomID, final String strPacketID) {

		Packet sendUrgentPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@").append(SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomID)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<body>").append(Utils.escapeXMLChars(strEditText))
						.append("</body>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("<info xmlns='urn:xmpp:urgent'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		if (connection.isConnected())
			connection.sendPacket(sendUrgentPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendUrgentPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendUrgentPacket);
			}
			m_queuePacket = temp;
		}

	}
	//개인 채팅 이모티콘 전송
	synchronized public void sendEmoticon(String strEditText,
										  final String emoticonUrl, int nFriendUserNumber, String strPacketID) {

		Message sendMSG = new Message();

		if(!strEditText.trim().equals(""))
			sendMSG.setBody(Utils.escapeXMLChars(strEditText));
		sendMSG.setTo(Integer.toString(nFriendUserNumber) + "@"
				+ SERVICE_NAME + TMS_ALL);
		sendMSG.setFrom(Integer.toString(App.m_MyUserInfo.m_nUserNo) + "@"
				+ SERVICE_NAME + TMS_ALL);
		sendMSG.setPacketID(strPacketID);
		sendMSG.addExtension(new PacketExtension() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				return "<info xmlns='urn:cork:emoticon'><name>"+emoticonUrl+"</name></info><request xmlns='urn:xmpp:receipts'/>";
			}

			@Override
			public String getElementName() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getNamespace() {
				// TODO Auto-generated method stub
				return null;
			}

		});
		CommonLog.e(this, "최초 전송 이모티콘 : " + sendMSG.toXML());
		if (connection.isConnected())
			connection.sendPacket(sendMSG);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendMSG.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendMSG);
			}
			m_queuePacket = temp;
		}

	}
	//그룹 채팅 이모티콘 전송
	synchronized public void sendEmoticonGroup(String strEditText,
										  final String emoticonUrl, String strRoomID, String strPacketID) {

		Message sendMSG = new Message();

		if(!strEditText.equals(""))
			sendMSG.setBody(Utils.escapeXMLChars(strEditText));
		sendMSG.setTo(strRoomID + "@"
				+ SERVICE_NAMEG + TMS_ALL);
		sendMSG.setFrom(Integer.toString(App.m_MyUserInfo.m_nUserNo) + "@"
				+ SERVICE_NAMEG + TMS_ALL);
		sendMSG.setPacketID(strPacketID);
		sendMSG.addExtension(new PacketExtension() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				return "<info xmlns='urn:cork:emoticon'><name>"+emoticonUrl+"</name></info><request xmlns='urn:xmpp:receipts'/>";
			}

			@Override
			public String getElementName() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getNamespace() {
				// TODO Auto-generated method stub
				return null;
			}

		});
		CommonLog.e(this, "최초 전송 이모티콘 : " + sendMSG.toXML());
		if (connection.isConnected())
			connection.sendPacket(sendMSG);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendMSG.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendMSG);
			}
			m_queuePacket = temp;
		}

	}
	// 개인 채팅 메세지 읽음 전달
	synchronized public void sendReadMessage(final Packet message) {

		final String strPacketID = Long.toString(System.currentTimeMillis())
				+ "_" + App.m_MyUserInfo.m_nUserNo;
		Message sendMSGRead = new Message();
		sendMSGRead.setPacketID(strPacketID);
		sendMSGRead.setTo(Integer.parseInt(message.getFrom().split("@")[0])
				+ "@" + SERVICE_NAME + TMS_ALL);
		sendMSGRead.setFrom(Integer.toString(App.m_MyUserInfo.m_nUserNo) + "@"
				+ SERVICE_NAME);
		sendMSGRead.addExtension(new PacketExtension() {

			@Override
			public String toXML() {

				// TODO Auto-generated method stub
				return "<read xmlns='urn:xmpp:notify'><ack id='"
						+ message.getPacketID()
						+ "'/></read><request xmlns='urn:xmpp:receipts'/>";
			}

			@Override
			public String getElementName() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public String getNamespace() {
				// TODO Auto-generated method stub
				return null;
			}

		});

		ChattingDBManager chattingDBMng3 = new ChattingDBManager(mContext);
		chattingDBMng3.openWritable(message.getFrom().split("@")[0]);
		int nDBResult = chattingDBMng3.updateReadMessage(message.getPacketID(),
				true);
		chattingDBMng3.close();

		if (nDBResult != -1) {
			if (connection.isConnected())
				connection.sendPacket(sendMSGRead);
			else {
				Queue<Packet> temp = new LinkedList<Packet>();
				boolean isSamePacket = false;
				while (true) {
					if (m_queuePacket.peek() != null) {
						Packet tempPacket = m_queuePacket.poll();
						if (tempPacket.toXML().equals(sendMSGRead.toXML())) {
							isSamePacket = true;
							CommonLog.e(TAG, "Same Packet");
						}
						temp.add(tempPacket);
					} else {
						break;
					}
				}
				if (!isSamePacket) {
					temp.add(sendMSGRead);
				}
				m_queuePacket = temp;
			}
			CommonLog.e(TAG, "Send Read Message: " + sendMSGRead);
		}
	}

	// 그룹 채팅 메세지 읽음 전달
	synchronized public void sendReadMessageGroup(final Packet message) {

		final String strPacketID = Long.toString(System.currentTimeMillis())
				+ "_" + App.m_MyUserInfo.m_nUserNo;
		Packet readPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@").append(SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(message.getFrom().split("@")[0])
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<read xmlns='urn:xmpp:notify'>")
						.append("<ack id='").append(message.getPacketID())
						.append("'/></read>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "Read Message : " + readPacket);

		if (connection.isConnected())
			connection.sendPacket(readPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(readPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(readPacket);
			}
			m_queuePacket = temp;
		}

	}

	// 개인 클라우드 전송

	synchronized public void sendCloud(final long lTime,
			final String strFileName, final String strDocId, final String strUrl,
			final int nFriendUserNumber, final String strCreatTime) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(nFriendUserNumber)
						.append("@" + SERVICE_NAME + TMS_ALL).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='sec' isVdi='false'>");
				buf.append("<fileName>").append(strFileName)
						.append("</fileName>");
				buf.append("<docId>").append(strDocId).append("</docId>");
				buf.append("<url>").append(strUrl).append("</url>");
				if (strCreatTime != null) {
					buf.append("<createTime>").append(strCreatTime)
							.append("</createTime>");
				}
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		if (connection.isConnected())
			connection.sendPacket(sendFilePacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(TAG, "SendFile : " + sendFilePacket);
	}

	// 개인 파일 전송
	synchronized public void sendFile(final long lTime,
			final String strFileName, final String strUrl, final String strPreviewUrl,
			final int nFriendUserNumber, final String strCreatTime,
			final boolean isContacts, final String strVdi) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(nFriendUserNumber)
						.append("@" + SERVICE_NAME + TMS_ALL).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='normal' isVdi='").append(strVdi).append("'>");
				buf.append("<fileName>").append(strFileName)
						.append("</fileName>");
				if (strFileName.equals("")) {
					buf.append("<mimetype>V</mimetype>");
				} else if (!strFileName.equals("") && isContacts) {
					buf.append("<mimetype>C</mimetype>");
				} else {
					buf.append("<mimetype>N</mimetype>");
				}
				if(!strPreviewUrl.equals("")){
					buf.append("<thumb>").append(strPreviewUrl).append("</thumb>");
				}
				buf.append("<url>").append(strUrl).append("</url>");
				if (strCreatTime != null) {
					buf.append("<createTime>").append(strCreatTime)
							.append("</createTime>");
				}
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		if (connection.isConnected())
			connection.sendPacket(sendFilePacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(TAG, "SendFile : " + sendFilePacket);
	}

	// 그룹 클라우드 전송
	synchronized public void sendCloudGroup(final long lTime,
			final String strFileName, final String strDocId, final String strUrl,
			final String strRoodID, final String strCreatTime) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoodID)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='sec' isVdi='false'>");
				buf.append("<fileName>").append(strFileName)
						.append("</fileName>");
				buf.append("<docId>").append(strDocId).append("</docId>");
				buf.append("<url>").append(strUrl).append("</url>");
				if (strCreatTime != null) {
					buf.append("<createTime>").append(strCreatTime)
							.append("</createTime>");
				}
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		if (connection.isConnected())
			connection.sendPacket(sendFilePacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(TAG, "SendFile : " + sendFilePacket);
	}

	// 그룹 파일 전송
	synchronized public void sendFileGroup(final long lTime,
			final String strFileName, final String strUrl, final String strPreviewUrl,
			final String strRoodID, final String strCreatTime,
			final boolean isContacts, final String strVdi) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoodID)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='normal' isVdi='").append(strVdi).append("'>");
				buf.append("<fileName>").append(strFileName)
						.append("</fileName>");
				if (strFileName.equals("")) {
					buf.append("<mimetype>V</mimetype>");
				} else if (!strFileName.equals("") && isContacts) {
					buf.append("<mimetype>C</mimetype>");
				} else {
					buf.append("<mimetype>N</mimetype>");
				}
				if(!strPreviewUrl.equals("")){
					buf.append("<thumb>").append(strPreviewUrl).append("</thumb>");
				}
				buf.append("<url>").append(strUrl).append("</url>");
				if (strCreatTime != null) {
					buf.append("<createTime>").append(strCreatTime)
							.append("</createTime>");
				}
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		if (connection.isConnected())
			connection.sendPacket(sendFilePacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}

	}

	// 개인 이미지 전송
	synchronized public void sendImage(final long lTime, final Bitmap bitamp,
			final String strUrl, final String strPreviewUrl,
			final int nFriendUserNumber) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(nFriendUserNumber)
						.append("@" + SERVICE_NAME + TMS_ALL).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='normal' isVdi='false'>");
				buf.append("<mimetype>I</mimetype>");
				buf.append("<url>").append(strUrl).append("</url>");
				buf.append("<width>").append(bitamp.getWidth())
						.append("</width>");
				buf.append("<height>").append(bitamp.getHeight())
						.append("</height>");
				buf.append("<thumb>").append(strPreviewUrl).append("</thumb>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		if (!connection.isConnected()) {
			CommonLog.e(TAG, "Send Image : Not Connected");
		}

		if (connection.isConnected())
			connection.sendPacket(sendFilePacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(this, "SendFile : " + sendFilePacket);
	}

	// 개인 이미지 전달
	synchronized public void sendImageOther(final long lTime, final int nWidth,
			final int nHeight, final String strUrl, final String strPreviewUrl,
			final int nFriendUserNumber) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(nFriendUserNumber)
						.append("@" + SERVICE_NAME + TMS_ALL).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='normal' isVdi='false'>");
				buf.append("<mimetype>I</mimetype>");
				buf.append("<url>").append(strUrl).append("</url>");
				buf.append("<width>").append(nWidth).append("</width>");
				buf.append("<height>").append(nHeight).append("</height>");
				buf.append("<thumb>").append(strPreviewUrl).append("</thumb>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		if (!connection.isConnected()) {
			CommonLog.e(TAG, "Send Image : Not Connected");
		}

		if (connection.isConnected())
			connection.sendPacket(sendFilePacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(this, "SendFile : " + sendFilePacket);
	}

	// 그룹 이미지 전송
	synchronized public void sendImageGroup(final long lTime,
			final Bitmap bitamp, final String strUrl,
			final String strPreviewUrl, final String strRoomID) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomID)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='normal' isVdi='false'>");
				buf.append("<mimetype>I</mimetype>");
				buf.append("<url>").append(strUrl).append("</url>");
				buf.append("<width>").append(bitamp.getWidth())
						.append("</width>");
				buf.append("<height>").append(bitamp.getHeight())
						.append("</height>");
				buf.append("<thumb>").append(strPreviewUrl).append("</thumb>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		if (connection.isConnected()) {
			CommonLog.e(TAG, "Send Packet Test : Send Image");
			connection.sendPacket(sendFilePacket);
		} else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(this, "SendImage : " + sendFilePacket);
	}

	// 그룹 이미지 전달
	synchronized public void sendImageGroupOther(final long lTime,
			final int nWidth, final int nHeight, final String strUrl,
			final String strPreviewUrl, final String strRoomID) {
		Packet sendFilePacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(lTime) + "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomID)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<info xmlns='urn:xmpp:file' type='normal' isVdi='false'>");
				buf.append("<mimetype>I</mimetype>");
				buf.append("<url>").append(strUrl).append("</url>");
				buf.append("<width>").append(nWidth).append("</width>");
				buf.append("<height>").append(nHeight).append("</height>");
				buf.append("<thumb>").append(strPreviewUrl).append("</thumb>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		if (connection.isConnected()) {
			CommonLog.e(TAG, "Send Packet Test : Send Image");
			connection.sendPacket(sendFilePacket);
		} else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(sendFilePacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(sendFilePacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(this, "SendImage : " + sendFilePacket);
	}

	// 개인 채팅방 진입시 메세지 읽음 처리
	synchronized public void setReadRoomMessage(
			final ArrayList<String> arrNoReadMessageID, final String strRoomId) {
		// CommonLog.e(this, "Start Send Read Message");
		StringBuilder ackIDs = new StringBuilder();

		for (String strMessageID : arrNoReadMessageID) {
			ackIDs.append("<ack id='").append(strMessageID).append("'/>");
		}

		final StringBuilder readAckIDs = ackIDs;

		Packet readPacket = new Packet() {
			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				CommonLog.e(TAG, "갯수 : " + arrNoReadMessageID.size());
				final String strPacketID = Long.toString(System
						.currentTimeMillis())
						+ "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomId + "@" + SERVICE_NAME + TMS_ALL)
						.append("\">");
				buf.append("<read xmlns='urn:xmpp:notify'>");
				buf.append(readAckIDs);
				buf.append("</read>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		if (connection.isConnected())
			connection.sendPacket(readPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(readPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(readPacket);
			}
			m_queuePacket = temp;
		}

	}

	// 그룹 채팅방 진입시 메세지 읽음 처리
	synchronized public void setReadRoomMessageGroup(
			final ArrayList<String> arrNoReadMessageID, final String strRoomId) {

		StringBuilder ackIDs = new StringBuilder();
		for (String strMessageID : arrNoReadMessageID) {
			ackIDs.append("<ack id='").append(strMessageID).append("'/>");
		}
		final StringBuilder readAckIDs = ackIDs;
		// 왜 packet으로 들어가면 arrNoReadMessageID 갯수가 0개가 되지?
		Packet readPacket = new Packet() {
			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				CommonLog.e(TAG, "갯수 : " + arrNoReadMessageID.size());
				String strPacketID = Long.toString(System.currentTimeMillis())
						+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomId)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<read xmlns='urn:xmpp:notify'>");
				buf.append(readAckIDs);
				buf.append("</read>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};

		CommonLog.e(TAG, "Send Read!!!!!!!!!!!!!");
		if (connection.isConnected())
			connection.sendPacket(readPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(readPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(readPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 개인 방 초기화
	synchronized public void clearRoom(final int nFriendUserNumber) {
		Packet clearPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(System
						.currentTimeMillis())
						+ "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(nFriendUserNumber)
						.append("@" + SERVICE_NAME + TMS_ALL).append("\">");
				buf.append("<info xmlns='urn:xmpp:clear'/>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		if (connection.isConnected())
			connection.sendPacket(clearPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(clearPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(clearPacket);
			}
			m_queuePacket = temp;
		}

	}

	// 그룹 방 초기화

	synchronized public void clearRoom(final String strRoomID) {
		Packet clearPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(System
						.currentTimeMillis())
						+ "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomID)
						.append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<info xmlns='urn:xmpp:clear'/>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		if (connection.isConnected())
			connection.sendPacket(clearPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(clearPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(clearPacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(this, "최초 전송 : " + clearPacket);
	}

	// 그룹 채팅 방 생성
	synchronized public void makeRoom(final ArrayList<Integer> arrRoomUser) {
		final String strPacketID = Long.toString(System.currentTimeMillis())
				+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub

				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(App.m_MyUserInfo.m_nUserNo + "@cork.com");
				buf.append("\" to=\"").append(
						strPacketID + "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:open\">");
				for (int i = 0; i < arrRoomUser.size(); i++) {
					buf.append("<user>")
							.append(Integer.toString(arrRoomUser.get(i)))
							.append("</user>");
				}
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "Make Room Packet : " + msgPacket);
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}

	}

	// 모임 채팅 방 생성
	synchronized public void makeSNSRoom(final ArrayList<Integer> arrRoomUser,
			final int nGroupId, final String strGrounpName,final String strImageURL, final int nImageIndex) {
		final String strPacketID = Long.toString(System.currentTimeMillis())
				+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub

				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(App.m_MyUserInfo.m_nUserNo + "@cork.com");
				buf.append("\" to=\"").append(
						strPacketID + "_" + nGroupId
								+ "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:open\">");
				buf.append("<roomname>").append(Utils.escapeXMLChars(strGrounpName))
						.append("</roomname>");
				buf.append("<image>");
				if(nImageIndex == 0)
					buf.append(strImageURL);
				else
					buf.append(nImageIndex);
				buf.append("</image>");
				for (int i = 0; i < arrRoomUser.size(); i++) {
					buf.append("<user>")
							.append(Integer.toString(arrRoomUser.get(i)))
							.append("</user>");
				}
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "Make Room Packet : " + msgPacket);
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}

	}

	// 모임 방 셀프 초대
	synchronized public void inviteSelf(final String strGroupID) {
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				String strPacketID = Long.toString(System.currentTimeMillis())
						+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(
						strGroupID + "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:selfinvite\">");
				buf.append("<groupid>").append(strGroupID).append("</groupid>");
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected()) {
			connection.sendPacket(msgPacket);
			CommonLog.e(this, "성공");
		} else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 방장 위임
	synchronized public void passOwner(final int nUserID, final String strRoomID) {
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				String strPacketID = Long.toString(System.currentTimeMillis())
						+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(
						strRoomID + "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:owner\">");
				buf.append("<user>").append(nUserID).append("</user>");
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		CommonLog.e(this, "아이디 : " + nUserID);
		if (connection.isConnected()) {
			connection.sendPacket(msgPacket);
			CommonLog.e(this, "성공");
		} else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 강퇴
	synchronized public void exitOther(final ArrayList<Integer> arrKickUser,
			final String strRoomID) {
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				String strPacketID = Long.toString(System.currentTimeMillis())
						+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(
						strRoomID + "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:kick\">");
				for (int nKickUser : arrKickUser) {
					buf.append("<user>").append(nKickUser).append("</user>");
				}
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	synchronized public void inviteOther(ArrayList<Integer> arrUserData,
			final String strRoomID) {
		final ArrayList<Integer> arrUser = arrUserData;
		final String strPacketID = Long.toString(System.currentTimeMillis())
				+ "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(
						strRoomID + "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:invite\">");
				// 임시
				for (int i = 0; i < arrUser.size(); i++) {
					buf.append("<user>")
							.append(Integer.toString(arrUser.get(i)))
							.append("</user>");
				}
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};

		if (connection.isConnected()) {

			connection.sendPacket(msgPacket);
		} else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
	}

	// 그룹 방 나가기
	synchronized public void exitRoom(final String strRoomID) {
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				final String strPacketID = Long.toString(System
						.currentTimeMillis())
						+ "_"
						+ Integer.toString(App.m_MyUserInfo.m_nUserNo);
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"")
						.append(Integer.toString(App.m_MyUserInfo.m_nUserNo))
						.append("@" + SERVICE_NAME);
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(
						strRoomID + "@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:quit\"/>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	synchronized public void requestGroupChats(){
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"get");
				buf.append("\" to=\"").append("groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:groupchats\"/>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 진입 시 방이 없을때 방 목록 요청
	synchronized public void requestRoomList() {
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"get");
				buf.append("\" to=\"").append("groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:rooms\"/>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 전달 받은 방 ID로 유저 목록 받음
	synchronized public void requestUserList(final String strRoomID) {
		final String strRealRoomId = strRoomID.split("\\|")[0];
		Packet msgPacket = new Packet() {

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"get");
				buf.append("\" to=\"").append(strRealRoomId)
						.append("@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:users\"/>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 그룹방 알람 on/off
	synchronized public void requestOnOff(final String onoff,
			final String strRoomID) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long
					.toString(System.currentTimeMillis())
					+ "_"
					+ Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set");
				buf.append("\" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" to=\"").append(strRoomID).append("@groupchat.cork.com\">");
				buf.append("<query xmlns=\"jabber:iq:alarm\">");
				buf.append("<").append(onoff).append("/>");
				buf.append("</query>");
				buf.append("</iq>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 친구 추가
	synchronized public void addBuddy(final String strUser) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
				buf.append("<info xmlns='urn:utalk:sync' type='buddyAdd'>");
				buf.append("<user>").append(strUser).append("</user>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 친구 삭제
	synchronized public void delBuddy(final ArrayList<String> arrUser) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
				buf.append("<info xmlns='urn:utalk:sync' type='buddyDel'>");
				for (String user : arrUser) {
					buf.append("<user>").append(user).append("</user>");
				}
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}
	// 채팅방 이름 변경 서버 저장용
	synchronized public void changeRoomTitle(final String strRoomId, final String strRoomName) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub

				StringBuilder buf = new StringBuilder();
				buf.append("<iq type=\"set\"").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(strRoomId).append("@groupchat." + SERVICE_NAME).append("\">");
				buf.append("<query xmlns=\"jabber:iq:roomname\">");
				buf.append("<roomname>").append(Utils.escapeXMLChars(strRoomName)).append("</roomname>");
				buf.append("</query>");
				buf.append("</iq>");
				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 채팅방 이름 변경 PC연동
	synchronized public void changeRoomNamePCsync(final String strRoomId, final String strRoomName) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
				buf.append("<info xmlns='urn:utalk:sync' type='chatNameModify'>");
				buf.append("<jid>").append(strRoomId).append("</jid>");
				buf.append("<newName>").append(Utils.escapeXMLChars(strRoomName)).append("</newName>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 모임 즐겨찾기 추가
	synchronized public void addGroupFavorite(final String strGroupId) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
				buf.append("<info xmlns='urn:utalk:sync' type='groupFavoriteAdd'>");
				buf.append("<groupId>").append(strGroupId).append("</groupId>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}

	// 모임 즐겨찾기 제거
	synchronized public void delGroupFavorite(final String strGroupId) {
		Packet msgPacket = new Packet() {
			final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

			@Override
			public String toXML() {
				// TODO Auto-generated method stub
				StringBuilder buf = new StringBuilder();
				buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
				buf.append("\" id=\"").append(strPacketID);
				buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
				buf.append("<info xmlns='urn:utalk:sync' type='groupFavoriteDel'>");
				buf.append("<groupId>").append(strGroupId).append("</groupId>");
				buf.append("</info>");
				buf.append("<request xmlns='urn:xmpp:receipts'/>");
				buf.append("</message>");

				return buf.toString();
			}
		};
		CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
		if (connection.isConnected())
			connection.sendPacket(msgPacket);
		else {
			Queue<Packet> temp = new LinkedList<Packet>();
			boolean isSamePacket = false;
			while (true) {
				if (m_queuePacket.peek() != null) {
					Packet tempPacket = m_queuePacket.poll();
					if (tempPacket.toXML().equals(msgPacket.toXML())) {
						isSamePacket = true;
						CommonLog.e(TAG, "Same Packet");
					}
					temp.add(tempPacket);
				} else {
					break;
				}
			}
			if (!isSamePacket) {
				temp.add(msgPacket);
			}
			m_queuePacket = temp;
		}
	}
	
	// 대화방 즐겨찾기 추가
		synchronized public void addChatFavorite(final String strRoomId) {
			Packet msgPacket = new Packet() {
				final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

				@Override
				public String toXML() {
					// TODO Auto-generated method stub
					StringBuilder buf = new StringBuilder();
					buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
					buf.append("\" id=\"").append(strPacketID);
					buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
					buf.append("<info xmlns='urn:utalk:sync' type='chatFavoriteAdd'>");
					buf.append("<jid>").append(strRoomId).append("</jid>");
					buf.append("</info>");
					buf.append("<request xmlns='urn:xmpp:receipts'/>");
					buf.append("</message>");

					return buf.toString();
				}
			};
			CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
			if (connection.isConnected())
				connection.sendPacket(msgPacket);
			else {
				Queue<Packet> temp = new LinkedList<Packet>();
				boolean isSamePacket = false;
				while (true) {
					if (m_queuePacket.peek() != null) {
						Packet tempPacket = m_queuePacket.poll();
						if (tempPacket.toXML().equals(msgPacket.toXML())) {
							isSamePacket = true;
							CommonLog.e(TAG, "Same Packet");
						}
						temp.add(tempPacket);
					} else {
						break;
					}
				}
				if (!isSamePacket) {
					temp.add(msgPacket);
				}
				m_queuePacket = temp;
			}
		}
		// 대화방 즐겨찾기 제거
		synchronized public void delChatFavorite(final String strRoomId) {
			Packet msgPacket = new Packet() {
				final String strPacketID = Long.toString(System.currentTimeMillis()) + "_" + Integer.toString(App.m_MyUserInfo.m_nUserNo);

				@Override
				public String toXML() {
					// TODO Auto-generated method stub
					StringBuilder buf = new StringBuilder();
					buf.append("<message").append(" from=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS");
					buf.append("\" id=\"").append(strPacketID);
					buf.append("\" to=\"").append(Integer.toString(App.m_MyUserInfo.m_nUserNo)).append("@" + SERVICE_NAME + "/TMS_PC").append("\">");
					buf.append("<info xmlns='urn:utalk:sync' type='chatFavoriteDel'>");
					buf.append("<jid>").append(strRoomId).append("</jid>");
					buf.append("</info>");
					buf.append("<request xmlns='urn:xmpp:receipts'/>");
					buf.append("</message>");

					return buf.toString();
				}
			};
			CommonLog.e(this, "최초 전송 : " + msgPacket.toXML());
			if (connection.isConnected())
				connection.sendPacket(msgPacket);
			else {
				Queue<Packet> temp = new LinkedList<Packet>();
				boolean isSamePacket = false;
				while (true) {
					if (m_queuePacket.peek() != null) {
						Packet tempPacket = m_queuePacket.poll();
						if (tempPacket.toXML().equals(msgPacket.toXML())) {
							isSamePacket = true;
							CommonLog.e(TAG, "Same Packet");
						}
						temp.add(tempPacket);
					} else {
						break;
					}
				}
				if (!isSamePacket) {
					temp.add(msgPacket);
				}
				m_queuePacket = temp;
			}
		}
}
