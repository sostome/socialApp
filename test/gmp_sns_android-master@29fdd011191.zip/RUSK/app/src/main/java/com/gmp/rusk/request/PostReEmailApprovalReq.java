package com.gmp.rusk.request;


import com.gmp.rusk.utils.CommonLog;

import org.json.JSONObject;

/**
 *	@author kch
 *			파트너 본인확인 이메일전송
 *			method : get
 */

public class PostReEmailApprovalReq extends Req{

	private String APINAME = "partner";
	private String AUTHENTIFICATION = "false";
	private final String METHOD = "POST";

	private final String JSON_USERID = "userId";


	public PostReEmailApprovalReq()
	{
		APINAME = APINAME  + "/email-confirmation";
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put(JSON_USERID, App.m_PartnerID);

			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PostGMPAuthReq.class.getSimpleName(), "" + e.toString());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
