package com.gmp.rusk.response;

import com.gmp.rusk.datamodel.ChannelCommentData;
import com.gmp.rusk.datamodel.ChannelThreadData;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-09.
 */

public abstract interface ChannelCommentResObject {

    public final String JSON_COMMENTS = "comments";
    public final String JSON_COMMENTNO = "commentNo";
    //public final String JSON_USERNO = "userNo";
    //public final String JSON_BODY = "body";
    //public final String JSON_CREATEDDATE = "createDate";
    //public final String JSON_UPDATEDDATE = "updatedDate";
    //public final String JSON_LIKECOUNT = "likeCount";
    //public final String JOSN_LIKED = "liked";

    public void parseChannelCommentData();
    public ArrayList<ChannelCommentData> getChannelCommentData();
}
