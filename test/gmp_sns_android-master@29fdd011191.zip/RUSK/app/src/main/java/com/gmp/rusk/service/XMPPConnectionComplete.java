package com.gmp.rusk.service;

public interface XMPPConnectionComplete {
	public void onConnectionComplete();
}
