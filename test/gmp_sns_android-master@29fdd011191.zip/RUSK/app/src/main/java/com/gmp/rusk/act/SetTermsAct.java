package com.gmp.rusk.act;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.GetTermTextReq;
import com.gmp.rusk.response.GetTermTextRes;
import com.gmp.rusk.utils.AppSetting;

/**
 * Created by kang on 2017-09-18.
 */

public class SetTermsAct extends Activity {

    CommonPopup m_Popup = null;
    private ProgressDlg m_Progress = null;

    @Override
    protected void onCreate(Bundle arg0) {
        // TODO Auto-generated method stub
        super.onCreate(arg0);
        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_set_terms);

        init();
    }

    private void init(){
        ImageView ivCancel = (ImageView) findViewById(R.id.btn_cancel);
        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        final TextView tvTerm = (TextView) findViewById(R.id.tv_term_text);
        tvTerm.setMovementMethod(new ScrollingMovementMethod());

        GetTermTextReq req = new GetTermTextReq();
        WebAPI webApi = new WebAPI(this);
        webApi.request(req, new WebListener() {
            @Override
            public void onPreRequest() {

            }

            @Override
            public void onNetworkError(int nErrorCode, String strMessage) {

            }

            @Override
            public void onPostRequest(String a_strData) {
                GetTermTextRes res = new GetTermTextRes(a_strData);
                tvTerm.setText(res.getTermText());
            }
        });
    }
}