package com.gmp.rusk.act;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.gmp.rusk.MyApp;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;

import java.util.List;

/**
 * Created by K on 2017-11-09.
 */

public class ExternalLinkAct extends Activity{

    MyApp App = MyApp.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent;

        App.m_isOtherApp = true;
        if(App.m_EntryData != null && App.m_MyUserInfo != null){
            intent = new Intent(this, MainTabAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        } else {
            intent = new Intent(this, IntroAct.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        }
        finish();
    }
}
