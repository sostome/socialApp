package com.gmp.rusk.request;

import org.json.JSONObject;


import com.gmp.rusk.utils.CommonLog;

/**
 *	@author dym
 *			모임 설정
 *			method : put
 */

public class PutGroupSettingReq extends Req{
	
	private String APINAME = "channel";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";

	private final String JSON_EVERYALARM		= "everyNotification";
	private final String JSON_BOARDALARM		= "threadNotification";
	private final String JSON_REPLYALARM	 	= "commentNotification";

	private Boolean m_isEveryAlarm = null;
	private Boolean m_isBoardAlarm = null;
	private Boolean m_isReplyAlarm = null;
	
	public PutGroupSettingReq(Integer a_nChannelNo, Boolean a_isBoardAlarm, Boolean a_isReplyAlarm, int a_nUserNo)
	{
		APINAME = APINAME +"/"+a_nChannelNo+"/member/"+a_nUserNo+"/configuration";

		m_isBoardAlarm = a_isBoardAlarm;
		m_isReplyAlarm = a_isReplyAlarm;
	}

	//메시지, 채널 푸시 포함 모든 푸시 차단이 everyAlarm
	public PutGroupSettingReq(Integer a_nChannelNo, Boolean a_isEveryAlarm, Boolean a_isBoardAlarm, Boolean a_isReplyAlarm, int a_nUserNo)
	{
		APINAME = APINAME +"/"+a_nChannelNo+"/member/"+a_nUserNo+"/configuration";

		m_isEveryAlarm = a_isEveryAlarm;
		m_isBoardAlarm = a_isBoardAlarm;
		m_isReplyAlarm = a_isReplyAlarm;
	}

	public String getAPIName()
	{
		return APINAME;
	}

	public String getMethod()
	{
		return METHOD;
	}
	
	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject();
			if(m_isEveryAlarm != null)
				jsonObj.put(JSON_EVERYALARM, m_isEveryAlarm);
			if(m_isBoardAlarm != null)
				jsonObj.put(JSON_BOARDALARM, m_isBoardAlarm);
			if(m_isReplyAlarm != null)
				jsonObj.put(JSON_REPLYALARM, m_isReplyAlarm);
			
			return jsonObj.toString();
		} catch (Exception e) {
			CommonLog.e(PutGroupSettingReq.class.getSimpleName(), "" + e.getMessage());
			return "";
		}
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
