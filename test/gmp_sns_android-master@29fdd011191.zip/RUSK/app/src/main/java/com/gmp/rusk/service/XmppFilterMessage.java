package com.gmp.rusk.service;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

import android.content.Context;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager.ContactsDBManager;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.push.PushController;
import com.gmp.rusk.request.GetUserInfoReq;

import com.gmp.rusk.response.GetUserInfoRes;
import com.gmp.rusk.response.Res;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.LocalAesCrypto;

public class XmppFilterMessage {

	public MyApp App = MyApp.getInstance();
	public final String SERVICE_NAME = "cork.com";
	public final String TMS_ALL = "/TMS_ALL";
	public final String TAG = XmppConnectionService.class.getSimpleName();

	// 그룹채팅방에 DB에 없는 사용자가 있을시 처리를 위함
	ArrayList<UserListData> m_arrDBSetUser = new ArrayList<UserListData>();

	Context mFilterContext;
	
	public void setContext(Context context){
		mFilterContext = context;
	}
	
	public class ToastRunnable implements Runnable {
		Context aContext;
		int nUserNo;
		String strName;
		String strAlert;
		String strImage;
		String strRoomId;

		public ToastRunnable(Context a_Context, int a_nUserNo, String a_strName, String a_strAlert, String a_strImage, String a_strRoomId) {
			aContext = a_Context;
			nUserNo = a_nUserNo;
			strName = a_strName;
			strAlert = a_strAlert;
			strImage = a_strImage;
			strRoomId = a_strRoomId;
		}

		@Override
		public void run() {

			PushController.showPushToast(aContext, nUserNo, strName, strAlert, strImage, strRoomId);

		}
	}

	public class PopupRunnable implements Runnable {
		Context aContext;
		String strAlert;
		String strRoomID;

		public PopupRunnable(Context a_Context, String a_strAlert, String a_strRoomID) {
			aContext = a_Context;
			strAlert = a_strAlert;
			strRoomID = a_strRoomID;
		}

		@Override
		public void run() {
			PushController.showKickPopup(aContext, strAlert, strRoomID);
		}
	}
	
	// 단말 DB에 해당 사용자 정보가 없을때
	synchronized public void requestAddedByUserList(final int nUserID, final CountDownLatch latch) {
		int[] nSelects = new int[1];
		nSelects[0] = nUserID;
		GetUserInfoReq req = new GetUserInfoReq(nSelects);
		WebAPI webApi = new WebAPI(mFilterContext);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub

			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub

				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				UserListData getItem = res.getUserListData().get(0);
				if (getItem != null)
					ContactsDBManager.insertContacts(mFilterContext, getItem);
				String[] aesData;
				String strFriendUserName;
				if (getItem == null) {
					strFriendUserName = mFilterContext.getString(R.string.not_in_db_user);
				} else {
					strFriendUserName = getItem.m_PersonalData.mapPersonalData.get(PersonalData.NAME);
				}
				ChattingRoomInfoData data;
				try {
					LocalAesCrypto crypto = new LocalAesCrypto();
					data = new ChattingRoomInfoData(Integer.toString(nUserID), crypto.encrypt(strFriendUserName), true, App.m_MyUserInfo.m_nUserNo,
							false);
					RoomDBManager.insertRoom(mFilterContext, data);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				CommonLog.e(mFilterContext, "없는 DB 생성중");
				latch.countDown();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				latch.countDown();
			}
		});
	}

	// 단말 DB에 해당 사용자 정보가 없을때(그룹)
	synchronized public void requestAddedByUserList(int[] nUserIDs, final CountDownLatch latch) {
		GetUserInfoReq req = new GetUserInfoReq(nUserIDs);
		WebAPI webApi = new WebAPI(mFilterContext);
		webApi.request(req, new WebListener() {

			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				CommonLog.e(TAG, "DB에 없는 사용자 넣는 중 : 작동!!!");
			}

			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				CommonLog.e(getClass().getSimpleName(), "Data : " + a_strData);
				GetUserInfoRes res = new GetUserInfoRes(a_strData, Res.RES_TYPE_USER_LIST);

				if (res.getUserListData() != null) {
					for (int i = 0; i < res.getUserListData().size(); i++) {
						UserListData getItem = res.getUserListData().get(i);
						if (getItem != null) {
							ContactsDBManager.insertContacts(mFilterContext, getItem);
							m_arrDBSetUser.add(getItem);
							CommonLog.e(TAG, "DB에 없는 사용자 넣는 중");
						}
					}
				}
				latch.countDown();
			}

			@Override
			public void onNetworkError(int a_nErrorCode, String a_strMessage) {
				// TODO Auto-generated method stub
				latch.countDown();
			}
		});
	}
}
