package com.gmp.rusk.response;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gmp.rusk.datamodel.ApprovalAcceptListData;
import com.gmp.rusk.utils.CommonLog;

public class GetAccepterPartnerListRes extends Res{
//	private final String JSON_REQUESTCOUNT				= "requestCount";
	private final String JSON_PARTNERS					= "partners";
	private final String JSON_USERNO		 			= "userNo";
	private final String JSON_NAME			 			= "name";
	private final String JSON_AFFILIATION					= "affiliation";
	//private final String JSON_IMAGEAVAILABLE			= "imageAvailable";
	private final String JSON_MOBILE				= "mobile";
	private final String JSON_EXPIRESOON		= "expireSoon";
	
	public int m_strRequestCount = 0;
	
	ArrayList<ApprovalAcceptListData> m_arrApprovalAcceptListDatas = null;
	
	public GetAccepterPartnerListRes(String a_strData) {
		super(a_strData);
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			
			if (!jsonRoot.isNull(JSON_PARTNERS)) {
				JSONArray jsonArray = jsonRoot.getJSONArray(JSON_PARTNERS);
				int nArrCount = jsonArray.length();
				if (nArrCount > 0) {
					m_arrApprovalAcceptListDatas = new ArrayList<ApprovalAcceptListData>();
					for (int i = 0; i < nArrCount; i++) {
						JSONObject jsonItem = jsonArray.getJSONObject(i);
						
						int nUserNo = jsonItem.optInt(JSON_USERNO);
						String strName = jsonItem.optString(JSON_NAME);
						String strAffiliation = jsonItem.optString(JSON_AFFILIATION);
						String strMobile = jsonItem.optString(JSON_MOBILE);
						boolean isExpireSoon = jsonItem.optBoolean(JSON_EXPIRESOON);
						
						ApprovalAcceptListData item = new ApprovalAcceptListData(nUserNo, strName, strAffiliation, strMobile, isExpireSoon);
						
						m_arrApprovalAcceptListDatas.add(item);
					}
				}
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			CommonLog.e(getClass(), "" + e.toString());
		}
	}

	public ArrayList<ApprovalAcceptListData> getApprovalAcceptList()
	{
		return m_arrApprovalAcceptListDatas;
	}
}
