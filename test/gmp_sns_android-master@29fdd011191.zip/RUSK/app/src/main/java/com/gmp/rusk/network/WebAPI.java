package com.gmp.rusk.network;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.util.Base64;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.request.Req;
import com.gmp.rusk.request.UploadReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;
import com.gmp.rusk.utils.Utils;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.conn.ssl.StrictHostnameVerifier;
import org.apache.http.entity.mime.MultipartEntity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Locale;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class WebAPI {

	public static final String REQTYPE_GET = "GET";
	public static final String REQTYPE_POST = "POST";
	public static final String REQTYPE_PUT = "PUT";
	public static final String REQTYPE_DELETE = "DELETE";
	
	public static  int m_nReqType;
	
	// 타임아웃
	private final static int CONNECTION_TIMEOUT = 10000;
	private final static int CONNECTION_UPLOAD_TIMEOUT = 10000;
	private final static int CONNECTION_LONGPOLLING_TIMEOUT = 60000 * 5;


	private final String TAG = "WebAPI";

	private static Context m_Context = null;
	
	// Web Response Listener
	private WebListener m_Listener;
	
	private boolean m_bIsHttps;

	// 생성자
	public WebAPI(Context context) {
		m_Context = context;
		m_bIsHttps = AppSetting.ISHTTPS;
	}

	// 네트워크 상태 체크
	private static int NetCheck() {
		if (m_Context == null)
			return NetworkManager.NETWORK_CONNECTED_ETC;

		int ret = NetworkManager.NetworkStateCheck(m_Context);
		if (ret == NetworkManager.NETWORK_DISCONNECTED) {
			return ret;
		}
		return ret;
	}
	
	public void request(Req req, WebListener listener) {
		m_Listener = listener;
		
		executeReqTask(req);
	}
	

	public void request(Req req, boolean bIsHttps, int nReqType,  WebListener listener) {
		m_bIsHttps = bIsHttps;
		m_nReqType = nReqType;
		m_Listener = listener;

		executeReqTask(req);
	}
	
	public void requestUpload(UploadReq req, WebListener listener)
	{
		m_Listener = listener;
		excuteUploadReqTask(req);
	}
	
	public void requestUpload(UploadReq req, boolean bIsHttps, int nReqType,  WebListener listener) {
		m_bIsHttps = bIsHttps;
		m_nReqType = nReqType;
		m_Listener = listener;

		excuteUploadReqTask(req);
	}

	private void executeReqTask(Req req) {
		String[] params = new String[ReqTask.IDX_MAX];
		params[ReqTask.IDX_APINAME] = req.getAPIName();
		params[ReqTask.IDX_IS_AUTHENTIFICATION] = req.getIsAuthentification();
		params[ReqTask.IDX_RESTFUL] = req.getMethod();
		params[ReqTask.IDX_PARAMS] = req.MakeRequestData();
		params[ReqTask.IDX_IS_LONGPOLLING] = req.getLongPolling();

		ReqTask task = new ReqTask();
		task.execute(params);
	}
	
	private void excuteUploadReqTask(UploadReq req)
	{
		UploadReqTask task = new UploadReqTask();
		task.execute(req);
	}
	
	private class ReqTask extends PriorityAsyncTaskWebApi<String, Void, String> {
		public final static int IDX_APINAME = 0;
		public final static int IDX_IS_AUTHENTIFICATION = IDX_APINAME + 1;
		public final static int IDX_PARAMS = IDX_IS_AUTHENTIFICATION + 1;
		public final static int IDX_RESTFUL = IDX_PARAMS + 1;
		public final static int IDX_IS_LONGPOLLING = IDX_RESTFUL + 1;
		public final static int IDX_MAX = IDX_IS_LONGPOLLING + 1;
		public int m_nResultCode = ApiResult.RESULT_SUCCESS;
		public String m_strResulErrorMessage = "";

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			httpContent httpObject = new httpContent();
			String strResult = null;
			try {
				if (m_bIsHttps) {
					// HTTPSConnection
					if (params[IDX_RESTFUL] == REQTYPE_GET) {
						// Get 방식
						strResult = httpObject.requestGetHttps(
								m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION], params[IDX_IS_LONGPOLLING]);
					} else if (params[IDX_RESTFUL] == REQTYPE_POST) {
						// Post 방식
						strResult = httpObject.requestPostHttps(
								m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION], params[IDX_IS_LONGPOLLING]);
					} else if (params[IDX_RESTFUL] == REQTYPE_PUT) {
						// Put 방식
						strResult = httpObject.requestPutHttps(
								m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION], params[IDX_IS_LONGPOLLING]);
					} else {
						// Delete 방식
						strResult = httpObject.requestDeleteHttps(m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION], params[IDX_IS_LONGPOLLING]);
					}

				} else {
					// HTTPConnection
					if (params[IDX_RESTFUL] == REQTYPE_GET) {
						// Get 방식
						strResult = httpObject.requestGetHttp(
								m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION]);
					} else if (params[IDX_RESTFUL] == REQTYPE_POST) {
						// Post 방식
						strResult = httpObject.requestPostHttp(
								m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION]);
					} else if (params[IDX_RESTFUL] == REQTYPE_PUT) {
						// Put 방식
						strResult = httpObject.requestPutHttp(
								m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION]);						
					} else {
						// Delete 방식
						strResult = httpObject.requestDeleteHttp(m_Context, params[IDX_APINAME],
								params[IDX_PARAMS], params[IDX_IS_AUTHENTIFICATION]);
					}

				}
			} catch (NetworkException e) {
				m_nResultCode = e.getErrorCode();
				m_strResulErrorMessage = e.getErrorMessage();
//				CommonLog.e(TAG, e.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				m_nResultCode = ApiResult.HTTP_ERR_UNKNOWN_EXCEPTION;
				m_strResulErrorMessage = m_Context.getString(R.string.network_bad);
//				CommonLog.e(TAG, e.getMessage());
			}
			return strResult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			if (m_Listener != null) {
				m_Listener.onPreRequest();
			}
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			if (m_Listener != null) {
				// Request 성공
				if (result != null && m_nResultCode == ApiResult.RESULT_SUCCESS) {
					m_Listener.onPostRequest(result);
					CommonLog.e(TAG, "Result : " + result);
				}
				
				// Request 실패
				else {
					CommonLog.e(TAG, "ErrorCode" + m_nResultCode);
					
					m_Listener.onNetworkError(m_nResultCode, m_strResulErrorMessage);
				}
			}
			super.onPostExecute(result);
		}
	}
	
	private class UploadReqTask extends PriorityAsyncTaskWebApi<UploadReq, Void, String> {
		
		public int m_nResultCode = ApiResult.RESULT_SUCCESS;
		public String m_strResulErrorMessage = "";

		@Override
		protected String doInBackground(UploadReq... params) {
			// TODO Auto-generated method stub
			CommonLog.e(TAG, "Upload doInBackground !!!!!!!");
			UploadReq req = params[0];
			httpContent httpObject = new httpContent();
			String strResult = null;
			try {
				if (m_bIsHttps) {
					// Upload 는 무조건 Post
					String strAPIName = req.getAPIName();
					String strAuth = req.getIsAuthentification();
					MultipartEntity multiPart = req.getMultiPartEntity();
					
					strResult = httpObject.requestUploadHttps(m_Context, strAPIName, strAuth, multiPart);
					
				} else {
					// Upload 는 무조건 Post
					String strAPIName = req.getAPIName();
					String strAuth = req.getIsAuthentification();
					MultipartEntity multiPart = req.getMultiPartEntity();
					
					strResult = httpObject.requestUploadHttp(m_Context, strAPIName, strAuth, multiPart);
				}
			} catch (NetworkException e) {
				m_nResultCode = e.getErrorCode();
				m_strResulErrorMessage = e.getErrorMessage();
//				CommonLog.e(TAG, e.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				m_nResultCode = ApiResult.HTTP_ERR_UNKNOWN_EXCEPTION;
				m_strResulErrorMessage = m_Context.getString(R.string.network_bad);
			}
			return strResult;
		}

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			if (m_Listener != null) {
				m_Listener.onPreRequest();
			}
			CommonLog.e(TAG, "Upload PreExecute !!!!!!!");
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			if (m_Listener != null) {
				// Request 성공
				if (result != null && m_nResultCode == ApiResult.RESULT_SUCCESS) {
					m_Listener.onPostRequest(result);
					CommonLog.e(TAG, "Result : " + result);
				}
				
				// Request 실패
				else {
					CommonLog.e(TAG, "ErrorCode" + m_nResultCode);
					
					m_Listener.onNetworkError(m_nResultCode, m_strResulErrorMessage);
				}
			}
			super.onPostExecute(result);
		}
	}

	public static class httpContent{
		public String requestGetHttp(Context context, String a_strAPIName, String a_strData, String a_strAuthentification) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP_PORT;
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strData);
//			strUri += a_strData;
			
			return HttpUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_GET, strUri, a_strData, a_strAuthentification, null);
//			return getHttpUrlContent(context, strUri);
		}
		
		public String requestGetHttps(Context context, String a_strAPIName, String a_strData, String a_strAuthentification, String a_strLongPolling) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strData);
			
			return HttpsUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_GET, strUri, a_strData, a_strAuthentification, null, a_strLongPolling);
		}
		
		public String requestPutHttp(Context context, String a_strAPIName, String a_strData, String a_strAuthentification) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strData);
//			strUri += a_strData;
			
			return HttpUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_PUT, strUri, a_strData, a_strAuthentification, null);
		}
		
		public String requestPutHttps(Context context, String a_strAPIName, String a_strData, String a_strAuthentification, String a_strLongPolling) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strData);
			
			return HttpsUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_PUT, strUri, a_strData, a_strAuthentification, null, a_strLongPolling);
		}
		
		
		public String requestPostHttp(Context context, String a_strAPIName, String a_strParam, String a_strAuthentification) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strParam);
			return HttpUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_POST, strUri, a_strParam, a_strAuthentification, null);
			
		}
		
		public String requestPostHttps(Context context, String a_strAPIName, String a_strParam, String a_strAuthentification, String a_strLongPolling) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT + "/api";
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strParam);
			return HttpsUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_POST, strUri, a_strParam, a_strAuthentification, null, a_strLongPolling);
		}
		
		public String requestDeleteHttp(Context context, String a_strAPIName, String a_strData, String a_strAuthentification) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP_PORT;
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			strUri += "/"+a_strAPIName;
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strData);
//			strUri += a_strData;
			
			return HttpUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_DELETE, strUri, a_strData, a_strAuthentification, null);
		}
		
		public String requestDeleteHttps(Context context, String a_strAPIName, String a_strData, String a_strAuthentification, String a_strLongPolling) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			CommonLog.e(WebAPI.class, "Param : " + a_strData);
			
			return HttpsUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_DELETE, strUri, a_strData, a_strAuthentification, null, a_strLongPolling);
		}
		
		public String requestUploadHttp(Context context, String a_strAPIName, String a_strAuthentification, MultipartEntity a_MultipartEntity) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTP_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			return HttpUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_POST, strUri, null, a_strAuthentification, a_MultipartEntity);
			
		}
		
		public String requestUploadHttps(Context context, String a_strAPIName, String a_strAuthentification, MultipartEntity a_MultipartEntity) throws Exception
		{
			String strUri = NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS + NetworkManager.NETWORK_OPEN_API_MAIN_URL_HTTPS_PORT + "/api";
			
			switch(NetCheck()){
			case NetworkManager.NETWORK_DISCONNECTED:
				CommonLog.e(WebAPI.class, "NetWork Disconnected");
//				return ApiResult.RESULT_DISCONNECT;
				throw new NetworkException(ApiResult.HTTP_ERR_DISCONNECTED, m_Context.getString(R.string.network_bad).toString());
			case NetworkManager.NETWORK_CONNECTED_WIFI:
//				strUri = strUri.replace("http://", HTTPS_STR);
				break;
			}
			
			strUri += "/"+a_strAPIName;
			
			CommonLog.e(WebAPI.class, "Uri : " + strUri);
			
			return HttpsUrlContent(context, a_strAPIName, NetworkManager.HTTP_METHOD_POST, strUri, null, a_strAuthentification, a_MultipartEntity, "false");
		}
	}
	
	public static String HttpUrlContent(Context context, String a_strAPIName, String a_strRequestMethod, String url, String a_strData, String a_strAuthentification, MultipartEntity a_MultipartEntity) throws Exception
	{
		MyApp App = MyApp.getInstance();
	    try
	    {   
	    	if(a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_GET) && a_strData != null )
	    		url += a_strData;
	    	
			URL connectUrl = new URL(url);
			HttpURLConnection con = null;
			
			con = (HttpURLConnection) connectUrl.openConnection();
			
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Connection", "close");
			
			//headerSet
			con.setRequestProperty("X-Device-OS", "A");
			con.setRequestProperty("Accept-Language", App.m_strLocale);
			con.setRequestProperty("X-Device-OS-Version", Utils.getBuildOSVersion());	
			con.setRequestProperty("X-Device-Model", Utils.getBuildModel());
			con.setRequestProperty("X-Device-Vender", Utils.getBuildManufacturer());
			
			TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
			
			//if(!AppSetting.FEATURE_VARIANT.equals("R"))
				con.setRequestProperty("X-Device-UID", tm.getDeviceId());
			//con.setRequestProperty("X-Device-UID", "MOBILE_2090");
			
			
			con.setRequestProperty("X-App-Version", Utils.getApplicationVersion(context));
			if(AppSetting.FEATURE_VARIANT.equals("S"))
				con.setRequestProperty("X-App-Variant", "P");
			else
				con.setRequestProperty("X-App-Variant", AppSetting.FEATURE_VARIANT);
		
			CommonLog.e("", "entry : " + a_strAPIName);
			
			if(!AppSetting.FEATURE_VARIANT.equals("R") && a_strAuthentification.equals("true"))
			{
				CommonLog.e("","P... a_strAuthentification.equals(true)");
				con.setRequestProperty("Authorization", "Basic " + Base64.encodeToString((App.m_PartnerID+":"+App.m_PartnerPW).getBytes(), 0));
			}
			else if(AppSetting.FEATURE_VARIANT.equals("R") && a_strAuthentification.equals("true"))
			{
				CommonLog.e("","R... a_strAuthentification.equals(true)");
				CommonLog.e("", "RegularAuthorization RegularID["+App.m_GMPData.m_strRegularID+"] " + "AuthKey["+App.m_GMPData.m_strAuthKey+"]");
//				App.m_GMPData.m_strRegularID = "1102978";
				App.m_GMPData.m_strRegularID = "1102450";
				
				
				CommonLog.e("", "RegularAuthorization RegularID["+App.m_GMPData.m_strRegularID+"] " + "AuthKey["+App.m_GMPData.m_strAuthKey+"]");
				con.setRequestProperty("Authorization", "GMP " + Base64.encodeToString((App.m_GMPData.m_strCompanyCode+"."+App.m_GMPData.m_strRegularID+":"+App.m_GMPData.m_strAuthKey).getBytes(), Base64.NO_WRAP));
				con.setRequestProperty("Authorization-Mdn", App.m_Mdn);
			}
				
			System.setProperty("http.keepAlive", "false");
			
			CommonLog.e("a_strRequestMethod", a_strRequestMethod);
			CommonLog.e("url",url);

			con.setRequestMethod(a_strRequestMethod);
			con.setDoInput(true);
			con.setDefaultUseCaches(false);
			
			con.setReadTimeout(CONNECTION_TIMEOUT);
			con.setConnectTimeout(CONNECTION_TIMEOUT);
			
			// Delete Method에서는 이것 넣으면 Exception 발생 왜 그럴까?
			if(!a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_DELETE) && !a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_GET))	
				con.setDoOutput(true);
			else
				con.setDoOutput(false);
			
				
			
			if(!a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_GET) && a_strData != null && !a_strData.equals(""))
			{
				con.connect();
				OutputStream os = con.getOutputStream();
				OutputStreamWriter ow = new OutputStreamWriter(os);
				ow.write(a_strData);
				ow.flush();
				ow.close();
			}
			else if(a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_POST) && a_MultipartEntity != null)
			{
				con.setRequestProperty("Connection", "Keep-Alive");
		        con.addRequestProperty("Content-length", a_MultipartEntity.getContentLength() + "");
		        con.setRequestProperty(a_MultipartEntity.getContentType().getName(), a_MultipartEntity.getContentType().getValue());
		        
		        OutputStream os = con.getOutputStream();
		        a_MultipartEntity.writeTo(os);
		        OutputStreamWriter ow = new OutputStreamWriter(os);
		        ow.flush();
		        ow.close();
		        con.connect();
			}

			if (con.getResponseCode() != ApiResult.HTTP_STATUS_OK) {
				
				con.getHeaderField("X-Status-Message");
				
				CommonLog.e("http","response code : " + con.getResponseCode());
				if(con.getResponseCode() == ApiResult.HTTP_SERVER_NOT_JOIN)
				{
					throw new NetworkException(con.getResponseCode(), "");
				}
				else if(con.getResponseCode() == ApiResult.HTTP_SERVER_CLOSE)
				{
//					InputStream inputStream = con.getErrorStream();
//					ByteArrayOutputStream content = new ByteArrayOutputStream();
//					// Read response into a buffered stream
//					int readBytes = 0;
//					byte[] sBuffer = new byte[1024 * 4];
//					while ((readBytes = inputStream.read(sBuffer)) != -1) {
//						content.write(sBuffer, 0, readBytes);
//					}
//					String ret = new String(content.toByteArray(),"UTF-8");
//					content.close();
//
//					
//					inputStream.close();
//					con.disconnect();
//					CommonLog.e("ret", "ret2 : " + ret);
					
					String ret = new String(URLDecoder.decode(con.getHeaderField("X-Status-Message"),"UTF-8"));
					CommonLog.e("ret", "HTTP_SERVER_CLOSE ret : " + ret);
					throw new NetworkException(con.getResponseCode(), ret);
				}else{
					String ret = new String(URLDecoder.decode(con.getHeaderField("X-Status-Message"),"UTF-8"));
					CommonLog.e("ret", "else ret : " + ret);
					throw new NetworkException(con.getResponseCode(), ret);
					
//					InputStream inputStream = con.getErrorStream();
//					ByteArrayOutputStream content = new ByteArrayOutputStream();
//					// Read response into a buffered stream
//					int readBytes = 0;
//					byte[] sBuffer = new byte[1024 * 4];
//					while ((readBytes = inputStream.read(sBuffer)) != -1) {
//						content.write(sBuffer, 0, readBytes);
//					}
//					String ret = new String(content.toByteArray(),"UTF-8");
//					content.close();
//
//					inputStream.close();
//					con.disconnect();
//					if(ret != null)
//					{
//						CommonLog.e("ret", "ret3 : " + ret);
//						throw new NetworkException(con.getResponseCode(), ret);
//					}
//					else
//						throw new NetworkException(con.getResponseCode(), "");
				}
			}
			
			// Pull content stream from response
			InputStream inputStream = con.getInputStream();
			
			ByteArrayOutputStream content = new ByteArrayOutputStream();
			
			// Read response into a buffered stream
			int readBytes = 0;
			byte[] sBuffer = new byte[1024 * 4];
			while ((readBytes = inputStream.read(sBuffer)) != -1) {
				content.write(sBuffer, 0, readBytes);
			}

			String ret = new String(content.toByteArray(),"UTF-8");
			content.close();

			inputStream.close();
			con.disconnect();
			
	        return ret;
	    }
	    
	    catch (UnsupportedEncodingException e) {
	    	e.printStackTrace();
	    	throw new NetworkException(context.getString(R.string.network_bad));
		}catch (SocketTimeoutException e){
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch(SocketException e){
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch (ClientProtocolException e) {
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch (IOException e) {
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch(Error e){
			e.printStackTrace();
			System.gc();
			throw new Exception("OutOfMemory!! " + e.getMessage());
		}
	}
	
	public static String HttpsUrlContent(Context context, String a_strAPIName, String a_strRequestMethod, String url, 
			String a_strData, String a_strAuthentification, MultipartEntity a_MultipartEntity, String a_strLongPolling) throws Exception
	{
		MyApp App = MyApp.getInstance();
	    try
	    {   	    	
	    	if(a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_GET) && url != null) 
	    		url += a_strData;
	    	
//	    	CookieManager cookieManager = new CookieManager();  
//	        CookieHandler.setDefault(cookieManager);
	    	
//	        CookieHandler.setDefault( new CookieManager( null, CookiePolicy.ACCEPT_ALL ) );
			//2016년 고도화 개발 서버 사용
			//trustAllHosts();
	        URL connectUrl = new URL(url);
			HttpsURLConnection con = null;
			
			HttpsURLConnection.setDefaultSSLSocketFactory(NoSSLv3Factory.getInstance());
			
			HttpsURLConnection https = (HttpsURLConnection) connectUrl.openConnection();


			//상용 서버 사용
			https.setHostnameVerifier(new StrictHostnameVerifier());
			//2016년 고도화 개발 서버 사용
			//https.setHostnameVerifier(DO_NOT_VERIFY);

			con = https;			
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Connection", "close");
			
			//headerSet
			con.setRequestProperty("X-Device-OS", "A");
			con.setRequestProperty("Accept-Language", App.m_strLocale);
			con.setRequestProperty("X-Device-OS-Version", Utils.getBuildOSVersion());	
			con.setRequestProperty("X-Device-Model", Utils.getBuildModel());
			con.setRequestProperty("X-Device-Vender", Utils.getBuildManufacturer());
			
			TelephonyManager tm = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
			
			//if(!AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR))
				con.setRequestProperty("X-Device-UID", tm.getDeviceId());
			//con.setRequestProperty("X-Device-UID", "MOBILE_2090");
			
			
			con.setRequestProperty("X-App-Version", Utils.getApplicationVersion(context));
			if(AppSetting.FEATURE_VARIANT.equals("S"))
				con.setRequestProperty("X-App-Variant", StaticString.VARIANT_PARTNER);
			else
				con.setRequestProperty("X-App-Variant", AppSetting.FEATURE_VARIANT);
		
			CommonLog.e("", "entry : " + a_strAPIName);
			
			String strPartnerID = App.m_PartnerID;

			
			if(!AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && a_strAuthentification.equals("true"))
			{
				CommonLog.e("","P... a_strAuthentification.equals(true)");
				String strAuth = "";
				SharedPref pref = SharedPref.getInstance(m_Context);

				strAuth = "Basic " + Base64.encodeToString((strPartnerID+":"+App.m_PartnerPW).getBytes(), 0);
				con.setRequestProperty("Authorization", strAuth);
			}
			else if(AppSetting.FEATURE_VARIANT.equals(StaticString.VARIANT_REGULAR) && a_strAuthentification.equals("true"))
			{
				CommonLog.e("","R... a_strAuthentification.equals(true)");
				CommonLog.e("", "RegularAuthorization RegularID["+App.m_GMPData.m_strRegularID+"] " + "AuthKey["+App.m_GMPData.m_strAuthKey+"]");
				CommonLog.e("", "RegularAuthorization Basic["+(App.m_GMPData.m_strRegularID+":"+App.m_GMPData.m_strAuthKey+"|"+Utils.getPhoneNumber(context))+"]");
				
//				String baseCode = Base64.encodeToString((App.m_GMPData.m_strRegularID+":"+App.m_GMPData.m_strAuthKey+"|"+Utils.getPhoneNumber(context)).getBytes(),Base64.NO_WRAP);
				con.setRequestProperty("Authorization", "GMP " + Base64.encodeToString((App.m_GMPData.m_strCompanyCode+"."+App.m_GMPData.m_strRegularID+":"+App.m_GMPData.m_strAuthKey).getBytes(), Base64.NO_WRAP));
				con.setRequestProperty("Authorization-Mdn", App.m_Mdn);
//				con.setRequestProperty("Authorization", "Basic " + new String(Base64.encode(baseCode.getBytes(),0)));
				
			}
			

			System.setProperty("http.keepAlive", "false");
	        
			SharedPref pref = SharedPref.getInstance(context);
			con.setRequestProperty("Cookie", pref.getStringPref(SharedPref.PREF_COOKIE, ""));
			
			
			con.setRequestMethod(a_strRequestMethod);
			con.setDoInput(true);
			
			// Delete Method에서는 이것 넣으면 Exception 발생 왜 그럴까?
			if(!a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_DELETE) && !a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_GET))	
				con.setDoOutput(true);
			else
				con.setDoOutput(false);
			
			con.setDefaultUseCaches(false);

			if(a_strLongPolling.equals("true"))
			{
				con.setReadTimeout(CONNECTION_LONGPOLLING_TIMEOUT);
				con.setConnectTimeout(CONNECTION_LONGPOLLING_TIMEOUT);
			}
			else
			{
				if(a_MultipartEntity == null){
					con.setReadTimeout(CONNECTION_TIMEOUT);
					con.setConnectTimeout(CONNECTION_TIMEOUT);
				} else {
					con.setReadTimeout(CONNECTION_UPLOAD_TIMEOUT);
					con.setConnectTimeout(CONNECTION_UPLOAD_TIMEOUT);
				}
//				Map<String, List<String>> map = con.getRequestProperties();
//				Iterator<String> keys = map.keySet().iterator();
//				CommonLog.e(m_Context.getClass().getSimpleName(), "Header Value");
//				for( String key : map.keySet() ){
//					CommonLog.e(m_Context.getClass().getSimpleName(), "Key : " + key + " Value : " + map.get(key));
//		        }
			}
			
			if(!a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_GET) && a_strData != null && !a_strData.equals(""))
			{
				con.connect();
				OutputStream os = con.getOutputStream();
				OutputStreamWriter ow = new OutputStreamWriter(os);
				ow.write(a_strData);
				ow.flush();
				ow.close();
			}
			else if(a_strRequestMethod.equals(NetworkManager.HTTP_METHOD_POST) && a_MultipartEntity != null)
			{
				con.setRequestProperty("Connection", "Keep-Alive");
		        con.addRequestProperty("Content-length", "" + a_MultipartEntity.getContentLength());
		        
		        con.setRequestProperty(a_MultipartEntity.getContentType().getName(), a_MultipartEntity.getContentType().getValue());
		        
		        OutputStream os = con.getOutputStream();
		        a_MultipartEntity.writeTo(con.getOutputStream());
		        os.close();
		        con.connect();
			}
			
			if (con.getResponseCode() != ApiResult.HTTP_STATUS_OK) {
				CommonLog.e(WebAPI.class.getSimpleName(), "Error Code : " + con.getResponseCode());
				CommonLog.e(WebAPI.class.getSimpleName(), "Error Msg : " + con.getResponseMessage());
				if(con.getResponseCode() == ApiResult.HTTP_SERVER_NOT_JOIN)
				{
					throw new NetworkException(con.getResponseCode(), "");
				}
				else if(con.getResponseCode() == ApiResult.HTTP_SERVER_CLOSE)
				{
					String ret = new String(URLDecoder.decode(con.getHeaderField("X-Status-Message"),"UTF-8"));
					throw new NetworkException(con.getResponseCode(), ret);
				}else{
					String ret = new String(URLDecoder.decode(con.getHeaderField("X-Status-Message"),"UTF-8"));
					throw new NetworkException(con.getResponseCode(), ret);
				}
			}
			// Pull content stream from response
			InputStream inputStream = con.getInputStream();
			
			ByteArrayOutputStream content = new ByteArrayOutputStream();
			if(a_strAPIName.equals(StaticString.LOGIN_API_NAME) || a_strAPIName.equals(StaticString.LOGIN_MIGRATE_NAME))
			{
//				String cookie = con.getHeaderField("Set-Cookie").substring(0, con.getHeaderField("Set-Cookie").indexOf(';'));
				pref.setStringPref(SharedPref.PREF_COOKIE, con.getHeaderField("Set-Cookie"));
//				CommonLog.e("", "Cookie : " + cookie);
			}
			// Read response into a buffered stream
			int readBytes = 0;
			byte[] sBuffer = new byte[1024 * 4];
			while ((readBytes = inputStream.read(sBuffer)) != -1) {
				content.write(sBuffer, 0, readBytes);
			}

			String ret = new String(content.toByteArray(),"UTF-8");
			content.close();

			inputStream.close();
			con.disconnect();
	        return ret;
	    }
	    catch (UnsupportedEncodingException e) {
	    	e.printStackTrace();
	    	throw new NetworkException(context.getString(R.string.network_bad));
		}catch (SocketTimeoutException e){
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch(SocketException e){
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch (ClientProtocolException e) {
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch (IOException e) {
			e.printStackTrace();
			throw new NetworkException(context.getString(R.string.network_bad));
		}catch(Error e){
			System.gc();
			throw new Exception("OutOfMemory!! " + e.getMessage());
		}
	}
	
	public static boolean ResultCheck(String a_strData)
	{
		if(a_strData == null || a_strData.equals(""))
		{
			return false;
		}
		
		return true;
	}

	///////////////////////////////////////////////
	//2016년 고도화 개발 서버 사용시 필요
/*	public static TrustManager[] trustAllCerts;
	public static void trustAllHosts() {
		System.setProperty("http.keepAlive", "false");
		// Create a trust manager that does not validate certificate chains
		if(trustAllCerts == null){
			trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new java.security.cert.X509Certificate[] {};
				}
				@Override
				public void checkClientTrusted(
						java.security.cert.X509Certificate[] chain,
						String authType)
						throws java.security.cert.CertificateException {
					// TODO Auto-generated method stub

				}

				@Override
				public void checkServerTrusted(
						java.security.cert.X509Certificate[] chain,
						String authType)
						throws java.security.cert.CertificateException {
					// TODO Auto-generated method stub0

				}
			} };
		}

		// Install the all-trusting trust manager
		try {
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	public final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
		@Override
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	};*/
}