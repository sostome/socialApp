package com.gmp.rusk.datamodel;

import java.util.ArrayList;

/**
 * Created by K on 2017-08-14.
 */

public class ChannelCommentData {

    public int m_nCommentNo = -1;
    public int m_nUserNo = -1;
    public String m_strBody = "";
    public String m_strCreatedDate = "";
    public String m_strUpdatedTime = "";
    public int m_nLikeCount = -1;
    public boolean m_isLiked = false;


}
