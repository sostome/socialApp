package com.gmp.rusk.datamodel;

public class GMPData {
	public String m_strCompanyCode = "";
	public String m_strRegularID = "";	
	public String m_strAuthKey = "";
	public String m_strEncPwd = "";
	
	
	public GMPData(String a_strCompanyCode, String a_strRegularID, String a_strAuthKey, String a_strEncPwd)
	{
		m_strCompanyCode = a_strCompanyCode;
		m_strRegularID = a_strRegularID;
		m_strAuthKey = a_strAuthKey;
		m_strEncPwd = a_strEncPwd;
	}
}
