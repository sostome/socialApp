package com.gmp.rusk.response;

import org.json.JSONException;
import org.json.JSONObject;

public class PostGroupRes extends ChannelRes{
	
	private final String JSON_CHANNELNO 				= "channelNo";
	private int m_nChannelNo = 0;
	
	public PostGroupRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		if(m_strResData == null || m_strResData.equals(""))
			return;
		
		try {
			JSONObject jsonRoot = new JSONObject(m_strResData);
			m_nChannelNo = jsonRoot.getInt(JSON_CHANNELNO);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int getChannelNo()
	{
		return m_nChannelNo;
	}
}
