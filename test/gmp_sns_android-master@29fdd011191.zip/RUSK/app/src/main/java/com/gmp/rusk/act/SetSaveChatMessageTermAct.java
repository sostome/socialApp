package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.View.OnClickListener;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

/**
 * SetSaveChatMessageTermAct
 * @author dym
 * 대화내용 보관정책 설정 Activity
 */
public class SetSaveChatMessageTermAct extends CustomActivity implements OnClickListener, OnCheckedChangeListener{
	
	private CommonPopup m_Popup = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		setContentView(R.layout.act_set_savechatmessageterm);
		initUI();
	}
	
	private void initUI()
	{
		ImageView btnClose = (ImageView)findViewById(R.id.btn_cancel);
		btnClose.setOnClickListener(this);
		ImageView btnSave = (ImageView)findViewById(R.id.btn_save);
		btnSave.setOnClickListener(this);
		CheckBox cb3Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3weekbeforedelete);
		CheckBox cb2Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_2weekbeforedelete);
		CheckBox cb1Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_1weekbeforedelete);
		CheckBox cb3Day = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3daybeforedelete);
		LinearLayout layout3week = (LinearLayout)findViewById(R.id.layout_savechatmessageterm_3weekbeforedelete);
		LinearLayout layout2week = (LinearLayout)findViewById(R.id.layout_savechatmessageterm_2weekbeforedelete);
		LinearLayout layout1week = (LinearLayout)findViewById(R.id.layout_savechatmessageterm_1weekbeforedelete);
		LinearLayout layout3day = (LinearLayout)findViewById(R.id.layout_savechatmessageterm_3daybeforedelete);
		TextView tv3week = (TextView)findViewById(R.id.tv_savechatmessageterm_3weekbeforedelete);
		TextView tv2week = (TextView)findViewById(R.id.tv_savechatmessageterm_2weekbeforedelete);
		TextView tv1week = (TextView)findViewById(R.id.tv_savechatmessageterm_1weekbeforedelete);
		TextView tv3day = (TextView)findViewById(R.id.tv_savechatmessageterm_3daybeforedelete);

		TextView tvDescription = (TextView)findViewById(R.id.tv_set_savechatmessageterm_description);
		
		SharedPref pref = SharedPref.getInstance(this);
		int nSaveChatMsgTerm = pref.getIntegerPref(SharedPref.PREF_SAVECHATMESSAGETERM, StaticString.CHATMESSAGETERM_3WEEKBEFORE);
		setCheckBoxUI(nSaveChatMsgTerm);
		cb3Week.setOnCheckedChangeListener(this);
		cb2Week.setOnCheckedChangeListener(this);
		cb1Week.setOnCheckedChangeListener(this);
		cb3Day.setOnCheckedChangeListener(this);

		layout3week.setOnClickListener(this);
		layout2week.setOnClickListener(this);
		layout1week.setOnClickListener(this);
		layout3day.setOnClickListener(this);

		tv3week.setText(String.format(getString(R.string.set_savechatmessageterm_delete), App.m_EntryData.m_MultiTenancy.arrMessageValidityPeriods.get(0)));
		tv2week.setText(String.format(getString(R.string.set_savechatmessageterm_delete), App.m_EntryData.m_MultiTenancy.arrMessageValidityPeriods.get(1)));
		tv1week.setText(String.format(getString(R.string.set_savechatmessageterm_delete), App.m_EntryData.m_MultiTenancy.arrMessageValidityPeriods.get(2)));
		tv3day.setText(String.format(getString(R.string.set_savechatmessageterm_delete), App.m_EntryData.m_MultiTenancy.arrMessageValidityPeriods.get(3)));
		tvDescription.setText(String.format(getString(R.string.set_savechatmessageterm_description), App.m_EntryData.m_MultiTenancy.arrMessageValidityPeriods.get(0)));
//		TextView tvTitle = (TextView)findViewById(R.id.tv_setsavechatmessageterm_title);
//		tvTitle.setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.btn_save)
		{
			showSavePopup();
		} else if(nId == R.id.btn_cancel){
			finish();
		} else if(nId == R.id.layout_savechatmessageterm_3weekbeforedelete){
			setCheckBoxUI(StaticString.CHATMESSAGETERM_3WEEKBEFORE);
		} else if(nId == R.id.layout_savechatmessageterm_2weekbeforedelete){
			setCheckBoxUI(StaticString.CHATMESSAGETERM_2WEEKBEFORE);
		} else if(nId == R.id.layout_savechatmessageterm_1weekbeforedelete){
			setCheckBoxUI(StaticString.CHATMESSAGETERM_1WEEKBEFORE);
		} else if(nId == R.id.layout_savechatmessageterm_3daybeforedelete){
			setCheckBoxUI(StaticString.CHATMESSAGETERM_3DAYBEFORE);
		}
		super.onClick(v);
	}
	
	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		// TODO Auto-generated method stub
		int nId = buttonView.getId();
		if(isChecked)
		{
			if(nId == R.id.cb_savechatmessageterm_3weekbeforedelete)
			{
				setCheckBoxUI(StaticString.CHATMESSAGETERM_3WEEKBEFORE);
			}
			else if(nId == R.id.cb_savechatmessageterm_2weekbeforedelete)
			{
				setCheckBoxUI(StaticString.CHATMESSAGETERM_2WEEKBEFORE);
			}
			else if(nId == R.id.cb_savechatmessageterm_1weekbeforedelete)
			{
				setCheckBoxUI(StaticString.CHATMESSAGETERM_1WEEKBEFORE);
			}
			else if(nId == R.id.cb_savechatmessageterm_3daybeforedelete)
			{
				setCheckBoxUI(StaticString.CHATMESSAGETERM_3DAYBEFORE);
			}
		}
		else
		{
			CheckBox cb3Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3weekbeforedelete);
			CheckBox cb2Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_2weekbeforedelete);
			CheckBox cb1Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_1weekbeforedelete);
			CheckBox cb3Day = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3daybeforedelete);
			
			boolean is3WeekChecked = cb3Week.isChecked();
			boolean is2WeekChecked = cb2Week.isChecked();
			boolean is1WeekChecked = cb1Week.isChecked();
			boolean is3DayChecked = cb3Day.isChecked();
			if(!is3WeekChecked && !is2WeekChecked && !is1WeekChecked && !is3DayChecked)
				buttonView.setChecked(true);
		}
	}
	
	private void setCheckBoxUI(int a_nSaveChatMsgTerm)
	{
		CheckBox cb3Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3weekbeforedelete);
		CheckBox cb2Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_2weekbeforedelete);
		CheckBox cb1Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_1weekbeforedelete);
		CheckBox cb3Day = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3daybeforedelete);
		if(a_nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3WEEKBEFORE)
		{
			cb3Week.setChecked(true);
			cb2Week.setChecked(false);
			cb1Week.setChecked(false);
			cb3Day.setChecked(false);
		}
		else if(a_nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_2WEEKBEFORE)
		{
			cb3Week.setChecked(false);
			cb2Week.setChecked(true);
			cb1Week.setChecked(false);
			cb3Day.setChecked(false);
		}
		else if(a_nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_1WEEKBEFORE)
		{
			cb3Week.setChecked(false);
			cb2Week.setChecked(false);
			cb1Week.setChecked(true);
			cb3Day.setChecked(false);
		}
		else if(a_nSaveChatMsgTerm == StaticString.CHATMESSAGETERM_3DAYBEFORE)
		{
			cb3Week.setChecked(false);
			cb2Week.setChecked(false);
			cb1Week.setChecked(false);
			cb3Day.setChecked(true);
		}
	}
	
	private void showSavePopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int nId = v.getId();
				if(nId == R.id.ib_pop_ok)
				{
					saveSaveChatMessageTermSetting();
				}
				CommonPopup popup_ok = (CommonPopup)v.getTag();
				popup_ok.cancel();
				popup_ok.dismiss();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.set_savechatmessageterm_savepopuptitle), getString(R.string.set_savechatmessageterm_savepopupmsg));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
	
	private void saveSaveChatMessageTermSetting()
	{
		CheckBox cb3Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3weekbeforedelete);
		CheckBox cb2Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_2weekbeforedelete);
		CheckBox cb1Week = (CheckBox)findViewById(R.id.cb_savechatmessageterm_1weekbeforedelete);
		CheckBox cb3Day = (CheckBox)findViewById(R.id.cb_savechatmessageterm_3daybeforedelete);
		
		int nTerm = StaticString.CHATMESSAGETERM_3WEEKBEFORE;
		if(cb3Week.isChecked())
			nTerm = StaticString.CHATMESSAGETERM_3WEEKBEFORE;
		else if(cb2Week.isChecked())
			nTerm = StaticString.CHATMESSAGETERM_2WEEKBEFORE;
		else if(cb1Week.isChecked())
			nTerm = StaticString.CHATMESSAGETERM_1WEEKBEFORE;
		else if(cb3Day.isChecked())
			nTerm = StaticString.CHATMESSAGETERM_3DAYBEFORE;
		
		SharedPref pref = SharedPref.getInstance(this);
		pref.setIntegerPref(SharedPref.PREF_SAVECHATMESSAGETERM, nTerm);
		
		finish();
	}
	
	/*private ProgressDlg m_Progress = null;
	
	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}*/
}
