package com.gmp.rusk.extension;

import com.gmp.rusk.utils.CommonLog;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

/**
 * Created by kang on 2017-02-07.
 */

public class EmoticonEx implements PacketExtension {


    public static final String NAMESPACE = "urn:cork:emoticon";
    public static final String ELEMENT_NAME = "info";

    private String emoticonName;


    public EmoticonEx() {
    }

    public EmoticonEx(String emoticonName) {
        this.emoticonName = emoticonName;
    }

    //
    //
    @Override
    public String getElementName() {
        // TODO Auto-generated method stub
        return ELEMENT_NAME;
    }

    @Override
    public String getNamespace() {
        // TODO Auto-generated method stub
        return NAMESPACE;
    }

    public String getEmoticonName() {
        return emoticonName;
    }


    @Override
    public String toXML() {
        // TODO Auto-generated method stub
        StringBuilder buf = new StringBuilder();
        // 1.5.5 에서 규격 수정됨

        // buf.append("<received xmlns='").append(NAMESPACE).append("' id='").append(id).append("'/>");
        return buf.toString();
    }

    public static class Provider implements PacketExtensionProvider {

        public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
            String emoticon = null;
            boolean done = false;
            while (!done) {
                int eventType = parser.getEventType();
                if (eventType == XmlPullParser.START_TAG) {
                    if (parser.getName().equals("name")) {
                        if (parser.getAttributeCount() != -1) {
                            emoticon = parser.nextText();
                        }
                    }
                } else if (eventType == XmlPullParser.END_TAG) {
                    if (parser.getName().equals(ELEMENT_NAME)) {
                        done = true;
                    }
                }
                if (!done)
                    parser.next();
            }
            return new EmoticonEx(emoticon);
        }
    }
}