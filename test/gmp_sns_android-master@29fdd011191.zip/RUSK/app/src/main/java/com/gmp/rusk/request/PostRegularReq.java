package com.gmp.rusk.request;

/**
 *	@author kch
 *			application에 정회원 가입 신청 API.
 *			다른 API가 HTTP Status Code, 202를 반환하면, 가입신청 프로세스를 타야하며, 가입신청 이후 202를 반환하지 않을 것이다.
 *			method : put
 */

public class PostRegularReq extends Req{
	
	private String APINAME = "regular";
	private String AUTHENTIFICATION = "true";
	private final String METHOD = "PUT";
	
	
	public PostRegularReq(int m_nUserNo)
	{
		APINAME = APINAME + "/" + m_nUserNo;
	}

	public String getAPIName()
	{
		return APINAME;
	}
	
	public String getMethod()
	{
		return METHOD;
	}

	@Override
	public String getJsonData() {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public String getParamData() {
		// TODO Auto-generated method stu
		return null;
	}

	@Override
	public String getNameValuePair() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIsAuthentification() {
		// TODO Auto-generated method stub
		return AUTHENTIFICATION;
	}
}
