package com.gmp.rusk.act;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.SharedPref;
import com.gmp.rusk.utils.StaticString;

/**
 * Created by K on 2016-09-05.
 */
public class SetTextSizeAct extends CustomActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    ImageView m_ivTextSizePreview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.act_set_textsize);

        initUI();
    }

    private void initUI(){
        ImageView btnClose = (ImageView) findViewById(R.id.btn_cancel);
        btnClose.setOnClickListener(this);
        ImageView btnSave = (ImageView) findViewById(R.id.btn_save);
        btnSave.setOnClickListener(this);
        m_ivTextSizePreview = (ImageView)findViewById(R.id.iv_textsize_preview);
        CheckBox cbSmall = (CheckBox)findViewById(R.id.cb_settextsize_small);
        CheckBox cbNormal = (CheckBox)findViewById(R.id.cb_settextsize_normal);
        CheckBox cbBig = (CheckBox)findViewById(R.id.cb_settextsize_big);

        LinearLayout layoutSmall = (LinearLayout)findViewById(R.id.layout_settextsize_small);
        LinearLayout layoutNormal = (LinearLayout)findViewById(R.id.layout_settextsize_normal);
        LinearLayout layoutBig = (LinearLayout)findViewById(R.id.layout_settextsize_big);
        layoutSmall.setOnClickListener(this);
        layoutNormal.setOnClickListener(this);
        layoutBig.setOnClickListener(this);

        SharedPref pref = SharedPref.getInstance(this);
        int nSaveTextSize = pref.getIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, StaticString.SETTEXTSIZE_SMALL);
        setCheckBoxUI(nSaveTextSize);
        cbSmall.setOnCheckedChangeListener(this);
        cbNormal.setOnCheckedChangeListener(this);
        cbBig.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int nId = buttonView.getId();
        if(isChecked)
        {
            if(nId == R.id.cb_settextsize_small)
            {
                setCheckBoxUI(StaticString.SETTEXTSIZE_SMALL);
            }
            else if(nId == R.id.cb_settextsize_normal)
            {
                setCheckBoxUI(StaticString.SETTEXTSIZE_NORMAL);
            }
            else if(nId == R.id.cb_settextsize_big)
            {
                setCheckBoxUI(StaticString.SETTEXTSIZE_BIG);
            }

        }
        else
        {
            CheckBox cbSmall = (CheckBox)findViewById(R.id.cb_settextsize_small);
            CheckBox cbNormal = (CheckBox)findViewById(R.id.cb_settextsize_normal);
            CheckBox cbBig = (CheckBox)findViewById(R.id.cb_settextsize_big);

            boolean isSmall = cbSmall.isChecked();
            boolean isNormal = cbNormal.isChecked();
            boolean isBig = cbBig.isChecked();
            if(!isSmall && !isNormal && !isBig)
                buttonView.setChecked(true);
        }
    }

    @Override
    public void onClick(View v) {
        int nId = v.getId();
        if(nId == R.id.btn_save)
        {
            saveSaveTextSize();
        } else if(nId == R.id.btn_cancel){
           finish();
        } else if(nId == R.id.layout_settextsize_small){
            setCheckBoxUI(StaticString.SETTEXTSIZE_SMALL);
        } else if(nId == R.id.layout_settextsize_normal){
            setCheckBoxUI(StaticString.SETTEXTSIZE_NORMAL);
        } else if(nId == R.id.layout_settextsize_big){
            setCheckBoxUI(StaticString.SETTEXTSIZE_BIG);
        }
        super.onClick(v);
    }

    private void setCheckBoxUI(int a_nSaveTextSize)
    {
        CheckBox cbSmall = (CheckBox)findViewById(R.id.cb_settextsize_small);
        CheckBox cbNormal = (CheckBox)findViewById(R.id.cb_settextsize_normal);
        CheckBox cbBig = (CheckBox)findViewById(R.id.cb_settextsize_big);
        if(a_nSaveTextSize == StaticString.SETTEXTSIZE_SMALL)
        {
            m_ivTextSizePreview.setBackgroundResource(R.drawable.img_size_s);
            cbSmall.setChecked(true);
            cbNormal.setChecked(false);
            cbBig.setChecked(false);
        }
        else if(a_nSaveTextSize == StaticString.SETTEXTSIZE_NORMAL)
        {
            m_ivTextSizePreview.setBackgroundResource(R.drawable.img_size_m);
            cbSmall.setChecked(false);
            cbNormal.setChecked(true);
            cbBig.setChecked(false);
        }
        else if(a_nSaveTextSize == StaticString.SETTEXTSIZE_BIG)
        {
            m_ivTextSizePreview.setBackgroundResource(R.drawable.img_size_b);
            cbSmall.setChecked(false);
            cbNormal.setChecked(false);
            cbBig.setChecked(true);
        }
    }

    private void saveSaveTextSize()
    {
        CheckBox cbSmall = (CheckBox)findViewById(R.id.cb_settextsize_small);
        CheckBox cbNormal = (CheckBox)findViewById(R.id.cb_settextsize_normal);
        CheckBox cbBig = (CheckBox)findViewById(R.id.cb_settextsize_big);

        int nTextSize = StaticString.SETTEXTSIZE_SMALL;
        if(cbSmall.isChecked())
            nTextSize = StaticString.SETTEXTSIZE_SMALL;
        else if(cbNormal.isChecked())
            nTextSize = StaticString.SETTEXTSIZE_NORMAL;
        else if(cbBig.isChecked())
            nTextSize = StaticString.SETTEXTSIZE_BIG;

        SharedPref pref = SharedPref.getInstance(this);
        pref.setIntegerPref(SharedPref.PREF_SET_SAVETEXTSIZE, nTextSize);

        finish();
    }
}
