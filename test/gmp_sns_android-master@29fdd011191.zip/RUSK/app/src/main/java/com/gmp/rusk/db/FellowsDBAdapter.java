package com.gmp.rusk.db;

import java.util.ArrayList;

import com.gmp.rusk.datamodel.FellowListData;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;

public class FellowsDBAdapter {
	
	// Database File Name
	private static final String DATABASE_NAME 		= "ttalk_fellows.db";
		
	// Fellows Table Name
	private static final String TABLE_FELLOWS		= "Fellows";
	
	// Fellows Table Field Name
	public static final String KEY_FELLOWS_USERID				= "userId";				// User Id
	public static final String KEY_FELLOWS_USERTYPE				= "userType";			// 사용자 유형 R:정직원 P:파트너
	public static final String KEY_FELLOWS_NAME					= "name";				// 이름
	public static final String KEY_FELLOWS_PARENTDEPARTMENT		= "parentdepartment";			// 소속
	public static final String KEY_FELLOWS_DEPARTMENT			= "department";				// 부서
	public static final String KEY_FELLOWS_CHARGE				= "charge";				// 직책
	public static final String KEY_FELLOWS_HASTHUMB				= "hasThumb";			// Thumbnail 유/무
	public static final String KEY_FELLOWS_ISAPPINSTALLED		= "isAppInstalled";		// Application 설치 유/무
//	public static final String KEY_FELLOWS_USERSTATUS			= "userStatus";			// 사용자 상태(A:정상, W:탈퇴, C:승인취소파트너)
	
	// Create Table Query
	private final String FELLOWS_CREATE = "create table " + TABLE_FELLOWS + " (" + 
												KEY_FELLOWS_USERID 				+ " integer primary key , " +
												KEY_FELLOWS_USERTYPE			+ " text, " +
												KEY_FELLOWS_NAME 				+ " text not null, " +
												KEY_FELLOWS_PARENTDEPARTMENT	+ " text not null, " +
												KEY_FELLOWS_DEPARTMENT			+ " text not null, " +
												KEY_FELLOWS_CHARGE 				+ " text not null, " +
												KEY_FELLOWS_HASTHUMB			+ " integer not null, " +
												KEY_FELLOWS_ISAPPINSTALLED 		+ " integer not null);";
//												KEY_FELLOWS_ISAPPINSTALLED 		+ " integer not null, " +
//												KEY_FELLOWS_USERSTATUS			+ " text not null);";
	
	// Drop Table Query 
	private final String FELLOWS_DROP = "DROP TABLE IF EXISTS " + TABLE_FELLOWS;
	
	private SQLiteDatabase m_db = null;
	private final Context m_context;
	private FellowsDBHelper m_dbHelper = null;
	
	public FellowsDBAdapter(Context context)
	{
		m_context = context;
		m_dbHelper = new FellowsDBHelper(m_context, DATABASE_NAME, null, DatabaseDefine.DATABASE_VERSION);
	}
	
	// Database Open Read & Write Permission
	public FellowsDBAdapter open() throws SQLException
	{
		m_db = m_dbHelper.getWritableDatabase();
		return this;
	}
	
	// Database Open Read Permission
	public FellowsDBAdapter openReadOnly() throws SQLException
	{
		m_db = m_dbHelper.getReadableDatabase();
		return this;
	}
	
	// Database Close
	public void close()
	{
		m_db.close();
	}
	
	/**
	 * insertFellows
	 * 동료 Array 추가 Query
	 * @param a_arrFellowListData	FellowListData ArrayList : 추가할 동료 ArrayList
	 * @return int insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertFellows(ArrayList<FellowListData> a_arrFellowListData)
	{
		int nCount = 0;
		
		if(a_arrFellowListData == null || a_arrFellowListData.size() == 0)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			for(FellowListData data : a_arrFellowListData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_FELLOWS_USERID, data.m_nUserNo);
				value.put(KEY_FELLOWS_USERTYPE, data.m_strUserType);
				value.put(KEY_FELLOWS_NAME, data.m_strName);
				value.put(KEY_FELLOWS_PARENTDEPARTMENT, data.m_strParentDepartment);
				value.put(KEY_FELLOWS_DEPARTMENT, data.m_strDepartment);
				value.put(KEY_FELLOWS_CHARGE, data.m_strCharge);
				if(data.m_isImageAvailable)
					value.put(KEY_FELLOWS_HASTHUMB, 1);		//
				else
					value.put(KEY_FELLOWS_HASTHUMB, 0);
				if(data.m_isActive)
					value.put(KEY_FELLOWS_ISAPPINSTALLED, 1);
				else
					value.put(KEY_FELLOWS_ISAPPINSTALLED, 0);
					
//				value.put(KEY_FELLOWS_USERSTATUS, data.m_strUserStatus);
				
				m_db.insert(TABLE_FELLOWS, null, value);
				nCount++;
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * insertFellows 
	 * 동료 단일 추가 Insert Query
	 * @param a_fellowListData FellowListData : 추가할 FellowListData 
	 * @return insert 성공한 개수, 0보다 작으면 에러 
	 */
	public int insertFellows(FellowListData a_fellowListData)
	{
		int nCount = 0;
		
		if(a_fellowListData == null)
			return 0;
		
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_FELLOWS_USERID, a_fellowListData.m_nUserNo);
			value.put(KEY_FELLOWS_USERTYPE, a_fellowListData.m_strUserType);
			value.put(KEY_FELLOWS_NAME, a_fellowListData.m_strName);
			value.put(KEY_FELLOWS_PARENTDEPARTMENT, a_fellowListData.m_strParentDepartment);
			value.put(KEY_FELLOWS_DEPARTMENT, a_fellowListData.m_strDepartment);
			value.put(KEY_FELLOWS_CHARGE, a_fellowListData.m_strCharge);
			if(a_fellowListData.m_isImageAvailable)
				value.put(KEY_FELLOWS_HASTHUMB, 1);
			else
				value.put(KEY_FELLOWS_HASTHUMB, 0);
			if(a_fellowListData.m_isActive)
				value.put(KEY_FELLOWS_ISAPPINSTALLED, 1);
			else
				value.put(KEY_FELLOWS_ISAPPINSTALLED, 0);
				
//			value.put(KEY_FELLOWS_USERSTATUS, a_fellowListData.m_strUserStatus);
			
			m_db.insert(TABLE_FELLOWS, null, value);
			nCount++;
			
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateFellows
	 * 동료 Array Update Query 
	 * FellowListData.m_nUserNo로 비교하여 Update를 수행
	 * @param a_fellowListData FellowListData ArrayList : Update 할 FellowListData의 ArrayList
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateFellows(ArrayList<FellowListData> a_arrFellowListData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			for(FellowListData data : a_arrFellowListData)
			{
				ContentValues value = new ContentValues();
				value.put(KEY_FELLOWS_NAME, data.m_strName);
				value.put(KEY_FELLOWS_USERTYPE, data.m_strUserType);
				value.put(KEY_FELLOWS_PARENTDEPARTMENT, data.m_strParentDepartment);
				value.put(KEY_FELLOWS_DEPARTMENT, data.m_strDepartment);
				value.put(KEY_FELLOWS_CHARGE, data.m_strCharge);
				if(data.m_isImageAvailable)
					value.put(KEY_FELLOWS_HASTHUMB, 1);		//
				else
					value.put(KEY_FELLOWS_HASTHUMB, 0);
				if(data.m_isActive)
					value.put(KEY_FELLOWS_ISAPPINSTALLED, 1);
				else
					value.put(KEY_FELLOWS_ISAPPINSTALLED, 0);
					
//				value.put(KEY_FELLOWS_USERSTATUS, data.m_strUserStatus);
				
				nCount = m_db.update(TABLE_FELLOWS, value, KEY_FELLOWS_USERID + "=" + data.m_nUserNo, null);
			}
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * updateFellows
	 * 동료 단일 Update Query 
	 * FellowListData.m_nUserNo로 비교하여 Update를 수행
	 * @param a_fellowListData FellowListData : Update 할 FellowListData
	 * @return int Update 한 개수, 0보다 작으면 에러 
	 */
	public int updateFellows(FellowListData a_fellowListData)
	{
		int nCount = 0;
		try
		{
			m_db.beginTransaction();
			
			ContentValues value = new ContentValues();
			value.put(KEY_FELLOWS_NAME, a_fellowListData.m_strName);
			value.put(KEY_FELLOWS_USERTYPE, a_fellowListData.m_strUserType);
			value.put(KEY_FELLOWS_PARENTDEPARTMENT, a_fellowListData.m_strParentDepartment);
			value.put(KEY_FELLOWS_DEPARTMENT, a_fellowListData.m_strDepartment);
			value.put(KEY_FELLOWS_CHARGE, a_fellowListData.m_strCharge);
			if(a_fellowListData.m_isImageAvailable)
				value.put(KEY_FELLOWS_HASTHUMB, 1);		//
			else
				value.put(KEY_FELLOWS_HASTHUMB, 0);
			if(a_fellowListData.m_isActive)
				value.put(KEY_FELLOWS_ISAPPINSTALLED, 1);
			else
				value.put(KEY_FELLOWS_ISAPPINSTALLED, 0);
				
//			value.put(KEY_FELLOWS_USERSTATUS, a_fellowListData.m_strUserStatus);
			
			nCount += m_db.update(TABLE_FELLOWS, value, KEY_FELLOWS_USERID + "=" + a_fellowListData.m_nUserNo, null);
			m_db.setTransactionSuccessful();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			nCount = -1;
		}
		finally{
			m_db.endTransaction();
		}
		
		return nCount;
	}
	
	/**
	 * deleteFellows
	 * 동료 전체 삭제
	 * @return int 삭제한 개수
	 */
	public int deleteFellows()
	{
		return m_db.delete(TABLE_FELLOWS, null, null);
	}
	
	/**
	 * deleteFellows
	 * 동료 단일 삭제
	 * @param a_nUserId 삭제할 UserId
	 * @return int 삭제한 개수
	 */
	public int deleteFellows(int a_nUserId)
	{
		return m_db.delete(TABLE_FELLOWS, KEY_FELLOWS_USERID + "=" + a_nUserId, null);
	}
	
	/**
	 * getFellowsList
	 * 동료 가져오기
	 * @return DB Cursor
	 */
	public Cursor getFellowsList()
	{
		return m_db.query(TABLE_FELLOWS, null, null, null, null, null, null);
	}
	
	public Cursor getFellows(int a_nUserId)
	{
		return m_db.query(TABLE_FELLOWS, null, KEY_FELLOWS_USERID + "=" + a_nUserId, null, null, null, null);
	}
		
	// SQLite Open Helper Class
	private class FellowsDBHelper extends SQLiteOpenHelper
	{

		public FellowsDBHelper(Context context, String name,
				CursorFactory factory, int version) {
			super(context, name, factory, version);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(FELLOWS_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			// Database Version Update 시 기존 데이터 백업에 대해 고려하여 Drop/Create 구현해야 함
			db.execSQL(FELLOWS_DROP);
			onCreate(db);
		}
	}
}
