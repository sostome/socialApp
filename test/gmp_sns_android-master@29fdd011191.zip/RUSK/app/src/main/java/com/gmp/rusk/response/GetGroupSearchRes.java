package com.gmp.rusk.response;

public class GetGroupSearchRes extends ChannelRes{


	public GetGroupSearchRes(String a_strData, String a_strType) {
		super(a_strData, a_strType);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub

	}


}
