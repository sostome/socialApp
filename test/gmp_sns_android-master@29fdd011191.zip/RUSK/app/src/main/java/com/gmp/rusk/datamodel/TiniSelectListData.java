package com.gmp.rusk.datamodel;

/**
 * Created by kang on 2017-03-06.
 */

public class TiniSelectListData {

    public String m_strMsgId;
    public String m_strSelectList;
}
