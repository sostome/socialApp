package com.gmp.rusk.response;

import android.graphics.Bitmap;

import com.gmp.rusk.datamodel.SNSBoardFileData;
import com.gmp.rusk.datamodel.SNSBoardReplyData;
import com.gmp.rusk.datamodel.SNSReplyData;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.Utils;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.StringBody;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

public class PostGroupBoardReplyRes extends ChannelRes{

	private final String JSON_COMMENTNO				= "commentNo";

	public int m_nCommentNo = 0;
	public PostGroupBoardReplyRes(String a_strData) {
		super(a_strData);
		// TODO Auto-generated constructor stub
		parseData();
	}

	@Override
	public void parseData() {
		// TODO Auto-generated method stub
		try {
			JSONObject jsonObj = new JSONObject(m_strResData);
			m_nCommentNo = jsonObj.getInt(JSON_COMMENTNO);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public int getCommentNo() {
		return m_nCommentNo;
	}

}
