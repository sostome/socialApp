package com.gmp.rusk.datamodel;

public class UserUpdateListData {
	public int m_nUserNo = 0;						//사용자 번호
	public PersonalData m_PersonalData;
	public String m_strUserType = "";				//사용자 유형 R:정직원 P:파트너
	public boolean m_isImageAvailable = false;		//이미지 보유 여부
	public boolean m_isActive = false;				//사용자 앱 설치 유무
	public String m_strUserStatus = "";				//사용자 상태 A.정상 W.탈퇴 C.승인취소된 파트너
	public String m_strGreeting = "";

	public UserUpdateListData(int a_nUserNo, PersonalData a_PersonalData, String a_strUserType, boolean a_isImageAvailable, boolean a_isActive, String a_strGreeting,
			String a_strUserStatus) {
		m_nUserNo = a_nUserNo;
		m_PersonalData = a_PersonalData;
		m_strUserType = a_strUserType;
		m_isImageAvailable = a_isImageAvailable;
		m_isActive = a_isActive;
		m_strUserStatus = a_strUserStatus;
		m_strGreeting = a_strGreeting;
	}
}
