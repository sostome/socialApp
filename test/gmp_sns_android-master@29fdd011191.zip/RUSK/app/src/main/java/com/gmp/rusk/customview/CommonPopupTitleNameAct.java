package com.gmp.rusk.customview;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.datamodel.ChattingRoomInfoData;
import com.gmp.rusk.db.TTalkDBManager.RoomDBManager;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.LocalAesCrypto;

public class CommonPopupTitleNameAct extends CustomActivity{

	private int m_nBtnType = 0;
	private String m_strTitle = "";
	private String m_strBody = "";
	private String m_strRoomID = "";
	EditText m_etPop_edit;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

		setContentView(R.layout.act_popup_common_title_name);
		// select UserNo 가져 오는 부분 구현
		Bundle bundle = getIntent().getExtras();

		if (bundle != null){
			m_nBtnType = bundle.getInt(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BTNTYPE);
			m_strTitle = bundle.getString(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_TITLE, getString(R.string.pop_error_title));
			m_strBody = bundle.getString(IntentKeyString.INTENT_KEY_COMMON_POPUPACT_BODY, "");
			m_strRoomID = bundle.getString(IntentKeyString.INTENT_KEY_ROOM_ID, "");
		}

		TextView tv_pop_title = (TextView)findViewById(R.id.tv_pop_title);
		tv_pop_title.setText(m_strTitle);

		TextView tv_pop_body = (TextView)findViewById(R.id.tv_pop_body);
		tv_pop_body.setText(m_strBody);

		m_etPop_edit = (EditText)findViewById(R.id.et_pop_edit);


		if(m_nBtnType == CommonPopupBtnTypeInt.POP_BTNTYPE_YES)
		{
			LinearLayout layout_one_btn = (LinearLayout)findViewById(R.id.layout_one_btn);
			layout_one_btn.setVisibility(View.VISIBLE);

			ImageButton ib_pop_ok_long = (ImageButton) findViewById(R.id.ib_pop_ok_long);
			ib_pop_ok_long.setOnClickListener(this);
		}
		else if(m_nBtnType == CommonPopupBtnTypeInt.POP_BTNTYPE_YESNO)
		{
			LinearLayout layout_two_btn = (LinearLayout)findViewById(R.id.layout_two_btn);
			layout_two_btn.setVisibility(View.VISIBLE);

			Button ib_pop_ok = (Button) findViewById(R.id.ib_pop_ok);
			ib_pop_ok.setOnClickListener(this);

			Button ib_pop_cancel = (Button) findViewById(R.id.ib_pop_cancel);
			ib_pop_cancel.setOnClickListener(this);
		}
		//방제목이 변경 된 적이 있다면 해당 제목을 먼저 표시

		//기존에는 DB에만 저장 하였음.
		ChattingRoomInfoData roomData = RoomDBManager.getChattingRoom(this, m_strRoomID);
		if (roomData.m_isTitleEdited) {
			try {
				LocalAesCrypto crypto = new LocalAesCrypto();
				m_etPop_edit.setText(crypto.decrypt(roomData.m_strRoomTitle));
				m_etPop_edit.setSelection(m_etPop_edit.getText().toString().length());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
//		super.onBackPressed();
	}

	@Override
	public void onClick(View v) {
		super.onClick(v);
		// TODO Auto-generated method stub
		if(v.getId() == R.id.ib_pop_ok_long)
		{
			
		}
		else if(v.getId() == R.id.ib_pop_ok)
		{
			if(m_etPop_edit.getText().toString().length() != 0 && m_etPop_edit.getText().toString().trim().length() == 0){
				Intent intent = new Intent();

				setResult(RESULT_CANCELED, intent);
				finish();
			} else {
				Intent intent = new Intent();
				intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_ID, m_strRoomID);
				intent.putExtra(IntentKeyString.INTENT_KEY_ROOM_CHANGE_TITLE, m_etPop_edit.getText().toString());
				setResult(RESULT_OK, intent);
				finish();
			}
		}
		else if(v.getId() == R.id.ib_pop_cancel)
		{
			Intent intent = new Intent();
			
			setResult(RESULT_CANCELED, intent);
			finish();
		}
	}
	
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub

		Rect dialogBounds = new Rect();
		getWindow().getDecorView().getHitRect(dialogBounds);
		if (!dialogBounds.contains((int) ev.getX(), (int) ev.getY())) {
			return false;
		}
		return super.dispatchTouchEvent(ev);
	}
}
