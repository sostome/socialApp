package com.gmp.rusk.utils;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;


import com.gmp.rusk.MyApp;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 
 * @author kurt
 */
public class LocalAesCrypto {

	public MyApp App = MyApp.getInstance();

	private SecretKeySpec m_skeySpec;
	private Cipher m_cipher;

	public LocalAesCrypto() throws Exception 
	{
		byte[] keyByte = App.m_EntryData.m_strLol.getBytes("utf-8");
//		System.arraycopy(keyByte, 0, defaultKey, 0,
//				((keyByte.length < 16) ? keyByte.length : 16));
		
		m_skeySpec = new SecretKeySpec(keyByte, "AES");
		m_cipher = Cipher.getInstance("AES"); // /ECB/PKCS7Padding", "SC");
	}

	public LocalAesCrypto(SecretKeySpec key) throws Exception{
		m_skeySpec = key;
		m_cipher = Cipher.getInstance("AES"); // /ECB/PKCS7Padding", "SC");
	}
	
	public String decrypt(String encrypted) throws Exception {
		byte[] result = decrypt(Base64.decode(encrypted.getBytes(), Base64.NO_WRAP));
		return new String(result);
	}
	
	private byte[] decrypt(byte[] encrypted)
			throws Exception {
		m_cipher.init(Cipher.DECRYPT_MODE, m_skeySpec);
		byte[] decrypted = m_cipher.doFinal(encrypted);
		return decrypted;
	}
	
	public String encrypt(String cleartext) throws Exception {
		byte[] result = encrypt(cleartext.getBytes("utf-8"));
		String resultBase64 = new String(Base64.encode(result, Base64.NO_WRAP));
		return resultBase64;
	}
	
	@SuppressLint("TrulyRandom")
	private  byte[] encrypt(byte[] clear) throws Exception {
		m_cipher.init(Cipher.ENCRYPT_MODE, m_skeySpec);
		byte[] encrypted = m_cipher.doFinal(clear);
		return encrypted;
	}

}


//다른쪽에 있던 코드
/*
public class AesCrypto {
	MyApp App = MyApp.getInstance();
	private final static byte[] defaultKey = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0 };

	private static SecretKeySpec skeySpec;
	private static Cipher cipher;

	public AesCrypto() throws Exception
	{

		//byte[] keyByte = App.m_EntryData.m_strLol.getBytes("utf-8");
		System.arraycopy(keyByte, 0, defaultKey, 0,
				((keyByte.length < 16) ? keyByte.length : 16));
		skeySpec = new SecretKeySpec(keyByte, "AES");
		cipher = Cipher.getInstance("AES/ECB/PKCS7Padding"); // /ECB/PKCS7Padding", "SC");
		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
	}

	public static String decrypt(String encrypted) throws Exception {
		byte[] result = decrypt(Base64.decode(encrypted.getBytes(), Base64.NO_WRAP));
		return new String(result);
	}

	private static byte[] decrypt(byte[] encrypted)
			throws Exception {
		byte[] decrypted = cipher.doFinal(encrypted);
		return decrypted;
	}

	public static String encrypt(String cleartext) throws Exception {
		byte[] result = encrypt(cleartext.getBytes("utf-8"));
		String resultBase64 = new String(Base64.encode(result, Base64.NO_WRAP));
		return resultBase64;
	}

	@SuppressLint("TrulyRandom")
	private static byte[] encrypt(byte[] clear) throws Exception {
		byte[] encrypted = cipher.doFinal(clear);
		return encrypted;
	}
}*/
