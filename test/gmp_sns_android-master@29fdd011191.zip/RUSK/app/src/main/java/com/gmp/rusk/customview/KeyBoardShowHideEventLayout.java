package com.gmp.rusk.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class KeyBoardShowHideEventLayout extends RelativeLayout{
	
	private boolean m_isKeyBoardShown = false;
	private OnKeyBoardEvent m_onKeyBoardEvent = null;
	
	private int m_nMaxProposedHeight = 0;
	
	public KeyBoardShowHideEventLayout(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
	
	public KeyBoardShowHideEventLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	public KeyBoardShowHideEventLayout(Context context, AttributeSet attrs,
			int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}
	
	public void setOnKeyBoardEvent(OnKeyBoardEvent a_onKeyBoardEvent)
	{
		m_onKeyBoardEvent = a_onKeyBoardEvent;
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
	    final int proposedheight = MeasureSpec.getSize(heightMeasureSpec);

	    if(proposedheight >= m_nMaxProposedHeight)
	    {
	        // Keyboard is hidden
			if(m_nMaxProposedHeight == 0)
	    		m_nMaxProposedHeight = proposedheight;
	    	m_isKeyBoardShown = false;
	    }
	    else {
	        // Keyboard is shown
	    	m_isKeyBoardShown = true;
	    }
	    
	    if(m_onKeyBoardEvent != null)
    		m_onKeyBoardEvent.onKeyBoardEvent(m_isKeyBoardShown);
	    
//	    final int actualHeight = getHeight();
	    
	    
//	    DisplayMetrics metrics = Utils.getDisplayMetrics(getContext());
//	    CommonLog.e(KeyBoardShowHideEventLayout.class.getSimpleName(), "deviceWidth : " + metrics.widthPixels);
//	    CommonLog.e(KeyBoardShowHideEventLayout.class.getSimpleName(), "deviceHeight : " + metrics.heightPixels);
//	    CommonLog.e(KeyBoardShowHideEventLayout.class.getSimpleName(), "proposedheight : " + proposedheight);
//	    CommonLog.e(KeyBoardShowHideEventLayout.class.getSimpleName(), "actualHeight : " + actualHeight);
//	    
//	    if (actualHeight > proposedheight){
//	        // Keyboard is shown
//	    	m_isKeyBoardShown = true;
//	    	if(m_onKeyBoardEvent != null)
//	    		m_onKeyBoardEvent.onKeyBoardEvent(m_isKeyBoardShown);
//	    } else {
//	        // Keyboard is hidden
//	    	m_isKeyBoardShown = false;
//	    	if(m_onKeyBoardEvent != null)
//	    		m_onKeyBoardEvent.onKeyBoardEvent(m_isKeyBoardShown);
//	    }

	    super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}
	
	public interface OnKeyBoardEvent
	{
		public void onKeyBoardEvent(boolean a_isKeyBoardShown);
	}
}
