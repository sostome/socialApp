package com.gmp.rusk.fragment;

import java.util.ArrayList;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.R;
import com.gmp.rusk.act.ProfileViewPopupAct;
import com.gmp.rusk.act.SNSGroupMemberListAct;
import com.gmp.rusk.datamodel.PersonalData;
import com.gmp.rusk.datamodel.SNSGroupMemberData;
import com.gmp.rusk.datamodel.UserListData;
import com.gmp.rusk.db.TTalkDBManager;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.imageloader.ImageLoaderManager;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeleteGroupUserCancelReq;
import com.gmp.rusk.request.PutGroupUserReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;
import com.gmp.rusk.utils.IntentKeyString;
import com.gmp.rusk.utils.StaticString;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SNSGroupInvitingMemberListFrag extends Fragment implements OnItemClickListener{

	public MyApp App = MyApp.getInstance();
	private View m_vList = null;
	private ArrayList<Integer> m_arrUnInviteMember = null;
	//private ArrayList<SNSGroupMemberData> m_arrCanceledMember = null;
	
	private InvitingMemberListAdapter m_adapterInvitingMemberList = null;
	private ProgressDlg m_Progress = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		m_vList = inflater.inflate(R.layout.fragact_snsgroupmemberlist_member, container, false);
		getInvitingMember();
		initUI();
		return m_vList;
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(requestCode == StaticString.REQUESTCODE_PROFILEVIEW)
		{
			if(resultCode == StaticString.RESULT_PROFILE_NOTIFYCHANGE_IMAGE)
			{
				if(m_adapterInvitingMemberList != null)
					m_adapterInvitingMemberList.notifyDataSetChanged();
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	
	private void getInvitingMember()
	{
		m_arrUnInviteMember = ((SNSGroupMemberListAct) getActivity()).getUnInvitedMember();
		//m_arrCanceledMember = ((SNSGroupMemberListAct) getActivity()).getCanceledMember();
	}
	
	private void initUI()
	{
		TextView tvSection = (TextView)m_vList.findViewById(R.id.tv_snsgroupmemberlist_section);
		int nCount = (m_arrUnInviteMember == null ? 0 : m_arrUnInviteMember.size());
		tvSection.setText(String.format(getString(R.string.snsgroupmemberlist_invitingmember_countformat), nCount));
		
		ListView lvInvitingMemberList = (ListView)m_vList.findViewById(R.id.lv_snsgroupmemberlist_memberlist);
		m_adapterInvitingMemberList = new InvitingMemberListAdapter();
		lvInvitingMemberList.setAdapter(m_adapterInvitingMemberList);
		lvInvitingMemberList.setOnItemClickListener(this);
	}
	
	private void doShowProfile(int a_nUserNo)
	{
		Intent intent = new Intent(getActivity(), ProfileViewPopupAct.class);
		//intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		intent.putExtra(IntentKeyString.INTENT_KEY_USERNO, a_nUserNo);
		startActivityForResult(intent, StaticString.REQUESTCODE_PROFILEVIEW);
	}
	
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub
		
		int nUserNo = (Integer)m_adapterInvitingMemberList.getItem(position);
		doShowProfile(nUserNo);
	}
	
	private class InvitingMemberListAdapter extends BaseAdapter
	{
		private final int ITEMTYPE_UNINVITED = 0;
		private final int ITEMTYPE_CANCELED = 1;
		
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return (m_arrUnInviteMember == null ? 0 : m_arrUnInviteMember.size());
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return m_arrUnInviteMember.get(position);
		}
		
		private int getItemType(int position)
		{
			int nUnInvitedSize = m_arrUnInviteMember == null ? 0 : m_arrUnInviteMember.size();
			if(position < nUnInvitedSize)
				return ITEMTYPE_UNINVITED;
			else
				return ITEMTYPE_CANCELED;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			final int nPosition = position;
			if(convertView == null)
			{
				LayoutInflater li = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = li.inflate(R.layout.layout_snsgroupmemberlist_listitem_member, parent, false);
			}
			
			final int nUserNo = (Integer)getItem(position);
			final int nItemType = getItemType(position);
			
			ImageView ivPic = (ImageView)convertView.findViewById(R.id.iv_snsgroupmemberlist_listitem_member_pic);
			ImageView ivPicNotFellow = (ImageView)convertView.findViewById(R.id.iv_snsgroupmemberlist_listitem_member_pic_notfellow);
			ImageView ivFrame = (ImageView)convertView.findViewById(R.id.iv_snsgroupmemberlist_listitem_member_frame);
			TextView tvName = (TextView)convertView.findViewById(R.id.tv_snsgroupmemberlist_listitem_member_name);
			ImageView ivPartnerIcon = (ImageView) convertView.findViewById(R.id.iv_chatlist_icon_partner);
			
			if(nItemType == ITEMTYPE_UNINVITED)
			{
				convertView.setBackgroundResource(R.drawable.chatroom_listitem_selecter);
				ivFrame.setBackgroundResource(R.drawable.sel_profile_pic_frame);
			}
			else
			{
				convertView.setBackgroundResource(R.drawable.chatroom_listitem_selecter);
				ivFrame.setBackgroundResource(R.drawable.profile_pic_frame_reject);
			}

			ImageLoaderManager imageLoaderMng = ImageLoaderManager.getInstance(getActivity());
			imageLoaderMng.getProfileImage(ivPic, App.getImageDownLoaderUrl(nUserNo, false), R.drawable.profile_pic_default, false);
			UserListData userData = TTalkDBManager.ContactsDBManager.getContacts(getContext(), nUserNo);

			if(userData.m_strUserType.equals(StaticString.VARIANT_REGULAR))
				ivPartnerIcon.setVisibility(View.GONE);
			else
				ivPartnerIcon.setVisibility(View.VISIBLE);

			tvName.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.NAME));
			LinearLayout layout_position = (LinearLayout) convertView.findViewById(R.id.layout_position);
			TextView tv_position = (TextView) convertView.findViewById(R.id.tv_position);
			LinearLayout layout_charge = (LinearLayout) convertView.findViewById(R.id.layout_charge);
			TextView tv_charge = (TextView) convertView.findViewById(R.id.tv_charge);
			TextView tv_uninstall = (TextView) convertView.findViewById(R.id.tv_uninstall);
			if(userData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && userData.m_PersonalData.mapPersonalData.get(PersonalData.POSITION) !=null && !userData.m_PersonalData.mapPersonalData.get(PersonalData.POSITION).equals("")){
				layout_position.setVisibility(View.VISIBLE);
				tv_position.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.POSITION));
			} else {
				layout_position.setVisibility(View.GONE);
			}

			if(userData.m_strUserType.equals(StaticString.VARIANT_REGULAR) && userData.m_PersonalData.mapPersonalData.get(PersonalData.CHARGE)!=null && !userData.m_PersonalData.mapPersonalData.get(PersonalData.CHARGE).equals("")){
				layout_charge.setVisibility(View.VISIBLE);
				tv_charge.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.CHARGE));
			} else {
				layout_charge.setVisibility(View.GONE);
			}

			if (userData.m_isActive) {
				tv_uninstall.setVisibility(View.GONE);
			} else {
				tv_uninstall.setVisibility(View.VISIBLE);
			}

			TextView tv_departments = (TextView) convertView.findViewById(R.id.tv_snsgroupmemberlist_listitem_member_departments);


			if (userData.m_strUserType.equals("R")) {
				tv_departments.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.DEPARTMENT)+" | "+userData.m_PersonalData.mapPersonalData.get(PersonalData.COMPANY_NAME));
			} else {
				tv_departments.setText(userData.m_PersonalData.mapPersonalData.get(PersonalData.AFFILIATION));
			}
			ivPicNotFellow.setVisibility(View.GONE);

			RelativeLayout layoutButton = (RelativeLayout)convertView.findViewById(R.id.layout_snsgroupmemberlist_listitem_member_btn);
			
			boolean isOwnered = ((SNSGroupMemberListAct)getActivity()).isOwnered();
			
			if(isOwnered)
			{
				layoutButton.setVisibility(View.VISIBLE);

				Button btnInviteCancel = (Button)convertView.findViewById(R.id.btn_snsgroupmemberlist_listitem_member_invitecancel);
				
				btnInviteCancel.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						int nGroupId = ((SNSGroupMemberListAct)getActivity()).getGroupId();
						DeleteGroupUserCancelReq req = new DeleteGroupUserCancelReq(nGroupId, nUserNo);
						WebAPI api = new WebAPI(getActivity());
						api.request(req, new WebListener() {
							@Override
							public void onPreRequest() {
								showProgress();
							}

							@Override
							public void onNetworkError(int nErrorCode, String strMessage) {
								closeProgress();
								((SNSGroupMemberListAct) getActivity()).showErrorPopup(nErrorCode, strMessage);
							}

							@Override
							public void onPostRequest(String a_strData) {
								closeProgress();
								int nItemType = getItemType(nPosition);
								if(nItemType == ITEMTYPE_UNINVITED)
									m_arrUnInviteMember.remove(nPosition);
								else
								{
									int nUnInvitedSize = m_arrUnInviteMember == null ? 0 : m_arrUnInviteMember.size();
									m_arrUnInviteMember.remove(nPosition - nUnInvitedSize);
								}

								m_adapterInvitingMemberList.notifyDataSetChanged();
								TextView tvSection = (TextView)m_vList.findViewById(R.id.tv_snsgroupmemberlist_section);
								int nCount = (m_arrUnInviteMember == null ? 0 : m_arrUnInviteMember.size());
								tvSection.setText(String.format(getString(R.string.snsgroupmemberlist_invitingmember_countformat), nCount));
							}
						});

					}
				});
			}
			else
			{
				layoutButton.setVisibility(View.GONE);
			}
			
			return convertView;
		}
	}
	
	private WebListener m_webInviteRetryListener = new WebListener() {
		
		@Override
		public void onPreRequest() {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onPostRequest(String a_strData) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void onNetworkError(int nErrorCode, String strMessage) {
			// TODO Auto-generated method stub
			((SNSGroupMemberListAct) getActivity()).showErrorPopup(nErrorCode, strMessage);
		}
	};

	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(getActivity());

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
