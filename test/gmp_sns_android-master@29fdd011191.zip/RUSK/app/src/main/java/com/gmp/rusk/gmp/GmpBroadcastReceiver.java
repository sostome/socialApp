package com.gmp.rusk.gmp;


import com.gmp.rusk.MyApp;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.CommonLog;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class GmpBroadcastReceiver extends BroadcastReceiver{

	public MyApp App = MyApp.getInstance();
	private final String TAG = GmpBroadcastReceiver.class.getSimpleName();
	
	public static String ACTION_GMP_LOGOUT_TICK = "com.skt.pe.widget.LOGOUT_TICK";
	public static String ACTION_GMP_LOGOUT_TICK_PERSONA = "com.skt.pe.tps.widget.LOGOUT_TICK";
	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		String strAction = intent.getAction();
		String strLogoutTick = "";
		
		if(AppSetting.FEATURE_PERSONA){
			strLogoutTick = ACTION_GMP_LOGOUT_TICK_PERSONA;
		} else {
			strLogoutTick = ACTION_GMP_LOGOUT_TICK;
		}
		
		CommonLog.e(TAG, "strAction : " + strAction);
		if(strAction == null)
			return;
		
		if(!isAppInit() && strAction.equals(strLogoutTick))
		{
//			Intent newIntent = new Intent(context, IntroAct.class);
//			newIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//			context.startActivity(newIntent);
			if(!AuthUtil.m_isRunGMPLogin)
				App.allActivityDestroy();
		}
	}
	
	public boolean isAppInit()
	{
		if(App.m_EntryData == null)
			return true;
		
		if(App.m_MyUserInfo == null)
			return true;
		
		return false;
	}
}
