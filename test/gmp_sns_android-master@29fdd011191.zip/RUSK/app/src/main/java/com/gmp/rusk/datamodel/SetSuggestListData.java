package com.gmp.rusk.datamodel;

/**
 * Created by 강철 on 2016-04-19.
 */
public class SetSuggestListData {

    public int m_nComplaintNo = 0;
    public boolean m_isResponsed = false;
    public String m_strTitle = "";
    public String m_strCreatedDate = "";
    public String m_strUpdatedDate = "";

}
