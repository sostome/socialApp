package com.gmp.rusk.act;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.gmp.rusk.R;
import com.gmp.rusk.customview.CommonPopup;
import com.gmp.rusk.customview.CommonPopupBtnTypeInt;
import com.gmp.rusk.customview.CustomActivity;
import com.gmp.rusk.dialog.ProgressDlg;
import com.gmp.rusk.network.WebAPI;
import com.gmp.rusk.network.WebListener;
import com.gmp.rusk.request.DeletePCClientReq;
import com.gmp.rusk.utils.AppSetting;
import com.gmp.rusk.utils.IntentKeyString;

public class PCClientStopAct extends CustomActivity implements OnClickListener{
	
	private String m_strHostName = "";
	private String m_strDeviceUID = "";
	
	private CommonPopup m_Popup = null;
	private ProgressDlg m_Progress = null;

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);
		
		if (!AppSetting.FEATURE_SCREENSHOT && !AppSetting.FEATURE_VARIANT.equals("R"))
			getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
		
		setContentView(R.layout.act_set_pcclientstop);
		initUI();
		checkIntent();
		setUI();
	}
	
	private void initUI()
	{
		ImageView ivClose = (ImageView) findViewById(R.id.btn_cancel);
		ivClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		Button ibStop = (Button)findViewById(R.id.ib_pcclientstop_stop);
		ibStop.setOnClickListener(this);
	}
	
	private void setUI()
	{
		TextView tvDeviceName = (TextView)findViewById(R.id.tv_pcclientstop_devicename);
		tvDeviceName.setText(m_strHostName);
	}
	
	private void checkIntent()
	{
		m_strHostName = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_PCCLIENTSTOP_HOSTNAME);
		m_strDeviceUID = getIntent().getStringExtra(IntentKeyString.INTENT_KEY_PCCLIENTSTOP_DEVICEUID);
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int nId = v.getId();
		if(nId == R.id.ib_pcclientstop_stop)
		{
			clickPCClientStop();
		}
		
		super.onClick(v);
	}
	
	private void clickPCClientStop()
	{
		DeletePCClientReq req = new DeletePCClientReq(m_strDeviceUID);
		WebAPI api = new WebAPI(this);
		api.request(req, new WebListener() {
			
			@Override
			public void onPreRequest() {
				// TODO Auto-generated method stub
				showProgress();
			}
			
			@Override
			public void onPostRequest(String a_strData) {
				// TODO Auto-generated method stub
				closeProgress();
				showPCClientStopCompletePopup();
			}
			
			@Override
			public void onNetworkError(int nErrorCode, String strMessage) {
				// TODO Auto-generated method stub
				closeProgress();
				showErrorPopup(nErrorCode, strMessage);
			}
		});
	}
	
	private void showPCClientStopCompletePopup()
	{
		m_Popup = new CommonPopup(this, new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				m_Popup.cancel();
				m_Popup.dismiss();
				setResult(RESULT_OK);
				finish();
			}
		}, CommonPopupBtnTypeInt.POP_BTNTYPE_YES, 0);
		m_Popup.setBodyAndTitleText(getString(R.string.set_pcclientstop_completepopup_title), getString(R.string.set_pcclientstop_completepopup_msg));
		m_Popup.setCancelable(false);
		isCheckShowPopup();
	}
	
	private void isCheckShowPopup() {
		if (super.m_isRunning) {
			m_Popup.show();
		}
	}
	
	public void showProgress() {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}

	public void showProgress(String a_strMsg) {
		if (m_Progress == null)
			m_Progress = new ProgressDlg(this, a_strMsg);

		if (!m_Progress.isShowing()) {
			m_Progress.show();
		}
	}
	
	public void closeProgress() {
		if (m_Progress != null && m_Progress.isShowing())
			m_Progress.cancel();
	}
}
