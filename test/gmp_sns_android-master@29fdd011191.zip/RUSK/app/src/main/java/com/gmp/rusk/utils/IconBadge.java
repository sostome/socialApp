package com.gmp.rusk.utils;

import com.gmp.rusk.act.IntroAct;

import android.content.Context;
import android.content.Intent;

public class IconBadge {
	
	private static final String ACTION_BADGE_COUNT_UPDATE = "android.intent.action.BADGE_COUNT_UPDATE";
	private static final String EXTRA_KEY_BADGE_COUNT = "badge_count";
	private static final String EXTRA_KEY_BADGE_COUNT_PACKAGENAME = "badge_count_package_name";
	private static final String EXTRA_KEY_BADGE_COUNT_CLASSNAME = "badge_count_class_name";
	
	public static void updateIconBadge(Context a_Context)
	{
		SharedPref pref = SharedPref.getInstance(a_Context);
		int nBadgeCount = pref.getIntegerPref(SharedPref.PREF_BADGE_COUNT, 0);
		int nPartnerCount = pref.getIntegerPref(SharedPref.PREF_PARTNERREQUEST_COUNT, 0);
		int nNewAlarmCount = pref.getIntegerPref(SharedPref.PREF_NEW_ALARM_COUNT, 0);
		Intent intent = new Intent(ACTION_BADGE_COUNT_UPDATE);
		intent.putExtra(EXTRA_KEY_BADGE_COUNT, nBadgeCount + nPartnerCount + nNewAlarmCount);
		intent.putExtra(EXTRA_KEY_BADGE_COUNT_PACKAGENAME, a_Context.getPackageName());
		intent.putExtra(EXTRA_KEY_BADGE_COUNT_CLASSNAME, IntroAct.class.getName());
		a_Context.sendBroadcast(intent);
	}
}
