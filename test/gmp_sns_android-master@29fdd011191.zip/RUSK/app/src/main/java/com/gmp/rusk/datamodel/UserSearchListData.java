package com.gmp.rusk.datamodel;

public class UserSearchListData {
	
	public boolean m_isRegular = false;
	
	public Object m_UserData = null;
}
