/**
 * (주)오픈잇 | http://www.openit.co.kr
 * Copyright (c)2006-2012, openit Inc.
 * All rights reserved.
 */
package com.skt.util;

import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.skt.util.ConfigManager;

/**
 * Email을 발송하는 클래스이다.
 * 
 * @author <a href="mailto:support@openit.co.kr">(주)오픈잇 | openit Inc.</a>
 * @version
 * @since
 * @created 2012. 10. 17.
 */
public class EmailService extends Thread {

    private final static String HOST = ConfigManager.getProperty("mail.send.host");

    private static final String PORT = ConfigManager.getProperty("mail.send.port");

    private static final String STARTTLS = "true";

    private static final String AUTH = "true";

    private static final String DEBUG = "false";

    private static final String SOCKET_FACTORY = "javax.net.ssl.SSLSocketFactory";

    // 보내는 사람 계정 정보
    private static final String FROMUSER = ConfigManager.getProperty("mail.send.fromuser");

    private static final String PASSWORD = ConfigManager.getProperty("mail.send.pwd");

    //배치 잡시 보내는 사람 메일 목록
    private static final String BATCHMAILLIST = ConfigManager.getProperty("mail.send.complete.userMail");
    
    /**
     * 로그 설정
     */
    private static final Log logger = LogFactory.getLog(EmailService.class);

    private final Map pMap;

    /**
     * 생성자
     */
    public EmailService(Map pMap) {
        this.pMap = pMap;
    }

    /**
     * (non-Javadoc)
     * 
     * @see java.lang.Thread#run()
     */
    @Override
    public void run() {
    	
        String msgTitle = "[toktok mobile] " +(String) pMap.get("TITLE");
        
        String to = (String)pMap.get("EMAIL");
        
        Properties props = new Properties();
        
        props.put("mail.smtp.host", HOST);
        props.put("mail.smtp.port", PORT);
        props.put("mail.smtp.user", FROMUSER);
        props.put("mail.smtp.auth", AUTH);
        props.put("mail.smtp.starttls.enable", STARTTLS);
        props.put("mail.smtp.debug", DEBUG);
        props.put("mail.smtp.socketFactory.port", PORT);
        props.put("mail.smtp.socketFactory.class", SOCKET_FACTORY);
        props.put("mail.smtp.socketFactory.fallback", "false");
        
        System.out.println("to =" + to);

        Session mailSession = Session.getDefaultInstance(props, null);

        Message emailMsg = new MimeMessage(mailSession);
        
        
        
        try {
        	
        	emailMsg.setFrom(new InternetAddress(FROMUSER));
        	if(to != null && !to.isEmpty()){
        		emailMsg.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(to));
        	}

            //배치 잡이면 아래와 같이 셋팅 해줌
            if(pMap.get("batchYn") != null && pMap.get("batchYn").equals("Y")){
            	StringTokenizer st = new StringTokenizer(BATCHMAILLIST,"|"); 
            	while (st.hasMoreTokens()){ 
            	String temp = st.nextToken();
            	System.out.println("Email = = "+temp);
            	emailMsg.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(temp));
            	}
            }
            emailMsg.setSubject(msgTitle);
            emailMsg.setContent(pMap.get("emailContent"), "text/html; charset=UTF-8");
            emailMsg.saveChanges();
            Transport transport = mailSession.getTransport("smtp");
            transport.connect(HOST, FROMUSER, PASSWORD);
            transport.sendMessage(emailMsg, emailMsg.getAllRecipients());
            transport.close();

        } catch (Exception e) {	
        	e.printStackTrace();
        	System.out.println("EMAIL SERVICE ERROR" + e.getMessage());
        }

    }
}
