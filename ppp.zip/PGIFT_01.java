package com.skcc.bcsvc.gift.biz;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.component.streotype.BizUnitBind;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.data.UserMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.ripple.core.coretypes.STObject;
import com.ripple.core.coretypes.hash.Hash256;
import com.ripple.core.types.known.tx.signed.SignedTransaction;
import com.skcc.bcsvc.gift.consts.GTPRESENT;

/**
 * [PU]상품권 - 선물하기.
 * <pre>
 * [PU]상품권 - 선물하기
 * </pre>
 * 
 * @author baekjg (백진구)
 * @since 2018-07-13 20:10:44
 */
@BizUnit("[PU]상품권 - 선물하기")
public class PGIFT_01 extends nexcore.framework.biz.online.ProcessUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */
	
	@BizUnitBind
	private DGIFT_02 dGIFT_02;

	/**
	 * Default Constructor
	 */
	public PGIFT_01(){
		super();
	}
	
	@BizUnitBind
	private FGIFT_01 fGIFT01;
	
	/**
	 * [PM] 상품권 - 선물하기.
	 * <pre>
	 * [PM] 상품권 - 선물하기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 17:15:39
	 */
	@BizMethod("[PM] 상품권 - 선물하기")
	public IDataSet pSendGift(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    String GIFT_SND_USER_ID = new String("");//필수
	    String GIFT_REV_USER_ID = new String("");//최근 내역인 경우 필수
	    String GIFT_SN_LIST_STR  = new String("");//필수	    
	    String GIFT_REV_CONT = new String("");
	    String GIFT_REV_USER_NAME = new String("");//비회원인 경우 필수 - 주소록 직접입력    
	    String GIFT_REV_USER_PHONE = new String("");//비회원인 경우 필수 - 주소록 직접입력
	    
	    
	    String[] GIFT_SN_ARR = new String[]{};
	    int len = 0;	    
	    
	    long GIFT_AMT = 0;
	    String GIFT_KND_KOR = new String("");
	    
	    String GIFT_REV_USER_NM = new String("");
	    String GIFT_SND_USER_NM = new String("");
	    	    
	    List<Map<String, Object>> listMsg = new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapMsg = new HashMap<String, Object>();
	    
	    String strFormattedAmt = "0";
	    long TOTAL_PRESENT_SUM = 0;//합계 발송일 경우
	    	    
        try {
        	
        	if(requestData.get("GIFT_REV_USER_ID") != null){
        		GIFT_REV_USER_ID = (String)requestData.get("GIFT_REV_USER_ID");//최근 내역
        	}else{
        		GIFT_REV_USER_ID = dGIFT_02.s011(requestData, onlineCtx).getString("USER_ID");//주소록 직접입력
        	}
        	
        	if(requestData.get("GIFT_REV_USER_NAME") != null){
        		GIFT_REV_USER_NAME = requestData.getString("GIFT_REV_USER_NAME");        		
        	}
        	
        	if(requestData.get("GIFT_REV_USER_PHONE") != null){
        		GIFT_REV_USER_PHONE = requestData.getString("GIFT_REV_USER_PHONE");        		
        	}
        	
        	if(requestData.get("GIFT_REV_CONT") != null){
        		GIFT_REV_CONT = requestData.getString("GIFT_REV_CONT");
        	}    
        	
        	GIFT_SN_LIST_STR = requestData.getString("GIFT_SN_LIST_STR");
        	GIFT_SN_ARR = GIFT_SN_LIST_STR.split(",");
        	GIFT_SND_USER_ID = requestData.getString("GIFT_SND_USER_ID");
         	       	      	        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_CONT:"+GIFT_REV_CONT);        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_NAME:"+GIFT_REV_USER_NAME);
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_PHONE:"+GIFT_REV_USER_PHONE);
        	       	
        	requestData.put("GIFT_USE_USER_ID", GIFT_REV_USER_ID);
        	requestData.put("GIFT_REV_USER_NAME", GIFT_REV_USER_NAME);
        	requestData.put("GIFT_REV_USER_PHONE", GIFT_REV_USER_PHONE);
        	requestData.put("GIFT_REV_USER_ID", GIFT_REV_USER_ID);
        	
        	len = GIFT_SN_ARR.length;
        	       	        	        	
        	//데이터 입렫        	
        	for(int i = 0; i < len; i++){
        		
        		String GIFT_SN = GIFT_SN_ARR[i];
        		
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN:"+GIFT_SN);
        		
        		requestData.put("GIFT_SN", GIFT_SN); 
        		
        		//HISTORY TABLE 업데이트            	
            	dGIFT_02.u001(requestData, onlineCtx);
        		
        		//HISTORY TABLE 인서트
        		dGIFT_02.i001(requestData, onlineCtx);
        		
        		//상품권 테이블 업데이트
        	    dGIFT_02.u002(requestData, onlineCtx);
        	    
        	    //PUSH SMS 메세지 발송         	    
                if(!GIFT_REV_USER_NAME.equals("") 
                   && !GIFT_REV_USER_PHONE.equals("")){
                	
                	GIFT_REV_USER_NM = GIFT_REV_USER_NAME;//PUSH SMS 대상 이름
            	    GIFT_AMT = dGIFT_02.s005(requestData, onlineCtx).getLong("GIFT_AMT");
            	    GIFT_KND_KOR = dGIFT_02.s005(requestData, onlineCtx).getString("GIFT_KND_KOR");   	    	
        	    	
        	    }else{
        	    	
                    GIFT_REV_USER_NM = dGIFT_02.s004(requestData, onlineCtx).getString("USER_NAME");//PUSH SMS 대상 이름 조회
                 	GIFT_AMT = dGIFT_02.s005(requestData, onlineCtx).getLong("GIFT_AMT");
                 	GIFT_KND_KOR = dGIFT_02.s005(requestData, onlineCtx).getString("GIFT_KND_KOR");  	    	      	    	
             	         	    	 
        	    }       	    
        	    
        	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_NM:"+GIFT_REV_USER_NM);
        	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_AMT:"+GIFT_AMT);
        	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_KND_KOR:"+GIFT_KND_KOR);
        	    
        	    TOTAL_PRESENT_SUM += GIFT_AMT;        	    
        	    GIFT_SND_USER_NM = dGIFT_02.s010(requestData, onlineCtx).getString("USER_NAME");//상품권 발송자 이름
        	    
        	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_NM:"+GIFT_SND_USER_NM);
        	    
        	    //if(requestData.get("GIFT_REV_USER_ID") != null && GIFT_REV_USER_NM != null 
        	    //		&& !GIFT_REV_USER_NM.equals("")){ //회원일 경우, 존재할 경우
        	    
        	    listMsg = new ArrayList<Map<String, Object>>();
    	        mapMsg = new HashMap<String, Object>();
    	               			       			
        			//if(i == len - 1){  
        				
        				 strFormattedAmt = String.format("%,d", GIFT_AMT);
        	    	     FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]strFormattedAmt:"+strFormattedAmt);
        	        	    
        	        	 if((GIFT_REV_USER_ID == null || GIFT_REV_USER_ID.equals("")) && !GIFT_REV_USER_PHONE.equals("")){
        	        		 
        	        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID == null || GIFT_REV_USER_ID.equals('')::GIFT_REV_USER_PHONE:"+GIFT_REV_USER_PHONE);        	        	    	
        	        	 	requestData.put("SEND_TYPE", "N");  
        	        	 	requestData.put("MSG_ID", "3");//선물하기 메세지
        	        	    mapMsg.put("USER_ID", GIFT_REV_USER_PHONE);
        	        	    	
        	        	 }else{
        	        	    
        	        		 FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        	        	 	requestData.put("SEND_TYPE", "S");//S : SMS 전송, P : PUSH 전송  , A : PUSH SMS 전송 , N: 비회웡 SMS 전송
        	        	 	requestData.put("MSG_ID", "3");//선물하기 메세지
        	        	    mapMsg.put("USER_ID", GIFT_REV_USER_ID);
        	        	 }
        	        	    	      	       
        	        	 mapMsg.put("TITLE", GIFT_REV_USER_NM);
        	        	 mapMsg.put("CONT", GIFT_SND_USER_NM+"|"+GIFT_KND_KOR+"|"+strFormattedAmt);
        	        	        
        	        	 listMsg.add(mapMsg);
        	        	      
        	        	 requestData.put("MSG_DATA", listMsg);
        				
        				 //SMS 전송
                	     responseData = callSharedMethodByDirect("com.skcc.bcsvc.co", "FBASE.fMobMsgSend", requestData, onlineCtx);
        			//}
            	              		
            	//}       	    
        	  
        	}
        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]**BizRuntimeException**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+be.getMessage());
            throw be;
            
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pSendGift", "[로그정보]**Exception**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}
	
	/**
	 * [PM]상품권 - 선물 가능 대상자 목록.
	 * <pre>
	 * [PM]상품권 - 선물 가능 대상자 목록
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 16:03:07
	 */
	@BizMethod("[PM]상품권 - 선물 가능 대상자 목록")
	public IDataSet pGetGiftGivableUserList(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
        try {
        	
            responseData.put("giftableUserList", dGIFT_02.s001(requestData, onlineCtx).getRecordSet("rs"));
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("PGIFT_01", "pGetGiftGivableUserList", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("PGIFT_01", "pGetGiftGivableUserList", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}

	/**
	 * [PM]상품권 - 선물하기 - 선물 가능 상품권 목록 조회.
	 * <pre>
	 * [PM]상품권 - 선물하기 - 선물 가능 상품권 목록 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 20:21:24
	 */
	@BizMethod("[PM]상품권 - 선물하기 - 선물 가능 상품권 목록 조회")
	public IDataSet pGetGiftableGiftList(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
        try {
            responseData.put("giftableList", dGIFT_02.s002(requestData, onlineCtx).getRecordSet("rs"));
            
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("PGIFT_01", "pGetGiftableGiftList", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("PGIFT_01", "pGetGiftableGiftList", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}

	/**
	 * [PM]상품권 - 선물하기 - 승인.
	 * <pre>
	 * [PM]상품권 - 선물하기 - 승인
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 21:33:21
	 */
	@BizMethod("[PM]상품권 - 선물하기 - 승인")
	public IDataSet pGiftApproval(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    String GIFT_REV_USER_ID = new String("");
	    String GIFT_SN_LIST_STR  = new String("");
	    String GIFT_SND_USER_ID_LIST_STR  = new String("");	        
	    
	    int len = 0;
	    IRecordSet rsGTList = null;
	    IRecordSet rsGTUserList = null;
	    
	    //PUSH
	    String GIFT_SND_USER_ID = new String(""); 
	    String GIFT_SND_USER_NM = new String("");
	    long GIFT_AMT = 0;
	    String GIFT_KND_KOR = new String("");
	    String GIFT_SN = new String("");	    
	    
	    List<Map<String, Object>> listMsg = new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapMsg = new HashMap<String, Object>();
	    
	    String strFormattedAmt = "0";
	    String sep = ",";
	    int roop = 0;	    	   
	    
		IDataSet responseDataSet = new DataSet();        
                        
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObj = new JSONObject();
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonResObj = new JSONObject();
        JSONObject jsonResObj2 = new JSONObject();
        JSONObject jsonBodyObj = new JSONObject();
                
        Object resObj = new Object();
        String status = "";
        
        HashMap resMap = new HashMap();
        String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};			
	    String[] GIFT_SN_LIST = new String[]{};    
	    
        try {
        	
        	GIFT_REV_USER_ID = requestData.getString("GIFT_REV_USER_ID");        	
        	requestData.put("GIFT_USE_USER_ID", GIFT_REV_USER_ID); 
        	        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        	        	
        	//상품권 리스트 조회
        	rsGTList = dGIFT_02.s016(requestData, onlineCtx).getRecordSet("rs");
        	        	
        	Iterator<IRecord> iter = rsGTList.iterator();
        	len = rsGTList.getRecordCount();
        	
        	while(iter.hasNext()){
        		
        		roop++;
        		if(roop > len-1){
        			sep = "";
        		}
        		
        		GIFT_SN = iter.next().getString("GIFT_SN");        		
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN:"+GIFT_SN);        		
        		GIFT_SN_LIST_STR += GIFT_SN+sep;         		
        	}
        	
        	rsGTUserList = dGIFT_02.s017(requestData, onlineCtx).getRecordSet("rs");
        	
        	roop = 0;  
        	sep = ",";
        	
        	Iterator<IRecord> iter2 = rsGTUserList.iterator();
        	len = rsGTUserList.getRecordCount();
        	
        	while(iter2.hasNext()){
        		
        		roop++;
        		if(roop > len-1){
        			sep = "";
        		}
        	
        		GIFT_SND_USER_ID = iter2.next().getString("GIFT_SND_USER_ID");        		
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);        		
        		GIFT_SND_USER_ID_LIST_STR += GIFT_SND_USER_ID+sep;
        	}
                   	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID_LIST_STR:"+GIFT_SND_USER_ID_LIST_STR);
        	
        	requestData.put("GIFT_SN_LIST_STR", GIFT_SN_LIST_STR);
        	requestData.put("GIFT_SND_USER_ID_LIST_STR", GIFT_SND_USER_ID_LIST_STR);
        	
        	resMap = makeSignByApprove(requestData, onlineCtx);
             	
        	
        	//if(resMap != null && resMap.get("tx_blob_array") != null && sequence_array != null){
        	
        		tx_blob_array  = (String[])resMap.get("tx_blob_array");
            	sequence_array = (long[])sequence_array;
            	GIFT_SN_LIST = (String[])resMap.get("GIFT_SN_LIST");            	            	
            	
            	len = tx_blob_array.length;
            	      	
            	for(int i=0;i<len;i++){
            		
            		jsonArray = new JSONArray();
                    jsonObj = new JSONObject();
                    jsonBodyObj = new JSONObject();
            		
            		jsonObj.put("tx_blob",tx_blob_array[i]);
            		jsonArray.add(jsonObj); 
            		
            		jsonBodyObj.put("method", "submit");
            		jsonBodyObj.put("params", jsonArray);
            		
            		requestData.put("params", jsonBodyObj);
            		
            		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]params:"+requestData.get("params").toString());
            		
            		responseData = fGIFT01.fGiftSendCoinNet(requestData, onlineCtx);
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]result:"+responseData.getString("result"));                	
                	
                	resObj = jsonParser.parse(responseData.getString("result"));
                	jsonResObj = (JSONObject) resObj;
                	jsonResObj2 = (JSONObject)jsonResObj.get("result");
                	status = jsonResObj2.get("status").toString();
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]status:"+status);
                	
                	if(status.equals("success")){               		
                		
                		//VERIFY함다
                		JSONObject txJsonObj = (JSONObject)jsonResObj2.get("tx_json");
                		String tx_id = txJsonObj.get("hash").toString();
                		
                		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]tx_id:"+tx_id);
                		
                		JSONArray jsonTxArray = new JSONArray();
                		JSONObject jsonTxObj = new JSONObject();
                		JSONObject jsonTxBodyObj = new JSONObject();
                		
                		jsonTxObj.put("transaction",tx_id);
                		jsonTxObj.put("binary",false);
                		jsonTxArray.add(jsonObj); 
                		
                		jsonTxBodyObj.put("method", "tx");
                		jsonTxBodyObj.put("params", jsonArray);
                		
                		requestData.put("params", jsonTxBodyObj);
                		
                		responseDataSet = fGIFT01.fGiftSendResultConfirmCoinNet(requestData, onlineCtx);
                    	
                    	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]confirm result:"+responseData.getString("result"));
                    	                	
                    	resObj = jsonParser.parse(responseData.getString("result"));
                    	jsonResObj = (JSONObject) resObj;
                    	jsonResObj2 = (JSONObject)jsonResObj.get("result");
                    	status = jsonResObj2.get("status").toString();
                    	
                    	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]conmfirm status:"+status);
                    	
                    	//if(jsonResObj2.get("validated") != null && Boolean.parseBoolean(jsonResObj2.get("validated").toString()) == true){
                    		
                    		//boolean validated = Boolean.parseBoolean(jsonResObj2.get("validated").toString());
                    		//FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "conmfirm validated:"+validated);
                    		
                    		GIFT_SN = GIFT_SN_LIST[i];
                    		
                    		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN:"+GIFT_SN);
                    		
                    		requestData.put("GIFT_SN", GIFT_SN); 
                    		
                    		//상품권 테이블 업데이트
                    	    dGIFT_02.u003(requestData, onlineCtx);
                    	    
                    	    // 메세지 발송
                    	    
                    	    GIFT_SND_USER_ID = (String)resMap.get("GIFT_SND_USER_ID");
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);
                    	    
                    	    GIFT_SND_USER_NM = dGIFT_02.s010(requestData, onlineCtx).getString("USER_NAME");//PUSH 대상 이름 조회
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_NM:"+GIFT_SND_USER_NM);
                    	   
                    	    GIFT_AMT = dGIFT_02.s005(requestData, onlineCtx).getLong("GIFT_AMT");//상품권 액수
                    	    GIFT_KND_KOR = dGIFT_02.s005(requestData, onlineCtx).getString("GIFT_KND_KOR");//상품권 액수
                    	  
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_AMT:"+GIFT_AMT);
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_KND_KOR:"+GIFT_KND_KOR);
                    	                       	    	
                    	   	requestData.put("SEND_TYPE", "S");//S : SMS 전송, P : PUSH 전송  , A : PUSH SMS 전송  
                    	   	requestData.put("MSG_ID", "5");//메세지 아이디 설정
                    			
                    	    listMsg = new ArrayList<Map<String, Object>>();
                    	    mapMsg = new HashMap<String, Object>();
                    	        
                    	    strFormattedAmt = String.format("%,d", GIFT_AMT);
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]strFormattedAmt:"+strFormattedAmt);
                    	        
                    	    mapMsg.put("USER_ID", GIFT_SND_USER_ID);
                    	    mapMsg.put("TITLE", GIFT_SND_USER_NM);
                    	    mapMsg.put("CONT", GIFT_SND_USER_NM+"|"+GIFT_KND_KOR+"|"+strFormattedAmt);
                    	        
                    	    listMsg.add(mapMsg);
                    	      
                    		requestData.put("MSG_DATA", listMsg);
                        	    
                        	//SMS 전송
                        	responseData = callSharedMethodByDirect("com.skcc.bcsvc.co", "FBASE.fMobMsgSend", requestData, onlineCtx);
                	  //}
                		
                	
                	}else{
                		//데이터 처리 없은
                	}            	
            		
            	}   
            	  	
            	
            	/**
            	 * {
            	 *   "result": {
            	 *     "engine_result": "tesSUCCESS",
            	 *     "engine_result_code": 0,
            	 *     "engine_result_message": "ddd",
            	 *     "status": "success",
            	 *     "tx_blob": "122ww",
            	 *     "tx_json":{
            	 *       "Account": "rnz",
            	 *       "Destination": "rDmW",
            	 *       "Fee": "10",
            	 *       "Flags": 214,
            	 *       "GiftID": "223",
            	 *       "Sequence": 3,
            	 *       "SigningPubKey": "233",
            	 *       "TransactionType": "GiftSend",
            	 *       "TxnSignature": "340",
            	 *       "hash": "799"
            	 *     }
            	 *   }
            	 *   
            	 * }
            	 * 
            	 * 
            	 */
        		
        	//}   		
    	   
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]**BizRuntimeException**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+be.getMessage());
            throw be;
            
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftApproval", "[로그정보]**Exception**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}
	
	/**
	 * [PM]상품권 - 선물하기 - 거부.
	 * <pre>
	 * [PM]상품권 - 선물하기 - 거부
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 21:33:21
	 */
	@BizMethod("[PM]상품권 - 선물하기 - 거부")
	public IDataSet pGiftReject(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    String GIFT_REV_USER_ID = new String("");
	    String GIFT_SN_LIST_STR  = new String("");
	    String GIFT_SND_USER_ID_LIST_STR  = new String("");	        
	    int len = 0;
	    IRecordSet rs = null;
	    IRecordSet rs1 = null;
	
	    String GIFT_SND_USER_ID = new String(""); 
	    String GIFT_SND_USER_NM = new String("");
	    long GIFT_AMT = 0;
	    String GIFT_KND_KOR = new String("");
	    String GIFT_SN = new String("");
	    
	    List<Map<String, Object>> listMsg = new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapMsg = new HashMap<String, Object>();
	    String strFormattedAmt = "0";
	    String sep = ",";
	    int roop = 0;	    	   
	    
		IDataSet responseDataSet = new DataSet();        
         
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObj = new JSONObject();
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonResObj = new JSONObject();
        JSONObject jsonResObj2 = new JSONObject();
        JSONObject jsonBodyObj = new JSONObject();
               
        Object resObj = new Object();
        String status = "";
        HashMap resMap = new HashMap();
        String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};			
	    String[] GIFT_SN_LIST = new String[]{};
	   
	    long TOTAL_PRESENT_SUM = 0;
	    
        try {
        	
        	GIFT_REV_USER_ID = requestData.getString("GIFT_REV_USER_ID");
        	        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        	requestData.put("GIFT_USE_USER_ID", GIFT_REV_USER_ID); 
        	        	
        	//상품권 리스트 조회
        	rs = dGIFT_02.s016(requestData, onlineCtx).getRecordSet("rs");
        	        	
        	Iterator<IRecord> iter = rs.iterator();
        	len = rs.getRecordCount();
        	
        	while(iter.hasNext()){
        		
        		roop++;
        		if(roop > len-1){
        			sep = "";
        		}
        		
        		GIFT_SN = iter.next().getString("GIFT_SN");        		
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN:"+GIFT_SN);        		
        		GIFT_SN_LIST_STR += GIFT_SN+sep;         		
        	}
        	
        	rs1 = dGIFT_02.s017(requestData, onlineCtx).getRecordSet("rs");
        	
        	roop = 0;  
        	sep = ",";
        	
        	Iterator<IRecord> iter2 = rs1.iterator();
        	len = rs1.getRecordCount();
        	
        	while(iter2.hasNext()){
        		
        		roop++;
        		if(roop > len-1){
        			sep = "";
        		}
        	
        		GIFT_SND_USER_ID = iter2.next().getString("GIFT_SND_USER_ID");        		
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);        		
        		GIFT_SND_USER_ID_LIST_STR += GIFT_SND_USER_ID+sep;
        	}
                  	        	
        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID_LIST_STR:"+GIFT_SND_USER_ID_LIST_STR);
        	
        	requestData.put("GIFT_SN_LIST_STR", GIFT_SN_LIST_STR);
        	requestData.put("GIFT_SND_USER_ID_LIST_STR", GIFT_SND_USER_ID_LIST_STR);
        	
        	resMap = makeSignByReject(requestData, onlineCtx);
                   	
        	//if(resMap != null && resMap.get("tx_blob_array") != null && sequence_array != null){
        	
        		tx_blob_array  = (String[])resMap.get("tx_blob_array");
            	sequence_array = (long[])sequence_array;
            	GIFT_SN_LIST = (String[])resMap.get("GIFT_SN_LIST");            	            	
            	
            	len = tx_blob_array.length;
            	      	
            	for(int i=0;i<len;i++){
            		
            		jsonArray = new JSONArray();
                    jsonObj = new JSONObject();
                    jsonBodyObj = new JSONObject();
            		
            		jsonObj.put("tx_blob",tx_blob_array[i]);
            		jsonArray.add(jsonObj); 
            		
            		jsonBodyObj.put("method", "submit");
            		jsonBodyObj.put("params", jsonArray);
            		
            		requestData.put("params", jsonBodyObj);
            		
            		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]params:"+requestData.get("params").toString());
            		
            		responseData = fGIFT01.fGiftSendCoinNet(requestData, onlineCtx);
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]result:"+responseData.getString("result"));                	
                	
                	resObj = jsonParser.parse(responseData.getString("result"));
                	jsonResObj = (JSONObject) resObj;
                	jsonResObj2 = (JSONObject)jsonResObj.get("result");
                	status = jsonResObj2.get("status").toString();
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]status:"+status);
                	
                	if(status.equals("success")){               		
                		                		
                		JSONObject txJsonObj = (JSONObject)jsonResObj2.get("tx_json");
                		String tx_id = txJsonObj.get("hash").toString();
                		
                		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]tx_id:"+tx_id);
                		
                		JSONArray jsonTxArray = new JSONArray();
                		JSONObject jsonTxObj = new JSONObject();
                		JSONObject jsonTxBodyObj = new JSONObject();
                		
                		jsonTxObj.put("transaction",tx_id);
                		jsonTxObj.put("binary",false);
                		jsonTxArray.add(jsonObj); 
                		
                		jsonTxBodyObj.put("method", "tx");
                		jsonTxBodyObj.put("params", jsonArray);
                		
                		requestData.put("params", jsonTxBodyObj);
                		
                		responseDataSet = fGIFT01.fGiftSendResultConfirmCoinNet(requestData, onlineCtx);
                    	
                    	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]gift Fund confirm result:"+responseData.getString("result"));
                    	                	
                    	resObj = jsonParser.parse(responseData.getString("result"));
                    	jsonResObj = (JSONObject) resObj;
                    	jsonResObj2 = (JSONObject)jsonResObj.get("result");
                    	status = jsonResObj2.get("status").toString();
                    	
                    	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]gift Fund conmfirm status:"+status);
                    	
                    	//if(jsonResObj2.get("validated") != null && Boolean.parseBoolean(jsonResObj2.get("validated").toString()) == true){
                    		
                    		//boolean validated = Boolean.parseBoolean(jsonResObj2.get("validated").toString());
                    		//FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "conmfirm validated:"+validated);
                    		
                    		GIFT_SN = GIFT_SN_LIST[i];
                    		
                    		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN:"+GIFT_SN);
                    		
                    		requestData.put("GIFT_SN", GIFT_SN); 
                    	                        		
                    	    //HISTORY 테이블 업데이트
                    		dGIFT_02.u004(requestData, onlineCtx); 
                    		
                    		GIFT_SND_USER_ID = (String)resMap.get("GIFT_SND_USER_ID");
                    		
                    		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);
                    		
                    		requestData.put("GIFT_USE_USER_ID", GIFT_SND_USER_ID);
                    		
                    		//상품권 테이블 업데이트
                    	    dGIFT_02.u005(requestData, onlineCtx);
                    	                        	    
                    	    // 메세지 발송
                    	   
                    	    GIFT_SND_USER_NM = dGIFT_02.s010(requestData, onlineCtx).getString("USER_NAME");//PUSH 대상 이름 조회
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SND_USER_NM:"+GIFT_SND_USER_NM);
                    	   
                    	    GIFT_AMT = dGIFT_02.s005(requestData, onlineCtx).getLong("GIFT_AMT");//상품권 액수
                    	    GIFT_KND_KOR = dGIFT_02.s005(requestData, onlineCtx).getString("GIFT_KND_KOR");//상품권 액수
                    	  
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_AMT:"+GIFT_AMT);
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_KND_KOR:"+GIFT_KND_KOR);                   	        	    
                    	                       	    	
                    	   	requestData.put("SEND_TYPE", "S");//S : SMS 전송, P : PUSH 전송  , A : PUSH SMS 전송  
                    	   	requestData.put("MSG_ID", "4");//메세지 아이디 설정
                    			
                    	    listMsg = new ArrayList<Map<String, Object>>();
                    	    mapMsg = new HashMap<String, Object>();
                    	        
                    	    strFormattedAmt = String.format("%,d", GIFT_AMT);
                    	    FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]strFormattedAmt:"+strFormattedAmt);
                    	        
                    	    mapMsg.put("USER_ID", GIFT_SND_USER_ID);
                    	    mapMsg.put("TITLE", GIFT_SND_USER_NM);
                    	    mapMsg.put("CONT", GIFT_SND_USER_NM+"|"+GIFT_KND_KOR+"|"+strFormattedAmt);
                    	        
                    	    listMsg.add(mapMsg);
                    	      
                    		requestData.put("MSG_DATA", listMsg);
                        	    
                        	//SMS 전송
                        	responseData = callSharedMethodByDirect("com.skcc.bcsvc.co", "FBASE.fMobMsgSend", requestData, onlineCtx);
                	  //}
                		
                	
                	}else{
                		//데이터 처리 없은
                	}            	
            		
            	}   
            	  	
            	
            	/**
            	 * {
            	 *   "result": {
            	 *     "engine_result": "tesSUCCESS",
            	 *     "engine_result_code": 0,
            	 *     "engine_result_message": "ddd",
            	 *     "status": "success",
            	 *     "tx_blob": "122ww",
            	 *     "tx_json":{
            	 *       "Account": "rnz",
            	 *       "Destination": "rDmW",
            	 *       "Fee": "10",
            	 *       "Flags": 214,
            	 *       "GiftID": "223",
            	 *       "Sequence": 3,
            	 *       "SigningPubKey": "233",
            	 *       "TransactionType": "GiftSend",
            	 *       "TxnSignature": "340",
            	 *       "hash": "799"
            	 *     }
            	 *   }
            	 *   
            	 * }
            	 * 
            	 * 
            	 */
        		
        	//}        	       	
        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]**BizRuntimeException**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+be.getMessage());
            throw be;
            
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]pGiftReject", "[로그정보]**Exception**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}

	/**
	 * [PM]상품권 - 선물하기 - 도착화면.
	 * <pre>
	 * [PM]상품권 - 선물하기 - 도착화면
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 18:19:31
	 */
	@BizMethod("[PM]상품권 - 선물하기 - 도착화면")
	public IDataSet pGetGiftReceive(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    String USER_NAME = "";
	    String MOB_PHN_NO = "";
	    String USER_ID = "";
	    	    
        try {
        	
        	//GIFT_REV_USER_ID 변수 필요
        	
        	responseData.put("giftReceivedList", dGIFT_02.s006(requestData, onlineCtx).getRecordSet("rs"));
            
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("PGIFT_01", "pGetGiftReceive", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("PGIFT_01", "pGetGiftReceive", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}

	/**
	 * [PM]상품권 - 선물하기 - 도착.
	 * <pre>
	 * [PM]상품권 - 선물하기 - 도착
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 18:39:38
	 */
	@BizMethod("[PM]상품권 - 선물하기 - 완료")
	public IDataSet pSendGiftFinish(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    String USER_NAME = "";
	    String MOB_PHN_NO = "";
	   	    
        try {
        	
        	//GIFT_REV_USER_ID 변수 필요
        	
        	USER_NAME = dGIFT_02.s009(requestData, onlineCtx).getString("USER_NAME");
        	MOB_PHN_NO = dGIFT_02.s009(requestData, onlineCtx).getString("MOB_PHN_NO");
        	
        	responseData.put("USER_NAME", USER_NAME);
        	responseData.put("MOB_PHN_NO", MOB_PHN_NO);        	
        	responseData.put("giftFinishList", dGIFT_02.s007(requestData, onlineCtx).getRecordSet("rs"));
            
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("PGIFT_01", "pSendGiftFinish", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;
        } catch(Exception e) {
        	e.printStackTrace();
        	log.error("<오류> <BizRuntimeException> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("PGIFT_01", "pSendGiftFinish", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;
	}
	
    public HashMap makeSignByApprove(IDataSet requestData, IOnlineContext onlineCtx){
		
		Log log = getLog(onlineCtx);		
		JSONObject body = new JSONObject();	
		
		String GIFT_REV_USER_ID = new String("");
		String GIFT_SN_LIST_STR = new String("");
		String GIFT_SND_USER_ID_LIST_STR = new String("");
		String[] GIFT_SN_LIST = new String[]{};
		String[] GIFT_SND_USER_ID_ARR = new String[]{};
		int len = 0;
						
		String secret = new String("");
		secret = GTPRESENT.GT_NET_PRESENT_TRANS_SECRET;
		String tx_json = "";
		String account = new String("");
		account = GTPRESENT.GT_NET_PRESENT_TRANS_ADDRESS;
		
		String transactionType = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_TYPE;
		String fee = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_FEE;
		long sequence = 0;
		String destination = new String("");
		
		STObject stobject = null;
		SignedTransaction signed2 = null;
		
		String tx_blob = new String("");
		Hash256 hash;
		
		IDataSet res1 = null;
		IDataSet res2 = null;
				
		String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};
		
		HashMap resMap = new HashMap();
		
		IDataSet accInfoRes = new DataSet();
        JSONObject jsonAccObj = new JSONObject();
		JSONObject jsonAccResult = new JSONObject();
		JSONObject jsonAccData = new JSONObject();
				
        try { 
        	
        	if(requestData.get("GIFT_REV_USER_ID") != null){
        		
        		GIFT_REV_USER_ID = requestData.getString("GIFT_REV_USER_ID");
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        		
        		//받는 사람 주소 가져오기
        		res1 = dGIFT_02.s012(requestData, onlineCtx);
        		destination = res1.getString("USER_WAT_ADDR");       		
        		
        	}
        	
        	if(requestData.get("DESTINATION_ADDRESS") != null){
        		destination = requestData.getString("DESTINATION_ADDRESS");
        	}
        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]destination:"+destination);
        	        	
        	//보내는 사람 주소 가져오기
        	if(requestData.get("GIFT_SND_USER_ID_LIST_STR") != null){
        		
        		GIFT_SND_USER_ID_LIST_STR = requestData.getString("GIFT_SND_USER_ID_LIST_STR");
        		GIFT_SND_USER_ID_ARR =  GIFT_SND_USER_ID_LIST_STR.split(",");
        	}
        	
        	resMap.put("GIFT_SND_USER_ID", GIFT_SND_USER_ID_ARR[0]);        	
        	requestData.put("GIFT_SND_USER_ID", GIFT_SND_USER_ID_ARR[0]);
        	res2 = dGIFT_02.s013(requestData, onlineCtx);
        	account = res2.getString("USER_WAT_ADDR");    
        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]account:"+account);
        	        	
        	//sequence = dGIFT_02.s014(requestData, onlineCtx).getLong("GIFT_HIST_NO");//보낼때마다 +1  BCT_GIFT_HIST 최대 GIFT_HIST_NO + 1 값
        	
        	requestData.put("account_address", account);
        	accInfoRes = fGIFT01.fGetAccountInfo(requestData, onlineCtx);
   			jsonAccObj = (JSONObject) new JSONParser().parse(accInfoRes.getString("result"));
    		jsonAccResult = (JSONObject) new JSONParser().parse(jsonAccObj.get("result").toString());
    		
			String status = jsonAccResult.get("status").toString();
			
			FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]status:"+status);
			
			if (status.equals("success")) {
	
				jsonAccData = (JSONObject) new JSONParser().parse(jsonAccResult.get("account_data").toString());
				sequence = Integer.parseInt(jsonAccData.get("Sequence").toString());				
				FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]sequence:"+sequence);
			}
			
			sequence = getSequence();
        	    		
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]sequence:"+sequence);
        	        	
        	GIFT_SN_LIST_STR = requestData.getString("GIFT_SN_LIST_STR"); 
        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	
        	GIFT_SN_LIST = GIFT_SN_LIST_STR.split(",");
        	
        	resMap.put("GIFT_SN_LIST", GIFT_SN_LIST);
        	
        	len = GIFT_SN_LIST.length;
        	
        	tx_blob_array = new String[len];
    		sequence_array = new long[len];
    		
            //if(destination != null && !destination.equals("")){
            	
            	for(int i=0;i<len;i++){
            		
            		String nowGiftSn = GIFT_SN_LIST[i];
            		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]nowGiftSn:"+nowGiftSn);
            		
            		body.put("Account", account);
                	body.put("GiftID", nowGiftSn);
                	body.put("TransactionType", transactionType);
                	body.put("Fee", fee);
                	body.put("Sequence", sequence+i);            	
                	body.put("Destination", destination);
                	
                	tx_json = body.toString();
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]tx_json:"+tx_json);  
                	                	
                	stobject = STObject.fromJSON(tx_json);
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]stobject.toHex():"+stobject.toHex());
                	signed2 = SignedTransaction.fromTx((com.ripple.core.types.known.tx.Transaction) stobject);
                	signed2.sign(secret);
                	
                	tx_blob = signed2.tx_blob;
                	hash = signed2.hash;
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]tx_blob:"+tx_blob);
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]TransactionID(HASH):"+hash); 
                
                	tx_blob_array[i] = tx_blob;
                	sequence_array[i] = sequence+i;
                	
                	resMap.put("tx_blob_array", tx_blob_array);
                	resMap.put("sequence_array", sequence_array);
            	} 
            	
            //}       	      	     	
        	                       
        } catch(BizRuntimeException be) {            
            log.error("<오류> <비즈니스오류> " + be.getMessage());
            be.printStackTrace();
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]**BizRuntimeException**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+be.getMessage());
            throw be;            
        } catch(Exception e) {            
            log.error("<오류> <일반오류> " + e.getMessage());
            e.printStackTrace();
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByApprove", "[로그정보]**Exception**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
		
        return resMap;
		
	}
    
   public HashMap makeSignByReject(IDataSet requestData, IOnlineContext onlineCtx){
		
	/*
	{
		  "method": "sign",
		  "params": [
		    {
		      "offline": false,
		      "secret": "상품권 발행자의 secret",
		      "tx_json": {
		        "Account": "상품권 발행자의 address",
		        "GiftID": "상품권 ID", // 상품권 Object의 ID(account_objects 조회 시 index field)
		        "TransactionType": "GiftFund",
		        "Amount": {
		          "currency": "통화타입",
		          "issuer": "counter_party_address",
		          "value”: “상품권에 충전할 금액"
		        }
		      }
		    }
		  ]
		}
		*/	
		Log log = getLog(onlineCtx);		
		JSONObject body = new JSONObject();	
		JSONObject innerbody = new JSONObject();
		
		String GIFT_REV_USER_ID = new String("");
		String GIFT_SN_LIST_STR = new String("");
		String GIFT_SND_USER_ID_LIST_STR = new String("");
		String[] GIFT_SN_LIST = new String[]{};
		String[] GIFT_SND_USER_ID_ARR = new String[]{};
		int len = 0;
						
		String secret = new String("");
		secret = GTPRESENT.GT_NET_PRESENT_TRANS_SECRET;
		String tx_json = new String("");
		String account = new String("");
		account = GTPRESENT.GT_NET_PRESENT_TRANS_ADDRESS;
		
		String giftId = "1234";
		String transactionType = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_REJECT_TYPE;
		String fee = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_FEE;
		long sequence = 0;
		String destination = new String("");	
		
		STObject stobject = null;
		SignedTransaction signed2 = null;
		
		String tx_blob = new String("");
		Hash256 hash;
		
		IDataSet res1 = null;
		IDataSet res2 = null;
				
		String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};
		
		HashMap resMap = new HashMap();
		
		IDataSet accInfoRes = new DataSet();
        JSONObject jsonAccObj = new JSONObject();
		JSONObject jsonAccResult = new JSONObject();
		JSONObject jsonAccData = new JSONObject();
				
        try { 
        	
        	if(requestData.get("GIFT_REV_USER_ID") != null){
        		
        		GIFT_REV_USER_ID = requestData.getString("GIFT_REV_USER_ID");
        		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        		
        		//받는 사람 주소 가져오기
        		res1 = dGIFT_02.s012(requestData, onlineCtx);
        		destination = res1.getString("USER_WAT_ADDR");       		
        		
        	}
        	
        	if(requestData.get("DESTINATION_ADDRESS") != null){
        		destination = requestData.getString("DESTINATION_ADDRESS");
        	}
        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]destination:"+destination);
        	        	
        	//보낸 사람 주소 가져오기
        	if(requestData.get("GIFT_SND_USER_ID_LIST_STR") != null){
        		
        		GIFT_SND_USER_ID_LIST_STR = requestData.getString("GIFT_SND_USER_ID_LIST_STR");
        		GIFT_SND_USER_ID_ARR =  GIFT_SND_USER_ID_LIST_STR.split(",");
        	}
        	
        	resMap.put("GIFT_SND_USER_ID", GIFT_SND_USER_ID_ARR[0]);
        	
        	requestData.put("GIFT_SND_USER_ID", GIFT_SND_USER_ID_ARR[0]);
        	res2 = dGIFT_02.s013(requestData, onlineCtx);
        	account = res2.getString("USER_WAT_ADDR");    
        	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]account:"+account);
        	        	
        	//sequence = dGIFT_02.s014(requestData, onlineCtx).getLong("GIFT_HIST_NO");//보낼때마다 +1  BCT_GIFT_HIST 최대 GIFT_HIST_NO + 1 값
        	
        	requestData.put("account_address", account);
        	accInfoRes = fGIFT01.fGetAccountInfo(requestData, onlineCtx);
   			jsonAccObj = (JSONObject) new JSONParser().parse(accInfoRes.getString("result"));
    		jsonAccResult = (JSONObject) new JSONParser().parse(jsonAccObj.get("result").toString());
    		
			String status = jsonAccResult.get("status").toString();
			
			FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]status:"+status);
			
			if (status.equals("success")) {
	
				jsonAccData = (JSONObject) new JSONParser().parse(jsonAccResult.get("account_data").toString());
				sequence = Integer.parseInt(jsonAccData.get("Sequence").toString());				
				FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]sequence:"+sequence);
			}
        	   
			sequence = getSequence();
			
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]sequence:"+sequence);
        	        	
        	GIFT_SN_LIST_STR = requestData.getString("GIFT_SN_LIST_STR");       	
        	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	
        	GIFT_SN_LIST = GIFT_SN_LIST_STR.split(",");
        	
        	resMap.put("GIFT_SN_LIST", GIFT_SN_LIST);
        	
        	len = GIFT_SN_LIST.length;
        	
        	tx_blob_array = new String[len];
    		sequence_array = new long[len];
    		
            //if(destination != null && !destination.equals("")){    		
            	for(int i=0;i<len;i++){
            		
            		String nowGiftSn = GIFT_SN_LIST[i];
            		FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]nowGiftSn:"+nowGiftSn);
            		
            		body.put("Account", account);
                	body.put("GiftID", nowGiftSn);
                	body.put("TransactionType", transactionType);
                	body.put("Sequence", sequence+i);
                	
                	innerbody.put("currency", GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_CURRENCY);
                	innerbody.put("issuer", GTPRESENT.GT_TG_COLDWAT_ADDR);
                	body.put("Fee", GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_FEE);
                	
                	requestData.put("GIFT_SN", nowGiftSn);
                	
                	res2 = dGIFT_02.s018(requestData, onlineCtx);
                	String GIFT_USE_AMT = res2.getString("GIFT_USE_AMT");               	
                	innerbody.put("value", GIFT_USE_AMT); 
                	
                	body.put("Amount", innerbody);                	
                	
                	tx_json = body.toString();
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]tx_json:"+tx_json);  
                	
                	
                	stobject = STObject.fromJSON(tx_json);
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]stobject.toHex():"+stobject.toHex());
                	signed2 = SignedTransaction.fromTx((com.ripple.core.types.known.tx.Transaction) stobject);
                	signed2.sign(secret);
                	
                	tx_blob = signed2.tx_blob;
                	hash = signed2.hash;
                	
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]tx_blob:"+tx_blob);
                	FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]INFO", "[줄번호]"+getLineNumber()+"[정보]TransactionID(HASH):"+hash); 
                               	
                	tx_blob_array[i] = tx_blob;
                	sequence_array[i] = sequence+i;
                	
                	resMap.put("tx_blob_array", tx_blob_array);
                	resMap.put("sequence_array", sequence_array);
            	} 
            	
            //}       	      	     	
        	                       
        } catch(BizRuntimeException be) {            
            log.error("<오류> <비즈니스오류> " + be.getMessage());
            be.printStackTrace();
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]**BizRuntimeException**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+be.getMessage());
            throw be;            
        } catch(Exception e) {            
            log.error("<오류> <일반오류> " + e.getMessage());
            e.printStackTrace();
            FGIFT_01.fPrintLog("[프로세스]PGIFT", "[메서드]makeSignByReject", "[로그정보]**Exception**ERROR", "[줄번호]"+getLineNumber()+"[정보]"+e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
		
        return resMap;
		
	}
	
	/**
	 * [PM]상품권 - 선물하기 - SK Coin Net .
	 * <pre>
	 * [PM]상품권 - 선물하기 - SK Coin Net 
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 23:34:24
	 */
	@BizMethod("[PM]상품권 - 선물하기 - SK Coin Net ")
	public IDataSet pGiftSendCoinNet(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
		IDataSet responseDataSet = new DataSet();
        Log log = getLog(onlineCtx);
        HashMap<String, String> headers = new  HashMap<String, String>();        
        String tx_blob = "";
        String method = "submit";
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObj = new JSONObject();
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonResObj = new JSONObject();
        JSONObject jsonResObj2 = new JSONObject();
        JSONObject jsonBodyObj = new JSONObject();
        //              보내는 사람 address                             보내는 사람 secret   
        //BOB Server3	r3mNozMsgzXoE49JwzZCixYYyZE8int43f	snvRHiVvk9vrJYy8Gvn49uCEERWm1	상품권 중계 계정 ( GiftSend 시에 사용 )
        
        Object resObj = new Object();
        String status = "";
        HashMap resMap = new HashMap();
        String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};
		int len = 0;
				
	    String GIFT_REV_USER_ID = "";
	    String GIFT_SN_LIST_STR  = "";
	    String[] GIFT_SN_ARR = new String[]{};
	    String GIFT_SND_USER_ID = "";
	    String GIFT_REV_CONT = "";
	   	    
	    //PUSH일 경우 대상, 상품권 금액 조회 
	    String GIFT_REV_USER_NM = "";
	    long GIFT_AMT = 0;
	    String GIFT_KND_KOR = "";
	    
	    List<Map<String, Object>> listMsg = new ArrayList<Map<String, Object>>();
	    Map<String, Object> mapMsg = new HashMap<String, Object>();
	    String strFormattedAmt = "0";
	    
	    String GIFT_REV_USER_NAME = "";	    
	    String GIFT_REV_USER_PHONE = "";
	    String GIFT_SND_USER_NM = "";
	    long TOTAL_PRESENT_SUM = 0;

        try {     
        	
        	if(requestData.get("GIFT_REV_USER_ID") != null){
        		GIFT_REV_USER_ID = (String)requestData.get("GIFT_REV_USER_ID");
        	}else{
        		GIFT_REV_USER_ID = dGIFT_02.s011(requestData, onlineCtx).getString("USER_ID");//상품권 발송자 아이디
        	}
        	
        	if(requestData.getString("GIFT_REV_USER_NAME") != null){
        		GIFT_REV_USER_NAME = requestData.getString("GIFT_REV_USER_NAME");        		
        	}
        	
        	if(requestData.getString("GIFT_REV_USER_PHONE") != null){
        		GIFT_REV_USER_PHONE = requestData.getString("GIFT_REV_USER_PHONE");        		
        	}
         	       	
        	GIFT_SN_LIST_STR = (String)requestData.get("GIFT_SN_LIST_STR");
        	GIFT_SN_ARR = GIFT_SN_LIST_STR.split(",");
        	GIFT_SND_USER_ID = (String)requestData.get("GIFT_SND_USER_ID");
        	
        	if((String)requestData.get("GIFT_REV_CONT") != null){
        		GIFT_REV_CONT = (String)requestData.get("GIFT_REV_CONT");
        	}      	
        	        	
        	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);
        	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_CONT:"+GIFT_REV_CONT);
        	
        	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_NAME:"+GIFT_REV_USER_NAME);
        	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_PHONE:"+GIFT_REV_USER_PHONE);
        	
        	requestData.put("GIFT_USE_USER_ID", GIFT_REV_USER_ID);
        	requestData.put("GIFT_REV_USER_NAME", GIFT_REV_USER_NAME);
        	requestData.put("GIFT_REV_USER_PHONE", GIFT_REV_USER_PHONE);
        	requestData.put("GIFT_REV_USER_ID", GIFT_REV_USER_ID);
        	
        	len = GIFT_SN_ARR.length;
	        
        	resMap = makeSign(requestData, onlineCtx);
        	
        	if(requestData.getString("method") == null || !requestData.getString("method").equals("submit")){
        		requestData.put("method", "submit");
        	}
        	
        	//if(resMap != null && resMap.get("tx_blob_array") != null && sequence_array != null){
        		
        		tx_blob_array  = (String[])resMap.get("tx_blob_array");
            	sequence_array = (long[])sequence_array;
            	
            	len = tx_blob_array.length;
            	      	
            	for(int i=0;i<len;i++){
            		
            		jsonArray = new JSONArray();
                    jsonObj = new JSONObject();
                    jsonBodyObj = new JSONObject();
            		
            		jsonObj.put("tx_blob",tx_blob_array[i]);
            		jsonArray.add(jsonObj); 
            		
            		jsonBodyObj.put("method", "submit");
            		jsonBodyObj.put("params", jsonArray);
            		
            		requestData.put("params", jsonBodyObj);
            		
            		FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "params:"+requestData.get("params").toString());
            		
            		responseData = fGIFT01.fGiftSendCoinNet(requestData, onlineCtx);
                	
                	FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "result:"+responseData.getString("result"));
                	
                	
                	resObj = jsonParser.parse(responseData.getString("result"));
                	jsonResObj = (JSONObject) resObj;
                	jsonResObj2 = (JSONObject)jsonResObj.get("result");
                	status = jsonResObj2.get("status").toString();
                	
                	FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "status:"+status);
                	
                	if(status.equals("success")){
                		
                		
                		//verify
                		JSONObject txJsonObj = (JSONObject)jsonResObj2.get("tx_json");
                		String tx_id = txJsonObj.get("hash").toString();
                		
                		FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "tx_id:"+tx_id);
                		
                		JSONArray jsonTxArray = new JSONArray();
                		JSONObject jsonTxObj = new JSONObject();
                		JSONObject jsonTxBodyObj = new JSONObject();
                		
                		jsonTxObj.put("transaction",tx_id);
                		jsonTxObj.put("binary",false);
                		jsonTxArray.add(jsonObj); 
                		
                		jsonTxBodyObj.put("method", "tx");
                		jsonTxBodyObj.put("params", jsonArray);
                		
                		requestData.put("params", jsonTxBodyObj);
                		
                		responseDataSet = fGIFT01.fGiftSendResultConfirmCoinNet(requestData, onlineCtx);
                    	
                    	FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "confirm result:"+responseData.getString("result"));
                    	                	
                    	resObj = jsonParser.parse(responseData.getString("result"));
                    	jsonResObj = (JSONObject) resObj;
                    	jsonResObj2 = (JSONObject)jsonResObj.get("result");
                    	status = jsonResObj2.get("status").toString();
                    	FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "conmfirm status:"+status);
                    	
                    	//if(jsonResObj2.get("validated") != null && Boolean.parseBoolean(jsonResObj2.get("validated").toString()) == true){
                    		
                    		//boolean validated = Boolean.parseBoolean(jsonResObj2.get("validated").toString());
                    		//FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "conmfirm validated:"+validated);
                    		
                    		String GIFT_SN = GIFT_SN_ARR[i];
                    		
                    		FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_SN:"+GIFT_SN);
                    		
                    		requestData.put("GIFT_SN", GIFT_SN); 
                    		
                 		   //HISTORY TABLE 업데이트        	
                        	dGIFT_02.u001(requestData, onlineCtx);
                    		
                    		//HISTORY TABLE 인서트
                    		dGIFT_02.i001(requestData, onlineCtx);
                    		
                    		//상품권 테이블 업데이트
                    	    dGIFT_02.u002(requestData, onlineCtx);
                    	    
                    	    //PUSH 메세지 발송       	    
                    	    
                            if(!GIFT_REV_USER_NAME.equals("") 
                               && !GIFT_REV_USER_PHONE.equals("")){
                            	
                            	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_NAME:"+GIFT_REV_USER_NAME); 
                            	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_PHONE:"+GIFT_REV_USER_PHONE);
                            	GIFT_REV_USER_NM = GIFT_REV_USER_NAME;//PUSH 대상 이름 조회
                        	    GIFT_AMT = dGIFT_02.s005(requestData, onlineCtx).getLong("GIFT_AMT");//상품권 액수
                        	    GIFT_KND_KOR = dGIFT_02.s005(requestData, onlineCtx).getString("GIFT_KND_KOR");//상품권 액수    	    	
                    	    	
                    	    }else{
                    	    	                    	
                    	    	FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_ID:"+GIFT_REV_USER_ID); 
                                GIFT_REV_USER_NM = dGIFT_02.s004(requestData, onlineCtx).getString("USER_NAME");//PUSH 대상 이름 조회
                             	GIFT_AMT = dGIFT_02.s005(requestData, onlineCtx).getLong("GIFT_AMT");//상품권 액수
                             	GIFT_KND_KOR = dGIFT_02.s005(requestData, onlineCtx).getString("GIFT_KND_KOR");//상품권 액수  	    	      	    	
                         	         	    	 
                    	    }       	    
                    	    
                    	    FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_NM:"+GIFT_REV_USER_NM);
                    	    FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_AMT:"+GIFT_AMT);
                    	    FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_KND_KOR:"+GIFT_KND_KOR);
                    	    
                    	    TOTAL_PRESENT_SUM += GIFT_AMT;
                    	    
                    	    GIFT_SND_USER_NM = dGIFT_02.s010(requestData, onlineCtx).getString("USER_NAME");//상품권 발송자 이름
                    	    FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_SND_USER_NM:"+GIFT_SND_USER_NM);
                    	    
                    	    //if(requestData.get("GIFT_REV_USER_ID") != null && GIFT_REV_USER_NM != null 
                    	    //		&& !GIFT_REV_USER_NM.equals("")){ //회원일 경우, 존재할 경우
                    	    
                    	    listMsg = new ArrayList<Map<String, Object>>();
                	        mapMsg = new HashMap<String, Object>();
                	               			       			
                    			//if(i == len - 1){  
                    				
                    				 strFormattedAmt = String.format("%,d", GIFT_AMT);
                    	    	     FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "strFormattedAmt:"+strFormattedAmt);
                    	        	    
                    	        	 if(GIFT_REV_USER_ID == null || GIFT_REV_USER_ID.equals("")){
                    	        		 
                    	        		FGIFT_01.fPrintLog("PGIFT", "pGiftSendCoinNet", "INFO", "GIFT_REV_USER_ID == null || GIFT_REV_USER_ID.equals('')::GIFT_REV_USER_PHONE:"+GIFT_REV_USER_PHONE);        	        	    	
                    	        	 	requestData.put("SEND_TYPE", "N");  
                    	        	 	requestData.put("MSG_ID", "3");//메세지 아이디 설정
                    	        	    mapMsg.put("USER_ID", GIFT_REV_USER_PHONE);
                    	        	    	
                    	        	 }else{
                    	        	    		
                    	        	 	requestData.put("SEND_TYPE", "S");//S : SMS 전송, P : PUSH 전송  , A : PUSH SMS 전송 , N: 비회웡 SMS 전송
                    	        	 	requestData.put("MSG_ID", "3");//메세지 아이디 설정 
                    	        	    mapMsg.put("USER_ID", GIFT_REV_USER_ID);
                    	        	 }
                    	        	    	      	       
                    	        	 mapMsg.put("TITLE", GIFT_REV_USER_NM);
                    	        	 mapMsg.put("CONT", GIFT_SND_USER_NM+"|"+GIFT_KND_KOR+"|"+strFormattedAmt);
                    	        	        
                    	        	 listMsg.add(mapMsg);
                    	        	      
                    	        	requestData.put("MSG_DATA", listMsg);
                    				
                    				//SMS 전송
                            	    responseData = callSharedMethodByDirect("com.skcc.bcsvc.co", "FBASE.fMobMsgSend", requestData, onlineCtx);
                    			//}
                        	              		
                        	//}       	    
                    	//}          		
                		
                	}else{
                		//데이터 처리 없은
                	}            	
            		
            	}         	
            	
            	/**
            	 * {
            	 *   "result": {
            	 *     "engine_result": "tesSUCCESS",
            	 *     "engine_result_code": 0,
            	 *     "engine_result_message": "ddd",
            	 *     "status": "success",
            	 *     "tx_blob": "122ww",
            	 *     "tx_json":{
            	 *       "Account": "rnz",
            	 *       "Destination": "rDmW",
            	 *       "Fee": "10",
            	 *       "Flags": 214,
            	 *       "GiftID": "223",
            	 *       "Sequence": 3,
            	 *       "SigningPubKey": "233",
            	 *       "TransactionType": "GiftSend",
            	 *       "TxnSignature": "340",
            	 *       "hash": "799"
            	 *     }
            	 *   }
            	 *   
            	 * }
            	 * 
            	 * 
            	 */
        		
        	//}
        	
        	
        	        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {            
            log.error("<오류> <비즈니스오류> " + be.getMessage());
            be.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;            
        } catch(Exception e) {            
            log.error("<오류> <일반오류> " + e.getMessage());
            e.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;			
	}
	
    public HashMap makeSign(IDataSet requestData, IOnlineContext onlineCtx){
		
		Log log = getLog(onlineCtx);		
		JSONObject body = new JSONObject();	
		
		String GIFT_SND_USER_ID = "";
		String GIFT_REV_USER_ID = "";
		String GIFT_SN_LIST_STR = "";
		String[] GIFT_SN_LIST = new String[]{};
		int len = 0;
						
		String secret = "spvqdUaD56J1LmjLHSKoYWFdJM9EZ";
		secret = GTPRESENT.GT_NET_PRESENT_TRANS_SECRET;
		String tx_json = "";
		String account = "rnztCX1xpRWnfEbYvbmJXY1hETxmRZnH9N";//보내는 사람아이디에 의해 wallet 주소 가져오기 
		account = GTPRESENT.GT_NET_PRESENT_TRANS_ADDRESS;
		
		String giftId = "1234";
		String transactionType = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_TYPE;
		String fee = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_FEE;
		long sequence = 3;
		String destination = "rDmWNq1EGSBqRXWv9ZAFDqW6BqSoVCG2ML";//받는 사람 아이디에 의해 wallet 주소 가져오기	
		
		STObject stobject = null;
		SignedTransaction signed2 = null;
		
		String tx_blob = "tx_blob245342dd";
		Hash256 hash;
		
		IDataSet res1 = null;
		IDataSet res2 = null;
		IDataSet res3 = null;
		
		String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};
		
		HashMap resMap = new HashMap();
		
		IDataSet accInfoRes = new DataSet();
        JSONObject jsonAccObj = new JSONObject();
		JSONObject jsonAccResult = new JSONObject();
		JSONObject jsonAccData = new JSONObject();
		
		String GIFT_REV_USER_NAME = "";
		String GIFT_REV_USER_PHONE = "";
		
        try { 
        	
        	if(requestData.get("GIFT_REV_USER_ID") != null){
        		
        		GIFT_REV_USER_ID = requestData.getString("GIFT_REV_USER_ID");
        		FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        		
        		//받는 사람 주소 가져오기
        		res1 = dGIFT_02.s012(requestData, onlineCtx);
        		destination = res1.getString("USER_WAT_ADDR");       		
        		
        	}else{
        		
        		/*if(requestData.get("GIFT_REV_USER_NAME") != null && requestData.get("GIFT_REV_USER_PHONE") != null){
            		
        			GIFT_REV_USER_NAME = requestData.getString("GIFT_REV_USER_NAME"); 
            		GIFT_REV_USER_PHONE = requestData.getString("GIFT_REV_USER_PHONE");   
            		
            		requestData.put("GIFT_USER_SEARCH", "NAME_PHONE");
            		requestData.put("USER_NAME", GIFT_REV_USER_NAME);
            		requestData.put("USER_PHONE", GIFT_REV_USER_PHONE);
            		
            		destination = dGIFT_02.s015(requestData, onlineCtx).getString("USER_WAT_ADDR");
            		        		
            	}*/      		
        		
        	}
        	
        	if(requestData.get("DESTINATION_ADDRESS") != null){
        		destination = requestData.getString("DESTINATION_ADDRESS");
        	}
        	
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "destination:"+destination);
        	        	
        	GIFT_SND_USER_ID = requestData.getString("GIFT_SND_USER_ID");        	
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);
        	
        	//보내는 사람 주소 가져오기
        	res2 = dGIFT_02.s013(requestData, onlineCtx);
        	account = res2.getString("USER_WAT_ADDR");    
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "account:"+account);
        	
        	
        	sequence = dGIFT_02.s014(requestData, onlineCtx).getLong("GIFT_HIST_NO");//보낼때마다 +1  BCT_GIFT_HIST 최대 GIFT_HIST_NO + 1 값
        	
        	requestData.put("account_address", account);
        	accInfoRes = fGIFT01.fGetAccountInfo(requestData, onlineCtx);
   			jsonAccObj = (JSONObject) new JSONParser().parse(accInfoRes.getString("result"));
    		jsonAccResult = (JSONObject) new JSONParser().parse(jsonAccObj.get("result").toString());
    		
			String status = jsonAccResult.get("status").toString();
			
			FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "status:"+status);
			
			if (status.equals("success")) {
	
				jsonAccData = (JSONObject) new JSONParser().parse(jsonAccResult.get("account_data").toString());
				sequence = Integer.parseInt(jsonAccData.get("Sequence").toString());
				sequence = 200000000;
				FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "sequence123:"+sequence);
			}
        	    		
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "sequence:"+sequence);
        	        	
        	GIFT_SN_LIST_STR = requestData.getString("GIFT_SN_LIST_STR");       	
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	
        	GIFT_SN_LIST = GIFT_SN_LIST_STR.split(",");
        	
        	len = GIFT_SN_LIST.length;
        	
        	tx_blob_array = new String[len];
    		sequence_array = new long[len];
    		
            //if(destination != null && !destination.equals("")){
            	
            	for(int i=0;i<len;i++){
            		
            		String nowGiftSn = GIFT_SN_LIST[i];
            		FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "nowGiftSn:"+nowGiftSn);
            		
            		body.put("Account", account);
                	body.put("GiftID", nowGiftSn);
                	body.put("TransactionType", transactionType);
                	body.put("Fee", fee);
                	body.put("Sequence", sequence+i);            	
                	body.put("Destination", destination);
                	
                	tx_json = body.toString();
                	
                	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "tx_json:"+tx_json);  
                	
                	
                	stobject = STObject.fromJSON(tx_json);
                	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "stobject.toHex():"+stobject.toHex());
                	signed2 = SignedTransaction.fromTx((com.ripple.core.types.known.tx.Transaction) stobject);
                	signed2.sign(secret);
                	
                	tx_blob = signed2.tx_blob;
                	hash = signed2.hash;
                	
                	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "tx_blob:"+tx_blob);
                	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "TransactionID(HASH):"+hash); 
                	
                	// Ripple base58 decoded hex value 계산하는 방법(Gift ID를 수동으로 계산시 활용)
                	//System.out.println(AccountID.fromAddress("raFp133rSH9Gc1bhZQxk6kY7MdUYaBKLwY").toHex());
                	 
                	// Sign Data 확인(사용자 wallet으로 부터 받은 데이터 확인)
                	//System.out.print(STObject.fromHex(signed2.tx_blob).toJSON());
                	
                	tx_blob_array[i] = tx_blob;
                	sequence_array[i] = sequence+i;
                	
                	resMap.put("tx_blob_array", tx_blob_array);
                	resMap.put("sequence_array", sequence_array);
            	} 
            	
            //}       	      	     	
        	                       
        } catch(BizRuntimeException be) {            
            log.error("<오류> <비즈니스오류> " + be.getMessage());
            be.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;            
        } catch(Exception e) {            
            log.error("<오류> <일반오류> " + e.getMessage());
            e.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
		
        return resMap;
		
	}
    
    public static int getLineNumber() {
    	return Thread.currentThread().getStackTrace()[2].getLineNumber();
    }
    
    private static long getSequence(){
		
		Date today = new Date();
		SimpleDateFormat sdf = null;
		
		sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		long seq =  Long.parseLong(sdf.format(today));
		
		System.out.println(seq);
		
		return seq;
		
	} 

  
}