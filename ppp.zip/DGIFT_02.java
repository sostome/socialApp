package com.skcc.bcsvc.gift.biz;

import java.util.Map;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;

/**
 * [DU]상품권 - 선물하기.
 * <pre>
 * [DU]상품권 - 선물하기
 * </pre>
 * 
 * @author baekjg (백진구)
 * @since 2018-07-13 20:02:30
 */
@BizUnit("[DU]상품권 - 선물하기")
public class DGIFT_02 extends nexcore.framework.biz.online.DataUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */

	/**
	 * Default Constructor
	 */
	public DGIFT_02(){
		super();
	}

	/**
	 * [DM]상품권 - 선물하기 -  BCT_GIFT_HIST 초기 업데이트.
	 * <pre>
	 * [DM]상품권 - 선물하기 -  BCT_GIFT_HIST 초기 업데이트
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 20:06:10
	 */
	@BizMethod("[DM]상품권 - 선물하기 -  BCT_GIFT_HIST 초기 업데이트")
	public IDataSet u001(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);	    
	    int row = 0;

		try{
	    	
			row = dbUpdate("U001", requestData, onlineCtx);   	  
			responseData.put("EXPECTED_ROW", row);
	    	
		} catch(BizRuntimeException be) {        	
            log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("DGIFT_02", "u001", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {        	
            log.error("<오류> <Exception> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("DGIFT_02", "u001", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	    
	}

	/**
	 * [DM]상품권 - 선물하기 - 선물 가능 대상자 목록.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 선물 가능 대상자 목록
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 20:14:39
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 선물 가능 대상자 목록")
	public IDataSet s001(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    IRecordSet recordset = dbSelect( "S001", requestData, onlineCtx);

	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 선물 가능 상품권 목록.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 선물 가능 상품권 목록
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 20:18:09
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 선물 가능 상품권 목록")
	public IDataSet s002(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    IRecordSet recordset = dbSelect( "S002", requestData, onlineCtx);

	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - BCT_GIFT_HIST 입력.
	 * <pre>
	 * [DM]상품권 - 선물하기 - BCT_GIFT_HIST 입력
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 20:32:37
	 */
	@BizMethod("[DM]상품권 - 선물하기 - BCT_GIFT_HIST 입력")
	public IDataSet i001(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);	    
	    int row = 0;

		try{
	    	
			row = dbInsert("I001", requestData, onlineCtx);	   	  
			responseData.put("EXPECTED_ROW", row);
	    	
		} catch(BizRuntimeException be) {        	
            log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("DGIFT_02", "i001", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {        	
            log.error("<오류> <Exception> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("DGIFT_02", "i001", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - BCT_GIFT - GIFT_STATE_CD 007005 업데이트.
	 * <pre>
	 * [DM]상품권 - 선물하기 - BCT_GIFT - GIFT_STATE_CD 007005 업데이트
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 20:45:12
	 */
	@BizMethod("[DM]상품권 - 선물하기 - BCT_GIFT - GIFT_STATE_CD 007005 업데이트")
	public IDataSet u002(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);	    
	    int row = 0;

		try{
	    	
			row = dbUpdate("U002", requestData, onlineCtx);   	  
			responseData.put("EXPECTED_ROW", row);
	    	
		} catch(BizRuntimeException be) {        	
            log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("DGIFT_02", "u002", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {        	
            log.error("<오류> <Exception> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("DGIFT_02", "u002", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 승인.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 승인
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 21:37:45
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 승인")
	public IDataSet u003(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);	    
	    int row = 0;

		try{
	    	
			row = dbUpdate("U003", requestData, onlineCtx);   	  
			responseData.put("EXPECTED_ROW", row);
	    	
		} catch(BizRuntimeException be) {        	
            log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("DGIFT_02", "u003", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {        	
            log.error("<오류> <Exception> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("DGIFT_02", "u003", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 거부 - BCT_GIFT_HIST 업데이트.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 거부 - BCT_GIFT_HIST 업데이트
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 21:55:56
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 거부 - BCT_GIFT_HIST 업데이트")
	public IDataSet u004(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);	    
	    int row = 0;

		try{
	    	
			row = dbUpdate("U004", requestData, onlineCtx);   	  
			responseData.put("EXPECTED_ROW", row);
	    	
		} catch(BizRuntimeException be) {        	
            log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("DGIFT_02", "u004", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {        	
            log.error("<오류> <Exception> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("DGIFT_02", "u004", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 거부 - GIFT_SND_USER_ID 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 거부 - GIFT_SND_USER_ID 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 22:00:45
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 거부 - GIFT_SND_USER_ID 조회")
	public IDataSet s003(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S003", requestData, onlineCtx);
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s003", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s003", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 거부 - BCT_GIFT 업데이트.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 거부 - BCT_GIFT 업데이트
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-13 22:12:58
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 거부 - BCT_GIFT 업데이트")
	public IDataSet u005(IDataSet requestData, IOnlineContext onlineCtx) {
	   
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);	    
	    int row = 0;

		try{
	    	
			row = dbUpdate("U005", requestData, onlineCtx);   	  
			responseData.put("EXPECTED_ROW", row);
	    	
		} catch(BizRuntimeException be) {        	
            log.error("<오류> <BizRuntimeException> " + be.getMessage(), be);
            FGIFT_01.fPrintLog("DGIFT_02", "u005", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {        	
            log.error("<오류> <Exception> " + e.getMessage(), e);
            FGIFT_01.fPrintLog("DGIFT_02", "u005", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - PUSH 대상 이름 전화번호 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - PUSH 대상 이름 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 13:32:13
	 */
	@BizMethod("[DM]상품권 - 선물하기 - PUSH 대상 이름 전화번호 조회")
	public IDataSet s004(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S004", requestData, onlineCtx);//requsetData에 GIFT_REV_USER_ID가 있어야 함
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s004", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s004", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - PUSH 상품권 금액 종류 조회 - GIFT_SN.
	 * <pre>
	 * [DM]상품권 - 선물하기 - PUSH 상품권 금액 조회 - GIFT_SN
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 13:36:56
	 */
	@BizMethod("[DM]상품권 - 선물하기 - PUSH 상품권 금액 종류 조회 - GIFT_SN")
	public IDataSet s005(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S005", requestData, onlineCtx);//requsetData에 GIFT_SN가 있어야 함
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s005", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s005", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 도착 -  수량, 액수, 커멘트 .
	 * <pre>
	 * [DM]상품권 - 선물하기 - 도착 -  수량, 액수, 커멘트 
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 18:16:28
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 도착 -  수량, 액수, 커멘트 ")
	public IDataSet s006(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    IRecordSet recordset = dbSelect( "S006", requestData, onlineCtx);

	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 완료.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 완료
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 18:37:52
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 완료")
	public IDataSet s007(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    IRecordSet recordset = dbSelect( "S007", requestData, onlineCtx);

	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 도착 - 발신자 정보 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 도착 - 발신자 정보 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-17 10:22:05
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 도착 - 발신자 정보 조회")
	public IDataSet s008(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S008", requestData, onlineCtx);//requsetData에 GIFT_SND_USER_ID가 있어야 함
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s008", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s008", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 완료 - 받는 사람 정보.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 완료 - 받는 사람 정보
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-17 13:20:24
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 완료 - 받는 사람 정보")
	public IDataSet s009(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S009", requestData, onlineCtx);//requsetData에 GIFT_REV_USER_ID가 있어야 함
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s009", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s009", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 승인,거부 - 발송 대상자 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 승인,거부 - 발송 대상자 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-17 14:38:06
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 승인,거부 - 발송 대상자 조회")
	public IDataSet s010(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S010", requestData, onlineCtx);//requsetData에 GIFT_SND_USER_ID가 있어야 함
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s010", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s010", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 주소록 정보 전송 사용자 - 아이디 검색 .
	 * <pre>
	 * [DM]상품권 - 선물하기 - 주소록 정보 전송 사용자 - 아이디 검색 
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * <pre>
	 * </pre>
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * <pre>
	 * </pre>
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-19 16:56:20
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 주소록 정보 전송 사용자 - 아이디 검색 ")
	public IDataSet s011(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    IRecord record = null;

		try{
	    	
	    	record = dbSelectSingle("S011", requestData, onlineCtx);//requsetData에 GIFT_REV_USER_NAME와 GIFT_REV_USER_PHONE이 있어야 함
	   	  
	 	    if (record != null){
	 	        responseData.putAll(record);
	 	    }
	    	
		} catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s011", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FGIFT_01.fPrintLog("DGIFT_02", "s011", "**Exception**ERROR", e.getMessage());
        }
	    
	    return responseData;
	}
	
	/**
	 * [DM]상품권 - 선물하기 - 보내는 사람 주소 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 보내는 사람 주소 가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 12:08:20
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 보내는 사람 주소 조회")
	public IDataSet s012(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	  
	    IRecord record = dbSelectSingle("S012", requestData, onlineCtx);
	   
	    if (record != null){
	        responseData.putAll(record);
	    }	  
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 받는 사람 주소 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 받는 사람 주소 가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 13:17:56
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 받는 사람 주소 조회")
	public IDataSet s013(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	   
	    IRecord record = dbSelectSingle("S013", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	    	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - BCT_GIFT_HIST GIFT_HIST_NO 최대값+1조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - BCT_GIFT_HIST GIFT_HIST_NO 최대값+1가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 14:19:40
	 */
	@BizMethod("[DM]상품권 - 선물하기 - BCT_GIFT_HIST GIFT_HIST_NO 최대값+1조회")
	public IDataSet s014(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	   
	    IRecord record = dbSelectSingle("S014", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	    	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 이름,전화번호, wallet 주소등으로 검색 .
	 * <pre>
	 * [DM]상품권 - 선물하기 - 이름,전화번호, wallet 주소등으로 검색 
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 16:49:34
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 이름,전화번호, wallet 주소등으로 검색 ")
	public IDataSet s015(IDataSet requestData, IOnlineContext onlineCtx) {
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	   
	    IRecord record = dbSelectSingle("S015", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	    	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 승인 거절 처리 리스트 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 승인 거절 처리 리스트 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 17:41:28
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 승인 거절 처리 리스트 조회")
	public IDataSet s016(IDataSet requestData, IOnlineContext onlineCtx) {
	   
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    IRecordSet recordset = dbSelect( "S016", requestData, onlineCtx);

	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	
	    return responseData;
		
	}

	/**
	 * [DM]상품권 - 선물하기 - 승인 거절 처리 리스트 조회 2.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 승인 거절 처리 리스트 조회 2
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 19:33:18
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 승인 거절 처리 리스트 조회 2")
	public IDataSet s017(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    
	    IRecordSet recordset = dbSelect( "S017", requestData, onlineCtx);

	    if (recordset.getRecordCount() > 0){
	        responseData.put("rs", recordset);
	    }
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 사용액 조회.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 사용액 조회
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-21 20:18:31
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 사용액 조회")
	public IDataSet s018(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	   
	    IRecord record = dbSelectSingle("S018", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	    	
	    return responseData;
	}
  
}