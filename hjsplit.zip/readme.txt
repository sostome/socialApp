
HJSplit 3.0

Description
File splitting program for Windows XP, 7, Vista, 200x, NT, 9x, ME, Linux/Wine and all 64bit editions of Windows.
HJSplit is able to split files of any type and any size.

Homepage: www.hjsplit.org
Version: 3.0
Release date: November 11, 2010

Licence for use
Freeware. Free for private/personal use and free corporate (business, govermnent, non-profit, etc.) use.

Licence for distribution
You can distribute this program, freely and without charge (on CD-Roms, Websites, etc.) provided that you do not change the program or the zip file in any way, that the program is clearly freeware or shareware, that you do not ask any money for the program itself. You may charge a nominal fee for material and/or distribution costs.

Copyright 1995 - 2010 Freebyte.com
http://www.freebyte.com