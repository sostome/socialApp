package com.skcc.bcsvc.gift.biz;

import java.util.HashMap;
import java.util.Map;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.component.streotype.BizUnitBind;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.data.UserMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.ripple.core.coretypes.STObject;
import com.ripple.core.coretypes.hash.Hash256;
import com.ripple.core.types.known.tx.signed.SignedTransaction;
import com.skcc.bcsvc.gift.consts.GTPRESENT;

/**
 * [PU]상품권 - 선물하기.
 * <pre>
 * [PU]상품권 - 선물하기
 * </pre>
 * 
 * @author baekjg (백진구)
 * @since 2018-07-16 23:26:31
 */
@BizUnit("[PU]상품권 - 선물하기")
public class PGIFT_01 extends nexcore.framework.biz.online.ProcessUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */
	
	@BizUnitBind
	private FGIFT_01 fGIFT01;
	
	@BizUnitBind
	private DGIFT_02 dGIFT02;

	/**
	 * Default Constructor
	 */
	public PGIFT_01(){
		super();
	}

	/**
	 * [PM]상품권 - 선물하기 - SK Coin Net .
	 * <pre>
	 * [PM]상품권 - 선물하기 - SK Coin Net 
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 23:34:24
	 */
	@BizMethod("[PM]상품권 - 선물하기 - SK Coin Net ")
	public IDataSet pGiftSendCoinNet(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
        Log log = getLog(onlineCtx);
        HashMap<String, String> headers = new  HashMap<String, String>();        
        String tx_blob = "";
        String method = "submit";
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObj = new JSONObject();
        JSONParser jsonParser = new JSONParser();
        JSONObject jsonResObj = new JSONObject();
        Object resObj = new Object();
        String status = "";
        HashMap resMap = new HashMap();
        String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};
		int len = 0;

        try {        	
	        
        	resMap = makeSign(requestData, onlineCtx);
        	
        	if(requestData.getString("method") == null || !requestData.getString("method").equals("submit")){
        		requestData.put("method", "submit");
        	}
        	
        	tx_blob_array  = (String[])resMap.get("tx_blob_array");
        	sequence_array = (long[])sequence_array;
        	
        	len = tx_blob_array.length;
        	       	
        	for(int i=0;i<len;i++){
        		
        		jsonArray = new JSONArray();
                jsonObj = new JSONObject();
        		
        		jsonObj.put("tx_blob",tx_blob_array[i]);
        		jsonArray.add(jsonObj);    		
            	
        		requestData.put("params", jsonArray);
        		
        		FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "params:"+requestData.get("params").toString());
        		
        		responseData = fGIFT01.fGiftSendCoinNet(requestData, onlineCtx);
            	
            	FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "INFO", "result:"+responseData.getString("result"));
            	
            	resObj = jsonParser.parse(responseData.getString("result"));
            	jsonResObj = (JSONObject) resObj;
            	status = jsonResObj.get("status").toString();
            	
            	if(status.equals("success")){
            		//성공시  MCT_GIFT_HIST 데이터 입력
            		//성공시  MCT_GIFT 업데이트
            	}else{
            		//데이터 처리 없은
            	}
        		
        	}
        	
        	
        	
        	
        	/**
        	 * {
        	 *   "result": {
        	 *     "engine_result": "tesSUCCESS",
        	 *     "engine_result_code": 0,
        	 *     "engine_result_message": "ddd",
        	 *     "status": "success",
        	 *     "tx_blob": "122ww",
        	 *     "tx_json":{
        	 *       "Account": "rnz",
        	 *       "Destination": "rDmW",
        	 *       "Fee": "10",
        	 *       "Flags": 214,
        	 *       "GiftID": "223",
        	 *       "Sequence": 3,
        	 *       "SigningPubKey": "233",
        	 *       "TransactionType": "GiftSend",
        	 *       "TxnSignature": "340",
        	 *       "hash": "799"
        	 *     }
        	 *   }
        	 *   
        	 * }
        	 * 
        	 * 
        	 */
        	        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {            
            log.error("<오류> <비즈니스오류> " + be.getMessage());
            be.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;            
        } catch(Exception e) {            
            log.error("<오류> <일반오류> " + e.getMessage());
            e.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "pGiftSendCoinNet", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
	
	    return responseData;			
	}
	
    public HashMap makeSign(IDataSet requestData, IOnlineContext onlineCtx){
		
		Log log = getLog(onlineCtx);		
		IDataSet tranNoDataSet = new DataSet();
		String requestBody = "";
		JSONObject body = new JSONObject();	
		
		String GIFT_SND_USER_ID = "";
		String GIFT_REV_USER_ID = "";
		String GIFT_SN_LIST_STR = "";
		String[] GIFT_SN_LIST = new String[]{};
		int len = 0;
						
		String secret = "spvqdUaD56J1LmjLHSKoYWFdJM9EZ";
		String tx_json = "";
		String account = "rnztCX1xpRWnfEbYvbmJXY1hETxmRZnH9N";//보내는 사람아이디에 의해 wallet 주소 가져오기 
		String giftId = "1234";
		String transactionType = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_TYPE;
		String fee = GTPRESENT.GT_NET_GIFT_PRESENT_TRANSACTION_FEE;
		long sequence = 3;
		String destination = "rDmWNq1EGSBqRXWv9ZAFDqW6BqSoVCG2ML";//받는 사람 아이디에 의해 wallet 주소 가져오기
		
		STObject stobject = null;
		SignedTransaction signed2 = null;
		
		String tx_blob = "";
		Hash256 hash;
		
		IDataSet res1 = null;
		IDataSet res2 = null;
		IDataSet res3 = null;
		
		String[] tx_blob_array = new String[]{};
		long[] sequence_array = new long[]{};
		
		HashMap resMap = new HashMap();
		
        try { 
        	
        	if(requestData.getString("GIFT_REV_USER_ID") != null){
        		
        		GIFT_REV_USER_ID = requestData.getString("GIFT_REV_USER_ID");
        		FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "GIFT_REV_USER_ID:"+GIFT_REV_USER_ID);
        		
        		//받는 사람 주소 가져오기
        		res1 = dGIFT02.s001(requestData, onlineCtx);
        		account = res1.getString("USER_WAT_ADDR");       		
        		
        	}
        	
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "account:"+account);
        	        	
        	GIFT_SND_USER_ID = requestData.getString("GIFT_SND_USER_ID");        	
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "GIFT_SND_USER_ID:"+GIFT_SND_USER_ID);
        	//보내는 사람 주소 가져오기
        	res2 = dGIFT02.s002(requestData, onlineCtx);
        	destination = res2.getString("USER_WAT_ADDR");    
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "destination:"+destination);
        	
        	sequence = dGIFT02.s003(requestData, onlineCtx).getLong("GIFT_HIST_NO");//보낼때마다 +1  BCT_GIFT_HIST 최대 GIFT_HIST_NO + 1 값
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "sequence:"+sequence);
        	        	
        	GIFT_SN_LIST_STR = requestData.getString("GIFT_SN_LIST_STR");       	
        	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "GIFT_SN_LIST_STR:"+GIFT_SN_LIST_STR);
        	
        	GIFT_SN_LIST = GIFT_SN_LIST_STR.split(",");
        	
        	len = GIFT_SN_LIST.length;
        	
        	tx_blob_array = new String[len];
    		sequence_array = new long[len];
        	
        	for(int i=0;i<len;i++){
        		
        		String nowGiftSn = GIFT_SN_LIST[i];
        		FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "nowGiftSn:"+nowGiftSn);
        		
        		body.put("Account", account);
            	body.put("GiftID", nowGiftSn);
            	body.put("TransactionType", transactionType);
            	body.put("Fee", fee);
            	body.put("Sequence", sequence+i);
            	body.put("Destination", destination);
            	
            	tx_json = body.toString();
            	
            	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "tx_json:"+tx_json);           	
            	
            	stobject = STObject.fromJSON(tx_json);
            	signed2 = SignedTransaction.fromTx((com.ripple.core.types.known.tx.Transaction)stobject);
            	signed2.sign(secret);
            	
            	tx_blob = signed2.tx_blob;
            	hash = signed2.hash;
            	
            	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "tx_blob:"+tx_blob);
            	FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "INFO", "TransactionID(HASH):"+hash); 
            	
            	tx_blob_array[i] = tx_blob;
            	sequence_array[i] = sequence+i;
            	
            	resMap.put("tx_blob_array", tx_blob_array);
            	resMap.put("sequence_array", sequence_array);
        	}       	     	
        	                       
        } catch(BizRuntimeException be) {            
            log.error("<오류> <비즈니스오류> " + be.getMessage());
            be.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "**BizRuntimeException**ERROR", be.getMessage());
            throw be;            
        } catch(Exception e) {            
            log.error("<오류> <일반오류> " + e.getMessage());
            e.printStackTrace();
            FGIFT_01.fPrintLog("PGIFT_01", "makeSign", "**Exception**ERROR", e.getMessage());
            throw new BizRuntimeException("BCSVC-E000", e);
        }
		
        return resMap;
		
	}
  
}