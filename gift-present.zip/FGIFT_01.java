package com.skcc.bcsvc.gift.biz;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;

import com.skcc.bcsvc.gift.consts.GTCOMMON;
import com.skcc.bcsvc.gift.consts.GTPRESENT;


/**
 * [FM]상품권 - 선물하기.
 * <pre>
 * [FM]상품권 - 선물하기
 * </pre>
 * 
 * @author baekjg (백진구)
 * @since 2018-07-17 09:20:17
 */
@BizUnit("[FM]상품권 - 선물하기")
public class FGIFT_01 extends nexcore.framework.biz.online.FunctionUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */

	/**
	 * Default Constructor
	 */
	public FGIFT_01(){
		super();
	}

	/**
	 * [FM]상품권 - 선물하기 - SK Coin Net.
	 * <pre>
	 * [FM]상품권 - 선물하기 - SK Coin Net
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-15 09:23:08
	 */
	@BizMethod("[FM]상품권 - 선물하기 - SK Coin Net")
	public IDataSet fGiftSendCoinNet(IDataSet requestData, IOnlineContext onlineCtx) {
		
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	    String authorizationHeader = "";	    
	    HttpURLConnection httpURLConnection = null;
	    Field[] fields = null;
	    StringBuffer stringBuffer = new StringBuffer();
	    OutputStreamWriter outputStreamWriter = null;
	    
		try {
			
			//토큰 조회
			IDataSet authHeaderDS = callSharedMethodByDirect("com.skcc.bcsvc.bc", "FTOKEN.fGetOAUTH2SKTgTOKEN", requestData, onlineCtx);
			authorizationHeader = authHeaderDS.getString("authHeader");
			
			FGIFT_01.fPrintLog("FGIFT_01", "fGiftSendCoinNet", "INFO", "토큰 조회용 (authorization)HEADER 값:"+authorizationHeader);
			
			httpURLConnection = getHttpURLConnection(GTPRESENT.GT_NET_DEV_GIFT_PRESENT_URL, onlineCtx);			       
			httpURLConnection.setRequestProperty("Authorization", authorizationHeader);
			httpURLConnection.setRequestProperty("Content-Type", GTCOMMON.GT_HTTP_JSON_CONTENT_TYPE);
           
            outputStreamWriter = new OutputStreamWriter(httpURLConnection.getOutputStream());
            outputStreamWriter.write(requestData.get("params").toString());
            outputStreamWriter.flush();
           
            if (httpURLConnection.getResponseCode() == 200) {
            	
                BufferedReader bufferedReader = new BufferedReader( new InputStreamReader( httpURLConnection.getInputStream(), "EUC-KR" ));

                String inputLine;
                
                while ((inputLine = bufferedReader.readLine()) != null) {
                	stringBuffer.append(inputLine);
                }
                
                bufferedReader.close();            	
            }
            
            httpURLConnection.disconnect();
            
            responseData.put("result", stringBuffer);
            
		} catch (MalformedURLException e) {
			if(httpURLConnection != null){
				httpURLConnection.disconnect();				
			}
			e.printStackTrace();
            log.error("<오류> <MalformedURLException> " + e.getMessage());
            FGIFT_01.fPrintLog("FGIFT_01", "fGiftSendCoinNet", "**MalformedURLException**ERROR", e.getMessage());
		} catch (IOException e) {
			if(httpURLConnection != null){
				httpURLConnection.disconnect();				
			}
			e.printStackTrace();
            log.error("<오류> <IOException> " + e.getMessage());
            FGIFT_01.fPrintLog("FGIFT_01", "fGiftSendCoinNet", "**IOException**ERROR", e.getMessage());
		} catch (IllegalArgumentException e) {
			if(httpURLConnection != null){
				httpURLConnection.disconnect();				
			}
			e.printStackTrace();
            log.error("<오류> <IllegalArgumentException> " + e.getMessage());
            FGIFT_01.fPrintLog("FGIFT_01", "fGiftSendCoinNet", "**IllegalArgumentException**ERROR", e.getMessage());
		} 
	
	    return responseData;
	}
	
   public static HttpsURLConnection getHttpsURLConnection(String connect_url, IOnlineContext onlineCtx){
		    
	    URL url = null;
	    HttpsURLConnection httpsURLConnection = null;
	    
		try {		
			
			url = new URL(connect_url);
			httpsURLConnection = (HttpsURLConnection) url.openConnection();
	        httpsURLConnection.setRequestMethod(GTCOMMON.GT_HTTP_POST_METHOD);
	        httpsURLConnection.setDoOutput(GTCOMMON.GT_HTTP_DO_OUTPUT);
	        httpsURLConnection.setConnectTimeout(GTCOMMON.GT_HTTP_CONNECT_TIME_OUT);
	        httpsURLConnection.setReadTimeout(GTCOMMON.GT_HTTP_READ_TIME_OUT);
	        httpsURLConnection.setInstanceFollowRedirects(GTCOMMON.GT_HTTP_INSTANCE_FOLLOW_REDIRECTS);	       
			            
		} catch (MalformedURLException e) {
			e.printStackTrace();           
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpsURLConnection", "**MalformedURLException**ERROR", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();           
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpsURLConnection", "**IOException**ERROR", e.getMessage());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpsURLConnection", "**IllegalArgumentException**ERROR", e.getMessage());
		}    
	
	    return httpsURLConnection;
		
	}
    
    public static HttpURLConnection getHttpURLConnection(String connect_url, IOnlineContext onlineCtx){
		   
	    URL url = null;
	    HttpURLConnection httpURLConnection = null;
	    
		try {		
			
			url = new URL(connect_url);
			httpURLConnection = (HttpURLConnection) url.openConnection();
	        httpURLConnection.setRequestMethod(GTCOMMON.GT_HTTP_POST_METHOD);
	        httpURLConnection.setDoOutput(GTCOMMON.GT_HTTP_DO_OUTPUT);
	        httpURLConnection.setConnectTimeout(GTCOMMON.GT_HTTP_CONNECT_TIME_OUT);
	        httpURLConnection.setReadTimeout(GTCOMMON.GT_HTTP_READ_TIME_OUT);
	        httpURLConnection.setInstanceFollowRedirects(GTCOMMON.GT_HTTP_INSTANCE_FOLLOW_REDIRECTS);	       
			
            
		} catch (MalformedURLException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpURLConnection", "**MalformedURLException**ERROR", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpURLConnection", "**IOException**ERROR", e.getMessage());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpURLConnection", "**IllegalArgumentException**ERROR", e.getMessage());
		}    
	
	    return httpURLConnection;
		
	}
    
    public static HttpsURLConnection getHttpsDataURLConnection(String connect_url, String method, String contentType, IOnlineContext onlineCtx){
			       
	    URL url = null;
	    HttpsURLConnection httpsURLConnection = null;
	    
		try {		
			
			url = new URL(connect_url);
			httpsURLConnection = (HttpsURLConnection) url.openConnection();		
			httpsURLConnection.setRequestMethod(method);
			httpsURLConnection.setRequestProperty("Content-Type", contentType);	
			httpsURLConnection.setDoOutput(GTCOMMON.GT_HTTP_DO_OUTPUT);     		
            
		} catch (MalformedURLException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpsDataURLConnection", "**MalformedURLException**ERROR", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpsDataURLConnection", "**IOException**ERROR", e.getMessage());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpsDataURLConnection", "**IllegalArgumentException**ERROR", e.getMessage());
		}    
	
	    return httpsURLConnection;
		
	}
	
	public static HttpURLConnection getHttpDataURLConnection(String connect_url, String method, String contentType, IOnlineContext onlineCtx){
		   
	    URL url = null;
	    HttpURLConnection httpURLConnection = null;
	    
		try {		
			
			url = new URL(connect_url);
			httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod(method);
			httpURLConnection.setRequestProperty("Content-Type", contentType);	
			httpURLConnection.setDoOutput(GTCOMMON.GT_HTTP_DO_OUTPUT);        
			            
		} catch (MalformedURLException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpDataURLConnection", "**MalformedURLException**ERROR", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpDataURLConnection", "**IOException**ERROR", e.getMessage());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();            
			FGIFT_01.fPrintLog("FGIFT_01", "getHttpDataURLConnection", "**IllegalArgumentException**ERROR", e.getMessage());
		}    
	
	    return httpURLConnection;
		
	}
	
	/**
	 * [FM]로그 프린트.
	 * <pre>
	 * [FM]로그 프린트
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-18 10:58:00
	 */
	
	public static void fPrintLog(String className, String method, String logLevel, String message) {	    
	
	    System.out.println("++++["+"@"+className+"=>."+ method + "=>" + "!#"+logLevel+ "#=>"+ "\""+ message+"\"]++++");
	
	}  
  
}