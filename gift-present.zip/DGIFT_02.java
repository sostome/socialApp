package com.skcc.bcsvc.gift.biz;

import java.util.Map;

import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;

/**
 * [DU]상품권 - 선물하기.
 * <pre>
 * [DU]상품권 - 선물하기
 * </pre>
 * 
 * @author baekjg (백진구)
 * @since 2018-07-16 11:15:55
 */
@BizUnit("[DU]상품권 - 선물하기")
public class DGIFT_02 extends nexcore.framework.biz.online.DataUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */

	/**
	 * Default Constructor
	 */
	public DGIFT_02(){
		super();
	}

	/**
	 * [DM]상품권 - 선물하기 - 보내는 사람 주소 가져오기.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 보내는 사람 주소 가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 11:17:20
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 보내는 사람 주소 조회")
	public IDataSet s001(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	  
	    IRecord record = dbSelectSingle("S001", requestData, onlineCtx);
	   
	    if (record != null){
	        responseData.putAll(record);
	    }	  
	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - 받는 사람 주소 가져오기.
	 * <pre>
	 * [DM]상품권 - 선물하기 - 받는 사람 주소 가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 11:17:56
	 */
	@BizMethod("[DM]상품권 - 선물하기 - 받는 사람 주소 조회")
	public IDataSet s002(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	   
	    IRecord record = dbSelectSingle("S002", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	    	
	    return responseData;
	}

	/**
	 * [DM]상품권 - 선물하기 - BCT_GIFT_HIST GIFT_HIST_NO 최대값+1가져오기.
	 * <pre>
	 * [DM]상품권 - 선물하기 - BCT_GIFT_HIST GIFT_HIST_NO 최대값+1가져오기
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-16 11:19:40
	 */
	@BizMethod("[DM]상품권 - 선물하기 - BCT_GIFT_HIST GIFT_HIST_NO 최대값+1조회")
	public IDataSet s003(IDataSet requestData, IOnlineContext onlineCtx) {
	    
		IDataSet responseData = new DataSet();
	    Log log = getLog(onlineCtx);
	   
	    IRecord record = dbSelectSingle("S003", requestData, onlineCtx);
	    
	    if (record != null){
	        responseData.putAll(record);
	    }
	    	
	    return responseData;
	}
  
}