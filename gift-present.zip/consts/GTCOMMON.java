package com.skcc.bcsvc.gift.consts;

/**
 * GTCOMMON 상수 클래스. 
 * <pre>
 * com.skcc.bcsvc.gift [상품권] 컴포넌트에서 사용할 상수를 정의 합니다.
 * </pre>
 * @author baekjg (백진구)
 * @since 2018-07-15 09:49:59
 */
public interface GTCOMMON {
	public static final String GT_HTTP_POST_METHOD = "POST";
	public static final String GT_HTTP_JSON_ACCEPT = "application/json";
	public static final String GT_HTTP_JSON_CONTENT_TYPE = "application/json";
	public static final String GT_HTTP_FORM_CONTENT_TYPE = "application/x-www-form-urlencoded";
	public static final int GT_HTTP_CONNECT_TIME_OUT = 5000;
	public static final int GT_HTTP_READ_TIME_OUT = 5000;
	public static final boolean GT_HTTP_DO_OUTPUT = true;
	public static final boolean GT_HTTP_INSTANCE_FOLLOW_REDIRECTS = true;
}