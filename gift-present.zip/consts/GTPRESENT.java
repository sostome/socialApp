package com.skcc.bcsvc.gift.consts;

/**
 * GTPRESENT 상수 클래스. 
 * <pre>
 * com.skcc.bcsvc.gift [상품권] 컴포넌트에서 사용할 상수를 정의 합니다.
 * </pre>
 * @author baekjg (백진구)
 * @since 2018-07-15 09:50:13
 */
public interface GTPRESENT {
	public static final String GT_TG_OAUTH2_AUTH_HEADER_URL = "https://gw4sk.skcc.com/auth/realms/skcc_gw_auth/protocol/openid-connect/token";
	public static final String GT_LAB_OAUTH2_AUTH_HEADER_URL = "https://skcoin.skcc.com/auth/realms/skcoinlab_auth/protocol/openid-connect/token";
	public static final String GT_RIPPLE_COIN_NET_URL = "http://io1.skcc.com:5005";
	public static final String GT_TG_OAUTH2_AUTH_ID = "bobserver";
	public static final String GT_TG_OAUTH2_AUTH_SECRET = "a6686c3e-b146-4f06-96f7-43e5659f5308";
	public static final String GT_LAB_OAUTH2_AUTH_ID = "bobserver";
	public static final String GT_LAB_OAUTH2_AUTH_SECRET = "1e7ed902-66ec-42ee-bb94-2cbfc1ed5613";
	public static final String GT_TG_PAY_TOKEN_CREATE_URL = "https://gw4sk.skcc.com/pay/api/v2/token";
	public static final String GT_TG_PAY_APPROVAL_URL = "https://gw4sk.skcc.com/pay/api/v2/approval";
	public static final String GT_NET_PROD_GIFT_PRESENT_URL = "http://io.skcc.com:5005";
	public static final String GT_NET_DEV_GIFT_PRESENT_URL = "http://io1.skcc.com:5005";
	//https://skcoin.skcc.com/payment/api/v2/approval
	//https://skcoin.skcc.com/tg-info/api/v2/currencies
	public static final String GT_TG_PAY_TOKEN_VALIDATION_URL = "http://io1.skcc.com:5005";
}