package com.skcc.bcsvc.bc.biz;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import nexcore.framework.core.component.streotype.BizAttribute;
import nexcore.framework.core.component.streotype.BizMethod;
import nexcore.framework.core.component.streotype.BizUnit;
import nexcore.framework.core.component.streotype.BizUnitBind;
import nexcore.framework.core.data.DataSet;
import nexcore.framework.core.data.IDataSet;
import nexcore.framework.core.data.IOnlineContext;
import nexcore.framework.core.data.IRecord;
import nexcore.framework.core.data.IRecordSet;
import nexcore.framework.core.data.IResultMessage;
import nexcore.framework.core.data.ResultMessage;
import nexcore.framework.core.data.UserMessage;
import nexcore.framework.core.exception.BizRuntimeException;

import org.apache.commons.logging.Log;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.skcc.bcsvc.bc.consts.CCOMMON;
import com.skcc.bcsvc.bc.consts.CFCOIN;

/**
 * [FU]코인OAUTH2TOKEN.
 * <pre>
 * [FU]코인OAUTH2TOKEN
 * </pre>
 * 
 * @author baekjg (백진구)
 * @since 2018-07-09 21:16:20
 */
@BizUnit("[FU]코인OAUTH2TOKEN")
public class FTOKEN extends nexcore.framework.biz.online.FunctionUnit {

	/**
	 * 이 클래스는 Singleton 객체로 수행됩니다. 
	 * 여기에 필드를 선언하여 사용하면 동시성 문제를 일으킬 수 있습니다.
	 */

	@BizUnitBind
	private FHTTPSConnection fHTTPSConnection;
	
	/**
	 * Default Constructor
	 */
	public FTOKEN(){
		super();
	}
	
	/**
	 * [FM]코인 OAUTH2HTTP 통신.
	 * <pre>
	 * [FM]코인 OAUTH2HTTP 통신
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-09 21:18:01
	 */
	@BizAttribute(isShared = true)
	@BizMethod("[FM]코인 OAUTH2HTTP 통신")
	public IDataSet fOAUTH2HTTP(IDataSet requestData, IOnlineContext onlineCtx) {
		 IDataSet responseData = new DataSet();
		    
		    Log log = getLog(onlineCtx);
		    String authHeader = "";
		    URL url = null;
		    HttpsURLConnection httpsURLConnection = null;
		    String method = "";
		    String contentType = "";
		    DataOutputStream outputStream = null;
		    StringBuffer stringBuffer = new StringBuffer();

			try {				
								
				authHeader = getBasicAuthHeader(requestData.getString("AUTH_ID"), requestData.getString("AUTH_SECRET"));			   
			    method = requestData.getString("METHOD");
			    contentType = requestData.getString("CONTENT_TYPE");
			    
			    FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "INFO", "Authorization:"+authHeader);
			    FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "INFO", "URL:"+requestData.getString("URL"));
			    FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "INFO", "METHOD:"+method);
			    FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "INFO", "CONTENT-TYPE:"+contentType);
			    			
				httpsURLConnection = fHTTPSConnection.getHttpsDataURLConnection(requestData.getString("URL"), method, contentType, onlineCtx);				
				httpsURLConnection.setRequestProperty("Authorization", authHeader);			
					            
				outputStream = new DataOutputStream(httpsURLConnection.getOutputStream());
				outputStream.write("grant_type=client_credentials".getBytes());
				outputStream.flush();
				outputStream.close();
				
				if (httpsURLConnection.getResponseCode() == 200) {
					
					BufferedReader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
		            String inputLine;
		            
		            while ((inputLine = reader.readLine()) != null) {
		            	stringBuffer.append(inputLine);
		            }
		            
					reader.close();
					
		        	JSONParser jsonParser = new JSONParser();
		        	JSONObject jsonObj = (JSONObject) jsonParser.parse(stringBuffer.toString());
		        			        	
		        	FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "INFO", stringBuffer.toString());
		        	
		        	responseData.put("token_type", jsonObj.get("token_type"));
		        	responseData.put("access_token", jsonObj.get("access_token"));
		        	responseData.put("refresh_token", jsonObj.get("refresh_token"));
		        	responseData.put("expires_in", jsonObj.get("expires_in"));
		        	responseData.put("refresh_expires_in", jsonObj.get("refresh_expires_in"));
		        	responseData.put("not-before-policy", jsonObj.get("not-before-policy"));
		        	responseData.put("session_state", jsonObj.get("session_state"));
		        	responseData.put("scope", jsonObj.get("scope"));		        	
		        	
				}
				
				httpsURLConnection.disconnect();
				            
			} catch (MalformedURLException e) {
				e.printStackTrace();
	            log.error("[오류] [MalformedURLException] " + e.getMessage());
	            FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "**MalformedURLException**ERROR", e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
	            log.error("[오류] [IOException] " + e.getMessage());
	            FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "**IOException**ERROR", e.getMessage());
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
	            log.error("[오류] [IllegalArgumentException] " + e.getMessage());
	            FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "**IllegalArgumentException**ERROR", e.getMessage());
			} catch (ParseException e) {
				e.printStackTrace();
	            log.error("[오류] [ParseException] " + e.getMessage());
	            FCOIN_02.fPrintLog("FTOKEN", "fOAUTH2HTTP", "**ParseException**ERROR", e.getMessage());
	        }
			
		    return responseData;
	}
	
	public String getBasicAuthHeader(String id, String pwd) {
		String joint = id+":"+pwd;
		String authHeader = "Basic "+Base64.getEncoder().encodeToString(joint.getBytes());
		return authHeader;
	}

	/**
	 * [FM]SK COIN TG TOKEN 조회 생성.
	 * <pre>
	 * [FM]SK COIN TG TOKEN 조회 생성
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-09 21:37:06
	 */
	@BizAttribute(isShared = true)
	@BizMethod("[FM]SK COIN TG TOKEN 조회 생성")
	public IDataSet fGetOAUTH2SKTgTOKEN(IDataSet requestData, IOnlineContext onlineCtx) {

		IDataSet responseData = new DataSet();
		IDataSet result = new DataSet();
		String token_type = "";
		String access_token = "";
		Log log = getLog(onlineCtx);
	    
        try {
 
        	requestData.put("AUTH_ID", CFCOIN.BC_TG_OAUTH2_AUTH_ID);        	
        	requestData.put("AUTH_SECRET", CFCOIN.BC_TG_OAUTH2_AUTH_SECRET);        	
        	requestData.put("URL",CFCOIN.BC_TG_OAUTH2_AUTH_HEADER_URL);
        	requestData.put("METHOD", CCOMMON.BC_HTTP_POST_METHOD);
        	requestData.put("CONTENT_TYPE", CCOMMON.BC_HTTP_FORM_CONTENT_TYPE);
        	
        	result = fOAUTH2HTTP(requestData, onlineCtx);
        	token_type = result.getString("token_type");
        	access_token = result.getString("access_token");
        	
        	FCOIN_02.fPrintLog("FTOKEN", "fGetOAUTH2SKTgTOKEN", "INFO", "token_type:"+token_type);
        	FCOIN_02.fPrintLog("FTOKEN", "fGetOAUTH2SKTgTOKEN", "INFO", "access_token:"+access_token);
        	
            responseData.put("authHeader", token_type+" "+access_token);
        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
            
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FCOIN_02.fPrintLog("FTOKEN", "fGetOAUTH2SKTgTOKEN", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FCOIN_02.fPrintLog("FTOKEN", "fGetOAUTH2SKTgTOKEN", "**Exception**ERROR", e.getMessage());
        }
        
	    return responseData;
	}

	/**
	 * SK COIN LAB TOKEN 조회 생성.
	 * <pre>
	 * SK COIN LAB TOKEN 조회 생성
	 * </pre>
	 * @param requestData 요청정보 DataSet 객체
	 * @param onlineCtx 요청 컨텍스트 정보
	 * @return 처리결과 DataSet 객체
	 * 
	 * @author baekjg (백진구)
	 * @since 2018-07-09 21:38:06
	 */
	@BizAttribute(isShared = true)
	@BizMethod("SK COIN LAB TOKEN 조회 생성")
	public IDataSet fGetOAUTH2SKLabToken(IDataSet requestData, IOnlineContext onlineCtx) {

		IDataSet responseData = new DataSet();
		IDataSet result = new DataSet();
		String token_type = "";
		String access_token = "";
		Log log = getLog(onlineCtx);
	    
        try {
 
        	requestData.put("AUTH_ID", CFCOIN.BC_LAB_OAUTH2_AUTH_ID);
        	requestData.put("AUTH_SECRET", CFCOIN.BC_LAB_OAUTH2_AUTH_SECRET);
        	requestData.put("URL", CFCOIN.BC_LAB_OAUTH2_AUTH_HEADER_URL);
        	requestData.put("METHOD", CCOMMON.BC_HTTP_POST_METHOD);
        	requestData.put("CONTENT_TYPE", CCOMMON.BC_HTTP_FORM_CONTENT_TYPE);
        	
        	result = fOAUTH2HTTP(requestData, onlineCtx);
        	token_type = result.getString("token_type");
        	access_token = result.getString("access_token");
        	
            responseData.put("authHeader", token_type+" "+access_token);
        	
            onlineCtx.setUserMessage(UserMessage.OK, "BCSVC-I000", null);
        
        } catch(BizRuntimeException be) {
        	be.printStackTrace();
            log.error("<오류> <BizRuntimeException> " + be.getMessage());
            FCOIN_02.fPrintLog("FTOKEN", "fGetOAUTH2SKLabToken", "**BizRuntimeException**ERROR", be.getMessage());
        } catch(Exception e) {
        	e.printStackTrace();
            log.error("<오류> <Exception> " + e.getMessage());
            FCOIN_02.fPrintLog("FTOKEN", "fGetOAUTH2SKLabToken", "**Exception**ERROR", e.getMessage());
        }
        
	    return responseData;
	}
  
}